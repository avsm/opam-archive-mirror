open Lazy

include (Monad.Make(struct
  type 'a t = 'a Lazy.t

  let return : 'a -> 'a t = lazy_from_val
  let bind z f = f (force z)
end) : Monad_intf.T with type 'a t := 'a Lazy.t)

let (!!) = force
let eager = Lazy.lazy_from_val
let from_val = Lazy.lazy_from_val

let peek v = if lazy_is_val v then Some (!!v) else None
      
let map f v = 
  if lazy_is_val v then eager (f !!v)
  else lazy (f !!v)

let is_val = lazy_is_val

let detuple xy = 
  map fst xy,
  map snd xy
