let foldi_left f st a =
  let len = Array.length a in
  let rec loop st i = 
    if i = len then st
    else
      loop (f st i (Array.unsafe_get a i)) (i+1)
  in
  loop st 0

let foldi_right f a st =
  let len = Array.length a in
  let rec loop st i = 
    if i = -1 then st
    else
      loop (f i (Array.unsafe_get a i) st) (i+1)
  in
  loop st (len-1)
