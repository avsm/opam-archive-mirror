(* command line argument spec *)

open Base
module Hashtbl = struct
  include Hashtbl
  include Xhashtbl
end
module List = struct
  include List
  include Xlist
end

type 'a opt = { 
  short : char option;
  long : string option;
  arg : [ `Nullary of 'a | `Unary of (string -> 'a) ]
}

let nullary short long arg = 
  match short, long with
  | None, None -> assert false
  |_ -> { short; long; arg = `Nullary arg }

let unary short long arg = 
  match short, long with
  | None, None -> assert false
  |_ -> { short; long; arg = `Unary arg }

type 'a t = {
  shorts : (char  , 'a opt) Hashtbl.t;
  longs  : (string * 'a opt) list;
}

let make opts =
  let shorts = Hashtbl.create 107 in
  List.iter (function 
    | { short= None } -> ()
    | ({ short= Some c } as o) ->
        Hashtbl.alter shorts c (function
          | Some _ -> assert false
          | None -> Some o)) opts;
  let longs = List.filter_map (function
    | { long= None } -> None
    | ({ long=Some s } as o) -> Some (s, o)) opts
  in
  let keys = List.map fst longs in
  let rec check st = function
    | [] -> ()
    | x::_ when List.mem x st -> assert false
    | x::xs -> check (x::st) xs
  in
  check [] keys;
  { shorts; longs }
    

  let string_tail s from = String.sub s from (String.length s - from)
    
  let rec parse t st = function
    | [] -> `Ok (List.rev st)
    | arg::args -> 
        match arg with
        | _ when String.length arg = 1 -> parse t (`Anon arg :: st) args
        | "--" -> `Ok (List.rev_append st (List.map (fun x -> `Anon x) args))
        | _ ->
            match arg.[0], arg.[1] with
            | '\\', '-' -> parse t (`Anon (string_tail arg 1) :: st) args
            | '-', '-' -> parse_long_switch t st (string_tail arg 2) args
            | '-', _ -> parse_short_switch t st (string_tail arg 1) args
            | _ -> parse t (`Anon arg :: st) args
      
  and parse_short_switch t st sw args =
    let len = String.length sw in
    let rec parse_sw st char_pos =
      if len <= char_pos then parse t st args
      else
        let sw_char = sw.[char_pos] in
        try
          let switch = Hashtbl.find t.shorts sw_char in
          match switch.arg with
          | `Unary f when len = char_pos + 1 ->
              get_parameter t st f (!% "-%c" sw_char) args
          | `Unary _ -> assert false
          | `Nullary v -> parse_sw (v :: st) (char_pos+1)
        with
        | Not_found -> `Error (!% "unknown option -%c" sw_char)
    in
    parse_sw st 0
      
  and parse_long_switch t st sw args =
    let sw, param =
      try
        let pos = String.index sw '=' in
        String.sub sw 0 (pos - 1), Some (string_tail sw (pos + 1))
      with
      | Not_found -> sw, None
    in
    let rec find found = function
      | [] ->
          begin match found with
          | None -> `Error (Printf.sprintf "unknown option --%s" sw)
          | Some switch ->
              match switch.arg, param with
              | `Unary f, Some param -> parse t (f param :: st) args
              | `Nullary v, None -> parse t (v :: st) args
              | _ -> assert false
          end
      | (k,switch) :: kss ->
          match
            try Some (String.sub k 0 (String.length sw)) with _ -> None
          with
          | Some k' when k = k' ->
              if found = None then find (Some switch) kss
              else `Error (Printf.sprintf "ambiguous option --%s" sw)
          | Some _ | None -> find found kss
    in
    find None t.longs

  and get_parameter t st f name = function
    | [] -> `Error (!% "option %s requires an argument" name)
    | arg::args -> parse t (f arg :: st) args

  let parse opts args = parse (make opts) [] args

