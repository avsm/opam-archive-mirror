(******************************************************************************)
(*     Alt-Ergo: The SMT Solver For Software Verification                     *)
(*     Copyright (C) 2013-2015 --- OCamlPro                                   *)
(*     This file is distributed under the terms of the CeCILL-C licence       *)
(******************************************************************************)

(* WARNING: a "cut" is performed on the following file in the Makefile.
   DO NOT CHANGE its format *)

let version="1.01"

let release_commit = "(not released)"

let release_date   = "(not released)"


let version="1.01"
let release_commit = "afced17160dd4c46b4b4e817b150e5c2d95ca671"
let release_date = "Tue Feb 16 11:53:41 CET 2016"
