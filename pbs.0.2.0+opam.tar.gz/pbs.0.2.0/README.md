ocaml-pbs
=========

Wrapper around PBS commands, and maybe some day protocol implementation

Modules (available through the pack module `Pbs` or directly with their `Pbs_` name):

- `Script` (a.k.a `Pbs_script`): functions to generate PBS scripts
- `Qstat` (a.k.a. `Pbs_qstat`) parse and manipulate the output of the `qstat` command

