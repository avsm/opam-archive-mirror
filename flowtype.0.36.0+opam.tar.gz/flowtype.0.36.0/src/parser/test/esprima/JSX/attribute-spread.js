<span {... style}></span>
