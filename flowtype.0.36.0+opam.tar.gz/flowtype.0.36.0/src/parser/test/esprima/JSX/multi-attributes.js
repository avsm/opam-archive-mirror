<home xlink:type="simple" other="foo" ></home>
