<sample test="This is &#0169; by Joe"></sample>
