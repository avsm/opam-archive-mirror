<foo.bar></foo.baz>
