/* assignmenr */
 a = b