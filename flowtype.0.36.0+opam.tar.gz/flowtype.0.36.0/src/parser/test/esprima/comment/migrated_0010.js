/* multiline
comment
should
be
ignored */ 42