while (true) {
  /**
   * comments in empty block
   */
}
