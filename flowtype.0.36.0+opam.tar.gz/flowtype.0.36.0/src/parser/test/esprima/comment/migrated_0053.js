/**/ function a() {function o() {}}
