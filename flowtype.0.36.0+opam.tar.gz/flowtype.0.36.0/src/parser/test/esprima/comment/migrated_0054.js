/**/ function a() {/**/function o() {}}
