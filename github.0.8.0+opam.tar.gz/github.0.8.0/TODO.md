Library:

* X-Rate-Limit support in the Monad.

* Can ATDgen map strings through functions
  (to get `Url.t` instead of a `string`, for example)

Git-jar:

* Add a `show [-r|-l]` to do only remote or local, so that
  Github connectivity isn't necessary just to query local cookies.

* Factor out the common user/pass Args instead of repeating the code.
