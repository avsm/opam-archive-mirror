v0.8.0 2016-03-08 La Forclaz (VS)
---------------------------------

First release. 
