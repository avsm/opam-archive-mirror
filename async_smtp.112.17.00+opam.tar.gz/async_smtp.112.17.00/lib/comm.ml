type t =
  | Helo of string
  | Sender of string
  | Recipient of string
  | Data
  | Quit
  | Help
  | Noop
