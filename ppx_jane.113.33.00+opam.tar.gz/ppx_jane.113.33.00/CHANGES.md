## 113.24.01

- Fix ocamlfind integration so that it's easier to use with ocamlbuild
  or the toplevel

## 113.24.00

- Initial release
