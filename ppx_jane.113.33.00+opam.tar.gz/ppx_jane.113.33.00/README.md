Standard Jane Street ppx rewriters
==================================

ppx\_jane is a [ppx_driver](https://github.com/janestreet/ppx_driver)
including all standard ppx rewriters.
