let () =
  print_endline "abc"

let () =
  print_endline "abc";
  print_endline "def"

let () =
  print_endline "abc";
  print_endline "def";
  print_endline "ghi"
