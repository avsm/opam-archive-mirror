operf-micro
===========

A set of micro-benchmarks for OCaml compiler

See more details on http://www.typerex.org/operf-micro.html
