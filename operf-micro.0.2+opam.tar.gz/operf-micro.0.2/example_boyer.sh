ocamlopt cycles.c time_stamp_counter.ml micro_bench_types.mli micro_bench_types.ml -I benchmarks/boyer benchmarks/boyer/boyer.ml micro_bench_run.ml -o benchmarks/boyer/benchmark.native
