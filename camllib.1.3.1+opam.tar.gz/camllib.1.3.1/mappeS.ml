(** Mappe specialized for keys of type string *)

include Mappe.Make(SetteS)
