let path () = Printf.printf "PATH: %s\n" [%getenv "PATH"]
