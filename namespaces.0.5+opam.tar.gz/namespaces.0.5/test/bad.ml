let () =
  Printf.printf "%i\n" Foo.v
