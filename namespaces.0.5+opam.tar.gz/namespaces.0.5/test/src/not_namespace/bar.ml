(* This module is inside a directory that is not tagged with "namespace", so it
   becomes a top-level module, as normal in OCaml. *)

let v = 10
