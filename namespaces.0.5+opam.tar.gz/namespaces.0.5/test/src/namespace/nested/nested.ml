(* This module is included at the namespace level, i.e. the values and types
   here will end up in Namespace.Nested. *)

let v = -1
