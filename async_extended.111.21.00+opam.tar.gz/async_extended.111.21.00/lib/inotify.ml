(* For backward compatibility. *)
include Async_inotify
