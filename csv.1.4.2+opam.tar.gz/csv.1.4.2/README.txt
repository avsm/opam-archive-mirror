(* OASIS_START *)
(* DO NOT EDIT (digest: d129a61ea14f757cedefb5e9e948aa41) *)

csv - A pure OCaml library to read and write CSV files.
=======================================================

This is a pure OCaml library to read and write CSV files, including all
extensions used by Excel — e.g. quotes, newlines, 8 bit characters in
fields, \"0 etc.  A special representation of rows of CSV files with a header
is provided.  The library comes with a handy command line tool called csvtool
for handling CSV files from shell scripts.

See the file [INSTALL.txt](INSTALL.txt) for building and installation
instructions.

[Home page](https://github.com/Chris00/ocaml-csv)

Copyright and license
---------------------

csv is distributed under the terms of the GNU Lesser General Public License
version 2.1 with OCaml linking exception.

(* OASIS_STOP *)
