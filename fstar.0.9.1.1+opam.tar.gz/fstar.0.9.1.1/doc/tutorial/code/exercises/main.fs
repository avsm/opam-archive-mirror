module AclsTest

UntrustedClientCode.dynamicChecking()
