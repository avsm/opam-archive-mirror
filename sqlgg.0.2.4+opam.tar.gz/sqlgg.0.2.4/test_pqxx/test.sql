# @create_employee
CREATE TABLE employee (id SERIAL PRIMARY KEY, name TEXT, salary INT);
# @insert_employee
INSERT INTO employee (name,salary) VALUES;
# @select_name
SELECT name FROM employee;
