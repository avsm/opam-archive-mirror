module Types = Elf_types
type t = Types.elf
include Elf_utils
include Elf_parse
