let package_name = "ppx_xml_conv"

let sections =
  [ ("lib",
    [ ("built_lib_ppx_xml_conv", None)
    ],
    [ ("META", None)
    ])
  ]
