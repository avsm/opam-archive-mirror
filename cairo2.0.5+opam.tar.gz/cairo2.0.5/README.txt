(* OASIS_START *)
(* DO NOT EDIT (digest: f4d38cf6f6b35cde666eb28503360062) *)

cairo2 - Binding to Cairo, a 2D Vector Graphics Library.
========================================================

This is a binding to Cairo, a 2D graphics library with support for multiple
output devices.  Currently supported output targets include the X Window
System, Quartz, Win32, image buffers, PostScript, PDF, and SVG file output.

See the file [INSTALL.txt](INSTALL.txt) for building and installation
instructions.

[Home page](https://github.com/Chris00/ocaml-cairo)

Copyright and license
---------------------

cairo2 is distributed under the terms of the GNU Lesser General Public
License version 3.0 with OCaml linking exception.

(* OASIS_STOP *)
