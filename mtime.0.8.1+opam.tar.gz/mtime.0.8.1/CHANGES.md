v0.8.1 2015-03-23 La Forclaz (VS)
---------------------------------

* Fix broken arithmetic on 32-bit platform with POSIX clocks. Thanks to
  Stephen Dolan for the report and the fix.


v0.8.0 2015-03-19 La Forclaz (VS)
---------------------------------

First release.
