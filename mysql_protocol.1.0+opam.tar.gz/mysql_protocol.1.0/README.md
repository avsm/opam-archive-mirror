mysql_protocol
==============

OCaml implementation of MySQL Protocol with the Bitstring library
