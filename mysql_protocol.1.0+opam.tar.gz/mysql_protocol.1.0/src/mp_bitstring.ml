
(* to have a 4*8 computed expression in order to force a Int64 type for length *)
let compute32 = 4 * 8;;
