include Version

let libdir = libdir ^ "herd"
