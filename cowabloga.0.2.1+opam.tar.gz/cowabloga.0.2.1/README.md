Helper OCaml libraries for setting up a blog and wiki, using the Zurb
Foundation CSS/HTML templates.

This is code extracted from the Mirage website, and is still being tidied
up for general use. See <http://openmirage.org> for more information.
