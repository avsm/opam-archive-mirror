0.3.0 (25-06-2015)
- Fix the `update` function
- Use a tail recursive List.map, for larger datasets
- `flow` can take a `Time t`
- Can set labels on x and y axis

0.2.1 (14-06-2015)
- Fix uninstall and install Makefile targets

0.2 (14-06-2015)
- Add `update` to allow segments to be replaced
- Rename old `update` to `flow`

0.1 (14-06-2015)
- Initial release
