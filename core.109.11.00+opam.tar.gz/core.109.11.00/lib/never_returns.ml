type never_returns with sexp_of

let never_returns (_ : never_returns) = assert false
