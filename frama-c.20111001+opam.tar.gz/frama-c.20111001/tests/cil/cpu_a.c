/* run.config
   OPT: tests/cil/cpu_b.c -machdep x86_16 -print
*/
typedef unsigned short DWORD ;

DWORD f(void) { return 0; }
