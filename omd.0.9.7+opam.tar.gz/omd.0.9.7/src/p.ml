let rec customized_to_html md =
  Omd_backend.html_of_md 
    ~override:(function
        | Omd_representation.Url (href,s,title) ->
          Some("<a href='" 
               ^ (Omd_utils.htmlentities ~md:true href) ^ "'"
               ^ (if title <> "" then
                    " title='" ^ (Omd_utils.htmlentities ~md:true title) ^ "'"
                  else "")
               ^ ">"
               ^ customized_to_html s ^ " target='_blank'</a>")
        | Omd_representation.Emph e ->
          Some("<em class='foo'>" ^  customized_to_html md ^ "</em>")
        | _ -> None)
    md
