let p = 42 in
let xx = 4 in
let xx = 4 in
let xx = 4 in
let xx = 4 in
let xx = 4 in
xx ^ p ;;

