(* OASIS_START *)
(* DO NOT EDIT (digest: adf4b1af28c28b3aec2e03f3c7491f5b) *)
This is the README file for the mpp distribution.

A meta preprocessor.

A meta preprocessor that works very well with OCaml.

See the files INSTALL.txt for building and installation instructions. 

Home page: https://github.com/pw374/MPP-language-blender


(* OASIS_STOP *)
