# Changelog

## dev

## 0.2

Now require llvm>=3.6

* Bugfix for fold_succ_e
* Restore compat with ocamlgraph 1.8.6
* Add Llvm's uses as label on edges.

## 0.1

* Init !
