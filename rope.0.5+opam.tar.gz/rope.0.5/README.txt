(* OASIS_START *)
(* DO NOT EDIT (digest: 689b19a9252de937559cc9db16d13157) *)
This is the README file for the rope distribution.

Ropes ("heavyweight strings")

Ropes ("heavyweight strings") are a scalable string implementation: they are
designed for efficient operation that involve the string as a whole. 
Operations such as concatenation, and substring take time that is nearly
independent of the length of the string.  Unlike strings, ropes are a
reasonable representation for very long strings such as edit buffers or mail
messages.

See the files INSTALL.txt for building and installation instructions. 

Home page: http://rope.forge.ocamlcore.org/


(* OASIS_STOP *)
