let apply_rewriters_str ?restore ~tool_name x = x
let apply_rewriters_sig ?restore ~tool_name x = x
