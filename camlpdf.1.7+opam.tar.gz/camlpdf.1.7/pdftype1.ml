(* Convert a PostScript Type 1 Font to a Type 3 font. *)
open Pdfutil
open Pdfio

let to_type3 pdf font = font

