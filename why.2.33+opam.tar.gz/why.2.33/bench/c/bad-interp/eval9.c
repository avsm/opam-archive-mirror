void f (){
  char x = '\9';
}
