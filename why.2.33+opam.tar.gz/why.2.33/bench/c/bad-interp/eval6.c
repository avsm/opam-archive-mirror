void f (){
  int x = 0x800000000000000000ll;
}
