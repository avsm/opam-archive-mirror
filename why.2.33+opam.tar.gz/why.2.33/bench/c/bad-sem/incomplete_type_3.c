typedef struct S tau;
tau x;
void f() { x.f = 0; }
