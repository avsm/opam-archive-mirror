

struct s { int x; };


int f() {
  struct s a b;
  return (a==b);
}
