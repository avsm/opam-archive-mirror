void foo () {
  int a[3];
  int *b = a;
}
