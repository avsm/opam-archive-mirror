typedef struct A
{
  int i;
} A;

typedef struct B
{
  A a;
} B;
