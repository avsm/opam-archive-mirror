void fn() {
  u8"hehe";
  u"hehe";
  U"hehe";
  "hehe";
  L"hehe";
}
