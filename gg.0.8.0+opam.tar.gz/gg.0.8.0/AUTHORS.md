* [Daniel C. Bünzli](http://erratique.ch), Gg module, main developer.
* Edwin Török, color conversion functions. 
