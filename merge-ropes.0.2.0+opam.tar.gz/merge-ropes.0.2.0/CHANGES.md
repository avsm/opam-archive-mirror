### 0.2.0

* Port to 0.9.* Irmin API (patch from @kayceesrk)
* Do not depend on `Core_kernel` anymore
* Do not depend on `sexplib` anymore

### 0.1.0

* Initial release