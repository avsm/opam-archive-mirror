
let () =
  ignore (OUnit.run_test_tt_main (Register_test.tests ()))
