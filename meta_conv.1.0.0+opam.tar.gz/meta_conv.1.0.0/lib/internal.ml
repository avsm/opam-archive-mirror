open Types
open Error
open Result

(** { 6 Misc functions } *)

let list_filter_map f xs = List.fold_right (fun x st -> 
  match f x with
  | None -> st
  | Some v -> v::st) xs []

let list_mapi f xs =
  let rec mapi f pos = function
    | [] -> []
    | x::xs -> f pos x :: mapi f (pos+1) xs
  in
  mapi f 0 xs

let (~?) = function
  | Some trace -> trace
  | None -> []

(** { 6 Error decoders } *)

let tuple_arity_error exp_len act_len ?(trace=[]) v = 
  `Error (Wrong_arity (exp_len, act_len, None), v, trace)
let variant_arity_error type_name constructor_name exp_len act_len ?(trace=[]) v = 
  `Error (Wrong_arity (exp_len, act_len, Some (type_name, constructor_name)), v, trace)
let variant_unknown_tag_error type_name tag_name ?(trace=[]) v =
  `Error (Unknown_tag (type_name, tag_name), v, trace)
let primitive_decoding_failure mes ?(trace=[]) v = 
  `Error (Primitive_decoding_failure mes, v, trace)
let sub_decoders_failed_for_one_of name ?(trace=[]) v =
  `Error (Sub_decoders_failed_for_one_of name, v, trace)

(** { 6 Tools used by generated code } *)

let field_assoc_exn name key alist 
    (throw : 'target Error.t -> 'host) 
    (decode_exn : ('host, 'target) Decoder.t_exn) 
    : ('host, 'target) Decoder.t_exn
  = fun ?(trace=[]) v ->
    try
      let trace = `Field key :: `Node v :: trace in
      decode_exn ?trace:(Some trace) (List.assoc key alist)
    with
    | Not_found -> 
        throw (Required_field_not_found (name, key), v, trace)

let field_assoc_optional_exn _name key alist decode_exn ?(trace=[]) v =
  try 
    let trace = `Field key :: `Node v :: trace in
    Some (decode_exn ?trace:(Some trace) (List.assoc key alist))
  with Not_found -> None

let filter_fields type_system actual =
  List.partition (fun (f,_) -> List.mem f type_system) actual 

let embeded_decoding_helper secondary_fields v = function
  | `Ok v -> `Ok (v, [])
  (* Having this function in Internal is mainly to avoid seeing
     bunch of Warnings 4 due to the next line, if it would be inlined
     in the generalted code. *) 
  | `Error (Error.Unknown_fields (_, keys, o), v', _) when v == v' ->
       (* extract the accepted fields and the decoded value, and rest fields
          - Obj.magic
          - inefficient
       *)
      let secondary_fields = List.filter (fun (k,_) -> List.mem k keys) secondary_fields in
      `Ok (Obj.obj o, secondary_fields)
  | `Error e -> `Error e

(** { 6 Useful tool functions for writing encoders+decoders of primitive types } *)

let integer_of_float min max conv n =
  if floor n <> n then `Error "not an integer"
  else if min <= n && n <= max then `Ok (conv n)
  else `Error "overflow"

let generic_list_of gets (d : (_,_) Decoder.t) ?(trace=[]) v = match gets v with
  | None -> 
      primitive_decoding_failure 
        "Meta_conv.Internal.generic_list_of: listable expected" 
        ~trace
        v
  | Some xs -> 
      let trace = `Node v::trace in 
      (* CR jfuruse: We should use exception to speed up *)
      Result.mapi (fun pos -> d ~trace:(`Pos pos :: trace)) xs

let generic_array_of gets d ?trace v =
  fmap Array.of_list (generic_list_of gets d ?trace v)

let generic_option_of extract f ?trace v =
  match extract v with 
  | Some None -> `Ok None
  | Some (Some v) -> f ?trace v >>= fun x -> `Ok (Some x)
  | None -> 
      primitive_decoding_failure 
        "Meta_conv.Internal.generic_option_of: option expected"
        ?trace v

let generic_lazy_t_of (errorf : 'target Error.t -> 'exn) f ?trace:_ v = 
  `Ok (lazy (
    (* trace is reset to avoid leak *)
    match f ?trace:None v with
    | `Ok v -> v
    | `Error e -> errorf e
  ))

let generic_mc_lazy_t_of f ?trace:_ v = 
  `Ok (lazy (f ?trace:None v)) (* trace is reset, to avoid leak *)

let generic_mc_fields_of get_fields f ?(trace=[]) target =
  let open Result in
  match get_fields target with
  | None -> primitive_decoding_failure "mc_fields expected" ~trace target
  | Some fields ->
      let trace = `Node target :: trace in
      map (fun (name, target) -> f ?trace:(Some (`Field name :: trace)) target >>= fun host -> `Ok (name, host)) fields

let prim_decode f = fun ?(trace=[]) v -> 
  try `Ok (f v) with 
  | Failure mes -> `Error (Primitive_decoding_failure mes, v, trace)

(** { 6 Conv module type } *)

module Make(A : Min) = struct
  include A

  exception Error of target Error.t

  type 'a encoder = ('a, target) Encoder.t
  type 'a decoder = ('a, target) Decoder.t
  type 'a decoder_exn = ('a, target) Decoder.t_exn
  
  module Decode' = struct

    let wrap f = fun ?(trace=([] : target Error.trace)) t -> try `Ok (f t) with exn -> `Error (Exception exn, t, trace)

    let tuple ?trace x = wrap Decode.tuple ?trace x
    let variant ?trace x = wrap Decode.variant ?trace x
    let poly_variant ?trace x = wrap Decode.poly_variant ?trace x
    let record ?trace x = wrap Decode.record ?trace x
    let object_ ?trace x = wrap Decode.object_ ?trace x
      
    let wrap f = fun ?(trace=([] : target Error.trace)) t -> try f t with exn -> raise (Error (Exception exn, t, trace))

    let tuple_exn ?trace x = wrap Decode.tuple ?trace x
    let variant_exn ?trace x = wrap Decode.variant ?trace x
    let poly_variant_exn ?trace x = wrap Decode.poly_variant ?trace x
    let record_exn ?trace x = wrap Decode.record ?trace x
    let object_exn ?trace x = wrap Decode.object_ ?trace x
      
  end

  let exn f ?trace v = match f ?trace v with
    | `Ok v -> v
    | `Error e -> raise (Error e)

  let throw e = raise (Error e)

  let result f ?trace t = 
    try `Ok (f ?trace t) with exn -> `Error (Error.Exception exn, t, ~?trace)

  let from_Ok = function
    | `Ok v -> v
    | `Error e -> raise (Error e)

  let format_error ppf (desc,_,_) = Error.format_desc ppf desc
  let format_full_error = Error.format A.format
end
