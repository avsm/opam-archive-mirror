(** { 6 Encoder } *)

module Encoder = struct
  type ('host, 'target) t = 'host -> 'target
end

(** { 6 Decoder } *)

module Decoder = struct
  type ('host, 'target) t = ?trace:'target Error.trace -> 'target -> ('host, 'target Error.t) Result.t
  type ('host, 'target) t_exn = ?trace:'target Error.trace -> 'target -> 'host
end

(** { 6 Conv module type } *)

module type Min = sig
  type target

  val format : Format.formatter -> target -> unit
  (** The target must be printable. *)  
  (** CR jfuruse: Is it called [print] instead? *)

  module Encode : sig
    val tuple        : target list -> target
    val variant      : string -> target list -> target
    val poly_variant : string -> target list -> target
    val record       : (string * target) list -> target
    val object_      : (string * target) list -> target
  end
  
  module Decode : sig

    (** Primitive ADT decoders. They may raise exceptions. *)

    val tuple        : target -> target list
    val variant      : target -> string * target list
    val poly_variant : target -> string * target list
    val record       : target -> (string * target) list
    val object_      : target -> (string * target) list
  end
end

(** [Internal.Make(A : Min)] returns a module with this signature *) 
module type S = sig

  include Min

  (** Exception for decoding error. We must declare here and not 
      in a more general place, since the error contains [target], 
      and we cannot have polymorphic exceptions in OCaml. *)
  exception Error of target Error.t

  type 'a encoder     = ('a, target) Encoder.t
  type 'a decoder     = ('a, target) Decoder.t
  type 'a decoder_exn = ('a, target) Decoder.t_exn

  (** Module [Decode'] is a wrapped version of [Decode] *)
  module Decode' : sig
    val tuple        : (target list) decoder
    val variant      : (string * target list) decoder
    val poly_variant : (string * target list) decoder
    val record       : ((string * target) list) decoder
    val object_      : ((string * target) list) decoder

    val tuple_exn        : (target list) decoder_exn
    val variant_exn      : (string * target list) decoder_exn
    val poly_variant_exn : (string * target list) decoder_exn
    val record_exn       : ((string * target) list) decoder_exn
    val object_exn       : ((string * target) list) decoder_exn
  end

  val exn : 'a decoder -> 'a decoder_exn
  (** Result monad decoder to decoder with runtime exception [Error]. *)

  val result : 'a decoder_exn -> 'a decoder
  (** Any exception (including [Error]) reported from [decoder_exn] 
      is reported as [`Error] *)

  val throw : target Error.t -> 'exn 
  (** raises [Error] *)

  val from_Ok : [< ('a, target Error.t) Result.t ] -> 'a
  (** If the argument is [`Error e], raises [Error e]. *)

  open Format

  val format_error : formatter -> target Error.t -> unit
  val format_full_error : formatter -> target Error.t -> unit
end

