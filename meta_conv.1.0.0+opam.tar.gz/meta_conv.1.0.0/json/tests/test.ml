open Meta_conv.Open
open Json_conv

module Test1 = struct
  type t = Foo | Bar of int * string with conv(json)
  
  let () = 
    let x = Bar (0, "hello") in
    assert (t_of_json (json_of_t x) = `Ok x)
end

module Test2 = struct
  type t = { foo : int; bar : float option } with conv(json)
  
  let () = 
    let x = { foo = 3; bar = Some 1.2 } in
    assert (t_of_json (json_of_t x) = `Ok x)
end

module Test3 = struct
  open Test2
  type t = Test2.t with conv(json)
  
  let () = 
    let x = { foo = 3; bar = Some 1.2 } in
    assert (t_of_json (json_of_t x) = `Ok x)
end

module Test4 = struct
  type t = Foo (:"foo":) | Bar (:"bar":) of int * string with conv(json)
  
  let () = 
    let x = Bar (0, "hello") in
    assert (t_of_json (json_of_t x) = `Ok x)
end

module Test5 = struct
  type t (: Ignore_unknown_fields :) = { x : int; y : float } with conv (json)
  type t' = { x' as "x" : int; y' as "y" : float; z' as "z" : unit  } with conv (json)
  
  let () = 
    let r' = { x' = 1; y' = 1.0; z' = () }  in
    assert (t_of_json (json_of_t' r') = `Ok { x = 1; y = 1.0 })
end

module Test6 = struct
  type t = { x : int; y : float; rest : Json.t mc_leftovers; } with conv (json)
  type t' = { x' as "x" : int; y' as "y" : float; z' as "z" : unit  } with conv (json)
  
  let () = 
    let r' = { x' = 1; y' = 1.0; z' = () }  in
    assert (t_of_json (json_of_t' r') = `Ok { x = 1; y = 1.0; rest = [ "z", Json.Null ] });
    assert (json_of_t (match t_of_json (json_of_t' r') with `Ok v -> v | _ -> assert false) = json_of_t' r')
end

module Test7 = struct
  type t = int * float * int list with conv (json)

  let () = 
    let v = 1, 1.2, [1;2;3] in
    assert (t_of_json (json_of_t v) = `Ok v)
end

module Test8 = struct

  type t = Foo 

  and ts = t list with conv(json)

end

module Test9 = struct

  type t = { x : int; y : float; z : t }

  and ts = t list with conv(json)

end

module Test10 = struct
  type t = { x : int mc_option } with conv(json)

  let r = { x = None }
  let () = assert (r = t_of_json_exn (json_of_t r))
end

module Test11 = struct
  (* not recursive but defined with [and] *)  
  type t = int
  and  s = float with conv(json)
end

module TestOneOf = struct
  type float2 = float * float with conv(json)
  type t (: one_of :) = Int of int | Float2 of float * float with conv(json)

  let () = 
    let vs = [ json_of_int 42; json_of_float2 (4.2, 4.2) ] in
    assert ( List.map t_of_json vs
               = [ `Ok (Int 42)
                 ; `Ok (Float2 (4.2, 4.2)) 
                 ] ) 
end

module TestOneOf2 = struct
  type float2 = float * float with conv(json)
  type t (: one_of :) = [ `Int of int |  `Float2 of float * float ] with conv(json)

  let () = 
    let vs = [ json_of_int 42; json_of_float2 (4.2, 4.2) ] in
    assert ( List.map t_of_json vs
               = [ `Ok (`Int 42)
                 ; `Ok (`Float2 (4.2, 4.2)) 
                 ] ) 
end

module TestResult = struct
  type t = (int, Json.t) mc_result with conv(json)
  let () =
    let vs = [ json_of_int 42; json_of_float 4.2 ] in
    let js = List.map (fun x -> from_Ok (t_of_json x)) vs in
    let vs' = List.map json_of_t js in
    assert (vs = vs')
end

module TestEmbeded = struct
  type a = { a_x : int; a_y : bool }
  and b = { b_x : float; b_y : char }
  and t = { a : a mc_embeded;
            b : b mc_embeded;
            foo : int;
            bar : int;
            unknowns : Json.t mc_leftovers;
          } with conv(json)

  module X = struct
    type t = { a_x : int; a_y : bool;
               b_x : float; b_y : char;
               foo : int; bar : int;
               z : string } with conv(json)

  end

  let () = 
    let j = X.json_of_t { X.a_x= 1; a_y= false; b_x= 4.2; b_y= 'A'; foo= 42; bar= 100; z= "unknown" } in
    let t = t_of_json_exn j in
    Format.eprintf "%a@." Json_conv.format j;
    let j' = json_of_t t in
    Format.eprintf "%a@." Json_conv.format j';
    assert (j = j')
end

module TestOptionEmbeded = struct
  type a = { a_x : int; a_y : bool }
  and b = { b_x : float; b_y : char }
  and t = { a : a mc_embeded;
            b : b mc_option_embeded;
            foo : int;
            bar : int;
            unknowns : Json.t mc_leftovers;
          } with conv(json)

  module X = struct
    type t = { a_x : int; a_y : bool;
               foo : int; bar : int;
               b_x : float; (* b_y : char; *) (* b_y missing, thus b mc_option_embeded becomes None *)
               z : string } with conv(json)

  end

  let () = 
    let j = X.json_of_t { X.a_x= 1; a_y= false; b_x= 4.2; foo= 42; bar= 100; z= "unknown" } in
    let t = t_of_json_exn j in
    Format.eprintf "%a@." Json_conv.format j;
    let j' = json_of_t t in
    Format.eprintf "%a@." Json_conv.format j';
    assert (j = j')
end

module UserMention = struct
  type t = <
      unknown : Json.t mc_leftovers;

      screen_name : string;
      name : string;
      id : int64;
      indices : int * int;
  > with conv(json)
      
end

module Sig : sig
  type 'a t = { x : int; y : 'a } with conv(json)
end = struct
  type 'a t = { x : int; y : 'a } with conv(json)
end
 

module TestAs = struct

  type t = { x as "xx/xx": int; y : float } with conv(json)

  let () =
    assert (t_of_json (json_of_t {x = 1; y = 4.2}) = `Ok { x = 1; y = 4.2 })

end

