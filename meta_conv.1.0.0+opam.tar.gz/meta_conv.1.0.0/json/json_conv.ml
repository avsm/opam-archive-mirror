open Printf
open Meta_conv.Open
open Meta_conv.Internal
open Json

(* encoders ***************************************************************)

include Meta_conv.Internal.Make(struct 

  type target = Json.t

  let rec format_list sep f ppf = function
    | [] -> ()
    | [x] -> f ppf x
    | x::xs -> f ppf x; Format.fprintf ppf sep; format_list sep f ppf xs

  let rec format ppf = 
    let open Format in
    function
      | String s -> fprintf ppf "%S" s
      | Number f -> fprintf ppf "%f" f
      | Object o -> 
          fprintf ppf "{ @[%a@] }"
            (format_list ";@ " (fun ppf (s,v) -> fprintf ppf "@[%s= @[<v2>%a@]@]" s format v)) o
      | Array ts -> 
          fprintf ppf "[ @[%a@] ]"
            (format_list ";@ " (fun ppf v -> fprintf ppf "@[<v2>%a@]@]" format v)) ts
      | Bool b -> fprintf ppf "%b" b
      | Null -> fprintf ppf "()"

  module Encode = struct
    let tuple ts       = Array ts
    let variant tag = function
      | [] -> String tag
      | ts -> Object [tag, Array ts]
    let record tag_ts  = Object tag_ts
    let poly_variant = variant
    let object_ = record
  end

  module Decode = struct
  
    let tuple = function 
      | Array ts -> ts
      | _ -> failwith "Array expected for tuple"
  
    let variant = function 
      | String tag -> tag, [] 
      | Object [tag, Array ts] -> tag, ts
      | _ -> failwith "Object expected for variant"
  
    let record = function
      | Object alist -> alist
      | _ -> failwith "Object expected for record"
  
    let poly_variant = variant
    let object_ = record
  end

end)

let json_of_int n       = Number (float n)
let json_of_int32 n     = Number (Int32.to_float n)
let json_of_int64 n     = Number (Int64.to_float n)
let json_of_nativeint n = Number (Nativeint.to_float n)
let json_of_char c      = String (String.make 1 c)
let json_of_string s    = String s
let json_of_float n     = Number n
let json_of_list f xs   = Array (List.map f xs)
let json_of_array f xs  = Array (List.map f (Array.to_list xs))
let json_of_bool b      = Bool b
let json_of_lazy_t f v  = f (Lazy.force v)
let json_of_unit ()     = Null
let json_of_option f    = function
  | None -> Null
  | Some v -> f v
  
(* decoders ***************************************************************)

let failwithf fmt = kprintf (fun s -> raise (Failure s)) fmt

let string_of_json = prim_decode (function
  | String s -> s
  | _ -> failwith "string_of_json: String expected")

let char_of_json = prim_decode (function
  | String s when String.length s = 1 -> s.[0]
  | _ -> failwith "char_of_json: a char expected")

let int_check name min max conv = prim_decode (function 
  | Number n -> 
      begin match integer_of_float min max conv n with
      | `Ok v -> v
      | `Error s -> failwithf "%s_of_json: %s" name s
      end
  | _ -> failwithf "%s_of_json: Number expected" name)

let int_of_json =
  int_check "int" (float min_int) (float max_int) int_of_float

let int64_of_json =
  let open Int64 in
  int_check "int64" (to_float min_int) (to_float max_int) of_float
      
let int32_of_json =
  let open Int32 in
  int_check "int32" (to_float min_int) (to_float max_int) of_float
      
let nativeint_of_json = 
  let open Nativeint in
  int_check "nativeint" (to_float min_int) (to_float max_int) of_float
      
let float_of_json = prim_decode (function
  | Number n -> n
  | _ -> failwith "float_of_json: Number expected")

let bool_of_json = prim_decode (function
  | Bool b -> b
  | _ -> failwith "bool_of_json: Bool expected")

let unit_of_json = prim_decode (function
  | Null -> ()
  | _ -> failwith "unit_of_json: Null expected")
  
let list_of_json f = 
  generic_list_of (function Array xs -> Some xs | _ -> None) f

let array_of_json f = 
  generic_array_of (function Array xs -> Some xs | _ -> None) f

let option_of_json f = generic_option_of 
  (function Null -> Some None | v -> Some (Some v))
  f

let lazy_t_of_json d = generic_lazy_t_of (fun e -> raise (Error e)) d
let mc_lazy_t_of_json (d : 'a decoder) = (generic_mc_lazy_t_of d : ('a, Json.t) mc_lazy_t decoder)

let json_of_mc_fields enc xs = Object (List.map (fun (name, a) -> (name, enc a)) xs)
let mc_fields_of_json dec = generic_mc_fields_of (function Object js -> Some js | _ -> None) dec
