type t =
  | String of string
  | Number of float
  | Object of obj
  | Array of t list
  | Bool of bool
  | Null

and obj = (string * t) list

