type t = Foo with conv(json),conv(python)
