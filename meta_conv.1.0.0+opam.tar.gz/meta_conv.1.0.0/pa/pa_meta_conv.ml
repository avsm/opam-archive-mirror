open Camlp4
open PreCast
open Pa_type_conv
open Ast

let _loc = Loc.ghost

open Tctools

(* syntax modification **************************************************)

 open Syntax

let annotations = Hashtbl.create 31

EXTEND Gram
  GLOBAL: constructor_declaration constructor_declarations row_field label_declaration
          type_declaration meth_decl
  ;
  
  constructor_declaration: 
      [ [ s = a_UIDENT; "(:"; e = expr; ":)"; "of"; t = constructor_arg_list ->
            Hashtbl.add annotations (_loc,s) e;
            <:ctyp< $uid:s$ of $t$ >>
        | s = a_UIDENT; "as"; n = a_STRING; "of"; t = constructor_arg_list ->
            Hashtbl.add annotations (_loc,s) <:expr< $str:n$ >>;
            <:ctyp< $uid:s$ of $t$ >>
        | s = a_UIDENT; "(:"; e = expr; ":)" ->
            Hashtbl.add annotations (_loc,s) e;
            <:ctyp< $uid:s$ >>
        | s = a_UIDENT; "as"; n = a_STRING ->
            Hashtbl.add annotations (_loc,s) <:expr< $str:n$ >>;
            <:ctyp< $uid:s$ >>
      ] ];

  constructor_declarations:
      [ [ s = a_UIDENT; "(:"; e = expr; ":)"; "of"; t = constructor_arg_list ->
            Hashtbl.add annotations (_loc,s) e;
            <:ctyp< $uid:s$ of $t$ >>
        | s = a_UIDENT; "as"; n = a_STRING; "of"; t = constructor_arg_list ->
            Hashtbl.add annotations (_loc,s) <:expr< $str:n$ >>;
            <:ctyp< $uid:s$ of $t$ >>
        | s = a_UIDENT; "(:"; e = expr; ":)" ->
            Hashtbl.add annotations (_loc,s) e;
            <:ctyp< $uid:s$ >>
        | s = a_UIDENT; "as"; n = a_STRING ->
            Hashtbl.add annotations (_loc,s) <:expr< $str:n$ >>;
            <:ctyp< $uid:s$ >>
      ] ];

  row_field:
      [ [ "`"; i = a_ident; "(:"; e = expr; ":)" -> 
           Hashtbl.add annotations (_loc,i) e;
           <:ctyp< `$i$ >>
        | "`"; i = a_ident; "as"; n = a_STRING -> 
           Hashtbl.add annotations (_loc,i) <:expr< $str:n$ >>;
           <:ctyp< `$i$ >>
        | "`"; i = a_ident; "(:"; e = expr; ":)"; "of"; "&"; t = amp_ctyp -> 
           Hashtbl.add annotations (_loc,i) e;
           <:ctyp< `$i$ of & $t$ >>
        | "`"; i = a_ident; "as"; n = a_STRING; "of"; "&"; t = amp_ctyp -> 
           Hashtbl.add annotations (_loc,i) <:expr< $str:n$ >>;
           <:ctyp< `$i$ of & $t$ >>
        | "`"; i = a_ident; "(:"; e = expr; ":)"; "of"; t = amp_ctyp -> 
           Hashtbl.add annotations (_loc,i) e;
           <:ctyp< `$i$ of $t$ >>
        | "`"; i = a_ident; "as"; n = a_STRING; "of"; t = amp_ctyp -> 
           Hashtbl.add annotations (_loc,i) <:expr< $str:n$ >>;
           <:ctyp< `$i$ of $t$ >>
      ] ]
    ;

  label_declaration:
    [ [ s = a_LIDENT; "(:"; e = expr; ":)"; ":"; t = poly_type ->  
            Hashtbl.add annotations (_loc,s) e;
            (* dont know why but it is impos to write 
               <:ctyp< $lid:s$ : $t$ >> *)
            TyCol (_loc, 
                   TyId(_loc, <:ident< $lid:s$ >> ), 
                   t )
      | s = a_LIDENT; "as"; n = a_STRING; ":"; t = poly_type ->  
            Hashtbl.add annotations (_loc,s) <:expr< $str:n$ >>;
            (* dont know why but it is impos to write 
               <:ctyp< $lid:s$ : $t$ >> *)
            TyCol (_loc, 
                   TyId(_loc, <:ident< $lid:s$ >> ), 
                   t )
      | "mutable"; s = a_LIDENT; "as"; n = a_STRING; ":"; t = poly_type ->
            Hashtbl.add annotations (_loc,s) <:expr< $str:n$ >>;
            (* dont know why but it is impos to write 
               <:ctyp< $lid:s$ : $t$ >> *)
            TyCol (_loc,
                   TyId(_loc, <:ident< $lid:s$ >> ),
                   TyMut(_loc, t) )
    ] ];

  type_declaration:
    [ [ (n, tpl) = type_ident_and_parameters; "(:"; e = expr; ":)"; tk = opt_eq_ctyp;
        cl = LIST0 constrain -> 
          Hashtbl.add annotations (_loc,n) e;
          Ast.TyDcl(_loc, n, tpl, tk, cl)
    ] ];

  meth_decl:
      [ [ lab = a_LIDENT; "(:"; e = expr; ":)"; ":"; t = poly_type -> 
          Hashtbl.add annotations (_loc, lab) e;
          TyCol (_loc, 
                 TyId(_loc, <:ident< $lid:lab$ >> ), 
                 t )
        | lab = a_LIDENT; "as"; n = a_STRING; ":"; t = poly_type -> 
          Hashtbl.add annotations (_loc, lab) <:expr< $str:n$ >>;
          TyCol (_loc, 
                 TyId(_loc, <:ident< $lid:lab$ >> ), 
                 t )
      ] ]
    ;

  (*  `QUOTATION x -> Quotation.expand _loc x Quotation.DynAst.ctyp_tag *)

(*  comma_idents:
    [ LEFTA
        [ ids1 = SELF; ","; ids2 = SELF -> ids1 @ ids2
        | id = ident -> [ strip_ident_loc id ]
        ]
    ];
*)
END

(* annotation parsing ******************************************************)

type record_type_name_annotation_semantics = {
  ignore_unknown_fields : bool;
}

let default_record_type_name_annotation_semantics = {
  ignore_unknown_fields = false;
}

let interprete_record_type_name_annotation loc name = 
  let annots = 
    List.flatten (List.map split_by_comma (Hashtbl.find_all annotations (loc, name)))
  in
  List.fold_left (fun _acc -> function
    | <:expr< Ignore_unknown_fields >> -> { ignore_unknown_fields = true }
    | e -> errorf (loc_of_expr e) "strange meta_conv record type name annotation")
    default_record_type_name_annotation_semantics
    annots

type variant_type_name_annotation_semantics = {
  one_of : bool;
}

let default_variant_type_name_annotation_semantics = {
  one_of = false;
}

let interprete_variant_type_name_annotation loc name = 
  let annots = 
    List.flatten (List.map split_by_comma (Hashtbl.find_all annotations (loc, name)))
  in
  List.fold_left (fun _acc -> function
    | <:expr< one_of >> -> { one_of = true }
    | _ -> failwith "strange meta_conv variant type name annotation")
    default_variant_type_name_annotation_semantics
    annots

let interprete_variant_annotation loc id_name = 
  match Hashtbl.find_all annotations (loc, id_name) with
  | [ <:expr< $str:x$ >> ] -> x
  | [] -> id_name
  | _ -> failwith "strange meta_conv variant annotation"

type type_record_field_annotation_semantics = 
    { name : string;
      optional : ctyp option; (* t mc_option => Some t *)
      leftovers : bool;
      embeded : ([ `Embeded | `Option_embeded ] * ctyp) option; (* t mc_embeded *)
    }

let interprete_record_field_annotation target_type_path loc id ctyp = 
  let name = name_of_ident id  in
  let optional = match ctyp with
    | <:ctyp< $t$ mc_option >>
    | <:ctyp< $t$ sexp_option >> -> Some t
    | _ -> None
  in
  let leftovers = match ctyp with
    | <:ctyp< $id:id$ mc_leftovers >> -> 
        (* Leftover is only enabled for conv(a) where a = target_type_path *)
        same_idents target_type_path id
    | _ -> false
  in
  let embeded = match ctyp with
    | <:ctyp< $ctyp$ mc_option_embeded >> -> Some (`Option_embeded, ctyp)
    | <:ctyp< $ctyp$ mc_embeded >> -> Some (`Embeded, ctyp)
    | _ -> None
  in
  let annots = 
    List.flatten (List.map split_by_comma (Hashtbl.find_all annotations (loc, name)))
  in
  let st0 = { name; optional; leftovers; embeded } in
  List.fold_left (fun st -> function
    | <:expr< $str:x$ >> -> { st with name = x }
    | _ -> prerr_endline "Unknown (: .. :) meta_conv annotation"; assert false) st0 annots

(* code generators ******************************************************)

module Encode(A : sig
  val target_type_path : ident
  val module_path : ident
  val conv_name : string
end) = struct
  
  open A

  (** for [X; Y; .. ], Z and BASE, build (X -> BASE) -> (Y -> BASE) -> ... -> Z -> BASE *)
  let dispatch_type params z base = 
    List.fold_right (fun ctyp st -> <:ctyp< ($ctyp$ -> $base$) -> $st$ >>) params <:ctyp< $z$ -> $base$ >>
  
  let func_type_for_sig params name = 
    dispatch_type params 
      (create_param_type params name)
      <:ctyp< $id:target_type_path$ >>

  let func_type params name = 
    create_for_all params (func_type_for_sig params name)

  let dcl _loc name (params : ctyp list) exp =
    <:binding<
      $lid: A.conv_name ^ "_of_" ^ name$ : $func_type params name$ = 
        $Gen.abstract _loc (List.map patt_of_tvar params) exp$
    >>
  
  let rec gen_ctyp : ?top:(Loc.t * string) -> ctyp -> expr = fun ?top -> function
    | TyId (loc, id) ->  (* int *)
        <:expr@loc< $id: change_id (fun s -> A.conv_name ^ "_of_" ^ s) id$ >>
          
    | (TyQuo (_loc, _) as tv) ->  (* 'a *)
        expr_of_tvar tv

    | <:ctyp< ($ctyp$, $id:id$) mc_result >> when same_idents target_type_path id ->
        <:expr<
          function 
            | `Ok v -> $gen_ctyp ctyp$ v
            | `Error (_, v, _) -> v
        >>

    | TyApp (loc, (TyId(_, _id) as f), args) ->  (* (int, float) Hashtbl.t *)
        let args = list_of_ctyp args [] in
        let f = gen_ctyp f in
        Gen.apply loc f (List.map gen_ctyp args)
    | TyApp (loc, TyApp (_loc, f, args1), args2) -> 
          (* a hack for int float Hashtbl.t => (int, float) Hashtbl.t *)
        gen_ctyp (TyApp (loc, f, TyCom(_loc, args1, args2)))
          
    | TyTup (loc, ctyp) ->
        let ctyps = list_of_ctyp ctyp [] in
        let ids = mk_idents "__x" (List.length ctyps) in
        Gen.abstract loc [ create_patt_tuple (List.map patt_of_id ids) ]
          (create_expr_app 
           <:expr< $id:module_path$.Encode.tuple >>
             [create_list (List.map2 (fun id ctyp ->
               <:expr< $gen_ctyp ctyp$ $expr_of_id id$ >>
             ) ids ctyps)])

    | (TyVrnEq _ as ctyp) ->  (* polymorphic variants w/o > < sign *)
        let loc, cases = deconstr_variant_type ctyp in
        gen_variants ?top loc cases

    | (TyObj _ as ctyp) -> 
        let loc, cases, flag = deconstr_object_type ctyp in
        (* I dunno how to handle open fields *)
        begin match flag with
        | RvRowVar | RvAnt _ -> assert false
        | RvNil -> () end;
        gen_object ?top loc cases
        
    | _ -> assert false
    
  and gen_gen_variants encf patt_of_idstr ?top _loc cases = 
    (* CR jfuruse: dupe with decoder *)
    let tyd_loc, name = match top with
      | Some top -> top
      | None -> Loc.ghost, Printf.sprintf "poly-variant at %s" (Loc.to_string _loc) 
    in
    let annot = interprete_variant_type_name_annotation tyd_loc name in 
    if not annot.one_of then 

      (* normal encoder *)
      let case (loc, idstr, ctyps) =
        let id_name = interprete_variant_annotation loc idstr in
        let ids = mk_idents "__x" (List.length ctyps) in
        let patt = create_patt_app (patt_of_idstr loc idstr) (List.map patt_of_id ids) in
        let exp = create_expr_app encf
          [ <:expr< $str: id_name$ >>;
            create_list (List.map2 (fun id ctyp ->
              <:expr< $gen_ctyp ctyp$ $expr_of_id id$ >>
            ) ids ctyps) ]
        in
        <:match_case< $ patt $ -> $ exp $ >>
      in
      <:expr< function $mcOr_of_list (List.map case cases)$ >>

    else
      
      (* one_of encoder *)
      let case (loc, idstr, ctyps) =
        let ids = mk_idents "__x" (List.length ctyps) in
        if ids = [] then errorf loc "'one_of' cannot accept 0-ary constructors";
        let patt = create_patt_app (patt_of_idstr loc idstr) (List.map patt_of_id ids) in
        let args = List.map2 (fun id ctyp ->
            <:expr< $gen_ctyp ctyp$ $expr_of_id id$ >>
          ) ids ctyps
        in
        match args with
        | [] -> assert false
        | [exp] -> <:match_case< $ patt $ -> $ exp $ >>
        | _ -> 
            let exp = create_expr_app
              <:expr< $id:module_path$.Encode.tuple >>
              [ create_list args ]
            in
            <:match_case< $ patt $ -> $ exp $ >>
      in
      <:expr< function $mcOr_of_list (List.map case cases)$ >>


  and gen_variants ?top _loc cases = 
    gen_gen_variants 
      <:expr< $id:module_path$.Encode.poly_variant >>
      (fun loc idstr -> <:patt@loc< `$idstr$ >>) 
      ?top _loc cases

  and gen_gen_record kind accessor creator ?top _loc field_types =
    (* CR jfuruse: dupe with decoder *)
    let tyd_loc, name = match top with
      | Some top -> top
      | None -> Loc.ghost, Printf.sprintf "poly-variant at %s" (Loc.to_string _loc) 
    in
    let _annot = interprete_record_type_name_annotation tyd_loc name in 
    let decode_exn = match kind with
      | `Record -> <:expr< $id:module_path$.Decode'.record_exn >>
      | `Object -> <:expr< $id:module_path$.Decode'.object_exn >>
    in
    let fields = List.fold_right (fun (loc, lab_id, ctyp) fields ->
      let f = gen_ctyp (strip_field_flags ctyp) in
      let sem = interprete_record_field_annotation target_type_path loc lab_id ctyp in
      match sem with
      | { leftovers = true; embeded = Some _; _ } -> assert false

      | { leftovers = true; _ } -> 
          accessor lab_id :: fields

      | { embeded = Some (`Embeded, ctyp); _ } -> 
          let f = gen_ctyp (strip_field_flags ctyp) in
          <:expr< $decode_exn$ 
                      ~trace: [`Field $str:name_of_ident lab_id$; `Field $str:name$] 
                     ($f$ $accessor lab_id$) 
          >> :: fields

      | { embeded = Some (`Option_embeded, ctyp); _ } -> 
          let f = gen_ctyp (strip_field_flags ctyp) in
          <:expr< match $accessor lab_id$ with
                  | None -> []
                  | Some v -> 
                      $decode_exn$ 
                        ~trace: [`Field $str:name_of_ident lab_id$; `Field $str:name$] 
                        ($f$ v)
          >> :: fields

      | { name = s; optional = Some ctyp; _ } ->
          let f = gen_ctyp (strip_field_flags ctyp) in
          <:expr< match $accessor lab_id$ with 
                  | None -> [] 
                  | Some v -> [($str:s$, $f$ v)] >>
          :: fields
      | { name = s; _ } ->
          <:expr< [ ($str:s$, $f$ $accessor lab_id$) ] >> :: fields) field_types []
    in
    let exp = <:expr< List.flatten $create_list fields$ >> in
    <:expr< (fun __v -> $creator$ $exp$) >>

  and gen_object ?top _loc field_types =
    let accessor lab_id = <:expr< __v#$name_of_ident lab_id$ >> in
    let creator = <:expr< $id:module_path$.Encode.object_ >> in
    gen_gen_record `Object accessor creator ?top _loc field_types

  let sum tyd_loc name params loc cases =
    let cases = List.map (fun (a, id, b) -> (a, name_of_ident id, b)) cases in
    let e = gen_gen_variants
      <:expr< $id:module_path$.Encode.variant >>
        (fun loc idstr -> <:patt@loc< $uid:idstr$ >>) 
        ~top:(tyd_loc, name)
        loc cases
    in
    [dcl tyd_loc name params e]
  
  let alias tyd_loc name params _loc cty = 
    let f = gen_ctyp ~top:(tyd_loc, name) cty in
    [ dcl tyd_loc name params <:expr< fun __v -> $f$ __v >> ]
    
  let record tyd_loc name params _loc field_types = 
    let accessor lab_id = <:expr< __v.$id:lab_id$ >> in
    let creator = <:expr< $id:module_path$.Encode.record  >> in
    let e = gen_gen_record `Record accessor creator ~top:(tyd_loc, name) _loc field_types in
    [ dcl tyd_loc name params e ]
    
  let variants tyd_loc name params _loc cases = 
    [ dcl tyd_loc name params (gen_variants tyd_loc cases) ]
  
  (******************* kind of template *)
  
  let def defloc name params cty =
    match deconstr_tydef cty with
    | `Variant (loc, cases)  -> variants defloc name params loc cases
    | `Sum     (loc, cases)  -> sum      defloc name params loc cases
    | `Record  (loc, fields) -> record   defloc name params loc fields
    | `Alias   (loc, ctyp)   -> alias    defloc name params loc ctyp
    | _ -> assert false
  
  (* Add "of_sexp" and "sexp_of" as "sexp" to the set of generators *)
  let str = fun rec_ tds ->
    let _loc = Ast.loc_of_ctyp tds in
    let decls = list_of_ctyp tds [] in
    let recursive = type_definitions_are_recursive rec_ tds in
    let binds = List.flatten (List.map (function
      | TyDcl (loc, name, params, definition, _constraints) -> 
          def loc name params definition
      | _ -> assert false) decls)
    in
    create_top_let recursive binds

  let dcl_sg _loc name (params : ctyp list) _cty = 
    <:sig_item<
      val $lid: A.conv_name ^ "_of_" ^ name $ : $func_type_for_sig params name$
    >>
  
  let sg = fun _rec_ tds ->
    let _loc = Ast.loc_of_ctyp tds in
    let decls = list_of_ctyp tds [] in
    let items = List.map (function
      | TyDcl (loc, name, params, def, _constraints) -> 
          dcl_sg loc name params def
      | _ -> assert false) decls
    in
    concat_sig_items items

end
  
module Decode(A : sig
  val target_type_path : ident
  val module_path : ident
  val conv_name : string
end) = struct
  
  open A


  (** for [X; Y; .. ], Z and BASE, build (X,BASE) path -> (Y,BASE) path -> ...... -> (Z,BASE) path *)
  let gen_dispatch_type targ t params base z = 
    List.fold_right (fun ctyp st -> <:ctyp< ($ctyp$, $base$) Meta_conv.Types.Decoder.$id:targ$ -> $st$ >>) 
      params <:ctyp< ($z$,$base$) Meta_conv.Types.Decoder.$id:t$ >>
  
  let dispatch_type     = gen_dispatch_type <:ident<t>> <:ident<t>>
  let dispatch_type_exn = gen_dispatch_type <:ident<t>> <:ident<t_exn>>

  let gen_func_type_for_sig disp params name = 
    disp params 
      <:ctyp< $id:target_type_path$ >> 
      (create_param_type params name)

  let gen_func_type disp params name = 
    create_for_all params (gen_func_type_for_sig disp params name)

  let func_type_for_sig     = gen_func_type_for_sig dispatch_type
  let func_type_exn_for_sig = gen_func_type_for_sig dispatch_type_exn

  let func_type     = gen_func_type dispatch_type
  let func_type_exn = gen_func_type dispatch_type_exn

  (* Use exception instead of dumb functional binds for efficiency *)
  let binds ids exps final = 
    match ids, exps with
    | [], [] -> <:expr< `Ok $final$ >>
    | _ ->
        let errorid = <:ident< $module_path$.Error >> in
        let lets = 
          List.fold_right2 (fun id exp st ->
            <:expr< let $id:id$ = $id:module_path$.from_Ok $exp$ in $st$ >>) 
            ids exps <:expr< `Ok $final$ >>
        in
        <:expr<  try $lets$ with $id:errorid$ e -> `Error e  >>

  let rec one_of = function
    | [] -> assert false
    | [x] -> x
    | x::xs -> <:expr< match $x$ with (`Ok _ as v) -> v | `Error _ -> $one_of xs$ >>





  (* Like type t = [ `Foo ], sometimes structural polymorphic types have
     names. [type_name] is for it.

     For type t = int * [ `Foo ], [ `Foo ] has no good name, so we use
     its position.
  *)
  let rec gen_ctyp : ?top: (Loc.t * string) -> ctyp -> expr = fun ?top -> function
    | TyId (loc, id) ->  (* int *)
        <:expr@loc< $id: change_id (fun s -> s ^ "_of_" ^ A.conv_name) id$ >>

    | (TyQuo (_loc, _) as tv) ->  (* 'a *)
        expr_of_tvar tv

    | <:ctyp< ($ctyp$, $id:id$) mc_result >> when same_idents target_type_path id ->
        <:expr< fun ?trace:(__t=[]) __v -> `Ok ( $gen_ctyp ctyp$ ~trace:__t __v ) >>

    | TyApp (loc, (TyId(_, _id) as f), args) ->  (* (int, float) Hashtbl.t *)
        let args = list_of_ctyp args [] in
        let f = gen_ctyp f in
        Gen.apply loc f (List.map gen_ctyp args)
    | TyApp (loc, TyApp (_loc, f, args1), args2) -> 
        (* a hack for int float Hashtbl.t => (int, float) Hashtbl.t *)
        gen_ctyp (TyApp (loc, f, TyCom(_loc, args1, args2)))

    | TyTup (_loc, ctyp) ->
        let ctyps = list_of_ctyp ctyp [] in
        let len = List.length ctyps in
        let ids = mk_idents "__x" len in
        let nums = from_to 0 (len-1) in
        let pat = create_patt_list (List.map patt_of_id ids) in 
        let tup = create_tuple (List.map expr_of_id ids) in
        let exps = List.map2 (fun (id,pos) ctyp -> 
          <:expr< $gen_ctyp ctyp$ ~trace:(`Pos $int: string_of_int pos$::__t) $id:id$>> ) 
          (List.combine ids nums) ctyps 
        in
        let binds = binds ids exps tup in
        <:expr< fun ?trace:(__t=[]) __v -> 
          match $id:module_path$.Decode'.tuple ~trace:__t __v with
          | `Ok $pat$ -> 
              let __t = `Node __v :: __t in
              $binds$
          | `Ok l -> Meta_conv.Internal.tuple_arity_error $int:string_of_int len$ (List.length l) ~trace:__t __v
          | `Error e -> `Error e
        >>

    | (TyVrnEq _ as ctyp) ->  (* polymorphic variants w/o > < sign *)
        let loc, cases = deconstr_variant_type ctyp in
        gen_variants ?top loc cases

    | (TyObj _ as ctyp) ->
        let loc, cases, flag = deconstr_object_type ctyp in
        (* I dunno how to handle open fields *)
        begin match flag with
        | RvRowVar | RvAnt _ -> assert false
        | RvNil -> () end;
        gen_object ?top loc cases
        
    | _ -> assert false
    
  and gen_gen_variants kind constructor_of_idstr ?top _loc cases = 
    let tyd_loc, name = match top with
      | Some top -> top
      | None -> Loc.ghost, Printf.sprintf "poly-variant at %s" (Loc.to_string _loc) 
    in
    let annot = interprete_variant_type_name_annotation tyd_loc name in 

    if not annot.one_of then begin

      (* normal decoder *)
      let case (loc, idstr, ctyps) =
        let id_name = interprete_variant_annotation loc idstr in
  
        let len = List.length ctyps in
        let ids = mk_idents "__x" len in
        let nums = from_to 0 (len-1) in
  
        let exps = List.map2 (fun (id,pos) ctyp -> 
          <:expr< $gen_ctyp ctyp$ ~trace:(`Pos $int: string_of_int pos$ :: __t) $id:id$ >> ) 
          (List.combine ids nums) ctyps in
        let final = create_expr_app (constructor_of_idstr idstr) (List.map expr_of_id ids) in
        (* id_name, [ ids ] *)
        <:match_case< 
          ($str:id_name$, l) -> 
            let __t = `Field $str:id_name$ :: `Node __v :: __t in
            begin match l with 
            | $create_patt_list (List.map patt_of_id ids)$ ->
                $ binds ids exps final $
            | _ -> 
                Meta_conv.Internal.variant_arity_error 
                  __name $str:id_name$ $int:string_of_int len$ (List.length l)
                  ~trace:__t
                  __v
            end
          >> 
      in
      let default = <:match_case<
        name, _l -> 
          Meta_conv.Internal.variant_unknown_tag_error 
            __name name ~trace:__t __v
        >>
      in
      let cases = List.map case cases @ [ default ] in
      let decode = match kind with
        | `Variant -> <:expr< $id:module_path$.Decode'.variant >>
        | `Poly_variant -> <:expr< $id:module_path$.Decode'.poly_variant >>
      in
      <:expr< fun ?trace:(__t=[]) __v -> 
        let __name = $str:name$ in
        match $decode$ ~trace:__t __v with 
        | `Ok v -> (match v with $mcOr_of_list cases$)
        | `Error e -> `Error e
      >>

    end else begin

      (* one_of decoder *)
      let case (loc, idstr, ctyps) =
  
        let len = List.length ctyps in
        let ids = mk_idents "__x" len in
        if ids = [] then errorf loc "'one_of' cannot accept 0-ary constructors";
        let pat = create_patt_tuple (List.map patt_of_id ids) in
  
        let the_type = match ctyps with
          | [] -> assert false
          | [ctyp] -> ctyp
          | _ -> TyTup(loc, tySta_of_list ctyps)
        in
        <:expr< 
          match $gen_ctyp the_type$ ~trace:__t __v with
          | `Ok $pat$ -> 
              `Ok ($create_expr_app (constructor_of_idstr idstr) (List.map expr_of_id ids)$)
          | (`Error _ as e) -> e
        >>

      in
      let default = <:expr<
        Meta_conv.Internal.sub_decoders_failed_for_one_of __name ~trace:__t __v
        >>
      in
      
      <:expr< fun ?trace:(__t=[]) __v -> 
        let __name = $str:name$ in
        $one_of (List.map case cases @ [ default ])$
      >>

    end


  and gen_variants ?top _loc cases = 
    gen_gen_variants `Poly_variant (fun idstr -> <:expr< `$idstr$ >>) ?top _loc cases

  and gen_gen_record kind creator ?top _loc field_types = 
    let tyd_loc, name = match top with
      | Some top -> top
      | None -> Loc.ghost, Printf.sprintf "object at %s" (Loc.to_string _loc) 
    in
    let annot = interprete_record_type_name_annotation tyd_loc name in

    let primary, embeded, leftovers = List.fold_right (fun (loc, lab_id, ctyp) 
      (primary, embeded, leftovers) ->
      let sem = interprete_record_field_annotation target_type_path loc lab_id ctyp in
      let ctyp = strip_field_flags ctyp in
      match sem with
      | { leftovers = true; embeded = Some _; _ }-> assert false

      | { leftovers = true; _ }-> 
          if leftovers <> None then errorf loc "Only one field with mc_leftovers is allowed";
          primary, embeded, Some lab_id

      | { embeded = Some ctyp; _ }-> 
          primary, (lab_id, ctyp) :: embeded, leftovers

      | { name=key; optional = Some ctyp; _ } -> 
          (lab_id, key, `Optional ctyp) :: primary, embeded, leftovers

      | { name=key; _ } -> 
          (lab_id, key, `Normal ctyp) :: primary, embeded, leftovers)
      field_types ([], [], None)
    in

    let primary_labels = create_list (List.map (fun (_,x,_) -> <:expr< $str:x$ >>) primary) in

    let primary_bindings = 
      let gen_primary (lab_id, key, t) = match t with
        | `Optional ctyp ->
            let conv = gen_ctyp ctyp in
            (* trace is updated in [field_assoc*], so we do not need to update it here *)
            <:binding< 
              $id:lab_id$ = 
                Meta_conv.Internal.field_assoc_optional_exn 
                  __name 
                  $str:key$ 
                  primary_fields 
                  ($id:module_path$.exn $conv$) 
                  ?trace:(Some __t) __v
            >>
              
        | `Normal ctyp ->
            let conv = gen_ctyp ctyp in

            <:binding< 
              $id:lab_id$ = 
                Meta_conv.Internal.field_assoc_exn 
                  __name 
                  $str:key$ 
                  primary_fields 
                  $id:module_path$.throw
                  ($id:module_path$.exn $conv$) 
                  ?trace:(Some __t) __v
            >>
      in
      List.map gen_primary primary
    in

    let embeded_bindings = 
      let gen_embeded (lab_id, (mode, ctyp)) =
        (* Very dirty trick + inefficient *) 
        let encoder = match kind with
          | `Record -> <:expr< $id:module_path$.Encode.record >>
          | `Object -> <:expr< $id:module_path$.Encode.object_ >>
        in
        match mode with
        | `Embeded -> 
            <:binding< 
              $id:lab_id$, secondary_fields = 
              (* rebuilding target record/object 
                 - inefficient
                 - record or object is fixed by the parent type, not by itself
              *)
              let v = $encoder$ secondary_fields in
              match 
                Meta_conv.Internal.embeded_decoding_helper secondary_fields v
                  ($gen_ctyp ctyp$ ~trace:(`Field $str:name_of_ident lab_id$ :: __t) v) 
              with
              | `Ok v -> v
              | `Error e -> $id:module_path$.throw e
            >>
        | `Option_embeded ->
            <:binding< 
              $id:lab_id$, secondary_fields = 
              (* rebuilding target record/object 
                 - inefficient
                 - record or object is fixed by the parent type, not by itself
              *)
              let v = $encoder$ secondary_fields in
              match 
                Meta_conv.Internal.embeded_decoding_helper secondary_fields v
                  ($gen_ctyp ctyp$ ~trace:(`Field $str:name_of_ident lab_id$ :: __t) v) 
              with
              | `Ok (v, rest_fields)  -> Some v, rest_fields
              | `Error _ -> None, secondary_fields
            >>
      in
      List.map gen_embeded embeded
    in

    let leftovers_binding final = match leftovers with
      | None -> final
      | Some lab_id ->
          <:expr< let $id:lab_id$, secondary_fields = secondary_fields, [] 
                  in $final$ 
          >>
    in

    let final = 
      if annot.ignore_unknown_fields then
        <:expr<
          let res = $
            creator (List.map (fun (_, id, _) -> name_of_ident id, expr_of_id id) field_types) 
            $
          in
          (* Use secondary_field to prevent unused var warning *)
          let _ = secondary_fields in
          (* Finally create a value *)
          `Ok res
        >>
      else
        <:expr<
          let res = $
            creator (List.map (fun (_, id, _) -> name_of_ident id, expr_of_id id) field_types) 
            $
          in
          (* Finally create a value *)
          if secondary_fields <> [] then 
            `Error (Meta_conv.Error.Unknown_fields (__name, List.map fst secondary_fields, Obj.repr res), __v, __t)
          else
            `Ok res
        >>
    in

    let decode = match kind with
      | `Record -> <:expr< $id:module_path$.Decode'.record >>
      | `Object -> <:expr< $id:module_path$.Decode'.object_ >>
    in

    <:expr< fun ?trace:(__t=[]) __v -> 
      let __name = $str:name$ in
      let primary_labels = $primary_labels$ in
      match $decode$ ~trace:__t __v with
      | `Error e -> `Error e
      | `Ok fields ->
          let primary_fields, secondary_fields = Meta_conv.Internal.filter_fields primary_labels fields in
          try
            let $biAnd_of_list primary_bindings$ in
            
            $ List.fold_right (fun b st -> <:expr< let $b$ in $st$ >>)
                embeded_bindings
                (leftovers_binding final) $
          with
          (* stupid, but we cannot directly write like
             | $id:module_path$.Error e -> `Error e *)
          | $id: <:ident< $id:module_path$.Error >> $ e -> `Error e
    >>

  and gen_object ?top _loc field_types = gen_gen_record `Object create_object ?top _loc field_types 

  let dcl _loc name (params : ctyp list) body =
    <:binding<
      $lid: name ^ "_of_" ^ A.conv_name$ : $func_type params name$ = 
      $Gen.abstract _loc (List.map patt_of_tvar params) body$
    >>,
    <:binding<
      $lid: name ^ "_of_" ^ A.conv_name ^ "_exn"$ : $func_type_exn params name$ = 
      $Gen.abstract _loc (List.map patt_of_tvar params) <:expr<
        fun ?(trace=[]) v -> 
          match $ Gen.apply _loc <:expr< $lid: name ^ "_of_" ^ A.conv_name$ >> (List.map expr_of_tvar params)$ ~trace v with
          | `Ok v -> v
          | `Error e -> raise ($id:module_path$.Error e)
              >> $
    >>

  let alias tyd_loc name params _loc cty = 
    let f = gen_ctyp ~top: (tyd_loc, name) cty in
    dcl tyd_loc name params 
      <:expr< fun ?trace:(__t=[]) __v -> $f$ ~trace:__t __v >>
  ;;

  (* CR jfuruse: 
     sum's kind is Variant
     variant's kind is Poly_variant
     It's deadly confusing.
  *)
  let sum tyd_loc name params _loc cases = 
    let cases = List.map (fun (a, id, b) -> (a, name_of_ident id, b)) cases in
    let e = gen_gen_variants `Variant (fun idstr -> <:expr< $uid:idstr$ >>) ~top:(tyd_loc, name) _loc cases
    in
    dcl tyd_loc name params e
      
  let record tyd_loc name params _loc field_types = 
    let e = 
      gen_gen_record `Record
        (fun fields -> create_record (List.map (fun (l,e) -> (<:ident<$lid:l$>>, e)) fields)) 
        ~top:(tyd_loc, name)
        _loc
        field_types
    in

    dcl tyd_loc name params e

  let variants tyd_loc name params _loc cases = 
    dcl tyd_loc name params (gen_variants ~top:(tyd_loc, name) _loc cases)

  (******************* kind of template *)
  
  let def defloc name params cty =
    match deconstr_tydef cty with
    | `Variant (loc, cases)  -> variants defloc name params loc cases
    | `Sum     (loc, cases)  -> sum      defloc name params loc cases
    | `Record  (loc, fields) -> record   defloc name params loc fields
    | `Alias   (loc, ctyp)   -> alias    defloc name params loc ctyp
    | _ -> assert false
  
  (* Add "of_xxx" and "xxx_of" as "xxx" to the set of generators *)
  let str rec_ tds =
    let _loc = Ast.loc_of_ctyp tds in
    let decls = list_of_ctyp tds [] in
    let recursive = type_definitions_are_recursive rec_ tds in
    let binds = List.map (function
      | TyDcl (loc, name, params, definition, _constraints) -> def loc name params definition
      | _ -> assert false) decls
    in
    <:str_item< $create_top_let recursive (List.map fst binds)$
                $create_top_let false (List.map snd binds)$ >>

  let dcl_sg _loc name (params : ctyp list) _d =
    <:sig_item<
      val $lid: name ^ "_of_" ^ A.conv_name$ : $func_type_for_sig params name$
      val $lid: name ^ "_of_" ^ A.conv_name ^ "_exn"$ : $func_type_exn_for_sig params name$
    >>
  
  let sg _rec_ tds =
      let _loc = Ast.loc_of_ctyp tds in
      let decls = list_of_ctyp tds [] in
      let items = List.map (function
        | TyDcl (loc, name, params, def, _constraints) -> dcl_sg loc name params def
        | _ -> assert false) decls
      in
      concat_sig_items items

end
  
let error () = failwith "syntax error in conv(...)"

let deduce_module_from_type = 
  let rec add_conv = function
    | IdAcc (loc, id1, id2) -> IdAcc(loc, id1, add_conv id2)
    | IdUid (loc, name) -> IdUid (loc, name ^ "_conv")
    | IdApp (_loc, _, _) | IdLid (_loc, _) | IdAnt (_loc, _) -> 
        failwith "meta_conv: illegal type_path"
  in
  let rec f = function
    | IdAcc (_, id1, IdLid (_, _)) -> add_conv id1
    | IdAcc (loc, id1, id2) -> IdAcc (loc, id1, f id2)
    | IdLid _ -> IdUid (_loc, "Conv")
    | IdApp (_loc, _, _) -> 
        failwith "meta_conv: impossible to deduce module_path from this form of type_path"
    | IdUid (_loc, _) | IdAnt (_loc, _) -> 
        failwith "meta_conv: illegal type_path"
  in
  f 

let parse_name name =
  let prefix s = 
    try 
      let lens = String.length s in
      let lenrest = String.length name - lens in
      let pre = String.sub name 0 lens in
      let rest = String.sub name lens lenrest in
      if pre = s then Some rest else None with _ -> None
  in
  let postfix s = 
    try 
      let lens = String.length s in
      let lenrest = String.length name - lens in
      let post = String.sub name lenrest lens in
      let rest = String.sub name 0 lenrest in
      if post = s then Some rest else None with _ -> None
  in
  match prefix "of_", postfix "_of" with
  | None, None -> name, [`Encode; `Decode]
  | Some v, None -> v, [`Decode]
  | None, Some v -> v, [`Encode]
  | _ -> failwith "You really want to have of_xxx_of thing???"

let deduce_type_from_name name = 
  IdAcc (_loc, IdUid (_loc, String.capitalize name), IdLid (_loc, "t"))

let rec parse_arg = function
  | <:expr< ( $lid:name$ ( $id:type_$, $id:module_$ ) ) >> ->
    (* CR jfuruse: This does not work with type_cov 108.08.00 according to its bug:
       https://bitbucket.org/yminsky/ocaml-core/issue/10/type_conv-bug-at-fetch_generator_arg
    *)
      let name, dirs = parse_name name in
      [ (name, dirs, type_, module_) ]
  | <:expr< $lid:name$ $id:type_$ >> ->
      let name, dirs = parse_name name in
      [ (name, dirs, type_, deduce_module_from_type type_) ]
  | <:expr< $lid:name$ >> ->
      let name, dirs = parse_name name in
      let type_ = deduce_type_from_name name in
      let module_ = deduce_module_from_type type_ in
      [ (name, dirs, type_, module_) ]
  | ExCom(_, e1, e2) -> parse_arg e1 @ parse_arg e2
  | ExTup(_, (ExCom _ as e)) -> parse_arg e
  | _ -> error ()

let parse_argopt = function
  | Some arg -> parse_arg arg
  | None -> error ()

let () = 
  Pa_type_conv.add_generator_with_arg "conv" Syntax.expr (fun argopt rec_ tds ->
    concat_str_items begin
      List.flatten (List.map (fun (name, dirs, type_, module_) ->
        let module A = struct 
          let target_type_path = type_
          let module_path = module_
          let conv_name = name
        end in
        let module Encode = Encode(A) in
        let module Decode = Decode(A) in
        (if List.mem `Encode dirs then [Encode.str rec_ tds] else [])
        @ (if List.mem `Decode dirs then [Decode.str rec_ tds] else []))
                      (parse_argopt argopt))
    end);

  Pa_type_conv.add_sig_generator_with_arg "conv" Syntax.expr (fun argopt rec_ tds ->
    concat_sig_items begin
      List.flatten (List.map (fun (name, dirs, type_, module_) ->
        let module A = struct 
          let target_type_path = type_
          let module_path = module_
          let conv_name = name
        end in
        let module Encode = Encode(A) in
        let module Decode = Decode(A) in
        (if List.mem `Encode dirs then [Encode.sg rec_ tds] else [])
        @ (if List.mem `Decode dirs then [Decode.sg rec_ tds] else [])) 
                      (parse_argopt argopt))
    end)
