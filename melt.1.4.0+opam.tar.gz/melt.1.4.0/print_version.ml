#use "melt_version.ml"

let () = print ()
