
class xc :
    def __init__(self):
        self.d = {"XenServer" : "SDK"}
        self.s = "SDK"
    def readconsolering(self):
        return self.s
    def physinfo(self):
        return self.d
    def xeninfo(self):
        return self.d

