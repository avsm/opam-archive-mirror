(** Re-exports simple middleware that doesn't have auxiliary
    functions *)
let static = Static.m
let debug = Debug.m
