let package_name = "ppx_sexp_conv"

let sections =
  [ ("lib",
    [ ("built_lib_ppx_sexp_conv", None)
    ; ("built_lib_ppx_sexp_conv_expander", None)
    ],
    [ ("META", None)
    ])
  ]
