(*

  Sub-shell call $`...` which calls `command'. The command variable must be bound manually.

*)

open Spotlib.Spot
let command s = Spotlib.Spot.Unix.shell_command s

let _ = $`ls .`
;;
    
let _ = <:qx<ls .>>
;;


    
