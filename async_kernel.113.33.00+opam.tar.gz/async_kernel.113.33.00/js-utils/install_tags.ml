let package_name = "async_kernel"

let sections =
  [ ("lib",
    [ ("built_lib_async_kernel", None)
    ],
    [ ("META", None)
    ])
  ]
