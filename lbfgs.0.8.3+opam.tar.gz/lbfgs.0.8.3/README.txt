(* OASIS_START *)
(* DO NOT EDIT (digest: 79b965564956629a290ec53e021c4eb0) *)
This is the README file for the lbfgs distribution.

Minimization of multidimensional functions on bounded or unbounded domains.

This is a binding to L-BFGS-B, a library for Large-scale Bound-constrained
Optimization.

See the files INSTALL.txt for building and installation instructions. 

Home page: https://forge.ocamlcore.org/projects/lbfgs/


(* OASIS_STOP *)
