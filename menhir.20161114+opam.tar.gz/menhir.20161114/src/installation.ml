let libdir = "/Users/fpottier/dev/menhir/src/"
let ocamlfind = true
