
type t = World
let create () = World
let to_string World = "world"
