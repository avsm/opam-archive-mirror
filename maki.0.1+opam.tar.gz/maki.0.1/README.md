# maki

Persistent incremental computations, for repeatable tests and benchmarks.

**Status**: beta

For more details, see [the initial design document](doc/maki_design.md)

## Documentation

See http://c-cube.github.io/maki/
