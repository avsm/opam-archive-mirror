indexmap
========

Generic indexed data for OCaml