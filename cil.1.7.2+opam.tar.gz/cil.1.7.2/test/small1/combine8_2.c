typedef struct {
  int x;
  struct bar * next;
} STR;

STR * g1;

struct bar {
  double d;
};
