
struct mystring
{
};


static __inline__ void __dt__8mystringFv (struct mystring *const, int);

extern int __T_9xSysError;

int * glob = &__T_9xSysError;

int __T_9xSysError = 0;

static void* pdt = __dt__8mystringFv;

static __inline__ void
__dt__8mystringFv (struct mystring *const this, int x)
{
  if (this != 0)
    {
    }
}

int main()
{
  return 0;
}
