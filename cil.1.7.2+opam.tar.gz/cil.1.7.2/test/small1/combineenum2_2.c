enum {
  SECOND,
  FIRST,
} x2;

int foo() {
  return x2;
}
