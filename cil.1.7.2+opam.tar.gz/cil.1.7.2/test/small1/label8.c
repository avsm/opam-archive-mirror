int main() {
	goto __Cont;
	for ( ; ; ) continue;
 __Cont:
	return 0;
}
