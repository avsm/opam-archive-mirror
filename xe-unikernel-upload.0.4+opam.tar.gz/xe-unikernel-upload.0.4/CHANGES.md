v0.4 (2014-08-18)
* be consistent and use 'xe-unikernel-upload' everywhere

v0.3 (2014-08-18)
* interpret the .xe:server=<IP> as requiring HTTPS
* use the new ocaml-mbr Partition code
