(* OASIS_START *)
(* DO NOT EDIT (digest: 8699e87310b50c19bccee77510c5857b) *)
This is the README file for the tptp distribution.

(c) 2012-2013 Radek Micek

TPTP format parsing

tptp is a library for reading and writing FOF and CNF formulas in TPTP
format. Library can process all TPTP problems which don't contain line
starting with "thf(" or "tff(".

See the files INSTALL.txt for building and installation instructions. See the
file LICENSE.txt for copying conditions. 


(* OASIS_STOP *)
