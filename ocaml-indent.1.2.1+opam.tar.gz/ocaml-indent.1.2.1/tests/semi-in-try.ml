let _ = 
  try
    loop Region.zero State.init str;
    print_stderr "hello"
  ; raise Exit
  with
  | Exit -> Tokenstr.close str
