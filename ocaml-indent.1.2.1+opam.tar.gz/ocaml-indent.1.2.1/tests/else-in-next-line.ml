let f x = if boo then bar
  else zee
