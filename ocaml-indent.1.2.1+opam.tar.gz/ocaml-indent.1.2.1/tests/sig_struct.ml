module LexReader : sig
  type t
  val create_from_channel : in_channel -> t
end = struct
  open Lexbuf

  type t = Lexbuf.t * Lexing.lexbuf

  let create_from_channel ic = 
    let buf = Lexbuf.create () in
    let f s n = 
      let read_bytes = input ic s 0 n in
      Lexbuf.add_substring buf s 0 read_bytes;
      read_bytes
    in
    buf, Lexing.from_function f
end
