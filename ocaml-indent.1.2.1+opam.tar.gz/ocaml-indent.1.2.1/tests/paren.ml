let x = ( 1,
          2,
          3 )

let x = (
  1,
  2,
  3
)

let x = f (fun x ->
  1
)

let x = (f
           g)

let x = (
  f g
)

let x = ( 1
        , 2
        , 3
        )

let x = f (fun x -> y
  z
)

let z = let x = 
          f ( (* com *) 1, 
              2 )

