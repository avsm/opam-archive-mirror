let x = <<x>>
let x = << \ >>
let x = << >\> >>
