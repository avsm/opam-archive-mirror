let f = function X -> 1 
               | Y -> 2 
