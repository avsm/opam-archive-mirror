(** {!CCIO} has moved into {!Containers}, the main library.
 
  The reason is that it has no additional dependency and is arguably a
  useful completement to parts of {!Pervasives} (the channel management)

  As a result, linking "containers" rather than "containers.io" should be
  enough if one needs {!CCIO}. *)
