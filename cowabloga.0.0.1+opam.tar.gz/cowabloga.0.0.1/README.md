Helper OCaml libraries for setting up a blog and wiki, using
the Zurb Foundation CSS/HTML templates.
