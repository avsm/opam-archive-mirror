# `ocal`

A replacement for the Unix `cal` utility.
