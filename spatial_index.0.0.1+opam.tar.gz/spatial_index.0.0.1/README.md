SpatialIndex - Implementation of several spatial indexes
========================================================

See the file [INSTALL.md](INSTALL.md) for building and installation
instructions.

References
----------

1. [Guttman, A. (1984). "R-Trees: A Dynamic Index Structure for Spatial Searching"](http://www-db.deis.unibo.it/courses/SI-LS/papers/Gut84.pdf)

Copyright and license
---------------------

SpatialIndex is distributed under the terms of the Berkeley software
distribution license (3 clauses).

Build status
------------

[![Build Status](https://travis-ci.org/aluuu/spatial-index.svg?branch=master)](https://travis-ci.org/aluuu/spatial-index)