Authors of SpatialIndex:

* Alexander Dinu
