(* OASIS_START *)
(* DO NOT EDIT (digest: 5623a4c0a065e84472c07ee32471dc65) *)
This is the README file for the odate distribution.

Date & Duration Library

Simple date and duration manipulation. Also implement duration printer based
on string format. Already implemented in opalang [http://opalang.org/]. For
documentation about the format, see :
http://doc.opalang.org/value/stdlib.core.date/Duration/try_generate_printer.

See the files INSTALL.txt for building and installation instructions. 

Home page: https://github.com/hhugo/odate


(* OASIS_STOP *)
