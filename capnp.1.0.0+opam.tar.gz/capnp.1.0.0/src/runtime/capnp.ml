
module MessageSig   = CapnpRuntime.MessageSig
module Message      = CapnpRuntime.Message
module Array        = CapnpRuntime.CArray
module BytesStorage = CapnpRuntime.BytesStorage
module Codecs       = CapnpRuntime.Codecs
module Runtime      = CapnpRuntime

