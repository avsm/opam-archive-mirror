exception SemanticError of (string * string)
