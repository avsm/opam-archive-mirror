"echo" "-e" "Println Called"
cmd="ec""ho"
"$cmd" "Echo Called"
retval=$("echo" "Value 100%")
"echo" "-e" "$retval"
