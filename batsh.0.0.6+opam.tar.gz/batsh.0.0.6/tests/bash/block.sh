#Level 0 Start
"echo" "-e" "Hello"
#Level 1 Start
"echo" "-e" "Lo"
#Level 2 Start
"echo" "-e" "and behold"
#Level 2 End
#Level 1 End
"echo" "-e" "End"
#Level 0 End
