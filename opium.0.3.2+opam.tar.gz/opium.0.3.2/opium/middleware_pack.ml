module Static = Static
module Debug = Debug            (* do not open core.std b/c it shadows this *)
module Router = Router
