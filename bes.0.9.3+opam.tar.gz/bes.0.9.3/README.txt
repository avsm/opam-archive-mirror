(* OASIS_START *)
(* DO NOT EDIT (digest: 56e1783a6756dadabf1d4e3e1d2e2ef5) *)
This is the README file for the bes distribution.

boolean expression simplifier

This is a pure OCaml library containing several algorithms to simplify
boolean expressions (boolean expression simplifier)

See the files INSTALL.txt for building and installation instructions. 


(* OASIS_STOP *)
