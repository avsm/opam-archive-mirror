## 111.21.00

- Added plain differ `Plain_diff` and use it in some cases for
  improved results.
- Move modules under `Patience_diff_lib.Std`.

## 111.17.00

- Exposed `Patience_diff.matches`.

## 111.13.00

- Moved `Patience_diff` out of `Core_extended` into its own library
  depending only on `Core_kernel`.

