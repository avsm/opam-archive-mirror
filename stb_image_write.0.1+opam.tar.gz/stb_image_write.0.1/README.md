Stb\_image\_write is an OCaml binding to stb\_image\_write from Sean Barrett, [Nothings](http://nothings.org/).

stb\_image\_write.h writes out PNG/BMP/TGA images to C stdio.

The OCaml binding is released under CC-0 license.  It has no dependency beside
working OCaml and C compilers (stb\_image\_write is self-contained).

```shell
$ make
$ make install
```
