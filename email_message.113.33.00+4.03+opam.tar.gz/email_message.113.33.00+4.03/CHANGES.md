## 113.33.00+4.03

Various updates to work with OCaml 4.03.0

## 113.24.00

- Bugfixes and minor API improvements.

## 113.00.00

- Extended and improved Email_message API.

## 112.17.00

Moved from janestreet-alpha

