(***********************************************************************)
(*                                                                     *)
(*                           HWeak                                     *)
(*                                                                     *)
(*                        Remi Vanicat                                 *)
(*                                                                     *)
(*  Copyright 2002 R�mi Vanicat                                        *)
(*  All rights reserved.  This file is distributed under the terms of  *)
(*  the GNU Library General Public License, with the special exception *)
(*  on linking described in the LICENCE file of the Objective Caml     *)
(*  distribution                                                       *)
(*                                                                     *)
(*  A large part of this file is an adptation of the implentation of   *)
(*  Weak Hastable by Damien Doligez that can be found into Objective   *)
(*  Caml which is Copyright 1997 and 2002 Institut National de         *)
(*  Recherche en Informatique et en Automatique and is distributed     *)
(*  under the same licence                                             *) 
(*                                                                     *)
(***********************************************************************)

open Weak

type 'a weak_t = 'a t;;
let weak_create = create;;
let emptybucket () = weak_create 0;;

type 'a t = {
  emptybucket : 'a weak_t;
  mutable table : 'a weak_t array;
  mutable totsize : int;             (* sum of the bucket sizes *)
  mutable limit : int;               (* max ratio totsize/table length *)
};;

let eq_obj x y = (x :> < >) == (y :> < >)

let get_index t d = (Oo.id d land max_int) mod (Array.length t.table);;

let create sz =
  let em = emptybucket () in
  let sz = if sz < 7 then 7 else sz in
  let sz = if sz > Sys.max_array_length then Sys.max_array_length else sz in
  {
    emptybucket = em;
    table = Array.create sz em;
    totsize = 0;
    limit = 3;
  };;

let clear t =
  for i = 0 to Array.length t.table - 1 do
    t.table.(i) <- t.emptybucket;
  done;
  t.totsize <- 0;
  t.limit <- 3;
;;

let fold f t init =
  let rec fold_bucket i b accu =
    if i >= length b then accu else
      match get b i with
      | Some v -> fold_bucket (i+1) b (f v accu)
      | None -> fold_bucket (i+1) b accu
  in
  Array.fold_right (fold_bucket 0) t.table init
;;

let count t =
  let rec count_bucket i b accu =
    if i >= length b then accu else
      count_bucket (i+1) b (accu + (if check b i then 1 else 0))
  in
  Array.fold_right (count_bucket 0) t.table 0
;;

let next_sz n = min (3*n/2 + 3) (Sys.max_array_length - 1);;

let rec resize t =
  let oldlen = Array.length t.table in
  let newlen = next_sz oldlen in
  if newlen > oldlen then begin
    let newt = create newlen in
    newt.limit <- t.limit + 100;          (* prevent resizing of newt *)
    fold (fun d () -> add newt d) t ();
    (* assert Array.length newt.table = newlen; *)
    t.table <- newt.table;
    t.limit <- t.limit + 2;
  end
    
and add_aux t d index =
  let bucket = t.table.(index) in
  let sz = length bucket in
  let rec loop i =
    if i >= sz then begin
      let newsz = min (sz + 3) (Sys.max_array_length - 1) in
      if newsz <= sz then failwith "Weak.Make : hash bucket cannot grow more";
      let newbucket = weak_create newsz in
      blit bucket 0 newbucket 0 sz;
      set newbucket i (Some d);
      t.table.(index) <- newbucket;
      t.totsize <- t.totsize + (newsz - sz);
      if t.totsize > t.limit * Array.length t.table then resize t;
    end else begin
      if check bucket i
      then loop (i+1)
      else set bucket i (Some d)
    end
  in
  loop 0;
  
and add t d = add_aux t d (get_index t d)
;;

let find_or t d ifnotfound =
  let index = get_index t d in
  let bucket = t.table.(index) in
  let sz = length bucket in
  let rec loop i =
    if i >= sz then ifnotfound index
    else begin
      match get_copy bucket i with
      | Some v when eq_obj v d
          -> begin match get bucket i with
          | Some v -> v
          | None -> loop (i+1)
          end
      | _ -> loop (i+1)
    end
  in
  loop 0
;;

let merge t d = find_or t d (fun index -> add_aux t d index; d);;

let find t d = find_or t d (fun index -> raise Not_found);;

let find_shadow t d iffound ifnotfound =
  let index = get_index t d in
  let bucket = t.table.(index) in
  let sz = length bucket in
  let rec loop i =
    if i >= sz then ifnotfound else begin
      match get_copy bucket i with
      | Some v when eq_obj v d -> iffound bucket i
      | _ -> loop (i+1)
    end
  in
  loop 0
;;

let remove t d = find_shadow t d (fun w i -> set w i None) ();;

let mem t d = find_shadow t d (fun w i -> true) false;;

let stats t =
  let len = Array.length t.table in
  let lens = Array.map length t.table in
  Array.sort compare lens;
  let totlen = Array.fold_left ( + ) 0 lens in
  (len, count t, totlen, lens.(0), lens.(len/2), lens.(len-1))
;;


class ['a] c size =
object
  val tbl = create size

  method virtual add : 'a -> unit
  method add x =
    ignore (merge tbl x)

  method virtual find : 'b. (< .. > as 'b) -> 'a
  method find x =
    find tbl x

  method virtual remove : 'b. (< .. > as 'b) -> unit
  method remove x =
    remove tbl x

  method virtual mem : 'b. (< .. > as 'b) -> bool
  method mem x =
    mem tbl x

  method clear () =
    clear tbl

  method count =
    count tbl
end
