(* OASIS_START *)
(* DO NOT EDIT (digest: d458058cd9131e4c16bc8127ab6e5953) *)
This is the README file for the mongo.ml distribution.

OCaml driver for MongoDB

See the files INSTALL.txt for building and installation instructions. 


(* OASIS_STOP *)
