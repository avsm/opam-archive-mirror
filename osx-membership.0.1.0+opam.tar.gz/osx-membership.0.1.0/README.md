## OCaml bindings to OS X membership.h uid/gid mapping

These bindings use [ctypes](https://github.com/ocamllabs/ocaml-ctypes)
for type-safe stub generation.
