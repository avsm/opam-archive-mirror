xenops-cli
==========

A simple command-line tool for interacting with xenopsd