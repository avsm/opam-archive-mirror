To install, use OPAM and execute the following:

```
$ opam remote add xen-org git://github.com/xen-org/opam-repo-dev
$ opam install message_switch
```

Then just run `make` and `make install`.
