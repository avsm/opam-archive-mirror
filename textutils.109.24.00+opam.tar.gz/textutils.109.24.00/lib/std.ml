module Ascii_table = Ascii_table
module Console = Console
