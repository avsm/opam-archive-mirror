include Core_kernel.Flags
