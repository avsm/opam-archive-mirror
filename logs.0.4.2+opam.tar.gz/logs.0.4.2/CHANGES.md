v0.4.2 2015-12-03 Cambridge (UK)
--------------------------------

First release.
