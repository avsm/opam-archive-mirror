let n="0.25"
let d="Thu Sep 4 18:04:34 BST 2014"
