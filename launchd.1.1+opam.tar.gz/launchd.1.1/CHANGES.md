1.1 (12-Oct-2015)
- Fix segfault in lwt version when not run from launchd

1.0 (9-Oct-2015)
- Initial version
