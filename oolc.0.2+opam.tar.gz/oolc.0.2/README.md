# Oolc

An OCaml implementation of [Open Location Code](https://github.com/google/open-location-code).
