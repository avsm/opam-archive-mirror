There you can find my experience about interfacing OCaml and Qt.

* Code generator for QtQuick 2.0 is in `src`.
* Library for interfacing with QtQuick 2 is in `lablqml`.
* Test example is now in `qml/test`
 
Github pages [site](http://kakadu.github.io/lablqt/) and [tutorial](http://kakadu.github.io/lablqt/tutorial.html) are available.

Use `./configure && make` to build it. Don't forget to install good Qt version.

Happy hacking,
Kakadu

