module QPushButton = QPushButton
(*
 * module QObjectCleanupHandler = QObjectCleanupHandler 
 *)
