In this directory you can find examples described in 
http://kakadu.github.io/lablqt/qtquick-helloworld.html

