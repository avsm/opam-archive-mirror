There `mocml` tool for code generation is located.
  * Executable `mocml` is a generator for OCaml+QML project. You don't need to other executables for hacking QML-related ocaml code. `mocml` reads input file in JSON format, and using this information about C++ API generates wrappers to call OCaml from C++/ECMAscript. For some examples see `../qml` directory


