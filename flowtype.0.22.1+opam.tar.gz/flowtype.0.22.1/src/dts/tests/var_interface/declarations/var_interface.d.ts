declare var adult: {
    minage: number;
    new(): adult;
}

interface adult {
    height: number;
    age: number;
}
