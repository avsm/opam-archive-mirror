module Program = struct
  let hh_server = "typechecker"
  let ide_server = "ide"
end
