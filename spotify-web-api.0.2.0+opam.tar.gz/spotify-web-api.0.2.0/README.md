ocaml-spotify-web-api [![Build status](https://travis-ci.org/johnelse/ocaml-spotify-web-api.png?branch=master)](https://travis-ci.org/johnelse/ocaml-spotify-web-api)
=====================

OCaml bindings for the [spotify web API](https://developer.spotify.com/web-api/).

Dependencies:

* [lwt](http://ocsigen.org/lwt/)
* [cohttp](https://github.com/avsm/ocaml-cohttp)
* [biniou](https://github.com/mjambon/biniou)
* [atdgen](https://github.com/mjambon/atdgen)
* [uri](https://github.com/avsm/ocaml-uri)
