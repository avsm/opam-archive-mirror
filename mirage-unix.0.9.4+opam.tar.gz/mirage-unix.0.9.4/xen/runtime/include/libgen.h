#ifndef _LIBGEN_H
#define _LIBGEN_H

#include <sys/cdefs.h>

__BEGIN_DECLS

char *dirname(char *path) __THROW;
char *basename(char *path) __THROW;

__END_DECLS

#endif
