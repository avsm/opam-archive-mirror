(* Pragmas *)
type case_pragma = RegularCase | PragmaNotCase
