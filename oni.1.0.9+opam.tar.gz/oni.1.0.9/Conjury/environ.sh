#!/bin/sh

###############################################################################
# $Change$
# Copyright (C) 2010, james woodyatt
# All rights reserved.
#
# 
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
# 
#   Redistributions of source code must retain the above copyright
#   notice, this list of conditions and the following disclaimer.
#   
#   Redistributions in binary form must reproduce the above copyright
#   notice, this list of conditions and the following disclaimer in
#   the documentation and/or other materials provided with the
#   distribution
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
# COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
# INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
# STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
# OF THE POSSIBILITY OF SUCH DAMAGE. 

this=${0##*/}

usage() {
    if [ -n "$*" ]; then
        echo ''
        echo "${this}: $*"
    fi
    cat 1>&2 <<_usage_

Usage:
    ${this} -h
    ${this} -[m] [-S ...] [-T ...] [-O ...] [-F ...] [-c ...] products...

  Options:
    -h          Print this message.
    -m          Edit search paths to include the tools directories.
    -d          Do not build release configuration
    -a          Build all products
    -c config   Add <config> to the alternative configurations to build
    -S stage    Specify explicit stage directory (default is \$PWD/stage).
    -O objects  Specify objects directory (default is \$stage/obj).
    -T tools    Specify tools directory (default is \$stage/tools, implies -m).
    -F finish   Specify finishing directory (default is \$stage/fin).
    -A aux      Specify auxillary directory (default is \$stage/aux).
    
    Note: -d requires at least one -c <config> argument.
_usage_

    exit 1
}

top=$(cd $(dirname $0)/.. && pwd)

uname=$(uname)
if [ $uname = Darwin ]; then
    njobs=$(($(/usr/sbin/sysctl -n hw.ncpu) * 3 / 2))
    if [ $njobs -lt 2 ]; then njobs=2; fi
else
    njobs=2
fi

# INCOMPLETE! We should remove the results of previous edits before inserting
# new values.

OMAKEFLAGS=${OMAKEFLAGS:+"${OMAKEFLAGS} "}
OMAKEFLAGS+="-j$njobs --force-dotomake --dotomake ${top}/.omake"

edit_paths=false
release_config="release"
opts='A:F:O:S:T:ac:dhm'
allproducts=false
while getopts ${opts} opt; do
    case ${opt} in
      A)
        eval ':'
        AUXROOT=${OPTARG}
        ;;
      F)
        eval ':'
        FINROOT=${OPTARG}
        ;;
      S)
        eval ':'
        stage=${OPTARG}
        ;;
      O)
        eval ':'
        OBJROOT=${OPTARG}
        ;;
      T)
        eval ':'
        tools=${OPTARG}
        edit_paths=true
        ;;
      a)
        allproducts=true
        ;;
      c)
        eval ':'
        [ -n "${configs}" ] && configs+=' '
        configs+="${OPTARG}"
        ;;
      d)
        release_config=
        ;;
      m)
        edit_paths=true
        ;;
      '?'|h)
        usage
        ;;
    esac
done

shift $((${OPTIND} -1))

stage=${stage:="$PWD/stage"}
OMAKEFLAGS+=" OBJROOT=\\\"${OBJROOT:="$stage/obj"}\\\""
OMAKEFLAGS+=" FINROOT=\\\"${FINROOT:="$stage/fin"}\\\""
OMAKEFLAGS+=" AUXROOT=\\\"${AUXROOT:="$stage/aux"}\\\""

if [ -n "${release_config}" ]; then
    [ -n "${configs}" ] && release_config+=' '
    configs=${release_config}${configs}
fi

[ "${configs}" = '' ] && usage

OMAKEFLAGS+=" CONFIGURATIONS=\\\"${configs}\\\""

if ${allproducts}; then
    products=
    for pfile in ${top}/products/*.om; do
        if [ -r ${pfile} ]; then
            products+=$(basename -s .om ${pfile})
        fi
    done
elif [ $# -gt 0 ]; then
    products=$*
    for p in ${products}; do
        pfile=${top}/products/${p}.om
        if [ ! -r ${pfile} ]; then
            cat 1>&2 <<_no_product_
$0: Error: unable to read ${pfile}
_no_product_

                exit 1
        fi
    done
fi

if [ -n "${products}" ]; then
    OMAKEFLAGS+=" PRODUCTS=\\\"$products\\\""
fi

if ${edit_paths}; then
    toolsdir=${tools:="$stage/tools"}
    OMAKEFLAGS+=" TOOLSDIR=\\\"$toolsdir\\\""
    if [ $uname = Darwin ]; then
        echo "DYLD_LIBRARY_PATH=\"$toolsdir/usr/lib\":$DYLD_LIBRARY_PATH"
        echo "export DYLD_LIBRARY_PATH"
    else
        echo "LD_LIBRARY_PATH=\"$toolsdir/usr/lib\":$LD_LIBRARY_PATH"
    fi
    echo "MANPATH=\"$toolsdir/usr/man\":$MANPATH"
    echo "PATH=\"$toolsdir/usr/bin\":\"$toolsdir/usr/local/bin\":$PATH"
fi

echo "OMAKEFLAGS=\"${OMAKEFLAGS}\"; export OMAKEFLAGS"
exit 0

# End $File$
