/*---------------------------------------------------------------------------*
  $Change$
  Copyright (c) 2003-2010, James H. Woodyatt
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  
    Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
    
    Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in
    the documentation and/or other materials provided with the
    distribution
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
  COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
  STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
  OF THE POSSIBILITY OF SUCH DAMAGE. 
 *---------------------------------------------------------------------------*/

#include "nx_ip6_addr_p.h"

#include <sys/socket.h>
#include <arpa/inet.h>

#include <string.h>


#define FAILWITH(S)     (failwith("Nx_ip6_addr." S))
#define INVALID_ARGUMENT(S) (invalid_argument("Nx_ip6_addr." S))

enum nx_ip6_addr_format {
    Nx_ip6_addr_unspecified,
    Nx_ip6_addr_unicast,
    Nx_ip6_addr_multicast
};

enum nx_ip6_addr_unicast_format {
    Nx_ip6_addr_U_unassigned,
    Nx_ip6_addr_U_reserved,
    Nx_ip6_addr_U_loopback,
    Nx_ip6_addr_U_v4compat,
    Nx_ip6_addr_U_v4mapped,
    Nx_ip6_addr_U_link,
    Nx_ip6_addr_U_site,
    Nx_ip6_addr_U_uniqlocal,
    Nx_ip6_addr_U_global
};

enum nx_ip6_addr_multicast_flag {
    /* constant constructors */
    Nx_ip6_addr_M_F_transient = 0,
    
    /* non-constant constructors */
    Nx_ip6_addr_M_F_unassigned = 0
};

enum nx_ip6_addr_multicast_scope {
    /* constant constructors */
    Nx_ip6_addr_M_S_node = 0,
    Nx_ip6_addr_M_S_link,
    Nx_ip6_addr_M_S_site,
    Nx_ip6_addr_M_S_org,
    Nx_ip6_addr_M_S_global,
    
    /* non-constant constructors */
    Nx_ip6_addr_M_S_unassigned = 0
};

static const int nx_ip6_addr_multicast_scope_array[] = {
    /* Nx_ip6_addr_M_S_node    */   1,
    /* Nx_ip6_addr_M_S_link    */   2,
    /* Nx_ip6_addr_M_S_site    */   5,
    /* Nx_ip6_addr_M_S_org     */   8,
    /* Nx_ip6_addr_M_S_global  */   14,
};

static value nx_ip6_addr_alloc_constructor_0(int n)
{
    value v = alloc_small(1, 0);
    Store_field(v, 0, Int_val(n));
    return v;
}

static const Nx_constant_table_t nx_ip6_addr_multicast_scope_table = {
    nx_ip6_addr_multicast_scope_array,
    sizeof nx_ip6_addr_multicast_scope_array / sizeof (int),
    nx_ip6_addr_alloc_constructor_0
};

static int nx_ip6_addr_compare(value v1, value v2)
{
    CAMLparam2(v1, v2);
    const u_int8_t* addr1Ptr;
    const u_int8_t* addr2Ptr;
    int i, result;
    
    addr1Ptr = &Nx_ip6_addr_val(v1)->s6_addr[15];
    addr2Ptr = &Nx_ip6_addr_val(v2)->s6_addr[15];
    for (i = 15; i >= 0; --i, --addr1Ptr, --addr2Ptr) {
        result = *addr1Ptr - *addr2Ptr;
        if (result) break;
    }
    
    CAMLreturn(result);
}

static long nx_ip6_addr_hash(value v)
{
    CAMLparam1(v);
    long result;
    const u_int32_t* u32Ptr;
    u_int32_t hash, x;
    
    u32Ptr = (const u_int32_t*) Nx_ip6_addr_val(v)->s6_addr;
    hash = 0;
    hash ^= (x = *u32Ptr++, ntohl(x));
    hash ^= (x = *u32Ptr++, ntohl(x));
    hash ^= (x = *u32Ptr++, ntohl(x));
    hash ^= (x = *u32Ptr, ntohl(x));
    result = (long) hash;
    
    CAMLreturn(result);
}

static void nx_ip6_addr_serialize
   (value v, unsigned long* size32Ptr, unsigned long* size64Ptr)
{
    CAMLparam1(v);
    
    serialize_block_1(Nx_ip6_addr_val(v)->s6_addr, 16);
    *size32Ptr = 16;
    *size64Ptr = 16;
    
    CAMLreturn0;
}

static unsigned long nx_ip6_addr_deserialize(void* bufferPtr)
{
    deserialize_block_1(bufferPtr, 16);
    return 16;
}

static struct custom_operations nx_ip6_addr_op = {
    "org.conjury.oni.cf.in6_addr",
    custom_finalize_default,
    nx_ip6_addr_compare,
    nx_ip6_addr_hash,
    nx_ip6_addr_serialize,
    nx_ip6_addr_deserialize
};

value nx_ip6_addr_alloc(const struct in6_addr* addrPtr)
{
    value result;
    
    result = alloc_custom(&nx_ip6_addr_op, 16, 0, 1);
    *Nx_ip6_addr_val(result) = *addrPtr;
    return result;
}

static int nx_ip6_addr_format_code(const struct in6_addr* addrPtr)
{
    int i;
    for (i = 0; i < 4; ++i) {
        u_int32_t word;
        const u_int32_t fp = htonl(0xFF000000);
        
        word = *(const u_int32_t*) &addrPtr->s6_addr[i * 4];
        if (!i && (word & fp) == fp) return Nx_ip6_addr_multicast;
        if (i < 3 && !!word) break;
        if (i == 3 && !word) return Nx_ip6_addr_unspecified;
    }
    
    return Nx_ip6_addr_unicast;
}

/*---
    external format: opaque t -> format = "nx_ip6_addr_format"
  ---*/
CAMLprim value nx_ip6_addr_format(value addr)
{
    CAMLparam1(addr);
    CAMLreturn(Val_int(nx_ip6_addr_format_code(Nx_ip6_addr_val(addr))));
}

/*---
    external is_unicast:
        [> opaque ] t -> unicast t = "nx_ip6_addr_is_unicast"
  ---*/
CAMLprim value nx_ip6_addr_is_unicast(value addr)
{
    CAMLparam1(addr);
    
    const struct in6_addr* addr6Ptr = Nx_ip6_addr_val(addr);
    
    if (nx_ip6_addr_format_code(addr6Ptr) != Nx_ip6_addr_unicast)
        FAILWITH("is_unicast");
    CAMLreturn(addr);
}

/*---
    external is_multicast:
        [> opaque ] t -> multicast t = "nx_ip6_addr_is_multicast"
  ---*/
CAMLprim value nx_ip6_addr_is_multicast(value addr)
{
    CAMLparam1(addr);
    
    const struct in6_addr* addr6Ptr = Nx_ip6_addr_val(addr);
    
    if (nx_ip6_addr_format_code(addr6Ptr) != Nx_ip6_addr_multicast)
        FAILWITH("is_multicast");
    CAMLreturn(addr);
}

/*---
    external unicast_format:
        [> unicast] t -> unicast_format = "nx_ip6_addr_unicast_format"
  ---*/
CAMLprim value nx_ip6_addr_unicast_format(value addr)
{
    CAMLparam1(addr);
    
    const struct in6_addr* addr6Ptr = Nx_ip6_addr_val(addr);
    value result = Val_int(Nx_ip6_addr_U_unassigned);
    u_int32_t word;
    
    word = *(const u_int32_t*) &addr6Ptr->s6_addr[0];
    word = ntohl(word);
    
    if (word > 0) {
        u_int32_t fp3 = word >> 29;
        if (fp3 == 0) {
            unsigned int fp7 = word >> 25;
            if (fp7 == 1 || fp7 == 2)
                result = Val_int(Nx_ip6_addr_U_reserved);
        }
        else if (fp3 == 1)
            result = Val_int(Nx_ip6_addr_U_global);
        else if (fp3 == 7) {
            unsigned int fp8 = word >> 24;
            if (fp8 == 0)
                result = Val_int(Nx_ip6_addr_U_reserved);
            else if (fp8 == 0xFE) {
                unsigned int fp10 = (word >> 22) & 3;
                if (fp10 == 2)
                    result = Val_int(Nx_ip6_addr_U_link);
                else if (fp10 == 3)
                    result = Val_int(Nx_ip6_addr_U_site);
            }
            else if (fp8 == 0xFC || fp8 == 0xFD)
                result = Val_int(Nx_ip6_addr_U_uniqlocal);
        }
    }
    else /* word == 0 */ {
        int i;
        
        result = Val_int(Nx_ip6_addr_U_reserved);
        
        for (i = 1; i < 3; ++i) {
            word = *(const u_int32_t*) &addr6Ptr->s6_addr[i * 4];
            
            if (i == 1 && !!word) break;
            
            if (i == 2) {
                const struct in_addr* addr4Ptr;
                
                if (word && word != ntohl(0xFFFF)) break;
                
                addr4Ptr = (const struct in_addr*) &addr6Ptr->s6_addr[12];
                
                if (!word && addr4Ptr->s_addr == ntohl(1)) {
                    result = Val_int(Nx_ip6_addr_U_loopback);
                    break;
                }
                                
                if (
                    nx_ip4_addr_category_code(addr4Ptr) == Nx_ip4_addr_unicast
                   )
                {
                    result = word
                        ? Val_int(Nx_ip6_addr_U_v4mapped)
                        : Val_int(Nx_ip6_addr_U_v4compat);
                    break;
                }
            }
        }
    }
    
    CAMLreturn(result);
}

/*---
    external is_v4compat:
        [> opaque ] t -> Nx_ip4_addr.opaque t = "nx_ip6_addr_is_v4compat"
  ---*/
CAMLprim value nx_ip6_addr_is_v4compat(value addr)
{
    CAMLparam1(addr);
    
    const struct in6_addr* addr6Ptr = Nx_ip6_addr_val(addr);
    struct in_addr addr4;
    
    if (!IN6_IS_ADDR_V4COMPAT(addr6Ptr)) FAILWITH("is_v4compat");
    addr4.s_addr = *(const u_int32_t*)(&addr6Ptr->s6_addr[12]);
    CAMLreturn(nx_ip4_addr_alloc(&addr4));
}

/*---
    external to_v4compat:
        [> Nx_ip4_addr.unicast ] -> v4compat t = "nx_ip6_addr_to_v4compat"
  ---*/
CAMLprim value nx_ip6_addr_is_v4mapped(value addr)
{
    CAMLparam1(addr);
    
    const struct in6_addr* addr6Ptr = Nx_ip6_addr_val(addr);
    struct in_addr addr4;
    
    if (!IN6_IS_ADDR_V4MAPPED(addr6Ptr)) FAILWITH("is_v4mapped");    
    addr4.s_addr = *(const u_int32_t*)(&addr6Ptr->s6_addr[12]);
    CAMLreturn(nx_ip4_addr_alloc(&addr4));
}

/*---
    external is_v4mapped:
        [> opaque ] t -> Nx_ip4_addr.opaque t = "nx_ip6_addr_is_v4mapped"
  ---*/
CAMLprim value nx_ip6_addr_to_v4compat(value addr4)
{
    CAMLparam1(addr4);
    
    const struct in_addr* addrPtr = Nx_ip4_addr_val(addr4);
    struct in6_addr addr6;
    
    addr6 = in6addr_any;
    *((u_int32_t*) &addr6.s6_addr[0]) = 0;
    *((u_int32_t*) &addr6.s6_addr[4]) = 0;
    *((u_int32_t*) &addr6.s6_addr[8]) = 0;
    *((u_int32_t*) &addr6.s6_addr[12]) = addrPtr->s_addr;
    
    CAMLreturn(nx_ip6_addr_alloc(&addr6));
}

/*---
    external to_v4mapped:
        [> Nx_ip4_addr.unicast ] -> v4mapped t = "nx_ip6_addr_to_v4mapped"
  ---*/
CAMLprim value nx_ip6_addr_to_v4mapped(value addr4)
{
    CAMLparam1(addr4);
    
    const struct in_addr* addrPtr = Nx_ip4_addr_val(addr4);
    struct in6_addr addr6;
    
    addr6 = in6addr_any;
    *((u_int32_t*) &addr6.s6_addr[0]) = 0;
    *((u_int32_t*) &addr6.s6_addr[4]) = 0;
    *((u_int32_t*) &addr6.s6_addr[8]) = htonl(0xFFFF);
    *((u_int32_t*) &addr6.s6_addr[12]) = addrPtr->s_addr;
    
    CAMLreturn(nx_ip6_addr_alloc(&addr6));
}

#ifndef IN6ADDR_NODELOCAL_ALLNODES_INIT
#define IN6ADDR_NODELOCAL_ALLNODES_INIT \
        {{{ 0xff, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, \
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01 }}}
#endif

#ifndef IN6ADDR_LINKLOCAL_ALLNODES_INIT
#define IN6ADDR_LINKLOCAL_ALLNODES_INIT \
        {{{ 0xff, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, \
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01 }}}
#endif

#ifndef IN6ADDR_LINKLOCAL_ALLROUTERS_INIT
#define IN6ADDR_LINKLOCAL_ALLROUTERS_INIT \
        {{{ 0xff, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, \
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02 }}}
#endif

static const struct in6_addr nx_in6addr_nodelocal_allnodes =
    IN6ADDR_NODELOCAL_ALLNODES_INIT;

static const struct in6_addr nx_in6addr_linklocal_allnodes =
    IN6ADDR_LINKLOCAL_ALLNODES_INIT;

static const struct in6_addr nx_in6addr_linklocal_allrouters =
IN6ADDR_LINKLOCAL_ALLROUTERS_INIT;

static value nx_ip6_addr_unspecified_val = Val_unit;
static value nx_ip6_addr_loopback_val = Val_unit;
static value nx_ip6_addr_node_local_all_nodes_val = Val_unit;
static value nx_ip6_addr_link_local_all_nodes_val = Val_unit;
static value nx_ip6_addr_link_local_all_routers_val = Val_unit;

/*---
    external to_multicast_components:
        [> multicast ] t ->
        multicast_scope * multicast_flag list * multicast_group_id t =
        "nx_ip6_addr_to_multicast_components"
  ---*/
CAMLprim value nx_ip6_addr_to_multicast_components(value addrVal)
{
    CAMLparam1(addrVal);
    CAMLlocal5(resultVal, scopeVal, flagListVal, groupIdVal, hdVal);
    CAMLlocal1(consVal);
    
    const struct in6_addr* addrPtr = Nx_ip6_addr_val(addrVal);
    struct in6_addr groupId;
    u_int32_t word;
    int i;
    
    word = *(const u_int32_t*) addrPtr->s6_addr;
    word = ntohl(word);
    
    scopeVal = nx_get_constant
       (&nx_ip6_addr_multicast_scope_table, (word >> 16) & 0xF);
    flagListVal = Val_int(0);
    for (i = 0; i < 4; ++i) {
        if (word & (0x100000 << i)) {
            hdVal = alloc_small(2, 0);
            if (i == 0)
                Store_field(hdVal, 0, Val_int(0));
            else {
                consVal = alloc_small(1, 0);
                Store_field(consVal, 0, Val_int(i));
                Store_field(hdVal, 0, consVal);
            }
            Store_field(hdVal, 1, flagListVal);
            flagListVal = hdVal;
        }
    }
    
    groupId.s6_addr[0] = 0;
    groupId.s6_addr[1] = 0;
    memcpy(&groupId.s6_addr[2], &addrPtr->s6_addr[2], 14);
    groupIdVal = nx_ip6_addr_alloc(&groupId);
    
    resultVal = alloc_small(3, 0);
    Store_field(resultVal, 0, scopeVal);
    Store_field(resultVal, 1, flagListVal);
    Store_field(resultVal, 2, groupIdVal);
    
    CAMLreturn(resultVal);
}

/*---
    external of_multicast_components:
        multicast_scope -> multicast_flag list -> multicast_group_id t ->
        multicast t = "nx_ip6_addr_of_multicast_components"
  ---*/
CAMLprim value nx_ip6_addr_of_multicast_components
   (value scopeVal, value flagListVal, value groupIdVal)
{
    CAMLparam3(scopeVal, flagListVal, groupIdVal);
    CAMLlocal2(flagVal, consVal);
    
    struct in6_addr addr;
    u_int8_t byte;
    
    addr.s6_addr[0] = 0xFF;
    
    byte = 0;
    while (Is_block(flagListVal)) {
        flagVal = Field(flagListVal, 0);
        if (Is_block(flagVal)) {
            int unassigned;
            
            consVal = Field(0, flagVal);
            unassigned = Int_val(consVal);
            if (unassigned < 0 || unassigned > 3)
                INVALID_ARGUMENT("of_multicast_components");
            byte |= 0x10 << unassigned;
        }
        else
            byte |= 0x10 << Int_val(flagVal);
        
        flagListVal = Field(flagListVal, 1);
    }
    
    byte |= nx_ip6_addr_multicast_scope_table.array[Int_val(scopeVal)];
    addr.s6_addr[1] = byte;
    
    memcpy(&addr.s6_addr[2], &Nx_ip6_addr_val(groupIdVal)->s6_addr[2], 14);
    
    CAMLreturn(nx_ip6_addr_alloc(&addr));
}

/*---
    external unspecified_: unit -> unspecified t = "nx_ip6_addr_unspecified"
  ---*/
CAMLprim value nx_ip6_addr_unspecified(value unit)
{
    CAMLparam0();
    (void) unit;
    CAMLreturn(nx_ip6_addr_unspecified_val);
}

/*---
    external loopback_: unit -> unicast t = "nx_ip6_addr_loopback"
  ---*/
CAMLprim value nx_ip6_addr_loopback(value unit)
{
    CAMLparam0();
    (void) unit;
    CAMLreturn(nx_ip6_addr_loopback_val);
}

/*---
    external node_local_all_nodes_:
        unit -> multicast t = "nx_ip6_addr_node_local_all_nodes"
  ---*/
CAMLprim value nx_ip6_addr_node_local_all_nodes(value unit)
{
    CAMLparam0();
    (void) unit;
    CAMLreturn(nx_ip6_addr_node_local_all_nodes_val);
}

/*---
    external link_local_all_nodes_:
        unit -> multicast t = "nx_ip6_addr_link_local_all_nodes"
  ---*/
CAMLprim value nx_ip6_addr_link_local_all_nodes(value unit)
{
    CAMLparam0();
    (void) unit;
    CAMLreturn(nx_ip6_addr_link_local_all_nodes_val);
}

/*---
    external link_local_all_routers_:
        unit -> multicast t = "nx_ip6_addr_link_local_all_routers"
  ---*/
CAMLprim value nx_ip6_addr_link_local_all_routers(value unit)
{
    CAMLparam0();
    (void) unit;
    CAMLreturn(nx_ip6_addr_link_local_all_routers_val);
}

/*---
    external equal:
        [> opaque ] t -> [> opaque ] t -> bool = "nx_ip6_addr_equal"
  ---*/
CAMLprim value nx_ip6_addr_equal(value addr1, value addr2)
{
    CAMLparam2(addr1, addr2);
    
    value result;
    
    if (IN6_ARE_ADDR_EQUAL(Nx_ip6_addr_val(addr1), Nx_ip6_addr_val(addr2)))
        result = Val_true;
    else
        result = Val_false;
    
    CAMLreturn(result);
}

/*---
    external compare:
        [> opaque ] t -> [> opaque ] t -> int = "nx_ip6_addr_compare_aux"
  ---*/
CAMLprim value nx_ip6_addr_compare_aux(value v1, value v2)
{
    int d = nx_ip6_addr_compare(v1, v2);
    return Val_int(d);
}

/*---
    external pton: string -> opaque t option = "nx_inet_pton6"
  ---*/
CAMLprim value nx_inet_pton6(value str)
{
    CAMLparam1(str);
    CAMLlocal1(resultVal);
    
    struct in6_addr addr;
    int result;
    
    result = inet_pton(AF_INET6, String_val(str), &addr);
    if (result < 0) failwith("inet_pton(AF_INET6, ...)");
    
    resultVal = Val_int(0);
    if (result > 0) {
        resultVal = alloc_small(1, 0);
        Store_field(resultVal, 0, nx_ip6_addr_alloc(&addr));
    }
    
    CAMLreturn(resultVal);
}

/*---
    external ntop: [> opaque ] t -> string = "nx_inet_ntop6"
  ---*/
CAMLprim value nx_inet_ntop6(value str)
{
    CAMLparam1(str);
    
    char buffer[INET6_ADDRSTRLEN];
    
    if (inet_ntop(AF_INET6, Nx_ip6_addr_val(str), buffer, sizeof buffer) == 0)
        failwith("inet_ntop(AF_INET6, ....)");
    
    CAMLreturn(copy_string(buffer));
}

/*---
  Initialization primitive
  ---*/
CAMLprim value nx_ip6_addr_init(value unit)
{
    (void) unit;
    register_custom_operations(&nx_ip6_addr_op);
        
    register_global_root(&nx_ip6_addr_unspecified_val);
    nx_ip6_addr_unspecified_val = nx_ip6_addr_alloc(&in6addr_any);
    
    register_global_root(&nx_ip6_addr_loopback_val);
    nx_ip6_addr_loopback_val = nx_ip6_addr_alloc(&in6addr_loopback);
    
    register_global_root(&nx_ip6_addr_node_local_all_nodes_val);
    nx_ip6_addr_node_local_all_nodes_val =
        nx_ip6_addr_alloc(&nx_in6addr_nodelocal_allnodes);
    
    register_global_root(&nx_ip6_addr_link_local_all_nodes_val);
    nx_ip6_addr_link_local_all_nodes_val =
        nx_ip6_addr_alloc(&nx_in6addr_linklocal_allnodes);
    
    register_global_root(&nx_ip6_addr_link_local_all_routers_val);
    nx_ip6_addr_link_local_all_routers_val =
        nx_ip6_addr_alloc(&nx_in6addr_linklocal_allrouters);
    
    return Val_unit;
}

/*--- $File$ ---*/
