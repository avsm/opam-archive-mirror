(*---------------------------------------------------------------------------*
  $Change$
  Copyright (c) 2006-2010, James H. Woodyatt
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  
    Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
    
    Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in
    the documentation and/or other materials provided with the
    distribution
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
  COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
  STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
  OF THE POSSIBILITY OF SUCH DAMAGE. 
 *---------------------------------------------------------------------------*)

(*
let jout = Cf_journal.stdout
*)

open Cf_cmonad.Op

type signal = [ `Signal of int ]
type idle = [ `Idle of Cf_tai64n.t ]
type time = [ `Time of Cf_tai64n.t ]

type ('c, 'n) signaler_fix = ('c, 'n) Iom_gadget.fix
    constraint 'c = [> Iom_stream.flowcontrol ]
    constraint 'n = [> signal ]

type ('c, 'n) idler_fix = ('c, 'n) Iom_gadget.fix
    constraint 'c = [> Iom_stream.flowcontrol ]
    constraint 'n = [> idle ]

type ('c, 'n) timer_fix = ('c, 'n) Iom_gadget.fix
    constraint 'c = [> Iom_stream.flowcontrol ]
    constraint 'n = [> time ]

type reader_fix =
    (Iom_octet_stream.fragment, Iom_stream.flowcontrol, Iom_stream.failed)
    Iom_stream.ifix

type writer_fix =
    (Iom_octet_stream.fragment, Iom_stream.stop, Iom_stream.flownotify)
    Iom_stream.ofix

class virtual ['control] core controlRx =
    let controlRx = (controlRx : 'control Iom_gadget.rx) in
    object(self:'self)
        inherit Iom_gadget.start as super
        inherit Iom_gadget.next
        constraint 'control = [> Iom_stream.stop ]
        constraint 'self = unit Iom_gadget.t #Nx_poll.event
        
        val mutable started_ = false
        
        method private stop: 'a. 'a Iom_gadget.t = Iom_gadget.abort
        
        method private control = function
            | `Stop -> self#stop
            | _ -> self#next
        
        method private guard = controlRx#get self#control
        
        method start =
            if started_ then
                failwith "Iom_reactor.core#start: already started!";
            started_ <- true;
            super#start
    end

class virtual ['control, 'source] source ~k:kernel pad =
    let pad = (pad : ('control, 'source) Iom_gadget.pad) in
    let controlRx, sourceTx = pad in
    object(self:'self)
        inherit ['control] core controlRx as super
        constraint 'control = [> Iom_stream.flowcontrol ]
        
        val mutable source_ = false
        
        method virtual private source: 'source option
        
        method private service p =
            let eopt = self#source in
            match eopt, source_ with
            | None, true ->
                Nx_poll.Loaded p
            | None, false ->
                Nx_poll.Unloaded
            | Some event, true ->
                Nx_poll.Working (p, Iom_gadget.start (sourceTx#put event))
            | Some event, false ->
                Nx_poll.Final (Iom_gadget.start (sourceTx#put event))
        
        method private stop =
            if source_ then self#unload;
            super#stop
        
        method private ready =
            if not source_ then Iom_gadget.poll self kernel;
            source_ <- true;
            self#next
        
        method private wait =
            if source_ then begin
                self#unload;
                source_ <- false;
            end;
            self#next
            
        method private control = function
            | #Iom_stream.ready -> self#ready
            | #Iom_stream.wait -> self#wait
            | c -> super#control c
    end

class ['control, 'signal] signaler ~k ~n pad = object
    inherit ['control, 'signal] source ~k pad
    inherit [unit Iom_gadget.t] Nx_poll.signal n
    constraint 'signal = [> signal ]
    method private source = Some (`Signal n)
end

class ['control, 'idle] idler ~k pad = object
    inherit ['control, 'idle] source ~k pad
    inherit [unit Iom_gadget.t] Nx_poll.idle
    constraint 'idle = [> idle ]
    
    method private source =
        match epoch_ with
        | Some now -> Some (`Idle now)
        | None -> None
end

class ['control, 'time] timer ~k ?t0 ~dt pad = object
    inherit ['control, 'signal] source ~k pad as super
    inherit [unit Iom_gadget.t] Nx_poll.time ?t0 dt
    constraint 'time = [> time ]
    
    method private source = Some (`Time epoch_ : 'time)
    
    method private ready =
        epoch_ <- Cf_tai64n.add (Cf_tai64n.now ()) dt;
        super#ready
end

let signaler ~n k = Iom_gadget.create (new signaler ~k ~n)
let idler k = Iom_gadget.create (new idler ~k)
let timer ?t0 ~dt k = Iom_gadget.create (new timer ~k ?t0 ~dt)

let retry_needed = function
    | Unix.EAGAIN 
    | Unix.EWOULDBLOCK ->
        true
    | _ ->
        false

class virtual ['fragment, 'control, 'notify] reader_aux
    ~k ?(rwx: Nx_poll.rwx = `R) ~fd ~limits pad =
    let limits = Iom_octet_stream.normalize_limits limits in
    let fragmentTx, (controlRx, notifyTx) = pad in
    let notifyTx = (notifyTx : 'notify Iom_gadget.tx) in
    let pad = (controlRx, fragmentTx) in
    object(self:'self)
        inherit ['control, 'fragment] source ~k pad as source
        inherit [unit Iom_gadget.t] Nx_poll.file rwx fd as poll
        
        constraint 'fragment = #Iom_octet_stream.fragment
        constraint 'notify = [> Iom_stream.failed ]
        
        val mutable buffer_ = ""
        val mutable cursor_ = 0
        val mutable more_ = Iom_stream.More
        val mutable stack_ = []
        val mutable free_ = limits.Iom_octet_stream.high
        val mutable cons_ = lazy (assert false)
        
        method virtual private fragment: 'fragment
        
        method private unload_ p =
            buffer_ <- "";
            cursor_ <- 0;
            poll#unload_ p
        
        method private load_ p =
            buffer_ <- String.create limits.Iom_octet_stream.high;
            cursor_ <- 0;
            poll#load_ p
                
        method private octets n =
            let n = Unix.read fd buffer_ cursor_ n in
            if n = 0 then raise End_of_file;
            n
        
        method private fail: 'a. exn -> 'a Iom_gadget.t = fun x ->
            notifyTx#put (`Failed x) >>= fun () ->
            self#stop
        
        method private source =
            let n0 = limits.Iom_octet_stream.high - cursor_ in
            let n0 = min n0 free_ in
            let n0 =
                if n0 < limits.Iom_octet_stream.low then begin
                    buffer_ <- String.create limits.Iom_octet_stream.high;
                    cursor_ <- 0;
                    limits.Iom_octet_stream.high
                end
                else
                    n0
            in
            match
                try Some (self#octets n0) with End_of_file -> None
            with
            | None ->
                more_ <- Iom_stream.Last;
                Lazy.force cons_ ()
            | Some n ->
                let pos = cursor_ in
                stack_ <- (buffer_, pos, n) :: stack_;
                cursor_ <- cursor_ + n;
                if n >= n0 && n0 < free_ then begin
                    free_ <- free_ - n0;
                    self#source
                end
                else
                    Lazy.force cons_ ()
        
        method private service p =
            assert source_;
            try
                match self#source with
                | None ->
                    Nx_poll.Loaded p
                | Some fragment ->
                    let more = fragment#more in
                    let out = fragmentTx#put fragment in
                    match more with
                    | Iom_stream.More -> Nx_poll.Working (p, out)
                    | Iom_stream.Last -> Nx_poll.Final out
            with
            | Unix.Unix_error (code, _, _) when retry_needed code ->
                Nx_poll.Loaded p
            | x ->
                Nx_poll.Final (self#fail x)
        
        method start =
            try
                let start = source#start in
                Unix.set_nonblock fd;
                start
            with
            | x ->
                self#fail x
        
        initializer
            let rec f () =
                if 
                    more_ = Iom_stream.More &&
                    cursor_ < limits.Iom_octet_stream.low
                then
                    None
                else begin
                    assert (more_ = Iom_stream.Last || stack_ <> []);
                    buffer_ <- String.create limits.Iom_octet_stream.high;
                    cursor_ <- 0;
                    free_ <- limits.Iom_octet_stream.high;
                    stack_ <- List.rev stack_;
                    let fragment = self#fragment in
                    stack_ <- [];
                    Some fragment
                end
            in
            cons_ <- Lazy.lazy_from_val f
    end

class ['control, 'notify] reader ~k ?rwx ~fd ~limits pad =
    object
        inherit [Iom_octet_stream.fragment, 'control, 'notify] reader_aux
            ~k ~limits ?rwx ~fd pad
        
        method private fragment = new Iom_octet_stream.fragment more_ stack_
    end

let reader ~fd ~limits k = Iom_stream.ifix (new reader ~k ~fd ~limits)

class ['fragment, 'control, 'notify] writer ~k:kernel ~fd pad =
    let fragmentRx, (controlRx, notifyTx) = pad in
    let fragmentRx = (fragmentRx : 'fragment Iom_gadget.rx) in
    let notifyTx = (notifyTx : 'notify Iom_gadget.tx) in
    object(self:'self)
        inherit ['control] core controlRx as core
        inherit [unit Iom_gadget.t] Nx_poll.file `W fd as poll
        
        constraint 'fragment = #Iom_octet_stream.fragment
        constraint 'notify = [> Iom_stream.flownotify ]
        
        val mutable buffer_ = Cf_deque.nil
        val mutable more_ = Iom_stream.More
        
        method private stop =
            self#unload;
            core#stop
        
        method private fail: 'a. exn -> 'a Iom_gadget.t = fun x ->
            notifyTx#put (`Failed x) >>= fun () ->
            self#stop
        
        method private complete = notifyTx#put `Wait
        
        method private octets buf pos len = Unix.write fd buf pos len
        
        method private consume =
            match Cf_deque.B.pop buffer_ with
            | None ->
                ()
            | Some ((buf, pos, len) , tl) ->
                match
                    try Cf_exnopt.U (self#octets buf pos len)
                    with x -> Cf_exnopt.X x
                with
                | Cf_exnopt.X (Unix.Unix_error (code, _, _))
                  when retry_needed code ->
                    ()
                | Cf_exnopt.X x ->
                    raise x
                | Cf_exnopt.U n when n = len ->
                    buffer_ <- tl;
                    self#consume
                | Cf_exnopt.U n ->
                    let hd = buf, pos + n, len - n in
                    buffer_ <- Cf_deque.B.push hd tl
        
        method private receive fragment =
            let data = fragment#data and more = fragment#more in
            if Cf_deque.empty buffer_ then begin
                buffer_ <- Cf_deque.B.of_list data;
                match try self#consume; None with x -> Some x with
                | Some x ->
                    self#fail x
                | None ->
                    match more with
                    | Iom_stream.More ->
                        if Cf_deque.empty buffer_ then
                            self#next
                        else begin
                            Iom_gadget.poll self kernel;
                            notifyTx#put `Wait >>= fun () ->
                            self#next
                        end
                    | Iom_stream.Last ->
                        if Cf_deque.empty buffer_ then
                            self#complete
                        else begin
                            more_ <- Iom_stream.Last;
                            Iom_gadget.poll self kernel;
                            self#next
                        end
            end
            else begin
                buffer_ <- Cf_message.push data buffer_;
                if more = Iom_stream.Last then begin
                    more_ <- Iom_stream.Last;
                    Iom_gadget.abort
                end
                else
                    self#next
            end
        
        method private service p =
            assert (not (Cf_deque.empty buffer_));
            try
                self#consume;
                if Cf_deque.empty buffer_ then begin
                    Nx_poll.Final begin
                        notifyTx#put `Ready >>= fun () ->
                        if more_ = Iom_stream.Last then
                            self#complete
                        else
                            Cf_cmonad.nil
                    end
                end
                else
                    Nx_poll.Loaded p
            with
            | x ->
                Nx_poll.Final (self#fail x)
        
        method private guard =
            controlRx#get self#control >>= fun ()  ->
            fragmentRx#get self#receive
        
        method start =
            try
                let start = core#start in
                Unix.set_nonblock fd;
                start
            with
            | x ->
                self#fail x
    end

let writer ~fd k = Iom_stream.ofix (new writer ~k ~fd)

(*--- $File$ ---*)
