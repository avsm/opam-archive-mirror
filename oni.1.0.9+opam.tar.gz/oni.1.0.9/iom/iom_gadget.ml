(*---------------------------------------------------------------------------*
  $Change$
  Copyright (c) 2002-2010, James H. Woodyatt
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  
    Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
    
    Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in
    the documentation and/or other materials provided with the
    distribution
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
  COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
  STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
  OF THE POSSIBILITY OF SUCH DAMAGE. 
 *---------------------------------------------------------------------------*)

type input = Nx_poll.more and output = unit
type work = (input, output) Cf_gadget.work
type gate = (input, output) Cf_gadget.gate
type 'a guard = (input, output, 'a) Cf_gadget.guard
type 'a t = (input, output, 'a) Cf_gadget.t

let start = Cf_gadget.start
let guard = Cf_gadget.guard
let abort = Cf_gadget.abort

type 'a wire = ('a, input, output) Cf_gadget.wire
class type connector = Cf_gadget.connector
class ['a] rx e = ['a, input, output] Cf_gadget.rx e
class ['a] tx e = ['a, input, output] Cf_gadget.tx e

type ('x, 'y) pad = 'x rx * 'y tx
type ('x, 'y) fix = 'y rx * 'x tx

let wire = Cf_gadget.wire
let wirepair = Cf_gadget.wirepair
let null = Cf_gadget.null

let connect = Cf_gadget.connect
let simplex = Cf_gadget.simplex
let connectpair = Cf_gadget.connectpair
let duplex = Cf_gadget.duplex

let wrap = Cf_gadget.wrap

class virtual next = [input, output] Cf_gadget.next
class virtual start = [input, output] Cf_gadget.start

let create = Cf_gadget.create
let createM = Cf_gadget.createM

open Cf_cmonad.Op

type queue = <get: unit t> Queue.t
type kernel = { k_poll_: Nx_poll.t; k_queue_: queue }

let poll e k =
    let e = (e :> unit t Nx_poll.event) in
    e#load ~q:k.k_queue_ k.k_poll_

let run =
    let rec ingest1_ q =
        if Queue.is_empty q then
            Cf_cmonad.nil 
        else
            let e = Queue.take q in
            e#get >>= fun () ->
            ingest1_ q
    and ingest0_ q =
        Cf_gadget.read >>= function
        | Nx_poll.More ->
            ingest1_ q >>= fun () ->
            ingest0_ q
        | Nx_poll.Last ->
            Cf_cmonad.nil 
    in
    let rec runloop_ p w =
        match Lazy.force w with
        | Cf_flow.Z -> ()
        | Cf_flow.P ((), tl) -> assert (not true); runloop_ p tl
        | Cf_flow.Q f -> runloop_ p (lazy (f (Nx_poll.cycle p)))
    in
    fun f ->
        let p = Nx_poll.create () and q = Queue.create () in
        let k = { k_poll_ = p; k_queue_ = q; } in
        let m = f k >>= fun () -> Cf_gadget.start (ingest0_ k.k_queue_) in
        let w = Cf_gadget.eval m in
        let save = Unix.sigprocmask Unix.SIG_SETMASK [] in
        runloop_ p w;
        ignore (Unix.sigprocmask Unix.SIG_SETMASK save)

(*--- $File$ ---*)
