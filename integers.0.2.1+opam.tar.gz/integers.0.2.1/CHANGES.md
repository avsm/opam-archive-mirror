v0.2.1 2016-11-14
-----------------
* Register the custom deserializers

v0.2.0 2016-10-04
-----------------
* Expose from_byte_size functions in Unsigned and Signed
* Support for platforms where standard integer types are macros
* Add 'max' and 'min' functions to Unsigned.S.
* Expose private types for UChar, UInt8, UInt16.

0.1.0 2016-09-26
----------------
* Initial public release
