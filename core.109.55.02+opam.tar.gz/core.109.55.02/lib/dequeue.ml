include Core_kernel.Dequeue
