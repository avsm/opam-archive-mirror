include Core_kernel.Ref
