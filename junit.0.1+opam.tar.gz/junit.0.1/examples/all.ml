let () =
  Simple.simple ()
