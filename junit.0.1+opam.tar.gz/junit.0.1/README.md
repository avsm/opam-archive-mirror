# OCaml JUnit

ocaml-junit is a module for the creation of JUnit XML reports. It
provides a typed API to produce valid reports. They are supposed to be
accepted by Jenkins.

## Installation

opam pin add junit https://github.com/Khady/ocaml-junit.git

## Documentation

Available [here](https://khady.github.io/ocaml-junit/dev/)

## References:

- [Jenkins](https://github.com/jenkinsci/xunit-plugin/blob/master/src/main/resources/org/jenkinsci/plugins/xunit/types/model/xsd/junit-10.xsd)
- [JUnit-Schema](https://github.com/windyroad/JUnit-Schema/blob/master/JUnit.xsd)
- [Windyroad](http://windyroad.com.au/dl/Open%20Source/JUnit.xsd)
- [a gist](https://gist.github.com/erikd/4192748)

Those files are archived in directory [`schemes`](schemes)
