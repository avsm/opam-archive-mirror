require "mkmf"
create_makefile("extprot_decoder")
