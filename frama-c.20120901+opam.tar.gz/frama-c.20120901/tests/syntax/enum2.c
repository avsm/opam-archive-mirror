/* run.config
   DONTRUN: main test is in enum1.
*/


#define V
#include "enum.h"

int e2() {
  return E2;
}

int f2() {
  return F22;
}

int k2() {
  return K22;
}

int i2() {
  return I2;
}
