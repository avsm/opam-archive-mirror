enum e {E1, E2};

#ifndef V
enum f {F11, F12};
enum {K11, K12};
#else
enum f {F21, F22};
enum   {K21, K22};
#endif

enum { I1, I2};
