higlo
=====

Syntax highlighter in OCaml.

More information at http://zoggy.github.io/higlo/ .
