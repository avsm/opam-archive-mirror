/* run.config
STDOPT: +"-cpp-extra-args='-nostdinc -Ishare/libc'"
*/

#define __FC_REG_TEST
#include "fc_posix_runtime.c"

