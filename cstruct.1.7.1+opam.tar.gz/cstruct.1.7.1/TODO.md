Nice-to-have for a 2.0 release:

* Bounds checking elimination at attach-time (possibly interface-breaking)

* Document the signatures for ocamldoc

Nice to have:

* Performance tests vs bitstring
