open Common

let funs = [
  prop "autocollapse" bool;
  prop "collapse" bool;
  simple_unit "collapse_go" [evas_object; bool];
]

