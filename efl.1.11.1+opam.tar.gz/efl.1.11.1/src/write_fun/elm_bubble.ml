open Common

let funs = [
  prop "pos" elm_bubble_pos;
]

