open Common

let funs = [
  prop "enabled" bool;
  prop "smooth" bool;
  prop "alpha" bool;
  prop "auto" bool;
  simple_unit "point_color_set" [evas_object; int; int; int; int; int];
]

