(* this is a wrong config file containing type errors in it *)
let job = 42
