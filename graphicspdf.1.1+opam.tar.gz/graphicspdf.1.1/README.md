graphicspdf
===========

Version of OCaml's Graphics module which outputs PDF, modelled on Pierre Weis' "GraphPS".

It depends upon camlpdf and requires ocamlfind to build.

To build:

1. type "make".

2. type "make install" to install the library.

The documents have been generated in doc/graphicspdf/html

To build the example, type "make" whilst in the examples directory.


