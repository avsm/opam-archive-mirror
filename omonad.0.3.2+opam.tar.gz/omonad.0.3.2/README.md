omonad
======

Monad syntax using ppx extensions, à la [pa_monad](http://www.cas.mcmaster.ca/~carette/pa_monad/).
