include Core_kernel.Fn
