type a = Foo [@@deriving show]
