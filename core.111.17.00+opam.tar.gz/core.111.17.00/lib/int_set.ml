include Core_kernel.Int_set
