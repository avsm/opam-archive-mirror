include Core_kernel.Result
