include Core_kernel.Intable
