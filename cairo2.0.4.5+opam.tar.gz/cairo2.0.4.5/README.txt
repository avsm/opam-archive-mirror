(* OASIS_START *)
(* DO NOT EDIT (digest: 4d79b5ff4e506312c32884c5dbbf182d) *)
This is the README file for the cairo2 distribution.

Binding to Cairo, a 2D Vector Graphics Library.

This is a binding to Cairo, a 2D graphics library with support for multiple
output devices.  Currently supported output targets include the X Window
System, Quartz, Win32, image buffers, PostScript, PDF, and SVG file output.

See the files INSTALL.txt for building and installation instructions. 

Home page: http://forge.ocamlcore.org/projects/cairo/


(* OASIS_STOP *)
