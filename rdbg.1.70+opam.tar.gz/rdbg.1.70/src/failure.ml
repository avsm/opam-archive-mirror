(* Time-stamp: <modified the 04/12/2013 (at 14:33) by Erwan Jahier> *)

(* exported *)
type info =
  | Boolean of Expr.t
  | Numeric of Expr.t

