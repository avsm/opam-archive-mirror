(* Time-stamp: <modified the 09/02/2016 (at 16:28) by Erwan Jahier> *)

open RdbgArg
open Event
open RdbgMain
open RifIO
open GnuplotRif
open Coverage
open RdbgArg
open RdbgStdLib
open LutinRdbg



(* let main_read_arg () = *)
(*   let tmp_dir =  *)
(*     match args.tmp_dir_provided with  *)
(* 	   | None -> Util.get_fresh_dir Sys.os_type  *)
(*       | Some file -> file   *)
(*   in  *)
(*   args.tmp_dir <- tmp_dir;  *)
(*   Unix.putenv "TMPDIR" (String.escaped tmp_dir)  *)
  	      
let _ =
  ( try RdbgArg.parse Sys.argv;
	 with
	     Failure(e) ->
	       output_string args.ocr e;
	       flush args.ocr ;
	       flush args.ecr ;
	       exit 2
	   | e ->
	     output_string args.ocr (Printexc.to_string e);
	     flush args.ocr;
	     exit 2
  );
;;

try 
  List.iter 
    (fun f -> 
      Printf.printf "rdbgbatch dynlinks %s\n" f; flush stdout; 
      Dynlink.loadfile f
    )
    args._others;
  if 
    (args._others = [] &&
        (Printf.eprintf "No cmxs file has been provided to %s.\n%s.\n" 
           Sys.argv.(0) "Starting in Lurette mode"; flush stderr;
         true)
      || 
        not args.rdbg 
    )
  then RdbgRun.lurette_start()
with 
  | Dynlink.Error msg -> 
    Printf.eprintf "\n*** error in rdbg (Dynlink.loadfile %s).\n*** %s.\n" 
      (List.fold_left (fun acc x -> acc^" "^x) "" args._others)
      (Dynlink.error_message msg);
    flush stderr;
    exit 2
  | Event.End(i) ->  RdbgRun.clean_terminate(); exit i
  | pb -> 
    output_string args.ocr (Printexc.to_string pb);
    Printf.printf "bye\n"; flush stdout; exit 2

;;

let _ = 
  Printf.printf "rdbgbatch: bye\n"; flush stdout; exit 0



