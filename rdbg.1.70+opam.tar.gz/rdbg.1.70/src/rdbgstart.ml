(* Time-stamp: <modified the 08/03/2016 (at 17:13) by Erwan Jahier> *)

open RdbgStdLib (* so that they are included by ocamlbuild *)
open Event
open RdbgMain
open RifIO
open GnuplotRif
open Coverage
open RdbgArg
open LutinRdbg

(* open LutinRun *)
(* open Value *)

(* faire comme dans rdbgbatch pour les arguments *)


let myexit i = 
  if args.rdbg then failwith "error in rdbg-top" else exit i

    (* Taken from 
       http://stackoverflow.com/questions/6158596/setting-the-prompt-in-an-ocaml-custom-toplevel 
    *)
let _ =   
  (Toploop.read_interactive_input :=  
     let old = !Toploop.read_interactive_input in 
     fun prompt buffer len -> 
       old "(rdbg) " buffer len);
  flush stderr;
  flush stdout;
  output_string stdout ("        Rdbg Version \""^(RdbgVersion.str)^
                          "\" (\""^RdbgVersion.sha^"\") \n");
  flush stdout;
  Topmain.main()
