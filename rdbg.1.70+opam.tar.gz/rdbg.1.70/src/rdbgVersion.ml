let str="1.70"
let sha="41a1704"
