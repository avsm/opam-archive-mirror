open Event;;
open RdbgMain;;
open RdbgStdLib;;

(* on verra pour le sucre plus tard... *)
open RdbgArg;;
open Lus2licRun;;

let sut_plugin = 
  let args = ["../../bin/lus2lic";"heater_control.lus";"-n";"heater_control"] in
  let aargs = Array.of_list args in
  Printf.printf "Lus2licRun.make %s\n" (String.concat " " args); flush stdout;
  Lus2licRun.make aargs

let env_plugin = 
  let args = ["../../bin/lus2lic";"heater_env.lus";"-n";"heater_env"] in
  let aargs = Array.of_list args in
  Printf.printf "Lus2licRun.make %s\n" (String.concat " " args); flush stdout;
  Lus2licRun.make aargs
;;

args.suts <- [Ocaml(sut_plugin)];;
args.envs <- [Ocaml(env_plugin)];;


args.step_nb <- 50;;
(* args.verbose <- 50;; *)
args.debug_rdbg <- true;;
(* Dynlink.allow_unsafe_modules true;; *)



open RdbgRun ;;
let main () = 
  let e = 
    try RdbgRun.start()
    with e -> 
      Printf.printf "pb in test.ml :  %s\n"  (Printexc.to_string e);
      flush stdout;
      exit 2
  in
  try
    let _e =  stepi e args.step_nb in
    ()
  with 
    | Event.End(_)
    | _ -> 
      Printf.printf "bye\n"; flush stdout
;;


let _ = try
  main (); 
  Printf.eprintf "main(): ok\n";flush stderr;
  clean_terminate(); 
  Printf.eprintf "clean_terminate(): ok\n"; flush stderr;
  exit 0
  
 with e -> (Printf.printf "pb in test.ml :  %s\n"  (Printexc.to_string e) ) 

