open Event;;
open RdbgMain;;
open RdbgStdLib;;

open RdbgArg;;
 args.rdbg <-false;; 
args.output <- "test3.rif0";;
#use "test.ml";;
