(**************************************************************************)
(* Utilities *)

open Data
let get_float var sol =  
  match (try List.assoc var sol with Not_found -> assert false) 
  with (F f) -> f | _ -> 
    Printf.printf "*** error when parsing float\n";
    flush stdout;
    assert false
 
let get_bool var sol =  
  match (try List.assoc var sol with Not_found -> assert false) 
  with (B b) -> b | _ -> 
    Printf.printf "*** error when parsing bool\n";
    flush stdout;
    assert false

(**************************************************************************)

let init  _ = ()
let kill  _ = ()

let mems_i = []
let mems_o = []

let (inputs : (string * Data.t) list)  = [ "x", Data.Real; "y", Data.Real]
let (outputs :(string * Data.t) list) = [ "a", Data.Real; "b", Data.Real]

let (step :  Data.subst list -> Data.subst list) =
  fun sut_outs -> 
    let x = get_float "x" sut_outs
    and y = get_float "y" sut_outs in
    let a = x +. 1.0 and b = y +. 1.0 in
(*     Printf.printf "Sut step x=%f y=%f a=%f b=%f\n" x y a b; *)
(*     flush stdout; *)
      [("a",F a);("b",F b)]

type ctx = Event.t
type e = Event.t

let (step_dbg : Data.subst list -> ctx -> (Data.subst list -> ctx -> e)-> e) =
  fun sl ctx cont -> 
    let atom = {
      Event.file = "sut.ml" ; 
      Event.str = "
    let x = get_float \"x\" sut_outs
    and y = get_float \"y\" sut_outs in
    let a = x +. 1.0 and b = y +. 1.0 in
      [(\"a\",F a);(\"b\",F b)]
" ;
      Event.line = 30,37; (* a bit touchy to be kept in sync manually... *)
      Event.char = 871,1098 ; (* even worse! *)
      Event.stack= None; 
    }
    in
    let sinfo = {
      (* it's not really mandatory to define it (i.e., to put a
         non-empty list in there), in particular if it is not compiler
         generated code... *)
      Event.atoms = [atom]; 
      Event.expr = ( (* not touchy this time, but tedious.. *)
        let xp1   = Expr.Op(Expr.Sum, [Expr.Var "x"; Expr.Fval 1.0]) in
        let yp1   = Expr.Op(Expr.Sum, [Expr.Var "y"; Expr.Fval 1.0]) in
        let def_a = Expr.Op(Expr.Eq, [Expr.Var "a"; xp1]) in
        let def_b = Expr.Op(Expr.Eq, [Expr.Var "b"; yp1]) in
        Expr.Op(Expr.And, [def_a; def_b]));  
      Event.more = None;  (* stub *)
    }
    in
    let ctx = Event.incr_event_nb ctx in
    {
      Event.step = ctx.Event.step;
      Event.data = ctx.Event.data;
      Event.nb = ctx.Event.nb;
      Event.depth = ctx.Event.depth;
      Event.kind = Event.Exit;
      Event.lang = "ocaml";
      Event.name = "ze sut";
      Event.inputs = inputs ;
      Event.outputs = outputs;
      Event.sinfo = Some (fun() -> sinfo);
      Event.next = (fun () -> cont (step sl) ctx);
      Event.terminate = ctx.Event.terminate;
    } 

open RdbgPlugin 
let plugin = {
  id = "ocaml sut";
  inputs = inputs;
  outputs= outputs;
  kill= kill;
  init_inputs= mems_i;
  init_outputs= mems_o;
  step = step;
  step_dbg = step_dbg
}


