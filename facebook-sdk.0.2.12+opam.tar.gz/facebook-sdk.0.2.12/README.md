Facebook Graph API client library for oCaml
-------------------------------------------

OCaml bindings to the Facebook graph API using cohttp and lwt threads.  This
package is still in the early stages of development and at present only
contains the functionality required to fetch a user's timeline.