
int (*f(int i))() {
  int g() {
    return i;
  };
  return &g;
}

int main(int argc, char **argv)
{
  int (*g1)();
  int (*g2)();
  g1 = f(1);
  printf("%d\n",g1());
  g2 = f(2);
  printf("%d %d\n",g1(),g2());
}
