open Gl
open GlPix
open GlTex

external image1d_direct :
    proxy:bool -> level:int -> internal:int ->
    width:int -> border:int -> format:[< format] -> [< kind] Raw.t -> unit
    = "ml_glTexImage1D_bc""ml_glTexImage1D"

external image2d_direct :
    proxy:bool -> level:int -> internal:int -> width:int ->
    height:int -> border:int -> format:[< format] -> [< kind] Raw.t -> unit
    = "ml_glTexImage2D_bc""ml_glTexImage2D"

external image3d_direct :
    proxy:bool -> level:int -> internal:int -> width:int ->
    height:int -> depth:int -> border:int -> format:[< format] -> [< kind] Raw.t -> unit
    = "ml_glTexImage3D_bc" "ml_glTexImage3D"

external parameter : target:[`texture_1d|`texture_2d|`texture_3d] -> parameter -> unit
    = "mlext_glTexParameter"

external bind_texture : target:[`texture_1d|`texture_2d|`texture_3d] -> texture_id -> unit
    = "mlext_glBindTexture"

type cap =
  [`alpha_test|`auto_normal|`blend|`clip_plane0|`clip_plane1|`clip_plane2
  |`clip_plane3|`clip_plane4|`clip_plane5|`color_material|`cull_face
  |`depth_test|`dither|`fog|`light0|`light1|`light2|`light3|`light4|`light5
  |`light6|`light7|`lighting|`line_smooth|`line_stipple
  |`index_logic_op |`color_logic_op
  |`map1_color_4|`map1_index|`map1_normal|`map1_texture_coord_1
  |`map1_texture_coord_2|`map1_texture_coord_3|`map1_texture_coord_4
  |`map1_vertex_3|`map1_vertex_4|`map2_color_4|`map2_index|`map2_normal
  |`map2_texture_coord_1|`map2_texture_coord_2|`map2_texture_coord_3
  |`map2_texture_coord_4|`map2_vertex_3|`map2_vertex_4|`normalize|`point_smooth
  |`polygon_smooth|`polygon_stipple|`scissor_test|`stencil_test|`texture_1d
  |`texture_2d|`texture_3d|`texture_gen_q|`texture_gen_r|`texture_gen_s|`texture_gen_t]

external enable : cap -> unit = "mlext_glEnable"
external disable : cap -> unit = "mlext_glDisable"
external is_enabled : cap -> bool = "mlext_glIsEnabled"
