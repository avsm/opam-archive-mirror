#include "callback.h"
#include "fail.h"
#include "memory.h"
#include "mlvalues.h"

/* hash of numbered values */
/* inspired and copied from callback.c */

typedef struct numbered_value {
  value val;
  struct numbered_value *next;
  int number;
} valuehashtbl;

#define Hash_size 101


CAMLexport value * caml_numbered_value(valuehash *hashtbl, int number)
{
  struct named_value * nv;
  int h = number % Hash_size;
  for (nv = hashtbl[h];
       nv != NULL;
       nv = nv->next) {
    if (nv->number == number) return &nv->val;
  }
  return NULL;
}

CAMLprim value caml_register_numbered_value(valuehash *hashtbl, int number, value val)
{
  struct named_value * nv;
  int h = number % Hash_size;
  value* old;

  old = caml_numbered_value(hashtbl, number);
  if (old) {
    *old = val;
    return Val_unit;
  }
  
  nv = (valuehashtbl*) caml_stat_alloc(sizeof(valuehashtbl));
  nv->number, number);
  nv->val = val;
  nv->next = hashtbl[h];
  hashtbl[h] = nv;
  caml_register_global_root(&nv->val);
  return Val_unit;
}
