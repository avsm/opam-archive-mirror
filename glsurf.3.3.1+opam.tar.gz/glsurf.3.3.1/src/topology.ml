(**************************************************************************)
(*                                                                        *)
(*                               GlSurf                                   *)
(*                                                                        *)
(*                   C. Raffalli, Universite de Savoie                    *)
(*                                                                        *)
(* Copyright 2003, 2004 Christohe Raffalli                                *)
(*                                                                        *)
(*  This file is part of GlSurf.                                          *)
(*                                                                        *)
(*  GlSurf is free software; you can redistribute it and/or modify        *)
(*  it under the terms of the GNU General Public License as published by  *)
(*  the Free Software Foundation; either version 2 of the License, or     *)
(*  (at your option) any later version.                                   *)
(*                                                                        *)
(*  GlSurf is distributed in the hope that it will be useful,             *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *)
(*  GNU General Public License for more details.                          *)
(*                                                                        *)
(*  You should have received a copy of the GNU General Public License     *)
(*  along with GlSurf; if not, write to the Free Software                 *)
(*  Foundation, Inc., 59 Temple Place, Suite 330, Boston,                 *)
(*  MA  02111-1307  USA                                                   *)
(**************************************************************************)

open Format

type topores =
    Par of topores list

let rec print_topology' (Par l) =
  print_string "(";
  print_topology l;
  print_string ")"

and print_topology l =
  List.iter print_topology' l

let rec topo_to_string' (Par l) =
  "("^topo_to_string l^")"

and topo_to_string l =
  List.fold_right (fun x s ->  topo_to_string' x ^ s) l ""

let string_to_topo s =
  let rec fn acc i =
    if i >= String.length s then (acc, i) else
      match s.[i] with
      | ')' ->
	acc, i+1
      | '(' ->
	let r, j = fn [] (i+1) in
	fn (Par r::acc) j
      | _ -> invalid_arg "string_to_topo"
  in fst (fn [] 0)

(* comparison: you must normalize ordinal before comparison *)
let rec compare_topo  o1 o2 = match o1, o2 with
  | [], [] -> 0
  | [], _ -> 1
  | _, [] -> -1
  | x::o1', y::o2' ->
      match compare_topo' x y with
	-1 -> -1
      | 1 -> 1
      | 0 -> compare_topo o1' o2'
      | _ -> assert false

and compare_topo' (Par x) (Par y) =
  compare_topo x y

(* compute the normal form of an ordinal*)
let rec normalize_topo o1 =
  List.sort compare_topo' (List.map normalize_topo' o1)

and normalize_topo' (Par o1) = Par (normalize_topo o1)

let rec div2_topo l = match l with
  [] -> []
| x::y::l ->
    if not (compare_topo' x y = 0) then begin
      print_string "Warning: bad topology";
      print_newline ();
    end;
    x::div2_topo l
| _ -> []

and div2_topo' (Par l) = Par (div2_topo l)

let rec depth l =
  List.fold_left (fun n x -> max n (depth' x)) 0 l

and depth' (Par l) = 1 + depth l
