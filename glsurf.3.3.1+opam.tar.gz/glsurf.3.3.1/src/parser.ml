(**************************************************************************)
(*                                                                        *)
(*                               GlSurf                                   *)
(*                                                                        *)
(*                   C. Raffalli, Universite de Savoie                    *)
(*                                                                        *)
(* Copyright 2003, 2004 Christohe Raffalli                                *)
(*                                                                        *)
(*  This file is part of GlSurf.                                          *)
(*                                                                        *)
(*  GlSurf is free software; you can redistribute it and/or modify        *)
(*  it under the terms of the GNU General Public License as published by  *)
(*  the Free Software Foundation; either version 2 of the License, or     *)
(*  (at your option) any later version.                                   *)
(*                                                                        *)
(*  GlSurf is distributed in the hope that it will be useful,             *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *)
(*  GNU General Public License for more details.                          *)
(*                                                                        *)
(*  You should have received a copy of the GNU General Public License     *)
(*  along with GlSurf; if not, write to the Free Software                 *)
(*  Foundation, Inc., 59 Temple Place, Suite 330, Boston,                 *)
(*  MA  02111-1307  USA                                                   *)
(**************************************************************************)

open Format
open Vect3
open Function
open Draw
open Marching_cube
open Curve
open Input_util
open Parameters
open Triangulation_tools
open Dirty
open Glarrays
open Algebra
open Action
open Optimisation
open Chrono
open Expression

let parse_float str =
  match str with parser
    [< e = Expr.parse; _ = parse_spaces >] ->
      Expr.eval e []

let parse_int str =
  match str with parser
    [< e = Expr.parse; _ = parse_spaces >] ->
     truncate (floor (Expr.eval e [] +. 0.5))

let parse_semicol str =
  match str with parser
    [< '';'; _ = parse_spaces >] ->
      ()

let eval_text str =
  let l = Str.split_delim (Str.regexp "\\$") str in

  let rec fn acc = function
      [] -> String.concat "" (List.rev acc)
    | s::l -> gn (s::acc) l

  and gn acc = function
      [] -> let r = String.concat "" (List.rev acc) in
      r
    | s::l ->
	let str = Stream.of_string s in
	let e = Expr.parse str in
	let s = Expr.write_to_string (Expr.simplify e) in
	fn (s::acc) l

  in fn [] l

let parse_while parse str =
  parse_spaces str;
  let save_line_number = !Input_util.line_number in
  let parse_pred str =
    match str with parser
    | [< ''<' >] -> (
      match str with parser
      | [< ''=' >] -> (<=)
      | [<  >] -> (<))
    | [< ''>' >] -> (
       match str with parser
      | [< ''=' >] -> (>=)
      | [<  >] -> (>))
    | [< ''=' >] -> (=)
    | [< ''!' ; ''=' >] -> (<>)
  in
  let rec fn lvl acc str =
    match str with parser
    | [< ''}' when lvl = 0 >] -> List.rev acc
    | [< ''}' as c >] -> fn (lvl - 1) (c::acc) str
    | [< ''{' as c >] -> fn (lvl + 1) (c::acc) str
    | [< 'c >] -> fn lvl (c::acc) str
  in
  let l = fn (-1) [] str in
  let rec fn () =
    let str' = Stream.of_list l in
    match str' with parser
      [< x = Expr.parse ; _ = parse_spaces;
	 p = parse_pred; _ = parse_spaces;
	 y = Expr.parse; _ = parse_spaces;
	 ''{'; _ = parse_spaces >] ->
	 if p (Expr.eval x []) (Expr.eval y []) then begin
	   try
	     while true do
	       Input_util.line_number := save_line_number;
	       parse str';
	     done
	   with
	    Exit -> fn ()
	 end
  in
  fn ()

let parse_list fn str =
  let rec parse_list' acc str =
    parse_spaces str;
    match str with parser
      [< e0 = fn >] -> parse_aux (e0::acc) str

  and parse_aux acc str =
    parse_spaces str;
    match str with parser
      [< '',' >] -> parse_list' acc str
    | [< >] -> List.rev acc

  in parse_list' [] str

let parse_elist fn str =
    match str with parser
      [< l = parse_list fn >] -> l
    | [< >] -> []

let rec parse_args fn str =
  parse_spaces str;
  match str with parser
    [< ''('; args = parse_list fn; _ = parse_spaces; '')' >] -> args
  | [< >] -> []

and parse_curve_options str =
  parse_spaces str;
  match str with parser
    [< ''[' >] ->
      let on = ref None and
	  adapt = ref None and
	  refine = ref None in
      parse_spaces str;
      let rec fn () =
	match str with parser
	  [< s = parse_ident; _ = parse_spaces;
	     n = parse_ident; _ = parse_spaces >] ->
	       begin
		 match s with
		 | "on" -> on := Some n
		 | "refine" -> refine := Some n
		 | "adapt" -> adapt := Some n
		 | _ -> failwith ("Unknown curve option: "^s)
	       end;
	       fn ()
	| [< '']' >] -> !on, !refine, !adapt
      in
      fn ()
  | [< >] ->
      None, None, None

let fp args str =
  Expr.loc_var := args;
  try
    let r = Expr.parse str in
    Expr.loc_var := [];
    r
  with
    e ->
      Expr.loc_var := []; raise e

let parse_object str =
  let old_object_syntax = get_bool false "old_object_syntax" in
  let parse_float =
    if old_object_syntax then Input_util.parse_float else parse_float
  in
  let parse_int =
    if old_object_syntax then Input_util.parse_int else parse_int
  in
  let parse_delim f str = if old_object_syntax then
    match str with parser [< r = f >] -> r
  else
    match str with parser [< ''('; _ = parse_spaces; r = f; _ = parse_spaces; '')'
			       ; _ = parse_spaces >] -> r
  in
  let parse_semicol =
    if old_object_syntax then fun str -> ()
    else parse_semicol
  in
  let vertices = ref [] in
  let triangles = ref [] in
  let edges = ref [] in
  let points = ref [] in
  let text = ref [] in
  let rec parse_vertices str =
    match str with parser
      [< l = parse_delim (parse_list parse_float) >] ->
	begin
	  match l with
	    [x;y;z] ->
	      vertices := [|x;y;z|]::!vertices;
	      parse_vertices str
	  | [x;y] ->
	      vertices := [|x;y;0.0|]::!vertices;
	      parse_vertices str
	  | _ -> failwith "missing comma or coordinates in vertices"
	end
    | [<>] -> ()
  in
  let rec parse_triangles str =
    match str with parser
      [<  l = parse_delim (parse_list parse_int) >] ->
	begin
	  match l with
	    [x;y;z] ->
	      triangles := (x,y,z)::!triangles;
	      parse_triangles str
	  | _ -> failwith "missing comma or coordinates in triangles"
	end
    | [<>] -> ()
  in
  let rec parse_points str =
    match str with parser
      [< l = parse_list parse_int >] ->
	l
  in
  let rec fn exc str =
    parse_spaces str;
    match str with parser
      [< cmd = parse_ident; _ = parse_spaces >] -> (
	match cmd with
	  "vertices" ->
	    parse_vertices str; ignore (parse_semicol str); fn exc str
	| "triangles" ->
	    parse_triangles str; ignore (parse_semicol str); fn exc str
	| "line" ->
	    let l = parse_points str in ignore (parse_semicol str);
	    edges := l:: !edges; fn exc str
	| "points" ->
	    let l = parse_points str in ignore (parse_semicol str);
	    points := l@ !points;
	    fn exc str
        | "text" ->
	    begin match str with parser
	      [<  _ = parse_spaces ;''(';  x = parse_float;_ = parse_spaces;
		  _ = parse_spaces; '','; y = parse_float; _ = parse_spaces;
		  _ = parse_spaces; '',';z = parse_float; _ = parse_spaces;
		  _ = parse_spaces; '')'; _ = parse_spaces;
		 string = parse_string; _ = parse_spaces; '';'; _ = parse_spaces >] ->
		   text:=([|x;y;z|],eval_text string)::!text;
		   fn exc str
	    end
	| "while" ->
	   parse_while (fn true) str; fn exc str
	| "let" ->
          (match str with parser
            [< name = parse_ident; args = parse_args parse_ident;
               _ = parse_spaces; ''='; e = fp args;
               _ = parse_spaces; '';' >] ->
		 Expr.fun_table := StringMap.add
		   name {Expr.fname = name; Expr.variables = args;
                           Expr.value = Expr.simplify e }
                   !Expr.fun_table;
		 if args = [] then begin
		   if List.mem_assoc name float_params then
		     List.assoc name float_params := get_val 0. name;
		   if List.mem_assoc name int_params then
		     List.assoc name int_params := get_int 0 name;
		   if List.mem_assoc name bool_params then
		     List.assoc name bool_params := get_bool true name;
		 end;
		 fn exc str
	  )

	| s ->
	    failwith ("Unknown object command "^s)
       )
    | [< >] ->
	if exc then raise Exit else ()
  in
  do_begin ();
  fn false str;
  do_end ();
  let rvertices = List.rev !vertices in
  vertices := [];
  let gs = triangles_to_polytope rvertices !triangles in
  let es, ps = object_to_curve_and_points rvertices !edges !points in
  let front_diffuse = get_tuple4 (0.7, 0.3, 0.2, 1.0) "front_diffuse" in
  let back_diffuse = get_tuple4 (0.3, 0.7, 0.2, 1.0) "back_diffuse" in
  let line_color = get_tuple4 (1.0, 1.0, 1.0, 1.0) "line_color" in
  let text_color = get_tuple4 (1.0, 1.0, 1.0, 1.0) "text_color" in
  let line_width = get_val 2.0 "line_width" in
  let transparent = get_bool false "transparent" in
  let point_color = get_tuple4 (1.0, 1.0, 0.0, 1.0) "point_color" in
  let point_size = get_val 4.0 "point_size" in
  {
   poly = Expr.cst Field_R.zero;
   ts = gs;
   es = es;
   ps = ps;
   text = !text;
   handle = None;
   next_eq = None;
   grad = (fun _ -> failwith "not a surface");
   eval = (fun _ -> failwith "not a surface");
   newton = (fun _ -> failwith "not a surface");
   hessian = (fun _ -> failwith "not a surface");
   hessian_mat = (fun _ -> failwith "not a surface");
   ihessian = (fun _ -> failwith "not a surface");
   third = (fun _ -> failwith "not a surface");
   front_diffuse = front_diffuse;
   back_diffuse = back_diffuse;
   front_ambient =  get_tuple4 (0.2, 0.2, 0.2, 1.0) "front_ambient";
   back_ambient =  get_tuple4 (0.2, 0.2, 0.2, 1.0) "back_ambient";
   front_shininess =   get_val 60.0 "front_shininess";
   back_shininess =   get_val 60.0 "back_shininess";
   front_specular  =   get_tuple4 (0.7, 0.7, 0.7, 1.0) "front_specular";
   back_specular  =   get_tuple4 (0.7, 0.7, 0.7, 1.0) "back_specular";
   transparent = transparent;
   line_color = line_color;
   line_width = line_width;
   text_color = text_color;
   point_color = point_color;
   point_size = point_size;
   pov_surface_texture = get_string "pov_surface_texture";
   pov_line_texture = get_string "pov_surface_texture";
   pov_point_texture = get_string "pov_surface_texture";
   pov_poly = get_bool true "pov_poly";
   pov_isosurface = get_bool false "pov_isosurface";
   pov_grad_coef = get_val 1.5 "pov_grad_coef";
   sorigin = get_vector3  [|0.0;0.0;0.0|] "origin";
   ssize = get_val 2.0 "size";
   auto_hide = get_bool true "auto_hide";
 }

let parse_draw_options str =
  let pause = ref (-1) in
  begin
    match str with parser
      [< ''['; s = parse_ident; _ = parse_spaces >] ->
	begin
	  match s with
	    "pause" ->
	      begin
		match str with parser
		  [< t = parse_int; _ = parse_spaces >] ->
		    pause := t;
	      end
	  | s ->
	      failwith ("Unkonwn draw option: "^s)
	end;
	begin
	  match str with parser
	    [< '']'; _ = parse_spaces >] -> ()
	end;
    |  [< >] ->
	()
  end;
  !pause

let parse_save_options str =
  match str with parser
    [< ''['; s = parse_ident; _ = parse_spaces >] ->
      let r =
	match s with
	  "ascii" ->
	    Ascii
	| "glsurf" ->
	    Glsurf
	| "binary" ->
	    Binary
	| s ->
	    failwith ("Unkonwn save option: "^s)
      in
      begin
	match str with parser
	  [< '']'; _ = parse_spaces >] -> ()
      end;
      r
  |  [< >] ->
      Binary


(*
type cmd =
    Let of (string * string list * Expr.elem)
  | Group of cmd list
  | Object of
*)

type ('a,'b) sum = Inl of 'a | Inr of 'b

let rec parse_cmd str =
  parse_spaces str;
  match str with parser
    [< cmd = parse_ident; _ = parse_spaces >] -> (
      match cmd with

      | "add_draw" ->
          (match str with parser
            [< names = parse_list parse_ident; '';' >] ->
	      let fn acc name =
		try
		  Hashtbl.find all_surfaces name::acc
		with
		  Not_found -> acc
	      in
	      let surfaces = List.fold_left fn [] names in
	      !add_to_queue [Add_surfaces surfaces];
	  )

      | "area" ->
          (match str with parser
            [< name = parse_ident; _ = parse_spaces; '';' >] ->
	      let s =
		try
		  Hashtbl.find all_surfaces name
		with
		  Not_found ->
		    failwith ("Unknown surface: "^name)
	      in
	      let _ = area s.ts in
	      ()
	  )

      | "auto_next" ->
	  (match str with parser
	    [< x = parse_int;  _ = parse_spaces; '';' >] ->
	      time_before_next := x)

      | "auto_rotate" ->
	  (match str with parser
	    [< x = parse_int;  _ = parse_spaces; '';' >] ->
	      time_before_rotate := x)

      | "begin" ->
	  do_begin ()
      | "end" ->
	  do_end ()

      | "cache" ->
	  begin match str with parser
            [<  x = parse_bool;  _ = parse_spaces; '';' >] ->
	      Cache.use_cache := x;
	      if x && not (Sys.file_exists !Cache.cache_directory) then
		Unix.mkdir !Cache.cache_directory 0o700
	  end

      | "cache_directory" ->
	  begin match str with parser
            [< dirname = parse_string; _ = parse_spaces; '';' >] ->
	      Cache.cache_directory := dirname;
	  end

      | ("color" | "vector" | "point" ) ->
          (match str with parser
            [< name = parse_ident; _ = parse_spaces; ''='; _ = parse_spaces;
	       l = parse_args parse_float; _ = parse_spaces; '';' >] ->
		 let l = Array.of_list l in
		 Hashtbl.replace !all_vectors name l
	  )

      | "curve" | "curve_correct" ->
          (match str with parser
            [< on,refine,adapt = parse_curve_options;
	       name = parse_ident; _ = parse_spaces; ''=';
	       _ = parse_spaces;
	       e = fp ["x";"y";"z"]; _ = parse_spaces; '';' >] ->
		 let ts =
		   match on with
		     Some name2 ->
		       (try
			 Hashtbl.find all_surfaces name2
		       with Not_found ->
			 failwith ("Unknown surface: "^name2))
		   | None ->
		       let e = Expr.Var "z" in
		       let s = do_make_mesh e in
		       s
		 in
		 let s = chrono (
		   match adapt with
		     None -> do_make_curve (fun _ _ -> ()) refine ts
		   | Some c ->
		       (try
			 let s =
			   Hashtbl.find all_surfaces c in
			 do_adapt_curve s
		       with Not_found ->
			 failwith ("Unknown surface: "^c))
		  ) e in
		 Hashtbl.replace all_surfaces name s)

      | "curve_mode" ->
	  (match str with parser
	    [< x = parse_bool;  _ = parse_spaces; '';' >] ->
	      !add_to_queue [Curve_mode x];
	    )

      | "delete"  ->
          (match str with parser
            [< names = parse_list parse_ident; '';' >] ->
	      List.iter do_delete names
	  )

      | "display" ->
          (match str with parser
            [< '';' >] ->
	      !add_to_queue [Redisplay]
	  )

      | "draw" ->
          (match str with parser
            [< time = parse_draw_options;
	       names = parse_elist parse_ident; '';' >] ->
	      let fn name =
		try
		  Hashtbl.find all_surfaces name
		with
		  Not_found ->
		    failwith ("Unknown surface: "^name)
	      in
	      let surfaces = List.map fn names in
	      do_draw time surfaces
	  )

      | "full_screen" ->
	  (match str with parser
	    [< x = parse_bool;  _ = parse_spaces; '';' >] ->
	      !add_to_queue [Run (fun () -> full_screen x)];
	    )

      | "initial_position" ->
	 begin match str with parser
           [< _ = parse_spaces; '';' >] ->
	     let gl_parameters = {
	       origin = get_vector3  [|0.0;0.0;0.0|] "origin";
	       size = get_val 2.0 "size"
	     } in
	     let draw_parameters = {
	       lmodel_ambient  =   get_tuple4 (0.2, 0.2, 0.2, 1.0) "lmodel_ambient";
	       lmodel_twoside  =   get_bool true "lmodel_twoside";
	       background = get_tuple3 (0.1, 0.1, 0.3) "background";
	       fog = get_hint off "fog";
	       perspective_correction = get_hint fastest "perspective_correction";
	       line_smooth = get_hint off "line_smooth";
	       point_smooth = get_hint off "line_smooth";
	       polygon_smooth = get_hint off "polygon_smooth";
	       smooth_shade =  get_bool true "smooth_shade"
	     } in
	     !add_to_queue
	       [Change_param(true,gl_parameters, draw_parameters)];
	 end

      | "input" | "include" ->
	  begin match str with parser
            [< filename = parse_string; _ = parse_spaces; '';' >] ->
	      let save_interactive = !Input_util.interactive in
	      Input_util.interactive := false;
	      let save_line_number = !Input_util.line_number in
	      Input_util.line_number := 1;
	      let ch = open_in filename in
	      let str = Stream.of_channel ch in
	      begin try
		while true do
		  parse_cmd str
		done
	      with
		Exit ->
		  close_in ch
	      end;
	      Input_util.interactive := save_interactive;
	      Input_util.line_number := save_line_number;
	      if save_interactive then begin
		print_string !Input_util.prompt; flush stdout
	      end;
	  end

      | "invert" ->
	  (match str with parser
	    [< names1 =  parse_list parse_ident; _ = parse_spaces; ''-'; ''>'; _ = parse_spaces;
	       names2 =  parse_list parse_ident; '';' >] ->
	      let func = Array.of_list (List.map (fun name -> StringMap.find name !Expr.fun_table ) names1) in
	      let args = Array.map (fun f -> Array.of_list f.Expr.variables) func in
	      let names2 = Array.of_list names2 in
	      let arity = Array.length names2 in
	      let mat = Array.init arity (fun j ->
		Array.init arity (fun i ->
		  let env = Array.to_list ( Array.mapi (fun k s ->
		    (s, if k = j then 1.0 else 0.0)) args.(i))
		  in
		  Expr.eval func.(i).Expr.value env))
	      in
	      let _ = Array.iteri (fun i name ->
		let v = Array.init arity (fun k ->  if k = i then 1.0 else 0.0) in
		let w = Pivot.solve mat v in
		let e = ref (Expr.Cst(0.0)) in
		let _ = Array.iteri (fun j x->
		  e := Expr.Add(Expr.Mul(Expr.Cst(x),Expr.Var(args.(i).(j))),!e)) w
		in
		Expr.print !e; print_newline ();
		Expr.fun_table := StringMap.add
		  name {Expr.fname = name; Expr.variables = Array.to_list args.(i);
                           Expr.value = Expr.simplify !e } !Expr.fun_table) names2
	      in
	      ())

      | "largeur" ->
          (match str with parser
            [< name = parse_ident; _ = parse_spaces; '';' >] ->
	      let s =
		try
		  Hashtbl.find all_surfaces name
		with
		  Not_found ->
		    failwith ("Unknown surface: "^name)
	      in
	      let ma,mi = largeur s.ts in
	      Printf.printf "largeur: min %f, max %f" mi ma;
	      ()
	  )

      | "length" ->
          (match str with parser
            [< name = parse_ident; _ = parse_spaces; '';' >] ->
	      let s =
		try
		  Hashtbl.find all_surfaces name
		with
		  Not_found ->
		    failwith ("Unknown surface: "^name)
	      in
	      let x = length s in
	      print_string "Length: ";
	      print_float x;
	      print_newline ();
	  )

      | "let" ->
          (match str with parser
            [< name = parse_ident; args = parse_args parse_ident;
               _ = parse_spaces; ''='; e = fp args;
               _ = parse_spaces; '';' >] ->
		 Expr.fun_table := StringMap.add
		   name {Expr.fname = name; Expr.variables = args;
                           Expr.value = Expr.simplify e }
                   !Expr.fun_table;
		 if args = [] then begin
		   if List.mem_assoc name float_params then
		     List.assoc name float_params := get_val 0. name;
		   if List.mem_assoc name int_params then
		     List.assoc name int_params := get_int 0 name;
		   if List.mem_assoc name bool_params then
		     List.assoc name bool_params := get_bool true name;
		 end;
	  )

      | "light" ->
          (match str with parser
            [< num = parse_int;  _ = parse_spaces >] ->
	      (match str with parser
	      | [< command = parse_ident; _ = parse_spaces; '';' >] ->
		  !add_to_queue
		  [match command with
		    "on" -> LightOn num
		  | "off" -> LightOff num
		  | _ -> failwith ("Illegal light command: "^command)];
             | [< r = parse_args parse_float; _ = parse_spaces; '';' >] ->
		  let pos = match r with
		  [x;y;z;t] -> (x,y,z,t)
		  | [x;y;z] -> (x,y,z,1.0)
		  | _ -> failwith ("Wrong size for light position")
		  in
		  let l = {
		    light_position = pos;
		    light_ambient = get_tuple4 (0.2,0.2,0.2,1.0) "light_ambient";
		    light_diffuse = get_tuple4 (1.0,1.0,1.0,1.0) "light_diffuse";
		    light_specular = get_tuple4 (0.8,0.8,0.8,0.8) "light_specular";} in
		  !add_to_queue [LightPos(num,l)]))

      | "line" ->
	  (match str with parser
	    [< name = parse_ident; _ = parse_spaces; ''='; _ = parse_spaces;
	       v1 = parse_ident; _ = parse_spaces;
               v2 = parse_ident; _ = parse_spaces; _ = parse_spaces; '';' >] ->
		 let v1 = Hashtbl.find !all_vectors v1 in
		 let v2 = Hashtbl.find !all_vectors v2 in
		 if Array.length v1 <> 2 || Array.length v2 <> 2 then
		   failwith "bad length of vector for line command.";
		 let [|x1;y1|] = v1 and [| x2;y2|] = v2 in
		 let x = Expr.Var "x" and y = Expr.var "y" in
		 let e = Expr.Sub(
		   Expr.Mul(
		   Expr.Sub (Expr.Cst y1, Expr.Cst y2),
		   Expr.Sub (x, Expr.Cst x2)),
		   Expr.Mul(
		   Expr.Sub (Expr.Cst x1, Expr.Cst x2),
		   Expr.Sub (y, Expr.Cst y2)))
		 in
		 let e = Expr.simplify e in
		 print_string name; print_string " = ";
		 Expr.print e; print_newline ();
		 Expr.fun_table := StringMap.add
		   name {Expr.fname = name; Expr.variables = ["x";"y"];
                           Expr.value = e}
                   !Expr.fun_table;)

      | "load" ->
	  (match str with parser
            [< name = parse_ident; _ = parse_spaces;
	       filename = parse_string; _ = parse_spaces; '';' >] ->
		 let s = load_surface filename in
		 Hashtbl.replace all_surfaces name s
	  )

      | "message" ->
	  (match str with parser
            [< name = parse_ident; _ = parse_spaces; ''='; _ = parse_spaces;
	       str = parse_string; _ = parse_spaces; '';' >] ->
		 let msg = {
		   message = eval_text str;
		   message_x = get_int (-10) "message_x";
		   message_y = get_int (-10) "message_y";
		   message_color = get_tuple3 (1.0,1.0,1.0) "message_color";
		 } in
		 !add_to_queue [Add_message (name,msg)];
	  )

      | "newton" ->
	  (match str with parser
	    [< name = parse_ident; _ = parse_spaces; ''='; _ = parse_spaces;
	       eq = parse_args Expr.parse; _ = parse_spaces;
	       vars = parse_args parse_ident; _ = parse_spaces;
	       x0 = parse_args parse_float; _ = parse_spaces; '';' >] ->
		 let p = newton_solve eq vars x0 in
		 Hashtbl.replace !all_vectors name p
	  )

      | "object" ->
          (match str with parser
            [< name = parse_ident; _ = parse_spaces; ''=';
	       _ = parse_spaces; s = parse_object; _ = parse_spaces; '';' >] ->
		 Hashtbl.replace all_surfaces name s
	  )

      | "pause" ->
            let time =
	      match str with parser
                [< r = parse_int; _ = parse_spaces; '';' >] -> r
              | [< _ = parse_spaces; '';' >] -> -1
            in
	    !add_to_queue [Wait time]

      | "plane" ->
	  (match str with parser
	    [< name = parse_ident; _ = parse_spaces; ''='; _ = parse_spaces;
	       v1 = parse_ident; _ = parse_spaces;
	       v2 = parse_ident; _ = parse_spaces;
               v3 = parse_ident; _ = parse_spaces; _ = parse_spaces; '';' >] ->
		 let v1 = Hashtbl.find !all_vectors v1 in
		 let v2 = Hashtbl.find !all_vectors v2 in
		 let v3 = Hashtbl.find !all_vectors v3 in
		 if Array.length v1 <> 3 || Array.length v2 <> 3
		     || Array.length v3 <> 3 then
		   failwith "bad length of vector for plane command.";
		 let [|x1;y1;z1|] = v1 and [|x2;y2;z2|] = v2
		 and [|x3;y3;z3|] = v3 in
		 let x = Expr.Var "x" and y = Expr.var "y"
		 and z = Expr.var "z" in
		 let det2 a b c d =
		   Expr.Sub(Expr.Mul(a,d),Expr.Mul(b,c)) in
		 let e = Expr.Add(Expr.Sub(
		   Expr.Mul(det2 (Expr.Sub (Expr.Cst y1, Expr.Cst y3))
		     (Expr.Sub (Expr.Cst y2, Expr.Cst y3))
		     (Expr.Sub (Expr.Cst z1, Expr.Cst z3))
		     (Expr.Sub (Expr.Cst z2, Expr.Cst z3)),
				  Expr.Sub (x, Expr.Cst x3)),
		   Expr.Mul(det2 (Expr.Sub (Expr.Cst x1, Expr.Cst x3))
		     (Expr.Sub (Expr.Cst x2, Expr.Cst x3))
		     (Expr.Sub (Expr.Cst z1, Expr.Cst z3))
		     (Expr.Sub (Expr.Cst z2, Expr.Cst z3)),
				  Expr.Sub (y, Expr.Cst y3))),
		   Expr.Mul(det2 (Expr.Sub (Expr.Cst x1, Expr.Cst x3))
		     (Expr.Sub (Expr.Cst x2, Expr.Cst x3))
		     (Expr.Sub (Expr.Cst y1, Expr.Cst y3))
		     (Expr.Sub (Expr.Cst y2, Expr.Cst y3)),
				  Expr.Sub (z, Expr.Cst z3)))
		 in
		 let e = Expr.simplify e in
		 print_string name; print_string " = ";
		 Expr.print e; print_newline ();
		 Expr.fun_table := StringMap.add
		   name {Expr.fname = name; Expr.variables = ["x";"y";"z"];
                           Expr.value = e}
                  !Expr.fun_table;)

      | "print" ->
	  (match str with parser
	    [< e = Expr.parse; _ = parse_spaces; '';' >] ->
	      let save_mode = !print_mode in
	      print_mode := `High_precision;
	      Expr.print e; print_newline ();
	      print_mode := save_mode;
	  )

      | "quality" ->
          (match str with parser
            [< name = parse_ident; _ = parse_spaces; '';' >] ->
	      let s =
		try
		  Hashtbl.find all_surfaces name
		with
		  Not_found ->
		    failwith ("Unknown surface: "^name)
	      in
	      let _ = evaluate_quality s.ts in
	      ()
	  )

      | "quit" ->
	  (match str with parser
	    [< '';' >] ->
	      !add_to_queue [Quit];
	    )

      | "remove_message" ->
	  (match str with parser
            [< name = parse_ident; _ = parse_spaces; '';' >] ->
	      !add_to_queue [Remove_message name])

      | "save" ->
	  (match str with parser
            [< save_option = parse_save_options; _ = parse_spaces;
	       name = parse_ident; _ = parse_spaces;
	       filename = parse_string; _ = parse_spaces; '';' >] ->
		 save_surface save_option
		   filename (Hashtbl.find all_surfaces name)
	  )

      | "save_image" ->
	  (match str with parser
            [< name = parse_string; _ = parse_spaces; '';' >] ->
	      !add_to_queue [Save_image name]
	  )

      | "string" ->
	  (match str with parser
            [< string_param = parse_ident; _ = parse_spaces; ''=';
               _ = parse_spaces; name = parse_string;
	       _ = parse_spaces; '';' >] ->
	      try
		List.assoc string_param string_params := name
	      with
		Not_found -> failwith ("Unknown string parameters: "^name)
	  )

      | "surface" ->
          (match str with parser
            [< name = parse_ident; _ = parse_spaces; ''=';
	       _ = parse_spaces;
	       e = fp ["x";"y";"z"]; _ = parse_spaces; '';' >] ->
		 let s = chrono do_make_mesh e in
		 Hashtbl.replace all_surfaces name s
	  )

      | "surface_texture" ->
	  (match str with parser
	    [< name = parse_ident; _ = parse_spaces >] ->
	      if name = "off" then
		 match str with parser
		   [< '';'; _ = parse_spaces >] ->
		     cur_stexture := None
	      else begin
		match str with parser
		    [< typ = parse_ident; _ = parse_spaces; ''('; _ = parse_spaces;
		       ex = Expr.parse; _ = parse_spaces; '','; _ = parse_spaces;
		       ey = Expr.parse; _ = parse_spaces; '','; _ = parse_spaces;
		       ez = Expr.parse; _ = parse_spaces; '')'; _ = parse_spaces;
		       '';'; _ = parse_spaces >] ->
		    let fmt = match name with
		      "alpha" -> `alpha
		    | "red" -> `red
		    | "green" -> `green
		    | "blue" -> `blue
		    | "luminance" -> `luminance
		    | _ -> failwith ("invalid texture parameter: "^name)
		    in
		    let typ = match typ with
			"chessboard" -> `chessboard
		      | "lines" -> `lines
 		    | _ -> failwith ("invalid texture parameter: "^typ)
		    in
		    let evalx [|x;y;z|] = Expr.eval ex ["x",x;"y",y;"z",z] in
		    let evaly [|x;y;z|] = Expr.eval ey ["x",x;"y",y;"z",z] in
		    let evalz [|x;y;z|] = Expr.eval ez ["x",x;"y",y;"z",z] in
		    let color = get_tuple4 (1.0,1.0,1.0,1.0) "surface_texture_color" in
		    let mode = if
		      get_bool true "blend_surface_texture" then `blend else `modulate in
		    cur_stexture := Some (fmt, typ, evalx, evaly, evalz ,color,mode);
	      end)


      | "remove_draw" ->
          (match str with parser
            [< names = parse_list parse_ident; '';' >] ->
	      let fn acc name =
		try
		  Hashtbl.find all_surfaces name::acc
		with
		  Not_found -> acc
	      in
	      let surfaces = List.fold_left fn [] names in
	      !add_to_queue [Remove_surfaces surfaces]
	  )

      | "topology" ->
          (match str with parser
            [< name = parse_ident; _ = parse_spaces; '';' >] ->
	      let s =
		try
		  Hashtbl.find all_surfaces name
		with
		  Not_found ->
		    failwith ("Unknown surface: "^name)
	      in
	      let _ = euler s.ts in
	      ()
	  )

      | "while" ->
	  parse_while parse_cmd str

      | name ->
	  raise (Stream.Error ("Unknown command: "^name)))

  | [< '';' >] ->
      ()

  | [< 'c >] ->
      raise (Stream.Error ("Illegal char: "^Char.escaped c))

  | [< >] ->
      raise Exit
