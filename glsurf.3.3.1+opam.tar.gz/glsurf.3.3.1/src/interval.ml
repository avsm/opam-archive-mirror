(**************************************************************************)
(*                                                                        *)
(*                               GlSurf                                   *)
(*                                                                        *)
(*                   C. Raffalli, Universite de Savoie                    *)
(*                                                                        *)
(* Copyright 2003, 2004 Christohe Raffalli                                *)
(*                                                                        *)
(*  This file is part of GlSurf.                                          *)
(*                                                                        *)
(*  GlSurf is free software; you can redistribute it and/or modify        *)
(*  it under the terms of the GNU General Public License as published by  *)
(*  the Free Software Foundation; either version 2 of the License, or     *)
(*  (at your option) any later version.                                   *)
(*                                                                        *)
(*  GlSurf is distributed in the hope that it will be useful,             *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *)
(*  GNU General Public License for more details.                          *)
(*                                                                        *) 
(*  You should have received a copy of the GNU General Public License     *)
(*  along with GlSurf; if not, write to the Free Software                 *)
(*  Foundation, Inc., 59 Temple Place, Suite 330, Boston,                 *)
(*  MA  02111-1307  USA                                                   *)
(**************************************************************************)

open Format
open Algebra
open Expression
open Vect3
open Dirty
open Floatexpr
open Expr

let rec eval_power exp puis = 
  (* power function in field (time log_2(n))*)
  match puis with
    0 -> 1.0
  | 1 -> exp
  | _ when puis < 0 -> 1.0 /. (eval_power exp (-puis))
  | _ when puis mod 2 = 0 ->
      let r = eval_power exp (puis / 2) in
      r *. r
  | _ -> 
      let r = eval_power exp ((puis - 1) / 2) in
      exp *. (r *. r) 

let bound_square x y =
  let a = x *. x and b = y *. y in
  if x *. y <= 0.0 then 0.0, max a b
  else min a b, max a b
  
let bound_product x y x' y' =
  let a = x *. x' and b = x *. y' 
  and c = y *. x' and d = y *. y' in
  min (min a b) (min c d), max (max a b) (max c d)

let addi((x,y),(x',y')) = 
  x +. x',  y +. y'

let subi((x,y),(x',y')) = 
  x -. y',  y -. x'

let addil((x,y),(x')) = 
  x +. x',  y +. x'

let mulil((x,y),x') =
  let a = x *. x' 
  and b = y *. x' in
  min a b, max a b

let muli((x,y),(x',y')) =
  let a = x *. x' and b = x *. y' 
  and c = y *. x' and d = y *. y' in
  min (min a b) (min c d), max (max a b) (max c d)
  
let minsqi (x,y) =
  min (x*.y) (min (x*.x) (y*.y))

let bound_eval expr v = 
  let tbl = Hashtbl.create 1001 in
  let rec fn e =
    try Hashtbl.find tbl e with Not_found -> 
    let r = match e with
      Var name -> 
	(try 
	  List.assoc name v 
	with Not_found -> 
	  failwith ("Unbound variable: "^name))
    | Cst n -> n, n
    | Add (e,e') -> 
	let x,y = fn e and x',y' = fn e' in
        x +. x',  y +. y'
    | Sub (e,e') -> 
	let x,y = fn e and x',y' = fn e' in
	x -. y',  y -. x'
    | Mul (e,e') -> 
	let x,y = fn e and x',y' = fn e' in
	let a = x *. x' and b = x *. y' 
	and c = y *. x' and d = y *. y' in
	min (min a b) (min c d), max (max a b) (max c d)
    | Div (e,e') -> 
	let x,y = fn e and x',y' = fn e' in
	if x' *. y' <= 0.0 then
	  failwith "Div by zero in bound_eval"
	else
	let a = x /. x' and b = x /. y' 
	and c = y /. x' and d = y /. y' in
	min (min a b) (min c d), max (max a b) (max c d)
    | Pow (e,deg) ->  
	let x,y = fn e in
	let a = eval_power x deg and b = eval_power y deg in
	if x *. y <= 0.0 && deg mod 2 = 0 then 0.0, max a b
	else min a b, max a b
    | Tra (trindex, e) -> 
	failwith "Tra not supported in bound_eval"
    | Tra2 (trindex, e, e') -> 
	failwith "Tra2 not supported in bound_eval"
    in
    Hashtbl.add tbl e r;
    r
  in 
  fn expr 

let is_non_zero expr v =
  let x, y = bound_eval expr v in
  x *. y > 0.0

let is_positive expr v =
  let x, _ = bound_eval expr v in
  x > 0.0

type dl1 =
  { cst : elem;
    lin : elem list;
    res : elem
  }

let add(e, e') =
  if e = zero then e' else
  if e' = zero then e else
  Add(e,e')

let sub(e, e') =
  if e = zero then e' else
  if e' = zero then e else
  Sub(e,e')

let mul(e, e') =
  if e = zero then zero else
  if e' = zero then zero else
  if e = one then e' else
  if e' = one then e else
  Mul(e,e')


let pow(e, n) =
  if e = zero then zero else
  if e = one || n = 0 then one else
  if n = 1 then e else
  Pow(e,n)

let expr_from_lin v l =
  List.fold_left2 (fun e name l -> add(mul(l,Var name),e)) zero v l

let expr_from_dl1 v dl1 =
  add(dl1.cst, add(expr_from_lin v dl1.lin, dl1.res))

let compute_dl1 v expr = 
  Pervasives.print_string "#"; Pervasives.flush stdout;
  let expr = Expr.simplify expr in
  Pervasives.print_string "@"; Pervasives.flush stdout;
  let zz = List.map (fun v -> zero) v in
  let rec factorial n = 
    if n <= 1 then 1.0 else float n *. factorial (n - 1) in
  let binome p n a b =
    let coef p n = factorial n /. (factorial p *. factorial (n - p)) in
(*
    let rec fn p =
      if p = n then pow(a,n) else add(fn (p+1), mul(Cst (coef p n), mul(pow(a,p),pow(b,(n-p)))))
    in
    fn p
*)
    let rec fn acc p =
      if p = n then acc else mul(acc,add(fn a (p+1), mul(Cst (coef p n), pow(b,(n-p)))))
    in
    fn (pow(a,p)) p
  in
  let tbl = Hashtbl.create 1001 in
  let rec fn e = 
    try Hashtbl.find tbl e
    with Not_found -> let r = 
    Pervasives.print_string "*"; Pervasives.flush stdout;
    match e with 
      Var name -> 
	if List.mem name v then
	  { cst = zero; lin = List.map (fun v -> if name = v then one else zero) v; res = zero }
	else
	  { cst = e; lin = zz; res = zero }
    | Cst n as e -> 
	{ cst = e; lin = zz; res = zero }
    | Add (e,e') -> 
	let dle = fn e and dle' = fn e' in
	{ cst = add(dle.cst, dle'.cst);
          lin = List.map2 (fun e e' -> add(e,e')) dle.lin dle'.lin;
	  res = add(dle.res, dle'.res) }
    | Sub (e,e') -> 
	let dle = fn e and dle' = fn e' in
	{ cst = sub(dle.cst, dle'.cst);
          lin = List.map2 (fun e e' -> sub(e,e')) dle.lin dle'.lin;
	  res = sub(dle.res, dle'.res) }
    | Mul (e,e') -> 
	let dle = fn e and dle' = fn e' in
	{ cst = mul(dle.cst, dle'.cst);
          lin = List.map2 (fun e e' -> add(mul(dle'.cst,e),mul(dle.cst,e'))) dle.lin dle'.lin;
	  res = 
	    let le = expr_from_lin v dle.lin and le' = expr_from_lin v dle'.lin in
	    let ale = add(dle.cst,le) and ale' = add(dle'.cst,le') in
	    add(mul(le,le'),add(mul(ale,dle'.res), add(mul(ale',dle.res), mul(dle.res,dle'.res))))
	}
    | Div (e,e') ->
	failwith "Div not supported in dl1"
    | Pow (e,deg) ->  
	let dle = fn e in
	begin
	  match deg with 
	    0 -> fn one
	  | 1 -> dle
	  | _ ->
	      { cst = pow(dle.cst, deg);
		lin = List.map (fun e -> mul(Cst(float deg),mul(e,pow(dle.cst,deg - 1)))) dle.lin;
		res = let le = expr_from_lin v dle.lin in
                  add(binome 1 deg dle.res (add(dle.cst,le)),binome 2 deg le dle.cst)
	      }
	end
    | Tra (trindex, e) -> 
	failwith "Tra not supported in dl1"
    | Tra2 (trindex, e, e') -> 
	failwith "Tra2 not supported in dl1"
    in
    Hashtbl.add tbl e r;
    r
  in 
  let dl1 = fn expr in
  dl1
(*
  { cst = Expr.simplify dl1.cst;
    lin = List.map Expr.simplify dl1.lin;
    res = Expr.simplify dl1.res }
*)
(*
test_dl1 (x + hx)^2 + (y+hy)^2 + (z+hz)^2 hx,hy,hz;
test_dl1 (x + hx)^4 + (y+hy)^4 + (z+hz)^4 hx,hy,hz;
test_dl1 ((x + hx)^4 + (y+hy)^4 + (z+hz)^4)*((x + hx)^2 + (y+hy)^2 + (z+hz)^2) hx,hy,hz;
*)

let bound_dl1_on_simplex v dl1 env simplex =
  Pervasives.print_string "$"; Pervasives.flush stdout;
  let a = eval dl1.cst env in
  let env2 = ref (List.map (fun name -> name,(max_float, min_float)) v) in
  let b = List.map (fun env' -> 
    env2 := List.map2 
	(fun (name,(mi,ma)) h -> name,(min mi h, max ma h)) !env2 env';
    List.fold_left2 (fun acc e h -> acc +. h *. eval e env) 0.0 dl1.lin env') 
      simplex in
  let bmin = List.fold_left min max_float b in 
  let bmax = List.fold_left max min_float b in 
  let env' = List.map (fun (v,x) -> v,(x,x)) env in
  let cmin, cmax = bound_eval dl1.res (List.rev_append env' !env2) in
  a +. bmin +. cmin, a +. bmax +. cmax

(*
let bound_on_simplex v dl1 coords =
  let center = 
*)
