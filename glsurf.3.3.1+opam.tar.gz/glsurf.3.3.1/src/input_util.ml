(**************************************************************************)
(*                                                                        *)
(*                               GlSurf                                   *)
(*                                                                        *)
(*                   C. Raffalli, Universite de Savoie                    *)
(*                                                                        *)
(* Copyright 2003, 2004 Christohe Raffalli                                *)
(*                                                                        *)
(*  This file is part of GlSurf.                                          *)
(*                                                                        *)
(*  GlSurf is free software; you can redistribute it and/or modify        *)
(*  it under the terms of the GNU General Public License as published by  *)
(*  the Free Software Foundation; either version 2 of the License, or     *)
(*  (at your option) any later version.                                   *)
(*                                                                        *)
(*  GlSurf is distributed in the hope that it will be useful,             *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *)
(*  GNU General Public License for more details.                          *)
(*                                                                        *)
(*  You should have received a copy of the GNU General Public License     *)
(*  along with GlSurf; if not, write to the Free Software                 *)
(*  Foundation, Inc., 59 Temple Place, Suite 330, Boston,                 *)
(*  MA  02111-1307  USA                                                   *)
(**************************************************************************)

let prompt = ref ""

let interactive = ref false

let line_number = ref 1

let is_star str =
  let l = Stream.npeek 2 str in
  if List.length l < 2 then false else
  match List.nth l 1 with
    ('*') -> true
  | _ -> false

let rec search_end_comment n str = match str with parser
  [< ''*' >] -> maybe_end_comment n str
| [< ''(' when is_star str >] -> Stream.junk str; search_end_comment (n+1) str
| [< 'c >] ->
    if c = '\n' then incr line_number;
    search_end_comment n str

and maybe_end_comment n str = match str with parser
  [< '')' >] -> if n = 0 then () else search_end_comment (n-1) str
| [< ''*' >] -> maybe_end_comment n str
| [< 'c >] ->
    if c = '\n' then incr line_number;
    search_end_comment n str

let rec parse_spaces str = match str with parser
  [< ''\n' when !interactive >] ->
    print_string !prompt; flush stdout; parse_spaces str
| [< ''\n'; _ = parse_spaces >] -> incr line_number
| [< '' '|'\r'|'\t'; _ = parse_spaces >] -> ()
| [< ''(' when is_star str >]  ->
    Stream.junk str; search_end_comment 0 str; parse_spaces str
| [< >] -> ()

let rec parse_delim op cl f str =
  parse_spaces str;
  match str with parser
    [< 'c when c = op;
       r = parse_delim op cl f;
       _ = parse_spaces; 'c when c = cl >] -> r
  | [< r = f >] -> r

let buf = Bytes.create 4096

let rec parse_digits' pos str = match str with parser
    [< ''0'..'9' as c; npos = parse_digits' (pos + 1) >] ->
      Bytes.set buf pos c; npos
  | [< >] -> pos
let parse_digits pos str = match str with parser
    [< ''0'..'9' as c; npos = parse_digits' (pos + 1) >] ->
      Bytes.set buf pos c; npos

let parse_int' str =
  let npos = match str with parser
      [< ''+'; _ = parse_spaces; npos = parse_digits 0 >] -> npos
    | [< ''-'; _ = parse_spaces; npos = parse_digits 1 >] ->
	Bytes.set buf 0 '-'; npos
    | [< npos = parse_digits 0 >] -> npos
  in
  int_of_string (Bytes.sub_string buf 0 npos)

let parse_int = parse_delim '(' ')' parse_int'

let parse_big_int' str =
  let npos = match str with parser
      [< ''+'; _ = parse_spaces; npos = parse_digits 0 >] -> npos
    | [< ''-'; _ = parse_spaces; npos = parse_digits 1 >] ->
	Bytes.set buf 0 '-'; npos
    | [< npos = parse_digits 0 >] -> npos
  in
  Big_int.big_int_of_string (Bytes.sub_string buf 0 npos)

let parse_big_int = parse_delim '(' ')' parse_big_int'

let parse_float_exp' pos str =
  Bytes.set buf pos 'e';
  let pos = pos+1 in
  match str with parser
    [< npos = parse_digits pos >] -> npos
  | [< ''+'; npos = parse_digits pos >] -> npos
  | [< ''-'; npos = parse_digits (pos+1) >] -> Bytes.set buf pos '-'; npos

let parse_float_exp pos str =
  if pos = 0 then match str with parser
    [< ''e'|'E'; npos = parse_float_exp' pos >] -> npos
  else match str with parser
    [< ''e'|'E'; npos = parse_float_exp' pos >] -> npos
  | [< >] -> pos

let parse_float_dec pos str = match str with parser
    [< ''.'; pos' = parse_digits' (pos+1);
       npos = parse_float_exp pos' >] -> Bytes.set buf pos '.'; npos
  | [< npos = parse_float_exp pos >] -> npos

let parse_float_dec' pos str = match str with parser
    [< ''.'; pos' = parse_digits' (pos+1);
       npos = parse_float_exp pos' >] -> Bytes.set buf pos '.'; npos

let is_digit str =
  let l = Stream.npeek 2 str in
  if List.length l < 2 then false else
  match List.nth l 1 with
    ('0'..'9') -> true
  | _ -> false

let parse_float' str =
  let npos = match str with parser
      [< pos = parse_digits 0;
	 npos = parse_float_dec pos >] -> npos
    | [< ''-' when is_digit str ; pos = parse_digits' 1;
	 npos = parse_float_dec pos >] -> Bytes.set buf 0 '-'; npos
    | [< npos = parse_float_dec' 0 >] -> npos
  in
  float_of_string (String.sub buf 0 npos)

let parse_float = parse_delim '(' ')' parse_float'

let parse_denom str =
  parse_spaces str;
  match str with parser
      [< ''/'; _ = parse_spaces; n = parse_big_int >] -> Num.Big_int n
    | [< >] -> Num.Int 1

let parse_num' str =
  match str with parser
      [< n = parse_big_int; p = parse_denom >] -> Num.div_num (Num.Big_int n) p

let parse_num = parse_delim '(' ')' parse_num'

let parse_tuple' f g str =
  match str with parser
      [< fst = f; _ = parse_spaces; '',';
	 _ = parse_spaces; snd = g >] -> fst, snd

let parse_tuple f g str = parse_delim '(' ')' (parse_tuple' f g) str

let parse_complex zero opp f str =
  let fn str = match str with parser
      [< ''+'; _ = parse_spaces; re = f >] -> re
    | [< ''-'; _ = parse_spaces; re = f >] -> opp re
    | [< >] -> zero
  in
  let gn str = match str with parser
      [< ''+'; _ = parse_spaces; ''i'; _ = parse_spaces; im = f >] -> im
    | [< ''-'; _ = parse_spaces; ''i'; _ = parse_spaces; im = f >] -> opp im
    | [< >] -> zero
  in
  match str with parser
      [< ''i'; _ = parse_spaces; im = f;
	 _ = parse_spaces; re = fn >] -> re, im
    | [< re = f; _ = parse_spaces; im = gn >] -> re, im

let rec parse_alpha' pos str = match str with parser
    [< ''0'..'9'|'_'|'a'..'z'|'A'..'Z' as c;
       npos = parse_alpha' (pos + 1) >] ->
      Bytes.set buf pos c; npos
  | [< >] -> pos

let parse_alpha pos str = match str with parser
    [< ''a'..'z'|'A'..'Z' as c; npos = parse_alpha' (pos + 1) >] ->
      Bytes.set buf pos c; npos

let parse_ident' str =
  let npos = match str with parser
      [< npos = parse_alpha 0 >] -> npos
  in
  String.sub buf 0 npos

let parse_ident = parse_delim '(' ')' parse_ident'

let parse_bool str =
  let name = parse_ident str in
  match name with
    "true" -> true
  | "false" -> false
  | _ -> raise (Stream.Error "waiting for \"true\" or \" false\".")


let parse_string str =
  match str with parser
    [< ''"' >] ->
      let rec fn pos = match str with parser
	[< ''"' >] ->
	  Bytes.sub_string buf 0 pos
      | [< ''\\' >] ->
	  Bytes.set buf pos (Stream.next str);
	  fn (pos + 1)
      | [< 'c >] ->
	  if c = '\n' then incr line_number;
	  Bytes.set buf pos c;
	  fn (pos + 1)
      in
      fn 0
