(**************************************************************************)
(*                                                                        *)
(*                               Glsurf                                   *)
(*                                                                        *)
(*                   C. Raffalli, Universite de Savoie                    *)
(*                                                                        *)
(* Copyright 2003, 2004, 2005 Christohe Raffalli                          *)
(*                                                                        *)
(*  This file is part of GlSurf.                                          *)
(*                                                                        *)
(*  GlSurf is free software; you can redistribute it and/or modify        *)
(*  it under the terms of the GNU General Public License as published by  *)
(*  the Free Software Foundation; either version 2 of the License, or     *)
(*  (at your option) any later version.                                   *)
(*                                                                        *)
(*  GlSurf is distributed in the hope that it will be useful,             *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *)
(*  GNU General Public License for more details.                          *)
(*                                                                        *) 
(*  You should have received a copy of the GNU General Public License     *)
(*  along with GlSurf; if not, write to the Free Software                 *)
(*  Foundation, Inc., 59 Temple Place, Suite 330, Boston,                 *)
(*  MA  02111-1307  USA                                                   *)
(**************************************************************************)

open Format
open Algebra
open Expression
open Vect3
open Function
open Parameters
open Target
open Dirty

type vertex_info =
  Initial
| Minsize of float
| Onsurface
| Onsurfacetmp of point

type cvertex = 
    { 
      mutable cpos : point;
      mutable info : vertex_info;
    }

(* a cube: height vertices *)
type cube =
    { 
      face1 : face;
      face2 : face;
      face3 : face;
      face4 : face;
      face5 : face;
      face6 : face;
    } 

and face =
    {
     edge1 : edge;
     edge2 : edge;
     edge3 : edge;
     edge4 : edge;
     mutable face_status : face_status;
   }

(* an edge: two vertices *)
and edge =
    { vertex1 : cvertex;
      vertex2 : cvertex;
      mutable status : edge_status;
    }

and edge_status =
    Nothing
  | Mesh_point of point
  | Divided of edge * edge

and face_status =
    FNothing
  | FDivided of face * face * face * face
  
let cedge12 t =
  t.face1.edge3
let cedge23 t =
  t.face1.edge2
let cedge43 t =
  t.face1.edge4
let cedge14 t =
  t.face1.edge1
let cedge12' t =
  t.face2.edge3
let cedge23' t =
  t.face2.edge2
let cedge43' t =
  t.face2.edge4
let cedge14' t =
  t.face2.edge1
let cedge11' t =
  t.face5.edge3
let cedge22' t =
  t.face5.edge4
let cedge33' t =
  t.face6.edge4
let cedge44' t =
  t.face6.edge3

let vertex1 t =
  (cedge12 t).vertex1
let vertex2 t =
  (cedge12 t).vertex2
let vertex3 t =
  (cedge43 t).vertex2
let vertex4 t =
  (cedge43 t).vertex1
let vertex1' t =
  (cedge12' t).vertex1
let vertex2' t =
  (cedge12' t).vertex2
let vertex3' t =
  (cedge43' t).vertex2
let vertex4' t =
  (cedge43' t).vertex1

let length_edges e = 
  norm (e.vertex2.cpos -- e.vertex1.cpos)

let fold_edges_cube f g t =
  g (g (g (g (f (cedge12 t)) (f (cedge23 t)))
	  (g (f (cedge43 t)) (f (cedge14 t))))
       (g (g (f (cedge12' t)) (f (cedge23' t)))
	  (g (f (cedge43' t)) (f (cedge14' t)))))
    (g (g (f (cedge11' t)) (f (cedge22' t)))
       (g (f (cedge33' t)) (f (cedge44' t))))

let fold_edges_cube_tail acc f t =
  let acc = f acc (cedge12 t) in
  let acc = f acc (cedge23 t) in
  let acc = f acc (cedge43 t) in
  let acc = f acc (cedge14 t) in
  let acc = f acc (cedge12' t) in
  let acc = f acc (cedge23' t) in
  let acc = f acc (cedge43' t) in
  let acc = f acc (cedge14' t) in
  let acc = f acc (cedge11' t) in
  let acc = f acc (cedge22' t) in
  let acc = f acc (cedge44' t) in
  acc
    
let iter_edges_cube f t =
  f (cedge12 t); f (cedge23 t);
  f (cedge43 t); f (cedge14 t);
  f (cedge12' t); f (cedge23' t);
  f (cedge43' t); f (cedge14' t);
  f (cedge11' t); f (cedge22' t);
  f (cedge33' t); f (cedge44' t)

let try_iter_edges_cube f t =
  let f g t = try  f (g t) with Not_found -> () in
  f cedge12 t; f cedge23 t;
  f cedge43 t; f cedge14 t;
  f cedge12' t; f cedge23' t;
  f cedge43' t; f cedge14' t;
  f cedge11' t; f cedge22' t;
  f cedge33' t; f cedge44' t

let iter_vertex_edges_cube f t =
  f (vertex1 t) (cedge12 t) (cedge14 t) (cedge11' t);
  f (vertex1' t) (cedge12' t) (cedge14' t) (cedge11' t);
  f (vertex2 t) (cedge12 t) (cedge23 t) (cedge22' t);
  f (vertex2' t) (cedge12' t) (cedge23' t) (cedge22' t);
  f (vertex3 t) (cedge43 t) (cedge23 t) (cedge33' t);
  f (vertex3' t) (cedge43' t) (cedge23' t) (cedge33' t);
  f (vertex4 t) (cedge43 t) (cedge14 t) (cedge44' t);
  f (vertex4' t) (cedge43' t) (cedge14' t) (cedge44' t)

let iter_vertex_cube f t =
  f (vertex1 t) ;
  f (vertex1' t);
  f (vertex2 t) ;
  f (vertex2' t);
  f (vertex3 t) ;
  f (vertex3' t);
  f (vertex4 t) ;
  f (vertex4' t)

let print_edge e =
  open_hbox ();
  print_vector e.vertex1.cpos; print_space ();
  print_vector e.vertex2.cpos; print_newline ()

let print_face f =
  print_edge f.edge1;
  print_edge f.edge2;
  print_edge f.edge3;
  print_edge f.edge4;
  print_string "-"; print_newline ()

let print_cube c =
  print_face c.face1;
  print_face c.face2;
  print_face c.face3;
  print_face c.face4;
  print_face c.face5;
  print_face c.face6;
  print_newline ()

module Make_mesh =
  functor (P:Computing_parameter) -> 
    functor (F:Function) ->
struct
  
  open F
  open P

  let create_cvertex pos =
    let v = value pos in
    {
     cpos = pos;
     info = if v = 0.0 then Onsurface else Initial
   } 

  let mesh_on_vertex v =
    match v.info with
      Onsurface -> v.cpos
    | _ ->
	let sv = v.cpos in
	v.info <-  Onsurface;
	sv
	  
  let move_vertex v v' =
    v.cpos <- v'

  let xmin, ymin, zmin = 
    match let h = compute_size /. 2.0 in compute_origin -- [|h; h; h|] with
      [|xmin; ymin; zmin|] -> xmin, ymin, zmin
    | _ -> assert false

  let xmax, ymax, zmax = 
    match let h = compute_size /. 2.0 in compute_origin ++ [|h; h; h|] with
      [|xmax; ymax; zmax|] -> xmax, ymax, zmax
     | _ -> assert false
	
  let nb_sides = function
      [|x;y;z|] -> 
	(if x = xmin  || x = xmax then 1 else 0) +
	  (if y = ymin  || y = ymax then 1 else 0) +
	  (if z = zmin  || z = zmax then 1 else 0)
    | _ -> assert false

  let on_side p = nb_sides p > 0

  let same_sides p1 p2 = match p1, p2 with
    [|x;y;z|], [|x';y';z'|] ->
(*     let (=) x y = abs_float (x-.y) < 100.0*. min_float in *)
      (x = xmin) == (x' = xmin) &&
      (x = xmax) == (x' = xmax) &&
      (y = ymin) == (y' = ymin) &&
      (y = ymax) == (y' = ymax) &&
      (z = zmin) == (z' = zmin) &&
      (z = zmax) == (z' = zmax)
  |  _ -> assert false

  let count_cubes = ref 0

  let adjv e =
    let v1 = e.vertex1 and v2 = e.vertex2 in
    let size = norm (v2.cpos -- v1.cpos) in
    let f v =
      match v.info with
	Initial -> v.info <- Minsize size
      | Minsize s -> if size < s then v.info <- Minsize size
      | _ -> ()
    in
    f v1; f v2

  let set_status initial e =
    let v1 = e.vertex1 and v2 = e.vertex2 in
    match e.status with
      Divided _ -> ()
    | _ ->
	  match v1.info, v2.info with 
	  | Onsurface, Onsurface -> 
	      e.status <- Nothing
	  | _, Onsurface -> 
	      e.status <- Nothing 
	  | Onsurface, _ -> 
	      e.status <- Nothing 
	  | _ -> 
	      if initial then
		try
		  e.status <- Mesh_point (dighotomie v1.cpos v2.cpos)
		with
		  Not_found -> ()
 

  let create_edge v1 v2 =
(*
    print_string "creating edge: ";
    print_int v1.index;
    print_vector v1.cpos;
    print_int v2.index;
    print_vector v2.cpos;
*)
    let e = 
      { vertex1 = v1;
	vertex2 = v2;
	status = Nothing;
      }  
    in
    set_status true e;
    e

  let vertexes_moved = ref 0 

  let count_volume =
    let volume = compute_size *. compute_size *. compute_size in
    let done_volume = ref 0.0 in
    let previous_print = ref (-100) in
    let previous_cube = ref 0 in
    fun size -> begin
      done_volume := !done_volume +. size *. size *. size;
      let percent = int_of_float (!done_volume /. volume *. 100.0) in
      if percent - !previous_print >= 1 || !count_cubes - !previous_cube > 100
	then begin
	print_string "\r";
	print_int percent; print_string "% of space, ";
	print_int !count_cubes; print_string " cubes  ";	 
	print_flush ();
	previous_print := percent; previous_cube := !count_cubes;
      end
    end

  let do_count_cubes =
    let done_cubes = ref 0 in
    let previous_print = ref (-100) in
    fun () -> begin
      done_cubes := !done_cubes + 1;
      let percent = (100 * !done_cubes) / !count_cubes in
      if percent - !previous_print >= 1 then begin
	print_string "\r";
	print_int percent; print_string "% of cubes";
	print_flush ();
	previous_print := percent
      end
    end

  let create_face e1 e2 e3 e4 =
    {
     edge1 = e1; edge2 = e2; edge3 = e3; edge4 = e4; face_status = FNothing
   }

  let create_cube f1 f2 f3 f4 f5 f6 = 
    {
     face1 = f1;
     face2 = f2;
     face3 = f3;
     face4 = f4;
     face5 = f5;
     face6 = f6;
   }

  let create_init_cube v1 v2 v3 v4 v1' v2' v3' v4' =
    let edge12 = create_edge v1 v2 in
    let edge23 = create_edge v2 v3 in
    let edge43 = create_edge v4 v3 in
    let edge14 = create_edge v1 v4 in
    let edge12' = create_edge v1' v2' in
    let edge23' = create_edge v2' v3' in
    let edge43' = create_edge v4' v3' in
    let edge14' = create_edge v1' v4' in
    let edge11' = create_edge v1 v1' in
    let edge22' = create_edge v2 v2' in
    let edge33' = create_edge v3 v3' in
    let edge44' = create_edge v4 v4' in

    let face1 = create_face edge14 edge23 edge12 edge43 in
    let face2 = create_face edge14' edge23' edge12' edge43' in 
    let face3 = create_face edge14 edge14' edge11' edge44' in
    let face4 = create_face edge23 edge23' edge22' edge33' in
    let face5 = create_face edge12 edge12' edge11' edge22' in
    let face6 = create_face edge43 edge43' edge44' edge33' in

    create_cube face1 face2 face3 face4 face5 face6
 
  let add_to_undo p ul = match !ul with
    None -> ()
  | Some l -> ul:=Some (p::l)
      
  let do_undo ul = match !ul with
    None -> ()
  | Some l -> List.iter (fun f -> f ()) l

  let cancel_undo uls =
    List.iter (fun ul -> ul:=None) uls

  let undo_edge e ov () =
    e.status <- ov

  let divide_edge undo_list e =
    match e.status with
      Divided(e1,e2) -> e1,e1.vertex2,e2
    | _ ->
	let r = create_cvertex ((e.vertex1.cpos ++ e.vertex2.cpos) // 2.0) in
	let e1 = create_edge e.vertex1 r in
	let e2 = create_edge r e.vertex2 in
	let old_status = e.status in
	add_to_undo (undo_edge e old_status) undo_list;
	e.status <- Divided(e1,e2);
	e1,r,e2

  let undo_face f ov () =
    f.face_status <- ov

  let divide_face undo_list f =
    match f.face_status with
      FDivided(f1,f2,f3,f4) -> 
	f1,f2,f3,f4,f1.edge2.vertex2,f1.edge2,f3.edge3,f3.edge1,f1.edge4
    | _ ->
(*
	let v1,v2 = f.edge3.vertex1, f.edge3.vertex2 in
	let v3,v4 = f.edge4.vertex2, f.edge4.vertex1 in
*)
	let v1m12,m12,m12v2 = divide_edge undo_list f.edge3 in
	let v2m23,m23,m23v3 = divide_edge undo_list f.edge2 in
	let v1m14,m14,m14v4 = divide_edge undo_list f.edge1 in
	let v4m43,m43,m43v3 = divide_edge undo_list f.edge4 in

	let c = create_cvertex ((m12.cpos ++ m43.cpos) // 2.0) in

	let m12c = create_edge m12 c in
	let cm43 = create_edge c m43 in
	let m14c = create_edge m14 c in
	let cm23 = create_edge c m23 in

	let f1 = create_face v1m14 m12c v1m12 m14c in
	let f2 = create_face m12c v2m23 m12v2 cm23 in
	let f3 = create_face cm43 m23v3 cm23 m43v3 in
	let f4 = create_face m14v4 cm43 m14c v4m43 in
	let old_status = f.face_status in
        add_to_undo (undo_face f old_status) undo_list;

	f.face_status <- FDivided(f1,f2,f3,f4);
	f1,f2,f3,f4,c,m12c,cm23,cm43,m14c

  type cube_result =
      Cube of (int * int * cube)
    | Subdivided

	

  let adjust_pos factor vertex edges = try
    let min_size =
      match vertex.info with
        Minsize m -> m /. factor
      | _ -> raise Exit
    in 
    let onsurface v = match v.info with
      Onsurface -> true
    |_ -> false
    in
    if not (onsurface vertex) then 
    let on_side = on_side vertex.cpos in
    let d0,new_pos,old_pos= 
      match vertex.info with 
	Onsurfacetmp(old_pos) ->
	  norm (vertex.cpos -- old_pos), None, old_pos
      | _ -> 
	  try
            if not adjust_try_newton || on_side then raise Not_found;
	    let p0 = newton (10.0*.min_size) epsilon vertex.cpos in
	    let d = norm (vertex.cpos -- p0) in
	    if d > min_size /. 1.5 then raise Not_found else
	    d , Some p0, vertex.cpos 
	  with Not_found ->
	    min_size, None, vertex.cpos
    in
    let is_best (d,_ as r) e =
      match e.status with
	Mesh_point v ->
	  let nd = norm (vertex.cpos -- v) in
	  if nd < d &&  
	    (not on_side || same_sides vertex.cpos v) 
	  then (nd, Some v) else r
      |	Divided _ ->
	  assert false
      |	_ -> r
    in
    let (_, new_pos) = List.fold_left is_best (d0,new_pos) edges in
    match new_pos with
      None -> ()
    | Some v -> 
	  move_vertex vertex v;
	  incr vertexes_moved;
	  vertex.info <- Onsurfacetmp(old_pos);
  with Exit -> ()

  let root_at_vertex = ref [] 

  let add_end acc v =
    match v.info with
      Onsurface ->
	if not (List.memq v.cpos acc) then begin
	  root_at_vertex := v::!root_at_vertex;
	  v.cpos::acc 
	end else 
	  acc
    | Onsurfacetmp(_) ->
	if not (List.memq v !root_at_vertex) then begin
	  root_at_vertex := v::!root_at_vertex;
	end;
	acc
    | _ -> acc

  let min_size_cube = ref 0

  let rec look_for_all_roots' size acc e =
      match e.status with
        Mesh_point p -> 
	  if size > !min_size_cube then 
	    min_size_cube := size; 
	  if List.memq p acc then acc else p::acc
      | Nothing -> 
	  if size > !min_size_cube then 
	    min_size_cube := size; 
	  let acc = add_end acc (e.vertex1) in
	  let acc = add_end acc (e.vertex2) in
	  acc
      | Divided(e1,e2) ->
	  let size = size + 1 in
	  let acc = look_for_all_roots' size acc e1 in
	  look_for_all_roots' size acc e2

  let worstq = (1.0 +. sqrt 2.0) *. (Pervasives.( ** ) 2.0 (float max_division_diff)) *. sqrt(3.0) 

  let rec root_in_face size acc f =
    match f.face_status with
      FDivided(f1, f2, f3, f4) ->
	let size = size + 1 in
	let acc = root_in_face size acc f1 in
	let acc = root_in_face size acc f2 in
	let acc = root_in_face size acc f3 in
	let acc = root_in_face size acc f4 in
	acc
    | FNothing ->
	let acc = look_for_all_roots' size acc f.edge1 in
	let acc = look_for_all_roots' size acc f.edge2 in
	let acc = look_for_all_roots' size acc f.edge3 in
	let acc = look_for_all_roots' size acc f.edge4 in
	acc
    
  let root_in_cube c =
    min_size_cube := 0;
    let acc = root_in_face 0 [] c.face1 in
    let acc = root_in_face 0 acc c.face2 in
    let acc = root_in_face 0 acc c.face3 in
    let acc = root_in_face 0 acc c.face4 in
    let acc = root_in_face 0 acc c.face5 in
    let acc = root_in_face 0 acc c.face6 in
    let rv = !root_at_vertex in
    root_at_vertex := [];
    !min_size_cube, acc, rv

  let singularities = ref ([] : point list) 
  let nb_min_size = ref 0

  let all_cubes = ref []

  let map_divide_cube uls f (_,depth, t as c0) =
    let depth = depth + 1 in
(*
    print_string "splitting cube: ";
    print_int t.tv1.index;
    print_vector t.cv1.pos;
    print_int t.cv2.index;
    print_vector t.cv2.pos;
    print_int t.cv3.index;
    print_vector t.cv3.pos;
    print_int t.cv4.index;
    print_vector t.cv4.pos;
    print_newline ();
*)
    let ul = ref (if depth > min_depth then Some [] else None) in
    let f11,f12,f13,f14,c1,m12c1,c1m23,c1m43,m14c1 = divide_face ul t.face1 in
    let f21,f22,f23,f24,c2,m12'c2,c2m23',c2m43',m14'c2 = divide_face ul t.face2 in
    let f31,f32,f33,f34,c3,m11'c3,c3m14',c3m44',m14c3 = divide_face ul t.face3 in
    let f41,f42,f43,f44,c4,m22'c4,c4m23',c4m33',m23c4 = divide_face ul t.face4 in
    let f51,f52,f53,f54,c5,m11'c5,c5m12',c5m22',m12c5 = divide_face ul t.face5 in
    let f61,f62,f63,f64,c6,m44'c6,c6m43',c6m33',m43c6 = divide_face ul t.face6 in

    let cc = create_cvertex ((c1.cpos ++ c2.cpos) // 2.0) in

    let c1cc = create_edge c1 cc in
    let ccc2 = create_edge cc c2 in
    let c3cc = create_edge c3 cc in
    let ccc4 = create_edge cc c4 in
    let c5cc = create_edge c5 cc in
    let ccc6 = create_edge cc c6 in

    let n1f12 = create_face m11'c3 c5cc m11'c5 c3cc  in
    let n2f12 = create_face c5cc m22'c4 c5m22' ccc4 in
    let n3f12 = create_face ccc6 c4m33' ccc4 c6m33' in
    let n4f12 = create_face c3m44' ccc6 c3cc m44'c6 in

    let n1f34 = create_face m12c1 c5cc m12c5 c1cc in
    let n2f34 = create_face c5cc m12'c2 c5m12' ccc2 in
    let n3f34 = create_face ccc6 c2m43' ccc2 c6m43'  in
    let n4f34 = create_face c1m43 ccc6 c1cc m43c6 in

    let n1f56 = create_face m14c1 c3cc m14c3 c1cc in
    let n2f56 = create_face c3cc m14'c2 c3m14' ccc2 in
    let n3f56 = create_face ccc4 c2m23' ccc2 c4m23' in
    let n4f56 = create_face c1m23 ccc4 c1cc m23c4 in

	
    (* SHOULD KEEP KNOWN ROOTS ? *)
    let c1 = create_cube f11 n1f12 f31 n1f34 f51 n1f56 in
    let c2 = create_cube f12 n2f12 n1f34 f41 f54 n4f56 in
    let c3 = create_cube f13 n3f12 n4f34 f44 n4f56 f64 in
    let c4 = create_cube f14 n4f12 f34 n4f34 n1f56 f61 in
    let c5 = create_cube n1f12 f21 f32 n2f34 f52 n2f56 in
    let c6 = create_cube n2f12 f22 n2f34 f42 f53 n3f56 in
    let c7 = create_cube n3f12 f23 n3f34 f43 n3f56 f63 in
    let c8 = create_cube n4f12 f24 f33 n3f34 n2f56 f62 in
    count_cubes := !count_cubes + 7;
(*
    print_cube t;
    print_cube c1;
    print_cube c2;
    print_cube c3;
    print_cube c4;
    print_cube c5;
    print_cube c6;
    print_cube c7;
    print_cube c8;
*)
    let uls' = ul::uls in
    let r1 = f uls' depth c1 in
    let r2 = f uls' depth c2 in
    let r3 = f uls' depth c3 in
    let r4 = f uls' depth c4 in
    let r5 = f uls' depth c5 in
    let r6 = f uls' depth c6 in 
    let r7 = f uls' depth c7 in
    let r8 = f uls' depth c8 in
    try
      let fn (roots,ms) = function
	  Subdivided -> raise Exit
	| Cube((depth,nb_roots,t)) ->
	    let ns,nr,_ = root_in_cube t in
	    unionq nr roots, max ms ns
      in
      let all_roots, mdiv =
	fn (fn (fn (fn (fn (fn (fn (fn ([],0) r1) r2) r3) r4) r5) r6) r7) r8 
      in
      let l = List.map (fun p -> p, grad p) all_roots in 
      let v1 = vertex1 t in
      let v2 = vertex2 t in
      let v3 = vertex3 t in
      let v4 = vertex4 t in
      let v1' = vertex1' t in
      let v2' = vertex2' t in
      let v3' = vertex3' t in
      let v4' = vertex4' t in
      let vertices = [v1;v3';v2;v3;v4;v1';v2';v4'] in
      let vertices =
	List.map (fun v -> 0.0, v.cpos, grad v.cpos) vertices in

      if depth <= min_depth || 
	mdiv > max_division_diff - 1 || keep_split_cond vertices l 
      then raise Exit;
      do_undo ul;
      count_cubes := !count_cubes - 7; 
      Cube c0
    with
      Exit ->
	let gn = function
	    Subdivided -> ()
	  | Cube(nb,_,_ as c) -> all_cubes:=c::!all_cubes
	in
	gn r1; gn r2; gn r3; gn r4; gn r5; gn r6; gn r7; gn r8;
	cancel_undo uls;
	Subdivided    

  let rec check_cube uls (min_roots, depth, t as t0) =
    let mdiv, roots, _ = root_in_cube t in
    let nb_roots = List.length roots in
    let v1 = vertex1 t in
    let v2 = vertex2 t in
    let size = norm (v1.cpos -- v2.cpos) in
    if nb_roots <= min_roots then begin
      count_volume size;
      Cube t0
    end else
    let v3 = vertex3 t in
    let v4 = vertex4 t in
    let v1' = vertex1' t in
    let v2' = vertex2' t in
    let v3' = vertex3' t in
    let v4' = vertex4' t in
(*
    print_vector v1.cpos; print_string ", ";
    print_vector v3'.cpos; print_newline ();
*)
    let vertices = [v1;v3';v2;v3;v4;v1';v2';v4'] in
    let max_depth = size /. 2.0 < min_size in
    if depth <= min_depth || 
      (not max_depth && 
       ((mdiv > max_division_diff && roots != []) || 
	let vertices =
	  List.map (fun v -> value v.cpos, v.cpos, grad v.cpos) vertices in
	let roots = List.map (fun v -> 0.0, v, grad v) roots in
	split_cond vertices roots))
    then begin
      map_divide_cube uls (fun uls d c -> check_cube uls (-1,d, c)) t0
    end else begin
      if max_depth then incr nb_min_size;
      count_volume size;
      if nb_roots > min_roots then 
	begin
	  (*
	  let rec no_Mesh_point v e =
	    match e.status with 
	      Mesh_point _ -> false
	    | Divided v' -> no_Mesh_point v (get_edge v v')
	    | _ -> true
	  in
	  let f v e1 e2 e3 =
	    match v.info with
	      Onsurface -> ()
	    | _ -> 
		if no_Mesh_point v e1 && 
		  no_Mesh_point v e2 && 
		  no_Mesh_point v e3 
		then
		  v.info <- Minsize 0.0
	  in
	  iter_vertex_edges_cube f t;
	     *)
	  Cube (nb_roots,depth,t);
	end
      else
	begin
	  Cube t0
	end
    end

  let rec reach_fixpoint () =
    print_string "\rTrying to reach fixpoint (";
    print_int !count_cubes; print_string " cubes).       ";
    print_newline ();
    let found_new = ref false in
    let check_one c =
      let r = check_cube [] c in 
      match r with
	Subdivided -> 
	  found_new := true;
      | Cube(c) -> 
	  all_cubes := c::!all_cubes
    in
    List.iter check_one (get_reset all_cubes);
    print_string "\r";
    if !found_new then reach_fixpoint () else begin
      print_string "Fixpoint reached (";
      print_int !count_cubes; print_string " cubes).       ";
      print_newline ();
    end

  let iter_all_edges f =
    List.iter (fun (_,_,c) -> iter_edges_cube f c) !all_cubes 

  let adjust_all () =
    Pervasives.print_string "."; flush stdout;
    iter_all_edges adjv;

    Pervasives.print_string "."; flush stdout;
    let gn e = 
      match e.status with 
	Mesh_point _ -> 
	  adjust_pos adjust_factor e.vertex1 [e];
	  adjust_pos adjust_factor e.vertex2 [e]
      | _ -> 
	  ()
    in
    iter_all_edges gn;

    Pervasives.print_string "."; flush stdout;
    let check_cube (_, _, t) =
      let _, roots, rv = root_in_cube t in
      let roots = ref (List.map (fun v -> (v, grad v)) roots) in
      let rv = List.filter (fun v1 ->
	match v1.info with 
	  Onsurfacetmp(op1) -> true
	| _ -> false) rv
      in
      let rv = List.sort (fun v1 v2 ->
	match v1.info, v2.info with 
	  Onsurfacetmp(op1), Onsurfacetmp(op2) ->
	    compare (norm (v1.cpos -- op1)) (norm (v2.cpos -- op2))
	| _ -> 
	    assert false) rv 
      in

      let fn v =
	match v.info with Onsurfacetmp(op) ->
	  begin
	    let g = grad v.cpos in
            let check (v',g') =
	      if angle g g' >= adjust_angle then raise Exit
	    in
	    try
	      List.iter check !roots;
	      roots := (v.cpos,g)::!roots;
	    with
	      Exit -> 
		v.info <- Initial; v.cpos <- op
	  end
	| _ -> 
	    ()
      in
      List.iter fn rv
    in
    List.iter check_cube !all_cubes;
    Pervasives.print_string "."; flush stdout;
    let kn v = 
      match v.info with 
	Onsurfacetmp _ -> v.info <- Onsurface 
      | _ -> ()
    in

    iter_all_edges (fun e -> kn e.vertex1; kn e.vertex2; set_status false e);
    Pervasives.print_string "."; flush stdout


  let collect_polygones prev_pols (_,_,c) =
    let debug = match !target with
      None -> false
    | Some p -> in_cube (vertex1 c).cpos (vertex3' c).cpos p
    in
    let pairs = ref [] and pos_pairs = ref [] and neg_pairs = ref [] in
    if debug then begin print_string "start cube"; print_newline () end;
    let rec collect_pair_in_face f =
      match f.face_status with
	FDivided(f1,f2,f3,f4) ->
	  collect_pair_in_face f1;
	  collect_pair_in_face f2;
	  collect_pair_in_face f3;
	  collect_pair_in_face f4;
      |  _ -> try
      let init = ref false in
      let firsts = ref [] in
      let sequences = ref [] in
      let collect acc =
	if debug then print_string "collect: ";
	if !init then begin
	  if debug then begin print_string "add sequence"; print_newline () end;
	  if acc <>  [] then sequences := acc::!sequences;
	end else begin
	  firsts := acc;
	  init := true;
	end;
      in
      let add_None = function
	  Some _::_ | [] as l -> None::l
	| l -> l
      in
      let fvalue p =
	match p.info with
	  Onsurface -> 0.0
	| _ -> value p.cpos
      in
      let rec look_for_all_roots acc dir e =
	let v1, v2 = if dir then 
	  e.vertex1, e.vertex2 else e.vertex2,e.vertex1 in 
	let fv2 = fvalue v2 in
	match e.status with  
          Mesh_point p -> 
	    if debug then begin 
	      open_hbox ();
	      print_vector p; print_float 0.0; print_newline ();
	    end;
	    let acc = Some p::acc in
	    begin
	      match v2.info with 
		Onsurface -> Some v2.cpos::acc 
	      | _ -> if fv2 < 0.0 then (collect acc; []) else add_None acc
	    end
	| Nothing -> 
	    begin
	      match v2.info with 
		Onsurface -> Some v2.cpos::acc 
	      | _ -> if fv2 < 0.0 then (collect acc; []) else add_None acc
	    end
	| Divided(e1,e2) ->
	    if dir then begin
	      let acc = look_for_all_roots acc dir e1 in
	      look_for_all_roots acc dir e2
	    end else begin	    
	      let acc = look_for_all_roots acc dir e2 in
	      look_for_all_roots acc dir e1
	    end
      in
      if debug then begin print_string "start face"; print_newline () end;
      if fvalue f.edge3.vertex1 < 0.0 then collect [];
      let roots = look_for_all_roots [] true f.edge3 in
      let roots = look_for_all_roots roots true f.edge2 in
      let roots = look_for_all_roots roots false f.edge4 in
      let roots = look_for_all_roots roots false f.edge1 in
      let roots = !firsts@roots in
      if !init then collect roots else begin
	let first = match roots with
	  Some x::_ -> Some x
	| _ -> None
	in
	let rec collect_pos = function
	    Some x::(Some y::_ as l) ->
	      if debug then begin 
		print_string "pos_pair: ";
		print_vector x; print_vector y; print_newline ();
	      end;
	      pos_pairs := (x,y)::!pos_pairs; 
	      collect_pos l
	  | None::l | Some _::None::l ->
	      collect_pos l
	  | [Some y]  -> 
	      begin
		match first with
		  Some x when x != y -> 
		    if debug then begin 
		      print_string "pos_pair: ";
		      print_vector x; print_vector y; 
		      print_newline ();
		    end;
		    pos_pairs := (x,y)::!pos_pairs; 
		| _ -> ()
	      end
	  | [] -> ()
	in
	collect_pos roots
      end;
      if debug then begin 
	print_int (List.length !sequences); 
	print_newline () 
      end;
      let rec split acc ld = function
	  [] -> ld::acc
	| None::ls -> split (if ld <> [] then ld::acc else acc) [] ls
	| Some x::ls -> split acc (x::ld) ls
      in
      if !sequences = [] then raise Not_found;
      let rec last = function
	  [x] -> x
	| x::l -> last l
	| _ -> assert false
      in
      let mesure x1 x2 l1 ls =
	match l1 with [] -> 0.0, x1, x2, 0.0, 0.0 (*assert false*) | x3::l ->
	let a = match x1, x2 with
	  Some x1', Some x2' ->
	    angle (x3 -- x2') (x2' -- x1') 
	| _ -> 0.0
	in
	let a, a1, a2 = match x2, l, ls with
	  Some x2', (x4::_), _ ->
	    a +. angle (x4 -- x3) (x3 -- x2'), 0.0, 0.0
	| Some x2', [], ([x4]::_) ->
	    a +. angle (x4 -- x3) (x3 -- x2'), 0.0, 0.0
	| Some x2', [], ((x4::l):: _) ->
	    let x5 = last l in
	    a,
	    angle (x4 -- x3) (x3 -- x2'),
	    angle (x5 -- x3) (x3 -- x2')
	| _ -> 
	    a, 0.0, 0.0
	in  
	match List.rev l with
	  [] -> a, x2, Some x3, a1, a2
	| [x4] -> a, Some x3, Some x4, a1, a2
	| x5::x4::_ -> a, Some x4, Some x5, a1 , a2
      in
      let rec group x1 x2 a1 a2 acc cur res best = function
	| l::ls -> 
	    let l' = List.rev l in
	    let mes,nx1,nx2, na1, na2 = mesure x1 x2 l ls in
	    let ncur = mes +. cur +. a1 in
	    let res, best = 
	      if ncur +. min na1 na2 < best then 
		group nx1 nx2 na1 na2 ((l',true)::acc) ncur res best ls 
	      else res, best
	    in
	    if List.length l = 1 then res, best else
	    let mes,nx1,nx2,na1,na2 = mesure x1 x2 l' ls in
	    let ncur = mes +. cur +. a2 in
	    if ncur +. min na1 na2 < best then 
	      group nx1 nx2 na1 na2 ((l,false)::acc) ncur res best ls 
	    else res, best
	| [] ->
	    acc, cur
      in
      let seq = List.map (split [] []) !sequences in
      let seq = List.map (fun l -> fst (group None None 0.0 0.0 [] 0.0 [] max_float l))
	  seq in
      let rec collect_pairs = function 
	  ((x::(y::_ as l)), true)::seq ->
	    if debug then begin 
	      print_string "neg_pair: ";
	      print_vector x; print_vector y; print_newline ();
	    end;
	    neg_pairs := (x,y)::!neg_pairs;
	    collect_pairs ((l,true)::seq)
	|((x::(y::_ as l)), false)::seq ->
	    if debug then begin 
	      print_string "pos_pair: ";
	      print_vector x; print_vector y; print_newline ();
	    end;
	    pos_pairs := (x,y)::!pos_pairs;
	    collect_pairs ((l,false)::seq)
	| ([x], _)::(((y::_),_)::_ as seq) ->
	    if debug then begin 
	      print_string "pair: ";
	      print_vector x; print_vector y; print_newline ();
	    end;
	    pairs := (x,y)::!pairs;
	    collect_pairs seq
	| [([_],_)] -> 
	    ()
	| _ ->
	    () (* assert false*)
      in
      List.iter collect_pairs seq;
    with Not_found -> 
      ()
  in
  if debug then begin print_string "face1"; print_newline () end;
  collect_pair_in_face c.face1;
  if debug then begin print_string "face2"; print_newline () end;
  collect_pair_in_face c.face2;
  if debug then begin print_string "face3"; print_newline () end;
  collect_pair_in_face c.face3;
  if debug then begin print_string "face4"; print_newline () end;
  collect_pair_in_face c.face4;
  if debug then begin print_string "face5"; print_newline () end;
  collect_pair_in_face c.face5;
  if debug then begin print_string "face6"; print_newline () end;
  collect_pair_in_face c.face6;
  if debug then begin print_string "endfaces"; print_newline () end;

  let rec select pairs pos neg =
    match pos with
      [] -> pairs
    | (x,y as p)::pos ->
	assert (x != y);
	if List.exists (fun (x', y') ->
	  (x == x' && y == y') || (x == y' && y == x')) neg then 
	  begin
	    if debug then begin 
	      print_string "pair: ";
	      print_vector x; print_vector y; print_newline ();
	    end;
	    select (p::pairs) pos neg 
	  end 
	else
	  select pairs pos neg
  in
  let pairs = select !pairs !pos_pairs !neg_pairs in
  let rec make_polygones pols l0 pairs =
    match pairs with
      [] -> pols
    | _ ->
    let l0, r, pairs = match l0, pairs with
      (r::l0, _) -> l0, r, pairs
    | [], (r,r')::l -> [r], r', l
    | _ -> assert false
    in
    let rec search acc r = function
	[] -> raise Not_found
      | (r1,r2)::l when r1 == r -> r2, (List.rev acc)@l
      | (r1,r2)::l when r2 == r -> r1, (List.rev acc)@l
      | p::l -> search (p::acc) r l
    in
    let rec search_end acc r = function
	[] -> raise Not_found
      | [r'] when r == r' -> r::acc, []
      | r'::_ as l when r == r' -> r::acc, l
      | r'::l -> search_end (r'::acc) r l
    in
    let rec fn acc r pairs =
      try 
	let p, l0 = search_end [] r acc in
	p, l0, pairs
      with Not_found -> try
	let r', pairs = search [] r pairs in
	fn (r::acc) r' pairs
      with Not_found ->
	(* assert false; *)
	match acc with
	  [] -> [], [], pairs
	| r::acc -> fn acc r pairs 
    in
    let p, l0, pairs = fn l0 r pairs in
    make_polygones (if p <> [] then p::pols else pols) l0 pairs
  in
  let polygones = make_polygones [] [] pairs in
  let r = triangles_from_polygones prev_pols polygones in
  do_count_cubes ();
  r

(*
  let show_cube_edges () =
    let fn e =
      match e.status with Divided _ -> () | _ ->
	let v1 = e.vertex1 and v2 = e.vertex2 in
	  GlDraw.vertex ~x:v1.cpos.(0) ~y:v1.cpos.(1) ~z:v1.cpos.(2)();
	  GlDraw.vertex ~x:v2.cpos.(0) ~y:v2.cpos.(1) ~z:v2.cpos.(2)()
    in
   let gllist = GlList.create `compile in
   GlDraw.begins `lines;
   iter_all_edges fn;

   GlDraw.ends ();
   GlList.ends ();
   cube_edges := Some gllist
*)

  module Cache = Cache.Make(P)

  let build_mesh () = 
    try Cache.read [F.f]
    with Not_found -> 
    let h = compute_size /. 2.0 in
    let c1 = create_cvertex (compute_origin -- [|-.h;-.h;-.h|]) in
    let c2 = create_cvertex (compute_origin -- [|  h;-.h;-.h|]) in
    let c3 = create_cvertex (compute_origin -- [|  h;  h;-.h|]) in
    let c4 = create_cvertex (compute_origin -- [|-.h;  h;-.h|]) in
    let c1' = create_cvertex (compute_origin -- [|-.h;-.h;  h|]) in
    let c2' = create_cvertex (compute_origin -- [|  h;-.h;  h|]) in
    let c3' = create_cvertex (compute_origin -- [|  h;  h;  h|]) in
    let c4' = create_cvertex (compute_origin -- [|-.h;  h;  h|]) in
    let init_cube = create_init_cube c1 c2 c3 c4 c1' c2' c3' c4' in
    print_string "Phase 1: searching cubes.";
    print_newline ();
    let _ = check_cube [] (-1, 1, init_cube) in
    count_cubes := List.length !all_cubes;
    reach_fixpoint ();
    print_string "Phase 2: adjusting vertices.                              ";
    print_newline ();
    adjust_all (); 
    print_int !vertexes_moved;
    print_string " vertices moved.";
    print_newline (); 
(*    show_cube_edges ();  *)
    print_string "Phase 3: collecting triangles.                            ";
    print_newline ();
    let r = List.fold_left collect_polygones [] (get_reset all_cubes) in
    print_string "\r";
    print_int (List.length r); 
    print_string " triangles collected.                                     "; 
    print_newline ();
    if !singularities <> [] then begin
      print_int (List.length !singularities); 
      print_string " points collected.";
      print_newline ();
    end;
    let r = 
      if flip then begin
	print_string "Phase 4: flipping edges                                    ";
	print_newline ();
	Triangulation_tools.flip_diagonals grad r 
      end else r
    in
    if !nb_min_size <> 0 then begin
      print_string "Warning: minsize reached: ";
      print_int !nb_min_size;
      print_string " times.";
      print_newline ();
    end;
    print_string "Finished: sending to openGL.";
    print_newline ();    
    let result = r, [], !singularities in
    Cache.write [F.f] result;
    result
end
