(**************************************************************************)
(*                                                                        *)
(*                               GlSurf                                   *)
(*                                                                        *)
(*                   C. Raffalli, Universite de Savoie                    *)
(*                                                                        *)
(* Copyright 2003, 2004 Christohe Raffalli                                *)
(*                                                                        *)
(*  This file is part of GlSurf.                                          *)
(*                                                                        *)
(*  GlSurf is free software; you can redistribute it and/or modify        *)
(*  it under the terms of the GNU General Public License as published by  *)
(*  the Free Software Foundation; either version 2 of the License, or     *)
(*  (at your option) any later version.                                   *)
(*                                                                        *)
(*  GlSurf is distributed in the hope that it will be useful,             *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *)
(*  GNU General Public License for more details.                          *)
(*                                                                        *) 
(*  You should have received a copy of the GNU General Public License     *)
(*  along with GlSurf; if not, write to the Free Software                 *)
(*  Foundation, Inc., 59 Temple Place, Suite 330, Boston,                 *)
(*  MA  02111-1307  USA                                                   *)
(**************************************************************************)

open Format
open Algebra
open Vect3
open Function

type point_def =
  { 
     point_pos : point;
     point_expr : Expr.elem;
  } 

type line_def =
  { 
     line_pos : point;
     line_expr : Expr.elem;
     line_dir  : vector;
  } 

type plane_def =
  { 
     plane_pos : point;
     plane_expr : Expr.elem;
     plane_normal  : vector;
  } 

type line_constructions =
    Line_Coord of point * point
  | Line_Dir of point * vector
  | Line_Plane_inter of plane_def * plane_def

type plane_constructions =
    Plane_Coord of point * point * point
  | Plane_Normal of point * vector

type point_constructions =
    Point_Coord of point
  | Point_Line_inter of plane_def * line_def  
  | Point_Plane_inter of plane_def * plane_def * plane_def

let construct_plane construction =
  let (x,y,z as p), (x0,y0,z0 as n) = 
    match construction with
      Plane_Coord(p1,p2,p3) ->
	let n = vector_prod (p2 -- p1) (p3 -- p1) in
	p1, n // norm n
    | Plane_Normal(p,n) ->
	p, n
  in
  let exp =
    Expr.Add (Expr.Mul (Expr.Sub (Expr.Var "x") (Expr.Cst x)) (Expr.Cst x0)) 
      (Expr.Add (Expr.Mul (Expr.Sub (Expr.Var "y") (Expr.Cst y)) (Expr.Cst y0)) 
	 (Expr.Mul (Expr.Sub (Expr.Var "z") (Expr.Cst z)) (Expr.Cst z0)))
  in
  { plane_pos = p; plane_normal = n; plane_expr = exp}

let construct_line construction =
  let (x,y,z as p), (x0,y0,z0 as d) =
    match construction with
      Line_Coord(p1,p2) ->
	let d = p2 -- p1 in
	p1, d // norm d
    | Line_Dir(p,n) ->
	p, n
    | Line_Plane_inter(p1, p2) ->
	let d = vector_prod p1.plane_normal p2.plane_normal in
	let dp = vector_prod d p1.plane_normal in
	let a = dp || (p2.plane_pos -- p1.plane_pos) in
        let p = p1.plane_pos ++ a**dp in
	p, d
  in
  let x' = Expr.Sub (Expr.Var "x") (Expr.Cst x) and x0 = Expr.Cst x0 in
  let y' = Expr.Sub (Expr.Var "y") (Expr.Cst y) and y0 = Expr.Cst y0 in
  let z' = Expr.Sub (Expr.Var "z") (Expr.Cst z) and z0 = Expr.Cst z0 in
  let exp = 
    Expr.Add (Expr.Pow(Expr.Sub (Expr.Mul x' y0) (Expr.Mul y' x0), 2))
	  (Expr.Add (Expr.Pow(Expr.Sub (Expr.Mul y' z0) (Expr.Mul z' y0), 2))
	     (Expr.Pow(Expr.Sub (Expr.Mul z' x0) (Expr.Mul x' z0), 2)))
  in
  { line_pos = p; line_dir = d; line_expr = exp}
    
let rec construct_point construction =
  let (x,y,z as p) =
    match construction with
      Point_Coord p -> p
    | Point_Line_inter (p , l) ->
	let a = l.line_dir || (p.plane_pos -- l.line_pos) in
	l.line_pos ++ a**l.line_dir
    | Point_Plane_inter (p1 , p2 , p) ->
	let l = construct_line (Line_Plane_inter(p1, p2)) in
	let a = l.line_dir || (p.plane_pos -- l.line_pos) in
	l.line_pos ++ a**l.line_dir
  in
  let x' = Expr.Sub (Expr.Var "x") (Expr.Cst x) in
  let y' = Expr.Sub (Expr.Var "y") (Expr.Cst y) in
  let z' = Expr.Sub (Expr.Var "z") (Expr.Cst z) in
  let exp = 
    Expr.Add (Expr.Pow(x', 2))
	  (Expr.Add (Expr.Pow(y', 2))
	     (Expr.Pow(z', 2)))
  in
  { point_pos = p; point_expr = exp}  

