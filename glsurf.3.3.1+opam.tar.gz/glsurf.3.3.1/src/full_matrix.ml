open Format
open Input_util
open Algebra
open Vector
open Matrix



(* Full matrix implementation : *)


module Make =
  functor (R:Ring) ->
  functor (Domain:Vector with type scalar = R.elem) ->
  functor (Image:Vector with type scalar = R.elem) ->
struct
  type scalar = R.elem
  type argument = Domain.elem
  type result = Image.elem

  let columns = Domain.dim
  let lines = Image.dim
  module D = struct
    let dim = columns * lines
  end
  let dim = columns * lines

  type elem = scalar array array

  let create init =
    let m = Array.make_matrix lines columns R.zero in
    let g i j v = m.(j).(i) <- v in
    init g;
    m

  let vcreate init =
    let m = Array.make_matrix lines columns R.zero in
    let g k v =
      let i = k mod columns in
      let j = k / columns in
      m.(j).(i) <- v in
    init g;
    m

  let null () =
    Array.make_matrix lines columns R.zero

  let copy m =
    let r = Array.make lines [| |] in
    for j = 0 to lines-1 do
      r.(j) <- Array.copy m.(j)
    done;
    r

  let apply m v =
    Image.vcreate
      (fun fn ->
	 for j = 0 to lines - 1 do
	   let r = ref R.zero in
	   for i = 0 to columns - 1 do
             r := R.(++) !r (R.( ** ) m.(j).(i) (Domain.vget v i))
	   done;
	   fn j !r
         done)

  let tapply v m =
    Domain.vcreate
      (fun fn ->
	 for i = 0 to columns - 1 do
	   let r = ref R.zero in
	   for j = 0 to lines - 1 do
	     r := R.(++) !r (R.( ** ) (R.conjugate m.(j).(i)) (Image.vget v j))
	   done;
	   fn i !r
         done)

  let get m i j =
    m.(j).(i)

  let vget m k =
    let i = k mod columns in
    let j = k / columns in
    m.(j).(i)

  let put m i j value =
    m.(j).(i) <- value

  let vput m k x =
    let i = k mod columns in
    let j = k / columns in
    m.(j).(i) <- x

  let sub m1 m2 =
    for i = 0 to columns-1 do
      for j = 0 to lines-1 do
	m1.(j).(i) <- R.(--) m1.(j).(i) m2.(j).(i)
      done
    done

  let add m1 m2 =
    for i = 0 to columns-1 do
      for j = 0 to lines-1 do
	m1.(j).(i) <- R.(++) m1.(j).(i) m2.(j).(i)
      done
    done

  let (++) (m1 : elem) (m2 : elem) =
    let r = copy m1 in
    add r m2;
    r

  let (--) (m1 : elem) (m2 : elem) =
    let r = copy m1 in
    sub r m2;
    r


  let (==) m1 m2 =
    try
      for i = 0 to lines-1 do
	for j = 0 to columns-1 do
	  if not (R.(==) m1.(i).(j) m2.(i).(j)) then raise Exit
	done
      done;
      true
    with Exit -> false

  let mul_scal x m =
    for i = 0 to lines-1 do
      for j = 0 to columns-1 do
	m.(i).(j) <- R.( ** ) x  m.(i).(j)
      done
    done

  let (@) x m = Array.map (Array.map (fun y -> R.( ** ) x y)) m

  let write formatter p =
    pp_print_string formatter "[";
    pp_open_hvbox formatter 2;
    pp_print_int formatter columns;
    pp_print_string formatter "x";
    pp_print_int formatter lines;
    pp_print_string formatter ":";
    for j=0 to lines-1 do
      if j <> 0 then pp_print_string formatter ",";
      pp_print_space formatter ();
      pp_print_string formatter "[";
      pp_open_box formatter 2;
      for i= 0 to (columns-1) do
	if i <> 0 then pp_print_string formatter ",";
	pp_print_space formatter ();
	R.write formatter p.(j).(i);
      done;
      pp_close_box formatter ();
      pp_print_string formatter "]";
    done;
    pp_close_box formatter ();
    pp_print_cut formatter ();
    pp_print_string formatter "]"

  let print = write std_formatter

  let parse str = failwith "not implemented"

  let read ch = parse (Stream.of_channel ch)

  let write_bin = output_value

  let read_bin = input_value

  let normalize m = Array.map (Array.map R.normalize) m

  let map fn m =
    let init f =
      for i = 0 to lines-1 do
	for j = 0 to columns-1 do
	  f i j (fn m.(i).(j))
	done
      done in
    create init

  let map2 fn m1 m2 =
    let init f =
      for i = 0 to lines-1 do
	for j = 0 to columns-1 do
	  f i j (fn m1.(i).(j) m2.(i).(j))
	done
      done in
    create init

  let mapq fn m =
      for i = 0 to lines-1 do
	for j = 0 to columns-1 do
	  m.(i).(j) <- fn m.(i).(j)
	done
      done

  let mapq2 fn m1 m2 =
      for i = 0 to lines-1 do
	for j = 0 to columns-1 do
	  m1.(i).(j) <- fn m1.(i).(j) m2.(i).(j)
	done
      done

  let init_null m =
      for i = 0 to lines-1 do
	for j = 0 to columns-1 do
	  m.(i).(j) <- R.zero
	done
      done

  let opp m = (R.opp R.one) @ m

  let zero = null ()

  let conjugate v = map R.conjugate v
end

module Make_Square =
  functor (R:Ring) ->
  functor (Domain:Vector with type scalar = R.elem) ->
struct
  module M = Make(R)(Domain)(Domain)

  module D = M.D

  type elem = M.elem
  type scalar = M.scalar
  type argument = M.argument
  type result = M.result

  let columns = M.columns
  let lines = M.lines
  let dim = M.dim

  let create = M.create
  let vcreate = M.vcreate
  let null = M.null
  (*     let init_null = matrix ->unit*)
  let copy = M.copy
  let apply = M.apply
  let tapply = M.tapply
  let mul_scal = M.mul_scal

  let get = M.get
  let put = M.put
  let vget = M.vget
  let vput = M.vput
  let sub = M.sub
  let add = M.add
  let (++) = M.(++)
  let (--) = M.(--)
  let (@) = M.(@)
  let (==) = M.(==)
  let print = M.print
  let parse = M.parse
  let read = M.read
  let write = M.write
  let read_bin = M.read_bin
  let write_bin = M.write_bin
  let normalize = M.normalize
  let map = M.map
  let map2 = M.map2
  let mapq = M.mapq
  let mapq2 = M.mapq2
  let init_null = M.init_null
  let opp = M.opp
  let zero= M.zero
  let conjugate = M.conjugate
  module P = Product(R)(M)(M)(M)

  let ( ** ) = P.( ** )

  let t_of_int n =
    let n = R.t_of_int n in
    let init f =
      for i = 0 to lines - 1 do
	f i i n
      done
    in
    create init

  let one = t_of_int 1

end


module Make_Symmetric =
  functor (R:Ring) ->
  functor (Domain:Vector with type scalar = R.elem) ->
struct
  module M = Make(R)(Domain)(Domain)

  module D = M.D

  type elem = M.elem
  type scalar = M.scalar
  type argument = M.argument
  type result = M.result

  let columns = M.columns
  let lines = M.lines
  let dim = M.dim

  let create init =
    let m = Array.make lines [||] in
    for j = 0 to lines-1 do
      m.(j) <- Array.make (j+1) R.zero
    done;
    let g i j v =
      if j >= i
      then m.(j).(i) <- v
      else m.(i).(j) <- R.conjugate v in
    init g;
    m

  let vcreate init =
    let m = Array.make_matrix lines columns R.zero in
    let g k v =
      let i = k mod columns in
      let j = k / columns in
      if j >= i then m.(j).(i) <- v else m.(i).(j) <- R.conjugate v in
    init g;
    m

  let null ()=
    let m = Array.make lines [||] in
    for j = 0 to lines-1 do
      m.(j)<- Array.make (j+1) R.zero
    done;
    m

  let get m i j =
    if (j >= i) then
      m.(j).(i)
    else
      R.conjugate m.(i).(j)

  let vget m k =
    let i = k mod columns in
    let j = k / columns in
    if (j >= i) then
      m.(j).(i)
    else
      R.conjugate m.(i).(j)

  let put m i j x =
    if (j >= i) then
      m.(j).(i) <- x
    else
      m.(i).(j) <- R.conjugate x

  let vput m k x =
    let i = k mod columns in
    let j = k / columns in
    if (j >= i) then
      m.(j).(i) <- x
    else
      m.(i).(j) <- R.conjugate x

  let copy m =
    let r = Array.make lines [||] in
      for j =0 to (lines-1) do
	r.(j)<- Array.copy m.(j)
      done;
      r

  let apply m v =
    Domain.vcreate( fun fn ->
	for j=0 to columns-1 do
	  let r = ref R.zero in
	    for i = 0 to j do
	      r:= R.(++) !r (R.( ** ) m.(j).(i) (Domain.vget v i))
	    done;
	    for i = j+1 to lines-1 do
	      r:= R.(++) !r (R.( ** ) (R.conjugate m.(i).(j)) (Domain.vget v i))
	    done;
	    fn j !r
	done)

  let tapply v m = apply m v

  let sub m1 m2 =
    for j = 0 to lines-1 do
      for i = 0 to j do
	m1.(j).(i) <- R.(--) m1.(j).(i) m2.(j).(i)
      done
    done

  let add m1 m2 =
    for j = 0 to lines-1 do
      for i = 0 to j do
	m1.(j).(i) <- R.(++) m1.(j).(i) m2.(j).(i)
      done
    done

  let mul_scal x m =
    for j = 0 to lines-1 do
      for i = 0 to j do
	m.(j).(i) <- R.( ** ) x  m.(j).(i)
      done
    done

  let (++) (m1 : elem) (m2 : elem) =
    let r = copy m1 in
      add r m2;
      r

  let (--) (m1 : elem) (m2 : elem) =
    let r = copy m1 in
      sub r m2;
      r

  let (@) = M.(@)

  let (==) m1 m2 =
    try
      for i = 0 to lines-1 do
	for j = 0 to i do
	  if not (R.(==) m1.(i).(j) m2.(i).(j)) then raise Exit
	done
      done;
      true
    with Exit -> false

  let mul_scal x m =
    for j = 0 to lines-1 do
      for i = 0 to j do
	m.(j).(i) <- R.( ** ) x  m.(j).(i)
      done
    done

  let write formatter p =
    pp_print_string formatter "[";
    pp_open_hvbox formatter 2;
    pp_print_int formatter columns;
    pp_print_string formatter "x";
    pp_print_int formatter lines;
    pp_print_string formatter ":";
    for j=0 to lines-1 do
      if j <> 0 then pp_print_string formatter ",";
      pp_print_space formatter ();
      pp_print_string formatter "[";
      pp_open_box formatter 2;
      for i= 0 to j do
	if i <> 0 then pp_print_string formatter ",";
	pp_print_space formatter ();
	R.write formatter p.(j).(i);
      done;
      if j <> lines-1 then begin
	pp_print_string formatter ",";
	pp_print_space formatter ();
	pp_print_string formatter "%";
	pp_print_int formatter (lines-j-1);
      end;
      pp_close_box formatter ();
      pp_print_string formatter "]";
    done;
    pp_close_box formatter ();
    pp_print_cut formatter ();
    pp_print_string formatter "]"


  let print = write std_formatter

  let put m indl indc value =
    m.(indc).(indl) <- value

  let parse str = failwith "not implemented"

  let read ch = parse (Stream.of_channel ch)

  let read_bin = M.read_bin
  let write_bin = M.write_bin
  let normalize = M.normalize

  let map fn m =
    let init f =
      for i = 0 to lines-1 do
	for j = 0 to i do
	  f i j (fn m.(i).(j))
	done
      done in
    create init

  let map2 fn m1 m2 =
    let init f =
      for i = 0 to lines-1 do
	for j = 0 to i do
	  f i j (fn m1.(i).(j) m2.(i).(j))
	done
      done in
    create init

  let mapq fn m =
      for i = 0 to lines-1 do
	for j = 0 to i do
	  m.(i).(j) <- fn m.(i).(j)
	done
      done

  let mapq2 fn m1 m2 =
      for i = 0 to lines-1 do
	for j = 0 to i do
	  m1.(i).(j) <- fn m1.(i).(j) m2.(i).(j)
	done
      done

  let init_null m =
      for i = 0 to lines-1 do
	for j = 0 to i do
	  m.(i).(j) <- R.zero
	done
      done

  let opp m = (R.opp R.one) @ m

  let zero = null ()

  let conjugate = M.conjugate

end
