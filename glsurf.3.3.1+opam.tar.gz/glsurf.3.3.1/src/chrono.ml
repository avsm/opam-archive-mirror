(**************************************************************************)
(*                                                                        *)
(*                               GlSurf                                   *)
(*                                                                        *)
(*                   C. Raffalli, Universite de Savoie                    *)
(*                                                                        *)
(* Copyright 2003, 2004 Christohe Raffalli                                *)
(*                                                                        *)
(*  This file is part of GlSurf.                                          *)
(*                                                                        *)
(*  GlSurf is free software; you can redistribute it and/or modify        *)
(*  it under the terms of the GNU General Public License as published by  *)
(*  the Free Software Foundation; either version 2 of the License, or     *)
(*  (at your option) any later version.                                   *)
(*                                                                        *)
(*  GlSurf is distributed in the hope that it will be useful,             *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *)
(*  GNU General Public License for more details.                          *)
(*                                                                        *) 
(*  You should have received a copy of the GNU General Public License     *)
(*  along with GlSurf; if not, write to the Free Software                 *)
(*  Foundation, Inc., 59 Temple Place, Suite 330, Boston,                 *)
(*  MA  02111-1307  USA                                                   *)
(**************************************************************************)

open Format

let chrono f a =
  let time = Unix.gettimeofday () in
  let r = f a in
  let time = Unix.gettimeofday() -. time in 
  print_string "Time: ";
  print_float time;
  print_string " seconds.";
  print_newline ();
  print_newline ();
  r

let create () =
  ref (0.0, Unix.gettimeofday ())

let start chr =
  chr := fst !chr, Unix.gettimeofday ()

let reset chr =
  chr := 0.0, Unix.gettimeofday ()

let cumul chr =
  let total, last_start = !chr in
  let current = Unix.gettimeofday () in
  chr := total +. (current -. last_start), current

let total chr = fst !chr

let print_total chr =
  print_string "Time: ";
  print_float (total chr);
  print_string " seconds.";
  print_newline ();

  
