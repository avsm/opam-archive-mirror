(**************************************************************************)
(*                                                                        *)
(*                               GlSurf                                   *)
(*                                                                        *)
(*                   C. Raffalli, Universite de Savoie                    *)
(*                                                                        *)
(* Copyright 2003, 2004, 2005 Christohe Raffalli                          *)
(*                                                                        *)
(*  This file is part of GlSurf.                                          *)
(*                                                                        *)
(*  GlSurf is free software; you can redistribute it and/or modify        *)
(*  it under the terms of the GNU General Public License as published by  *)
(*  the Free Software Foundation; either version 2 of the License, or     *)
(*  (at your option) any later version.                                   *)
(*                                                                        *)
(*  GlSurf is distributed in the hope that it will be useful,             *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *)
(*  GNU General Public License for more details.                          *)
(*                                                                        *) 
(*  You should have received a copy of the GNU General Public License     *)
(*  along with GlSurf; if not, write to the Free Software                 *)
(*  Foundation, Inc., 59 Temple Place, Suite 330, Boston,                 *)
(*  MA  02111-1307  USA                                                   *)
(**************************************************************************)
open Expression
open Function
open Parameters

let use_cache = ref false
let cache_directory = ref ".glsurf_cache"

module Make =
  functor (P:Computing_parameter)  ->
struct
  open P

  let write exprs result =
    if !use_cache then begin
      let infos =
	(List.map (fun e -> Expr.write_to_string (Expr.simplify e)) exprs, 
	 compute_size, compute_origin, max_angle, adjust_angle,
	 out_max_angle, min_size, min_depth, max_division_diff, adjust_factor,
	 adjust_try_newton, nb_random_points, flip)
      in
      let md5 = Digest.to_hex (Digest.string (Marshal.to_string infos [])) in
      let filename = Filename.concat !cache_directory (md5^".glt") in
      let ch = open_out filename in
      Marshal.to_channel ch result [Marshal.Closures];
      close_out ch
    end

  let read exprs =
    try 
      if not !use_cache then raise Not_found;
      let infos =
	(List.map (fun e -> Expr.write_to_string (Expr.simplify e)) exprs, 
	 compute_size, compute_origin, max_angle, adjust_angle,
	 out_max_angle, min_size, min_depth, max_division_diff, adjust_factor,
	 adjust_try_newton, nb_random_points, flip)
      in
      let md5 = Digest.to_hex (Digest.string (Marshal.to_string infos [])) in
      let filename = Filename.concat !cache_directory (md5^".glt") in
      let ch = open_in filename in
      let r = Marshal.from_channel ch in
      close_in ch;
      r
    with _-> raise Not_found
    
					      
      
end

  

