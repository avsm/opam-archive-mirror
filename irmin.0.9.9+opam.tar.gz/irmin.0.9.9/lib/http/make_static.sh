#!/bin/sh

set -e

ocaml-crunch static -m plain -o irmin_http_static.ml
