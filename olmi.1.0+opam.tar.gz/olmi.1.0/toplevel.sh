#!/bin/bash
ocaml -I _build/lib olmi.cma -I _build/examples olmiExamples.cma
