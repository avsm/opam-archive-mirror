(* Example for using Olmi *)

module Identity = OlmiIdentity
module Option = OlmiOption
module List = OlmiList
