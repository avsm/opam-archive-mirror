open Parsetree
open Asttypes
open Ast_mapper
open Longident
open Ast_helper

(* (&) is too strong *)
external ( & ) : ('a -> 'b) -> 'a -> 'b = "%apply"

let mapper = { 
  default_mapper with
  structure = (fun _ str -> 
    prerr_endline !Location.input_name;
    Compile.implementation Format.err_formatter "papa" str "gaga");
  signature = (fun _ sg -> 
    Compile.interface Format.err_formatter "papa" sg "gaga"); 
}

let () = 
  let rev_files = ref [] in 
  Arg.parse 
    []
    (fun s -> rev_files := s :: !rev_files) (* will be handled by [Ast_mapper.apply] *)
    "ppx_overload";
  match List.rev !rev_files with
  | [infile; outfile] ->
      prerr_endline "here we go";
      Clflags.dont_write_files := true;
      Ast_mapper.apply ~source:infile ~target:outfile mapper
  | _ -> 
      failwith "ppx_test infile outfile"
