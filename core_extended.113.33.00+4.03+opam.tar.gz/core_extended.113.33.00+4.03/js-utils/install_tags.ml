let package_name = "core_extended"

let sections =
  [ ("lib",
    [ ("built_lib_core_extended", None)
    ; ("built_lib_selector", None)
    ],
    [ ("META", None)
    ])
  ]
