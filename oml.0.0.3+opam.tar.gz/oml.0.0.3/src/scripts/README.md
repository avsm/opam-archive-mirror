This is a collection of scripts that are useful for testing things out for the developers of Oml. 

Not for distribution.
