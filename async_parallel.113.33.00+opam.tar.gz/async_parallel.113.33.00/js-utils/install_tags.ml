let package_name = "async_parallel"

let sections =
  [ ("lib",
    [ ("built_lib_async_parallel_deprecated", None)
    ],
    [ ("META", None)
    ])
  ]
