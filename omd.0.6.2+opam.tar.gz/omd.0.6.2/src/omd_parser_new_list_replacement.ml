open Omd_representation
open Omd_parser

type ordered = O | U

let new_list rev_main_loop main_loop r p l =
  let end_of_item (indent:int) l : (tok list*tok list) option = match l with
    | [] ->
       (* Let the rest do the work *)
       None
    | Newlines 0 :: Spaces n :: _ as l ->
       if n+2 >= indent+8 then (* code inside item *)
         None
       else if n+2 >= indent+4 then (* new paragraph inside item *)
         None
       else
         Some ([], l)
    | Newlines n :: _ as l -> (* n > 0 *)
       (* End of item, stop *)
       Some([], l)
    | (Newline :: (Space|Spaces _) :: (Star|Minus|Plus) :: (Space|Spaces _):: _)
    | (Newline :: (Space|Spaces _) :: Number _ :: Dot :: (Space|Spaces _) :: _)
      as l ->
       Some([], l)
    | _::_ ->
       None
  in
  let to_t = rev_main_loop [] [Newline] in
  let add (sublist:t) items =
    match items with
    | [] -> assert false
    | (o,indents,item)::tl ->
      (o,indents,(sublist@item))::tl
  in
  let make_up items : Omd_representation.t =
    match items with 
    | (U,_,item)::items ->
      [Ul(item::(List.map(fun (_,_,i) -> i) items))]
    | (O,_,item)::items ->
      [Ul(item::(List.map(fun (_,_,i) -> i) items))]
    | [] -> assert false
  in
  let rec list_items indents items l =
    match l with
    (* no more list items *)
    | [] ->
      make_up items, l
    (* more list items *)
    (* new unordered items *)
    | (Star|Minus|Plus)::(Space|Spaces _)::tl ->
       begin
         match fsplit ~f:(end_of_item 0) tl with
         | None ->
           make_up items, l
         | Some(new_item, rest) ->
           match indents with
           | [] ->
             assert(items = []);
             list_items indents ((U,[0],to_t new_item)::items) rest
           | 0::_ ->
             list_items indents ((U,indents,to_t new_item)::items) rest
           | _::_ ->
             make_up items, l
       end
    | Space::(Star|Minus|Plus)::(Space|Spaces _)::tl ->
       begin
         match fsplit ~f:(end_of_item 1) tl with
         | None -> make_up items, l
         | Some(new_item, rest) ->
           match indents with
           | [] ->
             assert(items = []);
             list_items indents ((U,[1],to_t new_item)::items) rest
           | 1::_ ->
             list_items indents ((U,indents,to_t new_item)::items) rest
           | i::_ ->
             if i < 1 then
               make_up items, l
             else (* i > 1 : new sub list*)
               let sublist, remains =
                 list_items (i::indents) [(U,i::indents,to_t new_item)] rest
               in
               list_items indents (add sublist items) remains
       end
    | Spaces n::(Star|Minus|Plus)::(Space|Spaces _)::tl ->
       begin
         match fsplit ~f:(end_of_item (n+2)) tl with
         | None ->
           make_up items, l
         | Some(new_item, rest) ->
           match indents with
           | [] ->
             assert(items = []); (* a�e... listes mal form�es ! *)
             list_items indents ((U,[1],to_t new_item)::items) rest
           | i::_ ->
             if i = n + 2 then
               list_items indents ((U,indents,to_t new_item)::items) rest
             else
               make_up items, l
       end
    (* new ordered items *)
    | Number _::Dot::(Space|Spaces _)::tl ->
       begin
         match fsplit ~f:(end_of_item 0) tl with
         | None ->
           make_up items, l
         | Some(new_item, rest) ->
           match indents with
           | [] ->
             assert(items = []);
             list_items indents ((O,[0],to_t new_item)::items) rest
           | 0::_ ->
             list_items indents ((O,indents,to_t new_item)::items) rest
           | _::_ ->
             make_up items, l
       end
    | Space::Number _::Dot::(Space|Spaces _)::tl ->
       begin
         match fsplit ~f:(end_of_item 1) tl with
         | None -> make_up items, l
         | Some(new_item, rest) ->
           match indents with
           | [] ->
             assert(items = []);
             list_items indents ((O,[1],to_t new_item)::items) rest
           | 1::_ ->
             list_items indents ((O,indents,to_t new_item)::items) rest
           | i::_ ->
             if i < 1 then
               make_up items, l
             else (* i > 1 : new sub list*)
               let sublist, remains =
                 list_items (i::indents) [(O,i::indents,to_t new_item)] rest
               in
               list_items indents (add sublist items) remains
       end
    | Spaces n::Number _::Dot::(Space|Spaces _)::tl ->
       begin
         match fsplit ~f:(end_of_item (n+2)) tl with
         | None ->
           make_up items, l
         | Some(new_item, rest) ->
           match indents with
           | [] ->
             assert(items = []); (* a�e... listes mal form�es ! *)
             list_items indents ((O,[1],to_t new_item)::items) rest
           | i::_ ->
             if i = n + 2 then
               list_items indents ((O,indents,to_t new_item)::items) rest
             else
               make_up items, l
       end
    | _ -> assert false
  in
  let rp, l = list_items [] [] l in
  rp@r, [Newline], l



(* let new_list rev_main_loop main_loop r p l = *)
(*   let end_of_item (indent:int) l : (tok list*tok list) option = match l with *)
(*     | [] -> *)
(*        (\* Let the rest do the work *\) *)
(*        None *)
(*     | Newlines n :: _ as l when n > 0 -> *)
(*        (\* End of item, stop *\) *)
(*        Some([], l) *)
(*     | Newlines 0 :: Spaces n :: _ as l -> *)
(*        if n+2 >= indent+8 then (\* code inside item *\) *)
(*          None *)
(*        else if n+2 >= indent+4 then (\* new paragraph inside item *\) *)
(*          None *)
(*        else *)
(*          Some ([], l) *)
(*     | (Newline :: (Space|Spaces _) :: (Star|Minus|Plus) :: (Space|Spaces _):: _) *)
(*     | (Newline :: (Space|Spaces _) :: Number _ :: Dot :: (Space|Spaces _) :: _) *)
(*       as l -> *)
(*        Some([], l) *)
(*     | _::_ -> *)
(*        None *)
(*   in *)
(*   let rec list_items indents items p l *)
(*       : (ordered * int list * tok list) list * tok list = *)
(*     match p, l with *)
(*     (\* no more list items *\) *)
(*     | _, [] -> items, l *)
(*     | _, Newlines n :: _ when n > 0 -> items, l *)
(*     (\* more list items *\) *)
(*     (\* new unordered items *\) *)
(*     | ([]|[Newline]), (Star|Minus|Plus)::(Space|Spaces _)::tl -> *)
(*        begin *)
(*          match fsplit ~f:(end_of_item 1) tl with *)
(*          | None -> items, l *)
(*          | Some(new_item, rest) -> *)
(*             let indents = 0::indents in *)
(*             list_items indents ((U,indents,new_item)::items) [Newline] rest *)
(*        end *)
(*     | ([]|[Newline]), Space::(Star|Minus|Plus)::(Space|Spaces _)::tl -> *)
(*        begin *)
(*          match fsplit ~f:(end_of_item 1) tl with *)
(*          | None -> items, l *)
(*          | Some(new_item, rest) -> *)
(*             let indents = 1::indents in *)
(*             list_items indents ((U,indents,new_item)::items) [Newline] rest *)
(*        end *)
(*     | ([]|[Newline]), Spaces n::(Star|Minus|Plus)::(Space|Spaces _)::tl -> *)
(*        begin *)
(*          match fsplit ~f:(end_of_item 1) tl with *)
(*          | None -> items, l *)
(*          | Some(new_item, rest) -> *)
(*             let indents = n+2::indents in *)
(*             list_items indents ((U,indents,new_item)::items) [Newline] rest *)
(*        end *)
(*     (\* new ordered items *\) *)
(*     | ([]|[Newline]), Number _::Dot::(Space|Spaces _)::tl -> *)
(*        begin *)
(*          match fsplit ~f:(end_of_item 1) tl with *)
(*          | None -> items, l *)
(*          | Some(new_item, rest) -> *)
(*             let indents = 0::indents in *)
(*             list_items indents ((O,indents,new_item)::items) [Newline] rest *)
(*        end *)
(*     | ([]|[Newline]), Space::Number _::Dot::(Space|Spaces _)::tl -> *)
(*        begin *)
(*          match fsplit ~f:(end_of_item 1) tl with *)
(*          | None -> items, l *)
(*          | Some(new_item, rest) -> *)
(*             let indents = 1::indents in *)
(*             list_items indents ((O,indents,new_item)::items) [Newline] rest *)
(*        end *)
(*     | ([]|[Newline]), Spaces n::Number _::(Space|Spaces _)::tl -> *)
(*        begin *)
(*          match fsplit ~f:(end_of_item 1) tl with *)
(*          | None -> items, l *)
(*          | Some(new_item, rest) -> *)
(*             let indents = (n+2)::indents in *)
(*             list_items indents ((O,indents,new_item)::items) [Newline] rest *)
(*        end *)
(*     | _ -> *)
(*        items, l *)
(*   in *)
(*   let rec make_lists (items:(ordered * int list * t) list) = *)
(*     let rec make_one_list curr_indent curr_ordered (accu:t list) = function *)
(*       | (o, indents, item) :: tl as l -> *)
(*          assert (indents <> []); *)
(*          if List.hd indents = curr_indent then *)
(*            make_one_list curr_indent curr_ordered (item::accu) tl *)
(*          else if List.hd indents >= curr_indent then *)
(*            let sublist, rest = *)
(*              if o = O then *)
(*                make_one_list (List.hd indents) o [Obj.magic (Ol([item]))] tl *)
(*              else *)
(*                make_one_list (List.hd indents) o [Obj.magic (Ul([item]))] tl *)
(*            in *)
(*            match accu with (\* patch accu *\) *)
(*            | [] -> assert false *)
(*            | (_::accu) -> *)
(*                assert false; *)
(* (\*               if o = O then *\) *)
(* (\*                 make_one_list *\) *)
(* (\*                   curr_indent *\) *)
(* (\*                   curr_ordered *\) *)
(* (\*                   ((Ol([Ol(sublist)]::list))::accu) *\) *)
(* (\*               else *\) *)
(* (\*                 make_one_list *\) *)
(* (\*                   curr_indent *\) *)
(* (\*                   curr_ordered *\) *)
(* (\*                   ((Ol([Ul(sublist)]::list))::accu) *\) *)
(*          else *)
(*            accu, l *)
(*       | [] -> *)
(*          accu, [] *)
(*     in *)
(*     match items with *)
(*     | [] -> [] *)
(*     | (o, i::_, _) :: _ -> *)
(*        match make_one_list i o [] items with *)
(*        | res, [] -> res *)
(*        | res, tl -> res @ make_lists tl *)
(*   in *)
(*   let rec fix_lists l = *)
(*     List.map *)
(*       (function *)
(*         | Ol l -> *)
(*            Ol (List.rev_map fix_lists l) *)
(*         | Ul l -> *)
(*            Ol (List.rev_map fix_lists l) *)
(*         | e -> *)
(*            e) *)
(*       l *)
(*   in *)
(*   let items, remains = list_items [] [] p l in *)
(*   let new_r = *)
(*     fix_lists *)
(*       (make_lists *)
(*          (List.map *)
(*             (fun(o,i,ts) -> o,i,rev_main_loop [] [] ts) *)
(*             items)) *)
(*     :: r *)
(*   in *)
(*   new_r, [Newline], remains *)
