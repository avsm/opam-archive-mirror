typedef int t;
signed t x; /* signed cannot qualify a typedef */

