/* #include <stdio.h> */

int main (){
  int x = 2147483648; /* 2^31 */
  /*   printf("%u\n",x); */
  return 0;
}
