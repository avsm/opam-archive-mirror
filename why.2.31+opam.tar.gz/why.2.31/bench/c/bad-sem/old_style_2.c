/* old style parameters declaration */
void f(x)
int y;
char y;
{}
