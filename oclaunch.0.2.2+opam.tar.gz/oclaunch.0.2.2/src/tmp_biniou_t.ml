(* Auto-generated from "tmp_biniou.atd" *)


type tmp_file = { command: string list; number: int }
