<!--- OASIS_START --->
<!--- DO NOT EDIT (digest: a582ff5eef328f0f8ccffbe2c68e80aa) --->

OcLaunch - Launch commands automagically
========================================

OcLaunch is a command-line tool to launch successively (each time the program
is called) commands. It is designed to be used with any program, interactive
or not. Feedback is welcome at leowzukw@vmail.me. Help at
https://gitlab.com/WzukW/oclaunch/wikis/home. Try it, it works automagically!

See the file [INSTALL.md](INSTALL.md) for building and installation
instructions.

[Home page](http://www.oclaunch.tuxfamily.org)

Copyright and license
---------------------

(C) 2014-2015 Joly Clément

OcLaunch is distributed under the terms of the CEA-CNRS-INRIA Logiciel Libre.

See [LICENSE](LICENSE) for more information.

<!--- OASIS_STOP --->
