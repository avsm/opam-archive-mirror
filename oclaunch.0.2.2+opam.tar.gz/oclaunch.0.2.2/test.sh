#!/bin/bash

# Some script to test the behavior of the programe with custom rc file

./oclaunch.native -v 5 --rc ./dev.json $*
