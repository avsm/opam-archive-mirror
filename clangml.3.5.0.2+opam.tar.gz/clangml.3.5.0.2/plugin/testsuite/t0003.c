// t0003.c
// __func___

char const *foo()
{
  return __func__;
}

