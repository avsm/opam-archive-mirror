@interface Object
+new;
@end

void f() {
  Object* o = [Object new];
}
