// from the kernel
typedef unsigned char u8;
static int adm1025_read_value(u8 register);
