typedef __attribute__((ext_vector_type(5))) __short5;

fn1() {
  __short5 a;
  a.y;
}
