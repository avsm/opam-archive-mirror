// gb0001.c
// applying cv-flags to a function type via typedef

typedef void voidfn ();
extern volatile voidfn fatal;
