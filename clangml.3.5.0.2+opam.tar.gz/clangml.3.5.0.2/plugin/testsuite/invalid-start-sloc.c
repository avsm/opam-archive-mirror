struct A {
  struct {
    int b;
    struct {
      int c
    };
  };
} a = { .c = 0 };
