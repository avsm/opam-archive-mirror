* [Daniel C. Bünzli](http://erratique.ch), main developer.
* David Kaloper, `Uucp.Break.tty_width_hint` function.
