include Core_lazy

let of_thunk = from_fun
