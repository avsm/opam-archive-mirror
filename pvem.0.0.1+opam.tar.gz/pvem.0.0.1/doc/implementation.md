
Implementation Notes
====================

Why Polymorphic Variants (For `Ok` and `Error`)
-----------------------------------------------


Using

```ocaml
type ('a, 'b) t =
  | Ok of 'a
  | Error of 'b
```

gives two annoying alternatives:

- be incompatible with Core `Result.t`, or
- depend on Core.

Type equality constraints do not work *twice*. I.e. one cannot write:

```ocaml
type ('a, 'b) result_core = ('a, 'b) Result.t  = Ok of 'a | Error of 'b
type ('a, 'b) result_err = ('a, 'b) Err.t  = Ok of 'a | Error of 'b
type ('a, 'b) result = ('a, 'b) result_err  = ('a, 'b) result_core
```

or any combination like that.
