## gtk-light - Light wrapper around lablgtk2
