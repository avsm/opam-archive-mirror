#ifndef EDJE_H
#define EDJE_H

#include "include.h"

PREFIX void ml_Edje_Signal_Cb(
        void* data, Evas_Object* obj, const char* emission, const char* source);

#endif

