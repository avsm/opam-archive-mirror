external add : Evas.obj -> Evas.obj = "ml_elm_mapbuf_add"

let addx = Elm_object.create_addx add

external enabled_set : Evas.obj -> bool -> unit = "ml_elm_mapbuf_enabled_set"

external enabled_get : Evas.obj -> bool = "ml_elm_mapbuf_enabled_get"

external smooth_set : Evas.obj -> bool -> unit = "ml_elm_mapbuf_smooth_set"

external smooth_get : Evas.obj -> bool = "ml_elm_mapbuf_smooth_get"

external alpha_set : Evas.obj -> bool -> unit = "ml_elm_mapbuf_alpha_set"

external alpha_get : Evas.obj -> bool = "ml_elm_mapbuf_alpha_get"

external auto_set : Evas.obj -> bool -> unit = "ml_elm_mapbuf_auto_set"

external auto_get : Evas.obj -> bool = "ml_elm_mapbuf_auto_get"

