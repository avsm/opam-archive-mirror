#ifndef ECORE_H
#define ECORE_H

inline Ecore_Pos_Map Ecore_Pos_Map_val(value v);
inline value Val_Ecore_Pos_Map_val(Ecore_Pos_Map m);

PREFIX void raise_not_X();
PREFIX void raise_not_Wayland();

PREFIX void ml_Ecore_Cb_1_free(void* data);
PREFIX void ml_Ecore_Cb_free(void* data);

#endif

