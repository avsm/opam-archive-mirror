Lazy prefix trees in OCaml
