#!/bin/bash

# Nothing to do -- all mtlearn tests are fragile because expectation
# maximization is very sensitive to the random numbers.
