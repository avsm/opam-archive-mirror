include Core_kernel.Float
