let _, x = hoge
