let _ = fun {desc = _} -> 0
