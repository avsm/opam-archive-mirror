open Printf
open Json

(** The names of type and modules

    If you want to auto generate of conversion functions [conv(xxx)] 
    of your target data type,

    * Your target data must have a name [Xxx.t] (here [Json.t]).
      (You can put it in another module [Aaa.Bbb.Xxx.t], but the data type must
       be accessible by [Xxx.t]: you need to [open Aaa.Bbb].

    * You must write a convesion module named [Xxx_conv] (here [Json_conv], this file.),
      and make it accessible as [Xxx_conv]. (Same again, you can put the module inside
      another module, but then, you need [open]. 

*)

(** Basic requirement: [include Meta_conv.Coder.Make(...)]

   You must define a module with

   * The target type [target], here [Json.t]
   * [format], a printer for [target], useful for debugging
   * And the basic constructor and deconstructor modules of [target], 
     [Constr] and [Deconstr] respectively.

   and apply [Meta_conv.Coder.Make] to it, and include the result.
*)

include Meta_conv.Coder.Make(struct 

  type target = Json.t  (** This is the target type! *)

  (** [format]: printer of [target] *)
  let rec format = 
    let open Format in
    let rec format_list sep f ppf = function
      | [] -> ()
      | [x] -> f ppf x
      | x::xs -> f ppf x; fprintf ppf sep; format_list sep f ppf xs
    in
    fun ppf -> function
      | String s -> fprintf ppf "%S" s
      | Number f -> fprintf ppf "%f" f
      | Object o -> 
          fprintf ppf "{ @[%a@] }"
            (format_list ";@ " (fun ppf (s,v) -> fprintf ppf "@[%s= @[<v2>%a@]@]" s format v)) o
      | Array ts -> 
          fprintf ppf "[ @[%a@] ]"
            (format_list ";@ " (fun ppf v -> fprintf ppf "@[<v2>%a@]@]" format v)) ts
      | Bool b -> fprintf ppf "%b" b
      | Null -> fprintf ppf "()"

  (** [Constr]: Constructors.

      This module implements how to construct a [target] value from other [target] values.
      It must have: 

        val tuple        : target list -> target
        val variant      : string -> target list -> target
        val poly_variant : string -> target list -> target
        val record       : (string * target) list -> target
        val object_      : (string * target) list -> target

      It is often the case that you do not really distinguish records and objects,
      and variants and polymorphic variants. In that case, you can write simply
      [let poly_variant = variant and object_ = record].
  *)
  module Constr = struct
    let tuple ts = Array ts
    let variant _tyname tag = function
      | [] -> String tag
      | ts -> Object [tag, Array ts]
    let record _tyname tag_ts  = Object tag_ts
    let poly_variant = variant (* We use the same construction as variants *)
    let object_ = record (* We use the same construction as records *)
  end

  (** [Deconstr]: Deconstructors.

      This module implements how to deconstruct a [target] value to sub [target] values.
      It must have: 

        val tuple        : target -> target list
        val variant      : target -> string * target list
        val poly_variant : target -> string * target list
        val record       : target -> (string * target) list
        val object_      : target -> (string * target) list

      If deconstruction is impossible, the functions can raise exceptions. The exceptions
      are caught and result into decoding failure errors. For example, if [tuple] takes
      a target value which is not interpretable as a tuple, it should raise an exception.

      It is often the case that you do not really distinguish records and objects,
      and variants and polymorphic variants. In that case, you can write simply
      [let poly_variant = variant and object_ = record].
  *)
  module Deconstr = struct
  
    let tuple = function 
      | Array ts -> ts
      | _ -> 
          (* Otherwise, it is not interpretable as a tuple, so raise an exception *)
          failwith "Array expected for tuple" 
  
    let variant _tyname = function 
      | String tag -> tag, [] 
      | Object [tag, Array ts] -> tag, ts
      | _ -> failwith "Object expected for variant"
  
    let record _tyname = function
      | Object alist -> alist
      | _ -> failwith "Object expected for record"
  
    let poly_variant = variant
    let object_ = record
  end

end)

(** Auxiliary: encoders and decoders for primitive types: [xxx_of_<type>] and [<type>_of_xxx] 

    Conversion functions for derived types which are defined using 
    [type t = ... with conv(xxx)] are created by [pa_meta_conv] CamlP4 extension,
    but those for primitive types are not. You need to define them by yourself.

    Primitive types are types without definitinons. Popular primitive types are:
    int, int32, int64, nativeint, char, string, float, list, array, bool, lazy_t,
    unit, option and Hashtbl.t.

    You should define encoders and decoders for those types in [Xxx_conv] module.
    You do not need to define en/decoders of all the primitive types, but 
    of course Meta_conv cannot auto-generate coders of derived types whose definitions
    depend on primitive types without coders.

    The names of coders for a primitive type <type> is [xxx_of_<type>] and
    [<type>_of_xxx]. Here, we are defining things for [conv(json)], so 
    they are [json_of_<type>] and [<type>_of_json].
*)

(** Encoders for primitive types *)

let json_of_int n       = Number (float n)
let json_of_int32 n     = Number (Int32.to_float n)
let json_of_int64 n     = Number (Int64.to_float n) (* CR jfuruse: BUG: Int64.max_int cannot be mapped to float properly *)
let json_of_nativeint n = Number (Nativeint.to_float n)
let json_of_char c      = String (String.make 1 c)
let json_of_string s    = String s
let json_of_float n     = Number n
let json_of_list f xs   = Array (List.map f xs)
let json_of_array f xs  = Array (List.map f (Array.to_list xs))
let json_of_bool b      = Bool b
let json_of_lazy_t f v  = f (Lazy.force v)
let json_of_unit ()     = Null
(* CR jfuruse: BUG: this makes [None] and [Some (None)] not distinguishable. i.e. t option^n are all mapped to t option *)
let json_of_option f    = function
  | None -> Null
  | Some v -> f v
  
(** Decoders for primitive types 

    Usually decoders are harder to imlement compared to encoders.
    There is a module [Helper] available, which is created by the above
    [Meta_conv.Coder.Make(...)]. [Helper] provides some useful functions
    for decoders. See the module type [Types.S] to know about [Helper].

    Note that [<type>_of_xxx] must report the decoding errors using
    the Result monad (See [Meta_conv.Result]). You should not raise
    an exception inside a decoder, or, use [result] to wrap a function
    of type [decoder_exn]. (They are available via the above 
    [include Meta_conv.Coder.Make(...)]. See [Types.S] for details.)
*)

let failwithf fmt = kprintf (fun s -> raise (Failure s)) fmt

let string_of_json = Helper.of_deconstr (function
  | String s -> s
  | _ -> failwith "string_of_json: String expected")

let char_of_json = Helper.of_deconstr (function
  | String s when String.length s = 1 -> s.[0]
  | _ -> failwith "char_of_json: a char expected")

let int_check name min max conv = Helper.of_deconstr (function 
  | Number n -> 
      begin match Helper.integer_of_float min max conv n with
      | `Ok v -> v
      | `Error s -> failwithf "%s_of_json: %s" name s
      end
  | _ -> failwithf "%s_of_json: Number expected" name)

let int_of_json =
  int_check "int" (float min_int) (float max_int) int_of_float

let int64_of_json =
  let open Int64 in
  int_check "int64" (to_float min_int) (to_float max_int) of_float
      
let int32_of_json =
  let open Int32 in
  int_check "int32" (to_float min_int) (to_float max_int) of_float
      
let nativeint_of_json = 
  let open Nativeint in
  int_check "nativeint" (to_float min_int) (to_float max_int) of_float
      
let float_of_json = Helper.of_deconstr (function
  | Number n -> n
  | _ -> failwith "float_of_json: Number expected")

let bool_of_json = Helper.of_deconstr (function
  | Bool b -> b
  | _ -> failwith "bool_of_json: Bool expected")

let unit_of_json = Helper.of_deconstr (function
  | Null -> ()
  | _ -> failwith "unit_of_json: Null expected")
  
let list_of_json f = 
  Helper.list_of (function Array xs -> Some xs | _ -> None) f

let array_of_json f = 
  Helper.array_of (function Array xs -> Some xs | _ -> None) f

(* CR jfuruse: BUG: Due to the inaccurate encoding of option, Some (Some (Some (Some x))) is encoded then decoded back to Some x *)
let option_of_json f = Helper.option_of 
  (function Null -> Some None | v -> Some (Some v))
  f

let lazy_t_of_json d = Helper.lazy_t_of (fun e -> raise (Error e)) d

(** Auxiliary: encoders and decoders of Meta_conv special types.

    Special types such as [mc_lazy_t] and [mc_fields] require their own special
    en/decoders. If you want to use those special types, you must define those
    coders.
 *)

let json_of_mc_lazy_t = Helper.of_mc_lazy_t
let mc_lazy_t_of_json = Helper.mc_lazy_t_of

let json_of_mc_fields enc xs = 
  Constr.record "mc_fields" (List.map (fun (name, a) -> (name, enc a)) xs)

let mc_fields_of_json dec = 
  Helper.mc_fields_of (function Object js -> Some js | _ -> None) dec
