0.2 (9-Nov-2015)
- add `Error.string_of_error`
- clarify that `fold_mapped` callbacks use sectors, not bytes
- bugfix `fold_mapped_s`
- `fold_unmapped_s` should not return the empty buffers: lengths are enough

0.1 (3-Nov-2015)
- initial version
