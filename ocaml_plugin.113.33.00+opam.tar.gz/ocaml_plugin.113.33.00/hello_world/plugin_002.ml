open! Core.Std

let message = 42
