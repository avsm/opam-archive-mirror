open Core.Std

let message = Int.to_string Plugin_002.message
