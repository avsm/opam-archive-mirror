
#define SDLRWops_val(v) ((SDL_RWops *)(Field((v), 0)))

enum mlsdl_rwops_tag {
  MLSDL_RWOPS_MEM,
};
