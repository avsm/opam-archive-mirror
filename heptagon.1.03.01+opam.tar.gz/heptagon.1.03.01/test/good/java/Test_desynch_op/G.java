package Test_desynch_op;


public class G {
    protected Desynch.Comm n_4;
    protected F n_3;
    
    public G () {
        this.n_4 = new Desynch.Comm();
        this.n_3 = new F();
        
    }
    public int step (boolean c_1, boolean d_1, boolean e_1, int z) {
        int t = 0;
        int v_3 = 0;
        int v_2 = 0;
        int v = 0;
        v = (z + 3);
        v_2 = n_3.step(e_1, c_1, v);
        v_3 = n_4.step(c_1, d_1, v_2);
        t = (v_3 + 4);
        return t;
    }
    public void reset () {
        
    }
}
