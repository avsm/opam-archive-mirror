package Tdesynch;


public class F {
    protected Desynch.Comm n;
    
    public F () {
        this.n = new Desynch.Comm();
        
    }
    public int step (boolean a_3, boolean b_3, int x) {
        int y = 0;
        y = n.step(a_3, b_3, x);
        return y;
    }
    public void reset () {
        
    }
}
