package Desynch;


public class F {
    protected Comm n;
    
    public F () {
        this.n = new Comm();
        
    }
    public int step (boolean a_1, boolean b_1, int x) {
        int y = 0;
        y = n.step(a_1, b_1, x);
        return y;
    }
    public void reset () {
        
    }
}
