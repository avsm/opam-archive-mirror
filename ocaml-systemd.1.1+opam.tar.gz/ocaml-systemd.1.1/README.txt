(* OASIS_START *)
(* DO NOT EDIT (digest: d3ac585c1fef43aa982dab73c3a681ad) *)

ocaml-systemd - OCaml systemd library
=====================================

See the file [INSTALL.txt](INSTALL.txt) for building and installation
instructions.

Copyright and license
---------------------

ocaml-systemd is distributed under the terms of the GNU Lesser General Public
License version 3 with OCaml linking exception.

(* OASIS_STOP *)
