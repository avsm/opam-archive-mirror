module Immediate = Immediate
