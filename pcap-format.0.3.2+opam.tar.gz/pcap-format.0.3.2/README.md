ocaml-pcap
==========

Ocaml code for generating and analysing pcap (packet capture) files.

This is based on Anil Madhavapeddy's "cstruct" example code.
