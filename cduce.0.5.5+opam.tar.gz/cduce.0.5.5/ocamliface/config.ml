let standard_library = "STDLIB"
let load_path = ref ([] : string list)
let bytecomp_c_compiler = ""
let bytecomp_c_linker = ""
