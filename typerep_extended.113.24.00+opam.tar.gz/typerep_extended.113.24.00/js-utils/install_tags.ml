let package_name = "typerep_extended"

let sections =
  [ ("lib",
    [ ("built_lib_typerep_extended", None)
    ],
    [ ("META", None)
    ])
  ]
