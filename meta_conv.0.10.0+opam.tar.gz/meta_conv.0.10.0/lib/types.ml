module Address = struct
  type t = int list
  let top = []
end

module Error = struct

  type 'target desc =
    | Deconstruction_error of 
        exn (** exception of the Decode.tuple, variant or record *)
    | Unknown_fields of 
        string (** type name *) 
        * (string * 'target) list (** unknown fields *)
    | Required_fields_not_found of 
        string (** type name *)
        * string list (** missing fields *)
        * (string * 'target) list (** the input *)
    | Wrong_arity of 
        int (** expected *) 
        * int (** actual *) 
        * (string * string) option (** type name and tag, if tuple, None *) 
    | Primitive_decoding_failure of 
        string (** message *)
  
  type 'target t = 'target desc * 'target * Address.t

end

module Result = struct

  (** Result monad *)
  type ('host, 'target) t =
    [ `Ok of 'host 
    | `Error of 'target Error.t
    ]

  let bind t f = match t with
    | `Ok v -> f v
    | `Error (err, v, adrs) -> `Error (err, v, adrs)

  let (>>=) = bind

  let fmap f t = match t with
    | `Ok v -> `Ok (f v)
    | `Error (err, v, adrs) -> `Error (err, v, adrs)

end

module Decoder = struct
  type ('host, 'target) t = ?adrs: Address.t -> 'target -> ('host, 'target) Result.t
  type ('host, 'target) t_exn = ?adrs: Address.t -> 'target -> 'host
end

type ('host, 'target) mc_lazy_t = ('host, 'target) Result.t lazy_t

type 'target mc_fields = (string * ('target * Address.t)) list
(** Not-yet-decoded fields *)
