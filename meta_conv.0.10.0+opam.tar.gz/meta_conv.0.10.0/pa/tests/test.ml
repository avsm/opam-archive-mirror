type x1 = int list with conv(json)
type 'a x2 = 'a list with conv(json)
type x3 = Hoo.t with conv(json)
type x4 = (int, float) Hashtbl.t with conv(json)

type x5 = Foo | Bar with conv(json)
type x6 = Foo of int | Bar with conv(json)
type x7 = Foo of int * float | Bar with conv(json)
type 'a x8 = Foo of 'a * float with conv(json)
type tup = int * float with conv(json)

type tup2 = Foo of (int * float) with conv(json)
type re1 = { l : int } with conv(json)
type re2 = { l : int; r : float } with conv(json)
type ('a, 'b) re3 = { l : 'a; r : 'b } with conv(json)
type re4 = { mutable l : int } with conv(json)

type e = { desc : edesc; loc : int }
and edesc = Foo of e 
with conv(json)
