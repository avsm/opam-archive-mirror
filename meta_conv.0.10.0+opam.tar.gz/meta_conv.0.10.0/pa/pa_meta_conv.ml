open Camlp4
open PreCast
open Pa_type_conv
open Ast

let _loc = Loc.ghost

open Tctools

(* syntax modification **************************************************)

 open Syntax

let annotations = Hashtbl.create 31

EXTEND Gram
  GLOBAL: constructor_declaration constructor_declarations label_declaration
          type_declaration
  ;
  
  constructor_declaration: 
      [ [ s = a_UIDENT; "(:"; e = expr; ":)"; "of"; t = constructor_arg_list ->
            Hashtbl.add annotations (_loc,s) e;
            <:ctyp< $uid:s$ of $t$ >>
        | s = a_UIDENT; "as"; n = a_STRING; "of"; t = constructor_arg_list ->
            Hashtbl.add annotations (_loc,s) <:expr< $str:n$ >>;
            <:ctyp< $uid:s$ of $t$ >>
        | s = a_UIDENT; "(:"; e = expr; ":)" ->
            Hashtbl.add annotations (_loc,s) e;
            <:ctyp< $uid:s$ >>
        | s = a_UIDENT; "as"; n = a_STRING ->
            Hashtbl.add annotations (_loc,s) <:expr< $str:n$ >>;
            <:ctyp< $uid:s$ >>
      ] ];

  constructor_declarations:
      [ [ s = a_UIDENT; "(:"; e = expr; ":)"; "of"; t = constructor_arg_list ->
            Hashtbl.add annotations (_loc,s) e;
            <:ctyp< $uid:s$ of $t$ >>
        | s = a_UIDENT; "as"; n = a_STRING; "of"; t = constructor_arg_list ->
            Hashtbl.add annotations (_loc,s) <:expr< $str:n$ >>;
            <:ctyp< $uid:s$ of $t$ >>
        | s = a_UIDENT; "(:"; e = expr; ":)" ->
            Hashtbl.add annotations (_loc,s) e;
            <:ctyp< $uid:s$ >>
        | s = a_UIDENT; "as"; n = a_STRING ->
            Hashtbl.add annotations (_loc,s) <:expr< $str:n$ >>;
            <:ctyp< $uid:s$ >>
      ] ];

  label_declaration:
    [ [ s = a_LIDENT; "(:"; e = expr; ":)"; ":"; t = poly_type ->  
            Hashtbl.add annotations (_loc,s) e;
            (* dont know why but it is impos to write 
               <:ctyp< $lid:s$ : $t$ >> *)
            TyCol (_loc, 
                   TyId(_loc, <:ident< $lid:s$ >> ), 
                   t )
      | s = a_LIDENT; "as"; n = a_STRING; ":"; t = poly_type ->  
            Hashtbl.add annotations (_loc,s) <:expr< $str:n$ >>;
            (* dont know why but it is impos to write 
               <:ctyp< $lid:s$ : $t$ >> *)
            TyCol (_loc, 
                   TyId(_loc, <:ident< $lid:s$ >> ), 
                   t )
      | "mutable"; s = a_LIDENT; "as"; n = a_STRING; ":"; t = poly_type ->
            Hashtbl.add annotations (_loc,s) <:expr< $str:n$ >>;
            (* dont know why but it is impos to write 
               <:ctyp< $lid:s$ : $t$ >> *)
            TyCol (_loc,
                   TyId(_loc, <:ident< $lid:s$ >> ),
                   TyMut(_loc, t) )
    ] ];

  type_declaration:
    [ [ (n, tpl) = type_ident_and_parameters; "(:"; e = expr; ":)"; tk = opt_eq_ctyp;
        cl = LIST0 constrain -> 
          Hashtbl.add annotations (_loc,n) e;
          Ast.TyDcl(_loc, n, tpl, tk, cl)
    ] ];

  (*  `QUOTATION x -> Quotation.expand _loc x Quotation.DynAst.ctyp_tag *)

(*  comma_idents:
    [ LEFTA
        [ ids1 = SELF; ","; ids2 = SELF -> ids1 @ ids2
        | id = ident -> [ strip_ident_loc id ]
        ]
    ];
*)
END

(* annotation parsing ******************************************************)

let rec split_by_comma = function
  | <:expr< $e1$, $e2$ >> -> split_by_comma e1 @ split_by_comma e2
  | <:expr< >> -> []
  | <:expr< $e$ >> -> [e]

type type_name_annotation_semantics = {
  field_check : expr option;
}

let default_type_name_annotation_semantics = {
  field_check = Some <:expr< Meta_conv.Internal.record_unknown_field_check >>
}

let interprete_type_name_annotation loc name = 
  let annots = 
    List.flatten (List.map split_by_comma (Hashtbl.find_all annotations (loc, name)))
  in
  List.fold_left (fun _acc -> function
    | <:expr< Ignore_unknown_fields >> -> 
        { field_check = None }
    | <:expr< field_check = $e$ >> -> { field_check = Some e }
    | _ -> failwith "strange meta_conv type name annotation")
    default_type_name_annotation_semantics
    annots

let interprete_variant_annotation loc id = 
  let id_name = name_of_ident id  in
  match Hashtbl.find_all annotations (loc, id_name) with
  | [ <:expr< $str:x$ >> ] -> x
  | [] -> id_name
  | _ -> failwith "strange meta_conv variant annotation"

type type_record_field_annotation_semantics = 
    { name : string;
      optional : bool;
      leftovers : bool }

let interprete_record_field_annotation loc id ctyp = 
  let name = name_of_ident id  in
  let optional = match ctyp with
    | <:ctyp< $_$ mc_option >>
    | <:ctyp< $_$ sexp_option >> -> true
    | _ -> false
  in
  let leftovers = match ctyp with
    | <:ctyp< $_$ mc_leftovers >> -> true
    | _ -> false
  in
  let annots = 
    List.flatten (List.map split_by_comma (Hashtbl.find_all annotations (loc, name)))
  in
  let st0 = { name; optional; leftovers } in
  List.fold_left (fun st -> function
    | <:expr< $str:x$ >> -> { st with name = x }
    | <:expr< Leftovers >> -> { st with leftovers = true }
    | _ -> prerr_endline "Unknown (: .. :) meta_conv annotation"; assert false) st0 annots

(* code generators ******************************************************)

module Encode(A : sig
  val target_type_path : ident
  val module_path : ident
  val conv_name : string
end) = struct
  
  open A

  let rec gen_ctyp : ctyp -> expr = function
    | TyId (loc, id) ->  (* int *)
        <:expr@loc< $id: change_id (fun s -> A.conv_name ^ "_of_" ^ s) id$ >>
          
    | (TyQuo (_loc, _) as tv) ->  (* 'a *)
        expr_of_tvar tv
          
    | TyApp (loc, (TyId(_, _id) as f), args) ->  (* (int, float) Hashtbl.t *)
        let args = list_of_ctyp args [] in
        let f = gen_ctyp f in
        Gen.apply loc f (List.map gen_ctyp args)
    | TyApp (loc, TyApp (_loc, f, args1), args2) -> 
          (* a hack for int float Hashtbl.t => (int, float) Hashtbl.t *)
        gen_ctyp (TyApp (loc, f, TyCom(_loc, args1, args2)))
          
    | TyTup (loc, ctyp) ->
        let ctyps = list_of_ctyp ctyp [] in
        let ids = mk_idents "__x" (List.length ctyps) in
        Gen.abstract loc [ create_patt_tuple (List.map patt_of_id ids) ]
          (create_expr_app 
           <:expr< $id:module_path$.Encode.tuple >>
             [create_list (List.map2 (fun id ctyp ->
               let f = gen_ctyp ctyp in
               <:expr< $f$ $expr_of_id id$ >>
             ) ids ctyps)])
    | _ -> assert false
    
  let alias _name _tyd_loc _loc cty = 
    let f = gen_ctyp cty in
    <:expr< fun __value -> $f$ __value >>
    
  let sum _name _tyd_loc _loc ctyp = 
    let constrs = list_of_ctyp ctyp [] in (* decompose TyOr *)
    let case loc id ctyp =
      let id_name = interprete_variant_annotation loc id in

      let ctyps = list_of_ctyp ctyp [] in (* decompose TyAnd *)
      let ids = mk_idents "__x" (List.length ctyps) in
      let patt = create_patt_app <:patt@loc< $id:id$ >> (List.map patt_of_id ids) in
      let exp = create_expr_app 
        <:expr< $id:module_path$.Encode.variant >>
        [ <:expr< $str: id_name$ >>;
          (* CR jfuruse: dupe in gen_ctyp *)
          create_list (List.map2 (fun id ctyp ->
            let f = gen_ctyp ctyp in
            <:expr< $f$ $expr_of_id id$ >>
          ) ids ctyps) ]
      in
      <:match_case< $ patt $ -> $ exp $ >>
    in
    let cases = 
      List.map (function
        | <:ctyp@loc< $id:id$ of $ctyp$ >> -> case loc id ctyp
        | <:ctyp@loc< $id:id$ >> -> case loc id (TyNil _loc)
        | _ -> assert false
      ) constrs 
    in
    <:expr< fun __value -> match __value with $mcOr_of_list cases$ >>
  
  let record name tyd_loc _loc ctyp = 
    let _annot = interprete_type_name_annotation tyd_loc name in
    let ctyps = list_of_ctyp ctyp [] in (* decomp TySems *)
    let fields, rest = List.fold_right (fun ctyp (fields, rest) ->
      match ctyp with
      | TyCol (loc, TyId(_, lab_id), ctyp) -> 
          let f = gen_ctyp (strip_field_flags ctyp) in
          let sem = interprete_record_field_annotation loc lab_id ctyp in
          begin match sem with
          | { leftovers = true; _ } ->
              (* CR jfuruse: adrses are not preserved *)
              fields, Some <:expr< List.map (fun (name, (v, _)) -> (name, v)) __value.$id:lab_id$ >>
          | { name = s; optional = true; _ } ->
              <:expr< match __value.$id:lab_id$ with 
                      | None -> None 
                      | Some v -> Some ($str:s$, $f$ v) >> :: fields,
              rest
          | { name = s; _ } ->
              <:expr< Some ($str:s$, $f$ __value.$id:lab_id$) >> :: fields,
              rest
          end
      | _ -> assert false) ctyps ([], None)
    in
    (* CR jfuruse: option map should be in the libarary *)
    let exp = <:expr<
      List.fold_right (fun x st -> match x with None -> st | Some v -> v::st) $create_list fields$ []
      >>
    in
    let exp = match rest with
      | None -> exp 
      | Some e -> <:expr< $exp$ @ $e$ >>
    in
    <:expr< fun __value -> $id:module_path$.Encode.record $exp$ >>
    
  (** for [X; Y; .. ], Z and BASE, build (X -> BASE) -> (Y -> BASE) -> ... -> Z -> BASE *)
  let dispatch_type params z base = 
    List.fold_right (fun ctyp st -> <:ctyp< ($ctyp$ -> $base$) -> $st$ >>) params <:ctyp< $z$ -> $base$ >>
  
  let func_type params name = 
    create_for_all params (dispatch_type params 
                             (create_param_type params name)
                             <:ctyp< $id:target_type_path$ >>)
  
  (******************* kind of template *)
  
  let def name loc cty =
    let variants _ = assert false in
    let mani     _ = assert false in
    let nil      _ = assert false in
    let alias  = alias name loc in
    let sum    = sum name loc in
    let record = record name loc in
    Gen.switch_tp_def ~alias ~sum ~record ~variants ~mani ~nil cty
  
  
  let dcl _loc name (params : ctyp list) d =
    <:binding<
      $lid: A.conv_name ^ "_of_" ^ name$ : $func_type params name$ = 
        $Gen.abstract _loc (List.map patt_of_tvar params) (def name _loc d)$
    >>
  
  (* Add "of_sexp" and "sexp_of" as "sexp" to the set of generators *)
  let str = fun rec_ tds ->
      let _loc = Ast.loc_of_ctyp tds in
      let decls = list_of_ctyp tds [] in
      let recursive = type_definitions_are_recursive rec_ tds in
      let binds = List.map (function
        | TyDcl (loc, name, params, def, _constraints) -> 
            dcl loc name params def
        | _ -> assert false) decls
      in
      create_top_let recursive binds

  let dcl_sg _loc name (params : ctyp list) _d =
    <:sig_item<
      val $lid: A.conv_name ^ "_of_" ^ name $ : $func_type params name$
    >>
  
  let sg = fun _rec_ tds ->
      let _loc = Ast.loc_of_ctyp tds in
      let decls = list_of_ctyp tds [] in
      let items = List.map (function
        | TyDcl (loc, name, params, def, _constraints) -> 
            dcl_sg loc name params def
        | _ -> assert false) decls
      in
      concat_sig_items items

end
  
module Decode(A : sig
  val target_type_path : ident
  val module_path : ident
  val conv_name : string
end) = struct
  
  open A

  let binds ids exps final = List.fold_right2 (fun id exp st ->
    <:expr< Meta_conv.Types.Result.bind $exp$ (fun $id:id$ -> $st$) >>) 
    ids exps <:expr< `Ok $final$ >>

  let rec gen_ctyp : ctyp -> expr = function
    | TyId (loc, id) ->  (* int *)
        <:expr@loc< $id: change_id (fun s -> s ^ "_of_" ^ A.conv_name) id$ >>

    | (TyQuo (_loc, _) as tv) ->  (* 'a *)
        expr_of_tvar tv

    | TyApp (loc, (TyId(_, _id) as f), args) ->  (* (int, float) Hashtbl.t *)
        let args = list_of_ctyp args [] in
        let f = gen_ctyp f in
        Gen.apply loc f (List.map gen_ctyp args)
    | TyApp (loc, TyApp (_loc, f, args1), args2) -> 
        (* a hack for int float Hashtbl.t => (int, float) Hashtbl.t *)
        gen_ctyp (TyApp (loc, f, TyCom(_loc, args1, args2)))

    | TyTup (_loc, ctyp) ->
        let ctyps = list_of_ctyp ctyp [] in
        let len = List.length ctyps in
        let ids = mk_idents "__x" len in
        let pat = create_patt_list (List.map patt_of_id ids) in 
        let tup = create_tuple (List.map expr_of_id ids) in
        let exps = List.map2 (fun id ctyp -> <:expr< $gen_ctyp ctyp$ $id:id$>> ) ids ctyps in
        let binds = binds ids exps tup in
        <:expr< fun ?(adrs:__adrs=Meta_conv.Types.Address.top) __value -> 
          match $id:module_path$.Decode.tuple (__value,_adrs) with
          | $pat$ -> $binds$
          | l -> Meta_conv.Internal.tuple_arity_error len (List.length l) __value __adrs
        >>
    | _ -> assert false
  
  let alias _name _tyd_loc _loc cty = 
    let f = gen_ctyp cty in
    <:expr< fun ?adrs __value -> $f$ ?adrs __value >>
  ;;

  let sum name _tyd_loc _loc ctyp = 
    let constrs = list_of_ctyp ctyp [] in (* decompose TyOr *)
    let case loc id ctyp =
      let id_name = interprete_variant_annotation loc id in

      let ctyps = list_of_ctyp ctyp [] in (* decompose TyAnd *)
      let len = List.length ctyps in
      let ids = mk_idents "__x" len in

      let exps = List.map2 (fun id ctyp -> 
        <:expr< $gen_ctyp ctyp$ ~adrs:(snd $id:id$) (fst $id:id$) >> ) ids ctyps 
      in
      let final = create_expr_app <:expr< $id:id$ >> (List.map expr_of_id ids) in

      (* id_name, [ ids ] *)
      let case = <:match_case< 
        ($str:id_name$, l) -> begin match l with 
          | $create_patt_list (List.map patt_of_id ids)$ ->
              $ binds ids exps final $
          | _ -> 
              Meta_conv.Internal.variant_arity_error 
                $str:name$ $str:id_name$ $int:string_of_int len$ (List.length l)
                __value __address
          end
        >> 
      in
      case
    in
    let default = <:match_case<
      name, l -> 
        Meta_conv.Internal.variant_unknown_tag_error 
          $str:name$ name __value __address
      >>
    in
    let cases = 
      List.map (function
        | <:ctyp@loc< $id:id$ of $ctyp$ >> -> case loc id ctyp
        | <:ctyp@loc< $id:id$ >> -> case loc id (TyNil _loc)
        | _ -> assert false
      ) constrs @ [ default ]
    in
    <:expr< fun ?adrs:(__address=Meta_conv.Types.Address.top) __value -> 
      match $id:module_path$.Decode.variant (__value, __address) with 
        $mcOr_of_list cases$ 
    >>
  
  let record ty_name tyd_loc _loc ctyp = 
    let annot = interprete_type_name_annotation tyd_loc ty_name in
    let ctyps = list_of_ctyp ctyp [] in (* decomp TySems *)
    let labels, fields, rest = List.fold_right (fun ctyp (labs, st, rest) -> match ctyp with
      | TyCol (loc, TyId(_, lab_id), ctyp) -> 
          let sem = interprete_record_field_annotation loc lab_id ctyp in
          let ctyp = strip_field_flags ctyp in
          begin match sem with
          | { leftovers = true; _ }-> 
              labs, (lab_id, <:expr< `Ok unknown_fields >>) :: st, Some lab_id
          | { name; optional = true; _ } -> 
              let conv = gen_ctyp ctyp in
              name :: labs,
              (lab_id, 
               <:expr< Meta_conv.Internal.field_assoc_optional $str:ty_name$ __value __address $str:name$ fields $conv$ >>)
              :: st,
              rest
          | { name; _ } -> 
              let conv = gen_ctyp ctyp in
              name :: labs,
              (lab_id, 
               <:expr< Meta_conv.Internal.field_assoc $str:ty_name$ __value __address $str:name$ fields $conv$ >>)
              :: st,
              rest
          end
      | _ -> assert false) ctyps ([], [], None)
    in
    let unknown_fields_check = match annot.field_check, rest with
      | None, Some _ -> failwith "Ignore_unknown_fields and Leftovers cannot be specified at the same time"
      | None, _ | Some _, Some _ -> <:expr< Meta_conv.Internal.record_ignore_unknown_fields >>
      | Some e, _ -> e
    in
    let the_record = 
      let final = create_record (List.map (fun (id, _) -> id, expr_of_id id) fields) in
      binds (List.map fst fields) (List.map snd fields) final
    in
    
    let labels = create_list (List.map (fun x -> <:expr< $str:x$ >>) labels) in
    <:expr< fun ?adrs:(__address=Meta_conv.Types.Address.top) __value -> 
      let valid_labels = $labels$ in
      let fields = $id:module_path$.Decode.record (__value, __address) in 
      let unknown_fields = Meta_conv.Internal.filter_record_fields valid_labels fields in
      $unknown_fields_check$ $str:ty_name$ __value __address unknown_fields (fun () -> 
        $the_record$) 
    >>
    
  (** for [X; Y; .. ], Z and BASE, build (X,BASE) Decoder.t -> (Y,BASE) Decoder.t -> ...... -> (Z,BASE) Decoder.t *)
  let dispatch_type params base z = 
    List.fold_right (fun ctyp st -> <:ctyp< ($ctyp$, $base$) Meta_conv.Types.Decoder.t -> $st$ >>) 
      params <:ctyp< ($z$,$base$) Meta_conv.Types.Decoder.t >>
  
  let dispatch_type_exn params base z = 
    List.fold_right (fun ctyp st -> <:ctyp< ($ctyp$, $base$) Meta_conv.Types.Decoder.t -> $st$ >>) 
      params <:ctyp< ($z$,$base$) Meta_conv.Types.Decoder.t_exn >>
  
  let func_type params name = 
    create_for_all params (dispatch_type params 
       <:ctyp< $id:target_type_path$ >>
       (create_param_type params name))
  
  let func_type_exn params name = 
    create_for_all params (dispatch_type_exn params 
       <:ctyp< $id:target_type_path$ >>
       (create_param_type params name))
  
  (******************* kind of template *)
  
  let def name loc cty =
    let variants _ = assert false in
    let mani     _ = assert false in
    let nil      _ = assert false in
    let alias  = alias name loc in
    let sum    = sum name loc in
    let record = record name loc in
    Gen.switch_tp_def ~alias ~sum ~record ~variants ~mani ~nil cty
  
  
  let dcl _loc name (params : ctyp list) d =
    <:binding<
      $lid: name ^ "_of_" ^ A.conv_name$ : $func_type params name$ = 
        $Gen.abstract _loc (List.map patt_of_tvar params) (def name _loc d)$
    >>, 
    <:binding<
      $lid: name ^ "_of_" ^ A.conv_name ^ "_exn"$ : $func_type_exn params name$ = 
        $Gen.abstract _loc (List.map patt_of_tvar params) <:expr<
          fun ?adrs v -> 
            match $ Gen.apply _loc <:expr< $lid: name ^ "_of_" ^ A.conv_name$ >> (List.map expr_of_tvar params)$ ?adrs v with
            | `Ok v -> v
            | `Error (e, v, adrs) -> raise ($id:module_path$.Error (e, v, adrs))
        >> $
    >>
  
  (* Add "of_sexp" and "sexp_of" as "sexp" to the set of generators *)
  let str = fun rec_ tds ->
      let _loc = Ast.loc_of_ctyp tds in
      let decls = list_of_ctyp tds [] in (* CR jfuruse: mutual *)
      let recursive = type_definitions_are_recursive rec_ tds in
      let binds = List.map (function
        | TyDcl (loc, name, params, def, _constraints) -> 
            dcl loc name params def
        | _ -> assert false) decls
      in
      [ create_top_let recursive (List.map fst binds);
        create_top_let recursive (List.map snd binds) ]

  let dcl_sg _loc name (params : ctyp list) _d =
    <:sig_item<
      val $lid: name ^ "_of_" ^ A.conv_name$ : $func_type params name$
      val $lid: name ^ "_of_" ^ A.conv_name ^ "_exn"$ : $func_type_exn params name$
    >>
  
  let sg = fun _rec_ tds ->
      let _loc = Ast.loc_of_ctyp tds in
      let decls = list_of_ctyp tds [] in
      let items = List.map (function
        | TyDcl (loc, name, params, def, _constraints) -> 
            dcl_sg loc name params def
        | _ -> assert false) decls
      in
      concat_sig_items items

end
  
let error () = 
  failwith "meta_conv needs arguments: \n\
(name_ident, type_path, module_path) \n\
(name_ident, type_path)              (* module_path is deduced from type_path *) \n\
(name_ident)                         (* type_path and module_path are deduced from name_ident)\n\
\n\
For example, conv(json, Json.t, Json_conv), conv(json, Json.t) and conv(json) work as same."


let deduce_module_from_type = 
  let rec add_conv = function
    | IdAcc (loc, id1, id2) -> IdAcc(loc, id1, add_conv id2)
    | IdUid (loc, name) -> IdUid (loc, name ^ "_conv")
    | IdApp (_loc, _, _) | IdLid (_loc, _) | IdAnt (_loc, _) -> 
        failwith "meta_conv: illegal type_path"
  in
  let rec f = function
    | IdAcc (_, id1, IdLid (_, _)) -> add_conv id1
    | IdAcc (loc, id1, id2) -> IdAcc (loc, id1, f id2)
    | IdLid _ -> IdUid (_loc, "Conv")
    | IdApp (_loc, _, _) -> 
        failwith "meta_conv: impossible to deduce module_path from this form of type_path"
    | IdUid (_loc, _) | IdAnt (_loc, _) -> 
        failwith "meta_conv: illegal type_path"
  in
  f 

let parse_name name =
  let prefix s = 
    try 
      let lens = String.length s in
      let lenrest = String.length name - lens in
      let pre = String.sub name 0 lens in
      let rest = String.sub name lens lenrest in
      if pre = s then Some rest else None with _ -> None
  in
  let postfix s = 
    try 
      let lens = String.length s in
      let lenrest = String.length name - lens in
      let post = String.sub name lenrest lens in
      let rest = String.sub name 0 lenrest in
      if post = s then Some rest else None with _ -> None
  in
  match prefix "of_", postfix "_of" with
  | None, None -> name, [`Encode; `Decode]
  | Some v, None -> v, [`Decode]
  | None, Some v -> v, [`Encode]
  | _ -> failwith "You really want to have of_xxx_of thing???"

let deduce_type_from_name name = 
  IdAcc (_loc, IdUid (_loc, String.capitalize name), IdLid (_loc, "t"))

let parse_arg = function
  | <:expr< ( $lid:name$, $id:type_$, $id:module_$ ) >> ->
      let name, dirs = parse_name name in
      (name, dirs, type_, module_)
  | <:expr< ( $lid:name$, $id:type_$ ) >> ->
      let name, dirs = parse_name name in
      (name, dirs, type_, deduce_module_from_type type_)
  | <:expr< ( $lid:name$ ) >> ->
      let name, dirs = parse_name name in
      let type_ = deduce_type_from_name name in
      let module_ = deduce_module_from_type type_ in
      (name, dirs, type_, module_)
  | _ -> error ()

let parse_argopt = function
  | Some arg -> parse_arg arg
  | None -> error ()

let () = 
  Pa_type_conv.add_generator_with_arg "conv" Syntax.expr (fun argopt rec_ tds ->
    let (name, dirs, type_, module_) = parse_argopt argopt in
    let module A = struct 
      let target_type_path = type_
      let module_path = module_
      let conv_name = name
    end in
    let module Encode = Encode(A) in
    let module Decode = Decode(A) in
    
    concat_str_items
      ( (if List.mem `Encode dirs then [Encode.str rec_ tds] else [])
        @ (if List.mem `Decode dirs then Decode.str rec_ tds else []) ));

  Pa_type_conv.add_sig_generator_with_arg "conv" Syntax.expr (fun argopt rec_ tds ->
    let (name, dirs, type_, module_) = parse_argopt argopt in
    let module A = struct 
      let target_type_path = type_
      let module_path = module_
      let conv_name = name
    end in
    let module Encode = Encode(A) in
    let module Decode = Decode(A) in
    
    concat_sig_items 
      ( (if List.mem `Encode dirs then [Encode.sg rec_ tds] else [])
        @ (if List.mem `Decode dirs then [Decode.sg rec_ tds] else []) ))
