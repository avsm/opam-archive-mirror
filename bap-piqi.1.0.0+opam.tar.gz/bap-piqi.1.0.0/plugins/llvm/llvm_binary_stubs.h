#include "caml/mlvalues.h"

#ifdef __cplusplus 
extern "C" {
#endif

    value llvm_binary_create_stub(value);
    value llvm_binary_arch_stub(value);
    value llvm_binary_entry_stub(value);
    value llvm_binary_segments_stub(value);
    value llvm_binary_symbols_stub(value);
    value llvm_binary_sections_stub(value);

#ifdef __cplusplus 
}
#endif
