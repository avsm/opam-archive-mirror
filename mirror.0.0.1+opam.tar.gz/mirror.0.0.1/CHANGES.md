1.0.0 (2015-02-15):
* Initial public release.
