A simple library to handle subcommand arguments.

Library initially written by Sylvain le Gall
(for [oasis](http://oasis.forge.ocamlcore.org/)) and later
updated by Sergei Lebedev
(for [barbra](https://github.com/camlunity/barbra)). 

I've just made it self-contained to make it easier to use.
No ocamlfind package yet.


