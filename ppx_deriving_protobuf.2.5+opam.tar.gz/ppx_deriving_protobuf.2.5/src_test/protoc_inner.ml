type foo = int
[@@deriving protobuf { protoc }]
