## 111.17.00

- Exposed `Patience_diff.matches`.

## 111.13.00

- Moved `Patience_diff` out of `Core_extended` into its own library
  depending only on `Core_kernel`.

