# Build tracedump utility:

```
bapbuild tracedump.native
```
