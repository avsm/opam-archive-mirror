let version = "1.0.1"
let date = "Mon Feb 9 15:11:56 CET 2015"
let libdir = "/usr/local/lib/cubicle"
