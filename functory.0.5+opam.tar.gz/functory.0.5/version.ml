let version = "0.5"
let date = "Tue Mar 5 17:34:53 CET 2013"
