(* OASIS_START *)
(* DO NOT EDIT (digest: 517254fd407fd9b404639e19e8c9f2b4) *)
This is the README file for the ocamlmod distribution.

Generate OCaml modules from source files

See the files INSTALL.txt for building and installation instructions. 


(* OASIS_STOP *)
