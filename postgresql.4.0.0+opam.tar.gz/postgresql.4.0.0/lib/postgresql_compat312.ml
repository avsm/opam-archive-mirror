let buffer_add_subbytes = Buffer.add_substring
