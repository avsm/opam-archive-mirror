let n="0.24"
let d="Thu Jan 30 17:54:39 GMT 2014"
