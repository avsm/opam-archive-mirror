CFStream Release Notes

cfstream-1.1.2 2014-07-02
-------------------------
* #3: Fix bug in `drop`.
* Reduced dependency to core_kernel instead of core.

cfstream-1.1.1 2014-03-02
-------------------------
* Fix doc build bug.

cfstream-1.1.0 2014-03-02
-------------------------
* Provide concat_map.
* New About module.

cfstream-1.0.0 2013-08-09
-------------------------
* First release.
