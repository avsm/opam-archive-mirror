## OCaml bindings to OS X generic file system attribute system calls

These bindings use [ctypes](https://github.com/ocamllabs/ocaml-ctypes)
for type-safe stub generation.
