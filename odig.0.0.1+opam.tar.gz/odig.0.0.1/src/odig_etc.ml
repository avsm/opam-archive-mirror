
(* This file is overwritten by the configuration process. During
   development it will work if you invoke the odig binary
   from the root directory of the repository. *)

let dir = Fpath.v "etc"
