let package_name = "ppx_optcomp"

let sections =
  [ ("lib",
    [ ("built_lib_ppx_optcomp", None)
    ],
    [ ("META", None)
    ])
  ]
