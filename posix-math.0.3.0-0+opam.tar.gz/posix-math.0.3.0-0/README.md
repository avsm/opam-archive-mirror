# POSIX math

This library provides access to the POSIX math functions, including complex numbers.

The source code of time is available under the MIT license.

This library is originally written by [Markus Weissmann](http://www.mweissmann.de/)
