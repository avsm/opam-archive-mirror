Files c11_*.cat are C11 models from

Overhauling SC atomics in C11 and OpenCL.
M. Batty, A. Donaldson, J. Wickerson. In Proc.
43rd ACM SIGPLAN-SIGACT Symposium on Principles of Programming Languages (POPL), 2016. 

Rewritten by Luc Maranget for herd7


