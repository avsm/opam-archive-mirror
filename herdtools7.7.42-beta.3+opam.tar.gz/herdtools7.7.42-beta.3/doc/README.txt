This is the source of diy documentation.

Dependencies.
- diy should be present and installed on the system
Additionaly
- rubber
- hevea
- dot (graphviz)
- fig2dev (transfig)
