(* OASIS_START *)
(* DO NOT EDIT (digest: 1f3c9fa67e8302b3d505a8fdb4871cbd) *)
This is the README file for the aws distribution.

aws client lib for amazon web services

See the files INSTALL.txt for building and installation instructions. 


(* OASIS_STOP *)
