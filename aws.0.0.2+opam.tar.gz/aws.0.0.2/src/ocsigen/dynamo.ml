module M = Dynamo_factory.Make (Ocsigen_HC)

include M
