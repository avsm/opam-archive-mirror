module M = S3_factory.Make (Http_client10)

include M
