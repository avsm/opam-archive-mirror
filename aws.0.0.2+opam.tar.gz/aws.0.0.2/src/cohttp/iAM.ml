module M = IAM_factory.Make (Http_client10)

include M
