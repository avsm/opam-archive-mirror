module M = EC2_factory.Make (Http_client10)

include M
