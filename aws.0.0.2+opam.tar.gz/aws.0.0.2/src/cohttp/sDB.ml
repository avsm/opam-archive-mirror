module M = SDB_factory.Make (Http_client10)

include M
