#!/bin/bash -xue

/opt/qbase3/qshell -c "
i.qp.updateAll()
"
