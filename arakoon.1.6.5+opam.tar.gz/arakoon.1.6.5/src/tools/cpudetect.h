#ifndef _CPUDETECT_H_
#define _CPUDETECT_H_

extern int has_sse_2;
extern int has_sse_3;
extern int has_sse_4_2;


#endif
