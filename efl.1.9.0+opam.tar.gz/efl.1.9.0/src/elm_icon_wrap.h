#ifndef ICON_H
#define ICON_H

#include "include.h"

inline Elm_Icon_Lookup_Order Elm_Icon_Lookup_Order_val(value v);
inline value Val_Elm_Icon_Lookup_Order(Elm_Icon_Lookup_Order order);

#endif
