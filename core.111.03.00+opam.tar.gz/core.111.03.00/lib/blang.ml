include Core_kernel.Blang
