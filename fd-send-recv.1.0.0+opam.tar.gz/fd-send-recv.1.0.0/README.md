ocaml-fd-send-recv
==================

Bindings which allow Unix.file_descrs to be sent and received over Unix domain sockets