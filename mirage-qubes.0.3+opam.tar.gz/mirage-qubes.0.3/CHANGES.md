### 0.3 (2016-05-14)

- Replace camlp4 with ppx. Cstruct no longer supports camlp4.

- Require a modern vchan in opam metadata.

- Less verbose logging from RExec.

- Disconnect qrexec clients if handshake fails.
