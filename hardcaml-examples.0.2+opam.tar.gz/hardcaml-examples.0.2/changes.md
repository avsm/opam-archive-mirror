# v0.2

* integrate llvmsim and vpi cosim

# v0.1

* hardcaml core generation and simulation framework
* examples; sort, prefix, mul, lfsr, cordic, rac
