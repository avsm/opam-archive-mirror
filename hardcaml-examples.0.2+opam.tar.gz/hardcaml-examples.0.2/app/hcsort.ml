module A = App.Make(HardCamlExamples.Sorting.Design)

