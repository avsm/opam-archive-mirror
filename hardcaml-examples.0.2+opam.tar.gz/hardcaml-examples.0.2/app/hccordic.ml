module A = App.Make(HardCamlExamples.Cordic.Design)

