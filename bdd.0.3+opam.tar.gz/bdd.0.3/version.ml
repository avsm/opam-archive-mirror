let version = "0.2"
let date = "Thu Feb 4 16:08:12 CET 2010"
