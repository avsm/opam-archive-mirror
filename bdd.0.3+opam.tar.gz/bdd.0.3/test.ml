(**************************************************************************)
(*                                                                        *)
(*  Copyright (C) Jean-Christophe Filliatre                               *)
(*                                                                        *)
(*  This software is free software; you can redistribute it and/or        *)
(*  modify it under the terms of the GNU Library General Public           *)
(*  License version 2, with the special exception on linking              *)
(*  described in file LICENSE.                                            *)
(*                                                                        *)
(*  This software is distributed in the hope that it will be useful,      *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                  *)
(*                                                                        *)
(**************************************************************************)

#load "bdd.cmo";;
open Bdd;;

#load "parser.cmo";;
#load "lexer.cmo";;

let p s = 
  let lb = Lexing.from_string s in
  match Parser.file Lexer.token lb with
    | f :: _ -> f
    | _ -> assert false 
;;

let bdd_of_formula f =
  let nbvar = ref 0 in
  let vars = Hashtbl.create 17 in
  let rec trans = function
    | Prop.Pvar s ->
	Fvar (try Hashtbl.find vars s 
	      with Not_found -> incr nbvar; Hashtbl.add vars s !nbvar; !nbvar)
    | Prop.Pnot f -> Fnot (trans f)
    | Prop.Pand (f1, f2) -> Fand (trans f1, trans f2)
    | Prop.Por (f1, f2) -> For (trans f1, trans f2)
    | Prop.Pimp (f1, f2) -> Fimp (trans f1, trans f2)
    | Prop.Piff (f1, f2) -> Fiff (trans f1, trans f2)
    | Prop.Ptrue -> Ftrue
    | Prop.Pfalse -> Ffalse
  in
  let f = trans f in
  set_max_var !nbvar;
  build f
;;

let test s = view (bdd_of_formula (p s));;
let count s = count_sat (bdd_of_formula (p s));;

let display b =
  print_to_dot b ~file:"test.dot";
  ignore (Sys.command "dot -Tps test.dot | gv -");;

let test2 s = 
  let b = bdd_of_formula (p s) in
  display b;;

let r = test2 "(A -> B) -> (B -> A)";;

let r = test "(a1<->a2)<->(a2<->a1)";;
let r = test "A \\/ ~A";;
let r = test "A -> ~~A";;
let r = test "A -> A";;
let r = test "((A -> B) -> A) -> A";;
let r = test "(A -> B)-> (~B -> ~ A)";;
let r = test "((A -> B) /\\ A) -> B";;
let r = test "((A -> B) /\\ ~ B) -> ~ A";;
let r = test "((A -> B) /\\ (B -> C)) -> (A -> C)";;
let r = test "(A /\\ (B \\/ C)) -> ((A /\\ B) \\/ (A /\\ C))";;
let r = test "((A /\\ B) \\/ (A /\\ C)) -> (A /\\ (B \\/ C))";;
let r = test "(A \\/ (B /\\ C)) -> ((A \\/ B) /\\ (A \\/ C))";;
let r = test "((A \\/ B) /\\ (A \\/ C)) -> (A \\/ (B /\\ C))";;
let r = test "(~ A -> A) -> A ";;
let r = test "((P -> (Q /\\ R /\\ S)) /\\ ~S) -> ~P";;
let r = test "(P /\\ Q) -> (Q /\\ P)";;
let r = test "(A /\\ A) \\/ ~A";;
let r = test "~~A <-> A";;
let r = test "~(A /\\ B) <-> (~A \\/ ~B)";;
let r = test "~(A \\/ B) <-> (~A /\\ ~ B)";;
let r = test "(A \\/ (B /\\ C)) <-> ((A \\/ B) /\\ (A \\/ C))";;
let r = test "(A /\\ (B \\/ C)) <-> ((A /\\ B) \\/ (A /\\ C))";;

let r = test "((b <-> c) -> (a/\\b/\\c)) /\\ 
((c<->a)->(a/\\b/\\c)) /\\ ((a<->b)->(a/\\b/\\c)) -> (a/\\b/\\c)";;

let r = test "~ ~(~p1 \\/ ~p2 \\/ ~p3 \\/ (p1 & p2 & p3))";;

let de_bruijn_p_2 = test "
(((((p1 -> p2) & (p2 -> p1)) -> (p1 & (p2 & (p3 & (p4 & p5))))) & ((((p2 ->
p3) & (p3 -> p2)) -> (p1 & (p2 & (p3 & (p4 & p5))))) & ((((p3 -> p4) & (p4 ->
p3)) -> (p1 & (p2 & (p3 & (p4 & p5))))) & ((((p4 -> p5) & (p5 -> p4)) ->
(p1 & (p2 & (p3 & (p4 & p5))))) & (((p5 -> p1) & (p1 -> p5)) -> (p1 & (p2 &
(p3 & (p4 & p5))))))))) -> (p1 & (p2 & (p3 & (p4 & p5)))))";;

#use "bench_prop.ml";;
#install_printer print;;
let test_de_bruijn_p n = view (bdd_of_formula (de_bruijn_p n));;
let test_de_bruijn_n n = view (bdd_of_formula (de_bruijn_n n));;

let r = test2 "A -> (A -> ~ A)";;
let r = test2 "A /\\ ~A";;
let r = test2 "(A \\/ B) /\\ ~A /\\ ~B";;
let r = test2 "(A -> B) -> (~A -> ~B)";;
let r = test2 "(A -> B) -> (B -> A)";;
let r = test2 "B -> (B /\\ A)";;
let r = test2 "(A -> A) <-> A";;

let () = display (bdd_of_formula (de_bruijn_n 5));;
