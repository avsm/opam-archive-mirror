(**************************************************************************)
(*                                                                        *)
(*  Copyright (C) Jean-Christophe Filliatre                               *)
(*                                                                        *)
(*  This software is free software; you can redistribute it and/or        *)
(*  modify it under the terms of the GNU Library General Public           *)
(*  License version 2, with the special exception on linking              *)
(*  described in file LICENSE.                                            *)
(*                                                                        *)
(*  This software is distributed in the hope that it will be useful,      *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                  *)
(*                                                                        *)
(**************************************************************************)

open Format
open Prop
open Bdd

module Time = struct
  
  open Unix
    
  let utime f x =                                                   
    let u = (times()).tms_utime in                                  
    let y = f x in
    let ut = (times()).tms_utime -. u in
    (y,ut)
      
  let print_utime f x = 
    let (y,ut) = utime f x in
    printf "user time: %2.2f@." ut;
    y
      
end

let bdd_of_formula f =
  let nbvar = ref 0 in
  let vars = Hashtbl.create 17 in
  let rec trans = function
    | Pvar s ->
	Fvar 
	  (try Hashtbl.find vars s 
	   with Not_found -> incr nbvar; Hashtbl.add vars s !nbvar; !nbvar)
    | Pnot f -> Fnot (trans f)
    | Pand (f1, f2) -> Fand (trans f1, trans f2)
    | Por (f1, f2) -> For (trans f1, trans f2)
    | Pimp (f1, f2) -> Fimp (trans f1, trans f2)
    | Piff (f1, f2) -> Fiff (trans f1, trans f2)
    | Ptrue -> Ftrue
    | Pfalse -> Ffalse
  in
  let f = trans f in
  set_max_var !nbvar;
  build f

let nb = ref 0

let sat_unsat f =
  incr nb;
  let b = bdd_of_formula f in
  printf "%d: %s " !nb (if tautology b then "valid" else "invalid")

let check = Time.print_utime sat_unsat
  
let () =
  let lb = Lexing.from_channel stdin in
  let fl = Parser.file Lexer.token lb in
  List.iter check fl

let () = 
  Array.iter
    (fun (l,n,s,b1,b2,b3) ->
       printf "table length: %d / nb. entries: %d / sum of bucket length: %d@."
	 l n s;
       printf "smallest bucket: %d / median bucket: %d / biggest bucket: %d@."
	 b1 b2 b3)
    (stats ())


