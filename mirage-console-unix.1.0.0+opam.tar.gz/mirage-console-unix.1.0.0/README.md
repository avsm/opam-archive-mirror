This library implements portable support for a console ring.

The following sources are used:

* The Unix version uses the standard output.
* The Xen version uses the paravirtual console device.
