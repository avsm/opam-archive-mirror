v0.2.0 2015-05-20 La Forclaz (VS)
---------------------------------

* The `Rresult_infix` module no longer exists. Open directly `Rresult`
  for using the library.



v0.1.0 2015-03-19 La Forclaz (VS)
---------------------------------

First release.
