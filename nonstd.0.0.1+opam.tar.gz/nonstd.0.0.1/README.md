Non-standard Mini-Library
=========================

Everybody start writing their own standard library … this one is extremely
minimalistic:

- `val (|>)`,
- `include Printf`,
- one `List` module (similar to [Core](http://github.com/janestreet/core)'s one),
- `Array` is `ArrayLabels`,
- minimalistic `Option` module,
- `Int` and `Float` modules.

and that's all, no dependencies, no blobs.

