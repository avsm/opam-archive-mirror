Atdgen uses type definitions in the ATD syntax and generates
efficient [JSON](http://json.org) serializers, deserializers and
validators for OCaml.

Installation
------------

```
$ opam install atdgen
```

Documentation
-------------

https://mjambon.github.io/atdgen-doc/


How to contribute
-----------------

See https://github.com/mjambon/documents/blob/master/how-to-contribute.md
