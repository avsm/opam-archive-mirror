fstar  $1 2>/dev/null | grep "All verif"
