open LallocTest

let _ = 
	print_int (lallocExample1 1 2)

;;