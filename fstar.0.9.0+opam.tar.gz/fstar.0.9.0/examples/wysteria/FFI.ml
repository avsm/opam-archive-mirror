open AST

let exec_ffi _ _ = D_v (Meta ((FStar_OrdSet.empty ()), Can_b, (FStar_OrdSet.empty ()), Can_w), (V_const C_unit))
