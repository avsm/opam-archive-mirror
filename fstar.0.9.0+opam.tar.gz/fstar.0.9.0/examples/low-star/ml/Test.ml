


let test () =
  print_string "Begining test...\n";
  Demo.demo ()

let _ =
  print_string "Beginning test...\n";
  Demo.demo ();
  print_string "\nEnd of test\n"
