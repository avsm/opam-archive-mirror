OByteLib
========

OCaml bytecode library tools.
Usefull to read, write and evaluate OCaml bytecode files.
