<rect option:square />
