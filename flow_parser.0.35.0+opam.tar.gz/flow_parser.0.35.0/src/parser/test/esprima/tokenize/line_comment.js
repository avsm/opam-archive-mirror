var answer = 42  // the Ultimate
