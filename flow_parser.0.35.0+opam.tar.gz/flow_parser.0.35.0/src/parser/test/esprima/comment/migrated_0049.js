/**
 * @type {number}
 */
var a = 5;
