var x = /[\uD834\uDF06-\uD834\uDF08a-z]/u
