(* TestCompare -- Test compare

   Mixture (https://github.com/michipili/mixture)
   This file is part of Mixture

   Copyright © 2013–2015 Michael Grünewald

   This file must be used under the terms of the CeCILL-B.
   This source file is licensed as described in the file COPYING, which
   you should have received as part of this distribution. The terms
   are also available at
   http://www.cecill.info/licences/Licence_CeCILL-B_V1-en.txt *)

module PlayingCard =
struct
  type card =
  | Card of regular
  | Joker
  and regular = { suit : card_suit; name : card_name; }
  and card_suit = Heart | Club | Spade | Diamond
  and card_name =  Ace | King | Queen | Jack | Simple of int

  module Basis =
  struct
    type t = card
    let compare = Pervasives.compare
  end

  module CompareMethods =
    Mixture_Compare.Make(Basis)

  include Basis
  include CompareMethods
end
