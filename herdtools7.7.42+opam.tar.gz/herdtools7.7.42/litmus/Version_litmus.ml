include Version

let libdir = libdir ^ "litmus"
