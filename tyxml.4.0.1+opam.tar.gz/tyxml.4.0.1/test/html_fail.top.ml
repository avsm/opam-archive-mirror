#use "topfind" ;;
#require "uutf" ;;
#require "re" ;;
#directory "lib" ;;
#directory "implem" ;;
#load "tyxml_f.cma" ;;
#load "tyxml.cma" ;;

open Tyxml.Html ;;

div [a [a []]] ;;
