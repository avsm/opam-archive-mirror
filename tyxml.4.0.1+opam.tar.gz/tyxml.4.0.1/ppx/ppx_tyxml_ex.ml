
let () = Ast_mapper.register "tyxml" Ppx_tyxml.mapper
