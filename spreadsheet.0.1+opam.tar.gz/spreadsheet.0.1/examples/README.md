examples
========

A few example spreadsheets demonstrating hopeful use-cases.
Running `make` in each folder should compile the example.

- `beaches` columns are primitive data
- `pet_names` one column is a list
- `phone_book` columns are user-defined types

