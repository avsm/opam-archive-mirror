beaches
=======

An inaccurate spreadsheet of Cape Cod beaches.

Running `main.ml` will parse `beaches.tab`, add a row to the dataset,
and write the modified data to a file `beaches2.tab`.

The written data will be sorted and include a new row.
