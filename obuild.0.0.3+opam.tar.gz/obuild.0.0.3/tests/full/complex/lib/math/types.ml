type t = { real : int ; imag : int }
