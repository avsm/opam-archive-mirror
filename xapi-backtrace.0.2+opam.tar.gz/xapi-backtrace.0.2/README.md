backtrace
=========

Helper functions to preserve and transport exception backtraces
