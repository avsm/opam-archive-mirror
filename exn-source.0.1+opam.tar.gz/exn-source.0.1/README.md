exn-source
==========

Exception backtrace for OCaml with source code printing.

To build
--------

Run `make`. Now, `make install` will install it. Run `examples/make` to build
the example.

To use
------

Use the package `exnsource` when compiling your program. Compile and link with
`-g` and run with `OCAMLRUNPARAM=b` as usual.

Full instructions
-----------------

See the built documentation, in `doc/exnsource/html/index.html`.

