1;;

(**
       0 CONST1 
       1 ATOM0 
       2 SETGLOBAL T010-const1
       4 STOP 
**)
