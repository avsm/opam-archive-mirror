(* PR#5835 *)

let f ~x = x + 1;;
f ?x:0;;
