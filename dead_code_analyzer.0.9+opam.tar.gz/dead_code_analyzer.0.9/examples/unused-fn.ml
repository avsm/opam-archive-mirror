let f x = 32 + x

let g x = f x - 32

let var = f 1
