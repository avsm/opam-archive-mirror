let x = Foo.x
