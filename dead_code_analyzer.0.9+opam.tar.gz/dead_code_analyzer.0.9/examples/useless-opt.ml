let foo ?(a = []) () = None

let x = foo ~a:[] ()
