module M = Func.M ( )

include M

let () = let o = new c in o#f
