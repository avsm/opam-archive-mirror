print_string [%blob "quine.ml"]
