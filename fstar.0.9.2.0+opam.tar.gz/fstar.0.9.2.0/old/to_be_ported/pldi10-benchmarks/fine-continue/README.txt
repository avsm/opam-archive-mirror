In order to compile this program, you need to set the FINE_COMPILER
environment variable to the name of the fine.exe executable on your
machine. The run "make" from this directory.