module FStar.Version

let version = "unknown version"

let platform = "unknown platform"

let compiler = "unknown compiler"

let date = "unknown date"

let commit = "unknown commit"
