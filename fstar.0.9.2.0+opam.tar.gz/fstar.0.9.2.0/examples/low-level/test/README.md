Some test drivers
=================

These OCaml drivers link to the OCaml-extracted fst files and run benchmarks.
