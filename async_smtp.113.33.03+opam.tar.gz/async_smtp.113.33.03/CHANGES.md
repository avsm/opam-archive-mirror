## 113.33.00

- Allow an smtp\_client to connect to a local unix socket

- Better logging

## 113.24.00

- Switched to PPX.

- Follow Core & Async evolution.

## 113.00.00

- Improve the async\_smtp client interface so that it is suitable as a
  replacement for Core\_extended.Std.Sendmail.

## 112.17.00

Moved from janestreet-alpha

