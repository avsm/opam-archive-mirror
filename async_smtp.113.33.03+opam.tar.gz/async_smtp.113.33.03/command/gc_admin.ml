open! Core.Std
open Async.Std
open Async_smtp.Std
open Common

let gc_command summary rpc =
  Command.rpc ~summary
    Command.Spec.empty
    (fun client ->
       Rpc.Rpc.dispatch_exn rpc client ()
       >>| fun () ->
       printf "OK\n"
    )
;;

let gc_stat_command summary rpc =
  Command.rpc ~summary
    Command.Spec.empty
    (fun client ->
       Rpc.Rpc.dispatch_exn rpc client ()
       >>| fun stat ->
       printf !"%{sexp:Gc.Stat.t}\n" stat
    )
;;

let stat       = gc_stat_command "Gc.stat"       Smtp_rpc_intf.Gc.stat
let quick_stat = gc_stat_command "Gc.quick_stat" Smtp_rpc_intf.Gc.quick_stat

let full_major = gc_command "Gc.full_major" Smtp_rpc_intf.Gc.full_major
let major      = gc_command "Gc.major"      Smtp_rpc_intf.Gc.major
let minor      = gc_command "Gc.minor"      Smtp_rpc_intf.Gc.minor
let compact    = gc_command "Gc.compact"    Smtp_rpc_intf.Gc.compact

let command =
  Command.group ~summary:"GC management"
    [ "stat"        , stat
    ; "quick-stat"  , quick_stat
    ; "full-major"  , full_major
    ; "major"       , major
    ; "minor"       , minor
    ; "compact"     , compact
    ]
;;
