#!/bin/bash

obuild configure
./build.sh

