/* @flow */

class ClassFoo6 {};

export default ClassFoo6;
