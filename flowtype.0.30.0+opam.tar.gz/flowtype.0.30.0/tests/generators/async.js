/* TODO: Support async iteration
 * See: https://github.com/zenparsing/async-iteration/#async-generator-functions
 */
async function *unsupported() {}
