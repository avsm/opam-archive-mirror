/* @providesModule A */
class Implementation {}
export function foo(): Implementation { return new Implementation; }
