var APIKeys = {
    AGE: 'age',
    NAME: 'name',
};

module.exports = APIKeys;
