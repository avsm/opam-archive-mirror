/**
 * @flow
 */
// one error here, to verify lib errors sort to top.
var x: string = 0;
