var o = require('./test5');
(o.hello: 'nothing'); // oops
