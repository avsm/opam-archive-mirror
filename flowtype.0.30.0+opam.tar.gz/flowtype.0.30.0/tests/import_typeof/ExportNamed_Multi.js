// @flow

export var num = 42;
export var str = 'asdf';
