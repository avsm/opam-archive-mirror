// @flow

export var name: "otherdir/testproj2" = "otherdir/testproj2";
