// @flow
var agelimit: number = adult;
var another_attempt: number = adult.minage;
var tom : adult = new adult();
