(* OASIS_START *)
(* OASIS_STOP *)

Ocamlbuild_plugin.mark_tag_used "tests";;

Ocamlbuild_plugin.dispatch dispatch_default;;

