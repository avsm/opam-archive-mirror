let foo = "B.C.foo"
let test = A.foo
