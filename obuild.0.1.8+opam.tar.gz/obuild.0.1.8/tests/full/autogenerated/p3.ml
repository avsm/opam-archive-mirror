open Path_generated
open Printf

let () =
    printf "project version is : %s\n" project_version
