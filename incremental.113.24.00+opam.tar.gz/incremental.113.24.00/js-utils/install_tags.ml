let package_name = "incremental"

let sections =
  [ ("lib",
    [ ("built_lib_incremental_lib", None)
    ],
    [ ("META", None)
    ])
  ]
