## 113.24.00

- Add README.org to Incremental.

- Added some type annotations based on comments by @def-lkb about lack of
  principality.

- Switched to ppx.
