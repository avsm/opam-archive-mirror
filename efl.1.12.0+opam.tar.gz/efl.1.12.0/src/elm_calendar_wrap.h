#include "include.h"

inline Elm_Calendar_Selectable Elm_Calendar_Selectable_val_list(value v);
inline value copy_Elm_Calendar_Selectable(Elm_Calendar_Selectable s);

