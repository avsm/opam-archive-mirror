open Common

let funs = [
  simple_unit "group_add" [evas_object; evas_object];
  prop "state_value" int;
  prop "value" int;
]

