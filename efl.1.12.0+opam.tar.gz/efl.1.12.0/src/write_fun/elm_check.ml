open Common

let funs = [
  prop "state" bool;
]

