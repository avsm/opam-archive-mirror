open Common

let pos = simple_ty "Elm_Bubble" "Pos"

let funs = [
  prop "pos" pos;
]

