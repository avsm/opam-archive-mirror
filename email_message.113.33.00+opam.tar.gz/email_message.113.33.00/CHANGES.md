## 113.24.00

- Bugfixes and minor API improvements.

## 113.00.00

- Extended and improved Email_message API.

## 112.17.00

Moved from janestreet-alpha

