<b>Resources for learning OCaml</b><br />
<a class="th" href="http://ocaml.org/docs/">
  <img src="graphics/rwo-coversmall.png" />
</a>
