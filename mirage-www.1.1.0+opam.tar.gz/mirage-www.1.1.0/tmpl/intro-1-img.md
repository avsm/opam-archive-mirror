<b>Try Mirage out</b><br />
<a class="th" href="#">
  <img src="graphics/cumulous-cruisin.jpg"> </img>
</a>
