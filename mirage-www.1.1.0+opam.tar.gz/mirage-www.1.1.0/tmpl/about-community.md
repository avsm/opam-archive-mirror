### Contributors

* *Vincent Bernardoff*, [github.com](https://github.com/vbmithr)
* *Amir Chaudhry*, University of Cambridge, [amirchaudhry.com](http://amirchaudhry.com)
* *Jon Crowcroft*, University of Cambridge, [cl.cam.ac.uk](http://www.cl.cam.ac.uk/~jac22/)
* *Steven Hand*, [cl.cam.ac.uk](http://www.cl.cam.ac.uk/~smh22/)
* *Jon Ludlam*, Citrix Systems R&D, [jon.recoil.org](http://jon.recoil.org/)
* *Raphael Proust*, University of Cambridge, [cl.cam.ac.uk](http://www.cl.cam.ac.uk/~rp452/)
* *Haris Rotsos*, University of Cambridge, [cl.cam.ac.uk](http://www.cl.cam.ac.uk/~cr409/)
* *David Sheets*, University of Cambridge, [github.com](https://github.com/dsheets)
* *Balraj Singh*, University of Cambridge, [github.com](https://github.com/balrajsingh)
* *Thomas Leonard*, University of Cambridge, [github.com](https://github.com/talex5)
