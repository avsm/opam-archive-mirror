[![Build Status](https://travis-ci.org/mirage/mirage-www.png?branch=master)](https://travis-ci.org/mirage/mirage-www)

# Mirage Website

This repository contains the Mirage public website, <http://openmirage.org/>.

It provides information about the project as well as the blog and wiki.

It also serves as a good first self-hosting test case.
