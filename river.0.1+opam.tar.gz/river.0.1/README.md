# ocaml-planet

A library for aggregating RSS2 and Atom feeds in OCaml.

Features:

* Performs deduplication.
* Sorts the posts from most recent to oldest.
* Supports pagination and generating well-formed html prefix snippets.
* Depends on ocamlnet for html parsing.
