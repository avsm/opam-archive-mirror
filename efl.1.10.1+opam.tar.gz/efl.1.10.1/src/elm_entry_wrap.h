#ifndef ELM_ENTRY_H
#define ELM_ENTRY_H

#include "include.h"

#endif

