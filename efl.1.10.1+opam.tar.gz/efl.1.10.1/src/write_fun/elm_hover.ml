open Common

let funs = [
  simple_unit "target_set" [evas_object; evas_object];
  simple_unit "parent_set" [evas_object; evas_object];
  simple_unit "dismiss" [evas_object]
]

