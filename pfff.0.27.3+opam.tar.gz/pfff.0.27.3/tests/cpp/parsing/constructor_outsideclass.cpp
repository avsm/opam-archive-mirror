Foo::Foo() 
{
}

inline Foo::Foo() 
{
}
