
//Ipv4Address::operator socklen_t()
//{
// 	return sizeof(struct sockaddr_in);
//}
