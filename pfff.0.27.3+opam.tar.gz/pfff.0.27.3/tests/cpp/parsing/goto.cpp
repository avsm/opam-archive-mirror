void main() {

  goto bad;
bad: 
  return 1;
}
