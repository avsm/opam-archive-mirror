void main() {
  vector<int> x;
  vector<foo> x;
}

void main() {
  std::vector<int> x;
  std::vector<foo> x;
}

void main() {
  std::vector<std::string> x;
}

void main() {
  std::vector<StringPiece const*> buffers;
}

void main() {
 map<string, set<string> >::iterator iter;
}

static facebook::concurrency::ThreadLocal<unsigned int> state;

