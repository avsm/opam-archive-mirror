
#define cp 1

extern int buf;

int xopen();

