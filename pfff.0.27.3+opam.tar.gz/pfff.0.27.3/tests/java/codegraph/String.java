package java.lang;

class String {
  public static a_string_method() { }
}
