package X;

import some.deep.pak.AClass;

class NotFoundButQualified {

  AClass x;
}