package X;

import java.util.List;

class ImportQualified {
  public List<Object> x;
}