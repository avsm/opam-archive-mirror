class AmbiguousLessThan {

  boolean foo(int i, int j) {
    //Array<Int> x;
    i<j;
  }

}