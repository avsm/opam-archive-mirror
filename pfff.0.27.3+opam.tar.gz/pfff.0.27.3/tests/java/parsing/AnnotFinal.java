class X {

     public boolean onInterceptTouchEvent(MotionEvent ev) {
         @SuppressWarnings("all") // suppress dead code warning

         final boolean debug = false;
     }
}

