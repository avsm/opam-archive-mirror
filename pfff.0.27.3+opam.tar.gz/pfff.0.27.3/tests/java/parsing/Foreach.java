
class Foreach {
  void main() {
    for (Object v : val) {
    }
  }
}

//BAD:!!!!!     for (FormBodyPart part : this.multipart.getBodyParts()) {
//BAD:!!!!!             for (String path : new String[]{"/", "/home.php", "/search/uberbar"}) {
//BAD:!!!!!         for (ImageView currentImage : images) {
//BAD:!!!!!       for (Signature signature : signatures) {
