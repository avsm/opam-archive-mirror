class Test {

  public void start(String operationType, @Nullable Bundle param) {
  }
  public View renderView(Context context, @Nullable final View view) {
  }
}

