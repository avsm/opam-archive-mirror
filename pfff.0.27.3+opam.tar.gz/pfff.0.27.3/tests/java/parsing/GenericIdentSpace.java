class X {
  void main() {
    List <Int> x;
  }
}
