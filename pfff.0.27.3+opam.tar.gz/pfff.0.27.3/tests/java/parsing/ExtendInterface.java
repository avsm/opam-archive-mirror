interface TestInterface<T extends Integer> {
}

