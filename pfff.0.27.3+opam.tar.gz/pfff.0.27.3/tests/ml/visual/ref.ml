
let x = 1


let y = ref 1


let z = Hashtbl.create 101
