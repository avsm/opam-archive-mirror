

(* this should be kept *)
let foo x = 
  MethodCallSimple(1, 2)


(* this should be kept too *)
let foo x = 
  MethodCallSimple(1, 2)

(* nested comment should
   (* be handled too *)
*)
