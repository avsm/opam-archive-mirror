let rec f x =
  g x
and g x = 
  f x
