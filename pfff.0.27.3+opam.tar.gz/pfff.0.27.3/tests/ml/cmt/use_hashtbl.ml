let empty_hash = Hashtbl.create 0


let foo x =
  empty_hash
