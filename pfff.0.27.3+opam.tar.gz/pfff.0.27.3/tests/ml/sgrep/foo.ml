let x = f 1

let y = f 2

