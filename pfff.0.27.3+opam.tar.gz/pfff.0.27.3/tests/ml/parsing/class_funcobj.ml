
class foo = object 
  method with_target x = {< targets = x >}
end
