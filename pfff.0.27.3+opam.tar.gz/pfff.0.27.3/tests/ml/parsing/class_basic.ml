class foo =
object(self)
  method foo = 1
end
