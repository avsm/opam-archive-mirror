class type t_item = object
method sel : bool
end

