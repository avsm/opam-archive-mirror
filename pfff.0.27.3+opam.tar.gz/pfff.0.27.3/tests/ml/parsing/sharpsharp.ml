let (##) a b = a + b

let x = 1 ## 2
