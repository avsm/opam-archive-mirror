module Foo = struct
    let foo = 1
end
