
let foo x = 
 List.rev !x

let y = ref 1

