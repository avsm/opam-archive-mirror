<?php

$f = 'AClass::testThis';

$f = 'AnotherClass';

$f = 'Anotherclassagain';

// too risky to create edge, could be a regular string.
$f = 'Exception';