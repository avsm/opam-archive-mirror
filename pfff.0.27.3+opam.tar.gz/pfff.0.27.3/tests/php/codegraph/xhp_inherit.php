<?php

class :x:misc2 extends :x:misc {
}
