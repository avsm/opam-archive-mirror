<?php

class DupeMethod {
  public function foo() {
  }

  public function foo() {
  }
}