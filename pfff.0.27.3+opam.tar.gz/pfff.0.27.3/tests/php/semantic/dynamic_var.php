<?php

$a = "b";
$b = "foo";

echo $b;
echo $$a;
echo ${"b".""};
