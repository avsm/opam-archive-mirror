<?php

$array = array(1,2,3);
$array2 = array(4,5,6);
foreach ($array2 as $array[0]) {
}
var_dump($array);
