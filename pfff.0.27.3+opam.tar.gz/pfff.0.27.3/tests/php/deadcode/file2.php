<?php

// not dead, called from top stmt in file1
function file2_foo() {
}

