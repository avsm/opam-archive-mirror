<?php

// @called-from-phpsh
function not_dead_annot() {
}

/**
 * @called-from-phpsh
 */
function not_dead_annot2() {
}
