
let debug_lexer = ref false

let verbose_parsing = ref true
let show_parsing_error = ref true

let error_recovery = ref false
