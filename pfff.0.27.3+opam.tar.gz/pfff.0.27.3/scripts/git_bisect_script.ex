#!/bin/sh
make opt
make visualopt

