<?php
function foo($a) {
  echo $a;
}
foo("hello world");
?>
