open Core.Std
open Import

module Test (Pool : sig
  include Pool.S
  val show_messages : bool ref
end) = struct

  let () = Pool.show_messages := false

  module Pointer = Pool.Pointer

  TEST_UNIT "get_tuple with length = 1" =
    let pool = Pool.create Pool.Slots.t1 ~capacity:10 ~dummy:0 in
    let ptr = Pool.new1 pool 42 in
    let tuple = Pool.get_tuple pool ptr in
    assert (tuple = 42)
  ;;

  TEST_UNIT "get_tuple with length > 1" =
    let pool = Pool.create Pool.Slots.t3 ~capacity:10 ~dummy:(0, 0, 0) in
    let ptr = Pool.new3 pool 42 42 42 in
    let tuple = Pool.get_tuple pool ptr in
    assert (Poly.equal tuple (42, 42, 42))
  ;;

  module rec List_ : sig
    module Pool : sig
      type 'a t with sexp_of

      val create : capacity:int -> dummy:'a -> 'a t
      val is_full : _ t -> bool
      val grow : ?capacity:int -> 'a t -> 'a t
    end

    type 'a t with sexp_of

    val nil : unit -> _ t
    val is_nil : _ t -> bool
    val create : 'a Pool.t -> 'a -> 'a t -> 'a t
    val free : 'a Pool.t -> 'a t -> unit
    val head : 'a Pool.t -> 'a t -> 'a
    val tail : 'a Pool.t -> 'a t -> 'a t
    val get : 'a Pool.t -> 'a t -> ('a * 'a t) option
  end = struct

    type 'a ty = ('a, 'a ty Pointer.t) Pool.Slots.t2 with sexp_of

    type 'a t = 'a ty Pointer.t with sexp_of

    let create = Pool.new2
    let free = Pool.free

    let nil = Pointer.null
    let is_nil = Pointer.is_null

    let head p t = Pool.get p t Pool.Slot.t0
    let tail p t = Pool.get p t Pool.Slot.t1

    let get t p = if is_nil p then None else Some (Pool.get_tuple t p)

    module Pool = struct
      type 'a t = 'a ty Pool.t with sexp_of

      let create ~capacity ~dummy =
        Pool.create Pool.Slots.t2 ~capacity ~dummy:(dummy, nil ())
      ;;
      let is_full = Pool.is_full
      let grow = Pool.grow
    end
  end

  open List_

  (* [create] with invalid capacity *)
  TEST_UNIT =
    List.iter [ -1; 0 ] ~f:(fun capacity ->
      assert (Result.is_error (Result.try_with (fun () ->
        ignore (Pool.create ~capacity ~dummy:())))))
  ;;

  let rec grow_loop p num_left =
    if num_left > 0 then grow_loop (Pool.grow p) (num_left - 1)
  ;;

  (* [grow] an empty pool *)
  TEST_UNIT = grow_loop (Pool.create ~capacity:1 ~dummy:()) 10

  (* [grow] a non-empty pool *)
  TEST_UNIT =
    let p = Pool.create ~capacity:1 ~dummy:0 in
    ignore (create p 13 (nil ()));
    grow_loop p 10;
  ;;

  (* [grow] a non-empty pool, while adding each time *)
  TEST_UNIT =
    let rec loop p num_left =
      if num_left > 0 then begin
        ignore (create p 13 (nil ()));
        loop (Pool.grow p) (num_left - 1);
      end;
    in
    loop (Pool.create ~capacity:1 ~dummy:0) 10;
  ;;

  let rec fold p list ~init ~f =
    if is_nil list then
      init
    else
      fold p (tail p list) ~init:(f init (head p list)) ~f
  ;;

  let to_list p list = List.rev (fold p list ~init:[] ~f:(fun l a -> a :: l))

  (* [grow] on demand *)
  TEST_UNIT =
    let total_length = 10_000 in
    let rec loop i p list =
      let i = i - 1 in
      if i < 0 then
        assert (Poly.equal (to_list p list) (List.init total_length ~f:Fn.id))
      else begin
        let p =
          if not (Pool.is_full p) then
            p
          else
            Pool.grow p
        in
        loop i p (create p i list);
      end;
    in
    loop total_length (Pool.create ~capacity:1 ~dummy:0) (nil ());
  ;;

  (* [free] *)
  TEST_UNIT =
    let n = 10 in
    let p = Pool.create ~capacity:n ~dummy:0 in
    for _i = 1 to 4 do
      let ls = List.init n ~f:(fun i -> create p i (nil ())) in
      assert (Pool.is_full p);
      List.iter ls ~f:(fun l -> free p l);
    done;
  ;;

  (* [free] *)
  TEST_UNIT =
    let rec loop p num_iters_left num_to_alloc_this_iter live =
      if num_iters_left = 0 then
        List.iter live ~f:(fun l -> free p l)
      else
        let p, live =
          List.fold (List.init num_to_alloc_this_iter ~f:Fn.id) ~init:(p, live)
            ~f:(fun (p, live) i ->
              let p = if Pool.is_full p then Pool.grow p else p in
              p, (create p i (nil ()) :: live))
        in
        let to_free, live =
          let r = ref true in
          List.partition_map live ~f:(fun a ->
            r := not !r;
            if !r then `Fst a else `Snd a)
        in
        List.iter to_free ~f:(fun l -> free p l);
        loop p (num_iters_left - 1) (num_to_alloc_this_iter * 2) live;
    in
    loop (Pool.create ~capacity:1 ~dummy:0) 10 1 [];
  ;;

  (* [get_tuple] *)
  TEST_UNIT =
    let p = Pool.create ~capacity:10 ~dummy:0 in
    let l = create p 13 (nil ()) in
    let z1 = Option.value_exn (get p l) in
    let z2 = (13, nil ()) in
    assert (Poly.equal z1 z2);
  ;;

  (* [get] *)
  TEST_UNIT =
    let p = Pool.create ~capacity:10 ~dummy:0 in
    try
      let l = create p 13 (nil ()) in
      assert (not (is_nil l));
      assert (head p l = 13);
      assert (is_nil (tail p l));
      free p l;
    with exn -> failwiths "failure" (exn, p) <:sexp_of< exn * _ Pool.t >>
  ;;

  (* [sexp_of] *)
  TEST_UNIT =
    let sexp_of = <:sexp_of< int t >> in
    ignore (sexp_of (nil ()));
    let p = Pool.create ~capacity:10 ~dummy:0 in
    try
      let l = create p 13 (nil ()) in
      ignore (sexp_of l);
    with exn -> failwiths "failure" (exn, p) <:sexp_of< exn * _ Pool.t >>
  ;;
end

TEST_MODULE = Test (Pool.Debug (Pool.None))
TEST_MODULE = Test (Pool.Debug (Pool.Obj_array))

open Pool.Obj_array

TEST_UNIT "immediate/boxed specialization" =
  (* Care has been taken to ensure that when working with immediate values in the pool,
     the compiler is able to emit code that does not invoke the write barrier.

     This can be very easily broken, and as such we're adding this unit test to detect
     when this may have happened.

     By performing many iterations and comparing Median times to Minimum times
     (conservatively), I'm hoping to avoid any spurious failures that may come from
     scheduling/load on the test machine.

     Lastly, this is intentionally performed here, outside the unit test functor, to avoid
     noise from the added indirection. *)
  let times = Array.create ~len:(16 * 1024) Time.Span.zero in
  let benchmark_time ~measurement f =
    f (); (* call once, untimed, to reduce cache effects *)
    let len = Array.length times in
    let times =
      Array.init len ~f:(fun _ ->
        let start = Time.now () in
        f ();
        let stop = Time.now () in
        Time.diff stop start)
    in
    Array.sort times ~cmp:Time.Span.compare;
    match measurement with
    | `Min -> times.(0)
    | `Median -> times.(len/2)
    | `Max -> times.(len-1)
  in
  let values = List.init 1024 ~f:Fn.id in
  let s_values = List.map values ~f:(fun i -> sprintf "%d" i) in
  let array_ = Array.create ~len:(List.length values) 0 in
  let array_imm_set (a : int array) i (x : int) = Array.set a i x in
  let array_obj_set a i x = Array.set a i x in
  let imm_set = benchmark_time ~measurement:`Median
    (fun () -> List.iter values ~f:(fun i -> array_imm_set array_ 0 i))
  in
  let obj_set = benchmark_time ~measurement:`Median
    (fun () -> List.iter values ~f:(fun i -> array_obj_set array_ 0 i))
  in
  assert (Time.Span.compare imm_set obj_set <= 0);

  let p = create Slots.t3 ~capacity:1 ~dummy:(Pointer.null (), 0, "") in
  let e = new3 p (Pointer.null ()) 0 "" in
  let pool_imm_set = benchmark_time ~measurement:`Min
    (fun () -> List.iter values ~f:(fun i -> set p e Slot.t1 i))
  in
  let pool_obj_set = benchmark_time ~measurement:`Min
    (fun () -> List.iter s_values ~f:(fun s -> set p e Slot.t2 s))
  in
  assert (Time.Span.compare pool_imm_set obj_set <= 0);
  assert (Time.Span.compare pool_imm_set pool_obj_set <= 0);
  (* the overhead of a pool set operation should not be as large as an array_set itself,
     hence pool_imm_set should be less than 2 times the array operation. *)
  let pool_ns = Time.Span.to_ns pool_imm_set in
  let array_ns = Time.Span.to_ns imm_set in
  assert (Float.(<) pool_ns (2. *. array_ns));
;;
