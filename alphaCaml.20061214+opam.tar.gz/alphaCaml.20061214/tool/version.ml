let version =
  "<unreleased>" (* to be overridden when a package is created *)

let version = "20061214"
