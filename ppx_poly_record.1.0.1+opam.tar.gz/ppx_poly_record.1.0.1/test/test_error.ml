let () = [%poly_record { x = 1 } [@@haha] ] 
 
