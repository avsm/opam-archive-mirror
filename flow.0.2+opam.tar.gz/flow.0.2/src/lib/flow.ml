(** Base module packing the whole library *)

include Flow_base
include Flow_list
module IO = Flow_io
module System = Flow_system
module Network = Flow_net

