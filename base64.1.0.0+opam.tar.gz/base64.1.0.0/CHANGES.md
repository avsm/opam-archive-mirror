1.0.0 (2014-08-03):
* Initial public release.
