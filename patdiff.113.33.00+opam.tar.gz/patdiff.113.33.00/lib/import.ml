module ANSITerminal    = Ansi_terminal.ANSITerminal
module Patience_diff   = Patience_diff_lib.Std.Patience_diff
