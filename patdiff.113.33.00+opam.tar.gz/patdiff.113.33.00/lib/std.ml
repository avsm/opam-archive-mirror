module Compare_core   = Compare_core
module Patdiff_core   = Patdiff_core
module Patdiff_format = Patdiff_format
module Patdiff_hunks  = Patdiff_hunks
