(**************************************************************************)
(*                                                                        *)
(*    Copyright 2012-2015 OCamlPro                                        *)
(*    Copyright 2012 INRIA                                                *)
(*                                                                        *)
(*  All rights reserved. This file is distributed under the terms of the  *)
(*  GNU Lesser General Public License version 2.1, with the special       *)
(*  exception on linking described in the file LICENSE.                   *)
(*                                                                        *)
(**************************************************************************)

(** Source of the opam-admin tool, main *)

open Cmdliner

let default_cmd =
  let doc = "Administration tool for local repositories." in
  Term.(ret (pure (`Help (`Pager, None)))),
  Term.info "opam-admin" ~version:OpamVersion.(to_string current) ~doc

let make_repo_cmd =
  let doc = "Initialize a repo for serving files." in
  Term.(Opam_mk_repo.(pure process $ args)),
  Term.info "make" ~doc

let check_repo_cmd =
  let doc = "Check a local repo for errors." in
  Term.(Opam_repo_check.(pure process $ args)),
  Term.info "check" ~doc

let stats_cmd =
  let doc = "Compute statistics." in
  Term.(Opam_stats.(pure process $ pure ())),
  Term.info "stats" ~doc

let depexts_cmd =
  let doc = "Add external dependencies." in
  Term.(Opam_depexts_change.(pure process $ args)),
  Term.info "depexts" ~doc
(*
let findlib_cmd =
  let doc = "Add findlib information." in
  Term.(Opam_findlib.(pure process $ args)),
  Term.info "findlib" ~doc
*)
let rename_cmd =
  let doc = "Rename a package." in
  Term.(Opam_rename.(pure process $ args)),
  Term.info "rename" ~doc

let upgrade_format_cmd =
  let doc =
    Printf.sprintf "Upgrade a repository format from 1.2 to %s."
      OpamVersion.(to_string (full ()))
  in
  Term.(Opam_format_upgrade.(pure process $ args)),
  Term.info "upgrade-format" ~doc

let () =
  OpamSystem.init ();
  try
    match
      Term.eval_choice ~catch:false
        default_cmd [
        make_repo_cmd; check_repo_cmd; stats_cmd;
        depexts_cmd; (*findlib_cmd;*) rename_cmd;
        upgrade_format_cmd
      ]
    with
    | `Error _ -> exit 2
    | _ -> exit 0
  with
  | OpamStd.Sys.Exit i -> exit i
