Changelog
=========

1.2
---

  * Chop the `.git` suffix from project name in `dev-repo:`.

1.1
---

  * Add `--tag-format` option.

1.0
---

  * Initial release.
