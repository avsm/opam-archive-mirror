let package_name = "rpc_parallel"

let sections =
  [ ("lib",
    [ ("built_lib_rpc_parallel_core_deprecated", None)
    ],
    [ ("META", None)
    ])
  ]
