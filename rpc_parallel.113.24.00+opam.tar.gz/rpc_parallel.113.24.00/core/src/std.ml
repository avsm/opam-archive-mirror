open! Core.Std

module Parallel_deprecated = Parallel
