open Ast_mapper

let _ = register "csv_provider" Csv_provider.csv_mapper
