#!/bin/sh
../../boot/ocamlrun -I ../../stdlib/ -I ../../otherlibs/unix/ ../ocamlspot $*
