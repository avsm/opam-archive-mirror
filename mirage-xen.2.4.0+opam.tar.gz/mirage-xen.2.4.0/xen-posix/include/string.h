#ifndef _XEN_POSIX_STRING_H
#define _XEN_POSIX_STRING_H

#include_next <string.h>

char *strerror(int errnum);

#endif /* _XEN_POSIX_STRING_H */
