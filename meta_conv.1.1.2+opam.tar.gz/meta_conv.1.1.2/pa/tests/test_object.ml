type t = < x : int > with conv(json)

