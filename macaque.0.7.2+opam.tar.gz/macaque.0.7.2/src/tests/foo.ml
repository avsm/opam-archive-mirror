open Sql

let id_table table = << t | t in $table$ >>

let id_value x = <:value< $x$ >>
