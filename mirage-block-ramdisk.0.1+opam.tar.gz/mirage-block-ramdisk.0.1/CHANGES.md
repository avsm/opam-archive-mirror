
0.1 (3-Nov-2015)
- initial release with support for `resize` and sparseness info
