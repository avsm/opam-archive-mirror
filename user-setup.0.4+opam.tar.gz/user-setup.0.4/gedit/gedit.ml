open OusSig
open OusTypes
open OusMisc

let name = "gedit"

let check () = has_command "gedit"

let base_template = []

let base_setup = []

let files = []

let comment = (^) "# "

let tools = []
