(* Time-stamp: <modified the 02/07/2015 (at 09:45) by Erwan Jahier> *)

open RdbgStdLib (* so that they are included by ocamlbuild *)
open Event
open RdbgMain
open RifIO
open GnuplotRif
open Coverage
open RdbgArg
open LutinRdbg

(* open LutinRun *)
(* open Value *)

(* faire comme dans rdbgbatch pour les arguments *)


let parg () =
  ( try RdbgArg.parse Sys.argv;
	 with
	     Failure(e) ->
	       output_string args.ocr e;
	       flush args.ocr ;
	       flush args.ecr ;
	       exit 2
	   | e ->
	     output_string args.ocr (Printexc.to_string e);
	     flush args.ocr;
	     exit 2
  )
(* ; *)
(*   (match args._others with *)
(*     | [str] -> cmxs := str *)
(*     | [] ->  *)
(*       Printf.eprintf "*** Error: No cmxs file has been provided to %s.\n%s.\n" Sys.argv.(0) usage; *)
(*       flush stderr; *)
(*       exit 2 *)
(*     |  _::_ ->  *)
(*       Printf.eprintf "*** Error: only one (cmxs) file is expected in arg of %s.\n%s.\n" *)
(*         Sys.argv.(0) usage; *)
(*       flush stderr; *)
(*       exit 2   *)
(*   ) *)
;;

let _ = 
  output_string stdout "type 'man' for a small on-line manual\n";
  output_string stdout ("        Rdbg Version "^(Version.str)^" ("^Version.sha^") \n");
  flush stdout;
    (* Taken from 
       http://stackoverflow.com/questions/6158596/setting-the-prompt-in-an-ocaml-custom-toplevel 
    *)
     
  (Toploop.read_interactive_input :=  
     let old = !Toploop.read_interactive_input in 
     fun prompt buffer len -> 
       old "(rdbg) " buffer len);
  Topmain.main()
(* 
 is Topmain.main() the segv culprit ? 
it seems so according to http://caml.inria.fr/mantis/print_bug_page.php?bug_id=6108
*)
