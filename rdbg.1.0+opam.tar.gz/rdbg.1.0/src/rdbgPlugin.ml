(* Time-stamp: <modified the 26/03/2014 (at 15:55) by Erwan Jahier> *)

type sl = ( string * Data .v) list (* substitutions *)
type e = Event .t
type ctx = Event.ctx
type t = {
  inputs  : (Data.ident * Data.t) list; (* name and type *)
  outputs : (Data.ident * Data.t) list; (* ditto *)
  kill: string -> unit;
  init_inputs  : sl;
  init_outputs : sl;
  step     : (sl -> sl); (* Lurette step *) 
  step_dbg : (sl -> ctx -> ( sl -> ctx -> e) -> e); (* RDBG step *)
}

let dummy = {
  inputs = [];
  outputs= [];
  kill= (fun _ -> ());
  init_inputs=[];
  init_outputs=[];
  step= (fun sl -> assert false);     
  step_dbg=(fun _ _ -> assert false); 
}
