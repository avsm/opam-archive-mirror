(* Time-stamp: <modified the 12/12/2014 (at 14:23) by Erwan Jahier> *)

open RdbgArg
(****************************************************************************)
(* use to perform system calls *)  
type my_create_process_result =
    OK
  | KO
  | PID of int (* if called with ~wait:false *)

let (my_create_process : ?std_in:(Unix.file_descr) -> ?std_out:(Unix.file_descr) ->
     ?std_err:(Unix.file_descr) ->
     ?wait:(bool) -> string -> string list -> my_create_process_result) =
  fun ?(std_in = Unix.stdin) ?(std_out = Unix.stdout) ?(std_err = Unix.stderr)
    ?(wait = true) prog args -> 
      try
        let pid = 
	       List.iter (fun x -> output_string stderr (x ^ " ")) (prog::args);
	       output_string stderr "\n";
	       flush stderr;
	       Unix.create_process
	         prog
	         (Array.of_list (prog::args))
	         (std_in)
	         (std_out)
	         (std_err)
        in
	     if not wait then PID pid else 
	       let (_,status) = (Unix.waitpid [Unix.WUNTRACED] pid) in
	       ( match status with 
		        Unix.WEXITED i -> 
		          if i = 0 || i = 1 then
		            (
			           output_string stderr ("     ... " ^ prog ^ " exited normally.\n");
			           flush stderr;
			           OK
		            )
		          else
		            (
			           output_string stderr (
                      "*** Error: " ^ prog ^ " exited abnormally (return code=" ^ 
                        (string_of_int i)^").\n");
			           flush stderr;
			           KO
		            )
            | Unix.WSIGNALED i-> 
		        output_string stderr ("*** Error: " ^ prog ^ " process was killed by signal " ^ 
                                       (string_of_int i)^"\n");
		        flush stderr;
		        KO
            | Unix.WSTOPPED i -> 
		        output_string stderr ("*** Error: " ^ prog ^ " process was stopped by signal " ^ 
                                       (string_of_int i)^"\n");
		        flush stderr;
		        KO
	       )
      with 
        | Unix.Unix_error(error, name, arg) -> 
	       let msg = ( "*** '" ^
			               (Unix.error_message error) ^
			               "'in the system call: '" ^ name ^ " " ^ arg ^ "'\n")
	       in
	       output_string stdout msg;
	       flush stdout;
	       output_string stderr msg;
	       flush stderr;
	       KO
        | e -> 
	       output_string stdout (Printexc.to_string e);
	       flush stdout;
	       output_string stderr (Printexc.to_string e);
	       flush stderr;
	       KO

(****************************************************************************)
let mygetenv_def def x = 
  let x = 
    match Sys.os_type with
      | "Win32" -> (x^"_DOS")
      | _ ->  x
  in
    try Unix.getenv x 
    with Not_found -> def

(* try to compile a C file into a dro file *)
let (c2dro: string -> bool) =
  fun cfile ->
    let base = Filename.chop_extension cfile in
    let dro =  base ^ ".dro" in
    try
      let cc = mygetenv_def "gcc" "GCC" in
	   ignore (my_create_process ~std_out:Unix.stderr ~wait:true cc
	             [cfile;  "-fPIC"; "-shared"; "-o"; dro ]);
      true
    with e -> 
      print_string (Printexc.to_string e);
      flush stdout;
      false
