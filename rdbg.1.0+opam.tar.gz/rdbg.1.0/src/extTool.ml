(* Time-stamp: <modified the 04/12/2013 (at 10:20) by Erwan Jahier> *)

open Mypervasives

let (sim2chro_dyn : unit -> out_channel) =
  fun () ->
    let sim2chro = mygetenv "SIM2CHRO" in
    let oc = Unix.open_process_out (sim2chro ^ " -nologo -ecran /dev/null") in
      oc          
