(* Time-stamp: <modified the 17/09/2014 (at 16:57) by Erwan Jahier> *)

type var = Data.ident * Data.t


(* Source info related to the current control point. Its content
   depends on the plugin it comes from. *)
type src_info_atom = { 
  str  : string ; 
  file : string ; 
  line : int * int ; (* line nb begin/end in file *)
  char : int * int ; (* char nb begin/end in file *)
  stack: src_info_atom option; (* useful for tracking inlined code *)
}

type src_info = {
  expr : Expr.t ;    (* holds info about the current control point *)
  atoms: src_info_atom list;
  more : (unit -> Expr.t) option;  (* more (costly) info *)
}

(* a.k.a. ports in the Prolog Byrd's box model *)
type kind = Ltop | Call | Exit 
  | MicroStep of string (* holds info related to the sub-lang micro-step *)

type t = { 
  nb    : int;
  step  : int;
  depth : int;
  data  : Data.subst list;  
  next  : unit -> t;
  terminate: unit -> unit;
  kind  : kind;
  name : string;
  lang : string; 
  inputs  : var list; 
  outputs : var list; 
  sinfo : (unit -> src_info) option
} 

(* useful here ? 
   Mais ca apparait dans l'interface des plugins. Vérifier si c'est nécessaire.
*)
type ctx = (* inherited debug info *)
    {
      ctx_step :int;
      ctx_name :string;
      ctx_depth:int;
      ctx_data: Data.subst list;
      ctx_terminate: unit -> unit;
      ctx_inputs  : var list;
      ctx_outputs : var list;
    }

(* raised by next  when there is no next event. Holds the event number.*)
exception End of int 
exception Error of string * t 

let seed = ref 0
let set_seed s = 
  seed := s

let event_nb = ref 0
let set_nb i = event_nb := i
let get_nb () =  !event_nb
let incr_nb() =
  incr event_nb;
(*   Printf.printf "Random.init %i+%i\n " !seed  !event_nb; flush stdout; *)
  Random.init (!seed + !event_nb); (* make sure everything is reproductible *) 
  !event_nb



    
