(* Time-stamp: <modified the 17/09/2014 (at 18:03) by Erwan Jahier> *)
(* A simple wrapper around rdbgstart.byte to avoid typing "()" and
   ";;" 

*)

let add_semi_ref = ref true

let rdbg_path = Mypervasives.mygetenv "RDBG_PATH"
let rdbg_lib = Filename.concat rdbg_path "_build"
let rdbg_lib = Filename.concat rdbg_lib "src" (* XXX fixme *)
let rdbg_top = Filename.concat rdbg_path "rdbgstart.byte" 

let help () = 
  print_string "This is rdbg; use it as a ocaml toplevel \nXXX finishme\n";
  flush stdout;
  exit 0

let other_args:string = 
  let args = List.tl (Array.to_list (Sys.argv)) in
  if List.mem "-h" args then help();
  if List.mem "-help" args then help();
  if List.mem "--help" args then help();
  String.concat " " args
  


let oc = Unix.open_process_out (rdbg_top ^ " -I " ^ rdbg_lib ^ " " ^ other_args)

let rec my_read_line () =
  let str = read_line () in
  match str with
    | "#auto"  -> 
      add_semi_ref:= true;
      print_string "type '#auto_off' to disable automatic semicolumn mode\n"; flush stdout;
      my_read_line ()
    | "#auto_off" -> 
      add_semi_ref:= false; 
      print_string "type '#auto' to enable automatic semicolumn mode\n"; flush stdout;
      my_read_line ()
    | _ -> str
  
let rec myloop () =
  let str = my_read_line () in
  let add_par = if String.contains str ' ' then "" else "()" in
  let no_semicol = not (Str.string_match (Str.regexp ";;[ \t]+$") str 0) in
  let semi = if !add_semi_ref && no_semicol then ";;" else "" in
  output_string oc (str ^ add_par ^ semi ^ "\n");
  flush oc;
  myloop ()

let preliminaries = "open RdbgMain;;
open Event;;
open RdbgStdLib;;
open RdbgArg
"

let _ =   
  try
    output_string oc preliminaries; flush oc;
    print_string "type '#auto_off' to disable automatic semicolumn mode\n"; 
    print_string "and '#auto_on' to restore the default behavior\n"; flush stdout;


    myloop ()
  with 
    | End_of_file -> Printf.printf "bye.\n"; flush stdout
    | e  -> 
      Printf.eprintf "Error in rdbg: %s\n" (Printexc.to_string e);
      flush stderr;
      exit 2
