(* Time-stamp: <modified the 10/08/2015 (at 14:46) by Erwan Jahier> *)
(* Opium/morphine like debugger *)
 
open RdbgRun
open RdbgArg
open Event
open Mypervasives

let cmd_list = []

(* a few shortcuts *)
let info() = 
    let msg =  "The current test parameters are:
     sut: "^ (String.concat "," (List.map reactive_program_to_string args.suts)) ^ "
     env: "^ (String.concat "," (List.map reactive_program_to_string args.envs)) ^ "
     oracle: "^ (String.concat "," (List.map reactive_program_to_string args.oracles)) ^ "
     test length: " ^  (string_of_int args.step_nb) ^ "
     precision: " ^ (string_of_int args.precision) ^ "
     seed:  " ^ (match args.seed with
			            None ->  "chosen randomly"
			          | Some i -> (string_of_int i))  ^ "
     verbosity level: " ^ (string_of_int (args.verbose)) ^ "
     rif file name: " ^ args.output ^ "
     overwrite rif file? "
      ^ (if args.overwrite_output then "yes" else "no") ^ "
     coverage file name: " ^ args.cov_file ^ "
     do we stop  when an oracle returns false? " 
      ^ (if args.stop_on_oracle_error then "yes" else "no") ^ "
     display local var? " ^ (if (args.display_local_var) then "yes" else "no") ^ "

"
    in
      output_string args.ocr msg;
      flush args.ocr


let i = info
let stl i =  args.step_nb <- i


let set_gnuplot b  = RdbgArg.args.RdbgArg.display_gnuplot  <- b
let set_sim2chro b = RdbgArg.args.RdbgArg.display_sim2chro <- b

let run () =  Event.event_nb := 0; RdbgRun.start ()
let next e = e.next
let data e = e.data
let terminate e = e.terminate
let off () = RdbgArg.args.RdbgArg.rdbg <- false
let on () = RdbgArg.args.RdbgArg.rdbg <- true

let _ = 
  RdbgArg.args.RdbgArg.rdbg <- true


(* XXX rm? *)
let (get_val_event : Event.t -> unit) =
  fun e -> 
    let nl,vl = List.split e.data in
    let nl = List.map (fun n ->  String.uncapitalize n) nl in
    let vstrl = List.map (Data.val_to_string (string_of_float)) vl in
    let str =
      "let " ^ (String.concat "," nl) ^ 
        " = " ^ (String.concat "," vstrl) ^ ";;\n"
    in
    print_string (str)

(* (Ugly?) hack to be able to display online help

   I suppose that "ldbg.mli" is formatted like this:

(** cmd help message *)
val cmd : <cmd profile>

where 
   - val begins a line,
   - the cmd profile fits on a line
   - the space before the ":" matters
   
*)

let rdbg_dir = mygetenv "RDBG_PATH"
let rdbg_lib_dir = Filename.concat rdbg_dir "src" (* XXX lib? *)


let ldbg_mli = readfile (Filename.concat rdbg_lib_dir "rdbgMain.mli")
let ldbg_utils_mli = readfile (Filename.concat rdbg_lib_dir "rdbgStdLib.mli")

let (get_cmd_list: string -> (string * (string * string)) list) = fun mli -> 
  let rec aux acc i0 = 
    try
      let i1 = Str.search_forward (Str.regexp ("(\\*\\*")) mli i0 in
      let i2 = Str.search_forward (Str.regexp ("\\*)")) mli i1 in
      let i3 = Str.search_forward (Str.regexp ("^val ")) mli i2 in
      let i4 = Str.search_forward (Str.regexp " :")  mli i3 in
      let i5 = Str.search_forward (Str.regexp "\n")  mli i4 in
      let help = String.sub mli (i1+4) (i2-i1-5) in
      let cmd = String.sub mli (i3+4) (i4-i3-4) in
      let profile = String.sub mli (i4+3) (i5-i4-3) in
        aux ((cmd,(profile,help))::acc) i5
    with Not_found -> acc
  in
    List.rev(aux [] 0)

let (cmd_list: (string * (string * string)) list) = 
  get_cmd_list ldbg_mli

let cmd_list_utils = get_cmd_list ldbg_utils_mli
let all_cmds = cmd_list @ cmd_list_utils


let get_profile str =
  try 
    let i = Str.search_forward (Str.regexp_string ("val "^str)) ldbg_mli 0 in
    let j = Str.search_forward (Str.regexp_string "\n")  ldbg_mli i in
      String.sub ldbg_mli (i+4) (j-i+4)
  with Not_found -> ""


let print_cmd_list = 
  List.iter 
    (fun (cmd, (msg,profile)) -> Printf.printf "\t%12s : %s\n" cmd msg)

let (apropos : string -> unit) =
  fun str -> 
    let l = List.filter 
      (fun (cmd,_) -> Str.string_match (Str.regexp_string str) cmd 0) all_cmds
    in
      print_cmd_list l
  

let (help:string -> unit) =
  fun cmd ->
    if cmd="base" then (
      print_string "Type 
help \"command\";; 
  to obtain more help on the following commands: \n";
      print_cmd_list cmd_list
    ) 
    else if  cmd="utils" then (
      print_cmd_list cmd_list_utils
    )
    else if List.mem_assoc cmd all_cmds then (
      let prof,help = List.assoc cmd all_cmds in
        Printf.printf "%s : %s\n%s\n" cmd prof help 
    )
    else (
      Printf.printf  "Unknown command. Available commands are : %s"
        (String.concat "," (fst (List.split all_cmds)))
    )

let h = help
let a = apropos

let (man:unit -> unit) =
  fun () -> 
    output_string stdout " rdbg  is a  Lutin  and Lustre  V6  debugger.  It  is  also an  ocaml
 top-level with several Modules  loaded: Event, Rdbg, and Ldbg_utils.
 ldbg automatically  adds semicolumn  at each 'Return',  because it's
 boring to type them. It also automatically adds \"()\" at phrases that
 does not contain  any blank (which is convenient most  of the time).
 The normal  ocaml top-level  behavior can  be turn  on and  off with
 '#auto_off' and '#auto' directives.
 
  Here are a few commands to be able to start browsing the online help:
   help \"base\"     (* for basic commands *)
   help \"utils\"    (* for Ldbg_utils commands *)
   apropos \"next\"  (* for all commands which name contains the string \"next\" *)
   apropos \"\"      (* for all commands *)
";
  flush stdout
 
