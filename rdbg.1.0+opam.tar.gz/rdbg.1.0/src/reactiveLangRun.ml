(* Time-stamp: <modified the 04/12/2013 (at 14:32) by Erwan Jahier> *)


let (make : string -> string -> string -> string list -> 
     vars * 
       vars * 
       (string -> unit) * (Data.subst list -> Data.subst list) *
       (Data.subst list -> Event.ctx -> (Data.subst list -> Event.ctx -> Event.t) -> Event.t) *
       Data.subst list * Data.subst list) =

  fun lang prog node args -> 
  assert false
