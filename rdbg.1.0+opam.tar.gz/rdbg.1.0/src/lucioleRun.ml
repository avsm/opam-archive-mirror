(* Time-stamp: <modified the 18/02/2014 (at 17:06) by Erwan Jahier> *)

type vars = (string * string) list
type sl = Data.subst list

open RdbgArg

let debug_msg msg =     
  if args.debug_rdbg then (output_string stdout ("lucioleRun: "^msg); flush stdout)

let output_msg msg = output_string stdout msg; flush stdout

let (make : string -> vars -> vars ->  (string -> unit) * (sl -> sl)) =
  fun dro_file luciole_inputs luciole_outputs -> 
    if luciole_outputs <> ["Step","bool"] || luciole_outputs <> [] then (
      Printf.eprintf "Inputs are missing. Try to generate them with luciole\n"; 
      Printf.eprintf "Luciole: generate rdbg_luciole.c\n"
    ); 
    Luciole.gen_stubs "rdbg" luciole_outputs luciole_inputs;
    Printf.eprintf "Luciole: generate rdbg.dro from rdbg_luciole.c\n"; 
    flush stderr;
    if RdbgMisc.c2dro "rdbg_luciole.c" then () else 
      ( 
        Printf.eprintf "*** Rdbg: Fail to generate rdbg.dro for luciole! bye...\n"; 
        flush stderr;
        exit 2
      );    

    Printf.eprintf "\nluciole: launch simec_trap on rdbg.dro\n"; 
    let (luciole_stdin_in,  luciole_stdin_out ) = Unix.pipe () in
    let (luciole_stdout_in, luciole_stdout_out) = Unix.pipe () in

    let luciole_ic = Unix.in_channel_of_descr  luciole_stdout_in in
    let luciole_oc = Unix.out_channel_of_descr luciole_stdin_out in
    let _ = 
      if Sys.os_type <> "Win32" then Unix.set_nonblock luciole_stdin_out;
      if Sys.os_type <> "Win32" then Unix.set_nonblock luciole_stdout_out;
      set_binary_mode_in  luciole_ic false;
      set_binary_mode_out luciole_oc false;
    in
    let prog = "simec_trap" ^ (if Sys.os_type="Win32" then ".bat" else "") in
    let luciole_args = [dro_file; string_of_int (Unix.getpid())] in
    let pid = 
      match RdbgMisc.my_create_process 
        ~std_in:luciole_stdin_in ~std_out:luciole_stdout_out
        ~wait:false
        prog
        luciole_args
      with
        | RdbgMisc.KO -> failwith ("error when calling simec_trap" ^ dro_file);
        | RdbgMisc.OK -> assert false
        | RdbgMisc.PID pid -> 
          debug_msg (prog ^ " " ^ dro_file ^ ": ok\n"); 
          pid
    in
    let kill msg = 
      close_out luciole_oc;
      close_in luciole_ic;
      (try 
         Printf.eprintf "%s\nKilling process %d\n" msg pid;
         flush stderr;
         Unix.kill pid Sys.sigterm 
       with e -> (Printf.printf "Killing of luciole process failed: %s\n" (Printexc.to_string e) ))
    in
    let (step : Data.subst list -> Data.subst list) = 
      fun sl -> 
        (* Sends values to luciole *)
        List.iter
          (fun (n,t) -> 
            let value = try List.assoc n sl with Not_found -> 
              let l = String.concat "," (List.map fst sl) in
              if args.debug_rdbg then 
                Printf.fprintf stdout "Reading luciole inputs:  %s not found in: %s ; " n l;
              match t with
                     (* use fake value as luciole input are only displayed ; 
                        hence its not worth exiting when inputs are missing (at first step)
                     *)
                  "bool" -> Data.B(true)
                | "int"  -> Data.I(42)
                | "real" -> Data.F(42.0)
                | _ -> 
                  Printf.fprintf stdout "*** cannot handle %s type as input of Luciole\n" t;
                  assert false
            in
            let my_string_of_float v = Mypervasives.my_string_of_float v args.precision in
            let val_str = (Data.val_to_string my_string_of_float value) ^"\n" in
            if args.debug_rdbg then
              Printf.fprintf stdout "write_luciole_inputs: %s = %s\n" n val_str;
            output_string luciole_oc val_str)
          luciole_inputs;
        flush luciole_oc;

        debug_msg "Rdbg: Start reading Luciole outputs...\n";
        (* Reads values from luciole *)
        let sl_out =
          List.map 
            (fun (name, vtype) -> 
              let str = 
                debug_msg ("read_luciole_outputs: reading " ^name ^"\n");
                let rstr = ref (input_line luciole_ic) in
                debug_msg ("XXX: '" ^ !rstr ^ "'\n");
                if (String.length !rstr >1 && String.sub !rstr 0 2 = "#q") then (
                  debug_msg ("luciole process has terminated \n");
                  failwith "luciole process has terminated"
                );
                while String.length !rstr = 0 || String.sub !rstr 0 1 = "#" do
                  debug_msg ("Skipping " ^ !rstr ^ "...\n");
                  rstr :=  input_line luciole_ic
                done;
                !rstr
              in
              debug_msg ("read_luciole_outputs:"^ str^"\n");
              let value = 
                match vtype with
                  | "bool" -> 
                    if str = "t" then Data.B(true) else if str = "f" then Data.B(false) else (
                      output_msg ("read_luciole_outputs:Can not convert the value of "
                                   ^name^" into a bool:'"^str^"'\n");
                      exit 2
                    )
                  | "int" -> (
                    try Data.I(int_of_string str)
                    with e ->  
                      output_msg ("read_luciole_outputs:Can not convert the value of "^
                                      name^" into an int:'"^str^"'\n"^
                                      (Printexc.to_string e));
                      exit 2
                  )
                  | "real" -> (
                    try Data.F(float_of_string str)
                    with e ->  
                      output_msg ("read_luciole_outputs:Can not convert  the value of "
                                   ^name^" into a float:'"^str^"'\n"^
                                     (Printexc.to_string e));
                      exit 2)
                  |  _ -> assert false
              in
              (name, value)
            )
            luciole_outputs
        in
        debug_msg "Rdbg: read_luciole_outputs: done.\n";
        sl_out
    in
    kill, step
