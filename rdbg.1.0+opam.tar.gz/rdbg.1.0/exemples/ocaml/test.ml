open Event;;
open RdbgMain;;
open RdbgStdLib;;

(* on verra pour le sucre plus tard... *)
open RdbgArg;;
args.suts <- [Ocaml(Dynlink.adapt_filename "sut.cma")];;
args.envs <- [Ocaml(Dynlink.adapt_filename "env.cma")];;

args.step_nb <- 100;;
args.seed <- Some 42;;


let _ = 
    let e = RdbgMain.run() in
  try
    print_string "RdbgRun.start(): ok.\n";
    flush stdout;
    let e = nexti e 50 in
    print_string "The end.\n";
    flush stdout;
    e.terminate();
    exit 0
  with Event.End _ -> 
    print_string "The end too.\n";
    flush stdout;
    e.terminate();
    exit 0


