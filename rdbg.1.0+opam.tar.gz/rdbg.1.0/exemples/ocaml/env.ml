

(**************************************************************************)
(* Utilities *)

open Data
let get_float var sol =  
  match (try List.assoc var sol with Not_found -> assert false) 
  with (F f) -> f | _ -> 
    Printf.printf "*** error when parsing float\n";
    flush stdout;
    assert false
 
let get_bool var sol =  
  match (try List.assoc var sol with Not_found -> assert false) 
  with (B b) -> b | _ -> 
    Printf.printf "*** error when parsing bool\n";
    flush stdout;
    assert false

(**************************************************************************)

let init  _ = ()
let kill  _ = ()
let mems_i = []
let mems_o = []

let (inputs  :(string * Data.t) list) = [ "a", Data.Real; "b", Data.Real]
let (outputs :(string * Data.t) list) = [ "x", Data.Real; "y", Data.Real]

let first_step = ref true
let (step :  Data.subst list -> Data.subst list)=
  fun env_outs -> 
    if !first_step  then  (
      (* ZZZ The env starts, and thus should be able to perform its
         first step with no input! *)
      first_step := false;
      [("x", F 10.0);("y", F 10.0)]
    )
    else 
      let a = get_float "a" env_outs
      and b = get_float "b" env_outs in
      let x = a +. 1.0 and y = b +. 1.0 in
(*       Printf.printf "Env step x=%f y=%f a=%f b=%f\n" x y a b; *)
(*       flush stdout; *)
      [("x",F x);("y",F y)]

let (step_dbg : Data.subst list -> Event.ctx -> (Data.subst list -> Event.ctx -> Event.t) -> Event.t) =
  fun sl ctx cont -> 
    {
      Event.step = ctx.Event.ctx_step;
      Event.data = ctx.Event.ctx_data;
      Event.nb = Event.incr_nb ();
      Event.depth = ctx.Event.ctx_depth;
      Event.kind = Event.Exit;
      Event.lang = "ocaml";
      Event.name = "ze env";
      Event.inputs = inputs ;
      Event.outputs = outputs;
      Event.sinfo = None; (* cf sut.ml for a possible way to fill that in *)

      Event.next = (fun () -> cont (step sl) ctx);
      Event.terminate = ctx.Event.ctx_terminate;
    } 
open RdbgPlugin 
let plugin = {
  inputs = inputs;
  outputs= outputs;
  kill= kill;
  init_inputs= mems_i;
  init_outputs= mems_o;
  step = step;
  step_dbg = step_dbg
}

let dyn_file = (Dynlink.adapt_filename "env.cma")

let _ = 
  OcamlRM.reg_plugin dyn_file plugin
