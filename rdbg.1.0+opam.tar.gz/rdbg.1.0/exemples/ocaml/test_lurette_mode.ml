open RdbgArg;;

args.rdbg <-false;;
#use "test.ml";;
