open Event;;
open RdbgMain;;
open RdbgStdLib;;

(* on verra pour le sucre plus tard... *)
open RdbgArg;;
open Lus2licRun;;
args.suts <- [Ocaml(Dynlink.adapt_filename "sut.cma")];;
args.envs <- [Ocaml(Dynlink.adapt_filename "env.cma")];;

args.step_nb <- 50;;
args.verbose <- 50;;
args.debug_rdbg <- true;;
(* Dynlink.allow_unsafe_modules true;; *)

open RdbgRun ;;
let main () = 
  let e = 
    try RdbgRun.start()
    with e -> 
      Printf.printf "pb in test.ml :  %s\n"  (Printexc.to_string e);
      flush stdout;
      exit 2
  in
  try
    let _e =  stepi e 500 in
    ()
  with 
    | Event.End(_)
    | _ -> 
      Printf.printf "bye\n"; flush stdout
;;


let _ = try
  main (); 
  Printf.eprintf "main(): ok\n";flush stderr;
  clean_terminate(); 
  Printf.eprintf "clean_terminate(): okexit 0\n"; flush stderr;
  exit 0
  
 with e -> (Printf.printf "pb in test.ml :  %s\n"  (Printexc.to_string e) ) 

