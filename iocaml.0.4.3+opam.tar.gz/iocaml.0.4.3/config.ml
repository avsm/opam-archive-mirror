let default_browser_command = "xdg-open"
let static_js = false
