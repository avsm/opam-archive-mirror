let default_browser_command = "open"
let static_js = false
