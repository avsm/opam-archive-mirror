#require "astring,ptime";;
#directory "_build/src";;
#load_rec "syslog_message.cmo";;
