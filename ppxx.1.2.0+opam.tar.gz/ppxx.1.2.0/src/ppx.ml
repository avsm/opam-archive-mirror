(* PPX related tools *)

open Utils

open Ast_mapper

let handle_error f =
  try f () with 
  | Syntaxerr.Error e ->
      !!% "%a@." Syntaxerr.report_error e;
      exit 2
  | e ->
      Format.eprintf "%a@."  Location.report_exception e;
      exit 2
  
    
let impl mapper fname =
  handle_error & fun () ->
    let str = Pparse.parse_implementation ~tool_name:"ppx" Format.err_formatter fname in
    let str = mapper.structure mapper str in
    Pprintast.structure Format.std_formatter str;
    Format.fprintf Format.std_formatter "@."

let intf mapper fname =
  handle_error & fun () ->
    let sg = Pparse.parse_interface ~tool_name:"ppx" Format.err_formatter fname in
    let sg = mapper.signature mapper sg in
    Pprintast.signature Format.std_formatter sg;
    Format.fprintf Format.std_formatter "@."
    
let anonymous mapper fname = 
  if Filename.check_suffix fname ".ml" then impl mapper fname (* .mlt ? *)
  else if Filename.check_suffix fname ".mli" then intf mapper fname 
  else assert false

let run opts name initf mapper = 

  let module Options = Compilerlib.BytecompOptions(struct
    let impl = impl mapper
    let intf = intf mapper
    let anonymous = anonymous mapper
  end) in
  let inappropriate =
    [ "-a"
    ; "-c"
    ; "-cc"
    ; "-cclib"
    ; "-ccopt"
    ; "-compat-32"
    ; "-custom"
    ; "-dllib"
    ; "-dllpath"
    ; "-for-pack"
    ; "-g"
    (* ; "-i" *)
    ; "-linkall"
    ; "-make-runtime"
    ; "-make_runtime"
    ; "-noassert"
    ; "-noautolink"
    ; "-o"
    ; "-output-obj"
    ; "-pack"
    ; "-pp"
    ; "-ppx"
    ; "-runtime-variant"
    ; "-use-runtime"
    ; "-use_runtime"
    ; "-where"
    ; "-"
    ; "-nopervasives"
    ; "-use-prims"
    ; "-drawlambda"
    ; "-dlambda"
    ; "-dinstr"
    ]
  in

  let debug = ref false in
  let option_list =
    ("-debug", Arg.Set debug, "debug mode")
    :: opts
    @ List.filter (fun (n,_,_) ->
      not & List.mem n inappropriate) Options.list
  in
  
  let rev_files = ref [] in 
  Arg.parse option_list
    (fun s -> rev_files := s :: !rev_files) (* will be handled by [Ast_mapper.apply] *)
    name;
  try
    match !debug, List.rev !rev_files with
    | true, files ->
        List.iter (initf (); anonymous mapper) files
    | false, [infile; outfile] ->
        initf ();
        Ast_mapper.apply ~source:infile ~target:outfile mapper
    | _ -> 
        failwith & name ^ " infile outfile"
  with
  | Location.Error e -> Location.report_error Format.err_formatter e
  
