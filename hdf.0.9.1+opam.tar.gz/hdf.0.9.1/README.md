OCaml HDF
---------

This library provides access to the HDF4 data reading and writing
library (http://www.hdfgroup.org/).  It provides both direct,
low-level access to HDF4 library functions as well as a higher level,
more OCaml-like interface.
