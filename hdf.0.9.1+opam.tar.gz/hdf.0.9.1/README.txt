(* OASIS_START *)
(* DO NOT EDIT (digest: 10bcbe3a07f5ff007b9efea005d3f45d) *)
This is the README file for the hdf distribution.

Bindings for the HDF4 library

This library provides access to the HDF4 data reading and writing library
(http://www.hdfgroup.org/). It provides both direct, low-level access to HDF4
library functions as well as a higher level, more OCaml-like interface.

See the files INSTALL.txt for building and installation instructions. 

Home page: https://github.com/hcarty/ocaml-hdf


(* OASIS_STOP *)
