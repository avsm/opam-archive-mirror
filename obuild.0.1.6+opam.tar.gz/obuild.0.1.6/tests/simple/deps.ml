
let main () =
  let _s = Str.quote "toto" in
  let _t = Unix.gettimeofday () in
  ()
;;

main ()
