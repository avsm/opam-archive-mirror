v0.5 (2015-06-06)
* update to mirage-types.2.3 (via mbr-format.0.3)
* add opam file
* new new-style travis configuration

v0.4 (2014-08-18)
* be consistent and use 'xe-unikernel-upload' everywhere

v0.3 (2014-08-18)
* interpret the .xe:server=<IP> as requiring HTTPS
* use the new ocaml-mbr Partition code
