### 2013-08-5 Version 0.67.0

- Support for lwt
- Change_collection,drop_database,drop_collection,ensure_index,drop_index,get_index,count command are now available
- MongoMetaOp: Helper for meta operation


### 2013-06-21 Version 0.66.1

Seperate `Bson` module out. Now `src folder` does not contain `Bson module`. Please refer to [Bson.ml](http://massd.github.io/bson/).

Added `compile.sh`.
