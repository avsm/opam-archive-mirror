(* File generated from gstreamer_idl.idl *)

type guint = int
and gint = int
and gchar = char
and gboolean = bool
and pGstElement
and pGstBin
and pGstCaps
and enum_1 =
  | GST_STATE_VOID_PENDING
  | GST_STATE_NULL
  | GST_STATE_READY
  | GST_STATE_PAUSED
  | GST_STATE_PLAYING
and gstState = enum_1
and enum_2 =
  | GST_STATE_CHANGE_FAILURE
  | GST_STATE_CHANGE_SUCCESS
  | GST_STATE_CHANGE_ASYNC
  | GST_STATE_CHANGE_NO_PREROLL
and gstStateChangeReturn = enum_2

external ocaml_gst_init : int -> string array option -> unit
	= "camlidl_gstreamer_idl_ocaml_gst_init"

external gst_version : unit -> guint * guint * guint * guint
	= "camlidl_gstreamer_idl_gst_version"

external gst_version_string : unit -> string
	= "camlidl_gstreamer_idl_gst_version_string"

external set_element_property_string : pGstElement -> string -> string -> unit
	= "camlidl_gstreamer_idl_set_element_property_string"

external set_element_property_bool : pGstElement -> string -> gboolean -> unit
	= "camlidl_gstreamer_idl_set_element_property_bool"

external set_element_property_int : pGstElement -> string -> gint -> unit
	= "camlidl_gstreamer_idl_set_element_property_int"

external set_element_caps : pGstElement -> pGstCaps -> unit
	= "camlidl_gstreamer_idl_set_element_caps"

external gst_element_link : pGstElement -> pGstElement -> gboolean
	= "camlidl_gstreamer_idl_gst_element_link"

external gst_element_set_state : pGstElement -> gstState -> gstStateChangeReturn
	= "camlidl_gstreamer_idl_gst_element_set_state"

external gst_element_factory_make : string -> string -> pGstElement
	= "camlidl_gstreamer_idl_gst_element_factory_make"

external gst_pipeline_new : string -> pGstElement
	= "camlidl_gstreamer_idl_gst_pipeline_new"

external gst_bin_of_element : pGstElement -> pGstBin
	= "camlidl_gstreamer_idl_gst_bin_of_element"

external gst_bin_add : pGstBin -> pGstElement -> gboolean
	= "camlidl_gstreamer_idl_gst_bin_add"

external gst_bin_get_by_name : pGstBin -> string -> pGstElement
	= "camlidl_gstreamer_idl_gst_bin_get_by_name"

external gst_caps_to_string : pGstCaps -> string
	= "camlidl_gstreamer_idl_gst_caps_to_string"

external gst_caps_from_string : string -> pGstCaps
	= "camlidl_gstreamer_idl_gst_caps_from_string"

external parse_launch : string -> pGstElement
	= "camlidl_gstreamer_idl_parse_launch"

