/* File generated from gstreamer_idl.idl */

#ifndef _CAMLIDL_GSTREAMER_IDL_H
#define _CAMLIDL_GSTREAMER_IDL_H

#ifdef __cplusplus
#define _CAMLIDL_EXTERN_C extern "C"
#else
#define _CAMLIDL_EXTERN_C extern
#endif

#ifdef _WIN32
#pragma pack(push,8) /* necessary for COM interfaces */
#endif

typedef unsigned int guint;

typedef int gint;

typedef char gchar;

typedef int gboolean;

_CAMLIDL_EXTERN_C void ocaml_gst_init(/*in*/ int argc, /*in*/ char **argv);

_CAMLIDL_EXTERN_C void gst_version(/*out*/ guint *major, /*out*/ guint *minor, /*out*/ guint *micro, /*out*/ guint *nano);

_CAMLIDL_EXTERN_C gchar *gst_version_string(void);

typedef void *pGstElement;
extern void gst_finalize_element(pGstElement *);

typedef void *pGstBin;
extern void gst_finalize_bin(pGstBin *);

typedef void *pGstCaps;
extern void gst_finalize_caps(pGstCaps *);

_CAMLIDL_EXTERN_C void set_element_property_string(/*in*/ pGstElement e, /*in*/ char *n, /*in*/ char *v);

_CAMLIDL_EXTERN_C void set_element_property_bool(/*in*/ pGstElement e, /*in*/ char *n, /*in*/ gboolean v);

_CAMLIDL_EXTERN_C void set_element_property_int(/*in*/ pGstElement e, /*in*/ char *n, /*in*/ gint v);

_CAMLIDL_EXTERN_C void set_element_caps(/*in*/ pGstElement e, /*in*/ pGstCaps c);

_CAMLIDL_EXTERN_C gboolean gst_element_link(/*in*/ pGstElement src, /*in*/ pGstElement dest);

typedef enum {
GST_STATE_VOID_PENDING = 0,
GST_STATE_NULL = 1,
GST_STATE_READY = 2,
GST_STATE_PAUSED = 3,
GST_STATE_PLAYING = 4,
} GstState;

typedef enum {
GST_STATE_CHANGE_FAILURE = 0,
GST_STATE_CHANGE_SUCCESS = 1,
GST_STATE_CHANGE_ASYNC = 2,
GST_STATE_CHANGE_NO_PREROLL = 3,
} GstStateChangeReturn;

_CAMLIDL_EXTERN_C GstStateChangeReturn gst_element_set_state(/*in*/ pGstElement element, /*in*/ GstState state);

_CAMLIDL_EXTERN_C pGstElement gst_element_factory_make(/*in*/ gchar const *factoryname, /*in*/ gchar const *name);

_CAMLIDL_EXTERN_C pGstElement gst_pipeline_new(/*in*/ gchar const *name);

_CAMLIDL_EXTERN_C pGstBin gst_bin_of_element(/*in*/ pGstElement e);

_CAMLIDL_EXTERN_C gboolean gst_bin_add(/*in*/ pGstBin bin, /*in*/ pGstElement element);

_CAMLIDL_EXTERN_C pGstElement gst_bin_get_by_name(/*in*/ pGstBin bin, /*in*/ gchar const *name);

_CAMLIDL_EXTERN_C gchar *gst_caps_to_string(/*in*/ pGstCaps caps);

_CAMLIDL_EXTERN_C pGstCaps gst_caps_from_string(/*in*/ gchar const *string);

_CAMLIDL_EXTERN_C pGstElement parse_launch(/*in*/ gchar const *pipeline_description);

#ifdef _WIN32
#pragma pack(pop)
#endif


#endif /* !_CAMLIDL_GSTREAMER_IDL_H */
