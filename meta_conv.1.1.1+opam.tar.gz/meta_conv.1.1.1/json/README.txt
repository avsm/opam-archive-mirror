This is just a sample implementation of JSON coders.
If you want to use JSON coders, I propose using tiny_json and tiny_json_conv.
