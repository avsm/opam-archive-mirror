// @flow
var M = require('M');;

var x : M.C = new M.C();
var z : typeof M.x = x.y;
var m : string = z;
var obj = new I();
var ret: string = obj.get_y(x);
