#ifndef __ucaml_pervasives_h__
#define __ucaml_pervasives_h__

static inline void print_int(int x)
{ 
    printf("%d", x); 
}

#endif 
