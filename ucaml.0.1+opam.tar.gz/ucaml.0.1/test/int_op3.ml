let () = 
  let rec print_fst x y = print_int x in
    print_fst (1 + -1) (10 + -9)

