let () = 
  let rec suc x = x + 1 in
    print_int (suc 0)
