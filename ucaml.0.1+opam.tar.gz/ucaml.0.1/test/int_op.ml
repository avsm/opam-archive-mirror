let () = 
  let n = 12 / 4 + 1 + 2 - 3 in
    print_int n


