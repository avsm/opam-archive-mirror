let () = 
  let b = true in
    ()
