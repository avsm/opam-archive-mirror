let () = 
  let x = 0 in
    print_int x

