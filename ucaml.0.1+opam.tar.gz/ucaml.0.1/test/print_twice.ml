let () = 
  print_int 1;
  print_int 2

