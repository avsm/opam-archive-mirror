let () =
  let a = true in
  let a = 1 in
  print_int a

