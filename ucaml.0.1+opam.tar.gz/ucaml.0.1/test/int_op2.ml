let () = 
  let n = 10 * (12 + 4) in
    print_int n

