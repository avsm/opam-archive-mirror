let () = 
  let t = not (not (not false)) in
    print_int (if t then 1 else 0)
