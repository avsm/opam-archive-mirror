let () = 
  let rec id x = x in
  let rec f y = 
    let z = y in 
      z in
    print_int (f 0)
    
