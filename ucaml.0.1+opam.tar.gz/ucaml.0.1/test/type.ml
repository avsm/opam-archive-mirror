type t = int

let foo = 1

let () = print_int foo
