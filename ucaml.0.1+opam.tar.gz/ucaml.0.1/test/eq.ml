let () =
  let rec eq x y = x = y in
  if (1 = 1) then print_int 1 else print_int 0;
  if (eq 1 1) then print_int 1 else print_int 0


