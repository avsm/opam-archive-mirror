let () = 
  let rec id x = x in
  print_int (id 0)

