(* Short format notations *)

(* Copyright 2009 Tiphaine Turpin

   This file is part of Format.

   Format is free software: you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Format is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Format.  If not, see <http://www.gnu.org/licenses/>. *)

open Pa_format
open Camlp4.PreCast
open Syntax

(* Extending Ocaml expressions to accept short formats *)
EXTEND Gram
    GLOBAL: expr a_STRING;
    expr: LEVEL "simple" [
      [ s = a_STRING ; LIDENT "s" -> expander (new sprint) _loc _loc s
      | s = a_STRING ; LIDENT "b" -> expander (new bprint) _loc _loc s
      | s = a_STRING ; LIDENT "o" -> expander (new print) _loc _loc s
      | s = a_STRING ; LIDENT "e" -> expander (new eprint) _loc _loc s
      | s = a_STRING ; LIDENT "f" -> expander (new fprint) _loc _loc s
      | s = a_STRING ; LIDENT "ps" -> expander (new psprint) _loc _loc s
      | s = a_STRING ; LIDENT "pb" -> expander (new pbprint) _loc _loc s
      | s = a_STRING ; LIDENT "po" -> expander (new pprint) _loc _loc s
      | s = a_STRING ; LIDENT "pe" -> expander (new peprint) _loc _loc s
      | s = a_STRING ; LIDENT "pf" -> expander (new pfprint) _loc _loc s ]
    ];
END
;;
