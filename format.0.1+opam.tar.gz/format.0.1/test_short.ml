(* Short format notations example*)
(*********************************)

(* Short notations work by adding a letter at the end of strings. Namely,
   - ""s instead of <:sprint<>>
   - ""b instead of <:bprint<>>
   - ""o instead of <:print<>>
   - ""e instead of <:eprint<>>
   - ""f instead of <:fprint<>>
   - ""ps instead of <:psprint<>>
   - ""pb instead of <:pbprint<>>
   - ""po instead of <:pprint<>>
   - ""pe instead of <:peprint<>>
   - ""pf instead of <:pfprint<>>

   For example: *)

let _ = prerr_endline "2 + 2 = $d:2+2$";;
let _ = prerr_endline "2 + 2 = $d:2+2$"s;;
let _ = "2 + 2 = $d:2+2$"o;;
let _ = "2 + 2 = $d:2+2$"e;;
let _ = "2 + 2 = $d:2+2$"f stdout;;

let _ =
  let b = Buffer.create 16 in
    "2 + 2 = $d:2+2$"b b;
    prerr_endline (Buffer.contents b)

let _ = "2 + 2 = $d:2+2$"ps;;
let _ = "2 + 2 = $d:2+2$"po;;
let _ = "2 + 2 = $d:2+2$"pe;;
let _ = "2 + 2 = $d:2+2$"pf Format.std_formatter;;

let _ =
  let b = Buffer.create 16 in
    "2 + 2 = $d:2+2$"pb b;
    prerr_endline (Buffer.contents b)

(* Double quotes must be escaped when using short syntax *)
let _ = <:eprint<not escaped: ""\n>>;;
let _ = "escaped: \"\"\n"e;;
