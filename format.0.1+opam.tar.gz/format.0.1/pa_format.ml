(* Format quotations *)

(* Copyright 2009 Tiphaine Turpin

   This file is part of Format.

   Format is free software: you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Format is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Format.  If not, see <http://www.gnu.org/licenses/>. *)

open Camlp4.PreCast
open FormatParser

(* TODO: prefix flush and output_* by Pervasives. (currently there is
   a problem with batteries). *)

(* Concatenate successive string items in a format (due to escaped
   characters) *)
let rec compact = function
  | String s :: String s' :: format -> compact (String (s ^ s') :: format)
  | item :: format ->
      (match item with
	 | If (e, l, r) -> If (e, compact l, compact r)
	 | For (p, e, e', f, sep) ->  For (p, e, e', compact f, compact sep)
	 | item -> item)
      :: compact format
  | [] -> []

(* Printing parameters for the format translator *)
class virtual printer _loc = object (this)
  method virtual print_string : Ast.expr
  method virtual printf : Ast.expr

  method print_expr e = function
    | "a" -> failwith "pa_format: 'a' format is not supported"
    | typ -> <:expr< $this#printf$ $str:"%" ^ typ$ $e$ >>

  method virtual flush : Ast.expr
  method virtual wrap : Ast.expr -> Ast.expr
end

(* Convert a format (i.e., a list of items) into an Ocaml expression
   of type unit which writes this format, according to the definition
   of writing given by [printer] *)
let rec format2unit_expr printer _loc items =
  List.fold_left
    (fun acc i -> <:expr< $acc$ ; $item2unit_expr printer _loc i$ >>)
    <:expr< () >>
    items

and item2unit_expr printer _loc = function
  | String s -> <:expr< $printer#print_string$ $str:String.escaped s$ >>
  | Value (typ, e) -> printer#print_expr e typ
  | If (e, l, r) -> <:expr<
      if $e$ then
	$format2unit_expr printer _loc l$
      else
	$format2unit_expr printer _loc r$
    >>
  | For (p, e, e', f, sep) ->
      let iter = match e' with Some e' -> e' | None -> <:expr< List.iter >> in
	<:expr<
	  let __format_first = ref true in
	    $iter$
	      (function $p$ ->
		 if not ! __format_first then
		   $format2unit_expr printer _loc sep$
		 else
		   __format_first := false;
		 $format2unit_expr printer _loc f$) $e$
	>>
  | Flush -> printer#flush

(* Convert a format into an Ocaml expressions of the appropriate type
   with respect to [printer]: [string], [Buffer.t -> unit], [unit],
   [out_channel -> unit], or [formatter -> unit]. *)
let format2expr printer _loc items = printer#wrap (format2unit_expr printer _loc items)

(* Map a converting function to an expander, which first parses the
   input string and converts it into an Ocaml expression *)
let expander ?(shift = true) printer gloc _ (s:string) =
  let lexbuf = Lexing.from_string s in
  let pos = Loc.start_pos gloc in
  let pos =
    if shift then (* opening double quote *)
      { pos with Lexing.pos_cnum = pos.Lexing.pos_cnum + 1 }
    else
      pos
  in
    lexbuf.Lexing.lex_abs_pos <- pos.Lexing.pos_cnum;
    lexbuf.Lexing.lex_start_pos <- pos.Lexing.pos_cnum;
    lexbuf.Lexing.lex_last_pos <- pos.Lexing.pos_cnum;
    lexbuf.Lexing.lex_start_p <- pos;
    lexbuf.Lexing.lex_curr_p <- pos;
    try
      format2expr (printer gloc) gloc
	(compact (FormatParser.format FormatLexer.token lexbuf))
    with
      | Failure "lexing: empty token" as e ->
	  Loc.raise (Loc.of_lexing_position lexbuf.Lexing.lex_curr_p) e
      | Parsing.Parse_error as e ->
	  Loc.raise (Loc.of_lexbuf lexbuf) e

(* Printers for the different ways of printing *)

class virtual bprint0 _loc = object
  inherit printer _loc as super
  method print_string = <:expr< Buffer.add_string __format_buf >>
  method printf = <:expr< Printf.bprintf __format_buf >>

  method print_expr e = function
    | "s" -> <:expr< Buffer.add_string __format_buf $e$ >>
    | "c" -> <:expr< Buffer.add_char __format_buf $e$ >>
    | "d" -> <:expr< Buffer.add_string __format_buf (string_of_int $e$) >>
    | "f" -> <:expr< Buffer.add_string __format_buf (string_of_float $e$) >>
    | "t" -> <:expr< $e$ __format_buf >>
    | typ -> super#print_expr e typ

  method flush = <:expr< () >>
end

class sprint _loc = object
  inherit bprint0 _loc
  method wrap e = <:expr<
    let __format_buf = Buffer.create 16 in
      $e$;
      Buffer.contents __format_buf
  >>
end

class bprint _loc = object
  inherit bprint0 _loc
  method wrap e = <:expr< function __format_buf -> $e$ >>
end

class print _loc = object
  inherit printer _loc as super
  method print_string = <:expr< Pervasives.print_string >>
  method printf = <:expr< Printf.printf >>

  method print_expr e = function
    | "s" -> <:expr< Pervasives.print_string $e$ >>
    | "c" -> <:expr< Pervasives.print_char $e$ >>
    | "d" -> <:expr< Pervasives.print_int $e$ >>
    | "f" -> <:expr< Pervasives.print_float $e$ >>
    | "t" -> <:expr< $e$ stdout >>
    | typ -> super#print_expr e typ

  method flush = <:expr< flush stdout >>
  method wrap e = e
end

class eprint _loc = object
  inherit printer _loc as super
  method print_string = <:expr< Pervasives.prerr_string >>
  method printf = <:expr< Printf.eprintf >>

  method print_expr e = function
    | "s" -> <:expr< Pervasives.prerr_string $e$ >>
    | "c" -> <:expr< Pervasives.prerr_char $e$ >>
    | "d" -> <:expr< Pervasives.prerr_int $e$ >>
    | "f" -> <:expr< Pervasives.prerr_float $e$ >>
    | "t" -> <:expr< $e$ stderr >>
    | typ -> super#print_expr e typ

  method flush = <:expr< flush stderr >>
  method wrap e = e
end

class fprint _loc = object
  inherit printer _loc as super
  method print_string = <:expr< output_string __format_ch >>
  method printf = <:expr< Printf.fprintf __format_ch >>
  method print_expr e = function
    | "s" -> <:expr< output_string __format_ch $e$ >>
    | "c" -> <:expr< output_char __format_ch $e$ >>
    | "d" -> <:expr< output_string __format_ch (Pervasives.string_of_int $e$) >>
    | "f" -> <:expr< output_string __format_ch (Pervasives.string_of_float $e$) >>
    | "t" -> <:expr< $e$ __format_ch >>
    | typ -> super#print_expr e typ
  method flush = <:expr< flush __format_ch >>
  method wrap e = <:expr< function __format_ch -> $e$ >>
end

class virtual pretty_printer _loc = object (this)
  inherit printer _loc as super
  method virtual private fmt : Ast.expr
  method print_string = <:expr< Format.fprintf $this#fmt$ >>
  method printf =  <:expr< Format.fprintf $this#fmt$ >>
  method print_expr e = function
    | "s" -> <:expr< Format.pp_print_string $this#fmt$ $e$ >>
    | "c" -> <:expr< Format.pp_print_char $this#fmt$ $e$ >>
    | "d" -> <:expr< Format.pp_print_int $this#fmt$ $e$ >>
    | "f" -> <:expr< Format.pp_print_float $this#fmt$ $e$ >>
    | "t" -> <:expr< $e$ $this#fmt$ >>
    | typ -> super#print_expr e typ
  method flush = <:expr< Format.pp_print_flush $this#fmt$ () >>
end

class virtual pbprint0 _loc = object
  inherit pretty_printer _loc as super
  method private fmt = <:expr< __format_fmt >>
end

class pbprint _loc = object
  inherit pbprint0 _loc as super
  method wrap e = <:expr<
    function __format_buf ->
      let __format_fmt = Format.formatter_of_buffer __format_buf in
	$e$;
	Format.pp_print_flush __format_fmt ()
  >>
end

class psprint _loc = object
  inherit pbprint0 _loc as super
  method wrap e = <:expr<
    let __format_buf = Buffer.create 16 in
    let __format_fmt = Format.formatter_of_buffer __format_buf in
      $e$;
      Format.pp_print_flush __format_fmt ();
      Buffer.contents __format_buf
  >>
end

class pprint _loc = object
  inherit pretty_printer _loc as super
  method private fmt = <:expr< Format.std_formatter >>
  method wrap e = e
end

class peprint _loc = object
  inherit pretty_printer _loc as super
  method private fmt = <:expr< Format.err_formatter >>
  method wrap e = e
end

class pfprint _loc = object
  inherit pretty_printer _loc as super
  method private fmt = <:expr< __format_fmt >>
  method wrap e = <:expr< function __format_fmt -> $e$ >>
end

(* Registering expanders *)
let _ =
  List.iter
    (function name, f ->
       Quotation.add name Syntax.Quotation.DynAst.expr_tag (expander ~shift:false f))
    ["sprint", new sprint;
     "bprint", new bprint;
     "print", new print;
     "eprint", new eprint;
     "fprint", new fprint;
     "psprint", new psprint;
     "pbprint", new pbprint;
     "pprint", new pprint;
     "peprint", new peprint;
     "pfprint", new pfprint]
