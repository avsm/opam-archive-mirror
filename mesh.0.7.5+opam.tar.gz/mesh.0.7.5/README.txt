(* OASIS_START *)
(* DO NOT EDIT (digest: 2841c381b5d6e81aa35dce8bb82534be) *)
This is the README file for the mesh distribution.

OCaml interface to various mesh generators, in particular triangle.

See the files INSTALL.txt for building and installation instructions. 

Home page: http://forge.ocamlcore.org/projects/mesh/


(* OASIS_STOP *)
