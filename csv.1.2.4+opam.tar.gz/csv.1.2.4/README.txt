(* OASIS_START *)
(* DO NOT EDIT (digest: 85740657a21ccd3aa9329963b4a1599c) *)
This is the README file for the csv distribution.

A pure OCaml library to read and write CSV files.

This is a pure OCaml library to read and write CSV files, including all
extensions used by Excel — eg. quotes, newlines, 8 bit characters in
fields, \"0 etc.

See the files INSTALL.txt for building and installation instructions. 


(* OASIS_STOP *)
