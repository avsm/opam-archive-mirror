* Deadline soon not being handled correctly. or is it?

* add a debug mode where the raw interaction with the server is logged
* more docs
* finish obean?
* add transparent pooling?

* tests for:
* deadline soon
* timeout
* releasing jobs
* burying jobs
* deleting jobs
