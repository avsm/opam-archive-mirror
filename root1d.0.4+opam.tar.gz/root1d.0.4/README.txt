(* OASIS_START *)
(* DO NOT EDIT (digest: 873b0e29bacc55411ddf74e036b19cc8) *)

root1d - Find roots of 1D functions.
====================================

Collection of functions to seek roots of functions float -> float. Pure OCaml
code.

See the file [INSTALL.txt](INSTALL.txt) for building and installation
instructions.

[Home page](http://forge.ocamlcore.org/projects/root1d/)

Copyright and license
---------------------

root1d is distributed under the terms of the GNU Lesser General Public
License version 3.0 with OCaml linking exception.

(* OASIS_STOP *)
