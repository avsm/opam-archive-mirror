let megabyte = String.make (1024 * 1024) ' '
;;
print_string megabyte
