(* OASIS_START *)
(* DO NOT EDIT (digest: cc026be493225874d2ee3bf0ccd677c5) *)

bson.ml - A bson data structure, including encoding/decoding
============================================================

See the file [INSTALL.txt](INSTALL.txt) for building and installation
instructions.

Copyright and license
---------------------

bson.ml is distributed under the terms of the MIT License.

(* OASIS_STOP *)
