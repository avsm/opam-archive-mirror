/**
 * @providesModule B
 * @flow
 */

module.exports = {
  numberValueB: 1,
  stringValueB: "someString"
};
