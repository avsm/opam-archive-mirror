open Types
open Error
open Result

module type S = sig
  type t
  
  module Encode : sig
    val tuple : t list -> t
    val variant : string -> t list -> t
    val poly_variant : string -> t list -> t
    val record : (string * t) list -> t
    val object_ : (string * t) list -> t
  end

  module Decode : sig
    val tuple   : t -> t list
    val variant : t -> string * t list
    val poly_variant : t -> string * t list
    val record  : t -> (string * t) list
    val object_ : t -> (string * t) list
  end
end

let tuple_arity_error exp_len act_len v = 
  `Error (Wrong_arity (exp_len, act_len, None), v)
let variant_arity_error type_name constructor_name exp_len act_len v = 
  `Error (Wrong_arity (exp_len, act_len, Some (type_name, constructor_name)), v)
let variant_unknown_tag_error type_name tag_name v =
  `Error (Unknown_fields (type_name, [ tag_name, v ]), v)
(*
let record_unknown_fields_error type_name v adrs =
  `Error (Unknown_fields (type_name, v), adrs) 
*)
let primitive_decoding_failure mes v = 
  `Error (Primitive_decoding_failure mes, v)

let field_assoc name v key alist (decode : (_,_) Decoder.t) =
  try 
    decode (List.assoc key alist)
  with Not_found -> 
    `Error (Required_fields_not_found (name, [key], alist), v)

let field_assoc_optional _name _v key alist (decode : (_,_) Decoder.t) =
  try 
    match decode (List.assoc key alist ) with
    | `Ok v -> `Ok (Some v)
    | `Error e -> `Error e
  with Not_found -> `Ok None

let filter_record_fields type_system actual =
  List.filter (fun (f,_) -> not (List.mem f type_system)) actual 

type ('host, 'target) field_checker =
    string (** type name *)
    -> 'target (** the input *)
    -> (string * 'target) list (** unknown fields *)
    -> (unit -> ('host, 'target Error.t) Result.t) 
    -> ('host, 'target Error.t) Result.t

let record_unknown_field_check name v unknowns k = match unknowns with
  | [] -> k ()
  | _ -> `Error (Unknown_fields (name, unknowns), v)

let record_ignore_unknown_fields _name _v _unknons k = k ()

let integer_of_float min max conv n =
  if floor n <> n then `Error "not an integer"
  else if min <= n && n <= max then `Ok (conv n)
  else `Error "overflow"

let generic_list_of gets d v = match gets v with
  | Some xs -> Result.map d xs
  | None -> 
      primitive_decoding_failure 
        "Meta_conv.Internal.generic_list_of: listable expected" 
        v

let generic_array_of gets d v =
  fmap Array.of_list 
  (generic_list_of gets d v)

let generic_option_of extract f v =
  match extract v with 
  | Some None -> `Ok None
  | Some (Some v) -> f v >>= fun x -> `Ok (Some x)
  | None -> 
      primitive_decoding_failure
        "Meta_conv.Internal.generic_option_of: option expected"
        v

let generic_lazy_t_of errorf (f : ('host, 'target) Decoder.t) v = 
  `Ok (lazy (
    match f v with
    | `Ok v -> v
    | `Error e -> errorf e
  ))

let generic_mc_lazy_t_of (f : ('host, 'target) Decoder.t) v = 
  `Ok (lazy (f v))

let generic_mc_fields_of get_fields (f : ('host, 'target) Decoder.t) target = 
  let open Result in
  match get_fields target with
  | None -> primitive_decoding_failure "mc_fields expected" target
  | Some fields ->
      map (fun (name, target) -> f target >>= fun host -> `Ok (name, host)) fields

let list_filter_map f xs = List.fold_right (fun x st -> 
  match f x with
  | None -> st
  | Some v -> v::st) xs []
