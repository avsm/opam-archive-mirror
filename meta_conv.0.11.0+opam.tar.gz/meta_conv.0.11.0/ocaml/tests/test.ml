open Meta_conv.Open
open Ocaml_conv

module Test1 = struct
  type t = Foo | Bar of int * string with conv(ocaml)
  
  let () = 
    let x = Bar (0, "hello") in
    assert (t_of_ocaml (ocaml_of_t x) = `Ok x)
end

module Test2 = struct
  type t = { foo : int; bar : float option } with conv(ocaml)
  
  let () = 
    let x = { foo = 3; bar = Some 1.2 } in
    assert (t_of_ocaml (ocaml_of_t x) = `Ok x)
end

module Test3 = struct
  open Test2
  type t = Test2.t with conv(ocaml)
  
  let () = 
    let x = { foo = 3; bar = Some 1.2 } in
    assert (t_of_ocaml (ocaml_of_t x) = `Ok x)
end

module Test4 = struct
  type t = Foo (:"foo":) | Bar (:"bar":) of int * string with conv(ocaml)
  
  let () = 
    let x = Bar (0, "hello") in
    assert (t_of_ocaml (ocaml_of_t x) = `Ok x)
end

module Test5 = struct
  type t (: Ignore_unknown_fields :) = { x : int; y : float } with conv (ocaml)
  type t' = { x' as "x" : int; y' as "y" : float; z' as "z" : unit  } with conv (ocaml)
  
  let () = 
    let r' = { x' = 1; y' = 1.0; z' = () }  in
    assert (t_of_ocaml (ocaml_of_t' r') = `Ok { x = 1; y = 1.0 })
end

module Test6 = struct
  type t = { x : int; y : float; rest : Ocaml.t mc_leftovers; } with conv (ocaml)
  type t' = { x' as "x" : int; y' as "y" : float; z' as "z" : unit  } with conv (ocaml)

  let format_t' = Ocaml.format_with ocaml_of_t'

  let () = 
    let r' = { x' = 1; y' = 1.0; z' = () }  in
    assert (t_of_ocaml (ocaml_of_t' r') = `Ok { x = 1; y = 1.0; rest = [ "z", Ocaml.Unit ] });
    assert (ocaml_of_t (match t_of_ocaml (ocaml_of_t' r') with `Ok v -> v | _ -> assert false) = ocaml_of_t' r');
    Format.eprintf "r' = %a@." format_t' r'
end

module Test7 = struct
  type t = { x : int; y : float; rest : Ocaml.t mc_leftovers; } with conv (ocaml)
  type t' = { x' as "x" : int; y' as "y" : float; z' as "z" : unit  } with conv (ocaml)

  let format_t = Ocaml.format_with ocaml_of_t

  let () = 
    let r' = { x' = 1; y' = 1.0; z' = () }  in
    let format_sprintf fmt = Format.(
      let buf = Buffer.create 100 in
      let ppf = formatter_of_buffer buf in
      kfprintf (fun ppf -> pp_print_flush ppf (); Buffer.contents buf) ppf fmt
    ) in
    let s = format_sprintf "%a" (Ocaml.format ~no_poly:false) (ocaml_of_t' r') in
    prerr_endline s;
    let o = match Ocaml.Parser.from_string s with [x] -> x | _ -> assert false in
    Format.eprintf "parse done: %a@." (Ocaml.format ~no_poly:false) o;
    try
      let r = t_of_ocaml_exn o in
      Format.eprintf "r = %a@." format_t r
    with
    | Ocaml_conv.Error e -> 
        Format.eprintf "ERR: %a@." (Meta_conv.Types.Error.format Ocaml.format) e
end

