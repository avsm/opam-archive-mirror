v0.8.1 2015-02-22 La Forclaz (VS)
---------------------------------

- Fix a bug in `String.Sub.span`.

v0.8.0 2015-12-14 Cambridge (UK)
--------------------------------

First release.
