Before 1.0:
==========

  * remove dependency on forkexec
  * remove dependency on stdext
  * improve ocamldoc
