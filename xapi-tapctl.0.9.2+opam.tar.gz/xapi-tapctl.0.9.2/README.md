Control a running tapdisk process
=================================

Tapdisk is a user-space process which serves a virtual disk image to a running
virtual machine. This library allows a running tapdisk to be manipulated, allowing
live statistics to be collected and live snapshots to be created.
