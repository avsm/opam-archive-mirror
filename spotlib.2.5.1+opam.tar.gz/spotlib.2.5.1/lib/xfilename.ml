open Filename

let split_extension s = 
  try
    let body = chop_extension s in
    body, 
    String.sub s 
      (String.length body) 
      (String.length s - String.length body)
  with
  | Invalid_argument _ -> s, ""

let is_root d = not (is_relative d) && dirname d = d

module Pervasives = struct
  let (^/) p1 p2 =
    if Filename.is_relative p2 then Filename.concat p1 p2 else p2
end
