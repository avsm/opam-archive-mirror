let to_string = Cduce_lib.Value.get_string_latin1

let print_xml_subst xml l =
  let l_subst = List.map 
    (fun (a,b) -> ((Cduce_lib.Ns.Uri.mk a), (Cduce_lib.Ns.Uri.mk b)))
    l in
  to_string (Cduce_lib.Print_xml.print_xml_subst ~utf8:true !Cduce_lib.Eval.ns_table xml l_subst)

let load_xml_subst s l =
  let l_subst = List.map 
    (fun (a,b) -> ((Cduce_lib.Ns.Uri.mk a), (Cduce_lib.Ns.Uri.mk b)))
    l in
  Cduce_lib.Load_xml.load_xml_subst ~ns:true s l_subst;;

let writer accum data =
  Buffer.add_string accum data;
  String.length data

let showContent content =
  Printf.printf "%s" (Buffer.contents content);
  flush stdout

let showInfo connection =
  Printf.printf "Time: %f\nURL: %s\n"
    (Curl.get_totaltime connection)
    (Curl.get_effectiveurl connection)

let send msg host action content_type =
  let result = Buffer.create 16384 in
  Curl.global_init Curl.CURLINIT_GLOBALALL;
  begin
    let errorBuffer = ref "" in
    try
      let connection = Curl.init () in
      Curl.set_errorbuffer connection errorBuffer;
      Curl.set_writefunction connection (writer result);
      Curl.set_followlocation connection true;
      Curl.set_url connection host;
      Curl.setopt connection (Curl.CURLOPT_POST true);
      Curl.setopt connection (Curl.CURLOPT_POSTFIELDS
			      ("<?xml version=\"1.0\" encoding=\"UTF-8\"?>" ^
	  msg));
      Curl.setopt connection (Curl.CURLOPT_HTTPHEADER 
				[("Content-Type: " ^ content_type);
				 "Connection: close";
				 ("SOAPAction: \"" ^ action ^ "\"")]);
      Curl.perform connection;
      showContent result;
      showInfo connection;
      Curl.cleanup connection
    with
      | Curl.CurlException (reason, code, str) ->
	  Printf.fprintf stderr "Error: %s\n" !errorBuffer
      | Failure s ->
	  Printf.fprintf stderr "Caught exception: %s\n" s
  end;
  Curl.global_cleanup ();
  Buffer.contents result
