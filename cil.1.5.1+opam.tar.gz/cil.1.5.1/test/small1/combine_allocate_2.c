

__inline static void *allocate (unsigned int __10884_34___n);

__inline static void * allocate (unsigned int __10884_34___n)
{
    return 0;
}


__inline static void  *allocate___0  (unsigned int __11367_34___n);


__inline static void * allocate___0 (unsigned int    __11367_34___n)
{
    return 0;
}



int main () {
  allocate___0(0);
  return 0;
}
