typedef int ptrdiff_t;
typedef int FILE;
static __inline__ ptrdiff_t theFunc (const FILE * __18137_44___f) { }
