void f(int x){
  /* This is illegal C syntax (missing ;) */
  switch(x){default:};
}
