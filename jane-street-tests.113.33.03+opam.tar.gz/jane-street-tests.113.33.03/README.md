Jane Street Tests
=================

This packages doesn't do anything interesting, it just contains test
for the various bits of Jane Street libraries and tools.

You can however use the various tests as inspiration for how to setup
things such as inline tests or inline expect tests.
