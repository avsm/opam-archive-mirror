#verbose true;;

6 * 7
[%%expect{|
- : int = 2
|}]
