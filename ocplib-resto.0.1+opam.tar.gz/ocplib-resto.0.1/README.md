# ocplib-resto (WIP)

This is a minimal OCaml library for type-safe HTTP/JSON RPCs.

This is based on a notion of service, *à la* Eliom, and it uses
`ocplib-json-typed` for self-documenting JSON encoders.

See `src/ezResto_test.ml` or `src/reste_test.ml` for example.`