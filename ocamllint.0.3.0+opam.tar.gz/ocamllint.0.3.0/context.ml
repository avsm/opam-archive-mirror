type t = Location.t option

let make ?loc () = loc

let loc x = x
