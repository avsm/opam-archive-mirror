v0.6.0 2016-11-24
-----------------

Extract caching code from LibreS3 into its own library.
