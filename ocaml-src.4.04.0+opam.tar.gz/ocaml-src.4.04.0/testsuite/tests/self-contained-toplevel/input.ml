print_endline Foo.value;;
