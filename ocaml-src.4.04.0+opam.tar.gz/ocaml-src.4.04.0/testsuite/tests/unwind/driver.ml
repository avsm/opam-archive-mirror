let () =
  Mylib.foo1 Mylib.bar 1 2 3 4 5 6 7 8 9 10;
  Mylib.foo2 Mylib.baz 1 2 3 4 5 6 7 8 9 10
