let () = Format.pp_set_margin Format.std_formatter 20;;

1 + "foo";;

let () = Format.pp_set_margin Format.std_formatter 80;;

1 + "foo";;
