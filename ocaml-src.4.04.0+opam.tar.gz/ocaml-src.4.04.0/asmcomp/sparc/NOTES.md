# Supported platforms

SPARC v8 and up, in 32-bit mode.

Operating systems: Solaris, Linux
  (abandoned since major Linux distributions no longer support SPARC).

Status of this port: nearly abandoned
  (no hardware or virtual machine available for testing).

# Reference documents

* Instruction set architecture:
  _The SPARC Architecture Manual_ version 8.
* ELF application binary interface:
  _System V Application Binary Interface,
   SPARC Processor Supplement_
