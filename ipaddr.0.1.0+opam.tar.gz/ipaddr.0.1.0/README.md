# ocaml-ipaddr

A library for manipulation of IP address representations.

Features:

 * No dependencies
 * oUnit-based tests
 * IPv4 support
 * IPv4 CIDR prefix support
 * V4 and V4.Prefix modules are Map.OrderedType
