0.1.0 (2015-01-24):
* initial release