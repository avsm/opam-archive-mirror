(* #use this to setup the interactive environment. *)

#require "cstruct, cstruct.syntax, sexplib.syntax, nocrypto";;

#directory "_build/src";;
#load_rec "otr.cmo";;

