type t = bytes

let create = Bytes.create
let length = Bytes.length
