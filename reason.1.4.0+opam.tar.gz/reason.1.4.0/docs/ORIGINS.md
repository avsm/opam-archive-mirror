The primary code for these docs was forked from Flatdoc. All code forked from Flatdoc is under Flatdoc's original license.

Inside of nested directories, are copies of other projects, which are under the licenses listed there.

