# language-reason package

Grammar forked from
[Atom-Rust](https://github.com/zargony/atom-language-rust) and therefore the
atom-reason grammar is also licensed under the MIT license. The
included file LICENSE.grammar is the license for the Reason
  grammar/reason.cson files:
