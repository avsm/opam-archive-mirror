(* A *)

type x = 
  (* A *)
  | Foo

  (* B *)

  | Bar

(* AA *)

(* D *)
let x = 3

module M = struct
  (* M1 *)
  let x =
    a
  (* M2 *)
  let y =
    b

  (* M3 *)
  (* M4 *)
end

(* ending comments *)

