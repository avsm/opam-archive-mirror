let a =
  {
    somerecord
    with
      a = b;
      c = d;
  }

let a =
  {
    somerecord
    with a = b;
         c = d;
  }

let z =
  { recofzfzfzrd   with a = bli; bzeefe =
                                   k
                      ; efgeg = a
  }

let b =
  let z =
    {           reczfzrd                  with a = bli;
                                               bzeefe = _;
    }

let b =
  let z =
    { reczfzrd with a = bli;
                    bzeefe
    }
