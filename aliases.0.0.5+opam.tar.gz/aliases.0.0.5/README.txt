(* OASIS_START *)
(* DO NOT EDIT (digest: 2abc06ab1c2fad7febe5a89fad2d9f98) *)
This is the README file for the aliases distribution.

In memory indexes

Implemtation of some data structure for :

- temporal index : bitree

- geographic index : quadtree

- string autocomplete : ptree, radix

See the files INSTALL.txt for building and installation instructions. 

Home page: https://github.com/besport/ocaml-aliases


(* OASIS_STOP *)
