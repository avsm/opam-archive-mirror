Ocaml-aliases
==========
 * quadtree
 * patriciatree
 * bitree

Ocaml-aliases is part of the Be Sport codebased and is released under the LGPL.

Copyright 2012 Be Sport, Inc - 580 Howard St San Francisco 94105 CA USA

For more information, contact hackers@besport.com

About Be Sport
==============

We believe that sport identity is defined by sport activity. Our goal is to bring you closer to your sport community so that you can be more involved in what matters to you. We want to help you discover local clubs and events, learn about potential teammates and opponents, share your goals and accomplishments, and maintain an online presence in your sport community.

Be Sport is currently in development for browser and mobile platforms. We would love to hear your ideas on how to make them better and easier to use. Both will be officially launched in the summer of 2012.

Game on!

Checkout http://www.besport.com
