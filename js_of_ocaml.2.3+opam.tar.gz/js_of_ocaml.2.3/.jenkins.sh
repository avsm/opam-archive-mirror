opam pin js_of_ocaml .
opam install --deps-only js_of_ocaml
opam install --verbose js_of_ocaml
opam remove --verbose js_of_ocaml
