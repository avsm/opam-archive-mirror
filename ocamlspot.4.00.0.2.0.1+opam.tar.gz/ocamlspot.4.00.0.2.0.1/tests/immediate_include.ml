include struct let (* x => *) x (* <= x *) = 1 end

let _ = x (* ? x *)
