`mirage-tcpip` provides a networking stack for the Mirage operating
system that supports TCP/IPv4, ARPv4, DHCPv4 and UDPv4.

WWW: <http://openmirage.org>
E-mail: <mirageos-devel@lists.xenproject.org>
