/*
The datakit package contains common patterns over 9P, which avoids the need
for applications to use 9P directly.
*/
package datakit
