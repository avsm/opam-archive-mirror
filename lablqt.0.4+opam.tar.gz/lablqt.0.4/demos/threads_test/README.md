Demo with OCaml threads from stdlib Thread module.

Use `./configure/`, `make` and `./program.native` to run the demo.

The demo starts a background thread which updates GUI text every second.

