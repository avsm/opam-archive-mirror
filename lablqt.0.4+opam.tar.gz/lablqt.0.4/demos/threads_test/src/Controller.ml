open QmlContext

class virtual controller = object(self)
  method virtual descr   : string[@@qtprop]
end[@@qtclass]
