This is very small example about sending data to OCaml side and changing properties of GUI
controls from OCaml side. I don't really remember why I have created it :)

===============================================
It is a demo for lablqt (outdated) introduction from:
    https://github.com/Kakadu/lablqt/wiki/Using-mocml-with-QtQuick-(description-of-hallo-world-app)
New helloworld tutorial can be found at: http://kakadu.github.io/lablqt/qtquick-helloworld.html

N.B. This example is not built automatically by `$LABLQT_ROOT/qml/configure`.

N.B. Don't forget that QtQuick 1.0 == QtDeclarative from Qt 4.x,
QtQuick 2.0 == QtDeclarative from Qt5.
