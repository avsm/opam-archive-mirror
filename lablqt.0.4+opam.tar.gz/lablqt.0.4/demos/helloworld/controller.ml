open QmlContext

class virtual controller = object(self)

  method virtual onMouseClicked: string  -> unit[@@qtmeth]


end[@@qtclass]
