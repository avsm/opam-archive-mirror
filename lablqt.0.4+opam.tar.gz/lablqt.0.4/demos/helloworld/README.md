
In this example you can find QML GUI with clickable area. After clicking OCaml
prints some text to terminal.

OCaml startup code is added too.

