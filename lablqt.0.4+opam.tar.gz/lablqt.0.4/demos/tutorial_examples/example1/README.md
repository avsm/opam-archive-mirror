For compilation you need  correct Qt5 environment with LABLQT variable set.

In this example you can find QML GUI with onclick handler in JavaScript.
OCaml startup code is added too.

