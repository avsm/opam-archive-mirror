This is source files for OLD tutorial about lablqt 
(located in http://kakadu.github.io/lablqt/tutorial.html).

The next version of tutorial is here: http://kakadu.github.io/lablqt/tutorial2.html 
Demos for next version of tutorial: https://github.com/Kakadu/lablqt/tree/gh-pages/demos/0.3


