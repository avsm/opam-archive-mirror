#require "oml" ;;
#show_module Oml ;;
(*module Oml :
  sig
    module Util : sig  end
    module Vectors : sig  end
    module Matrices : sig  end
    module Continued_fraction : sig  end
    module Functions : sig  end
    module Distributions : sig  end
    module Estimations : sig  end
    module Descriptive : sig  end
    module Inference : sig  end
    module Svd : sig  end
    module Regression : sig  end
    module Sampling : sig  end
    module Solvers : sig  end
    module Running : sig  end
    module Classify : sig  end
    module Measures : sig  end
    module Pca : sig  end
  end *)
open Oml ;;
