open Oml.Classification
module P = Probabilities

module IrisEncoded =
  struct
    type clas = [ `setosa | `versicolor | `virginica ]
    type feature = float array
    let encoding arr = arr
    let size = 4
  end

module IrisMlr = Logistic_regression.Multiclass(IrisEncoded)
(* #require dsfo *)
let irismlr = IrisMlr.estimate Iris.iris
let perf =
  Iris.iris
  |> List.map (fun (c, f) ->
      c, P.most_likely (IrisMlr.eval irismlr f))

let describe msg perf =
  let correct =
    List.fold_left (fun c (a,p) -> if a = p then c + 1 else c) 0 perf
  in
  let total = List.length perf in
  let pct_c = (float correct) /. (float total) in
  Printf.printf "%s: %0.3f correct\n" msg pct_c

let () = describe "Multiclass" perf

module IrisLr = Logistic_regression.Binary(IrisEncoded)

let irislr = IrisLr.estimate Iris.iris
let twoclassperf =
  Iris.iris
  |> List.map (fun (c, f) ->
      c, P.most_likely (IrisLr.eval irislr f))

let () = describe "Two class" twoclassperf

module IrisJustSetosa =
  struct
    type clas = [ `setosa | `notsetosa ]
    type feature = float array
    let encoding arr = arr
    let size = 4
  end

module IrisLr_Js = Logistic_regression.Binary(IrisJustSetosa)

let just_setosa =
  Iris.iris
  |> List.map (fun (c,f) ->
      match c with
      | `setosa -> `setosa, f
      | _       -> `notsetosa, f)

let irislr_js = IrisLr_Js.estimate just_setosa
let justsetosaperf =
  just_setosa
  |> List.map (fun (c, f) ->
      c, P.most_likely (IrisLr_Js.eval irislr_js f))

let () = describe "Just Setosa" justsetosaperf

