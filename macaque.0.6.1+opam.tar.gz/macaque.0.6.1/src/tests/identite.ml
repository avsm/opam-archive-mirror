open Sql

let id table = << t | t in $table$ >>

(*
  sh infer.sh tests/identite.ml
*)
