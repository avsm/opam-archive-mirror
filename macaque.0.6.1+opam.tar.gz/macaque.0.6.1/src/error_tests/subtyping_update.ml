let _ = <:update< t in $Base.recette$ := $ <:value< {nom = t.nom} >> $ | >>
