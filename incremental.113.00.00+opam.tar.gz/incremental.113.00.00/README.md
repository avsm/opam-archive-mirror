# incremental
A library for incremental computations
https://blogs.janestreet.com/introducing-incremental/
