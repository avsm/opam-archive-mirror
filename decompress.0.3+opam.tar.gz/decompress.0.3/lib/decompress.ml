module type Bytes = Decompress_common.Bytes
module type String = Decompress_common.String

module Inflate = Decompress_inflate
module Deflate = Decompress_deflate
