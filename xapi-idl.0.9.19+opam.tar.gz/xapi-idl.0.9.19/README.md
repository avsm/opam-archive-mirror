xcp-idl
=======

This repository contains

  1. interface definitions for xapi toolstack services
  2. common boilerplate for toolstack clients and servers, including
     * configuration file parsing
     * argument parsing
     * RPCs
