# Software supporting BSD Owl Scripts

Some software comes with handy scripts using BSD Make Pallàs
Scripts, we list these friends here:

- [Bhrìd TeX](https://bitbucket.org/michipili/bhrid/), a family of TeX formats;
- [Gasoline](https://bitbucket.org/michipil/gasoline), an
  OCaml library focused on the application domain;
- [Abach](https://bitbucket.org/michipil/abach), a would-be
  geometry-oriented computation library, for the OCaml language.
