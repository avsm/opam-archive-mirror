= Notes about Make variables =

| Operating system                 | ${unix}                   | ${.MAKE.OS}   |
| Debian 3.16.7-2 (2014-11-06)     | We run Debian             | Linux         |
| Darwin 10.8.0                    | We run Darwin.            | Darwin        |
| NetBSD 6.1.5                     | We run NetBSD.            | {EMPTY}       |
| FreeBSD 10.1-RELEASE             | We run FreeBSD, not UNIX. | FreeBSD       |
| CYGWIN_NT-5.1 1.7.32 (0.274/5/3) | We run CYGWIN_NT-5.1.     | CYGWIN_NT-5.1 |
