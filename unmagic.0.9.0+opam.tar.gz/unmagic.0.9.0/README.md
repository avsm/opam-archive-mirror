Read unmagic.mli
