#!/bin/sh

corebuild -tag annot -pkgs conduit.async ssl_echo.native
