Mirage console implementation for Solo5
