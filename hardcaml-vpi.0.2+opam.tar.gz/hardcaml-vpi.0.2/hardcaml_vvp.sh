LD_LIBRARY_PATH=`ocamlc -where` vvp -M`opam config var lib`/hardcaml-vpi -mcosim $1
