## OCaml bindings to OS X file system access control list system calls

These bindings use [ctypes](https://github.com/ocamllabs/ocaml-ctypes)
for type-safe stub generation.
