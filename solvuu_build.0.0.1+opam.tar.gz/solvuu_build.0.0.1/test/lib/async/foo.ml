open Async.Std

let x = Deferred.return 42

