#!/bin/bash                                                                                                                                                                                                                                                       
while true; do curl localhost:8080 > /dev/null 2>&1; done
