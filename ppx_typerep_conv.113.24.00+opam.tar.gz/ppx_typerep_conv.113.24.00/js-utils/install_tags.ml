let package_name = "ppx_typerep_conv"

let sections =
  [ ("lib",
    [ ("built_lib_ppx_typerep_conv", None)
    ],
    [ ("META", None)
    ])
  ]
