0.2.1 / 2014-11-14
==================

  * Removed dependency on Core (now Core_kernel).

0.2.0 / 2014-11-14
==================

  * Package name change: Vcard -> Sociaml_vcard.
  * Licence change to GPL-V3.

0.1.0 / 2014-10-06
==================

  * Initial commit, support for parsing and printing vCard 4.0 formatted data.