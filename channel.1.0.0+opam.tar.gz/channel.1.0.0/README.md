## Mirage channels

An implementation of `V1.CHANNEL` using page aligned buffers.