#include "sha2.h"
#include "md5.h"
#include "rijndael.h"
#include "d3des.h"

size_t nocrypto_stub_sizeof_md5_ctx ();
size_t nocrypto_stub_sizeof_sha_ctx ();
