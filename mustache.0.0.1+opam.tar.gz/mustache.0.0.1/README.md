ocaml-mustache
==============

mustache.js logic-less templates in OCaml

http://mustache.github.io/
