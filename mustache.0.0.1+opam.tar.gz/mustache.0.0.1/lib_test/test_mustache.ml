open OUnit2
open Printf
module List = ListLabels
module String = StringLabels

let list_string_printer s =
  "(" ^ (String.concat ~sep:";" s) ^ ")"

let token1 _ =
  let s = "  rudi  __ testing _ 123 __ kthulu _ borg_453" in
  let (words, numbers, text) = (ref [], ref [], ref 0) in
  let (e_words, e_numbers, e_text) = (
    ["rudi"; "testing"; "kthulu"; "borg"],
    ["123"; "453"],
    5
  ) in
  let tokens = Mustache.tokenize s [
    (`Word, " *\\([a-z]+\\) *");
    (`Number, " *\\([0-9]+\\) *");
  ] in
  tokens |> List.iter ~f:(function
    | `Text s -> incr text
    | `Token (`Word, s) -> words := s :: (!words)
    | `Token (`Number, s) -> numbers := s :: (!numbers)
  );
  let printer = list_string_printer in
  assert_equal ~printer ~msg:"words" !words (List.rev e_words);
  assert_equal ~printer ~msg:"numbers" !numbers (List.rev e_numbers);
  assert_equal ~msg:"text" ~printer:string_of_int !text e_text


let mustache1 _ =
  let s = "Hello {{ name }}!" in
  let tmpl = Mustache.of_string s in
  (* printf "tmpl parsed: %s\n" (Mustache.to_string tmpl); *)
  let js = `O ["name", `String "testing"] in
  (* printf "Rendered: %s\n" (Mustache.render tmpl js); *)
  assert_equal "Hello testing!" (Mustache.render tmpl js)

let mustache2 _ =
  let tmpl = Mustache.of_string "{{#bool}}there{{/bool}}" in
  let js' b = `O ["bool", `Bool b] in
  assert_equal "there" (Mustache.render tmpl @@ js' true);
  assert_equal "" (Mustache.render tmpl @@ js' false)

let mustache_section_list1 _ =
  let tmpl = Mustache.of_string "{{#implicit}}{{.}}{{/implicit}}" in
  let js' b =
    let strs = b |> List.map ~f:(fun s -> `String s) in
    `O ["implicit", `A strs]
  in
  assert_equal "" (Mustache.render tmpl @@ js' []);
  assert_equal "onetwothree" (Mustache.render tmpl @@ js' ["one";"two";"three"])

let mustache_section_list2 _ =
  let tmpl = Mustache.of_string "{{#things}}{{v1}}-{{v2}}{{/things}}" in
  let js' pairs =
    let dict (v1,v2) = `O [
      ("v1", (`String v1));
      ("v2", (`String v2))
    ] in
    let pairs = pairs |> List.map ~f:dict in
    `O ["things", `A pairs]
  in
  assert_equal "" (Mustache.render tmpl @@ js' []);
  let vs = [("one","1");("two","2")] in
  assert_equal "one-1two-2" (Mustache.render tmpl @@ js' vs)


let test_html_escape1 _ =
  let html = "<b>foo bar</b>" in
  let escaped = Mustache.escape_html html in
  assert_equal ~printer:(fun s -> s) "&lt;b&gt;foo bar&lt;/b&gt;" escaped

let suite =
  "test mustache" >:::
  [
    "test simple token parsing" >:: token1;
    "mustache1" >:: mustache1;
    "bool sections" >:: mustache2;
    "mustache section list 1" >:: mustache_section_list1;
    "mustache section list 2" >:: mustache_section_list2;
    "test html escaping" >:: test_html_escape1;
  ]

let () = run_test_tt_main suite
