(* Copyright (C) 2013, Thomas Leonard
 * See the README file for details, or visit http://0install.net.
 *)

(** Information about this software *)

let version = "2.11"

let parsed_version = Version.parse version
