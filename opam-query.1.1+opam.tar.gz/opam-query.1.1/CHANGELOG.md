Changelog
=========

1.1
---

  * Add `--tag-format` option.

1.0
---

  * Initial release.
