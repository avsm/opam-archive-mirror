# Stationary

Stationary is an OCaml static-site-generator library. Essentially,
you use it to describe the directory structure of your site, which
may contain HTML files generated when your program runs.

Please see
`examples/blog` for a sample site that uses most of the library's
functionality. 
The example is up and running
[here](http://imeckler.github.io/stationary/example-blog/).

Documentation may be found [here](http://imeckler.github.io/stationary/).

