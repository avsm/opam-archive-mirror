# Example blog

This is an example blog site. The program here generates a blog from
the posts stored in the `posts` directory and the about text in `about.txt`.

This example is up and running
[here](http://imeckler.github.io/stationary/example-blog/).

To build and serve the site on http://0.0.0.0:8000, run `sh build_and_serve.sh`.

Check out `src/main.ml` to see how it's done.
