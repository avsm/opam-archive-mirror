let get_real (t: Types.t) = t.Types.real
let get_imag (t: Types.t) = t.Types.imag
