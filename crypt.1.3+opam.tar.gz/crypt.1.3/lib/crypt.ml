external crypt_raw: string -> string -> string = "crypt_raw"
external crypt_md5: string -> string = "crypt_md5"

let crypt = crypt_raw
