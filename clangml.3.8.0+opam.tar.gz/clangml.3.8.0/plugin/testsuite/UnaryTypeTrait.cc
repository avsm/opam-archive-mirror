bool res = __is_enum(int);
