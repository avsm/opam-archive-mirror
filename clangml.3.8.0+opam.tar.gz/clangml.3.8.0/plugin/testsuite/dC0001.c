// hex float literal
float y = (__extension__ 0x1.0p2047);
