void *P = @"Linux forever";
