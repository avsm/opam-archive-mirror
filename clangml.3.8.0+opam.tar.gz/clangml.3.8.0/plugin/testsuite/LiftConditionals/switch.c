fn1() {
  switch (0 ? 0 : 0) {}
}
