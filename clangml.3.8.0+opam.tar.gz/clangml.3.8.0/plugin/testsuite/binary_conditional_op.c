
void f(){

  int b;
  b = 0;

  b = (b == 0) ?: 1;
  b = (b == 2) ?: 3;

}
