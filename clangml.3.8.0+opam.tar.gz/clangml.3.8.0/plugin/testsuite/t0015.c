// t0015.c
// ambiguous FunctionDefinition?

ttputc(c)
{
    return 3;
}
