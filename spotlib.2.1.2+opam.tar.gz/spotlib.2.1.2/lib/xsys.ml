open Base
open Unix

let mkdir ?(perm=0o700) s =
  match File.Test._d' s with
  | `Error ENOENT -> 
      begin try
	mkdir s perm; (* CR jfuruse: use umask? *)
	`Ok
      with
      | Unix_error (e,_,_) -> `Error e
      end
  | `True st -> `Already_exists st (* CR jfuruse: perm check ? *)
  | `False st -> `Not_a_directory st
  | `Error e -> `Error e
;;

let checkenv s = try ignore (Sys.getenv s); true with Not_found -> false

let command fmt = Printf.kprintf (fun s -> Sys.command s) fmt
let must fmt = Printf.kprintf (fun s -> if Sys.command s <> 0 then failwithf "command %s failed" s) fmt
let cp = must "/bin/cp %s %s"
let patch_p1 = must "/bin/patch -p1 < %s"
