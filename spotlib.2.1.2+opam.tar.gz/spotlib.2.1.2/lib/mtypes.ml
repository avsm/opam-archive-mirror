(** Some useful module capabilities *)

module type Printable = sig
  type t
  val show : t -> string
  val format : Format.formatter -> t -> unit
end

module type Comparable = sig
  type t
  val equal : t -> t -> bool
  val compare : t -> t -> int
end

module type Hashable = Hashtbl.HashedType
