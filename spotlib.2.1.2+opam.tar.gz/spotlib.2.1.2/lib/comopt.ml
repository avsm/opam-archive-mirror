(* command line argument spec *)

module Switch = struct
  type t = {
    name : string option; (* short switch: i.e. -a -b -c w/o '-' *)
    long : string option; (* long switch: i.e. --archive --bootstrap --compile w/o '--' *)
    with_arg : bool; (* if true, -axxx -a xxx --archive=xxx *)
  }
end

module Parse : sig
  type t = {
    args : string array;
    short_switches : (char, Switch.t) Hashtbl.t;
    long_switches : (string * Switch.t) list;
    stop_at_anon : bool (* stop parsing at the first anonymous argument *)
  }

  val parse : t -> int
    -> [> `Anon of string | `Switch of Switch.t * string option ] list
    *  [> `Error of string | `Ok of int ]

end = struct
  type t = {
    args : string array;
    short_switches : (char, Switch.t) Hashtbl.t;
    long_switches : (string * Switch.t) list;
    stop_at_anon : bool (* stop parsing at the first anonymous argument *)
  }

  let string_tail s from = String.sub s from (String.length s - from)
    
  let rec parse t st pos =
    check_end_else t st pos ~f:(fun () ->
      let arg = t.args.(pos) in
      match arg with
      | _ when String.length arg = 1 -> add_annon t st pos arg
      | "--" -> parse_as_anon t st (pos + 1)
      | _ ->
          match arg.[0], arg.[1] with
          | '-', '-' -> parse_long_switch t st (string_tail arg 2) (pos + 1)
          | '-', _ -> parse_short_switch t st (string_tail arg 1) (pos + 1)
          | _ -> add_annon t st pos arg)
      
  and parse_as_anon t st pos =
    check_end_else t st pos ~f:(fun () ->
      add_annon t st pos t.args.(pos))

  and add_annon t st pos arg =
    let st = `Anon arg :: st in
    let pos = pos + 1 in
    if t.stop_at_anon then st, `Ok pos
    else parse t st pos

  and check_end_else ~f t st pos = 
    if Array.length t.args <= pos then st, `Ok (pos + 1) else f ()

  and parse_short_switch t st sw arg_pos (* for next arg *) =
    let len = String.length sw in
    let rec parse_sw st char_pos =
      if len <= char_pos then parse t st arg_pos
      else
        let sw_char = sw.[char_pos] in
        try
          let switch = Hashtbl.find t.short_switches sw_char in
          if switch.Switch.with_arg then
            if len = char_pos + 1 then (* parmeter is in t.arg.(arg_pos) *)
              get_parameter t st switch (Printf.sprintf "-%c" sw_char) arg_pos            
            else (* parameter should be concatenated *)
              parse t (`Switch (switch, Some (string_tail sw char_pos)) :: st) arg_pos
          else parse_sw (`Switch (switch, None) :: st) (char_pos + 1)
        with
        | Not_found -> st, `Error (Printf.sprintf "unknown option -%c" sw_char)
    in
    parse_sw st 0
      
  and parse_long_switch t st sw arg_pos =
    let sw, param =
      try
        let pos = String.index sw '=' in
        String.sub sw 0 (pos - 1), Some (string_tail sw (pos + 1))
      with
      | Not_found -> sw, None
    in
    let rec find found = function
      | [] ->
          begin match found with
          | None -> st, `Error (Printf.sprintf "unknown option --%s" sw)
          | Some switch ->
              if switch.Switch.with_arg then
                match param with
                | Some s -> parse t (`Switch (switch, Some s) :: st) arg_pos
                | None -> get_parameter t st switch (Printf.sprintf "--%s" sw) arg_pos
              else
                match param with
                | Some _ -> st, `Error (Printf.sprintf "option --%s must not have a parameter" sw)
                | None -> parse t (`Switch (switch, None) :: st) arg_pos
          end
      | (k,switch) :: kss ->
          match
            try Some (String.sub k 0 (String.length sw)) with _ -> None
          with
          | Some k' when k = k' ->
              if found = None then find (Some switch) kss
              else st, `Error (Printf.sprintf "ambiguous option --%s" sw)
          | Some _ | None -> find found kss
    in
    find None t.long_switches

  and get_parameter t st switch name pos =
    if Array.length t.args = pos then
      st, `Error (Printf.sprintf "option %s requires an argument" name)
    else
      parse t (`Switch (switch, Some t.args.(pos)) :: st) (pos + 1)

  let parse t pos =
    let st, result = parse t [] pos in
    List.rev st, result
end
