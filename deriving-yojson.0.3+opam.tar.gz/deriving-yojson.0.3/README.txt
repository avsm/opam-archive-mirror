(* OASIS_START *)
(* DO NOT EDIT (digest: ec25ea0e930788dc6f3ce125f1851f48) *)
This is the README file for the deriving-yojson distribution.

Parse/convert ocaml value from/to yojson ast

See the files INSTALL.txt for building and installation instructions. 

Home page: https://github.com/hhugo/deriving-yojson


(* OASIS_STOP *)
