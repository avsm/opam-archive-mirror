interface adult {
    height: number;
    age: number;
}

declare var adult: {
    minage: number;
    new(): adult;
}
