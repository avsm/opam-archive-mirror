(/* comment */{
    p1: null,
    p2: null
})
