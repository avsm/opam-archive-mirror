(/* comment */{
    p1: null
})
