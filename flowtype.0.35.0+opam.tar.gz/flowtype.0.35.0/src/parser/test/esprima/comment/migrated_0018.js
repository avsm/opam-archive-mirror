// Hello, world!
42