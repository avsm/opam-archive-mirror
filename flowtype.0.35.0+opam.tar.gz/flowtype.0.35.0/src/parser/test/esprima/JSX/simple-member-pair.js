<milky-way.solar-system></milky-way.solar-system>
