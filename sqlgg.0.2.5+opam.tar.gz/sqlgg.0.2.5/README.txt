sqlgg: SQL Guided (code) Generator

Homepage at http://ygrek.org.ua/p/sqlgg/

Build
=====

Dependencies
------------

* menhir
* extlib
* oUnit
* deriving
* ocamlfind

`deriving` is special - there were several forks floating around for a long time.
Everything should work out of the box with either
<https://github.com/ocsigen/deriving> or <http://repo.or.cz/w/deriving.git>

Build
-----

Change to `src` directory and run `make` (or `build.bat` on Windows).

Windows users
=============

Install VS2005 SP1 redistributable
<http://www.microsoft.com/downloads/details.aspx?FamilyID=200b2fd9-ae1a-4a14-984d-389c36f85647>

----
2014-01-24
