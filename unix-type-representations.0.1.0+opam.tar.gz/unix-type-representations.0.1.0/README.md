Functions that expose the underlying types of some abstract types in the [Unix module](http://caml.inria.fr/pub/docs/manual-ocaml/libref/Unix.html).

Build status: [![Travis build Status](https://travis-ci.org/yallop/ocaml-unix-type-representations.svg?branch=master)](https://travis-ci.org/yallop/ocaml-unix-type-representations)
