ocaml-hamt
==========

Hash Array Mapped Tries for OCaml

## Prerequesites

* opam
* oasis
* monomorphic

## Build
```
make configure
make
make install
```

All original work was done by Thibault Suzanne [1][2]

[1] http://gallium.inria.fr/blog/implementing-hamt-for-ocaml/

[2] http://gitorious.org/ocaml-hamt/ocaml-hamt
