#!/bin/sh -e

COMM=${OCAMLN}c$OPT
echo $COMM $*
$COMM $*
