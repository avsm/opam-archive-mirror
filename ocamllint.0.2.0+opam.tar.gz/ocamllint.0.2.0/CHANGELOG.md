## v0.2.0

*2016-03-10*

(This release contains breaking changes, indicated by a star)

- Use a `Warning.t` type instead of plain strings
* Rename findlib package `ppx_lint` to `ppx` (#6)
- Add a configuration system based on plugins

## v0.1.0

*2016-01-07*

- Initial release
