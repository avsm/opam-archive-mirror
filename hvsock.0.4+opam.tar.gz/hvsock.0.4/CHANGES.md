0.4 (2016-05-12)
- Add an implementation of V1_LWT.FLOW

0.3 (2016-05-12)
- Avoid running out of Lwt_preemptive thread pool threads

0.2 (2016-05-12)
- Work around connect() blocking forever

0.1 (2016-05-12)
- Initial release
