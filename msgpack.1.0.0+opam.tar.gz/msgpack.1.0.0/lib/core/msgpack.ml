
module Serialize = Serialize
module Config = Config
module Pack = Pack
module MsgpackCore = MsgpackCore

type t = Serialize.t
