(* OASIS_START *)
(* DO NOT EDIT (digest: 3f734f07988aa2212c1ed1e9caf0fd1c) *)
This is the README file for the gammu distribution.

Cell phone and SIM card access.

Gammu is a binding to libGammu which allows to manage data in your cell phone
such as contacts, calendar or messages.

See the files INSTALL.txt for building and installation instructions. 

Home page: https://forge.ocamlcore.org/projects/ml-gammu/


(* OASIS_STOP *)
