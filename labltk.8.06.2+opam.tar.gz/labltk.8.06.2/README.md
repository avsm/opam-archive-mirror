LablTk is an interface to the Tcl/Tk GUI framework. It allows to develop GUI applications in a speedy and type safe way. A legacy Camltk interface is included. The OCamlBrowser library viewer is also part of this project.

The project page is:
https://forge.ocamlcore.org/projects/labltk/

You can find documentation here:
https://forge.ocamlcore.org/docman/?group_id=343&view=listfile&dirid=385
