## proj4ml - OCaml bindings to the PROJ.4 library

[PROJ.4][proj4] is a library that converts between geographic coordinate
systems.  The API currently closely follows the [C API][c_api].

[PROJ.4][proj4] and these OCaml bindings are distributed under the MIT
license.

[proj4]: http://trac.osgeo.org/proj/
[c_api]: http://trac.osgeo.org/proj/wiki/ProjAPI

