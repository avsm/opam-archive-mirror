let package_name = "typerep"

let sections =
  [ ("lib",
    [ ("built_lib_typerep_lib", None)
    ],
    [ ("META", None)
    ])
  ]
