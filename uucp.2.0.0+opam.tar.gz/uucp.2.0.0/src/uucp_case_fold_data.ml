(*---------------------------------------------------------------------------
   Copyright (c) 2014 Daniel C. Bünzli. All rights reserved.

   Distributed under the ISC license, see terms at the end of the file.
   uucp v2.0.0
  ---------------------------------------------------------------------------*)

(* WARNING do not edit. This file was automatically generated. *)

open Uucp_tmap
let fold_map_map : Uchar.t list t = { default = []; l0 = [|[|nil;nil;nil;nil;
[|[];[Uchar.unsafe_of_int 0x0061;];[Uchar.unsafe_of_int 0x0062;];
[Uchar.unsafe_of_int 0x0063;];[Uchar.unsafe_of_int 0x0064;];
[Uchar.unsafe_of_int 0x0065;];[Uchar.unsafe_of_int 0x0066;];
[Uchar.unsafe_of_int 0x0067;];[Uchar.unsafe_of_int 0x0068;];
[Uchar.unsafe_of_int 0x0069;];[Uchar.unsafe_of_int 0x006A;];
[Uchar.unsafe_of_int 0x006B;];[Uchar.unsafe_of_int 0x006C;];
[Uchar.unsafe_of_int 0x006D;];[Uchar.unsafe_of_int 0x006E;];
[Uchar.unsafe_of_int 0x006F;];|];[|[Uchar.unsafe_of_int 0x0070;];
[Uchar.unsafe_of_int 0x0071;];[Uchar.unsafe_of_int 0x0072;];
[Uchar.unsafe_of_int 0x0073;];[Uchar.unsafe_of_int 0x0074;];
[Uchar.unsafe_of_int 0x0075;];[Uchar.unsafe_of_int 0x0076;];
[Uchar.unsafe_of_int 0x0077;];[Uchar.unsafe_of_int 0x0078;];
[Uchar.unsafe_of_int 0x0079;];[Uchar.unsafe_of_int 0x007A;];[];[];[];
[];[];|];nil;nil;nil;nil;nil;[|[];[];[];[];[];[Uchar.unsafe_of_int 0x03BC;];
[];[];[];[];[];[];[];[];[];[];|];[|[Uchar.unsafe_of_int 0x00E0;];
[Uchar.unsafe_of_int 0x00E1;];[Uchar.unsafe_of_int 0x00E2;];
[Uchar.unsafe_of_int 0x00E3;];[Uchar.unsafe_of_int 0x00E4;];
[Uchar.unsafe_of_int 0x00E5;];[Uchar.unsafe_of_int 0x00E6;];
[Uchar.unsafe_of_int 0x00E7;];[Uchar.unsafe_of_int 0x00E8;];
[Uchar.unsafe_of_int 0x00E9;];[Uchar.unsafe_of_int 0x00EA;];
[Uchar.unsafe_of_int 0x00EB;];[Uchar.unsafe_of_int 0x00EC;];
[Uchar.unsafe_of_int 0x00ED;];[Uchar.unsafe_of_int 0x00EE;];
[Uchar.unsafe_of_int 0x00EF;];|];[|[Uchar.unsafe_of_int 0x00F0;];
[Uchar.unsafe_of_int 0x00F1;];[Uchar.unsafe_of_int 0x00F2;];
[Uchar.unsafe_of_int 0x00F3;];[Uchar.unsafe_of_int 0x00F4;];
[Uchar.unsafe_of_int 0x00F5;];[Uchar.unsafe_of_int 0x00F6;];[];
[Uchar.unsafe_of_int 0x00F8;];[Uchar.unsafe_of_int 0x00F9;];
[Uchar.unsafe_of_int 0x00FA;];[Uchar.unsafe_of_int 0x00FB;];
[Uchar.unsafe_of_int 0x00FC;];[Uchar.unsafe_of_int 0x00FD;];
[Uchar.unsafe_of_int 0x00FE;];
[Uchar.unsafe_of_int 0x0073;Uchar.unsafe_of_int 0x0073;];|];nil;nil;[|
[Uchar.unsafe_of_int 0x0101;];[];[Uchar.unsafe_of_int 0x0103;];[];
[Uchar.unsafe_of_int 0x0105;];[];[Uchar.unsafe_of_int 0x0107;];[];
[Uchar.unsafe_of_int 0x0109;];[];[Uchar.unsafe_of_int 0x010B;];[];
[Uchar.unsafe_of_int 0x010D;];[];[Uchar.unsafe_of_int 0x010F;];[];|];[|
[Uchar.unsafe_of_int 0x0111;];[];[Uchar.unsafe_of_int 0x0113;];[];
[Uchar.unsafe_of_int 0x0115;];[];[Uchar.unsafe_of_int 0x0117;];[];
[Uchar.unsafe_of_int 0x0119;];[];[Uchar.unsafe_of_int 0x011B;];[];
[Uchar.unsafe_of_int 0x011D;];[];[Uchar.unsafe_of_int 0x011F;];[];|];[|
[Uchar.unsafe_of_int 0x0121;];[];[Uchar.unsafe_of_int 0x0123;];[];
[Uchar.unsafe_of_int 0x0125;];[];[Uchar.unsafe_of_int 0x0127;];[];
[Uchar.unsafe_of_int 0x0129;];[];[Uchar.unsafe_of_int 0x012B;];[];
[Uchar.unsafe_of_int 0x012D;];[];[Uchar.unsafe_of_int 0x012F;];[];|];[|
[Uchar.unsafe_of_int 0x0069;Uchar.unsafe_of_int 0x0307;];[];
[Uchar.unsafe_of_int 0x0133;];[];[Uchar.unsafe_of_int 0x0135;];[];
[Uchar.unsafe_of_int 0x0137;];[];[];[Uchar.unsafe_of_int 0x013A;];[];
[Uchar.unsafe_of_int 0x013C;];[];[Uchar.unsafe_of_int 0x013E;];[];
[Uchar.unsafe_of_int 0x0140;];|];[|[];[Uchar.unsafe_of_int 0x0142;];[];
[Uchar.unsafe_of_int 0x0144;];[];[Uchar.unsafe_of_int 0x0146;];[];
[Uchar.unsafe_of_int 0x0148;];[];
[Uchar.unsafe_of_int 0x02BC;Uchar.unsafe_of_int 0x006E;];
[Uchar.unsafe_of_int 0x014B;];[];[Uchar.unsafe_of_int 0x014D;];[];
[Uchar.unsafe_of_int 0x014F;];[];|];[|[Uchar.unsafe_of_int 0x0151;];[];
[Uchar.unsafe_of_int 0x0153;];[];[Uchar.unsafe_of_int 0x0155;];[];
[Uchar.unsafe_of_int 0x0157;];[];[Uchar.unsafe_of_int 0x0159;];[];
[Uchar.unsafe_of_int 0x015B;];[];[Uchar.unsafe_of_int 0x015D;];[];
[Uchar.unsafe_of_int 0x015F;];[];|];[|[Uchar.unsafe_of_int 0x0161;];[];
[Uchar.unsafe_of_int 0x0163;];[];[Uchar.unsafe_of_int 0x0165;];[];
[Uchar.unsafe_of_int 0x0167;];[];[Uchar.unsafe_of_int 0x0169;];[];
[Uchar.unsafe_of_int 0x016B;];[];[Uchar.unsafe_of_int 0x016D;];[];
[Uchar.unsafe_of_int 0x016F;];[];|];[|[Uchar.unsafe_of_int 0x0171;];[];
[Uchar.unsafe_of_int 0x0173;];[];[Uchar.unsafe_of_int 0x0175;];[];
[Uchar.unsafe_of_int 0x0177;];[];[Uchar.unsafe_of_int 0x00FF;];
[Uchar.unsafe_of_int 0x017A;];[];[Uchar.unsafe_of_int 0x017C;];[];
[Uchar.unsafe_of_int 0x017E;];[];[Uchar.unsafe_of_int 0x0073;];|];[|[];
[Uchar.unsafe_of_int 0x0253;];[Uchar.unsafe_of_int 0x0183;];[];
[Uchar.unsafe_of_int 0x0185;];[];[Uchar.unsafe_of_int 0x0254;];
[Uchar.unsafe_of_int 0x0188;];[];[Uchar.unsafe_of_int 0x0256;];
[Uchar.unsafe_of_int 0x0257;];[Uchar.unsafe_of_int 0x018C;];[];[];
[Uchar.unsafe_of_int 0x01DD;];[Uchar.unsafe_of_int 0x0259;];|];[|
[Uchar.unsafe_of_int 0x025B;];[Uchar.unsafe_of_int 0x0192;];[];
[Uchar.unsafe_of_int 0x0260;];[Uchar.unsafe_of_int 0x0263;];[];
[Uchar.unsafe_of_int 0x0269;];[Uchar.unsafe_of_int 0x0268;];
[Uchar.unsafe_of_int 0x0199;];[];[];[];[Uchar.unsafe_of_int 0x026F;];
[Uchar.unsafe_of_int 0x0272;];[];[Uchar.unsafe_of_int 0x0275;];|];[|
[Uchar.unsafe_of_int 0x01A1;];[];[Uchar.unsafe_of_int 0x01A3;];[];
[Uchar.unsafe_of_int 0x01A5;];[];[Uchar.unsafe_of_int 0x0280;];
[Uchar.unsafe_of_int 0x01A8;];[];[Uchar.unsafe_of_int 0x0283;];[];[];
[Uchar.unsafe_of_int 0x01AD;];[];[Uchar.unsafe_of_int 0x0288;];
[Uchar.unsafe_of_int 0x01B0;];|];[|[];[Uchar.unsafe_of_int 0x028A;];
[Uchar.unsafe_of_int 0x028B;];[Uchar.unsafe_of_int 0x01B4;];[];
[Uchar.unsafe_of_int 0x01B6;];[];[Uchar.unsafe_of_int 0x0292;];
[Uchar.unsafe_of_int 0x01B9;];[];[];[];[Uchar.unsafe_of_int 0x01BD;];
[];[];[];|];[|[];[];[];[];[Uchar.unsafe_of_int 0x01C6;];
[Uchar.unsafe_of_int 0x01C6;];[];[Uchar.unsafe_of_int 0x01C9;];
[Uchar.unsafe_of_int 0x01C9;];[];[Uchar.unsafe_of_int 0x01CC;];
[Uchar.unsafe_of_int 0x01CC;];[];[Uchar.unsafe_of_int 0x01CE;];[];
[Uchar.unsafe_of_int 0x01D0;];|];[|[];[Uchar.unsafe_of_int 0x01D2;];[];
[Uchar.unsafe_of_int 0x01D4;];[];[Uchar.unsafe_of_int 0x01D6;];[];
[Uchar.unsafe_of_int 0x01D8;];[];[Uchar.unsafe_of_int 0x01DA;];[];
[Uchar.unsafe_of_int 0x01DC;];[];[];[Uchar.unsafe_of_int 0x01DF;];[];|];[|
[Uchar.unsafe_of_int 0x01E1;];[];[Uchar.unsafe_of_int 0x01E3;];[];
[Uchar.unsafe_of_int 0x01E5;];[];[Uchar.unsafe_of_int 0x01E7;];[];
[Uchar.unsafe_of_int 0x01E9;];[];[Uchar.unsafe_of_int 0x01EB;];[];
[Uchar.unsafe_of_int 0x01ED;];[];[Uchar.unsafe_of_int 0x01EF;];[];|];[|
[Uchar.unsafe_of_int 0x006A;Uchar.unsafe_of_int 0x030C;];
[Uchar.unsafe_of_int 0x01F3;];[Uchar.unsafe_of_int 0x01F3;];[];
[Uchar.unsafe_of_int 0x01F5;];[];[Uchar.unsafe_of_int 0x0195;];
[Uchar.unsafe_of_int 0x01BF;];[Uchar.unsafe_of_int 0x01F9;];[];
[Uchar.unsafe_of_int 0x01FB;];[];[Uchar.unsafe_of_int 0x01FD;];[];
[Uchar.unsafe_of_int 0x01FF;];[];|];[|[Uchar.unsafe_of_int 0x0201;];[];
[Uchar.unsafe_of_int 0x0203;];[];[Uchar.unsafe_of_int 0x0205;];[];
[Uchar.unsafe_of_int 0x0207;];[];[Uchar.unsafe_of_int 0x0209;];[];
[Uchar.unsafe_of_int 0x020B;];[];[Uchar.unsafe_of_int 0x020D;];[];
[Uchar.unsafe_of_int 0x020F;];[];|];[|[Uchar.unsafe_of_int 0x0211;];[];
[Uchar.unsafe_of_int 0x0213;];[];[Uchar.unsafe_of_int 0x0215;];[];
[Uchar.unsafe_of_int 0x0217;];[];[Uchar.unsafe_of_int 0x0219;];[];
[Uchar.unsafe_of_int 0x021B;];[];[Uchar.unsafe_of_int 0x021D;];[];
[Uchar.unsafe_of_int 0x021F;];[];|];[|[Uchar.unsafe_of_int 0x019E;];[];
[Uchar.unsafe_of_int 0x0223;];[];[Uchar.unsafe_of_int 0x0225;];[];
[Uchar.unsafe_of_int 0x0227;];[];[Uchar.unsafe_of_int 0x0229;];[];
[Uchar.unsafe_of_int 0x022B;];[];[Uchar.unsafe_of_int 0x022D;];[];
[Uchar.unsafe_of_int 0x022F;];[];|];[|[Uchar.unsafe_of_int 0x0231;];[];
[Uchar.unsafe_of_int 0x0233;];[];[];[];[];[];[];[];
[Uchar.unsafe_of_int 0x2C65;];[Uchar.unsafe_of_int 0x023C;];[];
[Uchar.unsafe_of_int 0x019A;];[Uchar.unsafe_of_int 0x2C66;];[];|];[|[];
[Uchar.unsafe_of_int 0x0242;];[];[Uchar.unsafe_of_int 0x0180;];
[Uchar.unsafe_of_int 0x0289;];[Uchar.unsafe_of_int 0x028C;];
[Uchar.unsafe_of_int 0x0247;];[];[Uchar.unsafe_of_int 0x0249;];[];
[Uchar.unsafe_of_int 0x024B;];[];[Uchar.unsafe_of_int 0x024D;];[];
[Uchar.unsafe_of_int 0x024F;];[];|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;[|[];[];[];[];[];[Uchar.unsafe_of_int 0x03B9;];[];
[];[];[];[];[];[];[];[];[];|];nil;nil;[|[Uchar.unsafe_of_int 0x0371;];
[];[Uchar.unsafe_of_int 0x0373;];[];[];[];[Uchar.unsafe_of_int 0x0377;];
[];[];[];[];[];[];[];[];[Uchar.unsafe_of_int 0x03F3;];|];[|[];[];[];[];
[];[];[Uchar.unsafe_of_int 0x03AC;];[];[Uchar.unsafe_of_int 0x03AD;];
[Uchar.unsafe_of_int 0x03AE;];[Uchar.unsafe_of_int 0x03AF;];[];
[Uchar.unsafe_of_int 0x03CC;];[];[Uchar.unsafe_of_int 0x03CD;];
[Uchar.unsafe_of_int 0x03CE;];|];[|
[Uchar.unsafe_of_int 0x03B9;Uchar.unsafe_of_int 0x0308;
 Uchar.unsafe_of_int 0x0301;];
[Uchar.unsafe_of_int 0x03B1;];[Uchar.unsafe_of_int 0x03B2;];
[Uchar.unsafe_of_int 0x03B3;];[Uchar.unsafe_of_int 0x03B4;];
[Uchar.unsafe_of_int 0x03B5;];[Uchar.unsafe_of_int 0x03B6;];
[Uchar.unsafe_of_int 0x03B7;];[Uchar.unsafe_of_int 0x03B8;];
[Uchar.unsafe_of_int 0x03B9;];[Uchar.unsafe_of_int 0x03BA;];
[Uchar.unsafe_of_int 0x03BB;];[Uchar.unsafe_of_int 0x03BC;];
[Uchar.unsafe_of_int 0x03BD;];[Uchar.unsafe_of_int 0x03BE;];
[Uchar.unsafe_of_int 0x03BF;];|];[|[Uchar.unsafe_of_int 0x03C0;];
[Uchar.unsafe_of_int 0x03C1;];[];[Uchar.unsafe_of_int 0x03C3;];
[Uchar.unsafe_of_int 0x03C4;];[Uchar.unsafe_of_int 0x03C5;];
[Uchar.unsafe_of_int 0x03C6;];[Uchar.unsafe_of_int 0x03C7;];
[Uchar.unsafe_of_int 0x03C8;];[Uchar.unsafe_of_int 0x03C9;];
[Uchar.unsafe_of_int 0x03CA;];[Uchar.unsafe_of_int 0x03CB;];[];[];[];
[];|];[|
[Uchar.unsafe_of_int 0x03C5;Uchar.unsafe_of_int 0x0308;
 Uchar.unsafe_of_int 0x0301;];
[];[];[];[];[];[];[];[];[];[];[];[];[];[];[];|];[|[];[];
[Uchar.unsafe_of_int 0x03C3;];[];[];[];[];[];[];[];[];[];[];[];[];
[Uchar.unsafe_of_int 0x03D7;];|];[|[Uchar.unsafe_of_int 0x03B2;];
[Uchar.unsafe_of_int 0x03B8;];[];[];[];[Uchar.unsafe_of_int 0x03C6;];
[Uchar.unsafe_of_int 0x03C0;];[];[Uchar.unsafe_of_int 0x03D9;];[];
[Uchar.unsafe_of_int 0x03DB;];[];[Uchar.unsafe_of_int 0x03DD;];[];
[Uchar.unsafe_of_int 0x03DF;];[];|];[|[Uchar.unsafe_of_int 0x03E1;];[];
[Uchar.unsafe_of_int 0x03E3;];[];[Uchar.unsafe_of_int 0x03E5;];[];
[Uchar.unsafe_of_int 0x03E7;];[];[Uchar.unsafe_of_int 0x03E9;];[];
[Uchar.unsafe_of_int 0x03EB;];[];[Uchar.unsafe_of_int 0x03ED;];[];
[Uchar.unsafe_of_int 0x03EF;];[];|];[|[Uchar.unsafe_of_int 0x03BA;];
[Uchar.unsafe_of_int 0x03C1;];[];[];[Uchar.unsafe_of_int 0x03B8;];
[Uchar.unsafe_of_int 0x03B5;];[];[Uchar.unsafe_of_int 0x03F8;];[];
[Uchar.unsafe_of_int 0x03F2;];[Uchar.unsafe_of_int 0x03FB;];[];[];
[Uchar.unsafe_of_int 0x037B;];[Uchar.unsafe_of_int 0x037C;];
[Uchar.unsafe_of_int 0x037D;];|];[|[Uchar.unsafe_of_int 0x0450;];
[Uchar.unsafe_of_int 0x0451;];[Uchar.unsafe_of_int 0x0452;];
[Uchar.unsafe_of_int 0x0453;];[Uchar.unsafe_of_int 0x0454;];
[Uchar.unsafe_of_int 0x0455;];[Uchar.unsafe_of_int 0x0456;];
[Uchar.unsafe_of_int 0x0457;];[Uchar.unsafe_of_int 0x0458;];
[Uchar.unsafe_of_int 0x0459;];[Uchar.unsafe_of_int 0x045A;];
[Uchar.unsafe_of_int 0x045B;];[Uchar.unsafe_of_int 0x045C;];
[Uchar.unsafe_of_int 0x045D;];[Uchar.unsafe_of_int 0x045E;];
[Uchar.unsafe_of_int 0x045F;];|];[|[Uchar.unsafe_of_int 0x0430;];
[Uchar.unsafe_of_int 0x0431;];[Uchar.unsafe_of_int 0x0432;];
[Uchar.unsafe_of_int 0x0433;];[Uchar.unsafe_of_int 0x0434;];
[Uchar.unsafe_of_int 0x0435;];[Uchar.unsafe_of_int 0x0436;];
[Uchar.unsafe_of_int 0x0437;];[Uchar.unsafe_of_int 0x0438;];
[Uchar.unsafe_of_int 0x0439;];[Uchar.unsafe_of_int 0x043A;];
[Uchar.unsafe_of_int 0x043B;];[Uchar.unsafe_of_int 0x043C;];
[Uchar.unsafe_of_int 0x043D;];[Uchar.unsafe_of_int 0x043E;];
[Uchar.unsafe_of_int 0x043F;];|];[|[Uchar.unsafe_of_int 0x0440;];
[Uchar.unsafe_of_int 0x0441;];[Uchar.unsafe_of_int 0x0442;];
[Uchar.unsafe_of_int 0x0443;];[Uchar.unsafe_of_int 0x0444;];
[Uchar.unsafe_of_int 0x0445;];[Uchar.unsafe_of_int 0x0446;];
[Uchar.unsafe_of_int 0x0447;];[Uchar.unsafe_of_int 0x0448;];
[Uchar.unsafe_of_int 0x0449;];[Uchar.unsafe_of_int 0x044A;];
[Uchar.unsafe_of_int 0x044B;];[Uchar.unsafe_of_int 0x044C;];
[Uchar.unsafe_of_int 0x044D;];[Uchar.unsafe_of_int 0x044E;];
[Uchar.unsafe_of_int 0x044F;];|];nil;nil;nil;[|[Uchar.unsafe_of_int 0x0461;];
[];[Uchar.unsafe_of_int 0x0463;];[];[Uchar.unsafe_of_int 0x0465;];[];
[Uchar.unsafe_of_int 0x0467;];[];[Uchar.unsafe_of_int 0x0469;];[];
[Uchar.unsafe_of_int 0x046B;];[];[Uchar.unsafe_of_int 0x046D;];[];
[Uchar.unsafe_of_int 0x046F;];[];|];[|[Uchar.unsafe_of_int 0x0471;];[];
[Uchar.unsafe_of_int 0x0473;];[];[Uchar.unsafe_of_int 0x0475;];[];
[Uchar.unsafe_of_int 0x0477;];[];[Uchar.unsafe_of_int 0x0479;];[];
[Uchar.unsafe_of_int 0x047B;];[];[Uchar.unsafe_of_int 0x047D;];[];
[Uchar.unsafe_of_int 0x047F;];[];|];[|[Uchar.unsafe_of_int 0x0481;];[];
[];[];[];[];[];[];[];[];[Uchar.unsafe_of_int 0x048B;];[];
[Uchar.unsafe_of_int 0x048D;];[];[Uchar.unsafe_of_int 0x048F;];[];|];[|
[Uchar.unsafe_of_int 0x0491;];[];[Uchar.unsafe_of_int 0x0493;];[];
[Uchar.unsafe_of_int 0x0495;];[];[Uchar.unsafe_of_int 0x0497;];[];
[Uchar.unsafe_of_int 0x0499;];[];[Uchar.unsafe_of_int 0x049B;];[];
[Uchar.unsafe_of_int 0x049D;];[];[Uchar.unsafe_of_int 0x049F;];[];|];[|
[Uchar.unsafe_of_int 0x04A1;];[];[Uchar.unsafe_of_int 0x04A3;];[];
[Uchar.unsafe_of_int 0x04A5;];[];[Uchar.unsafe_of_int 0x04A7;];[];
[Uchar.unsafe_of_int 0x04A9;];[];[Uchar.unsafe_of_int 0x04AB;];[];
[Uchar.unsafe_of_int 0x04AD;];[];[Uchar.unsafe_of_int 0x04AF;];[];|];[|
[Uchar.unsafe_of_int 0x04B1;];[];[Uchar.unsafe_of_int 0x04B3;];[];
[Uchar.unsafe_of_int 0x04B5;];[];[Uchar.unsafe_of_int 0x04B7;];[];
[Uchar.unsafe_of_int 0x04B9;];[];[Uchar.unsafe_of_int 0x04BB;];[];
[Uchar.unsafe_of_int 0x04BD;];[];[Uchar.unsafe_of_int 0x04BF;];[];|];[|
[Uchar.unsafe_of_int 0x04CF;];[Uchar.unsafe_of_int 0x04C2;];[];
[Uchar.unsafe_of_int 0x04C4;];[];[Uchar.unsafe_of_int 0x04C6;];[];
[Uchar.unsafe_of_int 0x04C8;];[];[Uchar.unsafe_of_int 0x04CA;];[];
[Uchar.unsafe_of_int 0x04CC;];[];[Uchar.unsafe_of_int 0x04CE;];[];[];|];[|
[Uchar.unsafe_of_int 0x04D1;];[];[Uchar.unsafe_of_int 0x04D3;];[];
[Uchar.unsafe_of_int 0x04D5;];[];[Uchar.unsafe_of_int 0x04D7;];[];
[Uchar.unsafe_of_int 0x04D9;];[];[Uchar.unsafe_of_int 0x04DB;];[];
[Uchar.unsafe_of_int 0x04DD;];[];[Uchar.unsafe_of_int 0x04DF;];[];|];[|
[Uchar.unsafe_of_int 0x04E1;];[];[Uchar.unsafe_of_int 0x04E3;];[];
[Uchar.unsafe_of_int 0x04E5;];[];[Uchar.unsafe_of_int 0x04E7;];[];
[Uchar.unsafe_of_int 0x04E9;];[];[Uchar.unsafe_of_int 0x04EB;];[];
[Uchar.unsafe_of_int 0x04ED;];[];[Uchar.unsafe_of_int 0x04EF;];[];|];[|
[Uchar.unsafe_of_int 0x04F1;];[];[Uchar.unsafe_of_int 0x04F3;];[];
[Uchar.unsafe_of_int 0x04F5;];[];[Uchar.unsafe_of_int 0x04F7;];[];
[Uchar.unsafe_of_int 0x04F9;];[];[Uchar.unsafe_of_int 0x04FB;];[];
[Uchar.unsafe_of_int 0x04FD;];[];[Uchar.unsafe_of_int 0x04FF;];[];|];[|
[Uchar.unsafe_of_int 0x0501;];[];[Uchar.unsafe_of_int 0x0503;];[];
[Uchar.unsafe_of_int 0x0505;];[];[Uchar.unsafe_of_int 0x0507;];[];
[Uchar.unsafe_of_int 0x0509;];[];[Uchar.unsafe_of_int 0x050B;];[];
[Uchar.unsafe_of_int 0x050D;];[];[Uchar.unsafe_of_int 0x050F;];[];|];[|
[Uchar.unsafe_of_int 0x0511;];[];[Uchar.unsafe_of_int 0x0513;];[];
[Uchar.unsafe_of_int 0x0515;];[];[Uchar.unsafe_of_int 0x0517;];[];
[Uchar.unsafe_of_int 0x0519;];[];[Uchar.unsafe_of_int 0x051B;];[];
[Uchar.unsafe_of_int 0x051D;];[];[Uchar.unsafe_of_int 0x051F;];[];|];[|
[Uchar.unsafe_of_int 0x0521;];[];[Uchar.unsafe_of_int 0x0523;];[];
[Uchar.unsafe_of_int 0x0525;];[];[Uchar.unsafe_of_int 0x0527;];[];
[Uchar.unsafe_of_int 0x0529;];[];[Uchar.unsafe_of_int 0x052B;];[];
[Uchar.unsafe_of_int 0x052D;];[];[Uchar.unsafe_of_int 0x052F;];[];|];[|
[];[Uchar.unsafe_of_int 0x0561;];[Uchar.unsafe_of_int 0x0562;];
[Uchar.unsafe_of_int 0x0563;];[Uchar.unsafe_of_int 0x0564;];
[Uchar.unsafe_of_int 0x0565;];[Uchar.unsafe_of_int 0x0566;];
[Uchar.unsafe_of_int 0x0567;];[Uchar.unsafe_of_int 0x0568;];
[Uchar.unsafe_of_int 0x0569;];[Uchar.unsafe_of_int 0x056A;];
[Uchar.unsafe_of_int 0x056B;];[Uchar.unsafe_of_int 0x056C;];
[Uchar.unsafe_of_int 0x056D;];[Uchar.unsafe_of_int 0x056E;];
[Uchar.unsafe_of_int 0x056F;];|];[|[Uchar.unsafe_of_int 0x0570;];
[Uchar.unsafe_of_int 0x0571;];[Uchar.unsafe_of_int 0x0572;];
[Uchar.unsafe_of_int 0x0573;];[Uchar.unsafe_of_int 0x0574;];
[Uchar.unsafe_of_int 0x0575;];[Uchar.unsafe_of_int 0x0576;];
[Uchar.unsafe_of_int 0x0577;];[Uchar.unsafe_of_int 0x0578;];
[Uchar.unsafe_of_int 0x0579;];[Uchar.unsafe_of_int 0x057A;];
[Uchar.unsafe_of_int 0x057B;];[Uchar.unsafe_of_int 0x057C;];
[Uchar.unsafe_of_int 0x057D;];[Uchar.unsafe_of_int 0x057E;];
[Uchar.unsafe_of_int 0x057F;];|];[|[Uchar.unsafe_of_int 0x0580;];
[Uchar.unsafe_of_int 0x0581;];[Uchar.unsafe_of_int 0x0582;];
[Uchar.unsafe_of_int 0x0583;];[Uchar.unsafe_of_int 0x0584;];
[Uchar.unsafe_of_int 0x0585;];[Uchar.unsafe_of_int 0x0586;];[];[];[];
[];[];[];[];[];[];|];nil;nil;[|[];[];[];[];[];[];[];
[Uchar.unsafe_of_int 0x0565;Uchar.unsafe_of_int 0x0582;];[];[];[];[];
[];[];[];[];|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
|];[|nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;[|[Uchar.unsafe_of_int 0x2D00;];
[Uchar.unsafe_of_int 0x2D01;];[Uchar.unsafe_of_int 0x2D02;];
[Uchar.unsafe_of_int 0x2D03;];[Uchar.unsafe_of_int 0x2D04;];
[Uchar.unsafe_of_int 0x2D05;];[Uchar.unsafe_of_int 0x2D06;];
[Uchar.unsafe_of_int 0x2D07;];[Uchar.unsafe_of_int 0x2D08;];
[Uchar.unsafe_of_int 0x2D09;];[Uchar.unsafe_of_int 0x2D0A;];
[Uchar.unsafe_of_int 0x2D0B;];[Uchar.unsafe_of_int 0x2D0C;];
[Uchar.unsafe_of_int 0x2D0D;];[Uchar.unsafe_of_int 0x2D0E;];
[Uchar.unsafe_of_int 0x2D0F;];|];[|[Uchar.unsafe_of_int 0x2D10;];
[Uchar.unsafe_of_int 0x2D11;];[Uchar.unsafe_of_int 0x2D12;];
[Uchar.unsafe_of_int 0x2D13;];[Uchar.unsafe_of_int 0x2D14;];
[Uchar.unsafe_of_int 0x2D15;];[Uchar.unsafe_of_int 0x2D16;];
[Uchar.unsafe_of_int 0x2D17;];[Uchar.unsafe_of_int 0x2D18;];
[Uchar.unsafe_of_int 0x2D19;];[Uchar.unsafe_of_int 0x2D1A;];
[Uchar.unsafe_of_int 0x2D1B;];[Uchar.unsafe_of_int 0x2D1C;];
[Uchar.unsafe_of_int 0x2D1D;];[Uchar.unsafe_of_int 0x2D1E;];
[Uchar.unsafe_of_int 0x2D1F;];|];[|[Uchar.unsafe_of_int 0x2D20;];
[Uchar.unsafe_of_int 0x2D21;];[Uchar.unsafe_of_int 0x2D22;];
[Uchar.unsafe_of_int 0x2D23;];[Uchar.unsafe_of_int 0x2D24;];
[Uchar.unsafe_of_int 0x2D25;];[];[Uchar.unsafe_of_int 0x2D27;];[];[];
[];[];[];[Uchar.unsafe_of_int 0x2D2D;];[];[];|];nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;[|[];[];[];[];[];[];[];[];[Uchar.unsafe_of_int 0x13F0;];
[Uchar.unsafe_of_int 0x13F1;];[Uchar.unsafe_of_int 0x13F2;];
[Uchar.unsafe_of_int 0x13F3;];[Uchar.unsafe_of_int 0x13F4;];
[Uchar.unsafe_of_int 0x13F5;];[];[];|];nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;[|
[Uchar.unsafe_of_int 0x0432;];[Uchar.unsafe_of_int 0x0434;];
[Uchar.unsafe_of_int 0x043E;];[Uchar.unsafe_of_int 0x0441;];
[Uchar.unsafe_of_int 0x0442;];[Uchar.unsafe_of_int 0x0442;];
[Uchar.unsafe_of_int 0x044A;];[Uchar.unsafe_of_int 0x0463;];
[Uchar.unsafe_of_int 0xA64B;];[];[];[];[];[];[];[];|];nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;[|
[Uchar.unsafe_of_int 0x1E01;];[];[Uchar.unsafe_of_int 0x1E03;];[];
[Uchar.unsafe_of_int 0x1E05;];[];[Uchar.unsafe_of_int 0x1E07;];[];
[Uchar.unsafe_of_int 0x1E09;];[];[Uchar.unsafe_of_int 0x1E0B;];[];
[Uchar.unsafe_of_int 0x1E0D;];[];[Uchar.unsafe_of_int 0x1E0F;];[];|];[|
[Uchar.unsafe_of_int 0x1E11;];[];[Uchar.unsafe_of_int 0x1E13;];[];
[Uchar.unsafe_of_int 0x1E15;];[];[Uchar.unsafe_of_int 0x1E17;];[];
[Uchar.unsafe_of_int 0x1E19;];[];[Uchar.unsafe_of_int 0x1E1B;];[];
[Uchar.unsafe_of_int 0x1E1D;];[];[Uchar.unsafe_of_int 0x1E1F;];[];|];[|
[Uchar.unsafe_of_int 0x1E21;];[];[Uchar.unsafe_of_int 0x1E23;];[];
[Uchar.unsafe_of_int 0x1E25;];[];[Uchar.unsafe_of_int 0x1E27;];[];
[Uchar.unsafe_of_int 0x1E29;];[];[Uchar.unsafe_of_int 0x1E2B;];[];
[Uchar.unsafe_of_int 0x1E2D;];[];[Uchar.unsafe_of_int 0x1E2F;];[];|];[|
[Uchar.unsafe_of_int 0x1E31;];[];[Uchar.unsafe_of_int 0x1E33;];[];
[Uchar.unsafe_of_int 0x1E35;];[];[Uchar.unsafe_of_int 0x1E37;];[];
[Uchar.unsafe_of_int 0x1E39;];[];[Uchar.unsafe_of_int 0x1E3B;];[];
[Uchar.unsafe_of_int 0x1E3D;];[];[Uchar.unsafe_of_int 0x1E3F;];[];|];[|
[Uchar.unsafe_of_int 0x1E41;];[];[Uchar.unsafe_of_int 0x1E43;];[];
[Uchar.unsafe_of_int 0x1E45;];[];[Uchar.unsafe_of_int 0x1E47;];[];
[Uchar.unsafe_of_int 0x1E49;];[];[Uchar.unsafe_of_int 0x1E4B;];[];
[Uchar.unsafe_of_int 0x1E4D;];[];[Uchar.unsafe_of_int 0x1E4F;];[];|];[|
[Uchar.unsafe_of_int 0x1E51;];[];[Uchar.unsafe_of_int 0x1E53;];[];
[Uchar.unsafe_of_int 0x1E55;];[];[Uchar.unsafe_of_int 0x1E57;];[];
[Uchar.unsafe_of_int 0x1E59;];[];[Uchar.unsafe_of_int 0x1E5B;];[];
[Uchar.unsafe_of_int 0x1E5D;];[];[Uchar.unsafe_of_int 0x1E5F;];[];|];[|
[Uchar.unsafe_of_int 0x1E61;];[];[Uchar.unsafe_of_int 0x1E63;];[];
[Uchar.unsafe_of_int 0x1E65;];[];[Uchar.unsafe_of_int 0x1E67;];[];
[Uchar.unsafe_of_int 0x1E69;];[];[Uchar.unsafe_of_int 0x1E6B;];[];
[Uchar.unsafe_of_int 0x1E6D;];[];[Uchar.unsafe_of_int 0x1E6F;];[];|];[|
[Uchar.unsafe_of_int 0x1E71;];[];[Uchar.unsafe_of_int 0x1E73;];[];
[Uchar.unsafe_of_int 0x1E75;];[];[Uchar.unsafe_of_int 0x1E77;];[];
[Uchar.unsafe_of_int 0x1E79;];[];[Uchar.unsafe_of_int 0x1E7B;];[];
[Uchar.unsafe_of_int 0x1E7D;];[];[Uchar.unsafe_of_int 0x1E7F;];[];|];[|
[Uchar.unsafe_of_int 0x1E81;];[];[Uchar.unsafe_of_int 0x1E83;];[];
[Uchar.unsafe_of_int 0x1E85;];[];[Uchar.unsafe_of_int 0x1E87;];[];
[Uchar.unsafe_of_int 0x1E89;];[];[Uchar.unsafe_of_int 0x1E8B;];[];
[Uchar.unsafe_of_int 0x1E8D;];[];[Uchar.unsafe_of_int 0x1E8F;];[];|];[|
[Uchar.unsafe_of_int 0x1E91;];[];[Uchar.unsafe_of_int 0x1E93;];[];
[Uchar.unsafe_of_int 0x1E95;];[];
[Uchar.unsafe_of_int 0x0068;Uchar.unsafe_of_int 0x0331;];
[Uchar.unsafe_of_int 0x0074;Uchar.unsafe_of_int 0x0308;];
[Uchar.unsafe_of_int 0x0077;Uchar.unsafe_of_int 0x030A;];
[Uchar.unsafe_of_int 0x0079;Uchar.unsafe_of_int 0x030A;];
[Uchar.unsafe_of_int 0x0061;Uchar.unsafe_of_int 0x02BE;];
[Uchar.unsafe_of_int 0x1E61;];[];[];
[Uchar.unsafe_of_int 0x0073;Uchar.unsafe_of_int 0x0073;];[];|];[|
[Uchar.unsafe_of_int 0x1EA1;];[];[Uchar.unsafe_of_int 0x1EA3;];[];
[Uchar.unsafe_of_int 0x1EA5;];[];[Uchar.unsafe_of_int 0x1EA7;];[];
[Uchar.unsafe_of_int 0x1EA9;];[];[Uchar.unsafe_of_int 0x1EAB;];[];
[Uchar.unsafe_of_int 0x1EAD;];[];[Uchar.unsafe_of_int 0x1EAF;];[];|];[|
[Uchar.unsafe_of_int 0x1EB1;];[];[Uchar.unsafe_of_int 0x1EB3;];[];
[Uchar.unsafe_of_int 0x1EB5;];[];[Uchar.unsafe_of_int 0x1EB7;];[];
[Uchar.unsafe_of_int 0x1EB9;];[];[Uchar.unsafe_of_int 0x1EBB;];[];
[Uchar.unsafe_of_int 0x1EBD;];[];[Uchar.unsafe_of_int 0x1EBF;];[];|];[|
[Uchar.unsafe_of_int 0x1EC1;];[];[Uchar.unsafe_of_int 0x1EC3;];[];
[Uchar.unsafe_of_int 0x1EC5;];[];[Uchar.unsafe_of_int 0x1EC7;];[];
[Uchar.unsafe_of_int 0x1EC9;];[];[Uchar.unsafe_of_int 0x1ECB;];[];
[Uchar.unsafe_of_int 0x1ECD;];[];[Uchar.unsafe_of_int 0x1ECF;];[];|];[|
[Uchar.unsafe_of_int 0x1ED1;];[];[Uchar.unsafe_of_int 0x1ED3;];[];
[Uchar.unsafe_of_int 0x1ED5;];[];[Uchar.unsafe_of_int 0x1ED7;];[];
[Uchar.unsafe_of_int 0x1ED9;];[];[Uchar.unsafe_of_int 0x1EDB;];[];
[Uchar.unsafe_of_int 0x1EDD;];[];[Uchar.unsafe_of_int 0x1EDF;];[];|];[|
[Uchar.unsafe_of_int 0x1EE1;];[];[Uchar.unsafe_of_int 0x1EE3;];[];
[Uchar.unsafe_of_int 0x1EE5;];[];[Uchar.unsafe_of_int 0x1EE7;];[];
[Uchar.unsafe_of_int 0x1EE9;];[];[Uchar.unsafe_of_int 0x1EEB;];[];
[Uchar.unsafe_of_int 0x1EED;];[];[Uchar.unsafe_of_int 0x1EEF;];[];|];[|
[Uchar.unsafe_of_int 0x1EF1;];[];[Uchar.unsafe_of_int 0x1EF3;];[];
[Uchar.unsafe_of_int 0x1EF5;];[];[Uchar.unsafe_of_int 0x1EF7;];[];
[Uchar.unsafe_of_int 0x1EF9;];[];[Uchar.unsafe_of_int 0x1EFB;];[];
[Uchar.unsafe_of_int 0x1EFD;];[];[Uchar.unsafe_of_int 0x1EFF;];[];|];[|
[];[];[];[];[];[];[];[];[Uchar.unsafe_of_int 0x1F00;];
[Uchar.unsafe_of_int 0x1F01;];[Uchar.unsafe_of_int 0x1F02;];
[Uchar.unsafe_of_int 0x1F03;];[Uchar.unsafe_of_int 0x1F04;];
[Uchar.unsafe_of_int 0x1F05;];[Uchar.unsafe_of_int 0x1F06;];
[Uchar.unsafe_of_int 0x1F07;];|];[|[];[];[];[];[];[];[];[];
[Uchar.unsafe_of_int 0x1F10;];[Uchar.unsafe_of_int 0x1F11;];
[Uchar.unsafe_of_int 0x1F12;];[Uchar.unsafe_of_int 0x1F13;];
[Uchar.unsafe_of_int 0x1F14;];[Uchar.unsafe_of_int 0x1F15;];[];[];|];[|
[];[];[];[];[];[];[];[];[Uchar.unsafe_of_int 0x1F20;];
[Uchar.unsafe_of_int 0x1F21;];[Uchar.unsafe_of_int 0x1F22;];
[Uchar.unsafe_of_int 0x1F23;];[Uchar.unsafe_of_int 0x1F24;];
[Uchar.unsafe_of_int 0x1F25;];[Uchar.unsafe_of_int 0x1F26;];
[Uchar.unsafe_of_int 0x1F27;];|];[|[];[];[];[];[];[];[];[];
[Uchar.unsafe_of_int 0x1F30;];[Uchar.unsafe_of_int 0x1F31;];
[Uchar.unsafe_of_int 0x1F32;];[Uchar.unsafe_of_int 0x1F33;];
[Uchar.unsafe_of_int 0x1F34;];[Uchar.unsafe_of_int 0x1F35;];
[Uchar.unsafe_of_int 0x1F36;];[Uchar.unsafe_of_int 0x1F37;];|];[|[];[];
[];[];[];[];[];[];[Uchar.unsafe_of_int 0x1F40;];
[Uchar.unsafe_of_int 0x1F41;];[Uchar.unsafe_of_int 0x1F42;];
[Uchar.unsafe_of_int 0x1F43;];[Uchar.unsafe_of_int 0x1F44;];
[Uchar.unsafe_of_int 0x1F45;];[];[];|];[|
[Uchar.unsafe_of_int 0x03C5;Uchar.unsafe_of_int 0x0313;];[];
[Uchar.unsafe_of_int 0x03C5;Uchar.unsafe_of_int 0x0313;
 Uchar.unsafe_of_int 0x0300;];
[];
[Uchar.unsafe_of_int 0x03C5;Uchar.unsafe_of_int 0x0313;
 Uchar.unsafe_of_int 0x0301;];
[];
[Uchar.unsafe_of_int 0x03C5;Uchar.unsafe_of_int 0x0313;
 Uchar.unsafe_of_int 0x0342;];
[];[];[Uchar.unsafe_of_int 0x1F51;];[];[Uchar.unsafe_of_int 0x1F53;];
[];[Uchar.unsafe_of_int 0x1F55;];[];[Uchar.unsafe_of_int 0x1F57;];|];[|
[];[];[];[];[];[];[];[];[Uchar.unsafe_of_int 0x1F60;];
[Uchar.unsafe_of_int 0x1F61;];[Uchar.unsafe_of_int 0x1F62;];
[Uchar.unsafe_of_int 0x1F63;];[Uchar.unsafe_of_int 0x1F64;];
[Uchar.unsafe_of_int 0x1F65;];[Uchar.unsafe_of_int 0x1F66;];
[Uchar.unsafe_of_int 0x1F67;];|];nil;[|
[Uchar.unsafe_of_int 0x1F00;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F01;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F02;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F03;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F04;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F05;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F06;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F07;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F00;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F01;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F02;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F03;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F04;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F05;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F06;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F07;Uchar.unsafe_of_int 0x03B9;];|];[|
[Uchar.unsafe_of_int 0x1F20;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F21;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F22;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F23;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F24;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F25;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F26;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F27;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F20;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F21;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F22;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F23;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F24;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F25;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F26;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F27;Uchar.unsafe_of_int 0x03B9;];|];[|
[Uchar.unsafe_of_int 0x1F60;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F61;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F62;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F63;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F64;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F65;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F66;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F67;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F60;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F61;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F62;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F63;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F64;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F65;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F66;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F67;Uchar.unsafe_of_int 0x03B9;];|];[|[];[];
[Uchar.unsafe_of_int 0x1F70;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x03B1;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x03AC;Uchar.unsafe_of_int 0x03B9;];[];
[Uchar.unsafe_of_int 0x03B1;Uchar.unsafe_of_int 0x0342;];
[Uchar.unsafe_of_int 0x03B1;Uchar.unsafe_of_int 0x0342;
 Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1FB0;];[Uchar.unsafe_of_int 0x1FB1;];
[Uchar.unsafe_of_int 0x1F70;];[Uchar.unsafe_of_int 0x1F71;];
[Uchar.unsafe_of_int 0x03B1;Uchar.unsafe_of_int 0x03B9;];[];
[Uchar.unsafe_of_int 0x03B9;];[];|];[|[];[];
[Uchar.unsafe_of_int 0x1F74;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x03B7;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x03AE;Uchar.unsafe_of_int 0x03B9;];[];
[Uchar.unsafe_of_int 0x03B7;Uchar.unsafe_of_int 0x0342;];
[Uchar.unsafe_of_int 0x03B7;Uchar.unsafe_of_int 0x0342;
 Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F72;];[Uchar.unsafe_of_int 0x1F73;];
[Uchar.unsafe_of_int 0x1F74;];[Uchar.unsafe_of_int 0x1F75;];
[Uchar.unsafe_of_int 0x03B7;Uchar.unsafe_of_int 0x03B9;];[];[];[];|];[|
[];[];
[Uchar.unsafe_of_int 0x03B9;Uchar.unsafe_of_int 0x0308;
 Uchar.unsafe_of_int 0x0300;];
[Uchar.unsafe_of_int 0x03B9;Uchar.unsafe_of_int 0x0308;
 Uchar.unsafe_of_int 0x0301;];
[];[];[Uchar.unsafe_of_int 0x03B9;Uchar.unsafe_of_int 0x0342;];
[Uchar.unsafe_of_int 0x03B9;Uchar.unsafe_of_int 0x0308;
 Uchar.unsafe_of_int 0x0342;];
[Uchar.unsafe_of_int 0x1FD0;];[Uchar.unsafe_of_int 0x1FD1;];
[Uchar.unsafe_of_int 0x1F76;];[Uchar.unsafe_of_int 0x1F77;];[];[];[];
[];|];[|[];[];
[Uchar.unsafe_of_int 0x03C5;Uchar.unsafe_of_int 0x0308;
 Uchar.unsafe_of_int 0x0300;];
[Uchar.unsafe_of_int 0x03C5;Uchar.unsafe_of_int 0x0308;
 Uchar.unsafe_of_int 0x0301;];
[Uchar.unsafe_of_int 0x03C1;Uchar.unsafe_of_int 0x0313;];[];
[Uchar.unsafe_of_int 0x03C5;Uchar.unsafe_of_int 0x0342;];
[Uchar.unsafe_of_int 0x03C5;Uchar.unsafe_of_int 0x0308;
 Uchar.unsafe_of_int 0x0342;];
[Uchar.unsafe_of_int 0x1FE0;];[Uchar.unsafe_of_int 0x1FE1;];
[Uchar.unsafe_of_int 0x1F7A;];[Uchar.unsafe_of_int 0x1F7B;];
[Uchar.unsafe_of_int 0x1FE5;];[];[];[];|];[|[];[];
[Uchar.unsafe_of_int 0x1F7C;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x03C9;Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x03CE;Uchar.unsafe_of_int 0x03B9;];[];
[Uchar.unsafe_of_int 0x03C9;Uchar.unsafe_of_int 0x0342;];
[Uchar.unsafe_of_int 0x03C9;Uchar.unsafe_of_int 0x0342;
 Uchar.unsafe_of_int 0x03B9;];
[Uchar.unsafe_of_int 0x1F78;];[Uchar.unsafe_of_int 0x1F79;];
[Uchar.unsafe_of_int 0x1F7C;];[Uchar.unsafe_of_int 0x1F7D;];
[Uchar.unsafe_of_int 0x03C9;Uchar.unsafe_of_int 0x03B9;];[];[];[];|];|];[|
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;[|
[];[];[];[];[];[];[Uchar.unsafe_of_int 0x03C9;];[];[];[];
[Uchar.unsafe_of_int 0x006B;];[Uchar.unsafe_of_int 0x00E5;];[];[];[];
[];|];[|[];[];[Uchar.unsafe_of_int 0x214E;];[];[];[];[];[];[];[];[];[];
[];[];[];[];|];nil;nil;[|[Uchar.unsafe_of_int 0x2170;];
[Uchar.unsafe_of_int 0x2171;];[Uchar.unsafe_of_int 0x2172;];
[Uchar.unsafe_of_int 0x2173;];[Uchar.unsafe_of_int 0x2174;];
[Uchar.unsafe_of_int 0x2175;];[Uchar.unsafe_of_int 0x2176;];
[Uchar.unsafe_of_int 0x2177;];[Uchar.unsafe_of_int 0x2178;];
[Uchar.unsafe_of_int 0x2179;];[Uchar.unsafe_of_int 0x217A;];
[Uchar.unsafe_of_int 0x217B;];[Uchar.unsafe_of_int 0x217C;];
[Uchar.unsafe_of_int 0x217D;];[Uchar.unsafe_of_int 0x217E;];
[Uchar.unsafe_of_int 0x217F;];|];nil;[|[];[];[];
[Uchar.unsafe_of_int 0x2184;];[];[];[];[];[];[];[];[];[];[];[];[];|];nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;[|[];[];[];[];[];[];
[Uchar.unsafe_of_int 0x24D0;];[Uchar.unsafe_of_int 0x24D1;];
[Uchar.unsafe_of_int 0x24D2;];[Uchar.unsafe_of_int 0x24D3;];
[Uchar.unsafe_of_int 0x24D4;];[Uchar.unsafe_of_int 0x24D5;];
[Uchar.unsafe_of_int 0x24D6;];[Uchar.unsafe_of_int 0x24D7;];
[Uchar.unsafe_of_int 0x24D8;];[Uchar.unsafe_of_int 0x24D9;];|];[|
[Uchar.unsafe_of_int 0x24DA;];[Uchar.unsafe_of_int 0x24DB;];
[Uchar.unsafe_of_int 0x24DC;];[Uchar.unsafe_of_int 0x24DD;];
[Uchar.unsafe_of_int 0x24DE;];[Uchar.unsafe_of_int 0x24DF;];
[Uchar.unsafe_of_int 0x24E0;];[Uchar.unsafe_of_int 0x24E1;];
[Uchar.unsafe_of_int 0x24E2;];[Uchar.unsafe_of_int 0x24E3;];
[Uchar.unsafe_of_int 0x24E4;];[Uchar.unsafe_of_int 0x24E5;];
[Uchar.unsafe_of_int 0x24E6;];[Uchar.unsafe_of_int 0x24E7;];
[Uchar.unsafe_of_int 0x24E8;];[Uchar.unsafe_of_int 0x24E9;];|];nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;[|
[Uchar.unsafe_of_int 0x2C30;];[Uchar.unsafe_of_int 0x2C31;];
[Uchar.unsafe_of_int 0x2C32;];[Uchar.unsafe_of_int 0x2C33;];
[Uchar.unsafe_of_int 0x2C34;];[Uchar.unsafe_of_int 0x2C35;];
[Uchar.unsafe_of_int 0x2C36;];[Uchar.unsafe_of_int 0x2C37;];
[Uchar.unsafe_of_int 0x2C38;];[Uchar.unsafe_of_int 0x2C39;];
[Uchar.unsafe_of_int 0x2C3A;];[Uchar.unsafe_of_int 0x2C3B;];
[Uchar.unsafe_of_int 0x2C3C;];[Uchar.unsafe_of_int 0x2C3D;];
[Uchar.unsafe_of_int 0x2C3E;];[Uchar.unsafe_of_int 0x2C3F;];|];[|
[Uchar.unsafe_of_int 0x2C40;];[Uchar.unsafe_of_int 0x2C41;];
[Uchar.unsafe_of_int 0x2C42;];[Uchar.unsafe_of_int 0x2C43;];
[Uchar.unsafe_of_int 0x2C44;];[Uchar.unsafe_of_int 0x2C45;];
[Uchar.unsafe_of_int 0x2C46;];[Uchar.unsafe_of_int 0x2C47;];
[Uchar.unsafe_of_int 0x2C48;];[Uchar.unsafe_of_int 0x2C49;];
[Uchar.unsafe_of_int 0x2C4A;];[Uchar.unsafe_of_int 0x2C4B;];
[Uchar.unsafe_of_int 0x2C4C;];[Uchar.unsafe_of_int 0x2C4D;];
[Uchar.unsafe_of_int 0x2C4E;];[Uchar.unsafe_of_int 0x2C4F;];|];[|
[Uchar.unsafe_of_int 0x2C50;];[Uchar.unsafe_of_int 0x2C51;];
[Uchar.unsafe_of_int 0x2C52;];[Uchar.unsafe_of_int 0x2C53;];
[Uchar.unsafe_of_int 0x2C54;];[Uchar.unsafe_of_int 0x2C55;];
[Uchar.unsafe_of_int 0x2C56;];[Uchar.unsafe_of_int 0x2C57;];
[Uchar.unsafe_of_int 0x2C58;];[Uchar.unsafe_of_int 0x2C59;];
[Uchar.unsafe_of_int 0x2C5A;];[Uchar.unsafe_of_int 0x2C5B;];
[Uchar.unsafe_of_int 0x2C5C;];[Uchar.unsafe_of_int 0x2C5D;];
[Uchar.unsafe_of_int 0x2C5E;];[];|];nil;nil;nil;[|
[Uchar.unsafe_of_int 0x2C61;];[];[Uchar.unsafe_of_int 0x026B;];
[Uchar.unsafe_of_int 0x1D7D;];[Uchar.unsafe_of_int 0x027D;];[];[];
[Uchar.unsafe_of_int 0x2C68;];[];[Uchar.unsafe_of_int 0x2C6A;];[];
[Uchar.unsafe_of_int 0x2C6C;];[];[Uchar.unsafe_of_int 0x0251;];
[Uchar.unsafe_of_int 0x0271;];[Uchar.unsafe_of_int 0x0250;];|];[|
[Uchar.unsafe_of_int 0x0252;];[];[Uchar.unsafe_of_int 0x2C73;];[];[];
[Uchar.unsafe_of_int 0x2C76;];[];[];[];[];[];[];[];[];
[Uchar.unsafe_of_int 0x023F;];[Uchar.unsafe_of_int 0x0240;];|];[|
[Uchar.unsafe_of_int 0x2C81;];[];[Uchar.unsafe_of_int 0x2C83;];[];
[Uchar.unsafe_of_int 0x2C85;];[];[Uchar.unsafe_of_int 0x2C87;];[];
[Uchar.unsafe_of_int 0x2C89;];[];[Uchar.unsafe_of_int 0x2C8B;];[];
[Uchar.unsafe_of_int 0x2C8D;];[];[Uchar.unsafe_of_int 0x2C8F;];[];|];[|
[Uchar.unsafe_of_int 0x2C91;];[];[Uchar.unsafe_of_int 0x2C93;];[];
[Uchar.unsafe_of_int 0x2C95;];[];[Uchar.unsafe_of_int 0x2C97;];[];
[Uchar.unsafe_of_int 0x2C99;];[];[Uchar.unsafe_of_int 0x2C9B;];[];
[Uchar.unsafe_of_int 0x2C9D;];[];[Uchar.unsafe_of_int 0x2C9F;];[];|];[|
[Uchar.unsafe_of_int 0x2CA1;];[];[Uchar.unsafe_of_int 0x2CA3;];[];
[Uchar.unsafe_of_int 0x2CA5;];[];[Uchar.unsafe_of_int 0x2CA7;];[];
[Uchar.unsafe_of_int 0x2CA9;];[];[Uchar.unsafe_of_int 0x2CAB;];[];
[Uchar.unsafe_of_int 0x2CAD;];[];[Uchar.unsafe_of_int 0x2CAF;];[];|];[|
[Uchar.unsafe_of_int 0x2CB1;];[];[Uchar.unsafe_of_int 0x2CB3;];[];
[Uchar.unsafe_of_int 0x2CB5;];[];[Uchar.unsafe_of_int 0x2CB7;];[];
[Uchar.unsafe_of_int 0x2CB9;];[];[Uchar.unsafe_of_int 0x2CBB;];[];
[Uchar.unsafe_of_int 0x2CBD;];[];[Uchar.unsafe_of_int 0x2CBF;];[];|];[|
[Uchar.unsafe_of_int 0x2CC1;];[];[Uchar.unsafe_of_int 0x2CC3;];[];
[Uchar.unsafe_of_int 0x2CC5;];[];[Uchar.unsafe_of_int 0x2CC7;];[];
[Uchar.unsafe_of_int 0x2CC9;];[];[Uchar.unsafe_of_int 0x2CCB;];[];
[Uchar.unsafe_of_int 0x2CCD;];[];[Uchar.unsafe_of_int 0x2CCF;];[];|];[|
[Uchar.unsafe_of_int 0x2CD1;];[];[Uchar.unsafe_of_int 0x2CD3;];[];
[Uchar.unsafe_of_int 0x2CD5;];[];[Uchar.unsafe_of_int 0x2CD7;];[];
[Uchar.unsafe_of_int 0x2CD9;];[];[Uchar.unsafe_of_int 0x2CDB;];[];
[Uchar.unsafe_of_int 0x2CDD;];[];[Uchar.unsafe_of_int 0x2CDF;];[];|];[|
[Uchar.unsafe_of_int 0x2CE1;];[];[Uchar.unsafe_of_int 0x2CE3;];[];[];
[];[];[];[];[];[];[Uchar.unsafe_of_int 0x2CEC;];[];
[Uchar.unsafe_of_int 0x2CEE;];[];[];|];[|[];[];[Uchar.unsafe_of_int 0x2CF3;];
[];[];[];[];[];[];[];[];[];[];[];[];[];|];nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;|];nil;nil;nil;nil;nil;nil;nil;[|nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;[|
[Uchar.unsafe_of_int 0xA641;];[];[Uchar.unsafe_of_int 0xA643;];[];
[Uchar.unsafe_of_int 0xA645;];[];[Uchar.unsafe_of_int 0xA647;];[];
[Uchar.unsafe_of_int 0xA649;];[];[Uchar.unsafe_of_int 0xA64B;];[];
[Uchar.unsafe_of_int 0xA64D;];[];[Uchar.unsafe_of_int 0xA64F;];[];|];[|
[Uchar.unsafe_of_int 0xA651;];[];[Uchar.unsafe_of_int 0xA653;];[];
[Uchar.unsafe_of_int 0xA655;];[];[Uchar.unsafe_of_int 0xA657;];[];
[Uchar.unsafe_of_int 0xA659;];[];[Uchar.unsafe_of_int 0xA65B;];[];
[Uchar.unsafe_of_int 0xA65D;];[];[Uchar.unsafe_of_int 0xA65F;];[];|];[|
[Uchar.unsafe_of_int 0xA661;];[];[Uchar.unsafe_of_int 0xA663;];[];
[Uchar.unsafe_of_int 0xA665;];[];[Uchar.unsafe_of_int 0xA667;];[];
[Uchar.unsafe_of_int 0xA669;];[];[Uchar.unsafe_of_int 0xA66B;];[];
[Uchar.unsafe_of_int 0xA66D;];[];[];[];|];nil;[|
[Uchar.unsafe_of_int 0xA681;];[];[Uchar.unsafe_of_int 0xA683;];[];
[Uchar.unsafe_of_int 0xA685;];[];[Uchar.unsafe_of_int 0xA687;];[];
[Uchar.unsafe_of_int 0xA689;];[];[Uchar.unsafe_of_int 0xA68B;];[];
[Uchar.unsafe_of_int 0xA68D;];[];[Uchar.unsafe_of_int 0xA68F;];[];|];[|
[Uchar.unsafe_of_int 0xA691;];[];[Uchar.unsafe_of_int 0xA693;];[];
[Uchar.unsafe_of_int 0xA695;];[];[Uchar.unsafe_of_int 0xA697;];[];
[Uchar.unsafe_of_int 0xA699;];[];[Uchar.unsafe_of_int 0xA69B;];[];[];
[];[];[];|];nil;nil;nil;nil;nil;nil;nil;nil;[|[];[];
[Uchar.unsafe_of_int 0xA723;];[];[Uchar.unsafe_of_int 0xA725;];[];
[Uchar.unsafe_of_int 0xA727;];[];[Uchar.unsafe_of_int 0xA729;];[];
[Uchar.unsafe_of_int 0xA72B;];[];[Uchar.unsafe_of_int 0xA72D;];[];
[Uchar.unsafe_of_int 0xA72F;];[];|];[|[];[];[Uchar.unsafe_of_int 0xA733;];
[];[Uchar.unsafe_of_int 0xA735;];[];[Uchar.unsafe_of_int 0xA737;];[];
[Uchar.unsafe_of_int 0xA739;];[];[Uchar.unsafe_of_int 0xA73B;];[];
[Uchar.unsafe_of_int 0xA73D;];[];[Uchar.unsafe_of_int 0xA73F;];[];|];[|
[Uchar.unsafe_of_int 0xA741;];[];[Uchar.unsafe_of_int 0xA743;];[];
[Uchar.unsafe_of_int 0xA745;];[];[Uchar.unsafe_of_int 0xA747;];[];
[Uchar.unsafe_of_int 0xA749;];[];[Uchar.unsafe_of_int 0xA74B;];[];
[Uchar.unsafe_of_int 0xA74D;];[];[Uchar.unsafe_of_int 0xA74F;];[];|];[|
[Uchar.unsafe_of_int 0xA751;];[];[Uchar.unsafe_of_int 0xA753;];[];
[Uchar.unsafe_of_int 0xA755;];[];[Uchar.unsafe_of_int 0xA757;];[];
[Uchar.unsafe_of_int 0xA759;];[];[Uchar.unsafe_of_int 0xA75B;];[];
[Uchar.unsafe_of_int 0xA75D;];[];[Uchar.unsafe_of_int 0xA75F;];[];|];[|
[Uchar.unsafe_of_int 0xA761;];[];[Uchar.unsafe_of_int 0xA763;];[];
[Uchar.unsafe_of_int 0xA765;];[];[Uchar.unsafe_of_int 0xA767;];[];
[Uchar.unsafe_of_int 0xA769;];[];[Uchar.unsafe_of_int 0xA76B;];[];
[Uchar.unsafe_of_int 0xA76D;];[];[Uchar.unsafe_of_int 0xA76F;];[];|];[|
[];[];[];[];[];[];[];[];[];[Uchar.unsafe_of_int 0xA77A;];[];
[Uchar.unsafe_of_int 0xA77C;];[];[Uchar.unsafe_of_int 0x1D79;];
[Uchar.unsafe_of_int 0xA77F;];[];|];[|[Uchar.unsafe_of_int 0xA781;];[];
[Uchar.unsafe_of_int 0xA783;];[];[Uchar.unsafe_of_int 0xA785;];[];
[Uchar.unsafe_of_int 0xA787;];[];[];[];[];[Uchar.unsafe_of_int 0xA78C;];
[];[Uchar.unsafe_of_int 0x0265;];[];[];|];[|[Uchar.unsafe_of_int 0xA791;];
[];[Uchar.unsafe_of_int 0xA793;];[];[];[];[Uchar.unsafe_of_int 0xA797;];
[];[Uchar.unsafe_of_int 0xA799;];[];[Uchar.unsafe_of_int 0xA79B;];[];
[Uchar.unsafe_of_int 0xA79D;];[];[Uchar.unsafe_of_int 0xA79F;];[];|];[|
[Uchar.unsafe_of_int 0xA7A1;];[];[Uchar.unsafe_of_int 0xA7A3;];[];
[Uchar.unsafe_of_int 0xA7A5;];[];[Uchar.unsafe_of_int 0xA7A7;];[];
[Uchar.unsafe_of_int 0xA7A9;];[];[Uchar.unsafe_of_int 0x0266;];
[Uchar.unsafe_of_int 0x025C;];[Uchar.unsafe_of_int 0x0261;];
[Uchar.unsafe_of_int 0x026C;];[Uchar.unsafe_of_int 0x026A;];[];|];[|
[Uchar.unsafe_of_int 0x029E;];[Uchar.unsafe_of_int 0x0287;];
[Uchar.unsafe_of_int 0x029D;];[Uchar.unsafe_of_int 0xAB53;];
[Uchar.unsafe_of_int 0xA7B5;];[];[Uchar.unsafe_of_int 0xA7B7;];[];[];
[];[];[];[];[];[];[];|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;[|[Uchar.unsafe_of_int 0x13A0;];
[Uchar.unsafe_of_int 0x13A1;];[Uchar.unsafe_of_int 0x13A2;];
[Uchar.unsafe_of_int 0x13A3;];[Uchar.unsafe_of_int 0x13A4;];
[Uchar.unsafe_of_int 0x13A5;];[Uchar.unsafe_of_int 0x13A6;];
[Uchar.unsafe_of_int 0x13A7;];[Uchar.unsafe_of_int 0x13A8;];
[Uchar.unsafe_of_int 0x13A9;];[Uchar.unsafe_of_int 0x13AA;];
[Uchar.unsafe_of_int 0x13AB;];[Uchar.unsafe_of_int 0x13AC;];
[Uchar.unsafe_of_int 0x13AD;];[Uchar.unsafe_of_int 0x13AE;];
[Uchar.unsafe_of_int 0x13AF;];|];[|[Uchar.unsafe_of_int 0x13B0;];
[Uchar.unsafe_of_int 0x13B1;];[Uchar.unsafe_of_int 0x13B2;];
[Uchar.unsafe_of_int 0x13B3;];[Uchar.unsafe_of_int 0x13B4;];
[Uchar.unsafe_of_int 0x13B5;];[Uchar.unsafe_of_int 0x13B6;];
[Uchar.unsafe_of_int 0x13B7;];[Uchar.unsafe_of_int 0x13B8;];
[Uchar.unsafe_of_int 0x13B9;];[Uchar.unsafe_of_int 0x13BA;];
[Uchar.unsafe_of_int 0x13BB;];[Uchar.unsafe_of_int 0x13BC;];
[Uchar.unsafe_of_int 0x13BD;];[Uchar.unsafe_of_int 0x13BE;];
[Uchar.unsafe_of_int 0x13BF;];|];[|[Uchar.unsafe_of_int 0x13C0;];
[Uchar.unsafe_of_int 0x13C1;];[Uchar.unsafe_of_int 0x13C2;];
[Uchar.unsafe_of_int 0x13C3;];[Uchar.unsafe_of_int 0x13C4;];
[Uchar.unsafe_of_int 0x13C5;];[Uchar.unsafe_of_int 0x13C6;];
[Uchar.unsafe_of_int 0x13C7;];[Uchar.unsafe_of_int 0x13C8;];
[Uchar.unsafe_of_int 0x13C9;];[Uchar.unsafe_of_int 0x13CA;];
[Uchar.unsafe_of_int 0x13CB;];[Uchar.unsafe_of_int 0x13CC;];
[Uchar.unsafe_of_int 0x13CD;];[Uchar.unsafe_of_int 0x13CE;];
[Uchar.unsafe_of_int 0x13CF;];|];[|[Uchar.unsafe_of_int 0x13D0;];
[Uchar.unsafe_of_int 0x13D1;];[Uchar.unsafe_of_int 0x13D2;];
[Uchar.unsafe_of_int 0x13D3;];[Uchar.unsafe_of_int 0x13D4;];
[Uchar.unsafe_of_int 0x13D5;];[Uchar.unsafe_of_int 0x13D6;];
[Uchar.unsafe_of_int 0x13D7;];[Uchar.unsafe_of_int 0x13D8;];
[Uchar.unsafe_of_int 0x13D9;];[Uchar.unsafe_of_int 0x13DA;];
[Uchar.unsafe_of_int 0x13DB;];[Uchar.unsafe_of_int 0x13DC;];
[Uchar.unsafe_of_int 0x13DD;];[Uchar.unsafe_of_int 0x13DE;];
[Uchar.unsafe_of_int 0x13DF;];|];[|[Uchar.unsafe_of_int 0x13E0;];
[Uchar.unsafe_of_int 0x13E1;];[Uchar.unsafe_of_int 0x13E2;];
[Uchar.unsafe_of_int 0x13E3;];[Uchar.unsafe_of_int 0x13E4;];
[Uchar.unsafe_of_int 0x13E5;];[Uchar.unsafe_of_int 0x13E6;];
[Uchar.unsafe_of_int 0x13E7;];[Uchar.unsafe_of_int 0x13E8;];
[Uchar.unsafe_of_int 0x13E9;];[Uchar.unsafe_of_int 0x13EA;];
[Uchar.unsafe_of_int 0x13EB;];[Uchar.unsafe_of_int 0x13EC;];
[Uchar.unsafe_of_int 0x13ED;];[Uchar.unsafe_of_int 0x13EE;];
[Uchar.unsafe_of_int 0x13EF;];|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
|];nil;nil;nil;nil;[|nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;[|
[Uchar.unsafe_of_int 0x0066;Uchar.unsafe_of_int 0x0066;];
[Uchar.unsafe_of_int 0x0066;Uchar.unsafe_of_int 0x0069;];
[Uchar.unsafe_of_int 0x0066;Uchar.unsafe_of_int 0x006C;];
[Uchar.unsafe_of_int 0x0066;Uchar.unsafe_of_int 0x0066;
 Uchar.unsafe_of_int 0x0069;];
[Uchar.unsafe_of_int 0x0066;Uchar.unsafe_of_int 0x0066;
 Uchar.unsafe_of_int 0x006C;];
[Uchar.unsafe_of_int 0x0073;Uchar.unsafe_of_int 0x0074;];
[Uchar.unsafe_of_int 0x0073;Uchar.unsafe_of_int 0x0074;];[];[];[];[];
[];[];[];[];[];|];[|[];[];[];
[Uchar.unsafe_of_int 0x0574;Uchar.unsafe_of_int 0x0576;];
[Uchar.unsafe_of_int 0x0574;Uchar.unsafe_of_int 0x0565;];
[Uchar.unsafe_of_int 0x0574;Uchar.unsafe_of_int 0x056B;];
[Uchar.unsafe_of_int 0x057E;Uchar.unsafe_of_int 0x0576;];
[Uchar.unsafe_of_int 0x0574;Uchar.unsafe_of_int 0x056D;];[];[];[];[];
[];[];[];[];|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;[|[];
[Uchar.unsafe_of_int 0xFF41;];[Uchar.unsafe_of_int 0xFF42;];
[Uchar.unsafe_of_int 0xFF43;];[Uchar.unsafe_of_int 0xFF44;];
[Uchar.unsafe_of_int 0xFF45;];[Uchar.unsafe_of_int 0xFF46;];
[Uchar.unsafe_of_int 0xFF47;];[Uchar.unsafe_of_int 0xFF48;];
[Uchar.unsafe_of_int 0xFF49;];[Uchar.unsafe_of_int 0xFF4A;];
[Uchar.unsafe_of_int 0xFF4B;];[Uchar.unsafe_of_int 0xFF4C;];
[Uchar.unsafe_of_int 0xFF4D;];[Uchar.unsafe_of_int 0xFF4E;];
[Uchar.unsafe_of_int 0xFF4F;];|];[|[Uchar.unsafe_of_int 0xFF50;];
[Uchar.unsafe_of_int 0xFF51;];[Uchar.unsafe_of_int 0xFF52;];
[Uchar.unsafe_of_int 0xFF53;];[Uchar.unsafe_of_int 0xFF54;];
[Uchar.unsafe_of_int 0xFF55;];[Uchar.unsafe_of_int 0xFF56;];
[Uchar.unsafe_of_int 0xFF57;];[Uchar.unsafe_of_int 0xFF58;];
[Uchar.unsafe_of_int 0xFF59;];[Uchar.unsafe_of_int 0xFF5A;];[];[];[];
[];[];|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;|];[|nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;[|[Uchar.unsafe_of_int 0x10428;];
[Uchar.unsafe_of_int 0x10429;];[Uchar.unsafe_of_int 0x1042A;];
[Uchar.unsafe_of_int 0x1042B;];[Uchar.unsafe_of_int 0x1042C;];
[Uchar.unsafe_of_int 0x1042D;];[Uchar.unsafe_of_int 0x1042E;];
[Uchar.unsafe_of_int 0x1042F;];[Uchar.unsafe_of_int 0x10430;];
[Uchar.unsafe_of_int 0x10431;];[Uchar.unsafe_of_int 0x10432;];
[Uchar.unsafe_of_int 0x10433;];[Uchar.unsafe_of_int 0x10434;];
[Uchar.unsafe_of_int 0x10435;];[Uchar.unsafe_of_int 0x10436;];
[Uchar.unsafe_of_int 0x10437;];|];[|[Uchar.unsafe_of_int 0x10438;];
[Uchar.unsafe_of_int 0x10439;];[Uchar.unsafe_of_int 0x1043A;];
[Uchar.unsafe_of_int 0x1043B;];[Uchar.unsafe_of_int 0x1043C;];
[Uchar.unsafe_of_int 0x1043D;];[Uchar.unsafe_of_int 0x1043E;];
[Uchar.unsafe_of_int 0x1043F;];[Uchar.unsafe_of_int 0x10440;];
[Uchar.unsafe_of_int 0x10441;];[Uchar.unsafe_of_int 0x10442;];
[Uchar.unsafe_of_int 0x10443;];[Uchar.unsafe_of_int 0x10444;];
[Uchar.unsafe_of_int 0x10445;];[Uchar.unsafe_of_int 0x10446;];
[Uchar.unsafe_of_int 0x10447;];|];[|[Uchar.unsafe_of_int 0x10448;];
[Uchar.unsafe_of_int 0x10449;];[Uchar.unsafe_of_int 0x1044A;];
[Uchar.unsafe_of_int 0x1044B;];[Uchar.unsafe_of_int 0x1044C;];
[Uchar.unsafe_of_int 0x1044D;];[Uchar.unsafe_of_int 0x1044E;];
[Uchar.unsafe_of_int 0x1044F;];[];[];[];[];[];[];[];[];|];nil;nil;nil;nil;
nil;nil;nil;nil;[|[Uchar.unsafe_of_int 0x104D8;];
[Uchar.unsafe_of_int 0x104D9;];[Uchar.unsafe_of_int 0x104DA;];
[Uchar.unsafe_of_int 0x104DB;];[Uchar.unsafe_of_int 0x104DC;];
[Uchar.unsafe_of_int 0x104DD;];[Uchar.unsafe_of_int 0x104DE;];
[Uchar.unsafe_of_int 0x104DF;];[Uchar.unsafe_of_int 0x104E0;];
[Uchar.unsafe_of_int 0x104E1;];[Uchar.unsafe_of_int 0x104E2;];
[Uchar.unsafe_of_int 0x104E3;];[Uchar.unsafe_of_int 0x104E4;];
[Uchar.unsafe_of_int 0x104E5;];[Uchar.unsafe_of_int 0x104E6;];
[Uchar.unsafe_of_int 0x104E7;];|];[|[Uchar.unsafe_of_int 0x104E8;];
[Uchar.unsafe_of_int 0x104E9;];[Uchar.unsafe_of_int 0x104EA;];
[Uchar.unsafe_of_int 0x104EB;];[Uchar.unsafe_of_int 0x104EC;];
[Uchar.unsafe_of_int 0x104ED;];[Uchar.unsafe_of_int 0x104EE;];
[Uchar.unsafe_of_int 0x104EF;];[Uchar.unsafe_of_int 0x104F0;];
[Uchar.unsafe_of_int 0x104F1;];[Uchar.unsafe_of_int 0x104F2;];
[Uchar.unsafe_of_int 0x104F3;];[Uchar.unsafe_of_int 0x104F4;];
[Uchar.unsafe_of_int 0x104F5;];[Uchar.unsafe_of_int 0x104F6;];
[Uchar.unsafe_of_int 0x104F7;];|];[|[Uchar.unsafe_of_int 0x104F8;];
[Uchar.unsafe_of_int 0x104F9;];[Uchar.unsafe_of_int 0x104FA;];
[Uchar.unsafe_of_int 0x104FB;];[];[];[];[];[];[];[];[];[];[];[];[];|];nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;[|[Uchar.unsafe_of_int 0x10CC0;];
[Uchar.unsafe_of_int 0x10CC1;];[Uchar.unsafe_of_int 0x10CC2;];
[Uchar.unsafe_of_int 0x10CC3;];[Uchar.unsafe_of_int 0x10CC4;];
[Uchar.unsafe_of_int 0x10CC5;];[Uchar.unsafe_of_int 0x10CC6;];
[Uchar.unsafe_of_int 0x10CC7;];[Uchar.unsafe_of_int 0x10CC8;];
[Uchar.unsafe_of_int 0x10CC9;];[Uchar.unsafe_of_int 0x10CCA;];
[Uchar.unsafe_of_int 0x10CCB;];[Uchar.unsafe_of_int 0x10CCC;];
[Uchar.unsafe_of_int 0x10CCD;];[Uchar.unsafe_of_int 0x10CCE;];
[Uchar.unsafe_of_int 0x10CCF;];|];[|[Uchar.unsafe_of_int 0x10CD0;];
[Uchar.unsafe_of_int 0x10CD1;];[Uchar.unsafe_of_int 0x10CD2;];
[Uchar.unsafe_of_int 0x10CD3;];[Uchar.unsafe_of_int 0x10CD4;];
[Uchar.unsafe_of_int 0x10CD5;];[Uchar.unsafe_of_int 0x10CD6;];
[Uchar.unsafe_of_int 0x10CD7;];[Uchar.unsafe_of_int 0x10CD8;];
[Uchar.unsafe_of_int 0x10CD9;];[Uchar.unsafe_of_int 0x10CDA;];
[Uchar.unsafe_of_int 0x10CDB;];[Uchar.unsafe_of_int 0x10CDC;];
[Uchar.unsafe_of_int 0x10CDD;];[Uchar.unsafe_of_int 0x10CDE;];
[Uchar.unsafe_of_int 0x10CDF;];|];[|[Uchar.unsafe_of_int 0x10CE0;];
[Uchar.unsafe_of_int 0x10CE1;];[Uchar.unsafe_of_int 0x10CE2;];
[Uchar.unsafe_of_int 0x10CE3;];[Uchar.unsafe_of_int 0x10CE4;];
[Uchar.unsafe_of_int 0x10CE5;];[Uchar.unsafe_of_int 0x10CE6;];
[Uchar.unsafe_of_int 0x10CE7;];[Uchar.unsafe_of_int 0x10CE8;];
[Uchar.unsafe_of_int 0x10CE9;];[Uchar.unsafe_of_int 0x10CEA;];
[Uchar.unsafe_of_int 0x10CEB;];[Uchar.unsafe_of_int 0x10CEC;];
[Uchar.unsafe_of_int 0x10CED;];[Uchar.unsafe_of_int 0x10CEE;];
[Uchar.unsafe_of_int 0x10CEF;];|];[|[Uchar.unsafe_of_int 0x10CF0;];
[Uchar.unsafe_of_int 0x10CF1;];[Uchar.unsafe_of_int 0x10CF2;];[];[];[];
[];[];[];[];[];[];[];[];[];[];|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;|];[|nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;[|[Uchar.unsafe_of_int 0x118C0;];
[Uchar.unsafe_of_int 0x118C1;];[Uchar.unsafe_of_int 0x118C2;];
[Uchar.unsafe_of_int 0x118C3;];[Uchar.unsafe_of_int 0x118C4;];
[Uchar.unsafe_of_int 0x118C5;];[Uchar.unsafe_of_int 0x118C6;];
[Uchar.unsafe_of_int 0x118C7;];[Uchar.unsafe_of_int 0x118C8;];
[Uchar.unsafe_of_int 0x118C9;];[Uchar.unsafe_of_int 0x118CA;];
[Uchar.unsafe_of_int 0x118CB;];[Uchar.unsafe_of_int 0x118CC;];
[Uchar.unsafe_of_int 0x118CD;];[Uchar.unsafe_of_int 0x118CE;];
[Uchar.unsafe_of_int 0x118CF;];|];[|[Uchar.unsafe_of_int 0x118D0;];
[Uchar.unsafe_of_int 0x118D1;];[Uchar.unsafe_of_int 0x118D2;];
[Uchar.unsafe_of_int 0x118D3;];[Uchar.unsafe_of_int 0x118D4;];
[Uchar.unsafe_of_int 0x118D5;];[Uchar.unsafe_of_int 0x118D6;];
[Uchar.unsafe_of_int 0x118D7;];[Uchar.unsafe_of_int 0x118D8;];
[Uchar.unsafe_of_int 0x118D9;];[Uchar.unsafe_of_int 0x118DA;];
[Uchar.unsafe_of_int 0x118DB;];[Uchar.unsafe_of_int 0x118DC;];
[Uchar.unsafe_of_int 0x118DD;];[Uchar.unsafe_of_int 0x118DE;];
[Uchar.unsafe_of_int 0x118DF;];|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;|];nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;[|nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;[|
[Uchar.unsafe_of_int 0x1E922;];[Uchar.unsafe_of_int 0x1E923;];
[Uchar.unsafe_of_int 0x1E924;];[Uchar.unsafe_of_int 0x1E925;];
[Uchar.unsafe_of_int 0x1E926;];[Uchar.unsafe_of_int 0x1E927;];
[Uchar.unsafe_of_int 0x1E928;];[Uchar.unsafe_of_int 0x1E929;];
[Uchar.unsafe_of_int 0x1E92A;];[Uchar.unsafe_of_int 0x1E92B;];
[Uchar.unsafe_of_int 0x1E92C;];[Uchar.unsafe_of_int 0x1E92D;];
[Uchar.unsafe_of_int 0x1E92E;];[Uchar.unsafe_of_int 0x1E92F;];
[Uchar.unsafe_of_int 0x1E930;];[Uchar.unsafe_of_int 0x1E931;];|];[|
[Uchar.unsafe_of_int 0x1E932;];[Uchar.unsafe_of_int 0x1E933;];
[Uchar.unsafe_of_int 0x1E934;];[Uchar.unsafe_of_int 0x1E935;];
[Uchar.unsafe_of_int 0x1E936;];[Uchar.unsafe_of_int 0x1E937;];
[Uchar.unsafe_of_int 0x1E938;];[Uchar.unsafe_of_int 0x1E939;];
[Uchar.unsafe_of_int 0x1E93A;];[Uchar.unsafe_of_int 0x1E93B;];
[Uchar.unsafe_of_int 0x1E93C;];[Uchar.unsafe_of_int 0x1E93D;];
[Uchar.unsafe_of_int 0x1E93E;];[Uchar.unsafe_of_int 0x1E93F;];
[Uchar.unsafe_of_int 0x1E940;];[Uchar.unsafe_of_int 0x1E941;];|];[|
[Uchar.unsafe_of_int 0x1E942;];[Uchar.unsafe_of_int 0x1E943;];[];[];[];
[];[];[];[];[];[];[];[];[];[];[];|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;|]}


(*---------------------------------------------------------------------------
   Copyright (c) 2014 Daniel C. Bünzli

   Permission to use, copy, modify, and/or distribute this software for any
   purpose with or without fee is hereby granted, provided that the above
   copyright notice and this permission notice appear in all copies.

   THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
  ---------------------------------------------------------------------------*)
