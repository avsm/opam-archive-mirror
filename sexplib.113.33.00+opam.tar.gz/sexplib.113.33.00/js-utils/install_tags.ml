let package_name = "sexplib"

let sections =
  [ ("lib",
    [ ("built_lib_sexplib", None)
    ; ("built_lib_sexplib_num", None)
    ; ("built_lib_sexplib_unix", None)
    ],
    [ ("META", None)
    ])
  ]
