#!bin/sh

./main.native --help=groff > $(opam config var man)/man1/valentine.1
