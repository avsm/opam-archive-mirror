# Bootvar

Library for passing boot parameters from Solo5 to MirageOS.

## Install

Bootvar can be installed with `opam`:

```
opam install mirage-bootvar-solo5
```

## License
Bootvar is published under the ISC license. See [LICENSE](LICENSE) for details.

