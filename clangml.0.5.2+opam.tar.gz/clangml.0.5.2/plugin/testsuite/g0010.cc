// g0003.cc
// from jrvb

int uselocale;
namespace __gnu_cxx
{
  extern "C" __typeof(uselocale) __uselocale;
}
