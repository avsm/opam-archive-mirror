fn1() __attribute__((stdcall));
