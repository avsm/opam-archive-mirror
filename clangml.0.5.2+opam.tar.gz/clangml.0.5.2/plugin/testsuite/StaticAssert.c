_Static_assert(sizeof(float) != sizeof(double), "True");
