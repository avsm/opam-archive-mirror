typedef float float4;

long numeric_out () {
  (float4)
   (
    ((union {unsigned __l; float __d;}) {__l: 0x7fc00000UL})
    .__d
    );
}
