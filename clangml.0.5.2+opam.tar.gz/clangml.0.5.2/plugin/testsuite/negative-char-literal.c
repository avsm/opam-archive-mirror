fn1 ()
{
  switch (0)
    case '\x80':
      ;
}
