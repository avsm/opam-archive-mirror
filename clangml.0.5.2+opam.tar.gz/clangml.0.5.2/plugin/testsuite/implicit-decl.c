void foo (void)
{
  bar ();
}
