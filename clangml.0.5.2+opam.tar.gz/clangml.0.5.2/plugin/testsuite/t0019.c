// t0019.c
// like in/t0414.cc but for C

struct S { int x; };
typedef struct S S;

void foo()
{
  struct S s;
}
