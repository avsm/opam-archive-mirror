// g0003.cc
// __builtin_va_list

typedef __builtin_va_list __gnuc_va_list;
