@interface A @end

@interface A(foo)
- (void)foo_myStuff;
@end
