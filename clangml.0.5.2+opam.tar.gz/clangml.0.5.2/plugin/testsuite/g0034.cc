// g0034.cc
// namespace attributes; gcc-4.2.1 has them, I'm not sure
// when they were added

namespace std __attribute__ ((__visibility__ ("default"))) {
}

// EOF
