include Test5
let _ = foo (* ? foo *) (* to foo of test.ml *)
let _ = Test5.in_test4 (* ? in_test4 *)

