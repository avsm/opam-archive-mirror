let y = 1
include Inc1
