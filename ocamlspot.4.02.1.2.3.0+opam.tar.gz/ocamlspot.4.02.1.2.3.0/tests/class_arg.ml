class c (* x => *) x (* <= x *) = object
  method get_x = x (* ? x *) + 0 
end
