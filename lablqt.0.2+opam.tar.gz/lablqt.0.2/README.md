There you can find my experienca about interfacing OCaml and Qt.

* Code generator for QtQuick 2.0 is in `src`.
* Library for interfacing with QtQuick 2 is in `lablqml`.
* Test example is now in `qml/test`

Use `./configure && make` to build it. Don't forget to install good Qt version.

Happy hacking,
Kakadu

