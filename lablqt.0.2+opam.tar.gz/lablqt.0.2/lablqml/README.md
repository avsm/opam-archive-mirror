To install this library manually into OPAM we should configure where
headers will be put:

    ./configure --datarootdir=`opam config var lib`

