class D {
  foo(): number { return 0; }
}
module.exports = D;
