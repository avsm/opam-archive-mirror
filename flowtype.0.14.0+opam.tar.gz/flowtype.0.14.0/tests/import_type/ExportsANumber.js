/* @ flow */

export var numValue = 42;
