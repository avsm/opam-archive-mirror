Xenops
------

Contains high-level abstractions around libxenctrl and xenstore to simplify
interactions with xen. Based on:

* [xenctrl](https://github.com/xen-org/ocaml-xen-lowlevel-libs)
* [xenstore](https://github.com/xen-org/ocaml-xenstore)

This library is under construction and much of the code is not yet built.
The eventual aim is to move much of
[xenopsd](https://github.com/djs55/xenopsd)'s libxenctrl backend here.
