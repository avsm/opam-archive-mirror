Authors of spatial_index:

* Alexander Dinu
