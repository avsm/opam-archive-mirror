camlgpc
=======

OCaml interface to Alan Murta's General Polygon Clipper.

GPC Homepage: http://www.cs.man.ac.uk/~toby/gpc/

To build
========

1. Type "make"

2. Type "make install" to install with ocamlfind

The documentation will be built in doc/camlgpc/html

To build the example
====================

Type "make" whilst in examples directory. Now execute the 'test' program.

