## Mockups ##

* [run frama-c on an examples with some options](frama-c-test.ml)
