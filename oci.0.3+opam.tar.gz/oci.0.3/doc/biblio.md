
Sharing mounts with a container
- http://s3hh.wordpress.com/2011/09/22/sharing-mounts-with-a-container/
