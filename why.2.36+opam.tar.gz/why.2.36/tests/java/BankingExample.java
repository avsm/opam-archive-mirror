public class BankingExample
      {
      
         public static final int MAX_BALANCE = 1000; 
         private int balance;
         private boolean isLocked = false; 
      
         //@ invariant my_inv: balance >= 0 && balance <= MAX_BALANCE;
      
         /*@ assigns balance, isLocked;
           @ ensures balance == 0;
           @*/
         public BankingExample()
         {
             this.balance = 0;
         }
      
          /*@ requires 0 < amount && amount + balance < MAX_BALANCE;
            @ assigns balance;
            @ ensures balance == \old(balance) + amount;
            @*/
         public void credit(final int amount)
         {
             this.balance += amount;
         }
     }