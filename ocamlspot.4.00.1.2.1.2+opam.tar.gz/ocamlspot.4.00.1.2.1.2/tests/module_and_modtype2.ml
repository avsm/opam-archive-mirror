module F(O : Module_and_modtype.O.M (* ? O.M *) ) = struct
end
