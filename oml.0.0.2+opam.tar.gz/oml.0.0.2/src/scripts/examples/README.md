In `utop` `# #use "script.ml"`
