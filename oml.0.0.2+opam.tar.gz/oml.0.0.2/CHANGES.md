Version 0.0.2 (2015-09-09):
---------------------------
  - Clean up the Classify API via a functor. 
  - Clean up test suite to use bounded floats and
    have a simpler testing framework.
  - Add bisection method.

Version 0.0.1 (2015-08-06):
---------------------------  
  - First public release: ready for other people to start hacking.
