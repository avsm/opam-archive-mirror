include Mimestring.Case_insensitive

