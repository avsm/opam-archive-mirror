For the `topkg test` to work download the Unicode segmentation test files
to the `test` directory this can simply done by:

    ocaml ./pkg/get_tests.ml
    topkg build
    topkg test
            
