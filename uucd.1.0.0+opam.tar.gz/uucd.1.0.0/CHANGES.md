v1.0.0 2013-10-01 Lausanne
--------------------------

- Updated for Unicode 6.3.0.
- OPAM friendly workflow and drop OASIS support.

v0.9.2 2013-01-04 La Forclaz (VS)
---------------------------------

- Updated for Unicode 6.2.0.

v0.9.1 2013-01-04 La Forclaz (VS)
---------------------------------

- Fix Uucd.is_scalar_value always returning false.

v0.9.0 2012-09-07 Lausanne
--------------------------

First release.
