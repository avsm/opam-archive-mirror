(* OASIS_START *)
(* DO NOT EDIT (digest: 57c7dff9c0037c01a59b3f8f51065745) *)
This is the README file for the omd distribution.

A Markdown frontend in pure OCaml.

This Markdown library has no dependency besides the OCaml compiler.  The
implementation targets the original Markdown with a few Github markdown
features.

See the files INSTALL.txt for building and installation instructions. 

Home page: https://github.com/pw374/omd


(* OASIS_STOP *)
