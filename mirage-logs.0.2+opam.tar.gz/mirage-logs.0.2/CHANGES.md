### 0.2.0 (2016-04-28)

- Add a `set_reporter` function (#1, @samoht)

### 0.1 (2016-02-18)

- Initial release (@talex5)
