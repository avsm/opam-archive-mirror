type t1 = int * int * int

type t2 = int * int * int * int

type t3 = int * int * int * int * int * int

let x = 1, 2, 3

let y = 1, 2, 3, 4

let z = 1, 2, 3, 4, 5, 6

let () =
  (match x, y, z with _ -> ());
  (match x, y, z, t with _ -> ());
  (match x, y, z, t, u, v with _ -> ());
  ()
