let () =
  if (true && false) then ();
  if (true) && (false) then ();
  if true && false then ();
  (match x with _ when true -> () | _ -> ());
  (match x with _ when (true) -> () | _ -> ());
  while f (false) do () done;
  while (false || false) do () done;
  while (false) || (false) do () done;
  for i = (1) to 3 do () done;
  for i = (1) + (2) to 3 do () done;
  for i = 1 to (3) do () done;
  for i = 1 to (3) + (0) do () done;
  ()
