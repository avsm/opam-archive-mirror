let () =
  if true then
    (if true then () else ())
  else
    (if true then () else ())

let () =
  if true then ()
  else if true then ()
  else ()
