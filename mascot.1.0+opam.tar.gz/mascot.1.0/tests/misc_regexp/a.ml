(* TODO: implement function *)
let f _ = ()

let () =
  print_endline "XXX"

(* call in order to do ... *)
let g () =
  print_endline "OK"
