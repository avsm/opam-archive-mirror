let () =
  while true do
    while true do
      while true do
        while true do
          print_endline "..."
        done
      done
    done
  done

let () =
  while true do
    while true do
      while true do
        print_endline "..."
      done
    done
  done
