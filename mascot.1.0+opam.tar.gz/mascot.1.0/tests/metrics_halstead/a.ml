let f x =
  3 * x

let g x y =
  for i = 1 to 3 do
    if i > x then
      print_endline y
  done

let h = function
  | 0 -> ()
  | n -> if (n mod 2) = 0 then for i = 1 to 5 do () done
