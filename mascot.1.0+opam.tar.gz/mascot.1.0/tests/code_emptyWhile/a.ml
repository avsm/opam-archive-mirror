let () =
  while a = !b do
    ()
  done;
  while a = !b do
    print_endline "..."
  done;
