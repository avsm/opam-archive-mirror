let () = ignore (1 + 1)

let () = ignore ()

let () = ignore (print_endline "...")

let () = ignore (1. +. 1.)
