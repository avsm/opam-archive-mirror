let () =
  try
    f x y
  with _ -> ()

let () =
  try
    f x y
  with Not_found -> ()

let () =
  try
    f x y
  with x -> ()

let () =
  try
    f x y
  with e when p e -> ()
