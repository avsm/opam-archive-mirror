let x, y = 1, 2

let x,y = x, y

let l = [1; 2; 3]

let l = [1 ; 2; 3]

let l = [
  1;
  2;
  3
]

let x = M.z

let z = M . z

let x = !r

let z = ! r

let id: 'a. 'a -> 'a = fun x -> x
