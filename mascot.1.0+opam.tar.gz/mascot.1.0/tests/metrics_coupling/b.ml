let b = A.a + 1

let b' = Int32.zero
