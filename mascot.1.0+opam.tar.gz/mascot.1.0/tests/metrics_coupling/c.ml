let c = A.a + B.b
