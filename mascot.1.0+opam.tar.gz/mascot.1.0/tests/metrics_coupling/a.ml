let a = 1

let () = List.iter ignore []
