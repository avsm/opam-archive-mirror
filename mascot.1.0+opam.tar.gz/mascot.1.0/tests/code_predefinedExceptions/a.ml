exception E of int

exception Not_found of bool

module M = struct
  exception E of int
  exception Not_found of bool
end
