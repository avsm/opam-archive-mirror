let () = begin print_string "hello."; print_newline () end; ()

let () = (print_string "hello."; print_newline ()); ()

let () = ( print_string "hello."; print_newline () ); ()

let l = [1; 2; 3]

let l = [ 1; 2; 3]

let l = [|1; 2; 3|]

let r = { Complex.re = 1.; Complex.im = 2. }

let a, b = let c = 1, 2 in (fst c), (snd c)

let l = [(succ 1); 4; 6; 8]

let l = (succ 1)::[]

let _ = f ~n:(1 + 2) ()
