let f x y z =
  if x = y then
    1
  else if x == z then
    2
  else
    3
