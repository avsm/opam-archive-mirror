let () =
  print_endline "1";
  print_endline "2";
  print_endline "3";
  print_endline "4";
  print_endline "5"

let () =
  print_endline "1";
  print_endline "2";
  print_endline "3";
  print_endline "4"
