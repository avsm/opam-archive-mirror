let () =
  for i = 1 to 3 do
    for j = 1 to 3 do
      for k = 1 to 3 do
        print_endline "..."
      done
    done
  done

let () =
  for i = 1 to 3 do
    for j = 1 to 3 do
      for k = 1 to 3 do
        for l = 1 to 3 do
          print_endline "..."
        done
      done
    done
  done
