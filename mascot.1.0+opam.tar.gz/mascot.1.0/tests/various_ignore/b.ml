let x = x + 1

let x = y

let x = x

module M = struct
  let y = y
end
