let () =
  print_endline "OK"

let () =
  print_endline "too long to be OK"
