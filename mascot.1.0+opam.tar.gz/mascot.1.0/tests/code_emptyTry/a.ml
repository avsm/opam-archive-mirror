let () =
  (try
    ()
  with Not_found -> ());
  (try
    print_endline "..."
  with _ -> ())
