let () =
  for i = 1 to 3 do
    ()
  done;
  for i = 1 to 3 do
    print_int i
  done;
