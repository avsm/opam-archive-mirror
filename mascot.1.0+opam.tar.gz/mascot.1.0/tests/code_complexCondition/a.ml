let f x y z = if x && y || (not z) then ()

let f x y z = while x && y || (not z) && (y || z && (not x)) do () done
