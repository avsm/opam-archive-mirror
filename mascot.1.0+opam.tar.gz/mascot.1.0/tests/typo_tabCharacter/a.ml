let () =
  print_endline "OK"

let () =
	print_endline "KO"

let () =
  print_endline "also	KO"
