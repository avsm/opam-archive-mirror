let () =
  try
    try
      try
        try
          print_endline "hello."
        with _ -> ()
      with _ -> ()
    with _ -> ()
  with _ -> ()

let () =
  try
    try
      try
        print_endline "hello."
      with _ -> ()
    with _ -> ()
  with _ -> ()
