let () =
  let msg =
    "this " ^
    "file " ^
    "is KO" in
  print_endline msg
