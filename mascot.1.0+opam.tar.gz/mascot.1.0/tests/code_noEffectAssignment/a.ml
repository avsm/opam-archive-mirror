let x = ref 0

let () = x := succ x

let () = x := x

