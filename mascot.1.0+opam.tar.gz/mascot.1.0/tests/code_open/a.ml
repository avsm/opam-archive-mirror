open String
open Printf

let () =
  printf "length = %d\n" (length "abcde")
