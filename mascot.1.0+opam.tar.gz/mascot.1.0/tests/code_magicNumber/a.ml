let () =
  let x = 9 + 9 + 9 in
  print_int x

let () =
  let x = 3 + 3 + 3 in
  print_int x

let () =
  let c = 11 in
  let x = c + c + c in
  print_int x
