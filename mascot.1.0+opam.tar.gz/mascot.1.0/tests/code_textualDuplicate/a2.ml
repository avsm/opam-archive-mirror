(* header *)

let x = 1

let f () =
  print_endline "start";
  print_endline "end"

let y = 2

