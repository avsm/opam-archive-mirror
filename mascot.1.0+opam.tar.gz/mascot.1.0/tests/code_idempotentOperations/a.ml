let x = 0 + 3 * (x / 1)

let y = y *. 1.

let z = 4 * x + 7 / 2
