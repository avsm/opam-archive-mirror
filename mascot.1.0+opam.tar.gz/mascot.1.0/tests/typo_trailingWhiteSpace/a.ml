let x = 1

let y = " "
	 
let z = 3 

let () =
  print_endline "azerty"

let () = 	
  print_endline "azerty" 

