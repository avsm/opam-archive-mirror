let f x y z = ()

let g x y z t = ()

class c = object
  method m x y z = ()
  method n x y z t = ()
end
