let (/) = Filename.concat

let () =
  let (+) x y = x + y in
  let (>>) x y = x + y in
  ignore (4 >> 5)
