type int = A | B

type 'a float = C

module M = struct
  type bool = D
end

type char
