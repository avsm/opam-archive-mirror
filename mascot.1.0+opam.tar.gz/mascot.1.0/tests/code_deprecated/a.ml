let l = [ 1; 2; 3 ]

let l' = Sort.list (<=) l
