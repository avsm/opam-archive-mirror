let f x y = x/ y * (-3)

let g x = x mod(3 + 2)

let h = List.fold_left (+) 0

let l = 1::2

let f2 ?(p = 0) = p?* p

let f3 x = match x with '0'..'9' -> 0 | _ -> 1

let x, y = [-1],~-1
