let x = 4

let a = 5

let ab = "cd"

module M = struct end

module Z = struct end
