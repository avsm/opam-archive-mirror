let () =
  if not true then ()

let y =
  if not true then 1 else 2
