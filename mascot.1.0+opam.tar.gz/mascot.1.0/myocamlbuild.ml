(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

open Ocamlbuild_plugin

let odocl_file = Pathname.pwd / "mascot.odocl"
let mlpack_file = Pathname.pwd / "mascotLibrary.mlpack"
let src_path = Pathname.pwd / "src"

let () =
  let odocl_chan = open_out odocl_file in
  let mlpack_chan = open_out mlpack_file in
  Array.iter
    (fun path ->
      let path = src_path / path in
      if Pathname.is_directory path then
        Array.iter
          (fun filename ->
            if (Pathname.check_extension filename "mli")
          || (Pathname.check_extension filename "mly")
          || (Pathname.check_extension filename "mll") then begin
              let modulename = Pathname.remove_extension filename in
              let modulename = Pathname.basename modulename in
              let modulename = String.capitalize modulename in
              output_string odocl_chan modulename;
              output_char odocl_chan '\n';
              output_string mlpack_chan modulename;
              output_char mlpack_chan '\n'
            end)
          (Pathname.readdir path))
    (Pathname.readdir src_path);
  close_out_noerr odocl_chan;
  close_out_noerr mlpack_chan

let version_tag = "src_common_version_ml"
let version_ml = "src/common/version.ml"
let version_file = "../VERSION"
let predefined_ml = "src/driver/predefined.ml"
let checks_path = "../src/checks"
let outputs_path = "../src/outputs"

let () =
  let safe_cp src dst =
    let src = Pathname.mk src in
    let dst = Pathname.mk dst in
    let dir = Pathname.dirname dst in
    let cmd = Printf.sprintf "mkdir -p %s" (Pathname.to_string dir) in
    if Sys.command cmd <> 0 then failwith ("cannot run " ^ cmd);
    cp src dst in
  dispatch begin function
    | After_rules ->
        flag ["ocaml"; "compile"; "use_compiler_libs"] (S[A"-I"; A"+compiler-libs"]);
        flag ["ocaml"; "link"; "byte"; "use_compiler_libs"] (S[A"-I"; A"+compiler-libs"; A"ocamlcommon.cma"]);
        flag ["ocaml"; "link"; "native"; "use_compiler_libs"] (S[A"-I"; A"+compiler-libs"; A"ocamlcommon.cmxa"]);
        if String.uppercase (try Sys.getenv "WARNINGS" with _ -> "") = "TRUE" then
          flag ["ocaml"; "compile"; "warnings"] (S[A"-w"; A"Ae"; A"-warn-error"; A"A"]);
        flag ["ocaml"; "compile"; "use_camlp4"] (S[A"-I"; P "+camlp4/Camlp4Parsers"]);
        flag ["ocaml"; "link"; "byte"; "use_camlp4"] (S[A"-I"; P "+camlp4/Camlp4Parsers"; A"camlp4fulllib.cma"]);
        flag ["ocaml"; "link"; "native"; "use_camlp4"] (S[A"-I"; P "+camlp4/Camlp4Parsers"; A"camlp4fulllib.cmxa"]);
        flag ["ocaml"; "compile"; "use_odoc_info"] (S[A"-I"; P "+ocamldoc"]);
        flag ["ocaml"; "link"; "byte"; "use_odoc_info"] (S[A"-I"; P "+ocamldoc"; A"odoc_info.cma"]);
        flag ["ocaml"; "link"; "native"; "use_odoc_info"] (S[A"-I"; P "+ocamldoc"; A"odoc_info.cmxa"]);
        flag ["ocaml"; "doc"; "use_odoc_info"] (S[A"-I"; P "+ocamldoc"]);

        dep [version_tag] [version_ml];
        rule ("generation of " ^ version_ml)
          ~prod:version_ml
          ~insert:`bottom
          (fun _ _ ->
            let version =
              try
                List.hd (string_list_of_file (Pathname.mk version_file))
              with _ -> "unknown" in
            let name, channel = Filename.open_temp_file "version" ".ml" in
            Printf.fprintf channel "let value = %S\n" version;
            close_out_noerr channel;
            safe_cp name version_ml);

        dep ["src_driver_predefined_ml"] [predefined_ml];
        rule ("generation of " ^ predefined_ml)
          ~prod:predefined_ml
          ~insert:`bottom
          (fun _ _ ->
            let print_module_list channel prefix path =
              let filenames = Sys.readdir path in
              Array.sort Pervasives.compare filenames;
              let rec get_signature chan =
                let line = input_line chan in
                try
                  Scanf.sscanf line "include %s@.%s" (fun x y -> x, y)
                with _ -> get_signature chan in
              Array.iter
                (fun filename ->
                  if Filename.check_suffix filename ".mli" then begin
                    let outer, inner =
                      try
                        let chan = open_in (Filename.concat path filename) in
                        let res = get_signature chan in
                        close_in_noerr chan;
                        res
                      with End_of_file ->
                        failwith ("cannot get signature for check file: " ^ filename) in
                    let basename = Filename.basename filename in
                    let module_name = String.capitalize (Filename.chop_suffix basename ".mli") in
                    Printf.fprintf channel " %s(module %s : %s.%s);\n"
                      (if prefix then outer ^ "." ^ inner ^ " " else "")
                      module_name
                      outer
                      inner;
                  end)
                filenames in
            let name, channel = Filename.open_temp_file "predefined" ".ml" in
            Printf.fprintf channel "let checks = [\n";
            print_module_list channel true checks_path;
            Printf.fprintf channel "]\n\nlet outputs = [\n";
            print_module_list channel false outputs_path;
            Printf.fprintf channel "]\n";
            close_out_noerr channel;
            safe_cp name predefined_ml)
    | _ -> ()
  end
