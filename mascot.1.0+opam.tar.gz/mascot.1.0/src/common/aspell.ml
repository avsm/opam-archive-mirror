(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type error =
  | Execution_error of string list
  | Invalid_character of char
  | Invalid_line of string

let string_of_error = function
  | Execution_error l -> Printf.sprintf "cannot run aspell:\n%s" (String.concat "\n" l)
  | Invalid_character ch -> Printf.sprintf "invalid leading character %C" ch
  | Invalid_line s ->  Printf.sprintf "invalid line %S" s

exception Exception of error

let () =
  Printexc.register_printer
    (function
      | Exception error -> Some (string_of_error error)
      | _ -> None)

let fail error =
  raise (Exception error)

type mistake = {
    word : string;
    suggestions : string list;
  }

let comma = Str.regexp ",[ \t]*"

module StringSet = Set.Make(struct type t = string let compare = Pervasives.compare end)

let analyse_lines ?(path="aspell") ?(dictionary="en") lines =
  let in_file = Filename.temp_file "aspell" "in" in
  let out_file = Filename.temp_file "aspell" "out" in
  let err_file = Filename.temp_file "aspell" "err" in
  Utils.write_lines (List.map (fun s -> "^" ^ s) lines) in_file;
  let cmd = Printf.sprintf "%s -a -l %s < %s > %s 2> %s"
      path
      dictionary
      in_file
      out_file
      err_file in
  if (Sys.command cmd) <> 0 then begin
    let err = Utils.read_lines err_file in
    fail (Execution_error err)
  end;
  let results = Utils.read_lines out_file in
  let acc, _ =
    List.fold_right
      (fun elem (acc, seen) ->
        let exists w = StringSet.mem w seen in
        let len = String.length elem in
        if len > 0 then
          match elem.[0] with
          | '*' -> acc, seen
          | '&' ->
              (try
                Scanf.sscanf elem "& %s %d %d: %s@\n"
                  (fun x _ _ l ->
                    if exists x then
                      acc, seen
                    else
                      let m = { word = x; suggestions = Str.split comma l } in
                      (m :: acc), (StringSet.add x seen))
              with _ -> fail (Invalid_line elem))
          | '#' ->
              (try
                Scanf.sscanf elem "# %s %d"
                  (fun x _ ->
                    if exists x then
                      acc, seen
                    else
                      let m = { word = x; suggestions = [] } in
                      (m :: acc), (StringSet.add x seen))
              with _ -> fail (Invalid_line elem))
          | '@' -> acc, seen
          | ch -> fail (Invalid_character ch)
        else
          acc, seen)
      results
      ([], StringSet.empty) in
  acc
