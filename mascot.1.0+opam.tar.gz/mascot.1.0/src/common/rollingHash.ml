(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = {
    hash_func : string -> int;
    elements : string array;
    mutable index : int;
    mutable curr_hash : int;
  }

let make f a =
  let hash = Array.fold_left (fun acc elem -> acc lxor (f elem)) 0 a in
  hash,
  { hash_func = f;
    elements = Array.copy a;
    index = 0;
    curr_hash = hash; }

let update rh s =
  let new_hash = rh.hash_func s in
  let old_hash = rh.hash_func rh.elements.(rh.index) in
  rh.elements.(rh.index) <- s;
  rh.index <- (succ rh.index) mod (Array.length rh.elements);
  rh.curr_hash <- rh.curr_hash lxor old_hash lxor new_hash;
  rh.curr_hash
