(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type error =
  | Empty_line
  | Invalid_block_start of string
  | Invalid_annotation of string
  | Invalid_reference_kind of string

let string_of_error = function
  | Empty_line -> "empty line"
  | Invalid_block_start s -> Printf.sprintf "invalid block start (%S)" s
  | Invalid_annotation s -> Printf.sprintf "invalid annotation (%S)" s
  | Invalid_reference_kind s -> Printf.sprintf "invalid reference kind (%S)" s

exception Exception of error

let () =
  Printexc.register_printer
    (function
      | Exception error -> Some (string_of_error error)
      | _ -> None)

let fail error =
  raise (Exception error)

type call =
  | Tail
  | Stack
  | Inline

type ident =
  | Definition
  | Internal_reference
  | External_reference

type t =
  | Type of string
  | Call of call
  | Ident of ident * string

type position = {
    filename : string;
    line : int;
    line_offset : int;
    offset : int;
  }

let ghost = {
  filename = "";
  line = -1;
  line_offset = -1;
  offset = -1;
}

type block = {
    range_start : position;
    range_end : position;
    elements : t list
  }

type file = block list

let load_file filename =
  let chan = open_in filename in
  let blocks = ref [] in
  let current_start = ref ghost in
  let current_end = ref ghost in
  let current_elements = ref [] in
  let add_block () =
    if (!current_start != ghost)
        && (!current_end != ghost)
        && (!current_elements <> []) then
      blocks := { range_start = !current_start;
                  range_end = !current_end;
                  elements = !current_elements} :: !blocks in
  (try
    while true do
      let line = input_line chan in
      if line = "" then fail Empty_line;
      if line.[0] = '\"' then begin
        add_block ();
        try
          Scanf.sscanf line "%S %d %d %d %S %d %d %d"
            (fun fn1 ln1 lo1 ofs1 fn2 ln2 lo2 ofs2 ->
              current_start := { filename = fn1;
                                 line = ln1;
                                 line_offset = lo1;
                                 offset = ofs1 };
              current_end := { filename = fn2;
                               line = ln2;
                               line_offset = lo2;
                               offset = ofs2 };
              current_elements := [])
        with _ -> fail (Invalid_block_start line)
      end else begin
        try
          let param = input_line chan in
          let close = input_line chan in
          let elem = match line, param, close with
          | "type(", _, ")" ->
              Type (String.sub param 2 ((String.length param) - 2))
          | "call(", "  tail", ")" -> Call Tail
          | "call(", "  stack", ")" -> Call Stack
          | "call(", "  inline", ")" -> Call Inline
          | "ident(", _, ")" ->
              (try
                let kind = ref Definition in
                let id = ref "" in
                Scanf.sscanf param "  %s %s@\n"
                  (fun k i ->
                    kind := (match k with
                    | "def" -> Definition
                    | "int_ref" -> Internal_reference
                    | "ext_ref" -> External_reference
                    | _ -> fail (Invalid_reference_kind k));
                    id := i);
                Ident (!kind, !id)
              with _ -> fail (Invalid_annotation line))
          | _ -> fail (Invalid_annotation line) in
          current_elements := elem :: !current_elements;
        with 
        | Sys_error _ | End_of_file -> fail (Invalid_annotation line)
      end
    done
  with End_of_file -> ());
  add_block ();
  close_in_noerr chan;
  !blocks
