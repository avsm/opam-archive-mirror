(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

(* Base types *)

type file =
  | Interface
  | Implementation

type report_function = int -> int option -> string -> unit

type report = {
    filename : string;
    info : report_function;
    warning : report_function;
    error : report_function;
  }


(* Generic checks *)

module type T = sig
  type t
  val category : CategoryName.t
  val name : CheckName.t
  val multiple : bool
  val description : string
  val documentation : string
  val rationale : string
  val limits : string
  val parameters : Parameter.map
  val run : State.id -> Ocamldep.dependency list -> t -> Parameter.map -> report -> unit
end

type lines = file * ((int * string) list)

type ocamldoc = Odoc_info.Module.t_module

type tokens = file * ((int * int * Camlp4.Sig.camlp4_token) list)

type structure = Camlp4.PreCast.Ast.str_item

type signature = Camlp4.PreCast.Ast.sig_item

type annotations = Annotation.file

type binary_annotations = Cmt_format.cmt_infos

module type Lines = T with type t = lines

module type OCamldoc = T with type t = ocamldoc

module type Tokens = T with type t = tokens

module type Structure = T with type t = structure

module type Signature = T with type t = signature

module type Annotations = T with type t = annotations

module type Binary_annotations = T with type t = binary_annotations

type t =
  | Lines of (module Lines)
  | OCamldoc of (module OCamldoc)
  | Tokens of (module Tokens)
  | Structure of (module Structure)
  | Signature of (module Signature)
  | Annotations of (module Annotations)
  | Binary_annotations of (module Binary_annotations)


(* Accessors *)

let category x =
  match x with
  | Lines x -> let module X = (val x : Lines) in X.category
  | OCamldoc x -> let module X = (val x : OCamldoc) in X.category
  | Tokens x -> let module X = (val x : Tokens) in X.category
  | Structure x -> let module X = (val x : Structure) in X.category
  | Signature x -> let module X = (val x : Signature) in X.category
  | Annotations x -> let module X = (val x : Annotations) in X.category
  | Binary_annotations x -> let module X = (val x : Binary_annotations) in X.category

let name x =
  match x with
  | Lines x -> let module X = (val x : Lines) in X.name
  | OCamldoc x -> let module X = (val x : OCamldoc) in X.name
  | Tokens x -> let module X = (val x : Tokens) in X.name
  | Structure x -> let module X = (val x : Structure) in X.name
  | Signature x -> let module X = (val x : Signature) in X.name
  | Annotations x -> let module X = (val x : Annotations) in X.name
  | Binary_annotations x -> let module X = (val x : Binary_annotations) in X.name

let multiple x =
  match x with
  | Lines x -> let module X = (val x : Lines) in X.multiple
  | OCamldoc x -> let module X = (val x : OCamldoc) in X.multiple
  | Tokens x -> let module X = (val x : Tokens) in X.multiple
  | Structure x -> let module X = (val x : Structure) in X.multiple
  | Signature x -> let module X = (val x : Signature) in X.multiple
  | Annotations x -> let module X = (val x : Annotations) in X.multiple
  | Binary_annotations x -> let module X = (val x : Binary_annotations) in X.multiple

let description x =
  match x with
  | Lines x -> let module X = (val x : Lines) in X.description
  | OCamldoc x -> let module X = (val x : OCamldoc) in X.description
  | Tokens x -> let module X = (val x : Tokens) in X.description
  | Structure x -> let module X = (val x : Structure) in X.description
  | Signature x -> let module X = (val x : Signature) in X.description
  | Annotations x -> let module X = (val x : Annotations) in X.description
  | Binary_annotations x -> let module X = (val x : Binary_annotations) in X.description

let documentation x =
  match x with
  | Lines x -> let module X = (val x : Lines) in X.documentation
  | OCamldoc x -> let module X = (val x : OCamldoc) in X.documentation
  | Tokens x -> let module X = (val x : Tokens) in X.documentation
  | Structure x -> let module X = (val x : Structure) in X.documentation
  | Signature x -> let module X = (val x : Signature) in X.documentation
  | Annotations x -> let module X = (val x : Annotations) in X.documentation
  | Binary_annotations x -> let module X = (val x : Binary_annotations) in X.documentation

let rationale x =
  match x with
  | Lines x -> let module X = (val x : Lines) in X.rationale
  | OCamldoc x -> let module X = (val x : OCamldoc) in X.rationale
  | Tokens x -> let module X = (val x : Tokens) in X.rationale
  | Structure x -> let module X = (val x : Structure) in X.rationale
  | Signature x -> let module X = (val x : Signature) in X.rationale
  | Annotations x -> let module X = (val x : Annotations) in X.rationale
  | Binary_annotations x -> let module X = (val x : Binary_annotations) in X.rationale

let limits x =
  match x with
  | Lines x -> let module X = (val x : Lines) in X.limits
  | OCamldoc x -> let module X = (val x : OCamldoc) in X.limits
  | Tokens x -> let module X = (val x : Tokens) in X.limits
  | Structure x -> let module X = (val x : Structure) in X.limits
  | Signature x -> let module X = (val x : Signature) in X.limits
  | Annotations x -> let module X = (val x : Annotations) in X.limits
  | Binary_annotations x -> let module X = (val x : Binary_annotations) in X.limits

let parameters x =
  match x with
  | Lines x -> let module X = (val x : Lines) in X.parameters
  | OCamldoc x -> let module X = (val x : OCamldoc) in X.parameters
  | Tokens x -> let module X = (val x : Tokens) in X.parameters
  | Structure x -> let module X = (val x : Structure) in X.parameters
  | Signature x -> let module X = (val x : Signature) in X.parameters
  | Annotations x -> let module X = (val x : Annotations) in X.parameters
  | Binary_annotations x -> let module X = (val x : Binary_annotations) in X.parameters

let same x y =
  (category x) = (category y) && (name x) = (name y)

module Loc = Camlp4.Struct.Loc

module Ast = Camlp4.Struct.Camlp4Ast.Make (Loc)

module Token = Camlp4.Struct.Token.Make (Loc)

module Lexer = Camlp4.Struct.Lexer.Make (Token)

module OCamlRevisedParser = Camlp4OCamlRevisedParser.Make (Camlp4.PreCast.Syntax)

let lines_cache =
  Cache.make
    (fun filename ->
      let chan = open_in filename in
      let line = ref 1 in
      let lines = ref [] in
      (try
        while true do
          lines := (!line, (input_line chan)) :: !lines;
          incr line
        done;
        assert false
      with
      | End_of_file ->
          close_in_noerr chan);
      List.rev !lines)

let ocamldoc_cache =
  Cache.make
    (fun filename ->
      match Odoc_info.analyse_files [Odoc_global.Intf_file filename] with
      | [res] -> Some res
      | [] -> None
      | _ -> assert false)

let tokens_cache =
  Cache.make
    (fun filename ->
      let loc = Loc.mk filename in
      let chan = open_in filename in
      let stream = Stream.of_channel chan in
      let lexer = Lexer.from_stream ~quotations: false loc stream in
      let rec iter acc =
        match Stream.peek lexer with
        | Some (Camlp4.Sig.EOI, _) -> List.rev acc
        | Some (token, loc) ->
            let line = Loc.start_line loc in
            let column = (Loc.start_off loc) - (Loc.start_bol loc) in
            Stream.junk lexer;
            iter ((line, column, token) :: acc)
        | None -> List.rev acc in
      let tokens = iter [] in
      close_in_noerr chan;
      tokens)

let structure_cache =
  Cache.make
    (fun filename ->
      let loc = Camlp4.PreCast.Loc.mk filename in
      let chan = open_in filename in
      let stream = Stream.of_channel chan in
      let ast = Camlp4.Register.CurrentParser.parse_implem loc stream in
      close_in_noerr chan;
      ast)

let signature_cache =
  Cache.make
    (fun filename ->
      let loc = Camlp4.PreCast.Loc.mk filename in
      let chan = open_in filename in
      let stream = Stream.of_channel chan in
      let ast = Camlp4.Register.CurrentParser.parse_interf loc stream in
      close_in_noerr chan;
      ast)

let last_path = ref ["."]

let get_candidates filename =
  List.fold_left
    (fun acc path ->
      let full = Filename.concat path filename in
      if (Sys.file_exists full) && not (Sys.is_directory full) then
        full :: acc
      else
        acc)
    []
    !last_path

let annotations_cache =
  Cache.make
    (fun filename ->
      if Filename.check_suffix filename ".ml" then begin
        let filename = (Filename.chop_suffix filename ".ml") ^ ".annot" in
        let candidates = get_candidates filename in
        match List.rev candidates with
        | hd :: _ -> Annotation.load_file hd
        | [] -> []
      end else
        [])

let binary_annotations_ghost =
  let open Cmt_format in
  { cmt_modname = "<ghost>";
    cmt_annots = Partial_interface [||];
    cmt_comments = [];
    cmt_args = [||];
    cmt_sourcefile = None;
    cmt_builddir = "";
    cmt_loadpath = [];
    cmt_source_digest = None;
    cmt_initial_env = Env.empty;
    cmt_imports = [];
    cmt_interface_digest = None;
    cmt_use_summaries = false; }

let binary_annotations_cache =
  Cache.make
    (fun filename ->
      let process filename =
        let candidates = get_candidates filename in
        match List.rev candidates with
        | hd :: _ -> Cmt_format.read_cmt hd
        | [] -> binary_annotations_ghost in
      if Filename.check_suffix filename ".ml" then begin
        let filename = (Filename.chop_suffix filename ".ml") ^ ".cmt" in
        process filename
      end else if Filename.check_suffix filename ".mli" then begin
        let filename = (Filename.chop_suffix filename ".mli") ^ ".cmti" in
        process filename
      end else
        binary_annotations_ghost)

let first_time = ref true

let do_run id no_cache search_path deps params filename chk =
  if !first_time then begin
    if !Camlp4Utils.use_original_syntax then begin
      let module OCamlParser = Camlp4OCamlParser.Make (Camlp4.PreCast.Syntax) in
      ()
    end;
    first_time := false
  end;
  if no_cache then begin
    Cache.clear lines_cache;
    Cache.clear ocamldoc_cache;
    Cache.clear tokens_cache;
    Cache.clear structure_cache;
    Cache.clear signature_cache;
    Cache.clear annotations_cache;
    Cache.clear binary_annotations_cache
  end;
  if (!last_path <> search_path) then begin
    Cache.clear annotations_cache;
    Cache.clear binary_annotations_cache;
    last_path := search_path
  end;
  let category = category chk in
  let name = name chk in
  let res = ref Report.empty in
  let info no no' msg = res := Report.add Report.Info category name filename no no' msg !res in
  let warning no no' msg = res := Report.add Report.Warning category name filename no no' msg !res in
  let error no no' msg = res := Report.add Report.Error category name filename no no' msg !res in
  let rep = { filename = filename; info = info; warning = warning; error = error; } in
  let file =
    if Filename.check_suffix filename ".mli" then
      Interface
    else if Filename.check_suffix filename ".ml" then
      Implementation
    else
      Implementation in
  (match chk with
  | Lines mdl ->
      let module Mdl = (val mdl : Lines) in
      let lines = Cache.get lines_cache filename in
      Mdl.run id deps (file, lines) params rep
  | OCamldoc mdl ->
      let module Mdl = (val mdl : OCamldoc) in
      if file = Interface then begin
        match Cache.get ocamldoc_cache filename with
        | Some x -> Mdl.run id deps x params rep
        | None -> error 1 None "no ocamldoc information retrieved"
      end
  | Tokens mdl ->
      let module Mdl = (val mdl : Tokens) in
      Mdl.run id deps (file, (Cache.get tokens_cache filename)) params rep
  | Structure mdl ->
      let module Mdl = (val mdl : Structure) in
      (match file with
      | Implementation ->
          Mdl.run id deps (Cache.get structure_cache filename) params rep
      | _ -> ())
  | Signature mdl ->
      let module Mdl = (val mdl : Signature) in
      (match file with
      | Interface ->
          Mdl.run id deps (Cache.get signature_cache filename) params rep
      | _ -> ())
  | Annotations mdl ->
      let module Mdl = (val mdl : Annotations) in
      (match file with
      | Implementation ->
          Mdl.run id deps (Cache.get annotations_cache filename) params rep
      | _ -> ())
  | Binary_annotations mdl ->
      let module Mdl = (val mdl : Binary_annotations) in
      let binary_annotations = Cache.get binary_annotations_cache filename in
      if binary_annotations != binary_annotations_ghost then
        Mdl.run id deps binary_annotations params rep);
  !res
