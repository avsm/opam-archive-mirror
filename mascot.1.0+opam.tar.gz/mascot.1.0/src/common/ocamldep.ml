(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type error =
  | Execution_error of string list
  | Invalid_line of string

let string_of_error = function
  | Execution_error l -> Printf.sprintf "cannot run ocamldep:\n%s" (String.concat "\n" l)
  | Invalid_line s -> Printf.sprintf "invalid line %S" s

exception Exception of error

let () =
  Printexc.register_printer
    (function
      | Exception error -> Some (string_of_error error)
      | _ -> None)

let fail error =
  raise (Exception error)

type dependency = {
    file : string;
    modules : string list;
  }

let analyse_files ?(path="ocamldep") ?(preprocessor="") files =
  let files = List.map Filename.quote files in
  let out_file = Filename.temp_file "ocamldep" "out" in
  let err_file = Filename.temp_file "ocamldep" "err" in
  let cmd = Printf.sprintf "%s%s -modules %s > %s 2> %s"
      path
      (if preprocessor = "" then
        ""
      else
        Printf.sprintf " -pp %S" preprocessor)
      (String.concat " " files)
      out_file
      err_file in
  if (Sys.command cmd) <> 0 then begin
    let err = Utils.read_lines err_file in
    fail (Execution_error err)
  end;
  let lines = Utils.read_lines out_file in
  let lines =
    List.map
      (fun line ->
        try
          Scanf.sscanf line "%s@:%s@\n"
            (fun filename modules ->
              let stream = Stream.of_string modules in
              let lexer = Genlex.make_lexer [] stream in
              let modules = Stream.npeek max_int lexer in
              let modules =
                List.map
                  (function
                  | Genlex.Ident id -> id
                  | Genlex.Kwd _
                  | Genlex.Int _
                  | Genlex.Float _
                  | Genlex.String _
                  | Genlex.Char _ -> assert false)
                  modules in
              { file = filename; modules = modules })
        with _ -> fail (Invalid_line line))
      lines in
  lines
