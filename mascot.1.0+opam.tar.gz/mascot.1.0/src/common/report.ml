(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

(* Base elements *)

type kind =
  | Info
  | Warning
  | Error

let string_of_kind = function
  | Info -> "info"
  | Warning -> "warning"
  | Error -> "error"

type element = {
    kind : kind;
    category : CategoryName.t;
    check : CheckName.t;
    filename : string;
    line : int;
    column : int option;
    message : string;
  }

let copy x =
 { kind = x.kind;
   category = CategoryName.make (x.category :> string);
   check = CheckName.make (x.check :> string);
   filename = String.copy x.filename;
   line = x.line;
   column = x.column;
   message = String.copy x.message; }


(* Reports *)

module StringMap = Map.Make (struct type t = string let compare = Pervasives.compare end)

type t = element list StringMap.t

let empty = StringMap.empty

let statistics x =
  StringMap.fold
    (fun _ elements (infos, warnings, errors) ->
      List.fold_left
        (fun (infos, warnings, errors) element ->
          match element.kind with
          | Info -> (succ infos, warnings, errors)
          | Warning -> (infos, succ warnings, errors)
          | Error -> (infos, warnings, succ errors))
        (infos, warnings, errors)
        elements)
    x
    (0, 0, 0)

let add knd cat chk fn ln cn msg x =
  let elem = { kind = knd;
               category = cat;
               check = chk;
               filename = fn;
               line = ln;
               column = cn;
               message = msg; } in
  let old =
    try
      StringMap.find elem.filename x
    with Not_found -> [] in
  if List.mem elem old then
    x
  else
    StringMap.add elem.filename (elem :: old) x

let concat x y =
  StringMap.merge
    (fun _ l1 l2 ->
      let l1 = match l1 with Some x -> x | None -> [] in
      let l2 = match l2 with Some x -> x | None -> [] in
      Some (l1 @ l2))
    x
    y

let concat_list l =
  List.fold_left concat empty l

let compare x y =
  let order e =
    e.filename, e.line, e.column, e.kind, e.category, e.check, e.message in
  Pervasives.compare (order x) (order y)

let merge x =
  let l =
    StringMap.fold
      (fun _ l acc -> (List.sort compare l) :: acc) 
      x
      [] in
  List.flatten (List.rev l)

let filter no_inf no_wrn no_err ignore_list x =
  StringMap.fold
    (fun filename elements acc ->
      let elements =
        List.filter
          (fun element ->
            let knd =
              (element.kind = Warning && no_wrn)
            || (element.kind = Error && no_err)
            || (element.kind = Info && no_inf) in
            let ign =
              List.exists
                (fun y ->
                  element.category = y.Ignore.category
                    && element.check = y.Ignore.check
                    && (match y.Ignore.file with Some f -> element.filename = f | None -> true)
                    && List.exists (fun (lo, hi) -> element.line >= lo & element.line <= hi) y.Ignore.intervals)
                ignore_list in
            (not knd) && (not ign))
          elements in
      if elements = [] then acc else StringMap.add filename elements acc)
    x
    StringMap.empty

let iter f x =
  List.iter (fun e -> f (copy e)) (merge x)

let map f x =
  List.map (fun e -> f (copy e)) (merge x)

let fold f acc x =
  List.fold_left
    (fun acc e -> f (copy e) acc)
    acc
    (merge x)

let split_by_file x =
  let l = StringMap.bindings x in
  List.map (fun (x, y) -> x, StringMap.singleton x y) l
