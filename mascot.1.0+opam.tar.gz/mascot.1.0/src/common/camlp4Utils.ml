(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

let line_and_column_of_location loc =
  let open Camlp4.PreCast.Ast in
  let col = (Loc.start_off loc) - (Loc.start_bol loc) in
  Loc.start_line loc, Some col

let rec string_of_ident i =
  let open Camlp4.PreCast.Ast in
  match i with
  | IdAcc (_, s1, s2) -> (string_of_ident s1) ^ "." ^ (string_of_ident s2)
  | IdApp (_, s1, s2) -> (string_of_ident s1) ^ " " ^ (string_of_ident s2)
  | IdLid (_, s)
  | IdUid (_, s)
  | IdAnt (_, s) -> s

let use_original_syntax = ref true


(* Whitespace functions *)

type where =
  | Before
  | After

let string_of_where = function
  | Before -> "before"
  | After -> "after"

type color =
  | White
  | Grey
  | Black

let color = function
  | Camlp4.Sig.KEYWORD _
  | Camlp4.Sig.SYMBOL _
  | Camlp4.Sig.LIDENT _
  | Camlp4.Sig.UIDENT _
  | Camlp4.Sig.ESCAPED_IDENT _
  | Camlp4.Sig.INT _
  | Camlp4.Sig.INT32 _
  | Camlp4.Sig.INT64 _
  | Camlp4.Sig.NATIVEINT _
  | Camlp4.Sig.FLOAT _
  | Camlp4.Sig.CHAR _
  | Camlp4.Sig.STRING _
  | Camlp4.Sig.LABEL _
  | Camlp4.Sig.OPTLABEL _
  | Camlp4.Sig.QUOTATION _
  | Camlp4.Sig.ANTIQUOT _
  | Camlp4.Sig.LINE_DIRECTIVE _ -> Black
  | Camlp4.Sig.COMMENT _ -> Grey
  | Camlp4.Sig.BLANKS "" -> Grey
  | Camlp4.Sig.BLANKS _ -> White
  | Camlp4.Sig.NEWLINE -> Grey
  | Camlp4.Sig.EOI -> Grey

let gen_check_white where kind symbol report x =
  match color x with
  | Black ->
      let where = string_of_where where in
      let msg = Printf.sprintf "missing whitespace %s %s %S" where kind symbol in
      report msg
  | _ -> ()

let gen_check_not_white where kind symbol report x =
  match color x with
  | White ->
      let where = string_of_where where in
      let msg = Printf.sprintf "extra whitespace %s %s %S" where kind symbol in
      report msg
  | _ -> ()

let check_white = gen_check_white Before

let check_not_white = gen_check_not_white Before

let check_first_white kind symbol report = function
  | (_, _, hd) :: _ -> gen_check_white After kind symbol report hd
  | [] -> ()

let check_first_not_white kind symbol report = function
  | (_, _, hd) :: _ -> gen_check_not_white After kind symbol report hd
  | [] -> ()


(* Debug functions *)

let print_structure x =
  Camlp4.PreCast.Printers.OCaml.print_implem x

let print_signature x =
  Camlp4.PreCast.Printers.OCaml.print_interf x

let string_of_token = function
  | Camlp4.Sig.KEYWORD s -> Printf.sprintf "KEYWORD %S" s
  | Camlp4.Sig.SYMBOL s -> Printf.sprintf "SYMBOL %S" s
  | Camlp4.Sig.LIDENT s -> Printf.sprintf "LIDENT %S" s
  | Camlp4.Sig.UIDENT s -> Printf.sprintf "UIDENT %S" s
  | Camlp4.Sig.ESCAPED_IDENT s -> Printf.sprintf "ESCAPED_IDENT %S" s
  | Camlp4.Sig.INT (_, s) -> Printf.sprintf "INT %S" s
  | Camlp4.Sig.INT32 (_, s) -> Printf.sprintf "INT32 %S" s
  | Camlp4.Sig.INT64 (_, s) -> Printf.sprintf "INT64 %S" s
  | Camlp4.Sig.NATIVEINT (_, s) -> Printf.sprintf "NATIVEINT %S" s
  | Camlp4.Sig.FLOAT (_, s) -> Printf.sprintf "FLOAT %S" s
  | Camlp4.Sig.CHAR (_, s) -> Printf.sprintf "CHAR %S" s
  | Camlp4.Sig.STRING (_, s) -> Printf.sprintf "STRING %S" s
  | Camlp4.Sig.LABEL s -> Printf.sprintf "LABEL %S" s
  | Camlp4.Sig.OPTLABEL s -> Printf.sprintf "OPTLABEL %S" s
  | Camlp4.Sig.QUOTATION _ -> "QUOTATION _"
  | Camlp4.Sig.ANTIQUOT (_, s) -> Printf.sprintf "ANTIQUOT %S" s
  | Camlp4.Sig.COMMENT s -> Printf.sprintf "COMMENT %S" s
  | Camlp4.Sig.BLANKS s -> Printf.sprintf "BLANKS %S" s
  | Camlp4.Sig.NEWLINE -> "NEWLINE"
  | Camlp4.Sig.LINE_DIRECTIVE (n, s) ->
      let f = match s with Some x -> x | None -> "<none>" in
      Printf.sprintf "LINE_DIRECTIVE %d %S" n f
  | Camlp4.Sig.EOI -> "EOI"

let print_tokens l =
  List.iter
    (fun (x, y, z) ->
      Printf.printf "%d, %d, %s\n" x y (string_of_token z))
    l


(* Miscellaneous functions *)

let binary_names = [
  "camlp4o";
  "camlp4of";
  "camlp4oof";
  "camlp4orf";
  "camlp4r";
  "camlp4rf";
]

let is_revised_binary = function
  | "camlp4r"
  | "camlp4rf" -> true
  | _ -> false

let predefined_modules = [
  "Camlp4OCamlRevisedParser";
  "Camlp4OCamlReloadedParser";
  "Camlp4OCamlParser";
  "Camlp4OCamlRevisedParserParser";
  "Camlp4OCamlParserParser";
  "Camlp4GrammarParser";
  "Camlp4MacroParser";
  "Camlp4QuotationCommon";
  "Camlp4QuotationExpander";
  "Camlp4OCamlRevisedQuotationExpander";
  "Camlp4OCamlOriginalQuotationExpander";
  "Camlp4ListComprehension";
]
