(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type id = int

type 'a getter = id -> 'a

type 'a setter = id -> 'a -> unit

let next = ref 0

let next_id () =
  incr next;
  !next

let init f =
  let table = Hashtbl.create 17 in
  let get_state id =
    try
      Hashtbl.find table id
    with Not_found ->
      let x = f () in
      Hashtbl.add table id x;
      x in
  let set_state id x =
    Hashtbl.replace table id x in
  get_state, set_state
