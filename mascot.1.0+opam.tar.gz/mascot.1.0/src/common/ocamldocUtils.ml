(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

let line_and_column_of_location x =
  match x with
  | Some loc ->
      let pos = loc.Location.loc_start in
      let line = pos.Lexing.pos_lnum in
      let column = pos.Lexing.pos_cnum - pos.Lexing.pos_bol in
      line, Some column
  | None -> 0, None

let rec string_of_text_element te = 
  let open Odoc_info in
  match te with
  | Raw s -> s
  | Code _ -> ""
  | CodePre _ -> ""
  | Verbatim s -> s
  | Bold t -> string_of_text t
  | Italic t -> string_of_text t
  | Emphasize t -> string_of_text t
  | Center t -> string_of_text t
  | Left t -> string_of_text t
  | Right t -> string_of_text t
  | List l -> string_of_text_list l
  | Enum l -> string_of_text_list l
  | Newline -> ""
  | Block t -> string_of_text t
  | Title (_, _, t) -> string_of_text t
  | Latex _ -> ""
  | Link (_, t) -> string_of_text t
  | Ref (_, _, Some x) -> string_of_text x
  | Ref (_, _, None) -> ""
  | Superscript t -> string_of_text t
  | Subscript t -> string_of_text t
  | Module_list _ -> ""
  | Index_list -> ""
  | Custom (_, t) -> string_of_text t
  | Target _ -> ""
and string_of_text l =
  String.concat " " (List.map string_of_text_element l)
and string_of_text_option = function
  | Some x -> string_of_text x
  | None -> ""
and string_of_text_list l =
  String.concat " " (List.map string_of_text l)
and string_of_text_snd_list l =
  string_of_text_list (List.map snd l)

let string_of_info info =
  let open Odoc_info in
  String.concat
    " "
    [string_of_text_option info.i_desc;
     string_of_text_snd_list info.i_before;
     string_of_text_option info.i_deprecated;
     string_of_text_option info.i_return_value;
     string_of_text_snd_list info.i_custom;
     string_of_text_snd_list info.i_sees;
     string_of_text_snd_list info.i_params;
     string_of_text_snd_list info.i_raised_exceptions]

let string_of_info_option = function
  | Some x -> string_of_info x
  | None -> ""

let is_empty_info_option strict = function
  | Some x ->
      if strict then
        let x = string_of_info x in
        let x = Utils.trim x in
        x = ""
      else
        false
  | None -> true
