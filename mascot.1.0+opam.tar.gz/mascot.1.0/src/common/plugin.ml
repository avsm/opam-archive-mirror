(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type error =
  | Dynlink_error of Dynlink.error
  | Duplicate_check of CheckName.t
  | Duplicate_output of OutputName.t

let string_of_error = function
  | Dynlink_error de -> Dynlink.error_message de
  | Duplicate_check id -> Printf.sprintf "duplicate check %S" (id :> string)
  | Duplicate_output id -> Printf.sprintf "duplicate output %S" (id :> string)

exception Exception of error

let () =
  Printexc.register_printer
    (function
      | Exception error -> Some (string_of_error error)
      | _ -> None)

let fail error =
  raise (Exception error)

let checks = ref []

let outputs = ref []

let register_check chk =
  if List.exists (Check.same chk) (!checks @ Predefined.checks) then
    fail (Duplicate_check (Check.name chk))
  else
    checks := chk :: !checks

let register_lines_check chk =
  register_check (Check.Lines chk)

let register_ocamldoc_check chk =
  register_check (Check.OCamldoc chk)

let register_tokens_check chk =
  register_check (Check.Tokens chk)

let register_structure_check chk =
  register_check (Check.Structure chk)

let register_signature_check chk =
  register_check (Check.Signature chk)

let register_output out =
  if List.exists (Output.same out) (!outputs @ Predefined.outputs) then
    let module Out = (val out : Output.T) in
    fail (Duplicate_output Out.name)
  else
    outputs := out :: !outputs

let get_checks () =
  List.rev !checks

let get_outputs () =
  List.rev !outputs

let load filename =
  try
    Dynlink.loadfile_private filename
  with
  | Dynlink.Error de -> fail (Dynlink_error de)
