(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

(* Exception *)

type error =
  | Duplicate_parameter of ParameterName.t
  | Invalid_value of string
  | Invalid_type of string * string
  | Unknown_parameter of ParameterName.t

let string_of_error = function
  | Duplicate_parameter s -> Printf.sprintf "duplicate parameter %S" (s :> string)
  | Invalid_value s -> Printf.sprintf "invalid value %S" s
  | Invalid_type (w, f) -> Printf.sprintf "invalid type: %S waited but %S found" w f
  | Unknown_parameter s -> Printf.sprintf "unknown parameter %S" (s :> string)

exception Exception of error

let () =
  Printexc.register_printer
    (function
      | Exception error -> Some (string_of_error error)
      | _ -> None)

let fail error =
  raise (Exception error)


(* Single parameters *)

type 'a t =
  | Bool_desc of bool desc
  | Int_desc of int desc
  | String_desc of string desc
  | Symbol_desc of string desc
  | Symbol_list_desc of string list desc

and 'a predicate = 'a -> bool

and 'a desc = ParameterName.t * string * 'a * 'a predicate

let bool x = Bool_desc x

let int x = Int_desc x

let string x = String_desc x

let symbol x = Symbol_desc x

let symbol_list x = Symbol_list_desc x

let ident = function
  | Bool_desc (x, _, _, _) -> x
  | Int_desc (x, _, _, _) -> x
  | String_desc (x, _, _, _) -> x
  | Symbol_desc (x, _, _, _) -> x
  | Symbol_list_desc (x, _, _, _) -> x

let doc = function
  | Bool_desc (_, x, _, _) -> x
  | Int_desc (_, x, _, _) -> x
  | String_desc (_, x, _, _) -> x
  | Symbol_desc (_, x, _, _) -> x
  | Symbol_list_desc (_, x, _, _) -> x

let typename = function
  | Bool_desc _ -> "boolean"
  | Int_desc _ -> "integer"
  | String_desc _ -> "string"
  | Symbol_desc _ -> "symbol"
  | Symbol_list_desc _ -> "symbol list"

let value = function
  | Bool_desc (_, _, x, _) -> string_of_bool x
  | Int_desc (_, _, x, _) -> string_of_int x
  | String_desc (_, _, x, _) -> Printf.sprintf "%S" x
  | Symbol_desc (_, _, x, _) -> x
  | Symbol_list_desc (_, _, x, _) -> "[" ^ (String.concat "; " x) ^ "]"

let coerce x =
  match x with
  | Bool_desc x -> Bool_desc x
  | Int_desc x -> Int_desc x
  | String_desc x -> String_desc x
  | Symbol_desc x -> Symbol_desc x
  | Symbol_list_desc x -> Symbol_list_desc x


(* Parameter maps *)

module StringMap = Map.Make (struct type t = ParameterName.t let compare = Pervasives.compare end)

type map = unit t StringMap.t

let empty_map = StringMap.empty

let size m =
  StringMap.cardinal m

let add_desc d m =
  let id = ident d in
  if StringMap.mem id m then
    fail (Duplicate_parameter id)
  else
    StringMap.add id (coerce d) m

let set_bool id x m =
  try
    match StringMap.find id m with
    | Bool_desc (_, doc, _, pred) ->
        if pred x then
          StringMap.add id (Bool_desc (id, doc, x, pred)) m
        else
          fail (Invalid_value (string_of_bool x))
    | dsc -> fail (Invalid_type ("bool", typename dsc))
  with Not_found -> fail (Unknown_parameter id)

let set_int id x m =
  try
    match StringMap.find id m with
    | Int_desc (_, doc, _, pred) ->
        if pred x then
          StringMap.add id (Int_desc (id, doc, x, pred)) m
        else
          fail (Invalid_value (string_of_int x))
    | dsc -> fail (Invalid_type ("int", typename dsc))
  with Not_found -> fail (Unknown_parameter id)

let set_string id x m =
  try
    match StringMap.find id m with
    | String_desc (_, doc, _, pred) ->
        if pred x then
          StringMap.add id (String_desc (id, doc, x, pred)) m
        else
          fail (Invalid_value x)
    | dsc -> fail (Invalid_type ("string", typename dsc))
  with Not_found -> fail (Unknown_parameter id)

let set_symbol id x m =
  try
    match StringMap.find id m with
    | Symbol_desc (_, doc, _, pred) ->
        if pred x then
          StringMap.add id (Symbol_desc (id, doc, x, pred)) m
        else
          fail (Invalid_value x)
    | dsc -> fail (Invalid_type ("symbol", typename dsc))
  with Not_found -> fail (Unknown_parameter id)

let set_symbol_list id x m =
  try
    match StringMap.find id m with
    | Symbol_list_desc (_, doc, _, pred) ->
        if pred x then
          StringMap.add id (Symbol_list_desc (id, doc, x, pred)) m
        else
          fail (Invalid_value ("[" ^ (String.concat "; " x) ^ "]"))
    | dsc -> fail (Invalid_type ("symbol list", typename dsc))
  with Not_found -> fail (Unknown_parameter id)

let get_bool id m =
  try
    match StringMap.find id m with
    | Bool_desc (_, _, x, _) -> x
    | dsc -> fail (Invalid_type ("bool", typename dsc))
  with Not_found -> fail (Unknown_parameter id)

let get_int id m =
  try
    match StringMap.find id m with
    | Int_desc (_, _, x, _) -> x
    | dsc -> fail (Invalid_type ("int", typename dsc))
  with Not_found -> fail (Unknown_parameter id)

let get_string id m =
  try
    match StringMap.find id m with
    | String_desc (_, _, x, _) -> x
    | dsc -> fail (Invalid_type ("string", typename dsc))
  with Not_found -> fail (Unknown_parameter id)

let get_symbol id m =
  try
    match StringMap.find id m with
    | Symbol_desc (_, _, x, _) -> x
    | dsc -> fail (Invalid_type ("symbol", typename dsc))
  with Not_found -> fail (Unknown_parameter id)

let get_symbol_list id m =
  try
    match StringMap.find id m with
    | Symbol_list_desc (_, _, x, _) -> x
    | dsc -> fail (Invalid_type ("symbol list", typename dsc))
  with Not_found -> fail (Unknown_parameter id)

let iter f map =
  StringMap.iter
    (fun _ v -> f (ident v) (typename v) (value v) (doc v))
    map


(* Parameter map builders *)

let return = function
  | Bool_desc (id, _, _, _) -> Obj.magic (get_bool id)
  | Int_desc (id, _, _, _) -> Obj.magic (get_int id)
  | String_desc (id, _, _, _) -> Obj.magic (get_string id)
  | Symbol_desc (id, _, _, _) -> Obj.magic (get_symbol id)
  | Symbol_list_desc (id, _, _, _) -> Obj.magic (get_symbol_list id)

let make1 d1 =
  let m = empty_map in
  let m = add_desc d1 m in
  m, return d1

let make2 d1 d2 =
  let m = empty_map in
  let m = add_desc d1 m in
  let m = add_desc d2 m in
  m, return d1, return d2

let make3 d1 d2 d3 =
  let m = empty_map in
  let m = add_desc d1 m in
  let m = add_desc d2 m in
  let m = add_desc d3 m in
  m, return d1, return d2, return d3

let make4 d1 d2 d3 d4 =
  let m = empty_map in
  let m = add_desc d1 m in
  let m = add_desc d2 m in
  let m = add_desc d3 m in
  let m = add_desc d4 m in
  m, return d1, return d2, return d3, return d4


(* Predefined predicates *)

let any _ = true

let positive x = x >= 0

let strictly_positive x = x > 0

let non_empty_string s = s <> ""

let level_symbol = function
  | "info"
  | "warning"
  | "error" -> true
  | _ -> false
