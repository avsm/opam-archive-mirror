(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type error =
  | Empty_name
  | Invalid_character of char

let string_of_error = function
  | Empty_name -> "empty check name"
  | Invalid_character ch -> Printf.sprintf "invalid check character %C" ch

exception Exception of error

let () =
  Printexc.register_printer
    (function
      | Exception error -> Some (string_of_error error)
      | _ -> None)

let fail error =
  raise (Exception error)

type t = string

let make s =
  let len = String.length s in
  if len = 0 then fail Empty_name;
  for i = 0 to pred len do
    match s.[i] with
    | 'a' .. 'z' | '_' -> ()
    | ch -> fail (Invalid_character ch)
  done;
  String.copy s
