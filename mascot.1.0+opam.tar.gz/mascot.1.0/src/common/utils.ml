(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

(* Time functions *)

let current_time () =
  let now = Unix.localtime (Unix.time ()) in
  Printf.sprintf "%d-%02d-%02d %02d:%02d:%02d"
    (1900 + now.Unix.tm_year)
    (succ now.Unix.tm_mon)
    now.Unix.tm_mday
    now.Unix.tm_hour
    now.Unix.tm_min
    now.Unix.tm_sec


(* String functions *)

let trim s =
  let is_white_space = function
    | ' ' | '\t' | '\r' | '\n' -> true
    | _ -> false in
  let len = String.length s in
  let i = ref 0 in
  while (!i < len) && (is_white_space  s.[!i]) do
    incr i
  done;
  let j = ref (pred len) in
  while (!j >= !i) && (is_white_space  s.[!j]) do
    decr j;
  done;
  if !j < !i then
    ""
  else
    String.sub s !i (!j - !i + 1)

let string_hash s =
  let res = ref 0 in
  String.iter
    (fun ch ->
      res := (223 * !res + (Char.code ch)) land 0x7FFFFFFF)
    s;
  !res


(* I/O functions *)

let read_lines filename =
  let chan = open_in filename in
  let lines = ref [] in
  try
    while true do
      lines := (input_line chan) :: !lines
    done;
    assert false
  with
  | End_of_file ->
      close_in_noerr chan;
      List.rev !lines

let write_lines lines filename =
  let chan = if filename = "-" then stdout else open_out filename in
  List.iter
    (fun line ->
      output_string chan line;
      output_char chan '\n')
    lines;
  if filename <> "-" then close_out_noerr chan


(* Parsing functions *)

let parse_file filename f =
  let channel = open_in filename in
  let lexbuf = Lexing.from_channel channel in
  try
    let res = f lexbuf in
    close_in_noerr channel;
    res
  with e ->
    close_in_noerr channel;
    raise e


(* XML functions *)

let xml_header = "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"

let escape_xml s =
  let buf = Buffer.create 128 in
  String.iter
    (function
      | '<' -> Buffer.add_string buf "&lt;"
      | '>' -> Buffer.add_string buf "&gt;"
      | '&' -> Buffer.add_string buf "&amp;"
      | '\'' -> Buffer.add_string buf "&apos;"
      | '\"' -> Buffer.add_string buf "&quot;"
      | ch -> Buffer.add_char buf ch)
    s;
  Buffer.contents buf

type xml_tree =
  { tag_name : string;
    tag_attributes : (string * string) list;
    tag_data : xml_data list; }
and xml_data =
  | Text of string
  | Data of string
  | Child of xml_tree

let string_of_xml_tree t =
  let buf = Buffer.create 1024 in
  let indent k =
    for _i = 1 to k do
      Buffer.add_string buf "  "; 
    done in
  let rec visit k x =
    indent k;
    Buffer.add_string buf "<";
    Buffer.add_string buf x.tag_name;
    List.iter
      (fun (k, v) ->
        Buffer.add_string buf (Printf.sprintf " %s=%S" k v))
      x.tag_attributes;
    (match x.tag_data with
    | [] -> Buffer.add_string buf "/>\n";
    | _ ->
        Buffer.add_string buf ">\n";
        List.iter
          (function
            | Text s ->
                if not (String.contains s '\n') then indent (succ k);
                Buffer.add_string buf (escape_xml s);
                Buffer.add_string buf "\n";
            | Data s ->
                if not (String.contains s '\n') then indent (succ k);
                Buffer.add_string buf s;
                Buffer.add_string buf "\n";
            | Child c ->
                visit (succ k) c)
          x.tag_data;
        indent k;
        Buffer.add_string buf "</";
        Buffer.add_string buf x.tag_name;
        Buffer.add_string buf ">\n") in
  visit 0 t;
  Buffer.contents buf


(* Binary format *)

let binary_magic_number = "MASCOT-REPORT"

let binary_current_version = (1, 0)
