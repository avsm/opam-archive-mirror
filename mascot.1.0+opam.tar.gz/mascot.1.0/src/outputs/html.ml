(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

let name = OutputName.make "html"

let css_style = [
  "table.report {" ;
  "  border-width: 1px;" ;
  "  border-style: none;" ;
  "  border-color: black;" ;
  "  border-collapse: collapse;" ;
  "  background-color: white;" ;
  "}" ;
  "table.report th {" ;
  "  border-width: 1px;" ;
  "  padding: 3px;" ;
  "  border-style: none;" ;
  "  border-color: black;" ;
  "}" ;
  "table.report td {" ;
  "  border-width: 1px;" ;
  "  padding: 3px;" ;
  "  border-style: none;" ;
  "  border-color: black;" ;
  "  text-align: left;";
  "  font-size: large;";
  "}" ;
  ".warning {";
  "  width: 16px;";
  "  height: 16px;";
  "  background: url(data:image/png;base64," ^ Images.warning ^ ");";
  "}";
  ".error {";
  "  width: 16px;";
  "  height: 16px;";
  "  background: url(data:image/png;base64," ^ Images.error ^ ");";
  "}";
  ".info {";
  "  width: 16px;";
  "  height: 16px;";
  "  background: url(data:image/png;base64," ^ Images.info ^ ");";
  "}";
  ".stats {";
  "  text-align: left;";
  "  background-color: gray;";
  "  font-weight: bold; font-family: \"helvetica\", sans-serif; font-size: large;";
  "}";
  ".file {";
  "  text-align: left;";
  "  background-color: lightgray;";
  "  font-weight: bold; font-family: \"helvetica\", sans-serif; font-size: large;";
  "}";
  ".element {";
  "  font-weight: normal;";
  "  font-family: helvetica, sans-serif;";
  "  font-size: small;";
  "}";
  ".bottom {";
  "  font-size: smaller;";
  "  text-align: center;";
  "}"
]

let run file _ report =
  let open Utils in
  let head =
    { tag_name = "head";
      tag_attributes = [];
      tag_data = [Child { tag_name = "title";
                          tag_attributes = [];
                          tag_data = [Text ("Mascot report / " ^ (current_time ()))]; };
                  Child { tag_name = "style";
                          tag_attributes = ["type", "text/css"];
                          tag_data = [Data (String.concat "\n" css_style)]; }]; } in
  let infos, warnings, errors = Report.statistics report in
  let plural x = if x > 1 then "s" else "" in
  let summary = Printf.sprintf "Summary: %d warning%s, %d error%s, and %d info%s"
      warnings (plural warnings)
      errors (plural errors)
      infos (plural infos) in
  let stats =
    { tag_name = "tr";
      tag_attributes = [];
      tag_data = [Child { tag_name = "td";
                          tag_attributes = ["colspan", "6";
                                            "class", "stats"];
                          tag_data = [Text summary]; }]; } in
  let lines =
    List.map
      (fun (file, report) ->
        let header =
          { tag_name = "tr";
            tag_attributes = [];
            tag_data = [Child { tag_name = "td";
                          tag_attributes = ["colspan", "6";
                                            "class", "file"];
                                tag_data = [Text file]; }]; } in
        let elements =
          Report.map
            (fun element ->
              let open Report in
              let style = ["class", "element"] in
              let kind = string_of_kind element.kind in
              let tag contents =
                Child { tag_name = "td";
                        tag_attributes = style;
                        tag_data = contents } in
              let tag' contents =
                Child { tag_name = "td";
                        tag_attributes = style;
                        tag_data = [Text contents] } in
              let tt contents =
                Child { tag_name = "tt";
                        tag_attributes = [];
                        tag_data = [Text contents] } in
              let img kind =
                Child { tag_name = "div";
                        tag_attributes = ["class", kind];
                        tag_data = [Text " "] } in
              let message =
                let max_length = 60 in
                if (String.length element.message) > max_length then
                  try
                    let idx = String.index_from element.message max_length ' ' in
                    let summary = String.sub element.message  0 idx in
                    tag [ Text summary;
                          Child { tag_name = "font";
                                  tag_attributes = ["title", element.message];
                                  tag_data = [ Text "..." ] } ]
                  with _ ->
                    tag' element.message
                else
                  tag' element.message in
              { tag_name = "tr";
                tag_attributes = [];
                tag_data = [(tag [img kind]);
                            (tag [tt (element.category :> string)]);
                            (tag [tt (element.check :> string)]);
                            (tag' ("line " ^ (string_of_int element.line)));
                            (tag' (match element.column with Some x -> "column " ^ (string_of_int x) | None -> ""));
                            message]; })
            report in
        let res = header :: elements in
        List.map (fun x -> Child x) res)
      (Report.split_by_file report) in
  let body =
    { tag_name = "body";
      tag_attributes = [];
      tag_data = [Child { tag_name = "center";
                          tag_attributes = [];
                          tag_data = [Child { tag_name = "table";
                                              tag_attributes = ["class", "report";
                                                                "width", "90%"];
                                              tag_data = (Child stats) :: (List.concat lines); }]; };
                  Child { tag_name = "p";
                          tag_attributes = ["class", "bottom"];
                          tag_data = [Text "Generated by ";
                                      Child { tag_name = "a";
                                              tag_attributes = ["href", "http://mascot.x9c.fr"];
                                              tag_data = [Text "Mascot ";
                                                          Text Version.value]; }]; }]; } in
  let tree =
    { tag_name = "html";
      tag_attributes = [];
      tag_data = [Child head; Child body]; } in
  write_lines [string_of_xml_tree tree] file
