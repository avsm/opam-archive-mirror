(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

let name = OutputName.make "jdepend"

let run file deps _ =
  let open Utils in
  let packages =
    { tag_name = "Packages";
      tag_attributes = [];
      tag_data = List.map
        (fun dep ->
          let modulename = String.capitalize (Filename.chop_extension (Filename.basename dep.Ocamldep.file)) in
          let used_by = List.filter (fun x -> List.mem modulename x.Ocamldep.modules) deps in
          let cc = 1 in
          let ac = 0 in
          let ca = List.length used_by in
          let ce = List.length dep.Ocamldep.modules in
          let a = (float ac) /. (float (cc + ac)) in
          let i = (float ce) /. (float (ce + ca)) in
          let d = (abs_float (a +. i -. 1.)) /. (sqrt 2.) in
          let int_child name x =
            Child { tag_name = name;
                    tag_attributes = [];
                    tag_data = [Text (string_of_int x)]; } in
          let float_child name x =
            Child { tag_name = name;
                    tag_attributes = [];
                    tag_data = [Text (Printf.sprintf "%.2f" x)]; } in
          let stats =
            { tag_name = "Stats";
              tag_attributes = [];
              tag_data = [int_child "TotalClasses" (cc + ac);
                          int_child "ConcreteClasses" cc;
                          int_child "AbstractClasses" ac;
                          int_child "Ca" ca;
                          int_child "Ce" ce;
                          float_child "A" a;
                          float_child "I" i;
                          float_child "D" d;
                          int_child "V" 1]; } in
          let abstract_classes =
            { tag_name = "AbstractClasses";
              tag_attributes = [];
              tag_data = []; } in
          let concrete_classes =
            { tag_name = "ConcreteClasses";
              tag_attributes = [];
              tag_data = [Child { tag_name = "Class";
                                  tag_attributes = ["sourceFile", dep.Ocamldep.file];
                                  tag_data = [Text modulename]; }]; } in
          let packages l =
            List.map
              (fun pkg -> 
                Child { tag_name = "Package";
                        tag_attributes = [];
                        tag_data = [Text pkg]; })
              l in
          let depends_upon =
            { tag_name = "DependsUpon";
              tag_attributes = [];
              tag_data = packages dep.Ocamldep.modules; } in
          let used_by =
            { tag_name = "UsedBy";
              tag_attributes = [];
              tag_data = packages (List.map (fun x -> x.Ocamldep.file) used_by); } in
          Child { tag_name = "Package";
                  tag_attributes = ["name", modulename];
                  tag_data = [Child stats;
                              Child abstract_classes;
                              Child concrete_classes;
                              Child depends_upon;
                              Child used_by]; })
        deps; } in
  let no_cycle =
    { tag_name = "Cycles";
      tag_attributes = [];
      tag_data = []; } in
  let tree =
    { tag_name = "JDepend";
      tag_attributes = [];
      tag_data = [Child packages; Child no_cycle]; } in
  write_lines [xml_header; string_of_xml_tree tree] file
