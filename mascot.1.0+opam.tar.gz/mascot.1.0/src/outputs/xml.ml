(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

let name = OutputName.make "xml"

let run file _ report =
  let open Utils in
  let tree =
    { tag_name = "mascot-report";
      tag_attributes = ["version", Version.value];
      tag_data = Report.map
        (fun element ->
          let open Report in
          let attrs =
            ["kind", string_of_kind element.kind;
             "category", (element.category :> string);
             "check", (element.check :> string);
             "file", element.filename;
             "line", string_of_int element.line]
            @ (match element.column with Some x -> ["column", string_of_int x] | None -> [])
            @ ["message", escape_xml element.message] in
          Child { tag_name = "entry";
                  tag_attributes = attrs;
                  tag_data = []; })
        report; } in
  write_lines [xml_header; string_of_xml_tree tree] file
