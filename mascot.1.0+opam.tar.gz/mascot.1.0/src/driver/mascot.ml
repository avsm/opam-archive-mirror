(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

let do_report reports ignore_list dependencies =
  let reports =
    List.map
      (MascotLibrary.Report.filter
         !MascotLibrary.Args.no_info
         !MascotLibrary.Args.no_warning
         !MascotLibrary.Args.no_error
         ignore_list)
      reports in
  let reports = MascotLibrary.Report.concat_list reports in
  List.iter
    (fun (o, s) ->
      if !s <> "" then
        let module O = (val o : MascotLibrary.Output.T) in
        Printf.printf "reporting to %S with output %S...\n" !s (O.name :> string);
        O.run !s dependencies reports)
    !MascotLibrary.Args.outputs

let get_ignore_list () =
    if !MascotLibrary.Args.ignore_file <> "" then
      MascotLibrary.Utils.parse_file
        !MascotLibrary.Args.ignore_file
        (MascotLibrary.IgnoreParser.file MascotLibrary.IgnoreLexer.token)
    else
      []

let main () =
  Printf.printf "loading configuration files...\n";
  let config =
    MascotLibrary.Utils.parse_file
      !MascotLibrary.Args.config_file
      (MascotLibrary.ConfigParser.file MascotLibrary.ConfigLexer.token) in
  let ignore_list = get_ignore_list () in

  Printf.printf "configuring checks...\n";
  let configured_checks =
    List.map
      (fun cat ->
        List.map
          (fun chk ->
            let elem = MascotLibrary.Args.find_check cat chk in
            match chk.MascotLibrary.Configuration.check_values with
            | Some cv -> 
                let params = MascotLibrary.Check.parameters elem in
                let params =
                  List.fold_left
                    (fun acc (id, vl) ->
                      match vl with
                      | MascotLibrary.Configuration.Bool_value bv ->
                          MascotLibrary.Parameter.set_bool id bv acc
                      | MascotLibrary.Configuration.Int_value iv ->
                          MascotLibrary.Parameter.set_int id iv acc
                      | MascotLibrary.Configuration.String_value sv ->
                          MascotLibrary.Parameter.set_string id sv acc
                      | MascotLibrary.Configuration.Symbol_value sv ->
                          MascotLibrary.Parameter.set_symbol id sv acc
                      | MascotLibrary.Configuration.Symbol_list_value slv ->
                          MascotLibrary.Parameter.set_symbol_list id slv acc)
                    params
                    cv in
                Some (MascotLibrary.State.next_id (), elem, params)
            | None -> None)
          cat.MascotLibrary.Configuration.category_checks)
      config in
  let configured_checks = List.flatten configured_checks in

  Printf.printf "analyzing dependencies...\n";
  let ml_files =
    List.filter
      (fun x -> Filename.check_suffix x ".ml")
      !MascotLibrary.Args.files in
  let dependencies =
    MascotLibrary.Ocamldep.analyse_files
      ~preprocessor:!MascotLibrary.Args.preprocessor
      (List.rev ml_files) in

  if !MascotLibrary.Args.syntax <> "" then begin
    Printf.printf "loading syntax %S...\n" !MascotLibrary.Args.preprocessor;
    if MascotLibrary.Camlp4Utils.is_revised_binary !MascotLibrary.Args.syntax then
      MascotLibrary.Camlp4Utils.use_original_syntax := false;
    let loader = Camlp4.Struct.DynLoader.mk () in
    List.iter
      (Camlp4.Struct.DynLoader.load loader)
      !MascotLibrary.Args.syntax_extensions;
    Camlp4.Register.iter_and_take_callbacks
      (fun (x, f) ->
        if not (List.mem x MascotLibrary.Camlp4Utils.predefined_modules) then
          f ())
  end;

  Printf.printf "running checks...\n";
  let reports =
    List.map
      (function
        | Some (id, chk, params) ->
            List.fold_left
              (fun acc elem ->
                try
                  let rep =
                    MascotLibrary.Check.do_run
                      id
                      !MascotLibrary.Args.disable_cache
                      (List.rev !MascotLibrary.Args.search_path)
                      dependencies
                      params
                      elem
                      chk in
                  MascotLibrary.Report.concat acc rep
                with e ->
                  let name = ((MascotLibrary.Check.name chk) :> string) in
                  Printf.eprintf "*** error while running check %S on file %S:\n" name elem;
                  Printf.eprintf "  %s\n" (Printexc.to_string e);
                  acc)
              MascotLibrary.Report.empty
              (List.rev !MascotLibrary.Args.files)
        | None -> MascotLibrary.Report.empty)
      configured_checks in

  (* reporting to activated outputs *)
  do_report reports ignore_list dependencies

let main_report_only () =
  let report =
    List.fold_left
      (fun acc elem ->
        let channel = open_in elem in
        let magic_length = String.length MascotLibrary.Utils.binary_magic_number in
        let file_magic = String.create magic_length in
        really_input channel file_magic 0 magic_length;
        if file_magic = MascotLibrary.Utils.binary_magic_number then begin
          let file_version : (int * int) = input_value channel in
          if file_version <> MascotLibrary.Utils.binary_current_version then begin
            Printf.eprintf "unsupported version for file %S\n" elem;
            exit 1
          end else begin
            let report : MascotLibrary.Report.t = input_value channel in
            MascotLibrary.Report.concat acc report
          end
        end else begin
          Printf.eprintf "invalid file %S\n" elem;
          exit 1
        end)
      MascotLibrary.Report.empty
      (List.rev !MascotLibrary.Args.files) in
  let ignore_list = get_ignore_list () in
  do_report [report] ignore_list []


let () =
  try
    MascotLibrary.Args.parse ();
    if !MascotLibrary.Args.report_only then
      main_report_only ()
    else
      main ();
    exit 0
  with
  | Sys_error se ->
      Printf.eprintf "*** system error: %s\n" se;
      exit 1
  | Dynlink.Error e ->
      Printf.eprintf "*** dynlink error: %s\n" (Dynlink.error_message e);
      exit 1
  | e ->
      Printf.eprintf "*** error: %s\n" (Printexc.to_string e);
      exit 1
