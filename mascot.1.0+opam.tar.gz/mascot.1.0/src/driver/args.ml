(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type error =
  | Invalid_output_name of string
  | No_configuration_file_specified
  | No_output_specified
  | No_file_specified
  | No_syntax_specified
  | Multiple_preprocessors
  | Duplicate_check of CategoryName.t * CheckName.t
  | Missing_check of CategoryName.t * CheckName.t

let string_of_error = function
  | Invalid_output_name id -> Printf.sprintf "Invalid output name %S" id
  | No_configuration_file_specified -> "no configuration file specified"
  | No_output_specified -> "no output specified"
  | No_file_specified -> "no file specified"
  | No_syntax_specified -> "no syntax specified"
  | Multiple_preprocessors -> "both camlp4 and non-camlp4 preprocessors specified"
  | Duplicate_check (cat, chk) -> Printf.sprintf "check '%s.%s' given twice" (cat :> string) (chk :> string)
  | Missing_check (cat, chk) -> Printf.sprintf "check '%s.%s' not found" (cat :> string) (chk :> string)

exception Exception of error

let () =
  Printexc.register_printer
    (function
      | Exception error -> Some (string_of_error error)
      | _ -> None)

let fail error =
  raise (Exception error)

module CategoryMap = Map.Make (struct type t = CategoryName.t let compare = Pervasives.compare end)

let config_file = ref ""

let ignore_file = ref ""

let parameters = ref []

let no_warning = ref false

let no_error = ref false

let no_info = ref false

let disable_cache = ref false

let syntax = ref ""

let syntax_extensions = ref []

let preprocessor = ref ""

let search_path = ref ["."]

let report_only = ref false

let outputs = ref []

let checks = ref CategoryMap.empty

let files = ref []

let add_file file =
  files := file :: !files

let add_parameter param =
  parameters := param :: !parameters

let already_seen = ref []

let find_check cat chk =
  let category_name = cat.Configuration.category_name in
  try
    let l = CategoryMap.find category_name !checks in
    List.find
      (fun c ->
        let res = chk.Configuration.check_name = Check.name c in
        if res && not (Check.multiple c) then begin
          if (List.mem (category_name, chk.Configuration.check_name) !already_seen) then
            fail (Duplicate_check (category_name, chk.Configuration.check_name))
          else
            already_seen := (category_name, chk.Configuration.check_name) :: !already_seen
        end;
        res)
      l
  with Not_found ->
    fail (Missing_check (category_name, chk.Configuration.check_name))

let print_parameters () =
  CategoryMap.iter
    (fun cat l ->
      List.iter
        (fun c ->
          let name = (cat : CategoryName.t :> string) ^ "." ^ ((Check.name c) :> string) in
          if List.mem name !parameters then begin
            Printf.printf "parameters for check '%s':\n" name;
            Parameter.iter
              (fun ident typename def doc ->
                Printf.printf "  - %s (%s defaulting to %s): %s\n"
                  (ident : ParameterName.t :> string)
                  typename
                  def
                  doc)
              (Check.parameters c)
          end)
        l)
    !checks;
  if !parameters <> [] then exit 0

let print_available () =
  CategoryMap.iter
    (fun cat l ->
      Printf.printf "category '%s':\n" (cat : CategoryName.t :> string);
      List.iter
        (fun c ->
          Printf.printf "  - %s: %s\n" ((Check.name c) :> string) (Check.description c))
        l)
    !checks;
  exit 0

let print_default_config () =
  CategoryMap.iter
    (fun cat l ->
      Printf.printf "category %s {\n" (cat : CategoryName.t :> string);
      List.iter
        (fun c ->
          let check_name = ((Check.name c) :> string) in
          let check_desc = Check.description c in
          Printf.printf "  (* %s: %s. *)\n" check_name check_desc;
          let params = Check.parameters c in
          let params =
            if Parameter.size params > 0 then begin
              let buff = Buffer.create 128 in
              Buffer.add_string buff "{\n";
              Parameter.iter
                (fun n _ v d ->
                  let n = (n : ParameterName.t :> string) in
                  Buffer.add_string buff "    ";
                  Buffer.add_string buff n;
                  Buffer.add_string buff " = ";
                  Buffer.add_string buff v;
                  Buffer.add_string buff "; (* ";
                  Buffer.add_string buff d;
                  Buffer.add_string buff ". *)\n")
                params;
              Buffer.add_string buff "  }";
              Buffer.contents buff
            end else
              "true" in
          Printf.printf "  %s = %s;\n\n" check_name params)
        l;
      Printf.printf "}\n\n\n")
    !checks;
  exit 0

let print_version () =
  print_endline Version.value;
  exit 0

let usage =
  Printf.sprintf "Usage: %s [options] [files]\nOptions are:"
    (Filename.basename Sys.argv.(0))

let switches =
  [ ("-config", Arg.Set_string config_file, "<file>  Set configuration file");
    ("-default-config", Arg.Unit print_default_config, " Print default configuration");
    ("-ignore", Arg.Set_string ignore_file, "<file>  Set ignore file");
    ("-plugin", Arg.String ignore, "<file>  Load plugin");
    ("-available", Arg.Unit print_available, " Print available checks");
    ("-parameters", Arg.String add_parameter, "<category.check>  Print check parameters");
    ("-no-warning", Arg.Set no_warning, " Disable report of warnings");
    ("-no-error", Arg.Set no_error, " Disable report of errors");
    ("-no-info", Arg.Set no_info, " Disable report of infos");
    ("-disable-cache", Arg.Set disable_cache, " Disable cache");
    ("-syntax",
     Arg.Symbol (Camlp4Utils.binary_names, (fun s -> syntax := s)),
     "  Set camlp4 preprocessor");
    ("-syntax-extension",
     Arg.String (fun s -> syntax_extensions := s :: !syntax_extensions),
     "<file>  Dynamically load camlp4 syntax extension");
    ("-preprocessor", Arg.Set_string preprocessor, "<command>  Set non-camlp4 preprocessor");
    ("-I",
     Arg.String (fun s -> search_path := s :: !search_path),
     "<path>  Add to search path");
    ("-report-only", Arg.Set report_only, " Build report from binary files (no analysis)");
    ("-version", Arg.Unit print_version, " Print version and exit") ]

let parse () =
  (* first, load plugins as they may add command-line switches *)
  let len = Array.length Sys.argv in
  let idx = ref 1 in
  while (!idx + 1 < len) do
    if Sys.argv.(!idx) = "-plugin" then begin
      Plugin.load Sys.argv.(succ !idx);
      idx := !idx + 2
    end else
      idx := !idx + 1
  done;
  (* second, build the  list of checks *)
  checks :=
    List.fold_left
      (fun acc elem ->
        let category = Check.category elem in
        let list = try CategoryMap.find category acc with Not_found -> [] in
        CategoryMap.add category (elem :: list) acc)
      CategoryMap.empty 
      (Predefined.checks @ (Plugin.get_checks ()));
  checks :=
    CategoryMap.map
      (fun l ->
        List.sort
          (fun c1 c2 ->
            Pervasives.compare (Check.name c1) (Check.name c2))
          l)
      !checks;
  (* third, build the complete list of command-line switches *)
  outputs := List.map (fun o -> o, ref "") (Predefined.outputs @ (Plugin.get_outputs ()));
  let switches =
    switches
    @ (List.map
         (fun (o, s) ->
           let module O = (val o : Output.T) in
           let name = "-" ^ (O.name :> string) in
           let switch_with_same_name (x, _, _) = x = (name :> string) in
           if List.exists switch_with_same_name switches then fail (Invalid_output_name (O.name :> string));
           (name, Arg.Set_string s, "<file>  Output report to " ^ (O.name :> string) ^ " format"))
         !outputs) in
  let switches = List.sort Pervasives.compare switches in
  (* finally, parse the command-line and enforce sanity checks *)
  Arg.parse switches add_file usage;
  print_parameters ();
  let no_output = List.for_all (fun (_, s) -> !s = "") !outputs in
  if (!syntax = "") && (!syntax_extensions <> []) then
    fail No_syntax_specified;
  if (!syntax <> "") && (!preprocessor <> "") then
    fail Multiple_preprocessors;
  if (!syntax <> "") then
    preprocessor := !syntax ^ " " ^ (String.concat " " (List.rev !syntax_extensions));
  if !config_file = "" && (not !report_only) then fail No_configuration_file_specified;
  if no_output then fail No_output_specified;
  if !files = [] then fail No_file_specified
