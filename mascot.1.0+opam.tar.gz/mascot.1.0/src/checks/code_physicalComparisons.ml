(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.structure

let category = CategoryName.code

let name = CheckName.make "physical_comparisons"

let multiple = false

let description = "detects physical comparisons"

let documentation =
  "This check detects the use of either '==' or '!='."

let rationale =
  "Novices coming from a C/C++/Java background often use them for a comparison " ^
  "that should be done through either '=' or '<>'."

let limits =
  "If any of the comparison operators has been redefined, the check will yield " ^
  "false positives. Moreover, in some contexts, it is perfectly legitimate to use " ^
  "physical comparisons."

let parameters = Parameter.empty_map

class check error = object

  inherit Camlp4.PreCast.Ast.map as super

  method! private expr expr =
    let open Camlp4.PreCast in
    let expr = super#expr expr in
    match expr with
    | <:expr< $_$ == $_$ >>
    | <:expr< $_$ != $_$ >> ->
        let loc = Ast.loc_of_expr expr in
        let line, column = Camlp4Utils.line_and_column_of_location loc in
        let msg = Printf.sprintf "physical comparison" in
        error line column msg;
        expr
    | _ -> expr

end

let run _ _ ast _ report =
  let inst = new check report.Check.error in
  ignore (inst#str_item ast)
