(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.lines

let category = CategoryName.code

let name = CheckName.make "textual_duplicate"

let multiple = false

let description = "textual duplicates"

let documentation =
  "Checks for the presence of duplicated text."

let rationale =
  "Duplicated text is often due to a copy/paste operation, and if possible " ^
  "should lead to code factorization."

let limits =
  "Being based on text, the check will not identify almost-identical code " ^
  "that differs only in terms of whitespaces or identifiers names."

let parameters, window, offset, trim_lines = Parameter.make3
    (Parameter.int
       (ParameterName.make "window",
        "minimum size of duplicates",
        10,
        Parameter.strictly_positive))
    (Parameter.int
       (ParameterName.make "offset",
        "number of lines to ignore at file start",
        0,
        Parameter.positive))
    (Parameter.bool
       (ParameterName.make "trim_lines",
        "whether to remove leading and trailing whitespaces",
        false,
        Parameter.any))

type snippet = {
    file : string;
    start : int;
    contents : string array;
}

let get_state, _ =
  State.init
    (fun () ->
      (Hashtbl.create 1789 : (int, snippet list) Hashtbl.t))

(* freely inspired by the Robin-Karp multiple pattern search algorithm *)
let run id _ (_, lines) parameters report =
  let window = window parameters in
  let offset = offset parameters in
  let trim_lines = trim_lines parameters in
  let state = get_state id in
  let lines = Array.of_list (List.map snd lines) in
  let len = Array.length lines in
  let check_and_add ofs hash =
    let extract = Array.sub lines ofs window in
    let candidates =
      try
        Hashtbl.find state hash
      with Not_found -> [] in
    let duplicates =
      List.filter
        (fun s -> s.contents = extract)
        candidates in
    (match duplicates with
    | hd :: tl ->
        let len = List.length tl in
        let tl =
          if len > 0 then
            Printf.sprintf ", and %d other place%s"
              len
              (if len > 1 then "s" else "")
          else
            "" in
        let msg =
          Printf.sprintf "code duplicate (%d lines from file '%s' starting at line %d%s)"
            window
            hd.file
            hd.start
            tl in
        report.Check.error (succ ofs) None msg
    | [] -> ());
    Hashtbl.replace
      state
      hash
      ({ file = report.Check.filename;
         start = succ ofs;
         contents = extract; } :: candidates) in
  if trim_lines then begin
    for i = 0 to pred len do
      lines.(i) <- Utils.trim lines.(i)
    done
  end;
  if (offset <= len - window) then begin
    let hash, rh =
      RollingHash.make
        Utils.string_hash
        (Array.sub lines offset window) in
    check_and_add offset hash;
    for i = succ offset to len - window do
      let hash = RollingHash.update rh lines.(i + window - 1) in
      check_and_add i hash;
    done
  end
