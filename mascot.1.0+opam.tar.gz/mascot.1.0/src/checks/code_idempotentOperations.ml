(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.structure

let category = CategoryName.code

let name = CheckName.make "idempotent_operations"

let multiple = false

let description = "detects some idempotent operations"

let documentation =
  "This check detects some idempotent operations over 'int' and 'float' types."

let rationale =
  "Obviously idempotent operations are often the hint of a mistake (e. g. use " ^
  "of the digit '0' instead of the letter 'o')."

let limits =
  "If a predefined operator is redefined, its associated set of idempotent " ^
  "operations may not be the same."

let parameters = Parameter.empty_map

class check error = object

  inherit Camlp4.PreCast.Ast.map as super

  method! private expr expr =
    let open Camlp4.PreCast in
    let expr = super#expr expr in
    match expr with
    | <:expr< $_$ + 0 >> | <:expr< 0 + $_$ >>
    | <:expr< $_$ * 1 >> | <:expr< 1 * $_$ >>
    | <:expr< $_$ - 0 >>
    | <:expr< $_$ / 1 >>
    | <:expr< $_$ +. 0. >> | <:expr< 0. + $_$ >>
    | <:expr< $_$ *. 1. >> | <:expr< 1. *. $_$ >>
    | <:expr< $_$ -. 0. >>
    | <:expr< $_$ /. 1. >> ->
        let loc = Ast.loc_of_expr expr in
        let line, column = Camlp4Utils.line_and_column_of_location loc in
        let msg = Printf.sprintf "idempotent operation" in
        error line column msg;
        expr
    | _ -> expr

end

let run _ _ ast _ report =
  let inst = new check report.Check.error in
  ignore (inst#str_item ast)
