(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.annotations

let category = CategoryName.code

let name = CheckName.make "deprecated"

let multiple = false

let description = "deprecated elements"

let documentation =
  "Detects use of deprecated elements."

let rationale =
  "One should not rely on the elements marked as deprecated in the official " ^
  "library."

let limits =
  "Does not check for deprecated elements outside of the official library."

let parameters = Parameter.empty_map

let stdlib = [
  "Array.create";
  "Array.create_matrix";
  "ArrayLabels.create";
  "ArrayLabels.create_matrix";
  "Filename.temp_dir_name";
  "Format.bprintf";
  "Format.kprintf";
  "Int32.format";
  "Int64.format";
  "Lazy.lazy_from_fun";
  "Lazy.lazy_from_val";
  "Lazy.lazy_is_val";
  "Nativeint.format";
  "Obj.final_tag";
  "Obj.marshal";
  "Obj.unmarshal";
  "Pervasives.( & )";
  "Pervasives.( or )";
  "Pervasives.or";
  "Printexc.catch";
  "Printf.kprintf";
  "Scanf.stdlib";
  "Sort.list";
  "Sort.array";
  "Sort.merge"
]

let otherlibs = [
  "Dynlink.add_interfaces";
  "Dynlink.add_available_units";
  "Dynlink.clear_available_units";
  "Dynlink.init";
  "ThreadUnix.execv";
  "ThreadUnix.execve";
  "ThreadUnix.execvp";
  "ThreadUnix.wait";
  "ThreadUnix.waitpid";
  "ThreadUnix.system";
  "ThreadUnix.read";
  "ThreadUnix.write";
  "ThreadUnix.single_write";
  "ThreadUnix.timed_read";
  "ThreadUnix.timed_write";
  "ThreadUnix.select";
  "ThreadUnix.pipe";
  "ThreadUnix.open_process_in";
  "ThreadUnix.open_process_out";
  "ThreadUnix.open_process";
  "ThreadUnix.sleep";
  "ThreadUnix.socket";
  "ThreadUnix.socketpair";
  "ThreadUnix.accept";
  "ThreadUnix.connect";
  "ThreadUnix.recv";
  "ThreadUnix.recvfrom";
  "ThreadUnix.send";
  "ThreadUnix.sendto";
  "ThreadUnix.open_connection";
  "ThreadUnix.establish_server";
  "Unix.SO_ERROR";
]

let run _ _ annotations _ report =
  let open Annotation in
  List.iter
    (fun block ->
      List.iter
        (function
          | Ident (External_reference, id) ->
              if (List.mem id stdlib) || (List.mem id otherlibs) then
                let line = block.range_start.line in
                let column = block.range_start.offset - block.range_start.line_offset + 1 in
                let msg = Printf.sprintf "element %s is deprecated" id in
                report.Check.error line (Some column) msg
          | _ -> ())
        block.elements)
    annotations
