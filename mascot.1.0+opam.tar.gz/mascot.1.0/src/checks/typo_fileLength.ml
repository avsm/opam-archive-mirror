(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.lines

let category = CategoryName.typography

let name = CheckName.make "file_length"

let multiple = false

let description = "long files"

let documentation =
  "Checks for the presence of long files."

let rationale =
  "Long files are difficult to read and master. They are also the hint that " ^
  "related modules should be refactored into smaller and more maintainable units."

let limits =
  ""

let parameters, maximum =
  Parameter.make1
    (Parameter.int (ParameterName.make "maximum",
                    "maximum file length",
                    500,
                    Parameter.strictly_positive))

let run _ _ (_, lines) parameters report =
  let maximum = maximum parameters in
  let len = List.length lines in
  if len > maximum then
    let msg = Printf.sprintf "file is too long (%d instead of %d)" len maximum in
    report.Check.error len None msg
