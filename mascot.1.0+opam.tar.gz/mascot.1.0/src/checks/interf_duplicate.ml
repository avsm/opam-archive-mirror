(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.signature

let category = CategoryName.interface

let name = CheckName.make "duplicate"

let multiple = false

let description = "detect duplicate entries in signatures"

let documentation =
  "Checks for the duplicates in signatures, that is ones that export "
  ^ "elements with the same name."

let rationale =
  "Signatures may indeed not contain duplicate, keeping only the last "
  ^ "of elements sharing the same name."

let limits =
  ""

let parameters = Parameter.empty_map

module StringSet = Set.Make (String)

class check error = object (self)

  inherit Camlp4.PreCast.Ast.fold as super

  method private item seen_values seen_exceptions si =
    let open Camlp4.PreCast.Ast in
    match si with
    | SgSem (_, si1, si2) ->
        let seen_values, seen_exceptions =
          self#item seen_values seen_exceptions si1 in
        self#item seen_values seen_exceptions si2
    | SgExc (loc, TyId (_, IdUid (_, name)))
    | SgExc (loc, TyOf (_, TyId (_, IdUid (_, name)), _)) ->
        if StringSet.mem name seen_exceptions then begin
          let line, column = Camlp4Utils.line_and_column_of_location loc in
          let msg = Printf.sprintf "exception %S is exported twice" name in
          error line column msg
        end;
        seen_values, StringSet.add name seen_exceptions
    | SgExt (loc, name, _, _)
    | SgVal (loc, name, _) ->
        if StringSet.mem name seen_values then begin
          let line, column = Camlp4Utils.line_and_column_of_location loc in
          let msg = Printf.sprintf "value %S is exported twice" name in
          error line column msg
        end;
        StringSet.add name seen_values, seen_exceptions
    | _ ->
        (* we do not check for other duplicates,
           because the compiler fails on them. *)
        seen_values, seen_exceptions

  method! sig_item si =
    ignore (self#item StringSet.empty StringSet.empty si);
    super#sig_item si

end

let run _ _ ast _ report =
  let inst = new check report.Check.error in
  ignore (inst#sig_item ast)
