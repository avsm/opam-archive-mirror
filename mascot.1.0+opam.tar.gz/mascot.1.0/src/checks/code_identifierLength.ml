(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.structure

let category = CategoryName.code

let name = CheckName.make "identifier_length"

let multiple = false

let description = "identifiers that are too short"

let documentation =
  "Checks that every identifier has a minimum length."

let rationale =
  "Short names often implies that code is harder to read and apprehend, because " ^
  "one has to refer to its binding to remember its exact meaning."

let limits =
  "In some context, a given letter has a very precise meaning that make a " ^
  "longer identifier useless (if not cluttering). Moreover, in very short " ^
  "function it is not always necessary to use long names for parameters."

let parameters, minimum, exclude_common = Parameter.make2
    (Parameter.int
       (ParameterName.make "minimum",
        "minimum identifier length",
        2,
        Parameter.strictly_positive))
    (Parameter.bool
       (ParameterName.make "exclude_common",
        "exclude common names from check",
        true,
        Parameter.any))

let common_names = ["f"; "g"; "h"; "i"; "j"; "k"; "l"; "x"; "y"; "z"; "s"; "t"; "M"; "T"]

let starts_with_letter_or_underscore s =
  (String.length s > 0)
    &&
  (match s.[0] with
  | 'a'..'z'
  | 'A'..'Z'
  | '_' -> true
  | _ -> false)

class check minimum exclude_common error = object (self)

  inherit Camlp4.PreCast.Ast.fold as super

  method private check loc s =
    if String.length s < minimum then begin
      if (not (exclude_common && (List.mem s common_names)))
          && (starts_with_letter_or_underscore s) then
        let line, column = Camlp4Utils.line_and_column_of_location loc in
        let msg = Printf.sprintf "name %S is too short (minimum size is %d)" s minimum in 
        error line column msg
    end

  method! binding binding =
    let open Camlp4.PreCast.Ast in
    (match binding with
    | BiEq (loc, p, _) ->
        let rec chk = function
          | PaId (_, id) ->
              let id = Camlp4Utils.string_of_ident id in
              self#check loc id
          | PaCom (_, p1, p2) ->
              chk p1;
              chk p2
          | PaTup (_, p) ->
              chk p
          | PaTyc (_, p, _) ->
              chk p
          | _ -> () in
        chk p
    | _ -> ());
    ignore (super#binding binding);
    self

  method! module_binding module_binding =
    let open Camlp4.PreCast.Ast in
    (match module_binding with
    | MbColEq (loc, id, _, _)
    | MbCol (loc, id, _) ->
        self#check loc id
    | _ -> ());
    ignore (super#module_binding module_binding);
    self

  method! str_item str_item =
    let open Camlp4.PreCast.Ast in
    (match str_item with
    | StMod (loc, id, _)
    | StMty (loc, id, _) ->
        self#check loc id
    | _ -> ());
    ignore (super#str_item str_item);
    self

end

let run _ _ ast parameters report =
  let minimum = minimum parameters in
  let exclude_common = exclude_common parameters in
  let inst = new check minimum exclude_common report.Check.error in
  ignore (inst#str_item ast)
