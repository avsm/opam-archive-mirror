(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.structure

let category = CategoryName.code

let name = CheckName.make "open"

let multiple = false

let description = "open statements"

let documentation =
  "Disallow the presence of open statements."

let rationale =
  "Open statements make source code difficult to read, because it is harder " ^
  "to know where a given name is bound."

let limits =
  "Disallowing open statements lead to longer code because every external " ^
  "reference has to be qualified."

let parameters, allowed_modules = Parameter.make1
    (Parameter.symbol_list
       (ParameterName.make "allowed_modules",
        "modules allowed in open statements",
        [],
        Parameter.any))

class check allowed_modules error = object (self)

  inherit Camlp4.PreCast.Ast.fold as super

  method! str_item x =
    let open Camlp4.PreCast.Ast in
    (match x with
    | StOpn (loc, id) ->
        let id = Camlp4Utils.string_of_ident id in
        if not (List.mem id allowed_modules) then begin
          let line, column = Camlp4Utils.line_and_column_of_location loc in
          error line column "illegal 'open' statement"
        end
    | _ -> ());
    ignore (super#str_item x);
    self

end

let run _ _ ast parameters report =
  let allowed_modules = allowed_modules parameters in
  let inst = new check allowed_modules report.Check.error in
  ignore (inst#str_item ast)
