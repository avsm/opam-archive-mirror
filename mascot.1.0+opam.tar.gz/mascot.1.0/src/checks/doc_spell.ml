(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.ocamldoc

let category = CategoryName.documentation

let name = CheckName.make "spell"

let multiple = false

let description = "spell-check the text of ocamldoc comments"

let documentation =
  "Spell-checks the text of ocamldoc comments through an external " ^
  "aspell-compatible spell-checking engine. When a mistake is reported, " ^
  "suggestions may also be proposed in order to facilitate correction."

let rationale =
  "Documentation is the entry-point of library users and/or code base " ^
  "committers, and it is annoying to leave some typos undetected. Moreover, " ^
  "users may feel uncomfortable to report such errors because they appear " ^
  "insignificant while correcting them clearly enhance the codebase quality."

let limits =
  "Some common abbreviations, or even full words may be too specific to " ^
  "appear in the common dictionary. This will require the user to either " ^
  "extend an existing dictionary, or to create a new one."

let parameters, path, dictionary =
  Parameter.make2
    (Parameter.string (ParameterName.make "path",
                       "path to aspell-compatible executable",
                       "aspell",
                       Parameter.any))
    (Parameter.string (ParameterName.make "dictionary",
                       "dictionary identifier",
                       "en",
                       Parameter.any))

class check path dict error = object (self)

  inherit Odoc_info.Scan.scanner as super

  method private spell_string loc x =
    let mistakes = Aspell.analyse_lines ~path:path ~dictionary:dict [x] in
      List.iter
        (fun mistake ->
          let word = Printf.sprintf "unknown word '%s'" mistake.Aspell.word in
          let suggestions =
            if mistake.Aspell.suggestions <> [] then
              ", suggestions: " ^ (String.concat ", " mistake.Aspell.suggestions)
            else
              "" in
          let line, column = OcamldocUtils.line_and_column_of_location loc.Odoc_info.loc_inter in
          error line column (word ^ suggestions))
        mistakes

  method private spell_info loc x =
    let text = OcamldocUtils.string_of_info_option x in
    self#spell_string loc text

  method private spell_text_option loc x =
    match x with
    | Some y ->
        let text = OcamldocUtils.string_of_text y in
        self#spell_string loc text
    | None -> ()

  method! scan_value x =
    let open Odoc_info.Value in
    self#spell_info x.val_loc x.val_info;
    let rec f y =
      let open Odoc_info.Parameter in
      match y with
      | Simple_name z -> self#spell_text_option x.val_loc z.sn_text
      | Tuple (l, _) -> List.iter f l in
    List.iter f x.Odoc_info.Value.val_parameters;
    super#scan_value x

  method! scan_type x =
    let open Odoc_info.Type in
    self#spell_info x.ty_loc x.ty_info;
    (match x.ty_kind with
    | Type_abstract -> ()
    | Type_variant l ->
        List.iter
          (fun y ->
            self#spell_text_option x.ty_loc y.vc_text)
          l
    | Type_record l ->
        List.iter
          (fun y ->
            self#spell_text_option x.ty_loc y.rf_text)
          l);
    super#scan_type x

  method! scan_exception x =
    let open Odoc_info.Exception in
    self#spell_info x.ex_loc x.ex_info;
    super#scan_exception x

  method! scan_attribute x =
    let open Odoc_info.Value in
    self#scan_value x.att_value;
    super#scan_attribute x

  method! scan_method x =
    let open Odoc_info.Value in
    self#scan_value x.met_value;
    super#scan_method x

  method! scan_included_module x =
    let open Odoc_info.Module in
    self#spell_info Odoc_info.dummy_loc x.im_info;
    super#scan_included_module x

  method! scan_class_pre _ =
    true

  method! scan_class_elements x =
    let open Odoc_info.Class in
    self#spell_info x.cl_loc x.cl_info;
    super#scan_class_elements x

  method! scan_class_type_pre _ =
    true

  method! scan_class_type_elements x =
    let open Odoc_info.Class in
    self#spell_info x.clt_loc x.clt_info;
    super#scan_class_type_elements x

  method! scan_module_pre _ =
    true

  method! scan_module_elements x =
    let open Odoc_info.Module in
    self#spell_info x.m_loc x.m_info;
    super#scan_module_elements x

  method! scan_module_type_pre _ =
    true

  method! scan_module_type_elements x =
    let open Odoc_info.Module in
    self#spell_info x.mt_loc x.mt_info;
    super#scan_module_type_elements x

end

let run _ _ modul parameters report =
  let path = path parameters in
  let dictionary = dictionary parameters in
  let inst = new check path dictionary report.Check.error in
  inst#scan_module_list [modul]
