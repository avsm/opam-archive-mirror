(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.signature

let category = CategoryName.interface

let name = CheckName.make "method_count"

let multiple = false

let description = "presence of complex classes"

let documentation =
  "Checks for the presence of complex classes, that is ones that define " ^
  "too many elements."

let rationale =
  "Classes with many elements are difficult to apprehend and are an hint " ^
  "that some refactoring should be performed in order to build smaller classes."

let limits =
  ""

let parameters, maximum =
  Parameter.make1
    (Parameter.int (ParameterName.make "maximum",
                    "maximum class elements",
                    32,
                    Parameter.strictly_positive))

class check maximum error = object (self)

  inherit Camlp4.PreCast.Ast.fold

  method! class_sig_item class_sig_item =
    let open Camlp4.PreCast.Ast in
    let elems = list_of_class_sig_item class_sig_item [] in
    let len = List.length elems in
    if len > maximum then begin
      let msg = Printf.sprintf "classes defines %d elements (insted of %d)" len maximum in
      let loc = loc_of_class_sig_item class_sig_item in
      let line, column = Camlp4Utils.line_and_column_of_location loc in
      error line column msg
    end;
    self

end

let run _ _ ast parameters report =
  let maximum = maximum parameters in
  let inst = new check maximum report.Check.error in
  ignore (inst#sig_item ast)
