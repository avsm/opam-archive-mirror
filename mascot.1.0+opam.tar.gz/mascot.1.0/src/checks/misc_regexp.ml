(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.lines

let category = CategoryName.miscellaneous

let name = CheckName.make "regexp"

let multiple = true

let description = "regular expression matching"

let documentation =
  "Checks whether a line partially matches a given regular expression."

let rationale =
  "A limited but flexible check allowing to look for various potential " ^
  "mistakes, or discouraged practices."

let limits =
  "Matching is limited to individual lines, meaning that it is impossible " ^
  "to match regular expressions spanning multiple lines."

let parameters, expr, case_sensitive, threshold, level = Parameter.make4
    (Parameter.string
       (ParameterName.make "expr",
        "regular expression to match",
        "",
        Parameter.any))
    (Parameter.bool
       (ParameterName.make "case_sensitive",
        "whether regular expression matching is case sensitive",
        true,
        Parameter.any))
    (Parameter.int
       (ParameterName.make "threshold",
        "threshold (number of line matches) for report",
        0,
        Parameter.positive))
    (Parameter.symbol
       (ParameterName.make "level",
        "report level ('info', 'warning', or 'error')",
        "error",
        Parameter.level_symbol))

let run _ _ (_, lines) parameters report =
  let case_sensitive = case_sensitive parameters in
  let expr = expr parameters in
  let threshold = threshold parameters in
  let level = level parameters in
  let report =
    match level with
    | "info" -> report.Check.info
    | "warning" -> report.Check.warning
    | "error" -> report.Check.error
    | _ -> assert false in
  if expr <> "" then begin
    let msg = Printf.sprintf "line matches regexp %S" expr in
    let expr = if case_sensitive then Str.regexp expr else Str.regexp_case_fold expr in
    let count = ref 0 in
    List.iter
      (fun (no, line) ->
        try
          ignore (Str.search_forward expr line 0);
          incr count;
          if !count > threshold then report no None msg
        with Not_found -> ())
      lines
  end
