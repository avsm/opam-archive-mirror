(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.structure

let category = CategoryName.metrics

let name = CheckName.make "halstead"

let multiple = false

let description = "Halstead complexity"

let documentation =
  "Computes the Halstead complexity of expressions."

let rationale =
  "The Halstead metric allows to identify functions that are too complex to " ^
  "understand, and thus to maintain."

let limits =
  "As any metric, the Halstead complexity only gives bare hints about whether an " ^
  "expression should be decomposed into smaller elements."

let parameters = Parameter.empty_map

module StringSet = Set.Make (struct type t = string let compare = Pervasives.compare end)

let set () = 0, StringSet.empty

let add (c, s) x =
  succ c, StringSet.add x s

class check info = object (self)

  inherit Camlp4.PreCast.Ast.fold

  method private ct operators operands c =
    let open Camlp4.PreCast.Ast in
    match c with
    | TyNil _ -> operators, operands
    | TyAny _ -> operators, (add operands "_")

    | TyQuo (_, _) -> operators, operands
    | TyAnP _
    | TyQuP (_, _) -> operators, (add operands "+")
    | TyAnM _
    | TyQuM (_, _) -> operators, (add operands "-")
    | TyVrn (_, _) -> operators, operands
    | TyAnt (_, _) -> operators, operands

    | TyCls (_, i) -> operators, (add operands (Camlp4Utils.string_of_ident i))
    | TyId (_, i) -> operators, (add operands (Camlp4Utils.string_of_ident i))

    | TyLab (_, s, c)
    | TyOlb (_, s, c) -> self#ct operators (add operands s) c

    | TyObj (_, c, _)
    | TyRec (_, c)
    | TySum (_, c)
    | TyTup (_, c)
    | TyVrnEq (_, c)
    | TyVrnSup (_, c)
    | TyVrnInf (_, c) -> self#ct operators operands c

    | TyPrv (_, c) -> self#ct (add operators "private") operands c
    | TyMut (_, c) -> self#ct (add operators "mutable") operands c

    | TyApp (_, c1, c2)
    | TyPol (_, c1, c2)
    | TyTypePol (_, c1, c2)
    | TyCol (_, c1, c2)
    | TySem (_, c1, c2)
    | TyCom (_, c1, c2)
    | TyOr  (_, c1, c2)
    | TySta (_, c1, c2)
    | TyVrnInfSup (_, c1, c2) ->
        let operators, operands = self#ct operators operands c1 in
        self#ct operators operands c2

    | TyOf (_, c1, c2) ->
        let operators, operands = self#ct (add operators "of") operands c1 in
        self#ct operators operands c2
    | TyAnd (_, c1, c2) ->
        let operators, operands = self#ct (add operators "nad") operands c1 in
        self#ct operators operands c2
    | TyArr (_, c1, c2) ->
        let operators, operands = self#ct (add operators "->") operands c1 in
        self#ct operators operands c2
    | TyMan (_, c1, c2) ->
        let operators, operands = self#ct (add operators "==") operands c1 in
        self#ct operators operands c2
    | TyAli (_, c1, c2) ->
        let operators, operands = self#ct (add operators "as") operands c1 in
        self#ct operators operands c2
    | TyAmp (_, c1, c2) ->
        let operators, operands = self#ct (add operators "&") operands c1 in
        self#ct operators operands c2
    | TyOfAmp (_, c1, c2) ->
        let operators, operands = self#ct (add (add operators "&") "of") operands c1 in
        self#ct operators operands c2

    | TyDcl (_, s, l1, c, l2) ->
        let operators, operands = self#ct (add operators s) operands c in
        let operators, operands = 
          List.fold_left
            (fun (operators, operands) c -> self#ct operators operands c)
            (operators, operands)
            l1 in
        List.fold_left
          (fun (operators, operands) (c1, c2) ->
            let operators, operands = self#ct operators operands c1 in
            self#ct operators operands c2)
          (operators, operands)
          l2
    | TyPkg _ -> operators, operands

  method private pat operators operands p =
    let open Camlp4.PreCast.Ast in
    match p with
    | PaNil _ -> operators, operands
    | PaAny _ -> operators, (add operands "_")

    | PaAnt (_, s)
    | PaChr (_, s)
    | PaInt (_, s)
    | PaInt32 (_, s)
    | PaInt64 (_, s)
    | PaNativeInt (_, s)
    | PaFlo (_, s)
    | PaStr (_, s)
    | PaVrn (_, s) ->
        operators, add operands s

    | PaId (_, i)
    | PaTyp (_, i) ->
        operators, add operands (Camlp4Utils.string_of_ident i)

    | PaArr (_, p)
    | PaRec (_, p)
    | PaTup (_, p) -> self#pat operators operands p
    | PaLaz (_, p) -> self#pat (add operators "lazy") operands p

    | PaAli (_, p1, p2)
    | PaApp (_, p1, p2)
    | PaCom (_, p1, p2)
    | PaSem (_, p1, p2)
    | PaOrp (_, p1, p2)
    | PaRng (_, p1, p2) ->
        let operators, operands = self#pat operators operands p1 in
        self#pat operators operands p2

    | PaLab (_, s, p)
    | PaOlb (_, s, p) -> self#pat operators (add operands s) p
    | PaEq (_, i, p) -> self#pat operators (add operands (Camlp4Utils.string_of_ident i)) p
    
    | PaOlbi (_, s, p, e) ->
        let operators, operands = self#pat operators (add operands s) p in
        self#exp operators operands e
    | PaTyc (_, p, c) ->
        let operators, operands = self#pat operators operands p in
        self#ct operators operands c

    | PaMod (_, s) -> (add operators "module"), (add operands s)

  method private matchcas operators operands mat =
    let open Camlp4.PreCast.Ast in
    match mat with
    | McNil _ -> operators, operands
    | McOr (_, m1, m2) ->
        let operators, operands = self#matchcas operators operands m1 in
        self#matchcas operators operands m2
    | McArr (_, p, e1, e2) ->
        let operators, operands = self#pat operators operands p in
        let operators, operands = self#exp operators operands e1 in
        self#exp operators operands e2
    | McAnt (_, s) -> operators, add operands s

  method private exp operators operands expr =
    let open Camlp4.PreCast.Ast in
    match expr with
    | ExNil _ -> operators, operands
    | ExAsf _ -> add operators "assert", operands
    | ExId (_, i) -> operators, add operands (Camlp4Utils.string_of_ident i)
    | ExNew (_, i) -> add operators "new", add operands (Camlp4Utils.string_of_ident i)
    | ExOpI (_, i, e) -> self#exp operators (add operands (Camlp4Utils.string_of_ident i)) e

    | ExAnt (_, s)
    | ExChr (_, s)
    | ExFlo (_, s)
    | ExInt (_, s)
    | ExInt32 (_, s)
    | ExInt64 (_, s)
    | ExNativeInt (_, s)
    | ExStr (_, s)
    | ExVrn (_, s) -> operators, add operands s

    | ExArr (_, e) -> self#exp operators operands e
    | ExAsr (_, e) -> self#exp (add operators "assert") operands e
    | ExLaz (_, e) -> self#exp (add operators "lazy") operands e
    | ExSeq (_, e) -> self#exp operators operands e
    | ExTup (_, e) -> self#exp operators operands e

    | ExLab (_, s, e)
    | ExOlb (_, s, e)
    | ExSnd (_, e, s)
    | ExFUN (_, s, e) -> self#exp operators (add operands s) e
    
    | ExAcc (_, e1, e2)
    | ExApp (_, e1, e2)
    | ExSem (_, e1, e2)
    | ExCom (_, e1, e2) ->
        let operators, operands = self#exp operators operands e1 in
        self#exp operators operands e2

    | ExAss (_, e1, e2) ->
        let operators, operands = self#exp (add operators ":=") operands e1 in
        self#exp operators operands e2
    | ExAre (_, e1, e2) ->
        let operators, operands = self#exp (add operators ".()") operands e1 in
        self#exp operators operands e2
    | ExSte (_, e1, e2) ->
        let operators, operands = self#exp (add operators ".[]") operands e1 in
        self#exp operators operands e2
    | ExWhi (_, e1, e2) ->
        let operators, operands = self#exp (add operators "while") operands e1 in
        self#exp operators operands e2
    | ExIfe (_, e1, e2, e3) ->
        let operators, operands = self#exp (add operators "if") operands e1 in
        let operators, operands = self#exp operators operands e2 in
        self#exp operators operands e3
    | ExFor (_, s, e1, e2, _, e3) ->
        let operators, operands = self#exp (add operators "for") (add operands s) e1 in
        let operators, operands = self#exp operators operands e2 in
        self#exp operators operands e3

    | ExFun (_, m) -> self#matchcas (add operators "fun") operands m
    | ExMat (_, e, m) ->
        let operators, operands = self#exp (add operators "match") operands e in
        self#matchcas operators operands m
    | ExTry (_, e, m) ->
        let operators, operands = self#exp (add operators "try") operands e in
        self#matchcas operators operands m

    | ExCoe (_, e, c1, c2) ->
        let operators, operands = self#exp (add operators ":>") operands e in
        let operators, operands = self#ct operators operands c1 in
        self#ct operators operands c2
    | ExTyc (_, e, c) ->
        let operators, operands = self#exp operators operands e in
        self#ct operators operands c
    
    | ExLet (_, _, b, e) ->
        let operators, operands = self#bnd operators operands b in
        self#exp operators operands e
    | ExLmd (_, s, _, e) -> self#exp operators (add operands s) e
    | ExObj (_, p, _) -> self#pat operators operands p
    
    | ExOvr (_, rb) -> self#rbnd operators operands rb
    | ExRec (_, rb, e) ->
        let operators, operands = self#rbnd operators operands rb in
        self#exp operators operands e
    | ExPkg _ -> operators, operands

  method private bnd operators operands b =
    let open Camlp4.PreCast.Ast in
    match b with
    | BiNil _ -> operators, operands
    | BiAnd (_, b1, b2) ->
        let operators, operands = self#bnd operators operands b1 in
        self#bnd operators operands b2
    | BiEq (_, p, e) ->
        let operators, operands = self#pat operators operands p in
        self#exp operators operands e
    | BiAnt (_, s) -> operators, (add operands s)

  method private rbnd operators operands rb =
    let open Camlp4.PreCast.Ast in
    match rb with
    | RbNil _ -> operators, operands
    | RbSem (_, rb1, rb2) ->
        let operators, operands = self#rbnd operators operands rb1 in
        self#rbnd operators operands rb2
    | RbEq (_, i, e) -> self#exp operators (add operands (Camlp4Utils.string_of_ident i)) e
    | RbAnt (_, s) -> operators, (add operands s)

  method! expr expr =
    let log2 x = (log x) /. (log 2.) in
    let ((nb_operators, operator_set), (nb_operands, operand_set)) = self#exp (set ()) (set ()) expr in
    let nb_uniq_operators = StringSet.cardinal operator_set in
    let nb_uniq_operands = StringSet.cardinal operand_set in
    let halstead_length = float (nb_operators + nb_operands) in
    let halstead_vocabulary = float (nb_uniq_operators + nb_uniq_operands) in
    let halstead_volume = halstead_length *. (log2 halstead_vocabulary) in
    let halstead_difficulty = ((float nb_uniq_operators) /. 2.) *. ((float nb_operands) /. (float nb_uniq_operands)) in
    let halstead_effort = halstead_difficulty *. halstead_volume in
    let open Camlp4.PreCast in
    let loc = Ast.loc_of_expr expr in
    let line, column = Camlp4Utils.line_and_column_of_location loc in
    info line column (Printf.sprintf "Halstead volume: %.2f" halstead_volume);
    info line column (Printf.sprintf "Halstead difficulty: %.2f" halstead_difficulty);
    info line column (Printf.sprintf "Halstead effort: %.2f" halstead_effort);
    self
end

let run _ _ ast _ report =
  let inst = new check report.Check.info in
  ignore (inst#str_item ast)
