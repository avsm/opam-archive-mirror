(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.structure

let category = CategoryName.code

let name = CheckName.make "builtin_types"

let multiple = false

let description = "redefinition builtin of types"

let documentation =
  "Checks that no builtin type is redefined."

let rationale =
  "Redefining a builtin type does not only result in code that is harder to " ^
  "apprehend, it is also not possible anymore to reference the original type."

let limits =
  ""

let parameters = Parameter.empty_map

(* from "typing/predef.ml" in the OCaml distribution *)
let builtin = [
  "int";
  "char";
  "string";
  "float";
  "bool";
  "unit";
  "exn";
  "array";
  "list";
  "format6";
  "option";
  "nativeint";
  "int32";
  "int64";
  "lazy_t";
]

class check error = object (self)

  inherit Camlp4.PreCast.Ast.fold as super

  method! str_item x =
    let open Camlp4.PreCast.Ast in
    (match x with
    | StTyp (_, TyDcl (loc, s, _, _, _)) ->
        if List.mem s builtin then begin
          let line, column = Camlp4Utils.line_and_column_of_location loc in
          let msg = Printf.sprintf "illegal redefinition of type %S" s in
          error line column msg
        end
    | _ -> ());
    ignore (super#str_item x);
    self

end

let run _ _ ast _ report =
  let inst = new check report.Check.error in
  ignore (inst#str_item ast)
