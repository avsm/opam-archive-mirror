(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.structure

let category = CategoryName.metrics

let name = CheckName.make "coupling"

let multiple = false

let description = "computes dependencies"

let documentation =
  "Computes the dependencies using the ocamldep tool, and both afferent and " ^
  "efferent couplings."

let rationale =
  "Afferent and efferent couplings allows to identify the role of a module, " ^
  "that is its place in the source base."

let limits =
  ""

let parameters = Parameter.empty_map

let run _ deps ast _ report =
  let str l = 
    if l = [] then
      ""
    else
      " (" ^ (String.concat ", " l) ^ ")" in
  let open Camlp4.PreCast in
  let loc = Ast.loc_of_str_item ast in
  let filename = Loc.file_name loc in
  let module_of_file f =
    String.capitalize (Filename.chop_extension (Filename.basename f)) in
  let modulename = module_of_file filename in
  let using = List.find (fun dep -> modulename = module_of_file dep.Ocamldep.file) deps in
  let using = using.Ocamldep.modules in
  let used_by = List.filter (fun x -> List.mem modulename x.Ocamldep.modules) deps in
  let used_by = List.map (fun x -> module_of_file x.Ocamldep.file) used_by in
  let info = report.Check.info 0 None in
  info (Printf.sprintf "Afferent couplings: %d%s" (List.length used_by) (str used_by));
  info (Printf.sprintf "Efferent couplings: %d%s" (List.length using) (str using))
