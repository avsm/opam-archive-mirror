(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.structure

let category = CategoryName.code

let name = CheckName.make "length"

let multiple = false

let description = "elements that are too long"

let documentation =
  "Checks that no function, class, or module is too long."

let rationale =
  "An element whose length is above a given limit should be refactored into " ^
  "smaller units in order to improve readability."

let limits =
  ""

let parameters, maximum = Parameter.make1
    (Parameter.int
       (ParameterName.make "maximum",
        "maximum number of lines",
        300,
        Parameter.strictly_positive))

class check maximum error = object (self)

  inherit Camlp4.PreCast.Ast.fold

  method! loc loc =
    let min_line = Camlp4.PreCast.Loc.start_line loc in
    let max_line = Camlp4.PreCast.Loc.stop_line loc in
    let length = max_line - min_line in
    if length > maximum then begin
      let msg = Printf.sprintf "element of length %d (instead of %d)" length maximum in
      error min_line None msg
    end;
    self

end

let run _ _ ast parameters report =
  let maximum = maximum parameters in
  let inst = new check maximum report.Check.error in
  ignore (inst#str_item ast)
