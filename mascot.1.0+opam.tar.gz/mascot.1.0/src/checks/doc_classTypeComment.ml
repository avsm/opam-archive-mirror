(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.ocamldoc

let category = CategoryName.documentation

let name = CheckName.make "class_type_comment"

let multiple = false

let description = "enforce presence of class type comments"

let documentation =
  "Enforces that each exported class type is commented, in order to produce a " ^
  "fully populated ocamldoc."

let rationale =
  "It is difficult to use a library, or to maintain a program if it is not " ^
  "fully and properly documented. "

let limits =
  "Some well-named class types need no documentation, and adding a documentation " ^
  "to them may be regarded as undesired noise."

let parameters, strict = Parameter.make1
    (Parameter.bool
       (ParameterName.make "strict",
        "whether empty comment should be rejected",
        false,
        Parameter.any))

class check strict error = object

  inherit Odoc_info.Scan.scanner as super

  method! scan_class_type_elements x =
    let open Odoc_info.Class in
    if OcamldocUtils.is_empty_info_option strict x.clt_info then begin
      let line, column = OcamldocUtils.line_and_column_of_location x.clt_loc.Odoc_info.loc_inter in
      error line column "missing class type comment"
    end;
    super#scan_class_type_elements x

end

let run _ _ modul parameters report =
  let strict = strict parameters in
  let inst = new check strict report.Check.error in
  inst#scan_module_list [modul]
