(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.tokens

let category = CategoryName.code

let name = CheckName.make "string_literals"

let multiple = false

let description = "duplicate string literals"

let documentation =
  "Looks for string literal duplicates."

let rationale =
  "Repeated elements need to be updated at once when a modification is made, " ^
  "leading to possible desynchronization if modification is only made partially."

let limits =
  "In OCaml, strings are mutable which means that it could be useful " ^
  "(although discouraged) to have multiple instances that are identical at " ^
  "program start but evolve in different manners. The developer may still " ^
  "investigate the possible use a the 'String.copy' function along with literal " ^
  "factorization. However, in some places (such as patterns) the compiler will " ^
  "require an integral constant, and reject a symbolic constant."

let parameters, exclude_empty, threshold = Parameter.make2
    (Parameter.bool
       (ParameterName.make "exclude_empty",
        "whether the empty string should be ignored",
        true,
        Parameter.any))
    (Parameter.int
       (ParameterName.make "threshold",
        "threshold for report",
        1,
        Parameter.strictly_positive))

module StringMap = Map.Make (struct type t = string let compare = Pervasives.compare end)

let run _ _ (file, tokens) parameters report =
  let exclude_empty = exclude_empty parameters in
  let threshold = threshold parameters in
  if file = Check.Implementation then begin
    let literals =
      List.fold_left
        (fun acc (line, _, elem) ->
          match elem with
          | Camlp4.Sig.STRING (_, s) ->
              let occurences, last = try StringMap.find s acc with Not_found -> 0, 0 in
              StringMap.add s ((succ occurences), (max line last)) acc
          | _ -> acc)
        StringMap.empty
        tokens in
    let literals =
      if exclude_empty then
        StringMap.remove "" literals
      else
        literals in
    StringMap.iter
      (fun literal (occurences, line) ->
        if occurences > threshold then
          let msg = Printf.sprintf "string literal %S is used %d times" literal occurences in
          report.Check.error line None msg)
      literals
  end
