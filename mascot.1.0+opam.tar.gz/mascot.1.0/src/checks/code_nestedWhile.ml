(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.structure

let category = CategoryName.code

let name = CheckName.make "nested_while"

let multiple = false

let description = "nested 'while' constructs"

let documentation =
  "Ensures that there is no deeply nested 'while' loops."

let rationale =
  "Above a given limit, the nesting of 'while' constructs render the code hard " ^
  "to read."

let limits =
  ""

let parameters, maximum = Parameter.make1
    (Parameter.int
       (ParameterName.make "maximum",
        "maximum nested while loops",
        3,
        Parameter.strictly_positive))

class check c maximum error = object (self)

  inherit Camlp4.PreCast.Ast.fold

  val count = c

  method get = c

  method private exp expr =
    let open Camlp4.PreCast.Ast in
    match expr with
(* no embedded expr *)
    | ExNil _
    | ExId _
    | ExAnt _
    | ExAsf _
    | ExChr _
    | ExFlo _
    | ExInt _
    | ExInt32 _
    | ExInt64 _
    | ExNativeInt _
    | ExNew _
    | ExStr _
    | ExVrn _
    | ExPkg _ ->
        new check 0 maximum error
(* one embedded expr *)
    | ExArr (_, e)
    | ExAsr (_, e)
    | ExCoe (_, e, _, _)
    | ExLab (_, _, e)
    | ExLaz (_, e)
    | ExOlb (_, _, e)
    | ExSeq (_, e)
    | ExTup (_, e)
    | ExSnd (_, e, _)
    | ExLet (_, _, _, e)
    | ExLmd (_, _, _, e)
    | ExTyc (_, e, _)
    | ExOpI (_, _, e)
    | ExFUN (_, _, e) ->
        self#exp e
(* two embedded exprs *)
    | ExAcc (_, e1, e2)
    | ExApp (_, e1, e2)
    | ExAre (_, e1, e2)
    | ExSem (_, e1, e2)
    | ExAss (_, e1, e2)
    | ExSte (_, e1, e2)
    | ExCom (_, e1, e2) ->
        new check (max (self#exp e1)#get (self#exp e2)#get) maximum error
(* miscellanesous *)
    | ExFun (_, mc) ->
        self#matchcase mc
    | ExMat (_, e, mc) ->
        new check (max (self#exp e)#get (self#matchcase mc)#get) maximum error
    | ExObj (_, _, csi) ->
        self#classstritem csi
    | ExOvr (_, rb) ->
        self#recbinding rb
    | ExRec (_, rb, e) ->
        new check (max (self#recbinding rb)#get (self#exp e)#get) maximum error
(* interesting constructions *)
    | ExIfe (_, e1, e2, e3) ->
        let c1 = (self#exp e1)#get in
        let c2 = (self#exp e2)#get in
        let c3 = (self#exp e3)#get in
        new check (max c1 (max c2 c3)) maximum error
    | ExWhi (loc, _, e2) ->
        let res = self#exp e2 in
        if (succ res#get) > maximum then begin
          let line, column = Camlp4Utils.line_and_column_of_location loc in
          let msg = Printf.sprintf "%d nested 'while' loops (instead of %d)" (succ res#get) maximum in 
          error line column msg
        end;
        new check (succ res#get) maximum error
    | ExFor (_, _, _, _, _, e) ->
        self#exp e
    | ExTry (_, e, mc) ->
        new check (max (self#exp e)#get (self#matchcase mc)#get) maximum error

  method private matchcase mc =
    let open Camlp4.PreCast.Ast in
    match mc with
    | McNil _ ->
        new check 0 maximum error
    | McOr (_, mc1, mc2) ->
        new check (max (self#matchcase mc1)#get (self#matchcase mc2)#get) maximum error
    | McArr (_, _, e1, e2) ->
        new check (max (self#exp e1)#get (self#exp e2)#get) maximum error
    | McAnt _ ->
        new check 0 maximum error

  method private recbinding rb =
    let open Camlp4.PreCast.Ast in
    match rb with
    | RbNil _ ->
        new check 0 maximum error
    | RbSem (_, rb1, rb2) ->
        new check (max (self#recbinding rb1)#get (self#recbinding rb2)#get) maximum error
    | RbEq (_, _, e) ->
        (self#exp e :> check)
    | RbAnt _ ->
        new check 0 maximum error

  method private classstritem csi =
    let open Camlp4.PreCast.Ast in
    match csi with
    | CrNil _ ->
        new check 0 maximum error
    | CrSem (_, csi1, csi2) ->
        new check (max (self#classstritem csi1)#get (self#classstritem csi2)#get) maximum error
    | CrCtr _ ->
        new check 0 maximum error
    | CrInh _ ->
        new check 0 maximum error
    | CrIni (_, e) ->
        self#exp e
    | CrMth (_, _, _, _, e, _) ->
        self#exp e
    | CrVal (_, _, _, _, e) ->
        self#exp e
    | CrVir _ ->
        new check 0 maximum error
    | CrVvr _ ->
        new check 0 maximum error
    | CrAnt _ ->
        new check 0 maximum error

  method! expr expr =
    ignore (self#exp expr); self

end

let run _ _ ast parameters report =
  let maximum = maximum parameters in
  let inst = new check 0 maximum report.Check.error in
  ignore (inst#str_item ast)
