(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.structure

let category = CategoryName.code

let name = CheckName.make "no_effect_assignment"

let multiple = false

let description = "detects assignments with no effect"

let documentation =
  "Detects useless assignments (e. g. 'x := x')."

let rationale =
  "Assignments with no effect are either the sign of an error, or the hint of possible simplification"

let limits =
  "This check does not protect against cycles of no-effect assignments."

let parameters = Parameter.empty_map


let rec eq x y =
  let open Camlp4.PreCast.Ast in
  match x, y with
  | IdAcc (_, id1, id2), IdAcc (_, id1', id2') -> (eq id1 id1') && (eq id2 id2')
  | IdApp (_, id1, id2), IdApp (_, id1', id2') -> (eq id1 id1') && (eq id2 id2')
  | IdLid (_, s1), IdLid (_, s2) -> s1 = s2
  | IdUid (_, s1), IdUid (_, s2) -> s1 = s2
  | IdAnt (_, s1), IdAnt (_, s2) -> s1 = s2
  | _ -> false

class check error = object (self)

  inherit Camlp4.PreCast.Ast.fold as super

  method! private expr expr =
    let open Camlp4.PreCast.Ast in
    (match expr with
    | ExAss (loc, ExAcc (_, ExId (_, id1), _), ExId (_, id2)) when eq id1 id2 ->
        let line, column = Camlp4Utils.line_and_column_of_location loc in
        let msg = Printf.sprintf "assignment with no effect" in 
        error line column msg;
    | _ -> ());
    ignore (super#expr expr);
    self

end

let run _ _ ast _ report =
  let inst = new check report.Check.error in
  ignore (inst#str_item ast)
