(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.structure

let category = CategoryName.code

let name = CheckName.make "predefined_exceptions"

let multiple = false

let description = "redefinition of predefined exceptions"

let documentation =
  "Checks that no predefined exception is redefined."

let rationale =
  "Redefining an exception with the same name as a predefined one leads to code " ^
  "that is difficult to read because the name is actually overloaded and only " ^
  "careful scope analysis can determine which exception is actually raised or " ^
  "caught at a given code point."

let limits =
  ""

let parameters = Parameter.empty_map

(* from "typing/predef.ml" in the OCaml distribution *)
let predef = [
  "Match_failure";
  "Out_of_memory";
  "Invalid_argument";
  "Failure";
  "Not_found";
  "Sys_error";
  "End_of_file";
  "Division_by_zero";
  "Stack_overflow";
  "Sys_blocked_io";
  "Assert_failure";
  "Undefined_recursive_module"
]

class check error = object (self)

  inherit Camlp4.PreCast.Ast.fold as super

  method private check_ident loc id =
    let s = Camlp4Utils.string_of_ident id in
    if List.mem s predef then begin
      let line, column = Camlp4Utils.line_and_column_of_location loc in
      let msg = Printf.sprintf "illegal redefinition of exception %S" s in
      error line column msg
    end

  method! str_item x =
    let open Camlp4.PreCast.Ast in
    (match x with
    | StExc (_, TyOf (_, TyId (loc, id), _), _) ->
        self#check_ident loc id
    | StExc (_, TyId (loc, id), _) ->
        self#check_ident loc id
    | _ -> ());
    ignore (super#str_item x);
    self

end

let run _ _ ast _ report =
  let inst = new check report.Check.error in
  ignore (inst#str_item ast)
