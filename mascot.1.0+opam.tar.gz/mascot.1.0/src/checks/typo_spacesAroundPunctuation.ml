(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.tokens

let category = CategoryName.typography

let name = CheckName.make "spaces_around_punctuation"

let multiple = false

let description = "white spaces around punctuation signs"

let documentation =
  "Checks that typographic rules about punctuation are respected."

let rationale =
  "Typographic conventions (in source code, as well as in ordinary text) should " ^
  "be followed because the uniformity they provide allows one to read faster."

let limits =
  ""

let parameters = Parameter.empty_map

let run _ _ (_, tokens) _ report =
  let rec iter = function
    | (_, _, prev_prev) :: (_, _, prev) :: (line, column, (Camlp4.Sig.SYMBOL ".")) :: tl ->
        let err = report.Check.error line (Some column) in
        (match prev_prev, prev with
        | Camlp4.Sig.SYMBOL "'", Camlp4.Sig.LIDENT _ -> ()
        | _ ->
            Camlp4Utils.check_not_white "sign" "." err prev;
            Camlp4Utils.check_first_not_white "sign" "." err tl);
        iter tl
    | (_, _, prev) :: (line, column, (Camlp4.Sig.SYMBOL s)) :: tl ->
        let err = report.Check.error line (Some column) in
        (match s with
        | "," | ";" ->
            Camlp4Utils.check_not_white "sign" s err prev;
            Camlp4Utils.check_first_white "sign" s err tl
        | "|" ->
            Camlp4Utils.check_white "sign" s err prev;
            Camlp4Utils.check_first_white "sign" s err tl
        | "!" | "?" ->
            Camlp4Utils.check_first_not_white "sign" s err tl
        | _ -> ());
        iter tl
    | _ :: tl -> iter tl
    | [] -> () in
  iter tokens
