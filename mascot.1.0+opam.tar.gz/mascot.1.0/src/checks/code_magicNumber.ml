(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.tokens

let category = CategoryName.code

let name = CheckName.make "magic_number"

let multiple = false

let description = "magic numbers"

let documentation =
  "Looks for magic numbers."

let rationale =
  "Repeated elements need to be updated at once when a modification is made, " ^
  "leading to possible desynchronization if modification is only made partially. " ^
  "Moreover, it is better to define symbolic constants rather than to repeat the " ^
  "integer constant in various places."

let limits =
  "Constants between -5 and 5 (both inclusive) are ignored by this check, but some " ^
  "other constants may be (at least in some context) self-explanatory. More, in some " ^
  "places (such as patterns) the compiler will require an integral constant, and " ^
  "reject a symbolic constant."

let parameters = Parameter.empty_map

type number =
  | Int of int
  | Int32 of int32
  | Int64 of int64
  | Nativeint of nativeint
  | Char of char

let type_and_string_of_number = function
  | Int x -> "int", string_of_int x
  | Int32 x -> "int32", Int32.to_string x
  | Int64 x -> "int64", Int64.to_string x
  | Nativeint x -> "nativeint", Nativeint.to_string x
  | Char x -> "char", String.make 1 x

module StringMap = Map.Make(struct type t = number let compare = Pervasives.compare end)

let run _ _ (file, tokens) _ report =
  if file = Check.Implementation then begin
    let replace map x line =
      let occurences, last = try StringMap.find x map with Not_found -> 0, 0 in
      StringMap.add x ((succ occurences), (max line last)) map in
    let values =
      List.fold_left
        (fun acc (line, _, elem) ->
          match elem with
          | Camlp4.Sig.INT (x, _) when x < -5 || x > 5 -> replace acc (Int x) line
          | Camlp4.Sig.INT32 (x, _) when x < -5l || x > 5l -> replace acc (Int32 x) line
          | Camlp4.Sig.INT64 (x, _) when x < -5L || x > 5L -> replace acc (Int64 x) line
          | Camlp4.Sig.NATIVEINT (x, _) when x < -5n || x > 5n -> replace acc (Nativeint x) line
          | Camlp4.Sig.CHAR (x, _) -> replace acc (Char x) line
          | _ -> acc)
        StringMap.empty
        tokens in
    StringMap.iter
      (fun number (occurences, line) ->
        if occurences > 1 then
          let typ, string = type_and_string_of_number number in
          let msg = Printf.sprintf "%s value \"%s\" is used %d times" typ string occurences in
          report.Check.error line None msg)
      values
  end
