(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.lines

let category = CategoryName.typography

let name = CheckName.make "header"

let multiple = false

let description = "coherent headers for source files"

let documentation =
  "Checks that all source files share the same header, as defined in a given file."

let rationale =
  "For copyright (or copyleft) issues, it is usually good practice to start " ^
  "each file with an header indicating both the distribution license, and " ^
  "the list of authors and/or copyright holders."

let limits =
  "The check cannot be used if different files use different header " ^
  "(e. g. due to different licenses)."

let parameters, file = Parameter.make1
    (Parameter.string
       (ParameterName.make "file",
        "path to header file",
        "/dev/null",
        Parameter.non_empty_string))

let run _ _ (_, lines) parameters report =
  let file = file parameters in
  let file = Utils.read_lines file in
  let report line = report.Check.error line None "invalid header" in
  let rec iter2 l1 l2 =
    match (l1, l2) with
    | (hd1 :: tl1), (hd2 :: tl2) ->
        if (snd hd1) = hd2 then
          iter2 tl1 tl2
        else
          report (fst hd1)
    | [], (_ :: _) ->
        report (List.length lines)
    | (_ :: _), [] -> ()
    | [], [] -> () in
  iter2 lines file
