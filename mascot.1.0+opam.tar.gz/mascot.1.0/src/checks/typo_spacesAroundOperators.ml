(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.tokens

let category = CategoryName.typography

let name = CheckName.make "spaces_around_operators"

let multiple = false

let description = "white spaces around operators"

let documentation =
  "Checks that typographic rules about operators are respected."

let rationale =
  "Typographic conventions (in source code, as well as in ordinary text) should " ^
  "be followed because the uniformity they provide allows one to read faster."

let limits =
  ""

let parameters = Parameter.empty_map

let opening token =
  let open Camlp4.Sig in
  match token with
  | SYMBOL "("
  | SYMBOL "["
  | SYMBOL "[|" -> true
  | _ -> false

let run _ _ (_, tokens) _ report =
  let rec iter = function
    | (_, _, prev) :: (line, column, (Camlp4.Sig.SYMBOL s)) :: tl ->
        let err = report.Check.error line (Some column) in
        let len = String.length s in
        (match s.[0] with
        | '-' | '~' when not (opening prev) ->
            Camlp4Utils.check_white "operator" s err prev
        | '$' | '%' | '&' | '*' | '+' | '/' | '<' | '=' | '>' | '@' | '^' | '|' ->
            Camlp4Utils.check_white "operator" s err prev;
            Camlp4Utils.check_first_white "operator" s err tl
        | '?' when len > 1 ->
            if len > 1 then begin
              Camlp4Utils.check_white "operator" s err prev;
              Camlp4Utils.check_first_white "operator" s err tl
            end else
              Camlp4Utils.check_white "operator" s err prev
        | ':' when len > 1 && s.[1] = ':' ->
            Camlp4Utils.check_white "operator" s err prev;
            Camlp4Utils.check_first_white "operator" s err tl
        | '.' when len > 1 ->
            if s <> ".." then begin
              Camlp4Utils.check_white "operator" s err prev;
              Camlp4Utils.check_first_white "operator" s err tl
            end
        | _ -> ());
        iter tl
    | (_, _, prev) :: ((line, column, (Camlp4.Sig.LIDENT s)) as hd) :: tl ->
        let err = report.Check.error line (Some column) in
        if List.mem s ["mod"; "land"; "lor"; "lxor"; "lsl"; "lsr"; "asr"] then begin
          Camlp4Utils.check_white "operator" s err prev;
          Camlp4Utils.check_first_white "operator" s err tl
        end;
        iter (hd :: tl)
    | _ :: tl -> iter tl
    | [] -> () in
  iter tokens
