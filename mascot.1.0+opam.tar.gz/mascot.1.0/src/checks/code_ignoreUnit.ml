(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.binary_annotations

let category = CategoryName.code

let name = CheckName.make "ignore_unit"

let multiple = false

let description = "ignore of unit expression"

let documentation =
  "Detects use of 'ignore' over expressions of type 'unit'."

let rationale =
  "The use of 'ignore' over expressions of type 'unit' is superfluous, and " ^
  "may be the hint of an error."

let limits =
  "The 'ignore' function may have been redefined locally."

let parameters = Parameter.empty_map

let is_ignore_path = function
  | Path.Pdot (Path.Pident { Ident.name = "Pervasives"; _}, "ignore", _ ) ->
      true
  | _ ->
      false

let has_unit_type e =
  match e.Typedtree.exp_type.Types.desc with
  | Types.Tconstr (path, [], _) when Path.same path Predef.path_unit ->
      true
  | _ ->
      false

let rec process_structure error s =
  List.iter (process_structure_item error) s.Typedtree.str_items
and process_structure_item error si =
  let open Typedtree in
  match si.str_desc with
  | Tstr_eval e ->
      process_expression error e
  | Tstr_value (_, l) ->
      List.iter (fun (_, e) -> process_expression error e) l
  | Tstr_module (_, _, me) ->
      process_module_expression error me
  | Tstr_recmodule l ->
      List.iter (fun (_, _, _, me) -> process_module_expression error me) l
  | Tstr_class l ->
      List.iter (fun (cd, _, _) -> process_class_declaration error cd) l
  | Tstr_primitive _
  | Tstr_type _
  | Tstr_exception _
  | Tstr_exn_rebind _
  | Tstr_modtype _
  | Tstr_open _
  | Tstr_class_type _
  | Tstr_include _ -> ()
and process_expression error e =
  let open Typedtree in
  match e.exp_desc with
  | Texp_ident _ -> ()
  | Texp_constant _ -> ()
  | Texp_let (_, l, e) ->
      List.iter (fun (_, e) -> process_expression error e) l;
      process_expression error e
  | Texp_function (_, l, _) ->
      List.iter (fun (_, e) -> process_expression error e) l
  | Texp_apply (e', l) ->
      (match e'.exp_desc, l with
      | Texp_ident (path, _, _), [(_, Some e, _)]
        when is_ignore_path path && has_unit_type e ->
          let loc = e'.exp_loc.Location.loc_start in
          let line = loc.Lexing.pos_lnum in
          let column = loc.Lexing.pos_cnum - loc.Lexing.pos_bol in
          error line (Some column) "ignore of a unit expression"
      | _ ->
          process_expression error e';
          List.iter
            (fun (_, eo, _) ->
              match eo with Some e -> process_expression error e | None -> ())
            l)
  | Texp_match (e, l, _) ->
      process_expression error e;
      List.iter (fun (_, e) -> process_expression error e) l
  | Texp_try (e, l) ->
      process_expression error e;
      List.iter (fun (_, e) -> process_expression error e) l
  | Texp_tuple l ->
      List.iter (process_expression error) l
  | Texp_construct (_, _, _, l, _) ->
      List.iter (process_expression error) l
  | Texp_variant (_, eo) ->
      (match eo with Some e -> process_expression error e | None -> ())
  | Texp_record (l, eo) ->
      List.iter (fun (_, _, _, e) -> process_expression error e) l;
      (match eo with Some e -> process_expression error e | None -> ())
  | Texp_field (e, _, _, _) ->
      process_expression error e
  | Texp_setfield (e1, _, _, _, e2) ->
      process_expression error e1;
      process_expression error e2
  | Texp_array l ->
      List.iter (process_expression error) l
  | Texp_ifthenelse (e1, e2, eo) ->
      process_expression error e1;
      process_expression error e2;
      (match eo with Some e -> process_expression error e | None -> ())
  | Texp_sequence (e1, e2) ->
      process_expression error e1;
      process_expression error e2
  | Texp_while (e1, e2) ->
      process_expression error e1;
      process_expression error e2
  | Texp_for (_, _, e1, e2, _, e3) ->
      process_expression error e1;
      process_expression error e2;
      process_expression error e3
  | Texp_when (e1, e2) ->
      process_expression error e1;
      process_expression error e2
  | Texp_send (e1, _, eo) ->
      process_expression error e1;
      (match eo with Some e -> process_expression error e | None -> ())
  | Texp_new _ -> ()
  | Texp_instvar _ -> ()
  | Texp_setinstvar (_, _, _, e) ->
      process_expression error e
  | Texp_override (_, l) ->
      List.iter (fun (_, _, e) -> process_expression error e) l;
  | Texp_letmodule (_, _, me, e) ->
      process_module_expression error me;
      process_expression error e
  | Texp_assert e ->
      process_expression error e
  | Texp_assertfalse -> ()
  | Texp_lazy e ->
      process_expression error e
  | Texp_object _ -> ()
  | Texp_pack me ->
      process_module_expression error me
and process_module_expression error me =
  let open Typedtree in
  match me.mod_desc with
  | Tmod_ident _ -> ()
  | Tmod_structure s ->
      process_structure error s
  | Tmod_functor (_, _, _, me) ->
      process_module_expression error me
  | Tmod_apply (me1, me2, _) ->
      process_module_expression error me1;
      process_module_expression error me2
  | Tmod_constraint (me, _, _, _) ->
      process_module_expression error me
  | Tmod_unpack (e, _) ->
      process_expression error e
and process_class_declaration error cd =
  process_class_expr error cd.Typedtree.ci_expr
and process_class_expr error ce =
  let open Typedtree in
  match ce.cl_desc with
  | Tcl_ident _
  | Tcl_structure _ -> ()
  | Tcl_fun (_, _, l, ce, _) ->
      List.iter (fun (_, _, e) -> process_expression error e) l;
      process_class_expr error ce
  | Tcl_apply (ce, l) ->
      process_class_expr error ce;
      List.iter
        (fun (_, eo, _) ->
          match eo with Some e -> process_expression error e | None -> ())
        l
  | Tcl_let (_, l1, l2, ce) ->
      List.iter (fun (_, e) -> process_expression error e) l1;
      List.iter (fun (_, _, e) -> process_expression error e) l2;
      process_class_expr error ce
  | Tcl_constraint (ce, _, _, _, _) -> process_class_expr error ce

let run _ _ annotations _ report =
  let open Cmt_format in
  let error = report.Check.error in
  match annotations.cmt_annots with
  | Implementation s -> process_structure error s
  | Partial_implementation a ->
      Array.iter
        (function
          | Partial_structure s -> process_structure error s
          | Partial_structure_item si -> process_structure_item error si
          | Partial_expression e -> process_expression error e
          | Partial_class_expr ce -> process_class_expr error ce
          | Partial_pattern _
          | Partial_signature _
          | Partial_signature_item _
          | Partial_module_type _ -> ())
        a
  | Packed _
  | Interface _
  | Partial_interface _ -> ()
