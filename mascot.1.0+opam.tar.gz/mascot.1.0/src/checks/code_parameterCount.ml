(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.structure

let category = CategoryName.code

let name = CheckName.make "parameter_count"

let multiple = false

let description = "functions with too many parameters"

let documentation =
  "Enforces that functions have a reasonable number of parameters."

let rationale =
  "Functions with too many parameters provide difficult to use APIs. In order to " ^
  "increase readability, one is advised to group parameters into data structures " ^
  "such as records."

let limits =
  ""

let parameters, maximum = Parameter.make1
    (Parameter.int
       (ParameterName.make "maximum",
        "maximum number of parameters",
        8,
        Parameter.strictly_positive))

let rec params x =
  let open Camlp4.PreCast.Ast in
  match x with
  | ExFun (_, McArr (_, _, _, e)) -> succ (params e)
  | _ -> 0

class check maximum error = object (self)

  inherit Camlp4.PreCast.Ast.fold as super

  method! expr expr =
    let open Camlp4.PreCast.Ast in
    (match expr with
    | ExFun (loc, McArr (_, _, _, _)) ->
        let n = params expr in
        if n > maximum then begin
          let line, column = Camlp4Utils.line_and_column_of_location loc in
          let msg = Printf.sprintf "function has %d parameters (instead of %d)" n  maximum in 
          error line column msg
        end
    | _ -> ());
    ignore (super#expr expr);
    self

end

let run _ _ ast parameters report =
  let maximum = maximum parameters in
  let inst = new check maximum report.Check.error in
  ignore (inst#str_item ast)
