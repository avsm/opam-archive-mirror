(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.lines

let category = CategoryName.typography

let name = CheckName.make "trailing_new_line"

let multiple = false

let description = "end-of-file newline"

let documentation =
  "Checks whether the last line of the file is an empty one."

let rationale =
  "End-of-file newlines are not only useless, they may also badly " ^
  "influence page layout when printing."

let limits =
  ""

let parameters = Parameter.empty_map

let run _ _ (_, lines) _ report =
  match List.rev lines with
  | (_, "") :: _ ->
      let len = List.length lines in
      report.Check.error len None "trailing new line" 
  | _ -> ()
