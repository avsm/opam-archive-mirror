(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.ocamldoc

let category = CategoryName.documentation

let name = CheckName.make "module_comment"

let multiple = false

let description = "enforce presence of module comments"

let documentation =
  "Enforces that each exported module is commented, in order to produce a " ^
  "fully populated ocamldoc."

let rationale =
  "It is difficult to use a library, or to maintain a program if it is not " ^
  "fully and properly documented. "

let limits =
  "Some well-named modules need no documentation, and adding a documentation " ^
  "to them may be regarded as undesired noise."

let parameters, require_author, require_version, strict =
  Parameter.make3
    (Parameter.bool
       (ParameterName.make "require_author",
        "enforce presence of @author tag (toplevel only)",
        false,
        Parameter.any))
    (Parameter.bool
       (ParameterName.make "require_version",
        "enforce presence of @version tag (toplevel only)",
        false,
        Parameter.any))
    (Parameter.bool
       (ParameterName.make "strict",
        "whether empty comment should be rejected",
        false,
        Parameter.any))

class check strict error = object

  inherit Odoc_info.Scan.scanner as super

  method! scan_module_elements x =
    let open Odoc_info.Module in
    if OcamldocUtils.is_empty_info_option strict x.m_info then begin
      let line, column = OcamldocUtils.line_and_column_of_location x.m_loc.Odoc_info.loc_inter in
      error line column "missing module comment"
    end;
    super#scan_module_elements x

end

let run _ _ modul parameters report =
  let require_author = require_author parameters in
  let require_version = require_version parameters in
  let strict = strict parameters in
  let inst = new check strict report.Check.error in
  inst#scan_module_list [modul];
  let open Odoc_info.Module in
  match modul.m_info with
  | Some info ->
      if require_author && info.Odoc_info.i_authors = [] then
        report.Check.error 1 None "missing @author comment";
      if require_version && info.Odoc_info.i_version = None then
        report.Check.error 1 None "missing @version comment"
  | None ->
      report.Check.error 1 None "missing module comment";
