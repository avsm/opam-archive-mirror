(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.signature

let category = CategoryName.interface

let name = CheckName.make "exported_count"

let multiple = false

let description = "presence of complex structures"

let documentation =
  "Checks for the presence of complex structures, that is ones that export " ^
  "too many elements."

let rationale =
  "Structures with many items are difficult to apprehend and are an hint " ^
  "that some refactoring should be performed in order to build smaller units."

let limits =
  ""

let parameters, maximum =
  Parameter.make1
    (Parameter.int (ParameterName.make "maximum",
                    "maximum exported elements",
                    32,
                    Parameter.strictly_positive))

class check maximum error = object (self)

  inherit Camlp4.PreCast.Ast.fold as super

  method! module_type module_type =
    let open Camlp4.PreCast.Ast in
    (match module_type with
    | MtSig (loc, sig_item) ->
        let elems = list_of_sig_item sig_item [] in
        let len = List.length elems in
        if len > maximum then begin
          let msg = Printf.sprintf "structure exports %d items (instead of %d)" len maximum in
          let line, column = Camlp4Utils.line_and_column_of_location loc in
          error line column msg
        end
    | _ -> ());
    ignore (super#module_type module_type);
    self

end

let run _ _ ast parameters report =
  let open Camlp4.PreCast in
  let maximum = maximum parameters in
  let elems = Ast.list_of_sig_item ast [] in
  let inst = new check maximum report.Check.error in
  let len = List.length elems in
  if len > maximum then begin
    let msg = Printf.sprintf "structure exports %d items (instead of %d)" len maximum in
    report.Check.error 1 None msg
  end;
  List.iter
    (fun elem -> ignore (inst#sig_item elem))
    elems
