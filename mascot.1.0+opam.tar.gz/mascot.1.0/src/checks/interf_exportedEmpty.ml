(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.signature

let category = CategoryName.interface

let name = CheckName.make "exported_empty"

let multiple = false

let description = "presence of empty structures"

let documentation =
  "Checks for the presence of empty structures, that is ones that export " ^
  "no element."

let rationale =
  "Empty structures are often the hint of a mistake."

let limits =
  "Empty structures may be useful if they contain side effects."

let parameters = Parameter.empty_map

class check error = object (self)

  inherit Camlp4.PreCast.Ast.fold as super

  method! module_type module_type =
    let open Camlp4.PreCast.Ast in
    (match module_type with
    | MtSig (loc, sig_item) ->
        if (list_of_sig_item sig_item []) = [] then begin
          let line, column = Camlp4Utils.line_and_column_of_location loc in
          error line column "structure exports no item"
        end
    | _ -> ());
    ignore (super#module_type module_type);
    self

end

let run _ _ ast _ report =
  let open Camlp4.PreCast in
  let inst = new check report.Check.error in
  let elems = Ast.list_of_sig_item ast [] in
  if elems = [] then begin
    report.Check.error 1 None "structure exports no item"
  end;
  List.iter
    (fun elem -> ignore (inst#sig_item elem))
    elems
