(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.structure

let category = CategoryName.code

let name = CheckName.make "complex_condition"

let multiple = false

let description = "complex if/while/when conditions"

let documentation =
  "Checks for complex conditions of 'if', 'while', and 'when' constructs, " ^
  "that is conditions with too many boolean operators"

let rationale =
  "Complex conditions make the control flow of a code harder to understand."

let limits =
  "Detection will not be accurate if either a boolean operator is redefined, " ^
  "or a synonym is declared."

let parameters, maximum = Parameter.make1
    (Parameter.int
       (ParameterName.make "maximum",
        "maximum number of boolean operators",
        5,
        Parameter.strictly_positive))

class check (c : int) maximum error = object (self)

  inherit Camlp4.PreCast.Ast.fold

  val count = c

  method get = c

  method exp exp =
    let open Camlp4.PreCast.Ast in
    match exp with
(* no embedded expr *)
    | ExNil _
    | ExAnt _
    | ExAsf _
    | ExChr _
    | ExFlo _
    | ExInt _
    | ExInt32 _
    | ExInt64 _
    | ExNativeInt _
    | ExNew _
    | ExStr _
    | ExVrn _
    | ExPkg _ ->
        new check 0 maximum error
(* one embedded expr *)
    | ExArr (_, e)
    | ExAsr (_, e)
    | ExCoe (_, e, _, _)
    | ExLab (_, _, e)
    | ExLaz (_, e)
    | ExOlb (_, _, e)
    | ExSeq (_, e)
    | ExTup (_, e)
    | ExSnd (_, e, _)
    | ExLet (_, _, _, e)
    | ExLmd (_, _, _, e)
    | ExTyc (_, e, _)
    | ExOpI (_, _, e)
    | ExFUN (_, _, e)
    | ExFor (_, _, _, _, _, e)
    | ExTry (_, e, _) ->
        self#exp e
(* two embedded exprs *)
    | ExAcc (_, e1, e2)
    | ExAre (_, e1, e2)
    | ExSem (_, e1, e2)
    | ExAss (_, e1, e2)
    | ExSte (_, e1, e2)
    | ExCom (_, e1, e2) ->
        new check (max (self#exp e1)#get (self#exp e2)#get) maximum error
(* miscellanesous *)
    | ExFun (_, mc) ->
        self#matchcase mc
    | ExMat (_, e, mc) ->
        new check (max (self#exp e)#get (self#matchcase mc)#get) maximum error
    | ExObj (_, _, csi) ->
        self#classstritem csi
    | ExOvr (_, rb) ->
        self#recbinding rb
    | ExRec (_, rb, e) ->
        new check (max (self#recbinding rb)#get (self#exp e)#get) maximum error
(* interesting constructions *)
    | ExId (_, id) ->
        let x =
          if List.mem (Camlp4Utils.string_of_ident id) ["||"; "&&"; "not"] then
            1
          else
            0 in
        new check x maximum error
    | ExApp (_, e1, e2) ->
        let n = (self#exp e1)#get + (self#exp e2)#get in
        new check n maximum error
    | ExIfe (loc, e1, e2, e3) ->
        let n = (self#exp e1)#get in
        ignore (self#exp e2);
        ignore (self#exp e3);
        if n > maximum then begin
          let line, column = Camlp4Utils.line_and_column_of_location loc in
          let msg = Printf.sprintf "complex condition (%d operators instead of %d)" n maximum in
          error line column msg
        end;
        new check 0 maximum error
    | ExWhi (loc, e1, e2) ->
        let n = (self#exp e1)#get in
        ignore (self#exp e2);
        if n > maximum then begin
          let line, column = Camlp4Utils.line_and_column_of_location loc in
          let msg = Printf.sprintf "complex condition (%d operators instead of %d)" n maximum in
          error line column msg
        end;
        new check 0 maximum error

  method private matchcase mc =
    let open Camlp4.PreCast.Ast in
    match mc with
    | McNil _ ->
        new check 0 maximum error
    | McOr (_, mc1, mc2) ->
        ignore (self#matchcase mc1);
        ignore (self#matchcase mc2);
        new check 0 maximum error
    | McArr (loc, _, e1, e2) ->
        let n = (self#exp e1)#get in
        ignore (self#exp e2);
        if n > maximum then begin
          let line, column = Camlp4Utils.line_and_column_of_location loc in
          let msg = Printf.sprintf "complex condition (%d operators instead of %d)" n maximum in
          error line column msg
        end;
        new check 0 maximum error
    | McAnt _ ->
        new check 0 maximum error

  method private recbinding rb =
    let open Camlp4.PreCast.Ast in
    match rb with
    | RbNil _ ->
        new check 0 maximum error
    | RbSem (_, rb1, rb2) ->
        ignore (self#recbinding rb1);
        ignore (self#recbinding rb2);
        new check 0 maximum error
    | RbEq (_, _, e) ->
        (self#exp e :> check)
    | RbAnt _ ->
        new check 0 maximum error

  method private classstritem csi =
    let open Camlp4.PreCast.Ast in
    match csi with
    | CrNil _ ->
        new check 0 maximum error
    | CrSem (_, csi1, csi2) ->
        ignore (self#classstritem csi1);
        ignore (self#classstritem csi2);
        new check 0 maximum error
    | CrCtr _ ->
        new check 0 maximum error
    | CrInh _ ->
        new check 0 maximum error
    | CrIni (_, e) ->
        self#exp e
    | CrMth (_, _, _, _, e, _) ->
        self#exp e
    | CrVal (_, _, _, _, e) ->
        self#exp e
    | CrVir _ ->
        new check 0 maximum error
    | CrVvr _ ->
        new check 0 maximum error
    | CrAnt _ ->
        new check 0 maximum error

  method! expr expr =
    ignore (self#exp expr);
    self

end

let run _ _ ast parameters report =
  let maximum = maximum parameters in
  let inst = new check 0 maximum report.Check.error in
  ignore (inst#str_item ast)
