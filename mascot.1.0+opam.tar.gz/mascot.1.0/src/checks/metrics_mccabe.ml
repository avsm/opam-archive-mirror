(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.structure

let category = CategoryName.metrics

let name = CheckName.make "mccabe"

let multiple = false

let description = "McCabe complexity"

let documentation =
  "Computes the McCabe complexity of expressions."

let rationale =
  "The McCabe metric allows to identify functions that are too complex to " ^
  "understand, and thus to maintain."

let limits =
  "As any metric, the McCabe complexity only gives bare hints about whether an " ^
  "expression should be decomposed into smaller elements."

let parameters = Parameter.empty_map

class check info = object (self)

  inherit Camlp4.PreCast.Ast.fold

  method private matchcas mat =
    let open Camlp4.PreCast.Ast in
    match mat with
    | McNil _ -> 0
    | McOr (_, m1, m2) -> (self#matchcas m1) + (self#matchcas m2)
    | McArr (_, _, e1, e2) -> (self#exp e1) + (self#exp e2)
    | McAnt _ -> 0

  method private exp expr =
    let open Camlp4.PreCast.Ast in
    match expr with
    | ExNil _
    | ExId _
    | ExAnt _
    | ExAsf _
    | ExChr _
    | ExFlo _
    | ExInt _
    | ExInt32 _
    | ExInt64 _
    | ExNativeInt _
    | ExNew _
    | ExVrn _
    | ExOvr _
    | ExStr _
    | ExObj _
    | ExPkg _ -> 0

    | ExArr (_, e)
    | ExAsr (_, e)
    | ExCoe (_, e, _, _)
    | ExSeq (_, e)
    | ExSnd (_, e, _)
    | ExTup (_, e)
    | ExTyc (_, e, _)
    | ExOpI (_, _, e)
    | ExLab (_, _, e)
    | ExLaz (_, e)
    | ExOlb (_, _, e)
    | ExLmd (_, _, _, e)
    | ExLet (_, _, _, e)
    | ExRec (_, _, e)
    | ExFUN (_, _, e) -> self#exp e

    | ExAcc (_, e1, e2)
    | ExApp (_, e1, e2)
    | ExAre (_, e1, e2)
    | ExSem (_, e1, e2)
    | ExAss (_, e1, e2)
    | ExSte (_, e1, e2)
    | ExCom (_, e1, e2) -> (self#exp e1) + (self#exp e2)

    | ExWhi (_, e1, e2) -> 1 + (self#exp e1) + (self#exp e2)
    | ExFor (_, _, e1, e2, _, e3) -> 1 + (self#exp e1) + (self#exp e2) + (self#exp e3)
    | ExIfe (_, e1, e2, e3) -> 1 + (self#exp e1) + (self#exp e2) + (self#exp e3)
    | ExFun (_, m) -> 1 + (self#matchcas m)
    | ExMat (_, e, m) -> 1 + (self#exp e) + (self#matchcas m)
    | ExTry (_, e, m) -> 1 + (self#exp e) + (self#matchcas m)

  method! expr expr =
    let open Camlp4.PreCast in
    let loc = Ast.loc_of_expr expr in
    let line, column = Camlp4Utils.line_and_column_of_location loc in
    let mccabe = 1 + (self#exp expr) in
    let msg = Printf.sprintf "McCabe complexity: %d" mccabe in
    info line column msg;
    self

end

let run _ _ ast _ report =
  let inst = new check report.Check.info in
  ignore (inst#str_item ast)
