(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.ocamldoc

let category = CategoryName.documentation

let name = CheckName.make "value_comment"

let multiple = false

let description = "enforce presence of value comments"

let documentation =
  "Enforces that each exported value is commented, in order to produce a " ^
  "fully populated ocamldoc."

let rationale =
  "It is difficult to use a library, or to maintain a program if it is not " ^
  "fully and properly documented. "

let limits =
  "Some well-named values need no documentation, and adding a documentation " ^
  "to them may be regarded as undesired noise."

let parameters, strict = Parameter.make1
    (Parameter.bool
       (ParameterName.make "strict",
        "whether empty comment should be rejected",
        false,
        Parameter.any))

class check strict error = object

  inherit Odoc_info.Scan.scanner as super

  method! scan_value x =
    let open Odoc_info.Value in
    if OcamldocUtils.is_empty_info_option strict x.val_info then begin
      let line, column = OcamldocUtils.line_and_column_of_location x.val_loc.Odoc_info.loc_inter in
      error line column "missing value comment"
    end;
    super#scan_value x

end

let run _ _ modul parameters report =
  let strict = strict parameters in
  let inst = new check strict report.Check.error in
  inst#scan_module_list [modul]
