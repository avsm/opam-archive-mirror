(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.tokens

let category = CategoryName.code

let name = CheckName.make "useless_external_parentheses"

let multiple = false

let description = "useless external parentheses"

let documentation =
  "Checks 'if', 'when', 'while', and 'for' constructs do not have superfluous " ^
  "external parentheses."

let rationale =
  "These constructs are themselves 'parenthesized', and accept expression of a " ^
  "fixed type. As a consequence, parentheses hinder readability."

let limits =
  ""

let parameters = Parameter.empty_map

let opening token =
  let open Camlp4.Sig in
  match token with
  | LIDENT "if"
  | LIDENT "while"
  | LIDENT "when"
  | SYMBOL "="
  | LIDENT "to" | LIDENT "downto" -> true
  | _ -> false

let closing token =
  let open Camlp4.Sig in
  match token with
  | LIDENT "then"
  | LIDENT "do"
  | SYMBOL "->"
  | LIDENT "to" | LIDENT "downto" -> true
  | _ -> false

let run _ _ (file, tokens) _ report =
  let fst (x, _, _) = x in
  let snd (_, x, _) = x in
  let thr (_, _, x) = x in
  if file = Check.Implementation then begin
    let open Camlp4.Sig in
    let tokens =
      List.filter
        (fun token ->
          match thr token with
          | KEYWORD _
          | SYMBOL _
          | LIDENT _
          | UIDENT _
          | ESCAPED_IDENT _
          | INT _
          | INT32 _
          | INT64 _
          | NATIVEINT _
          | FLOAT _
          | CHAR _
          | STRING _
          | LABEL _
          | OPTLABEL _
          | QUOTATION _
          | ANTIQUOT _
          | EOI -> true
          | COMMENT _
          | BLANKS _
          | NEWLINE
          | LINE_DIRECTIVE _ -> false)
        tokens in
    let prev = ref (0, 0, EOI) in
    let stack = Stack.create () in
    try
      List.iter
        (fun curr ->
          if (thr !prev) = (SYMBOL ")") then begin
            let first = Stack.pop stack in
            if first && (closing (thr curr)) then
              report.Check.error (fst curr) (Some (snd curr))
                "useless external parentheses"
          end;
          if (thr curr) = (SYMBOL "(") then
            Stack.push (opening (thr !prev)) stack;
          prev := curr)
        tokens
    with Queue.Empty -> () (* syntax error silently discarded *)
  end
