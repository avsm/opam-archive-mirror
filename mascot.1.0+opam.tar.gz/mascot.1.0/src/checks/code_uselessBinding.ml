(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.structure

let category = CategoryName.code

let name = CheckName.make "useless_binding"

let multiple = false

let description = "detects useless bindings"

let documentation =
  "Detects useless bindings (e. g. 'let x = x')."

let rationale =
  "Useless bindings are either the sign of an error, or the hint of possible simplification."

let limits =
  "This check does not protect against useless synonyms."

let parameters = Parameter.empty_map

class check error = object (self)

  inherit Camlp4.PreCast.Ast.fold as super

  method! binding binding =
    let open Camlp4.PreCast.Ast in
    (match binding with
    | BiEq (loc, PaId (_, id1), ExId (_, id2))
      when (Camlp4Utils.string_of_ident id1) = (Camlp4Utils.string_of_ident id2) ->
        let line, column = Camlp4Utils.line_and_column_of_location loc in
        let msg = Printf.sprintf "useless binding" in 
        error line column msg
    | _ -> ());
    ignore (super#binding binding);
    self

end

let run _ _ ast _ report =
  let inst = new check report.Check.error in
  ignore (inst#str_item ast)
