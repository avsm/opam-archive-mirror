(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.structure

let category = CategoryName.code

let name = CheckName.make "tuple_size"

let multiple = false

let description = "lengthy tuples"

let documentation =
  "Detects lengthy tuples."

let rationale =
  "When a tuple has too many members, it should be refactored into a record."

let limits =
  ""

let parameters, maximum = Parameter.make1
    (Parameter.int
       (ParameterName.make "maximum",
        "maximum number of members",
        4,
        Parameter.strictly_positive))

class check maximum error = object (self)

  inherit Camlp4.PreCast.Ast.fold as super

  method! private expr expr =
    let open Camlp4.PreCast.Ast in
    let rec size = function
      | ExCom (_, _, e) -> succ (size e)
      | _ -> 1 in
    (match expr with
    | ExTup (loc, tup) ->
        let sz = size tup in
        if sz > maximum then
        let line, column = Camlp4Utils.line_and_column_of_location loc in
        let msg = Printf.sprintf "tuple of size %d (instead of %d)" sz maximum in
        error line column msg
    | _ -> ());
    ignore (super#expr expr);
    self

  method! private patt patt =
    let open Camlp4.PreCast.Ast in
    let rec size = function
      | PaCom (_, _, e) -> succ (size e)
      | _ -> 1 in
    (match patt with
    | PaTup (loc, tup) ->
        let sz = size tup in
        if sz > maximum then
        let line, column = Camlp4Utils.line_and_column_of_location loc in
        let msg = Printf.sprintf "tuple of size %d (instead of %d)" sz maximum in
        error line column msg
    | _ -> ());
    ignore (super#patt patt);
    self

  method! private ctyp ctyp =
    let open Camlp4.PreCast.Ast in
    let rec size = function
      | TySta (_, _, e) -> succ (size e)
      | _ -> 1 in
    (match ctyp with
    | TyTup (loc, tup) ->
        let sz = size tup in
        if sz > maximum then
        let line, column = Camlp4Utils.line_and_column_of_location loc in
        let msg = Printf.sprintf "tuple of size %d (instead of %d)" sz maximum in
        error line column msg
    | _ -> ());
    ignore (super#ctyp ctyp);
    self

end

let run _ _ ast parameters report =
  let maximum = maximum parameters in
  let inst = new check maximum report.Check.error in
  ignore (inst#str_item ast)
