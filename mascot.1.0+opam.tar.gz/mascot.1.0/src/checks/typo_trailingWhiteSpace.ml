(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.lines

let category = CategoryName.typography

let name = CheckName.make "trailing_white_space"

let multiple = false

let description = "end-of-line whitespace"

let documentation =
  "Checks for the presence of whitespaces (either plain spaces or " ^
  "tabulations) at ends of lines."

let rationale =
  "End-of-line whitespaces are not only useless, they may also badly " ^
  "influence page layout when printing. Moreover, they are quite often " ^
  "the leftovers of a refactoring operation."

let limits =
  ""

let parameters, tolerance =
  Parameter.make1
    (Parameter.int (ParameterName.make "tolerance",
                    "how many whitespace characters may be tolerated",
                    0,
                    Parameter.positive))

let whitespace = function
  | ' ' | '\t' -> true
  | _ -> false

let run _ _ (_, lines) parameters report =
  let tolerance = tolerance parameters in
  List.iter
    (fun (no, line) ->
      let len = String.length line in
      if len > 0 then
        let i = ref (pred len) in
        while (!i >= 0) && (whitespace line.[!i]) do
          decr i
        done;
        let nb = len - 1 - !i in
        if nb > tolerance then
          report.Check.error no (Some len) "trailing white space")
    lines
