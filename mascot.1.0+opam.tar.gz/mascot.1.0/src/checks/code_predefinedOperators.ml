(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.structure

let category = CategoryName.code

let name = CheckName.make "predefined_operators"

let multiple = false

let description = "redefinition predefined of operators"

let documentation =
  "Checks that no predefined operator is redefined."

let rationale =
  "Replacing a predefined operators leads to code that is difficult to read, " ^
  "as the reader has to carefully remember which operators where redefined. " ^
  "Moreover, some redefinitions replace with implementations that do not have " ^
  "the same mathematical properties (such as commutativity), leading to " ^
  "incorrect assumptions."

let limits =
  ""

let parameters = Parameter.empty_map

let predef = [
(* from module "Num" *)
  "+/"; "-/"; "*/"; "//"; "**/";
  "=/"; "</"; ">/"; "<=/"; ">=/"; "<>/";
(* from module "Pervasives" *)
  "="; "<>"; "<"; ">"; "<="; ">=";
  "=="; "!=";
  "&&"; "&"; "||"; "or"; "not";
  "~-"; "~+";
  "succ"; "pred";
  "+"; "-"; "*"; "/"; "mod";
  "land"; "lor"; "lxor"; "lsl"; "lsr"; "asr";
  "~-."; "~+.";
  "+."; "-."; "*."; "/."; "**";
  "^";
  "@";
  "!"; ":=";
  "^^"
]

class check error = object (self)

  inherit Camlp4.PreCast.Ast.fold as super

  method! binding x =
    let open Camlp4.PreCast.Ast in
    (match x with
    | BiEq (loc, p, _) ->
        let rec chk = function
          | PaId (_, id) ->
              let s = Camlp4Utils.string_of_ident id in
              if List.mem s predef then begin
                let line, column = Camlp4Utils.line_and_column_of_location loc in
                let msg = Printf.sprintf "illegal redefinition of operator %S" s in
                error line column msg
              end
          | PaCom (_, p1, p2) ->
              chk p1;
              chk p2
          | PaTup (_, p) ->
              chk p
          | PaTyc (_, p, _) ->
              chk p
          | _ -> () in
        chk p
    | _ -> ());
    ignore (super#binding x);
    self

end

let run _ _ ast _ report =
  let inst = new check report.Check.error in
  ignore (inst#str_item ast)
