(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.structure

let category = CategoryName.code

let name = CheckName.make "empty_for"

let multiple = false

let description = "empty 'for' constructs"

let documentation =
  "Detects empty 'for' constructs."

let rationale =
  "Either the loop is a waste of time, either some code is missing."

let limits =
  ""

let parameters = Parameter.empty_map

class check error = object (self)

  inherit Camlp4.PreCast.Ast.fold as super

  method! private expr expr =
    let open Camlp4.PreCast.Ast in
    (match expr with
    | ExFor (loc, _, _, _, _, (ExId (_, (IdUid (_, "()"))))) ->
        let line, column = Camlp4Utils.line_and_column_of_location loc in
        error line column "empty 'for' loop"
    | _ -> ());
    ignore (super#expr expr);
    self

end

let run _ _ ast _ report =
  let inst = new check report.Check.error in
  ignore (inst#str_item ast)
