(*
 * This file is part of Mascot.
 * Copyright (C) 2010-2012 Xavier Clerc.
 *
 * Mascot is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Mascot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

type t = Check.tokens

let category = CategoryName.typography

let name = CheckName.make "spaces_around_blocks"

let multiple = false

let description = "white spaces around block delimiters"

let documentation =
  "Checks that typographic rules about block delimiters are respected."

let rationale =
  "Typographic conventions (in source code, as well as in ordinary text) should " ^
  "be followed because the uniformity they provide allows one to read faster."

let limits =
  ""

let parameters = Parameter.empty_map

type symbol_kind =
  | Opening
  | Closing
  | Punctuation
  | Label
  | Other

let symbol_kind token =
  let open Camlp4.Sig in
  match token with
  | SYMBOL "("
  | SYMBOL "["
  | SYMBOL "[|"
  | SYMBOL "{"
  | LIDENT "begin" -> Opening
  | SYMBOL ")"
  | SYMBOL "]"
  | SYMBOL "|]"
  | SYMBOL "}"
  | LIDENT "end" -> Closing
  | SYMBOL ","
  | SYMBOL ";"
  | SYMBOL ";;"
  | SYMBOL "." -> Punctuation
  | LABEL _
  | OPTLABEL _ -> Label
  | _ -> Other

let first kinds = function
  | (_, _, hd) :: _ -> List.mem (symbol_kind hd) kinds
  | [] -> true

let run _ _ (_, tokens) _ report =
  let rec iter = function
    | (_, _, prev) :: (line, column, (Camlp4.Sig.SYMBOL s)) :: tl ->
        let err = report.Check.error line (Some column) in
        (match s with
        | "(" | "[" ->
            (match symbol_kind prev with
            | Opening | Label -> ()
            | _ -> Camlp4Utils.check_white "sign" s err prev);
            Camlp4Utils.check_first_not_white "sign" s err tl
        | ")" | "]" ->
            let prev_kind = symbol_kind prev in
            if (prev_kind <> Closing) && (prev_kind <> Opening) then
              Camlp4Utils.check_not_white "sign" s err prev;
            if not (first [Closing; Punctuation] tl) then
              Camlp4Utils.check_first_white "sign" s err tl
        | "{" | "}" | "[|" | "|]" | "[<" | ">]" ->
            Camlp4Utils.check_white "sign" s err prev;
            if not (first [Closing; Punctuation] tl) then
              Camlp4Utils.check_first_white "sign" s err tl
        | _ -> ());
        iter tl
    | (_, _, prev) :: (line, column, (Camlp4.Sig.LIDENT "begin")) :: tl ->
        let err = report.Check.error line (Some column) in
        if symbol_kind prev = Opening then
          Camlp4Utils.check_white "keyword" "begin" err prev;
        iter tl
    | (_, _, _) :: (line, column, (Camlp4.Sig.LIDENT "end")) :: tl ->
        let err = report.Check.error line (Some column) in
        if not (first [Closing; Punctuation] tl) then
          Camlp4Utils.check_first_not_white "keyword" "end" err tl;
        iter tl
    | _ :: tl -> iter tl
    | [] -> () in
  iter tokens
