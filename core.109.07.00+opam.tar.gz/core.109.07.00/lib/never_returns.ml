type never_returns

let never_returns (_ : never_returns) = assert false
