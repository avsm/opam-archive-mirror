
function caml_sys_getenv () {
    return '';  
}
