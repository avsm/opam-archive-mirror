/**
 * @providesModule ES6_Default_AnonFunction1
 * @flow
 */

export default function():number { return 42; }
