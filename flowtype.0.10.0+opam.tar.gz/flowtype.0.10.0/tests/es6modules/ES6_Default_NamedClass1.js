/**
 * @providesModule ES6_Default_NamedClass1
 * @flow
 */

// TODO: Support named class declarations in an export
//export default class Foo { givesANum(): number { return 42; }};
