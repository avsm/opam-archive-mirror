/**
 * @providesModule ES6_ExportFrom_Intermediary2
 * @flow
 */

export {
  numberValue1,
  numberValue2 as numberValue2_renamed2
} from "ES6_ExportFrom_Source2";
