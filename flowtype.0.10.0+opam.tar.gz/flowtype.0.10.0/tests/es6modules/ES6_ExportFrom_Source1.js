/**
 * @providesModule ES6_ExportFrom_Source1
 * @flow
 */

export var numberValue1 = 1, numberValue2 = 2;
