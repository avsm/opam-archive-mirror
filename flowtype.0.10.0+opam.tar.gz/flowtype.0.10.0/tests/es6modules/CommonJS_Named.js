/**
 * @providesModule CommonJS_Named
 * @flow
 */

exports.numberValue1 = 1;
exports.numberValue2 = 2;
exports.numberValue3 = 3;
exports.numberValue4 = 4;
exports.numberValue5 = 5;
