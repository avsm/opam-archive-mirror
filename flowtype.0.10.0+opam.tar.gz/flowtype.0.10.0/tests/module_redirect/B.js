/**
 * @providesModule B
 * @flow
 */

module.exports = require('A');
