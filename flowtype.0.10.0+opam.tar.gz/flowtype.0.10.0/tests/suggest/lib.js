/* @flow */

function bar(w: number): number { return w; }

module.exports = bar;
