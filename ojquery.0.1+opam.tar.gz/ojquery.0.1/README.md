# jQuery Binding

This a binding of the jQuery library, using **goji** by Benjamin CANOU.

This library is not over yet, and the interface WILL change in the future. 
You are however free to use it if writing deprecated code is your thing.

## Usage

Do ```make```, ```make install```.

Compile your project with the package ojquery. Yep, that's all. 
You can use it now.

## Known Issues

You should not use this library as it is right now.

Most of the typing is not done. If the signature of the function seems correct 
to you, I guess you can use it. You might be able to still use some "not yet 
done" functions, but there is no guarantee at all, and you're on your own. 
Anyway, good luck.