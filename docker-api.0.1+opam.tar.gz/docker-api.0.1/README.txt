(* OASIS_START *)
(* DO NOT EDIT (digest: 36f3c55be4a388fbc147bf7571264693) *)

docker-api - Binding to the Docker Remote API
=============================================

Control Docker <https://www.docker.com/> containers using the remote API.

See the file [INSTALL.txt](INSTALL.txt) for building and installation
instructions.

[Home page](https://github.com/Chris00/ocaml-docker)

Copyright and license
---------------------

docker-api is distributed under the terms of the GNU Lesser General Public
License version 3.0 with OCaml linking exception.

(* OASIS_STOP *)
