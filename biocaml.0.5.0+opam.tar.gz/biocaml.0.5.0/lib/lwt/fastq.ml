include Biocaml_unix.Std.Fastq
include MakeIO(Future_lwt)
