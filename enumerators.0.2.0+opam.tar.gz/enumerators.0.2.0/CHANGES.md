## v0.2.0

- Build with topkg instead of make (issue #5)
- Enable the "bin_annot" flag
- Remove the 64-bit version of Beint.  The "Int64" version is used for all architectures.

## v0.1.1

*2015-12-03*

- Compile with `-safe-string` (issue #1)
- Add a bytecode-only target (PR #2)

## v0.1.0

*2015-08-28*

- Initial release
