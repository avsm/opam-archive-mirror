// @flow
var a : C = new D();
var a : D = new C();  // Error: C ~> D
