module type S = sig
  val cat : string -> string
end
