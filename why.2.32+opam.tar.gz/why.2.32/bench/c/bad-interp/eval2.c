void f (){
  int x = 0x100000000u;
  x=x;
}
