int * s;
void f() { s->x = 0; } 
/* request for member x in something not a structure or union */

