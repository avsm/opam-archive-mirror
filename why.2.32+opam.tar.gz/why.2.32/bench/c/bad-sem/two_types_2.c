struct { int x; } int y;
