# ocaml-opasswd [![Build Status](https://travis-ci.org/xapi-project/ocaml-opasswd.svg?branch=master)](https://travis-ci.org/xapi-project/ocaml-opasswd)

OCaml bindings to the glibc passwd file and shadow password
file interface.

It can be used to read, parse, manipulate and write passwd and shadow files on
Linux systems.
