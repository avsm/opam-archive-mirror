let c2 = 12
