let main = String.length Aa.aa - Bb.bb - C3.c3 - Cc.cc - 1
