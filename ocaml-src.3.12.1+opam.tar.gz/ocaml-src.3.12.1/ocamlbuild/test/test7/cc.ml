let cc = (String.length Aa.aa) + Bb.bb + C2.c2
