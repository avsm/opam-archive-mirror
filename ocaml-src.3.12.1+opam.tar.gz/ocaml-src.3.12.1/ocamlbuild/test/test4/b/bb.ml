let r = Str.regexp "r"
let foo = [2.2]
