let stack = 42
