let b = A.a + 1
