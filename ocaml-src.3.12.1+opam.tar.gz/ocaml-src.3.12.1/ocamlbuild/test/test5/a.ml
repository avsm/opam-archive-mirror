let a = 42 + Stack.stack
