Format.printf "C.B.b = %d@." C.B.b
