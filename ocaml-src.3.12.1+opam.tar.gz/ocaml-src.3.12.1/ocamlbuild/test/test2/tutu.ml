let tutu = (Array.length Vivi.vivi : Tyty.t)
let tutu' = 2.0 +. float_of_int tutu
