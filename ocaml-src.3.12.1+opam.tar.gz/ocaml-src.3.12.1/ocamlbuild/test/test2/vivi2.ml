let rec p i = [< '1; '2; p (i + 1) >]
let vivi = [|3|]
