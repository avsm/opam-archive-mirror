let b = D.d
