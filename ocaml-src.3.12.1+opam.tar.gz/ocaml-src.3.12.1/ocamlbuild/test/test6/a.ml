let a = B.b
