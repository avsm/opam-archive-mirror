type t
let d x = x
