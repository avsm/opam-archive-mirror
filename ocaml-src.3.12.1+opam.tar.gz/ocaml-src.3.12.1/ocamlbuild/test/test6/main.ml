A.a 2. +. D.d 1.
