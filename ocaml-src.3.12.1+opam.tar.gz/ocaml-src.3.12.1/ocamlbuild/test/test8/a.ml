print_endline Myconfig.version;;
