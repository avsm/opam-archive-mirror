external stub1: unit -> string = "stub1"


let () = print_endline (stub1 ())
