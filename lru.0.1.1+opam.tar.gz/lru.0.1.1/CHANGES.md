## v0.1.1 2016-11-28

* Fix missing dep on `psq` in META

## v0.1.0 2016-11-22

First release.
