open Util.Prelude


let analyse_decl clang =
  NamingConvention.analyse_decl clang
