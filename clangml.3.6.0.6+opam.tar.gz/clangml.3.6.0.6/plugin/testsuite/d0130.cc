// dsw: from Taras Glek <tglek@mozilla.com>
class foo {
    __attribute__ ((visibility ("default"))) __attribute__ ((visibility ("waga")))  foo() ;
    __attribute__ ((visibility ("default"))) ~foo() ;
};
