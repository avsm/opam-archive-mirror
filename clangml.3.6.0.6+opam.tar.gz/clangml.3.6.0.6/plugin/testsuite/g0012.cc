// g0012.cc
// __attribute__ on a return value
// from Kevin Millikin

int __attribute__((__cdecl__)) isalnum (int __c);
