
int f() {
  return (__builtin_types_compatible_p(int,float));
}
