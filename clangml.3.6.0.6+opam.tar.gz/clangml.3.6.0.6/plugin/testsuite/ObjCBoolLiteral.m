void * yes = __objc_yes;
void * no  = __objc_no;
