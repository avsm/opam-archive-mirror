v0.3.0 2016-11-09 Cambridge
---------------------------

Fixed OPAM

v0.2.0 2016-11-09 Cambridge
---------------------------

Fixed README and packaging

v0.1.0 2016-11-09 Cambridge
---------------------------

Initial public release.

