#ifdef __cplusplus
extern "C" {
#endif

    int bap_disasm_llvm_init();

#ifdef __cplusplus
}
#endif
