open Ctypes
open Foreign

type t = T.t
let t = T.t
