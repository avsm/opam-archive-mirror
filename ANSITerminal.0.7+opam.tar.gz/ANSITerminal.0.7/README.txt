(* OASIS_START *)
(* DO NOT EDIT (digest: 4c6c7d26b7cb92f974bcbd97414e7c79) *)

ANSITerminal - Basic control of ANSI compliant terminals and the windows shell.
===============================================================================

ANSITerminal is a module allowing to use the colors and cursor movements on
ANSI terminals. It also works on the windows shell (but this part is
currently work in progress).

See the file [INSTALL.txt](INSTALL.txt) for building and installation
instructions.

[Home page](https://github.com/Chris00/ANSITerminal)

Copyright and license
---------------------

ANSITerminal is distributed under the terms of the GNU Lesser General Public
License version 3.0 with OCaml linking exception.

(* OASIS_STOP *)
