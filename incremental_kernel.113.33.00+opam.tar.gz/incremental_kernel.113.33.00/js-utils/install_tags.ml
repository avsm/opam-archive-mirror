let package_name = "incremental_kernel"

let sections =
  [ ("lib",
    [ ("built_lib_incremental_kernel", None)
    ],
    [ ("META", None)
    ])
  ]
