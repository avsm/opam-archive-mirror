let package_name = "patience_diff"

let sections =
  [ ("lib",
    [ ("built_lib_patience_diff_lib", None)
    ],
    [ ("META", None)
    ])
  ]
