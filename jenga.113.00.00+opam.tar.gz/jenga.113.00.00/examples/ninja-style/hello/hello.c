#include <stdio.h>
#include "hello.h"

int main() {
  printf("hello - %d\n", V);
  return 0;
}
