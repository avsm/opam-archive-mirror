open Ctypes
       
type avro_type_t = int
let avro_type_t = int
