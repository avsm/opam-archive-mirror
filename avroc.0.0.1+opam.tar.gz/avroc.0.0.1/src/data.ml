open Ctypes

type avro_wrapped_buffer_t = unit
let avro_wrapped_buffer_t : avro_wrapped_buffer_t typ = void
