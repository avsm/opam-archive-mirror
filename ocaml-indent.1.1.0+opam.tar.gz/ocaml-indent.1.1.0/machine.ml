open Sexplib.Conv
open Pos

module Parser = Xparser

module Stack = struct

  type k =
    | KExpr of int
    | KParen of int
    | KBrace of int
    | KBracket of int
    | KLet of [`Top | `Local ] * int
    | KVal
    | KType of int
    | KException of int
    | KNone
    | KStruct of int
    | KSig of int
    | KModule of int
    | KOpen
    | KBegin of int
    | KObject of int
    | KMatch of int
    | KTry of int
    | KWith of int
    | KWhile of int
    | KIf of int
    | KThen of int
    | KElse of int
    | KFor of int
    | KDo of int
    | KFunction of int
    | KFun of int
    | KCaseArrow
  with sexp

  type elt = { k : k;
               indent : int }

  let sexp_of_elt { k; indent } =
    Sexplib.Sexp.List [ sexp_of_k k;
                        sexp_of_int indent ]

  type t = elt list with sexp_of

  (* CR jfuruse: strange *)
  let indent _last_indent  = function
    | [] -> 0
    | { indent = n } :: _ -> n
end

module State = struct
  type t = {
    modified : bool;   (* Has the source code ever modified ? *)
    orig_indent : int; (* The original indent of the current line *)
    last_indent : int; (* At line head, first pass: the fixed indent of the last line
                          At line head, snd pass: the fixed indent of the current line
                          Otherwise: the fixed indent of the current line *)
    last_token : Parser.token option;
    bases : Stack.t;
  } with sexp_of

  let init = { bases = []; orig_indent = 0; last_indent = 0; last_token = None; modified = false }

  let indent t = Stack.indent t.last_indent t.bases

  let print t = print_endline (Sexplib.Sexp.to_string_mach (sexp_of_t t))
end

open State
open Stack
open Parser

(* Check the previous token and tell the LET is toplevel or not *)
let is_top_let = function
  | None -> true
  | Some t ->
      match t with
      | COMMENT _ -> assert false (* COMMENT must be skipped *)
      | STRUCT | SEMISEMI

      | UIDENT _|STRING _|OPTLABEL _|NATIVEINT _|LIDENT _|LABEL _|INT64 _|INT32 _
      | INT _|FLOAT _|CHAR _|WITH|VIRTUAL|VAL|UNDERSCORE|TYPE|TRUE|TILDE|SIG|SHARP
      | RPAREN|REC|RBRACKET|RBRACE|QUOTE|QUESTIONQUESTION|QUESTION|PRIVATE|OPEN
      | OF|OBJECT|NEW|MUTABLE|MODULE|METHOD|MATCH|LET|LAZY|INHERIT|INCLUDE
      | GREATERRBRACKET|GREATERRBRACE|FUNCTOR|FUNCTION|FUN|FOR|FALSE
      | EXTERNAL|EXCEPTION|EOF|END|DOTDOT|DOT|DONE|CONSTRAINT|COLONGREATER
      | COLON|CLASS|BARRBRACKET|BAR|BANG|BACKQUOTE|ASSERT|AS|AND
          -> true

      | _ -> false

let rec unwind_top bases = match bases with (* unwind the top *)
  | { k = KLet (`Top, _) } :: bs -> bs (* CR jfuruse: probably we don't need it *)
  | { k = (KStruct _ | KSig _) } :: _ -> bases
  | _ :: bs -> unwind_top bs
  | [] -> []

(* true means I found something to make the token a block *)
let rec lparen_read_ahead lnum str =
  match Tokenstr.destr str with
  | None -> false
  | Some (i, _) when Region.lnum i.Tokenstr.region <> lnum -> false
  | Some (i, str) ->
      match i.Tokenstr.token with
      | COMMENT _ -> lparen_read_ahead lnum str
      | FUN -> false
      | FUNCTION -> false
      | _ -> true

let lbrace_read_ahead lnum str =
  match Tokenstr.destr str with
  | None -> false
  | Some (i, _) when Region.lnum i.Tokenstr.region <> lnum -> false
  | Some (i, str) ->
      match i.Tokenstr.token with
      | COMMENT _ -> lparen_read_ahead lnum str
      | _ -> true

let lbracket_read_ahead = lbrace_read_ahead

let function_read_ahead = lbrace_read_ahead

let token state str at_the_head region (t : Parser.token) : State.t * State.t =

  (** Which line the token is in *)
  let line = Region.lnum region in

  (** Which column the token is at *)
  let cols = Region.columns region in

  (** The indent of the current line.
      If the token is at the head of the line, it may be the original indent
  *)
  let indent = state.last_indent in

  (** The original indent stack. You must update this. *)
  let bases0 = state.bases in

  (** Just change the indentation to [cols]. Useful at the line heads *)
  let fix cols = [{ k = KNone; indent = cols }] in

  (* A basic rule.

     An effect of a token cannot exceed a token whose connectivity power is stronger.

     CR jfuruse: I could encode this information into Stack.k's ordering.
  *)

  let pre_bases, post_bases = match t with
    | SEMISEMI ->
        (* unwind the top *)
        let bases = unwind_top bases0 in
        bases, bases

    | OPEN ->
        let bases = unwind_top bases0 in
        bases,
        { k = KOpen; indent = cols + 2; } :: bases

    | MODULE ->
        let bases = unwind_top bases0 in
        bases,
        { k = KModule cols; indent = cols + 2; } :: bases

    | VAL ->
        let bases = unwind_top bases0 in
        bases,
        { k = KVal; indent = cols + 2; } :: bases

    | LET when is_top_let state.last_token ->
        let bases = unwind_top bases0 in
        bases,
        { k = KLet (`Top, cols); indent = cols + 2; } :: bases

    | LET ->
        bases0, { k = KLet (`Local, cols); indent = cols + 2; } :: bases0

    | EQUAL ->
        (* CR jfuruse: TODO
           - pre bases
           - for non definition equals *)
        let rec f bases = match bases with
          (* Definition equal rolls things back to its head *)
          | {k = (KLet (_, _cols) | KType _cols | KModule _cols) } :: _ ->
              bases, bases
          (* Equal can exceed the following *)
          | { k = (KExpr _ | KNone) } :: bs -> f bs
          (* Equal cannot exceed the other *)
          | _ :: _bs -> bases0, bases0
          | [] -> [], []
        in
        f bases0

    | TYPE when state.last_token = Some MODULE -> (* module type *)
        (* we might change the kind to KModuleType, but ... let's keep it simpler *)
        bases0, bases0

    | TYPE ->
        let bases = unwind_top bases0 in
        bases,
        { k = KType cols; indent = cols + 2; } :: bases

    | EXCEPTION ->
        let bases = unwind_top bases0 in
        bases,
        { k = KException cols; indent = cols + 2; } :: bases

    | AND ->
        (* for let *)
        (* recover the last let, type, module *)
        let rec f bases = match bases with
          | {k = (KLet (_,cols) | KType cols | KModule cols) } :: _ ->
              fix cols, bases
          | [] -> [], []
          | _ :: bs -> f bs
        in
        f bases0

    | IN ->
        (* in must paired with let *)
        let rec f bases = match bases with
          | { k = KLet(_, cols) } :: bs ->
              fix cols, bs
          | [] -> [], []
          | _ :: bs -> f bs
        in
        f bases0

    | STRUCT ->
        bases0, { k = KStruct indent; indent = indent + 2; } :: bases0

    | SIG ->
        bases0, { k = KSig indent; indent = indent + 2; } :: bases0

    | BEGIN ->
        bases0, { k = KBegin indent; indent = indent + 2; } :: bases0

    | OBJECT ->
        bases0, { k = KObject indent; indent = indent + 2; } :: bases0

    | END ->
        let rec f bases = match bases with
          | { k = (KStruct cols | KSig cols | KBegin cols | KObject cols) } :: bs ->
              fix cols, bs
          | [] -> [], []
          | _ :: bs -> f bs
        in
        f bases0

    | MATCH ->
        bases0,
        if at_the_head then
          { k = KMatch cols; indent = cols + 2; } :: bases0
        else
          (* bit special handling *)
          let rec compute bases = match bases with
            | [] -> indent
            | { k = KLet (_, cols) } :: _ -> max (cols + 2) indent
            | _ :: bs -> compute bs
          in
          { k = KMatch (compute bases0); indent = cols + 2; } :: bases0

    | TRY ->
        bases0,
        if at_the_head then
          { k = KTry cols; indent = cols + 2; } :: bases0
        else
          { k = KTry indent; indent = indent + 2; } :: bases0

    | WITH ->
        (* support for typeconv *)
        let rec f bases = match bases with
          | { k = KBrace cols } :: _ ->
              fix (cols + 2), bases
          | { k = (KType cols | KException cols | KMatch cols | KTry cols) } :: bs ->
              fix cols,
             { k = KWith cols; indent = cols + 2; } :: bs
          | [] -> [], []
          | _ :: bs -> f bs
        in
        f bases0

    | IF ->
        bases0, { k = KIf cols; indent = cols + 2; } :: bases0

    | THEN ->
        let rec f bases = match bases with
          | { k = KIf cols } :: bs ->
              fix cols,
              { k = KThen cols; indent = cols + 2; } :: bs
          | [] -> [], []
          | _ :: bs -> f bs
        in
        f bases0

    | ELSE ->
        let rec f bases = match bases with
          | { k = KThen cols } :: bs ->
              fix cols,
              { k = KElse cols; indent = cols + 2; } :: bs
          | [] -> [], []
          | _ :: bs -> f bs
        in
        f bases0

    | WHILE ->
        bases0, { k = KWhile indent; indent = cols + 2; } :: bases0

    | DO ->
        let rec f bases = match bases with
          | { k = (KWhile cols ) } :: bs ->
              { k = KDo cols; indent = cols; } :: bs, bs
          | [] -> [], []
          | _ :: bs -> f bs
        in
        f bases0

    | DONE ->
        let rec f bases = match bases with
          | { k = (KDo cols ) } :: bs ->
              fix cols, bs
          | [] -> [], []
          | _ :: bs -> f bs
        in
        f bases0

    | LPAREN ->
        if lparen_read_ahead line str then
          bases0, { k = KParen cols; indent = cols + 2; } :: bases0
        else
          bases0, { k = KParen indent; indent = indent + 2; } :: bases0

    | RPAREN ->
        let rec f bases = match bases with
          | { k = (KParen cols ) } :: bs ->
              fix cols, bs
          | [] -> [], []
          | _ :: bs -> f bs
        in
        f bases0

    | LBRACE ->
        if lbrace_read_ahead line str then
          bases0, { k = KBrace cols; indent = cols + 2; } :: bases0
        else
          bases0, { k = KBrace indent; indent = indent + 2; } :: bases0

    | RBRACE ->
        let rec f bases = match bases with
          | { k = (KBrace cols ) } :: bs ->
              fix cols, bs
          | [] -> [], []
          | _ :: bs -> f bs
        in
        f bases0

    | LBRACKET ->
        if lbracket_read_ahead line str then
          bases0, { k = KBracket cols; indent = cols + 2; } :: bases0
        else
          bases0, { k = KBracket indent; indent = indent + 2; } :: bases0

    | RBRACKET ->
        let rec f bases = match bases with
          | { k = (KBracket cols ) } :: bs ->
              fix cols, bs
          | [] -> [], []
          | _ :: bs -> f bs
        in
        f bases0

    | FUNCTION ->
        if function_read_ahead line str then
          bases0,
          { k = KFunction cols; indent = cols + 10 (* function+2 *); } :: bases0
        else
          bases0,
          { k = KFunction indent; indent = indent + 4 (* "  | " *); } :: bases0

    | FUN ->
        bases0, { k = KFun indent; indent = indent + 2; } :: bases0

    | BAR ->
        let rec f bases = match bases with
          | { k = ( KType cols
                  | KFunction cols) } :: _ ->
              fix (cols + 2), bases
          | { k = ( KBracket cols
                  | KWith cols
                  | KParen cols) } :: _ ->
              fix cols, bases
          | [] -> bases0, bases0 (* if overrun, keep the original *)
          | _ :: bs -> f bs
        in
        f bases0

    | MINUSGREATER ->
        let rec f bases = match bases with
          | { k = (KWith cols) } :: _ ->
              fix (cols + 2),
              { k = KCaseArrow; indent = cols + 4; } :: bases
          | { k = (KFunction cols) } :: _ ->
              fix (cols + 2),
              { k = KCaseArrow; indent = cols + 6; } :: bases
          | { k = (KFun cols) } :: _ ->
              fix (cols + 2),
              { k = KCaseArrow; indent = cols + 2; } :: bases
          | [] -> bases0, bases0 (* if overrun, keep the original *)
          | _ :: bs -> f bs
        in
        f bases0

    | COMMA ->
        let rec f bases = match bases with
          | { k = ( KBegin cols
                  | KBracket cols
                  | KBrace cols
                  | KLet (_, cols) ) } :: _ ->
              fix (cols + 2), bases
          | { k = ( KParen cols ) } :: _ ->
              fix cols, bases
          (* comma cannot exceeds them (comma is stronger than them) *)
          | { k = (KThen _ | KElse _ | KWith _ | KFunction _ | KFun _ | KMatch _ | KTry _ | KCaseArrow ) } :: _ ->
              bases0, bases
          | [] -> bases0, bases0 (* if overrun, keep the original *)
          | _ :: bs -> f bs
        in
        f bases0

    | SEMI ->
        let rec f bases = match bases with
          | { k = (KParen cols | KBegin cols | KBracket cols | KBrace cols | KLet (_, cols)) | KTry cols | KMatch cols | KFun cols | KFunction cols } :: _ ->
              fix cols, bases
          | { k = KCaseArrow } :: _ -> bases, bases
          | { k = (KThen cols | KElse cols ) } :: bs ->
              fix cols, bs
          | [] -> bases0, bases0 (* if overrun, keep the original *)
          | _ :: bs -> f bs
        in
        f bases0

    | INT64 _ | INT32 _ | INT _ | LIDENT _ | UIDENT _ | FLOAT _| CHAR _ | STRING _ | TRUE | FALSE ->
        let rec f bases = match bases with
          | { k = KExpr _ } :: _ -> bases0, bases0
          | [] -> bases0, { k = KExpr cols; indent = cols + 2; } :: bases0
          | _ :: bs -> f bs
        in
        f bases0

    | STAR | PLUSDOT | PLUS | MINUSDOT | MINUS
    | INFIXOP4 _ | INFIXOP3 _ | INFIXOP2 _ | INFIXOP1 _ | INFIXOP0 _
    | LESS | GREATER | AMPERSAND | AMPERAMPER
      ->
        let rec f bases = match bases with
          | { k = KExpr cols } :: _ ->
              { k = KNone; indent = cols } :: bases0, bases0
          | [] -> bases0, bases0
          | _ :: bs -> f bs
        in
        f bases0

    | COMMENT _ ->
        (* Comments are tricky. It is:

           - sometimes affected by the previous line's indentation
           - sometimes affected by the next line's indentation
           - sometimes independent
        *)
        fix cols, bases0

    |PREFIXOP _|OPTLABEL _|NATIVEINT _|LABEL _
    |WHEN|VIRTUAL|UNDERSCORE|TO|TILDE|
          SHARP|REC|QUOTE|QUESTIONQUESTION|QUESTION|
          PRIVATE|OR|OF|NEW|MUTABLE|METHOD
          |LESSMINUS|LBRACKETGREATER|LBRACKETLESS|LBRACKETBAR|
          LBRACELESS|LAZY|INITIALIZER|INHERIT|INCLUDE|GREATERRBRACKET|
          GREATERRBRACE|FUNCTOR|FOR|EXTERNAL|EOF|
          DOWNTO|DOTDOT|DOT|CONSTRAINT|COLONGREATER|COLONEQUAL|
          COLONCOLON|COLON|CLASS|BARRBRACKET|BARBAR|BANG|BACKQUOTE|ASSERT|AS
          -> bases0, bases0
  in
  { state with bases = pre_bases },
  { state with bases = post_bases }

let update_state state ~at_new_line ~fix_indent str orig_region t =

  (* If it is a new line + we need to fix the indent of the line, compute the line's indentation.
     Otherwise, we use the original state.
  *)
  let state' =
    if fix_indent && at_new_line then
      let pre, _ = token state str at_new_line orig_region t in
      { pre with last_indent = State.indent pre }
    else
      state
  in

  (* Fix the indentation. It may be updated by the previous call of [token]. *)
  let fixed_region =
    (* CR jfuruse: Spaghetti... *)
    if fix_indent then Region.move_chars (state'.last_indent - state.orig_indent) orig_region else orig_region
  in
  let state = { state
                with
                last_indent = state'.last_indent
                ; modified = state'.modified || orig_region <> fixed_region
              }
  in

  (* Rerun [token] *)
  token state str at_new_line fixed_region t
