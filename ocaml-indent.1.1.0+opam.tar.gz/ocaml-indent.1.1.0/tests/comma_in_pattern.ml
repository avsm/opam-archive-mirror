let parse_args () = 
  begin match paths
              , lines with
  | [], _ -> 
      assert false
  | [_]
    , _ -> 
      ()
  | _, 
    Some _ -> 
      failwith "Region can be specified with at most one file" 
  | _ -> ()
  end;
