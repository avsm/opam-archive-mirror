(* OASIS_START *)
(* DO NOT EDIT (digest: d83d11f520362285211215e045bb5eca) *)
This is the README file for the ocaml-indent distribution.

OCaml-indent: OCaml source code indenter

See the files INSTALL.txt for building and installation instructions. 


(* OASIS_STOP *)
