
let z1 = X.( ( + ) )
let z2 = X.( ( * ) )
let z3 = X.( 1 + 4 - x / 1)
let () =
  X.(
    let z = 1 + 4 - x / 1 + a.(2) in
    a.(i) <- z + 1
  )

let z5 = X.( 3 * x * x + 5 * x + 7 = 0 );;

let z6 = X.( [| |] )
let z7 = X.( [| 1; 2 |] )
