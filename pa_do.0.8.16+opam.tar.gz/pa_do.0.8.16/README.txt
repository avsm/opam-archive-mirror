(* OASIS_START *)
(* DO NOT EDIT (digest: 79e315a206382d5c02194cb4b00b2a3e) *)
This is the README file for the pa_do distribution.

Syntax extension module to enable easy local overloading of operators and
functions.

Delimited overloading is a syntax extension to ease the writing of efficient
arithmetic expressions in OCaml.  It allows out of the box to use the usual
arithmetic operators for Int32, Int64, Nativeint, Num, and Complex.  A fake
"Float" module is also provided. Some optimizations are performed, in
particular for the module Complex.

This syntax extension can be further extended: you can write overloadings for
your own modules using either the concrete syntax or by writing a small
syntax module.

See the files INSTALL.txt for building and installation instructions. 

Home page: http://pa-do.forge.ocamlcore.org/


(* OASIS_STOP *)
