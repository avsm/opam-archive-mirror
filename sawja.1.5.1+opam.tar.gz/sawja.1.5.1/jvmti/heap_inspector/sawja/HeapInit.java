package sawja;
public class HeapInit{
    static int i =2; 

    public static void main(String args[]){
    }
}
