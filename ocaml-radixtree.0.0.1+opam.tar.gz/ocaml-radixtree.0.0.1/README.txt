(* OASIS_START *)
(* DO NOT EDIT (digest: e48da6ef58407552de38f9b1e3279a21) *)
This is the README file for the ocaml-radixtree distribution.

Radix tree for string

See the files INSTALL.txt for building and installation instructions. 


(* OASIS_STOP *)
