let () = Format.set_margin 15


let () = Format.printf "@[<3>@[(---@[<3>@[(--@ --@[( --@ --@,)@]@,)@]@]@,)@]@]@."

(*
let different fmt =
  let () = Format.printf fmt in
  let _ = Format.flush_str_formatter in
  let () = Format.pp_set_margin Format.str_formatter 10 in
  let () = Format.fprintf Format.str_formatter fmt in
  let s = Format.flush_str_formatter () in
  let () = Format.printf "%s" s in
  Printf.printf "%s" s

let () = different "@[<3>(---@[(--@ --@[( --@ --@,)@]@,)@]@,)@]@."



*)
