let x =
  object
    inherit foo
    method bar = _
  end
