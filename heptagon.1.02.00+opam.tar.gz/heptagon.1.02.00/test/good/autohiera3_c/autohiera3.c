/* --- Generated the 4/9/2015 at 17:28 --- */
/* --- heptagon compiler, version 1.00.06 (compiled fri. sep. 4 17:4:1 CET 2015) --- */
/* --- Command line: heptc -target c -s test -hepts autohiera3.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "autohiera3.h"

void Autohiera3__test_reset(Autohiera3__test_mem* self) {
  self->v_1 = false;
  self->v = Autohiera3__St_P1;
  self->pnr_1 = false;
  self->ck = Autohiera3__St_1_S1;
}

void Autohiera3__test_step(int r, int r1, int e, Autohiera3__test_out* _out,
                           Autohiera3__test_mem* self) {
  
  int nr_St_P2;
  Autohiera3__st ns_St_P2;
  int st_St_1_S2_St_P2;
  int nr_St_P1;
  Autohiera3__st ns_St_P1;
  int st_St_1_S2_St_P1;
  Autohiera3__st ck_1;
  Autohiera3__st ns;
  int r_1;
  int nr;
  int pnr;
  int nr_1_St_1_S2;
  Autohiera3__st_1 ns_1_St_1_S2;
  int st_St_1_S2;
  int nr_1_St_1_S1;
  Autohiera3__st_1 ns_1_St_1_S1;
  int st_St_1_S1;
  Autohiera3__st_1 ns_1;
  int r_2;
  int nr_1;
  r_2 = self->pnr_1;
  switch (self->ck) {
    case Autohiera3__St_1_S1:
      st_St_1_S1 = 0;
      if (r) {
        nr_1_St_1_S1 = true;
        ns_1_St_1_S1 = Autohiera3__St_1_S2;
      } else {
        nr_1_St_1_S1 = false;
        ns_1_St_1_S1 = Autohiera3__St_1_S1;
      };
      ns_1 = ns_1_St_1_S1;
      nr_1 = nr_1_St_1_S1;
      _out->st = st_St_1_S1;
      break;
    case Autohiera3__St_1_S2:
      if (r_2) {
        pnr = false;
      } else {
        pnr = self->v_1;
      };
      r_1 = pnr;
      if (r_2) {
        ck_1 = Autohiera3__St_P1;
      } else {
        ck_1 = self->v;
      };
      if (e) {
        nr_1_St_1_S2 = true;
        ns_1_St_1_S2 = Autohiera3__St_1_S1;
      } else {
        nr_1_St_1_S2 = false;
        ns_1_St_1_S2 = Autohiera3__St_1_S2;
      };
      ns_1 = ns_1_St_1_S2;
      nr_1 = nr_1_St_1_S2;
      switch (ck_1) {
        case Autohiera3__St_P1:
          st_St_1_S2_St_P1 = 1;
          if (r1) {
            nr_St_P1 = true;
            ns_St_P1 = Autohiera3__St_P2;
          } else {
            nr_St_P1 = false;
            ns_St_P1 = Autohiera3__St_P1;
          };
          st_St_1_S2 = st_St_1_S2_St_P1;
          ns = ns_St_P1;
          nr = nr_St_P1;
          break;
        case Autohiera3__St_P2:
          st_St_1_S2_St_P2 = 2;
          nr_St_P2 = false;
          ns_St_P2 = Autohiera3__St_P2;
          st_St_1_S2 = st_St_1_S2_St_P2;
          ns = ns_St_P2;
          nr = nr_St_P2;
          break;
      };
      _out->st = st_St_1_S2;
      self->v_1 = nr;
      self->v = ns;
      break;
  };
  self->pnr_1 = nr_1;
  self->ck = ns_1;;
}

