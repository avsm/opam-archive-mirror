#!/usr/bin/env sh

scp -r $@ scm.gforge.inria.fr:/home/groups/nunchaku/htdocs/
