(* OASIS_START *)
(* DO NOT EDIT (digest: b8e6cc9e1d07d9c2684e736dcb63cb9e) *)

tptp - TPTP format parsing
==========================

tptp is a library for reading and writing FOF and CNF formulas in TPTP
format. Library can process all problems and axioms from TPTP 6.2.0 which
don't contain line starting with "thf(" or "tff(".

See the file [INSTALL.txt](INSTALL.txt) for building and installation
instructions.

Copyright and license
---------------------

(c) 2012-2015 Radek Micek

tptp is distributed under the terms of the MIT License.

See [LICENSE.txt](LICENSE.txt) for more information.

(* OASIS_STOP *)
