Round-Robin Datasources (RRDs) for OCaml.

Requires [rpclib](https://github.com/samoht/ocaml-rpc)
