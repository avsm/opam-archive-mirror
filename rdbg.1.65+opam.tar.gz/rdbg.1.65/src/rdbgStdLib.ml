(* Time-stamp: <modified the 08/03/2016 (at 15:50) by Erwan Jahier> *)
open RdbgMain
open Event



(******************************************************************)
(* print_event stuff *)
let show_trace = ref true
let show_data = ref true
let show_src = ref false


let print_src_info_atoms (si:src_info_atom) = 
  let rec aux pref si =
    Printf.printf "file:%s::%i (%i-%i) '%s'\n" si.file
      (fst si.line) (fst si.char) (snd si.char) si.str ;
    match si.stack with
      | None -> ()
      | Some si ->  aux (pref ^ "   ") si
  in
    aux "" si

let (sinfo_to_string : Event.t -> string) = 
  fun e -> 
    match e.sinfo with
      | None  -> ""
      | Some si -> String.concat "&" (List.map (fun sia->sia.str) (si()).atoms)
 
let (print_src : Event.t -> unit) = 
  fun e -> 
    match e.sinfo with
      | None  -> ()
      | Some si -> List.iter print_src_info_atoms (si()).atoms

let (kind2str: Event.kind -> string) =
  function
    | Ltop -> "top " 
    | Call -> "call"
    | Exit -> "exit"
    | MicroStep str -> str

(* Which one should I use??? *)
let my_string_of_float = string_of_float
(* let my_string_of_float = Mypervasives.my_string_of_float *)

let print_event (e:Event.t) =
  let l = List.filter (fun (vn,_) ->  String.length vn < 4 || String.sub vn 0 4 <> "pre_") e.data in
  let l = List.map
            (fun (vn,v) -> if vn.[0] = '_' then "" else
                             vn^"="^(Data.val_to_string my_string_of_float v)) l 
  in
  let l = List.filter (fun s ->  s <> "") l in
  let vals = if !show_data then String.concat "," l else "" in 
  let blanks = String.make e.depth ' ' in
  let si_str = if !show_src then (" \""^(sinfo_to_string e)^"\"") else "" in
  Printf.printf "%3i %3i %s%s %-15s\t[%s]%s\n" e.nb e.step blanks
    (kind2str e.kind) e.name vals si_str;
  flush stdout

(******************************************************************)
(* hooks (functions that are called after each next) *)

let (hooks: (string, (Event.t -> unit)) Hashtbl.t) = Hashtbl.create 10

let add_hook = Hashtbl.replace hooks 
let del_hook = Hashtbl.remove hooks
let get_hook = Hashtbl.find hooks 
let del_all_hooks () = Hashtbl.clear hooks
let list_hooks () = Hashtbl.fold (fun s _ acc -> s::acc) hooks []
let _ = add_hook "print_event" (fun e -> if !show_trace then print_event e)

let (run : unit -> Event.t) =
  fun () -> 
    let e = RdbgMain.run () in
       Hashtbl.iter (fun _ f -> f e) hooks; 
      e

(******************************************************************)
(* Moving forward *)

let (next :Event.t -> Event.t) = 
  fun e -> 
    let ne = e.next () in
     Hashtbl.iter (fun _ f -> f ne) hooks; 
    ne

let rec (nexti : Event.t -> int -> Event.t) =
  fun e cpt -> 
    if cpt > 0 then nexti (next e) (cpt-1) else e

let rec (next_cond : Event.t -> (Event.t -> bool) -> Event.t) =
  fun e p -> 
    let ne = next e in
      if p ne then ne else (
        next_cond ne p
      )

let rec (goto_i : Event.t -> int -> Event.t) =
  fun e i -> 
    if e.nb < i then goto_i (next e) i else e


let rec loopforever e = loopforever (e.next ());;

let rec (step : Event.t -> Event.t) =
  fun e ->
    let cond ne = e.kind=ne.kind && e.name=ne.name && e.depth=ne.depth in
    next_cond e cond
        
let rec (stepi : Event.t -> int -> Event.t) =
  fun e cpt ->
    if cpt > 0 then stepi (step e) (cpt-1) else e

let rec (goto_s : Event.t -> int -> Event.t) =
  fun e i -> 
    if e.step < i then goto_s (step e) i else e

(******************************************************************)
(* Breakpoints stuff *)

let breakpoints = ref []
let (delete : unit -> unit) =
  fun () -> 
    breakpoints := []

let (break : string -> unit) =
  fun str ->
  breakpoints := str::!breakpoints;;


let (break_matches : Event.t -> string -> bool) =
  fun e b -> 
    (* b ougth to be of the form:
       "node"
       "node::line"
       "file"
       "file::line"
    *)
    let si_match_file str si =
      (si.file = str || Filename.basename si.file = str) 
    in
    let si_match_line ln {line=(d,f)}  =
      let i = try int_of_string ln with _ -> -1 in
        (d <= i && i <= f)
    in
      match e.sinfo, Str.split (Str.regexp "::") b with
        |  _, [] -> false  (* no more breakpoints *)
        | None, _ -> false (* no source info at the current event *)
        | Some src, str::tail ->
          let src = src() in
            if Sys.file_exists str then
              match tail with
                | [ln] -> 
                    List.exists 
                      (fun si -> si_match_file str si && si_match_line ln si) src.atoms
                | [] ->  List.exists (si_match_file str) src.atoms
                | _  -> false
            else (* str file not exist. Maybey it's a node *)
              e.name = str && 
        (match tail with
           | [] -> true
           | [ln] -> List.exists (si_match_line ln) src.atoms
           | _ -> false         
        )

let (goto_brk : Event.t -> string -> Event.t) =
  fun e b -> 
    next_cond e (fun e -> break_matches e b)
    

let (continue : Event.t -> Event.t) =
  fun e -> 
    let stop e = List.exists (break_matches e) !breakpoints in
      next_cond e stop

(******************************************************************)
(* Accessing data *)

let (v:string -> Event.t -> Data.v) =
  fun n e  -> 
    if not (List.mem_assoc n e.data) then
      failwith ("No variable named " ^n^" exists")
    else
     List.assoc n e.data

let (vi:string -> Event.t -> int) =
  fun n e  -> 
    if not (List.mem_assoc n e.data) then
      failwith ("No variable named " ^n^" exists")
    else
    match List.assoc n e.data with
      | Data.I i -> i
      | _ -> failwith (n^" is not an int")
let (vf:string -> Event.t -> float) =
  fun n e -> 
    if not (List.mem_assoc n e.data) then
      failwith ("No variable named " ^n^" exists")
    else
    match List.assoc n e.data with
      | Data.F f -> f
      | _ -> failwith (n^" is not a float")


let (vb:string -> Event.t -> bool) =
  fun n e -> 
    if not (List.mem_assoc n e.data) then
      failwith ("No variable named " ^n^" exists")
    else
      match List.assoc n e.data with
        | Data.B b -> b
        | _ -> failwith (n^" is not a bool")

(******************************************************************)
(* A rather naive time travel mechanism  *)

let ckpt_rate = ref 100

let ckpt_tbl = Hashtbl.create 100

let check_point e =
  if e.nb mod !ckpt_rate = 0 || e.nb = 1 then 
    let x = (e.nb / !ckpt_rate) in 
(*       Printf.printf "Add entry nb %i (event nb %i)\n" x e.nb; *)
(*       flush stdout; *)
      Hashtbl.add ckpt_tbl x e

let (time_travel : bool -> unit) = 
  fun on -> 
    if on then add_hook "time_travel" check_point
          else del_hook "time_travel"



(* move backwards until a cond is reached *)
let (rev_cond : Event.t -> (Event.t -> bool) -> Event.t) =
  fun e p -> 
    let rec rev_aux e i =
       (* search if there exist an event e' in ]e.nb;i[ s.t. p e *)
(*       let _ =  *)
(*         Printf.printf "rev_aux e.nb=%i i=%i\n" e.nb i; *)
(*         assert (e.nb <= i); *)
(*         flush stdout; *)
(*       in *)
      let e = if p e then e else next_cond e (fun e -> p e || e.nb = i) in
        if p e then 
          rev_aux_last e e i (* search for a more recent one *)
        else (* e.nb = i *)
          let x = (e.nb / !ckpt_rate - 1) in
            if x < 0 then
              (print_string "No suitable event found\n";
               Hashtbl.find ckpt_tbl 0
              )
            else 
              let e = Hashtbl.find ckpt_tbl x in
              rev_aux e ((x+1) * !ckpt_rate -1)
    and rev_aux_last e e_good i =
      (* search if there exist an event e in ]e_good.n;i[ s.t. p e *)
(*       let _ =  *)
(*         Printf.printf "rev_aux_last e.nb=%i e_good.nb=%i i=%i\n" e.nb e_good.nb i; *)
(*         flush stdout; *)
(*       in *)
        if e.nb = i then e_good else 
          let e = next_cond e (fun e -> p e || e.nb = i) in
          let e_good = if p e then e else e_good in
            rev_aux_last e e_good i
    in
      if e.nb = 1 then 
        failwith "Cannot move backwards from the first event.\n" 
      else
        let x = ((e.nb - 1)/ !ckpt_rate) in
        let last_e = Hashtbl.find ckpt_tbl x in
          rev_aux last_e (e.nb-1)


(* move backwards until a breakpoint is reached *)
let (rev : Event.t -> Event.t) =
  fun e -> 
    let stop e = List.exists (break_matches e) !breakpoints in
      rev_cond e stop

let stop_at i e = e.nb = i;;

let (back : Event.t -> Event.t) =
  fun e -> 
    let stop ce =  (ce.nb = e.nb - 1) in
    let e = rev_cond e stop in
      e


let (goto : Event.t -> int -> Event.t) =
  fun e i -> 
    if i > e.nb then goto_i e i else if e.nb = i then e else
      let x = ((e.nb-1) / !ckpt_rate ) in
      let e = Hashtbl.find ckpt_tbl x in
        rev_cond e (fun e -> e.nb = i)



