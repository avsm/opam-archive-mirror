(* Time-stamp: <modified the 10/02/2016 (at 14:32) by Erwan Jahier> *)

open Mypervasives
open RdbgArg

type vars = (Data.ident * Data.t) list

(**********************************************************************************)

let debug_msg msg =     
  if args.debug_rdbg then (output_string stdout (msg^"\n"); flush stdout)


let (step_channel : string -> in_channel -> out_channel -> vars -> vars ->
     Data.subst list -> Data.subst list) =
  fun label ic oc in_vars out_vars sl ->
    let my_string_of_float v = Mypervasives.my_string_of_float v args.precision in
    let in_vals_str =
      List.fold_left
        (fun acc (name, _) ->
          try
            let value = List.assoc name sl in
            acc ^ " "^ (Data.val_to_string my_string_of_float value)
          with Not_found -> acc
        )
        ""
        in_vars
    in
    let res =
      debug_msg  (label ^ " receives '" ^ in_vals_str ^"'.\n");
      output_string oc (in_vals_str ^"\n");
      flush oc;
      RifIO.read ~debug:args.debug_rdbg ~label:("read the result of "^label) ic None out_vars
    in
    res

open RdbgPlugin

let (make : string -> RdbgPlugin.t) =
  fun cmd ->     
    let (stdin_in,  stdin_out) = Unix.pipe () in
    let (stdout_in, stdout_out) = Unix.pipe () in
    let cmd_ic = Unix.in_channel_of_descr stdout_in in
    let cmd_oc = Unix.out_channel_of_descr stdin_out in
    let _ =  set_binary_mode_in  cmd_ic false; set_binary_mode_out cmd_oc false in
    let arg_list = Str.split (Str.regexp " ") cmd in
    let arg_list = List.filter (fun str -> str<>"") arg_list in
    let prog = List.hd arg_list in
    let label = Printf.sprintf "from %s" prog in
    let pid_cmd =
      let arg_array = Array.of_list arg_list in
      try 
        if args.debug_rdbg then ( 
	       output_string stderr label; 
	       List.iter (fun x -> output_string stderr (x ^ " ")) arg_list;
	       output_string stderr "\n"; 
          flush stderr
        );
        Unix.create_process prog arg_array stdin_in stdout_out stdout_out
      with Unix.Unix_error(e,_, prog) -> 
        let msg = Unix.error_message e in
        Printf.eprintf "*** Error when creating process with %s: %s\n" prog msg;
        exit 2
    in
    let cmd_in, cmd_out = 
      try
        if args.debug_rdbg then (
          Printf.fprintf stderr "\nWait for interface declarations on stdin (%s).\n" cmd; 
          flush stderr);
        RifIO.read_interface ~debug:args.debug_rdbg ~label:label cmd_ic (Some stderr)
(*                              (if args.debug_rdbg then Some stderr else None) *)
      with RifIO.Bye -> exit 2
    in
    let _ =
      if args.debug_rdbg then (
        Printf.fprintf stderr "\nInterface declarations: ok.\n"; flush stderr);
      Printf.eprintf "Process %d (%s) created\n" pid_cmd cmd; flush stderr in
    let kill msg =
      (* Printf.print "EOF" *)
      Unix.close stdin_in;
      Unix.close stdin_out;
      Unix.close stdout_in;
      Unix.close stdout_out;
      (try 
         Printf.eprintf "%s\nKilling process %d\n" msg pid_cmd;
         flush stderr;
         Unix.kill pid_cmd Sys.sigterm 
       with e -> (Printf.printf "Killing %s process failed: %s\n" prog (Printexc.to_string e) ))
    in
    let step = 
      if args.debug_rdbg then (Printf.fprintf stderr "\nStep %s.\n" cmd; flush stderr);
      step_channel (prog) cmd_ic cmd_oc cmd_in cmd_out in
    let step_dbg sl ctx cont =
      {
        Event.nb = ctx.Event.nb;
        Event.step  = ctx.Event.step;
        Event.depth = ctx.Event.depth;
        Event.data  = ctx.Event.data;
        Event.terminate = ctx.Event.terminate;
        
        Event.kind = Event.Exit;
        Event.lang = "stdio";
        Event.sinfo = None;
        Event.name=prog;
        Event.inputs = [] ;
        Event.outputs = [];
        Event.next = (
          fun () ->  
          let ctx = { ctx with Event.nb = ctx.Event.nb+1 } in
          cont (step sl) ctx );
      }
    in 
    {
      id = "cmd";
      inputs = cmd_in;
      outputs= cmd_out;
      kill=kill;
      init_inputs=[];
      init_outputs=[];
      step=step;     
      step_dbg=step_dbg;
    }


(* exported *)
let (make_init : string -> RdbgPlugin.t) =
  fun cmd -> 
    assert false
(*     let sock_in, vars_in, vars_out, kill, step, step_dbg = make_socket_do sock_adr port in *)
(*     let out_init = RifIO.read ~debug:args.debug_rdbg sock_in None vars_out in *)
(*     let in_init = RifIO.read  ~debug:args.debug_rdbg sock_in None vars_in in *)
(*       vars_in, vars_out, kill, step, step_dbg, in_init, out_init *)
