(* Time-stamp: <modified the 09/03/2016 (at 17:19) by Erwan Jahier> *)
(* A simple wrapper around rdbg-top to avoid typing "()" and
   ";;" 

*)

let add_semi_ref = ref true

let rdbg_top = "rdbg-top" 

let usage = ( Sys.argv.(0) ^ " is an experimental wrapper around the ocaml toplevel rdbg-top.
It basically performs 2 things.

(1) It generates a rdbg-session.ml file template (if not already existing)

For example, try:
  rdbg -sut \"lus2lic file.lus -n node\" -env \"lutin f.lut -n main\"

nb: currently works for 'lus2lic' and 'lutin' only.

(2) It discharges users from writting \"()\" and \";;\" before rdbg commands.
This wrapping is
  - turned on/off by the '#auto_on'/'#auto_off directives';
  - locally inhibited for lines beginning with the ' ' character.

usage:"^ Sys.argv.(0) ^" [options] [ocaml script files]
where 
 [ocaml files] are evaluated by rdbg-top
 [options] are:")


let help () =  print_string usage; flush stdout


let verbose = ref true
let suts = ref []
let envs = ref []

let rec speclist =
  [
    "--quiet",Arg.Unit (fun _ -> (verbose := false)),
    "\t don't echo the commands sent to rdbg-top";

    "-sut",Arg.String (fun str -> (suts :=  str::!suts)), "<string> add a sut" ; 
    "-env",Arg.String (fun str -> (envs :=  str::!envs)), "<string> add an env" ; 

    "-h", Arg.Unit (fun _ -> (Arg.usage speclist usage; exit 0)), " ";
    "-help", Arg.Unit (fun _ -> (Arg.usage speclist usage ; exit 0)), "  ";
    "--help", Arg.Unit (fun _ -> (Arg.usage speclist usage ; exit 0)),  
    "\t display this help message"

  ]


let get_extension f =
  try
    let bf = Filename.chop_extension f in
    let lf,lbf = String.length f, String.length bf in
    String.sub f (lbf+1) (lf - lbf - 1)
  with _ -> ""

let args= ref []
let ml_files = ref []

let add_args arg = 
  if get_extension arg = "ml" 
  then 
    ml_files := arg::!ml_files 
  else
    args := (arg::!args)

let local_opt = List.map (fun (x,_,_) -> x) speclist

let other_args:string = 
  Arg.parse speclist add_args usage;
  String.concat " " (List.rev !ml_files)

let cmd = rdbg_top ^ " -I +rdbg-plugin " ^ other_args
let oc = 
  if !verbose then (
    print_string ("  - "^Sys.argv.(0)^" communicates with the process \""^cmd^"\"\n"); 
    flush stdout
  );
  Unix.open_process_out cmd

let rec my_read_line () =
  let str = read_line () in
  match str with
    | "#auto"  -> 
      add_semi_ref:= true;
      print_string "type '#auto_off' to disable automatic semicolumn mode\n";
      flush stdout;
      my_read_line ()
    | "#auto_off" -> 
      add_semi_ref:= false; 
      print_string "type '#auto' to enable automatic semicolumn mode\n";
      flush stdout;
      my_read_line ()
    | _ -> str
  
(**********************************************************************************)
(* generete a rdbg-session.ml *)

let prolog = "
open Event;;
open RdbgStdLib;;
open RdbgArg;;
open RdbgRun;;
open RdbgMain;;

#use \"topfind\";; 
#require \"rdbg-plugin\";;
"

let gen_plugin_def oc name str =
  let args = Str.split (Str.regexp " ") str in
  let tool = Filename.basename (List.hd args) in
  let args_str = String.concat ";" (List.map (fun s -> "\""^s^"\"") args) in
  let make_str =
    match tool with
    | "lutin" -> output_string oc "#require \"lutin\";;\n"; "LutinRun.make"
    | "lus2lic" -> output_string oc  "#require \"lustre-v6\";;\n"; "Lus2licRun.make"
    |  _ -> 
        print_string (str^" not supported by the rdbg wrapper\n"); 
        flush stdout; 
        ""
  in
  if make_str <> "" then (
    Printf.fprintf oc "
let %s = 
  let args = [%s] in
  let aargs = Array.of_list args in
  %s aargs
;;
" name args_str make_str;
  flush oc)

let gen_arg_fill oc suts_or_envs plugin_list =
    Printf.fprintf 
      oc "args.%s <- [%s];;\n" 
      suts_or_envs
      (String.concat ";" (List.map (fun n-> "Ocaml("^n^")") plugin_list))
 

let epilog = "
(* let e = run();; *)
       
let e = ref (run());;
let n () = e:=next !e;;
let ni i = e:= nexti !e i;;
"
let gen_rdbg_session_content oc =
  let give_unique_name (i, acc_names, acc_calls) str =  
      let name = Printf.sprintf "plugin_%i" i in
      (i+1, name::acc_names, str::acc_calls)
  in
  let i, sut_names, sut_calls = 
    List.fold_left give_unique_name (0, [],[]) !suts
  in
  let _, env_names, env_calls = 
    List.fold_left give_unique_name (i,[],[]) !envs
  in
  output_string oc prolog;
  List.iter2 (gen_plugin_def oc) sut_names sut_calls;
  List.iter2 (gen_plugin_def oc) env_names env_calls;
  gen_arg_fill oc "suts" sut_names;
  gen_arg_fill oc "envs" env_names;
  output_string oc epilog;
  flush oc


(**********************************************************************************)

let rec myloop () =
  let str = my_read_line () in
  let str = 
    (* a clutch I'd prefer to avoid *)
    if str = "man" then "RdbgMain.man" else str in
  let add_par = if String.contains str ' ' then "" else "()" in
  let no_semicol = not (Str.string_match (Str.regexp ";;[ \t]+$") str 0) in
  let semi = if !add_semi_ref && no_semicol && 
                  str <> "" && str.[0] <> ' ' then ";;" else "" in
  if str = "q" || str = "quit" then (
    ignore (Unix.close_process_out oc); exit 0) 
  else (
  if !verbose then (
    output_string stdout  ("sending to rdbg-top[" ^str ^ add_par ^ semi ^ "]\n");
    flush stdout
  );
  output_string oc (str ^ add_par ^ semi ^ "\n");
  flush oc;
  myloop ()
  ) 

let _ =   
  try
(*     output_string oc "open RdbgMain;;\n";  *)
(*     output_string oc "print_string \"\n  HINT: issue a \n#use \\\"rdbg-session.ml\\\"\n\"; flush stdout;; *)
(* "; *)
(*     flush oc;  *)
    let info() = 
      print_string "\n  - To use it, evaluate the directive:\n#use \"rdbg-session.ml\" \n";
    in
    let rdbg_session = "rdbg-session.ml" in
      if Sys.file_exists rdbg_session then (
        if !verbose then (
          print_string "  - The file \"rdbg-session.ml\" already exists. ";
          info();
          flush stdout) else ()
      ) 
      else (
        let foc = open_out rdbg_session in
        gen_rdbg_session_content foc;
        close_out foc;
        print_string ("  - The file \""^rdbg_session ^ "\" has just been generated. ");
        info();
        flush stdout
      );
    
    print_string "  - type 'man' for more help\n\n"; 
    flush stdout;
    myloop ()
  with 
    | End_of_file -> Printf.printf "bye.\n"; flush stdout
    | e  -> 
      Printf.eprintf "Error in rdbg: %s\n" (Printexc.to_string e);
      flush stderr
