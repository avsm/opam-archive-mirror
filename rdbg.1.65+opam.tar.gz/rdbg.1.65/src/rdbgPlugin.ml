(* Time-stamp: <modified the 10/02/2016 (at 14:24) by Erwan Jahier> *)

type sl = ( string * Data .v) list (* substitutions *)
type e = Event .t
type t = {
  id: string;
  inputs  : (Data.ident * Data.t) list; (* name and type *)
  outputs : (Data.ident * Data.t) list; (* ditto *)
  kill: string -> unit;
  init_inputs  : sl;
  init_outputs : sl;
  step     : (sl -> sl); (* Lurette step *) 
  step_dbg : (sl -> e -> ( sl -> e -> e) -> e); (* RDBG step *)
}

let dummy = {
  id = "dummy";
  inputs = [];
  outputs= [];
  kill= (fun _ -> ());
  init_inputs=[];
  init_outputs=[];
  step= (fun sl -> assert false);     
  step_dbg=(fun _ _ -> assert false); 
}
