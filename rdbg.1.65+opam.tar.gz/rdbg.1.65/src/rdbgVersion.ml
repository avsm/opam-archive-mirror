let str="1.65"
let sha="8ec1ae5"
