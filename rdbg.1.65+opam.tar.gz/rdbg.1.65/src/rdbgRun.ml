(* Time-stamp: <modified the 08/03/2016 (at 15:54) by Erwan Jahier> *)

open Mypervasives
open RdbgArg

type vars = (Data.ident * Data.t) list
  
(* to be able to dump cov info if the exec is stopped by a ctrl-c. *)
let cov_ref = ref None
let gnuplot_pid_ref = ref None
let gnuplot_oc = ref None

(* Returns luciole io if necessary *)
let (check_compat : vars -> vars -> vars -> vars -> vars -> vars ->
                    int * (vars * vars) option) =
  fun env_in env_out sut_in sut_out oracle_in oracle_out -> 
    (* cf lurette.set_luciole_mode_if_necessary to add a call to luciole *)
    
    let missing_sut_in = list_minus sut_in env_out
    and missing_env_in = list_minus env_in sut_out
    and missing_oracle_in = list_minus oracle_in (sut_out @env_out)  in
    let luciole_out = list_union missing_sut_in missing_env_in in 
    let luciole_in = list_minus (env_out@sut_out) luciole_out in 
    (*     let luciole_in = [] in  *)
    
    let vars_to_string vars = String.concat "," 
      (List.map (fun (n,t) -> n^":"^(Data.type_to_string t)) vars) 
    in
    if missing_sut_in <> [] then (
      let missing_str = vars_to_string missing_sut_in in
      Printf.eprintf "Some variables are missing in input of the SUT: %s\n" 
                     missing_str;
      flush stderr
    ) ;
    if missing_env_in <> [] then (
      let missing_str = vars_to_string missing_env_in in
      Printf.eprintf "Some variables are missing in input of its environment : %s\n" 
                     missing_str;
      flush stderr;
    );
    if luciole_out <> [] then (
      0, Some(luciole_in,luciole_out)
    ) 
    else if missing_oracle_in <> [] then (
      let missing_str = vars_to_string missing_oracle_in in
      Printf.eprintf "Some variables are missing in input of the oracle: %s\n" 
                     missing_str;
      flush stderr;
      2,None
    ) 
    else (
      if List.mem ("Step") (fst(List.split luciole_in)) then (
        Printf.eprintf 
          "*** You cannot use the name 'Step' for a variable with rdbg, sorry.\n";
        flush stderr;
        2,None
      ) else (
        Printf.eprintf "Variables are compatible.\n";
        flush stderr;
        0, None
      )
    )

open RdbgPlugin

type ctx = Event.t
type e = Event.t

let (make_rp_list : reactive_program list -> 
     vars list * vars list * (string -> unit) list * 
       (Data.subst list -> Data.subst list) list * 
       (Data.subst list -> ctx -> (Data.subst list -> ctx -> e) -> e) list *
       Data.subst list list * Data.subst list list) =
  fun rpl -> 
    let aux rp = 
      let plugin =
        match rp with
          | Stdio(cmd)     -> StdioRun.make cmd 
          | StdioInit(cmd) -> StdioRun.make_init cmd 
          | Ocaml(plugin)  -> plugin
      in
      let ins, outs, kill, step, step_dbg, initin, initout =  
        plugin.inputs,plugin.outputs,plugin.kill,plugin.step,plugin.step_dbg,
        plugin.init_inputs,plugin.init_outputs
      in
      let step = if args.debug_rdbg then 
          let (string_of_subst : Data.subst -> string) =
            fun (str, v) -> str ^ "<-" ^ (Data.val_to_string (string_of_float) v)
          in
          let sl2str sl = String.concat "," (List.map string_of_subst sl) in
          (fun sli  -> 
            let slo = step sli in
            Printf.eprintf "[%s] step(%s) = (%s) \n" 
              (reactive_program_to_string rp) (sl2str sli) (sl2str slo);
            flush stderr;
            slo)
        else 
          step 
      in
      ins, outs, kill, step, step_dbg, initin, initout     
    in
    Mypervasives.list_split7 (List.map aux rpl)
    

type cov_opt = 
    NO (* NoOracle *) 
  | OO (* OracleOnly *) 
  | OC of Coverage.t
exception OracleError of string
exception SutStop of cov_opt

(* Transform a map on a function list into CPS *)
let (step_dbg_sl :
       ('s list -> 'ctx -> ('s list -> 'ctx -> 'e) -> 'e) list -> 
       's list -> 'ctx  -> ('ctx -> 's list -> 'e) -> 'e) = 
  fun step_dbg_sl_l sl ctx cont -> 
    (* ouch! Celle-la est chevelue...  
       La difficulté, c'est de passer un 'List.map step' en CPS.
       Suis-je aller au plus simple ? En tout cas j'ai réussit :)
    *)
    let rec (iter_step  : 
               ('s list -> 'ctx  -> ('s list -> 'ctx  -> 'e) -> 'e) list -> 
              ('ctx * 's list list) -> 's list -> 'e) = 
      fun stepl (ctx,res_stepl) sl ->
        match stepl with
          | [] -> cont ctx (List.flatten (res_stepl))
          | step::stepl ->
             step sl ctx (fun res_sl ctx -> 
                          iter_step stepl (ctx,(res_sl::res_stepl)) sl)
    in
      iter_step step_dbg_sl_l (ctx,[]) sl 


let (start : unit -> e) =
  fun () ->
    if args.verbose > 0 then (Printf.printf "# RdbgRun.start()\n"; flush stdout);
    let sut_in_l, sut_out_l, sut_kill_l, sut_step_sl_l, sut_step_dbg_sl_l, 
      sut_init_in_l, sut_init_out_l = make_rp_list args.suts 
    in
    let sut_kill msg = List.iter (fun f -> f msg) sut_kill_l in
    let sut_init_in = List.flatten sut_init_in_l in
    let sut_init_out = List.flatten sut_init_out_l in

    (* Get oracle info (var names, step func, etc.)*)
    let oracle_in_l, oracle_out_l, oracle_kill_l, oracle_step_sl_l, 
        oracle_step_dbg_sl_l, _, _ = make_rp_list args.oracles
    in
    let oracle_kill msg = List.iter (fun f -> f msg) oracle_kill_l in
    
    (* Get env info (var names, step func, etc.)*)
    let env_in_l, env_out_l, env_kill_l, env_step_sl_l, env_step_dbg_sl_l, 
      env_init_in_l, env_init_out_l = make_rp_list args.envs 
    in
    let env_kill msg = List.iter (fun f -> f msg) env_kill_l in
    let _env_init_in = list_rm_dup (List.flatten env_init_in_l) in
    let _env_init_out = list_rm_dup (List.flatten env_init_out_l) in

    let vars_to_string l = 
      String.concat "\n"
        (List.map (fun (vn,vt) -> Printf.sprintf "\t%s:%s" vn (Data.type_to_string vt)) l)
    in
    let flat_sut_in  = list_rm_dup (List.flatten sut_in_l)
    and flat_sut_out = list_rm_dup (List.flatten sut_out_l)
    and flat_env_in  = list_rm_dup (List.flatten env_in_l)
    and flat_env_out = list_rm_dup (List.flatten env_out_l)
    and flat_oracle_in  = list_rm_dup (List.flatten oracle_in_l)
    and flat_oracle_out = list_rm_dup (List.flatten oracle_out_l)
    in
    let _ = if args.verbose > 0 || args.debug_rdbg then
        let sut_input_str = vars_to_string flat_sut_in in
        let sut_output_str = vars_to_string flat_sut_out in
        let env_input_str = vars_to_string  flat_env_in in
        let env_output_str = vars_to_string flat_env_out in
        let oracle_input_str = vars_to_string flat_oracle_in in
        let oracle_output_str_l = List.map vars_to_string oracle_out_l in
        Printf.printf "sut input : \n%s\n"  sut_input_str;
        Printf.printf "sut output : \n%s\n" sut_output_str;
        Printf.printf "env input : \n%s\n"  env_input_str;
        Printf.printf "env output : \n%s\n"  env_output_str;
        Printf.printf "oracle(s) input : \n%s\n"  oracle_input_str;
        List.iter (fun str -> Printf.printf "oracle output : \n%s\n" str)
                  oracle_output_str_l;
        flush stdout
    in
    (* Check var names and types compat. *)
    let res_compat, luciole_io_opt = 
      check_compat
        flat_env_in flat_env_out flat_sut_in flat_sut_out flat_oracle_in flat_oracle_out 
    in
    let (luciole_kill, luciole_step), luciole_outputs_vars =
      match luciole_io_opt with
        | None -> ((fun _ -> ()),(fun _ -> [])),[]
        | Some (luciole_in, luciole_out) -> 
          let luciole_in_string =
            List.map (fun (n,t) -> n,Data.type_to_string t) luciole_in
          and luciole_out_string=
            List.map (fun (n,t) -> n,Data.type_to_string t) luciole_out
          in
          (if args.luciole_mode then 
             (Printf.eprintf "read missing inputs from luciole\n";flush stderr;
              LucioleRun.make "./rdbg_luciole.dro" luciole_in_string luciole_out_string)
           else
             (Printf.eprintf "read missing inputs from stdin\n";flush stderr;             
              RifRun.make luciole_in_string luciole_out_string)) , 
          luciole_out
    in
    let cov_init = (* XXX faut-il renommer les sorties de l'oracle 
                          ou raler en cas de clash ? *)
      if List.flatten oracle_out_l = [] then NO else 
        let oracle_out = List.flatten (List.map List.tl oracle_out_l) in
        if List.length oracle_out < 1 then OO else 
          let is_bool (_,t) = (t = Data.Bool) in
          let names = List.filter is_bool oracle_out in
          let names = fst (List.split names) in
          OC (Coverage.init names args.cov_file args.reset_cov_file)
    in
    let oc = open_out args.output in
    let sim2chro_oc = if args.display_sim2chro then ExtTool.sim2chro_dyn () 
      else (open_out "/dev/null") in
    (* open_out "/dev/null" in *)
    let filter vals vars = 
      let vars = List.filter (fun (n,_) -> List.mem_assoc n vals) vars in
      List.map (fun (n,t) -> n, List.assoc n vals) vars
    in
    let rec check_oracles oracle_in_vals i oracle_out_l oracle_out_vals_l cov =
      let check_one_oracle = function 
        | [] -> assert false
        | (_, Data.B true)::tail -> tail
          
        | (_, Data.B false)::tail ->
          let msg = 
            match cov with 
                OC cov -> Coverage.dump_oracle_io oracle_in_vals tail cov 
              | _ -> ""
          in
          let msg = Printf.sprintf 
                      "\n*** The oracle returned false at step %i\n%s" i msg 
          in
          print_string msg;
          flush stdout;
          if args.stop_on_oracle_error then raise (OracleError msg) else tail

        | (vn, vv)::_  -> 
          let vv = Data.val_to_string_type vv in
          let msg = Printf.sprintf 
            "The oracle first output should be a bool; but %s has type %s" vn vv in
          failwith msg
      in
      match cov with 
          NO -> NO
        | OO -> ignore (List.map check_one_oracle oracle_out_vals_l); OO
        | OC cov -> 
          let ll = List.map check_one_oracle oracle_out_vals_l in
          let cov =
            List.fold_left
              (fun cov other_oracle_out_vals ->
                Coverage.update_cov other_oracle_out_vals cov) cov ll
          in
          cov_ref := Some cov;
          OC cov
    in
    let update_cov cov = 
      match cov with 
        | NO -> ()
        | OO -> ()
        | OC cov -> 
          let str =
            String.concat ", " (List.map reactive_program_to_string args.oracles)
          in
          Coverage.dump str args.output cov
    in
    (* The main loop *)
    let killem_all cov = 
      env_kill "quit\n";
      sut_kill "quit\n";
      luciole_kill "quit\n";
      oracle_kill "quit\n";
      close_out oc;
      close_out sim2chro_oc;
      update_cov cov;
    in
    let rec loop cov env_in_vals pre_env_out_vals ctx () =
      if ctx.Event.step > args.step_nb then 
        (killem_all cov; raise (Event.End ctx.Event.nb) ) 
      else
        let luciole_outs = luciole_step (env_in_vals@pre_env_out_vals) in
        let env_in_vals =  List.rev_append luciole_outs env_in_vals in
        if args.rdbg then 
          (* XXX l'idéal serait de faire ce test une seule fois à
             l'exterieur de la boucle en passant la fonction qui va
             bien selon le mode. Apres tout, c'est l'un des avantages
             des CPS... Une autre solution serait de tout dupliquer,
             mais bon, c'est mal.  *)
          let edata = env_in_vals@pre_env_out_vals in
          let ctx = 
            { ctx with 
              Event.name = "rdbg";
              Event.depth = 1;
              Event.data = edata;
            }
          in
          let cont ctx = loop2 cov env_in_vals pre_env_out_vals ctx luciole_outs in
          step_dbg_sl env_step_dbg_sl_l env_in_vals ctx cont
        else
          try 
            let env_step_sl sl = List.flatten (List.map (fun f -> f sl) env_step_sl_l) in
            let env_out_vals = env_step_sl env_in_vals in
            loop2 cov env_in_vals pre_env_out_vals ctx luciole_outs env_out_vals
          with 
            RifIO.Bye -> killem_all cov; raise RifIO.Bye
    and
        loop2 cov env_in_vals pre_env_out_vals ctx luciole_outs env_out_vals =
      let env_out_vals = 
        try List.map (fun (v,vt) -> v,List.assoc v env_out_vals) flat_env_out 
        with Not_found -> env_out_vals
      in
      let env_out_vals = luciole_outs @ env_out_vals in
      let sut_in_vals = filter env_out_vals flat_sut_in in        
      if args.rdbg then       
        let edata = sut_in_vals@ env_out_vals in
        let ctx = { ctx with 
          Event.name = "rdbg";
          Event.depth = 1;
          Event.data = edata;
        } 
        in
        let cont ctx = loop3 cov env_in_vals pre_env_out_vals env_out_vals ctx
                         luciole_outs in
        step_dbg_sl sut_step_dbg_sl_l sut_in_vals ctx cont
      else
        let sut_step_sl sl = List.flatten (List.map (fun f -> f sl) sut_step_sl_l) in
        let sut_out_vals = sut_step_sl sut_in_vals in
        loop3 cov env_in_vals pre_env_out_vals env_out_vals ctx luciole_outs 
              sut_out_vals
    and loop3 cov env_in_vals pre_env_out_vals env_out_vals ctx luciole_outs 
              sut_out_vals =
      let sut_out_vals = 
        try List.map (fun (v,vt) -> v,List.assoc v sut_out_vals) flat_sut_out 
        with Not_found -> sut_out_vals
      in
      let oracle_in_vals = 
        if args.delay_env_outputs 
        then List.rev_append pre_env_out_vals sut_out_vals 
        else List.rev_append     env_out_vals sut_out_vals 
      in
      let oracle_in_vals = List.rev_append luciole_outs oracle_in_vals in
      let oracle_in_vals = filter oracle_in_vals flat_oracle_in in
      let oracle_out_vals_l = List.map (fun f -> f oracle_in_vals) oracle_step_sl_l in

      (*       let oracle_out_vals = List.flatten oracle_out_vals_l in *)
      let oracle_out_vals_l = 
        try List.map2 
              (fun oracle_out oracle_out_vals -> 
                List.map (fun (v,vt) -> v,List.assoc v oracle_out_vals) oracle_out
              ) 
              oracle_out_l
              oracle_out_vals_l
        with Not_found -> oracle_out_vals_l
      in
      let my_string_of_float v = Mypervasives.my_string_of_float v args.precision in
      let print_val (vn,vv) = Data.val_to_string my_string_of_float vv  in
      (*       Printf.fprintf oc "#step %d\n" i; *)
      output_string oc ("#step "^(string_of_int ctx.Event.step)^"\n");
      if args.delay_env_outputs then (
        output_string oc (String.concat " " (List.map print_val (pre_env_out_vals)));
        output_string sim2chro_oc 
                      (String.concat " " (List.map print_val (pre_env_out_vals)));
      )
      else (
        output_string oc (String.concat " " (List.map print_val env_out_vals));
        output_string sim2chro_oc (String.concat " " (List.map print_val env_out_vals));
      );
      output_string oc (if env_out_vals <> [] then " #outs " else "#outs ");
      output_string oc (String.concat " " (List.map print_val sut_out_vals));
      output_string oc "\n";
      List.iter (fun l -> 
        output_string oc "#oracle_outs ";
        output_string oc (String.concat " " (List.map print_val l));
        output_string oc "\n";
      ) oracle_out_vals_l;
      flush oc;

      output_string sim2chro_oc "#outs ";
      output_string sim2chro_oc (String.concat " " (List.map print_val sut_out_vals));
      output_string sim2chro_oc "\n";
      flush sim2chro_oc;
      
      if not args.go && args.display_gnuplot then (
        if ctx.Event.nb = 1 then (
          let oc, pid = 
            GnuplotRif.terminal := GnuplotRif.Wxt;
            GnuplotRif.verbose := args.verbose>1;
            GnuplotRif.dynamic := true;
            GnuplotRif.rif_file := args.output;
            GnuplotRif.f ()
          in
          gnuplot_pid_ref := Some pid;
          gnuplot_oc := Some oc
        ) 
        else 
          (match !gnuplot_oc with
            | None -> ()
            | Some oc -> output_string oc "replot\n"; flush oc)
      );
      let step_nb = ctx.Event.step in
      let en = ctx.Event.nb in
      let edata = sut_out_vals@env_out_vals@(List.flatten oracle_out_vals_l) in
      let term () = 
        (match !gnuplot_pid_ref with
            | None -> ()
            | Some pid ->
              print_string "Killing gnuplot...\n"; flush stdout;
              Unix.kill pid Sys.sigkill;
              gnuplot_oc := None;
              gnuplot_pid_ref := None); 
          killem_all cov
      in
      let ctx = { ctx with 
                  Event.nb = en+1;
                  Event.step = step_nb+1;
                  Event.name = "rdbg";
                  Event.depth = 1;
                  Event.data = edata;
                  Event.terminate = term;
                } 
      in
      if args.rdbg then (
        {
          Event.step = step_nb;
          Event.name = ctx.Event.name;
          Event.depth= ctx.Event.depth;
          Event.data = ctx.Event.data;
          Event.terminate = ctx.Event.terminate;

          Event.nb = en;
          Event.kind = Event.Ltop;
          Event.lang = "";
          Event.inputs  = [];
          Event.outputs = [];
          Event.sinfo   = None;
          Event.next =
            (fun () ->
              loop (check_oracles oracle_in_vals step_nb oracle_out_l 
                                  oracle_out_vals_l cov) 
                sut_out_vals env_out_vals ctx () 
            );
        }
      )
      else (* lurette mode *)
        loop (check_oracles oracle_in_vals ctx.Event.step 
                            oracle_out_l oracle_out_vals_l cov) 
          sut_out_vals env_out_vals ctx () 
    in

    let loc = None in
    let _ = 
      RifIO.write oc ("# Rdbg Version \"" ^ RdbgVersion.str ^ "\" (\"" ^
                        RdbgVersion.sha^"\")\n");
      RifIO.write_interface oc
        (luciole_outputs_vars@flat_env_out) flat_sut_out loc (Some oracle_out_l);
      RifIO.flush oc;

      RifIO.write_interface sim2chro_oc
        (luciole_outputs_vars@flat_env_out) flat_sut_out loc (Some oracle_out_l);
      RifIO.flush sim2chro_oc;
    in
    let ctx =
      {
        Event.nb = 1;
        Event.step = 1;
        Event.name = "rdbg";
        Event.depth = 1;
        Event.inputs = [];
        Event.outputs = [];
        Event.data = [];
        Event.terminate = (fun () -> killem_all cov_init);
        Event.sinfo = None;
        (* fake values *)
        Event.lang = "";
        Event.next = (fun () -> assert false);
        Event.kind = Event.Ltop;
      }
    in
    let (first_event : e) =
      let res = 
        try 
          if res_compat = 0 then
            loop cov_init sut_init_out sut_init_in ctx ()
          else 
            raise(Event.End res_compat) 
        with 
          | SutStop cov -> 
            print_string "The SUT stopped\n";
            flush stdout;
            update_cov cov;
            raise(Event.End 1)

          | OracleError str -> 
            print_string str;
            flush stdout;
            raise(Event.End 2)

          | Failure str -> 
            print_string ("Failure occured in rdbg: "^str);
            flush stdout;
            raise(Event.End 2)
          | Event.End i -> raise(Event.End (10*i))
          | e -> 
            print_string (Printexc.to_string e);
            flush stdout;
            raise(Event.End 2)
      in
      res
    in
    first_event

let (lurette_start : unit -> unit) =
  fun () -> 
    ignore(start ())

(* exported *)
let (clean_terminate : unit -> unit) =
  fun () -> 
    let str = String.concat ", " (List.map reactive_program_to_string args.oracles) in
    (match !cov_ref with 
      | None -> ()
      | Some cov -> Coverage.dump str args.output cov);
    (match !gnuplot_pid_ref with
      | None -> ()
      | Some pid ->
        print_string "Killing gnuplot...\n"; 
        flush stdout;
        Unix.kill pid Sys.sigkill;
        gnuplot_pid_ref := None
    )

    
