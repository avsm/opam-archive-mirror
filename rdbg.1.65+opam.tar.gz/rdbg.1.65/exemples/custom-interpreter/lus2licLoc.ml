open Event;;
open RdbgMain;;
open RdbgStdLib;;
open RdbgArg;;
open Lus2licRun;;


let s2str (n,v) = (n^"="^(Data.val_to_string string_of_float v))
let print_local e =
  if e.kind=Exit then (
    print_string "# locals: ";
    List.iter 
      (fun (n,v) -> if n.[0] <> '_' then print_string (s2str (n,v) ^ " ") else ())
      e.data;
    print_string "\n"; flush stdout
  )
      
      
let _ = add_hook "print_event" print_local

let _ = 
  let call = read_line () in (* lus2lic should be called here *)
  let zeargs = Str.split (Str.regexp " ") call in
  let sut_plugin = Lus2licRun.make (Array.of_list zeargs) in
  Printf.eprintf "Lus2licRun.make %s\n" (String.concat " " zeargs); flush stderr;
  args.suts <- [Ocaml(sut_plugin)];
(*   show_trace := false; *)
  add_hook "print_event" (fun e -> print_local e);
  let e = run () in
  let e = nexti  e 1000 in
  ()
