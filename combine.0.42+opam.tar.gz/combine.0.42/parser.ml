exception Error

type token = 
  | ZDD
  | XOR
  | VERTREFL
  | UNION
  | TRUE
  | TIMING
  | TILES
  | SYM
  | SVG_OUT
  | STRING of (
# 40 "parser.mly"
       (string)
# 17 "parser.ml"
)
  | SOLVE
  | SHIFT
  | SET
  | SAT
  | RSBRA
  | RPAR
  | ROT90
  | ROT270
  | ROT180
  | ROT
  | RESIZE
  | PROBLEM
  | PRINT
  | PATTERN
  | ONE
  | ON
  | OFF
  | MINUS
  | MAYBE
  | LSBRA
  | LPAR
  | INTER
  | INCLUDE
  | IDENT of (
# 39 "parser.mly"
       (string)
# 45 "parser.ml"
)
  | ID
  | HORIZREFL
  | HAT
  | H2G2
  | FALSE
  | EXIT
  | EQUAL
  | EOF
  | DLX
  | DIM of (
# 41 "parser.mly"
       (int * int)
# 59 "parser.ml"
)
  | DIFF
  | DIAG2REFL
  | DIAG1REFL
  | DEBUG
  | CROP
  | COUNT
  | CONSTANT
  | COMMA
  | BARBAR
  | ASSERT
  | ASCII_OUT
  | ASCII of (
# 42 "parser.mly"
       (bool array array)
# 75 "parser.ml"
)
  | APPLY
  | AMPAMP

and _menhir_env = {
  _menhir_lexer: Lexing.lexbuf -> token;
  _menhir_lexbuf: Lexing.lexbuf;
  mutable _menhir_token: token;
  mutable _menhir_startp: Lexing.position;
  mutable _menhir_endp: Lexing.position;
  mutable _menhir_shifted: int
}

and _menhir_state = 
  | MenhirState122
  | MenhirState116
  | MenhirState115
  | MenhirState114
  | MenhirState113
  | MenhirState110
  | MenhirState108
  | MenhirState103
  | MenhirState102
  | MenhirState91
  | MenhirState90
  | MenhirState79
  | MenhirState72
  | MenhirState67
  | MenhirState65
  | MenhirState63
  | MenhirState62
  | MenhirState61
  | MenhirState60
  | MenhirState58
  | MenhirState56
  | MenhirState55
  | MenhirState53
  | MenhirState51
  | MenhirState50
  | MenhirState49
  | MenhirState48
  | MenhirState47
  | MenhirState46
  | MenhirState44
  | MenhirState42
  | MenhirState40
  | MenhirState38
  | MenhirState37
  | MenhirState36
  | MenhirState22
  | MenhirState20
  | MenhirState17
  | MenhirState15
  | MenhirState14
  | MenhirState13
  | MenhirState12
  | MenhirState11
  | MenhirState10
  | MenhirState9
  | MenhirState8
  | MenhirState7
  | MenhirState1
  | MenhirState0


# 20 "parser.mly"
  
  open Ast
  open Combine
  open Tiling.Tile
  open D4
  type option =
    | M of multiplicity
    | S of symetries


# 152 "parser.ml"
let _eRR =
  Error

let rec _menhir_goto_separated_nonempty_list_COMMA_tile_ : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_separated_nonempty_list_COMMA_tile_ -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    match _menhir_s with
    | MenhirState65 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv577 * _menhir_state * 'tv_tile) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_separated_nonempty_list_COMMA_tile_) = _v in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv575 * _menhir_state * 'tv_tile) = Obj.magic _menhir_stack in
        let (_ : _menhir_state) = _menhir_s in
        let (xs : 'tv_separated_nonempty_list_COMMA_tile_) = _v in
        ((let (_menhir_stack, _menhir_s, x) = _menhir_stack in
        let _v : 'tv_separated_nonempty_list_COMMA_tile_ = 
# 146 "/usr/share/menhir/standard.mly"
    ( x :: xs )
# 172 "parser.ml"
         in
        _menhir_goto_separated_nonempty_list_COMMA_tile_ _menhir_env _menhir_stack _menhir_s _v) : 'freshtv576)) : 'freshtv578)
    | MenhirState8 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv581 * _menhir_state) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_separated_nonempty_list_COMMA_tile_) = _v in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv579) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (x : 'tv_separated_nonempty_list_COMMA_tile_) = _v in
        ((let _v : 'tv_loption_separated_nonempty_list_COMMA_tile__ = 
# 59 "/usr/share/menhir/standard.mly"
    ( x )
# 187 "parser.ml"
         in
        _menhir_goto_loption_separated_nonempty_list_COMMA_tile__ _menhir_env _menhir_stack _menhir_s _v) : 'freshtv580)) : 'freshtv582)
    | _ ->
        _menhir_fail ()

and _menhir_goto_list_parser_option_ : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_list_parser_option_ -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    match _menhir_s with
    | MenhirState72 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv555 * _menhir_state * 'tv_parser_option) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_list_parser_option_) = _v in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv553 * _menhir_state * 'tv_parser_option) = Obj.magic _menhir_stack in
        let (_ : _menhir_state) = _menhir_s in
        let (xs : 'tv_list_parser_option_) = _v in
        ((let (_menhir_stack, _menhir_s, x) = _menhir_stack in
        let _v : 'tv_list_parser_option_ = 
# 116 "/usr/share/menhir/standard.mly"
    ( x :: xs )
# 209 "parser.ml"
         in
        _menhir_goto_list_parser_option_ _menhir_env _menhir_stack _menhir_s _v) : 'freshtv554)) : 'freshtv556)
    | MenhirState67 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv573 * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_list_parser_option_) = _v in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv571 * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        let (_ : _menhir_state) = _menhir_s in
        let (o : 'tv_list_parser_option_) = _v in
        ((let (_menhir_stack, _menhir_s, e, _startpos_e_, _endpos_e_) = _menhir_stack in
        let _v : 'tv_tile = 
# 129 "parser.mly"
    ( let option (s, m) = function
        | M m' -> s, m' (* FIXME: fail on ambiguity *)
	| S s' -> s', m (* idem *)
      in
      let s,m = List.fold_left option (Snone, Minf) o in e,s,m )
# 229 "parser.ml"
         in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv569) = _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_tile) = _v in
        ((let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv567 * _menhir_state * 'tv_tile) = Obj.magic _menhir_stack in
        ((assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        let _tok = _menhir_env._menhir_token in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv565 * _menhir_state * 'tv_tile) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | COMMA ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv559 * _menhir_state * 'tv_tile) = Obj.magic _menhir_stack in
            ((let _tok = _menhir_discard _menhir_env in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv557 * _menhir_state * 'tv_tile) = _menhir_stack in
            let (_tok : token) = _tok in
            ((match _tok with
            | APPLY ->
                _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState65 _menhir_env._menhir_startp
            | ASCII _v ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState65 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
            | CONSTANT ->
                _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState65 _menhir_env._menhir_startp
            | CROP ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState65 _menhir_env._menhir_startp
            | DIFF ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState65 _menhir_env._menhir_startp
            | IDENT _v ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState65 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
            | INTER ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState65 _menhir_env._menhir_startp
            | LPAR ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState65 _menhir_env._menhir_startp
            | RESIZE ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState65 _menhir_env._menhir_startp
            | SET ->
                _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState65 _menhir_env._menhir_startp
            | SHIFT ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState65 _menhir_env._menhir_startp
            | UNION ->
                _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState65 _menhir_env._menhir_startp
            | XOR ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState65 _menhir_env._menhir_startp
            | _ ->
                assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
                _menhir_env._menhir_shifted <- (-1);
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState65) : 'freshtv558)) : 'freshtv560)
        | RSBRA ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv561 * _menhir_state * 'tv_tile) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, x) = _menhir_stack in
            let _v : 'tv_separated_nonempty_list_COMMA_tile_ = 
# 144 "/usr/share/menhir/standard.mly"
    ( [ x ] )
# 289 "parser.ml"
             in
            _menhir_goto_separated_nonempty_list_COMMA_tile_ _menhir_env _menhir_stack _menhir_s _v) : 'freshtv562)
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv563 * _menhir_state * 'tv_tile) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv564)) : 'freshtv566)) : 'freshtv568)) : 'freshtv570)) : 'freshtv572)) : 'freshtv574)
    | _ ->
        _menhir_fail ()

and _menhir_goto_parser_option : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_parser_option -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv551 * _menhir_state * 'tv_parser_option) = Obj.magic _menhir_stack in
    ((assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
    let _tok = _menhir_env._menhir_token in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv549 * _menhir_state * 'tv_parser_option) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | MAYBE ->
        _menhir_run71 _menhir_env (Obj.magic _menhir_stack) MenhirState72
    | ONE ->
        _menhir_run70 _menhir_env (Obj.magic _menhir_stack) MenhirState72
    | ROT ->
        _menhir_run69 _menhir_env (Obj.magic _menhir_stack) MenhirState72
    | SYM ->
        _menhir_run68 _menhir_env (Obj.magic _menhir_stack) MenhirState72
    | COMMA | RSBRA ->
        _menhir_reduce47 _menhir_env (Obj.magic _menhir_stack) MenhirState72
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState72) : 'freshtv550)) : 'freshtv552)

and _menhir_goto_output : _menhir_env -> 'ttv_tail -> 'tv_output -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _v _endpos ->
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : (('freshtv547 * _menhir_state * Lexing.position) * _menhir_state * 'tv_algo) * (
# 39 "parser.mly"
       (string)
# 334 "parser.ml"
    ) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
    let (_v : 'tv_output) = _v in
    let (_endpos : Lexing.position) = _endpos in
    ((let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : (('freshtv545 * _menhir_state * Lexing.position) * _menhir_state * 'tv_algo) * (
# 39 "parser.mly"
       (string)
# 342 "parser.ml"
    ) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
    let (out : 'tv_output) = _v in
    let (_endpos_out_ : Lexing.position) = _endpos in
    ((let (((_menhir_stack, _menhir_s, _startpos__1_), _, a), id, _startpos_id_, _endpos_id_) = _menhir_stack in
    let _startpos = _startpos__1_ in
    let _endpos = _endpos_out_ in
    let _v : 'tv_decl = 
# 73 "parser.mly"
                                            ({decl_pos = (_startpos, _endpos);
      decl_node = Command (Solve (a, out), id)})
# 353 "parser.ml"
     in
    _menhir_goto_decl _menhir_env _menhir_stack _menhir_s _v) : 'freshtv546)) : 'freshtv548)

and _menhir_goto_boolean_expr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_boolean_expr -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v _endpos ->
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv543 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let (_v : 'tv_boolean_expr) = _v in
    let (_endpos : Lexing.position) = _endpos in
    ((let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv541 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
    let (_ : _menhir_state) = _menhir_s in
    let (b : 'tv_boolean_expr) = _v in
    let (_endpos_b_ : Lexing.position) = _endpos in
    ((let (_menhir_stack, _menhir_s, _startpos__1_) = _menhir_stack in
    let _startpos = _startpos__1_ in
    let _endpos = _endpos_b_ in
    let _v : 'tv_decl = 
# 67 "parser.mly"
    ({decl_pos = (_startpos, _endpos);
      decl_node = Assert b})
# 376 "parser.ml"
     in
    _menhir_goto_decl _menhir_env _menhir_stack _menhir_s _v) : 'freshtv542)) : 'freshtv544)

and _menhir_goto_tiles : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_tiles -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v _endpos ->
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : (('freshtv539 * _menhir_state * Lexing.position) * (
# 39 "parser.mly"
       (string)
# 386 "parser.ml"
    ) * Lexing.position * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let (_v : 'tv_tiles) = _v in
    let (_endpos : Lexing.position) = _endpos in
    ((let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : (('freshtv537 * _menhir_state * Lexing.position) * (
# 39 "parser.mly"
       (string)
# 395 "parser.ml"
    ) * Lexing.position * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
    let (_ : _menhir_state) = _menhir_s in
    let (tl : 'tv_tiles) = _v in
    let (_endpos_tl_ : Lexing.position) = _endpos in
    ((let (((_menhir_stack, _menhir_s, _startpos__1_), id, _startpos_id_, _endpos_id_), _, e, _startpos_e_, _endpos_e_) = _menhir_stack in
    let _startpos = _startpos__1_ in
    let _endpos = _endpos_tl_ in
    let _v : 'tv_decl = 
# 64 "parser.mly"
    ({decl_pos = (_startpos, _endpos);
      decl_node = Problem (id, e, tl)})
# 407 "parser.ml"
     in
    _menhir_goto_decl _menhir_env _menhir_stack _menhir_s _v) : 'freshtv538)) : 'freshtv540)

and _menhir_reduce47 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _v : 'tv_list_parser_option_ = 
# 114 "/usr/share/menhir/standard.mly"
    ( [] )
# 416 "parser.ml"
     in
    _menhir_goto_list_parser_option_ _menhir_env _menhir_stack _menhir_s _v

and _menhir_run68 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _ = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv535) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    ((let _v : 'tv_parser_option = 
# 100 "parser.mly"
        ( S Sall )
# 429 "parser.ml"
     in
    _menhir_goto_parser_option _menhir_env _menhir_stack _menhir_s _v) : 'freshtv536)

and _menhir_run69 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _ = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv533) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    ((let _v : 'tv_parser_option = 
# 101 "parser.mly"
        ( S Srotations )
# 442 "parser.ml"
     in
    _menhir_goto_parser_option _menhir_env _menhir_stack _menhir_s _v) : 'freshtv534)

and _menhir_run70 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _ = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv531) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    ((let _v : 'tv_parser_option = 
# 98 "parser.mly"
        ( M Mone )
# 455 "parser.ml"
     in
    _menhir_goto_parser_option _menhir_env _menhir_stack _menhir_s _v) : 'freshtv532)

and _menhir_run71 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _ = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv529) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    ((let _v : 'tv_parser_option = 
# 99 "parser.mly"
        ( M Mmaybe )
# 468 "parser.ml"
     in
    _menhir_goto_parser_option _menhir_env _menhir_stack _menhir_s _v) : 'freshtv530)

and _menhir_run38 : _menhir_env -> 'ttv_tail * _menhir_state * 'tv_expr * Lexing.position * Lexing.position -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _tok = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : ('freshtv527 * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | APPLY ->
        _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState38 _menhir_env._menhir_startp
    | ASCII _v ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState38 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | CONSTANT ->
        _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState38 _menhir_env._menhir_startp
    | CROP ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState38 _menhir_env._menhir_startp
    | DIFF ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState38 _menhir_env._menhir_startp
    | IDENT _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState38 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | INTER ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState38 _menhir_env._menhir_startp
    | LPAR ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState38 _menhir_env._menhir_startp
    | RESIZE ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState38 _menhir_env._menhir_startp
    | SET ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState38 _menhir_env._menhir_startp
    | SHIFT ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState38 _menhir_env._menhir_startp
    | UNION ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState38 _menhir_env._menhir_startp
    | XOR ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState38 _menhir_env._menhir_startp
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState38) : 'freshtv528)

and _menhir_run40 : _menhir_env -> 'ttv_tail * _menhir_state * 'tv_expr * Lexing.position * Lexing.position -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _tok = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : ('freshtv525 * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | APPLY ->
        _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState40 _menhir_env._menhir_startp
    | ASCII _v ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState40 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | CONSTANT ->
        _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState40 _menhir_env._menhir_startp
    | CROP ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState40 _menhir_env._menhir_startp
    | DIFF ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState40 _menhir_env._menhir_startp
    | IDENT _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState40 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | INTER ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState40 _menhir_env._menhir_startp
    | LPAR ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState40 _menhir_env._menhir_startp
    | RESIZE ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState40 _menhir_env._menhir_startp
    | SET ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState40 _menhir_env._menhir_startp
    | SHIFT ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState40 _menhir_env._menhir_startp
    | UNION ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState40 _menhir_env._menhir_startp
    | XOR ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState40 _menhir_env._menhir_startp
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState40) : 'freshtv526)

and _menhir_run42 : _menhir_env -> 'ttv_tail * _menhir_state * 'tv_expr * Lexing.position * Lexing.position -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _tok = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : ('freshtv523 * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | APPLY ->
        _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState42 _menhir_env._menhir_startp
    | ASCII _v ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState42 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | CONSTANT ->
        _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState42 _menhir_env._menhir_startp
    | CROP ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState42 _menhir_env._menhir_startp
    | DIFF ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState42 _menhir_env._menhir_startp
    | IDENT _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState42 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | INTER ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState42 _menhir_env._menhir_startp
    | LPAR ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState42 _menhir_env._menhir_startp
    | RESIZE ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState42 _menhir_env._menhir_startp
    | SET ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState42 _menhir_env._menhir_startp
    | SHIFT ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState42 _menhir_env._menhir_startp
    | UNION ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState42 _menhir_env._menhir_startp
    | XOR ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState42 _menhir_env._menhir_startp
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState42) : 'freshtv524)

and _menhir_run44 : _menhir_env -> 'ttv_tail * _menhir_state * 'tv_expr * Lexing.position * Lexing.position -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _tok = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : ('freshtv521 * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | APPLY ->
        _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState44 _menhir_env._menhir_startp
    | ASCII _v ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState44 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | CONSTANT ->
        _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState44 _menhir_env._menhir_startp
    | CROP ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState44 _menhir_env._menhir_startp
    | DIFF ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState44 _menhir_env._menhir_startp
    | IDENT _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState44 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | INTER ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState44 _menhir_env._menhir_startp
    | LPAR ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState44 _menhir_env._menhir_startp
    | RESIZE ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState44 _menhir_env._menhir_startp
    | SET ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState44 _menhir_env._menhir_startp
    | SHIFT ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState44 _menhir_env._menhir_startp
    | UNION ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState44 _menhir_env._menhir_startp
    | XOR ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState44 _menhir_env._menhir_startp
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState44) : 'freshtv522)

and _menhir_fail : unit -> 'a =
  fun () ->
    Printf.fprintf Pervasives.stderr "Internal failure -- please contact the parser generator's developers.\n%!";
    assert false

and _menhir_goto_loption_separated_nonempty_list_COMMA_tile__ : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_loption_separated_nonempty_list_COMMA_tile__ -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : ('freshtv519 * _menhir_state) * _menhir_state * 'tv_loption_separated_nonempty_list_COMMA_tile__) = Obj.magic _menhir_stack in
    ((assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
    let _tok = _menhir_env._menhir_token in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : ('freshtv517 * _menhir_state) * _menhir_state * 'tv_loption_separated_nonempty_list_COMMA_tile__) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | RSBRA ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv513 * _menhir_state) * _menhir_state * 'tv_loption_separated_nonempty_list_COMMA_tile__) = Obj.magic _menhir_stack in
        let (_endpos : Lexing.position) = _menhir_env._menhir_endp in
        ((let _ = _menhir_discard _menhir_env in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv511 * _menhir_state) * _menhir_state * 'tv_loption_separated_nonempty_list_COMMA_tile__) = Obj.magic _menhir_stack in
        let (_endpos__3_ : Lexing.position) = _endpos in
        ((let ((_menhir_stack, _menhir_s), _, xs0) = _menhir_stack in
        let _endpos = _endpos__3_ in
        let _v : 'tv_tile_list = let l =
          let xs = xs0 in
          
# 135 "/usr/share/menhir/standard.mly"
    ( xs )
# 659 "parser.ml"
          
        in
        
# 109 "parser.mly"
                                                ( l )
# 665 "parser.ml"
         in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv509) = _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_tile_list) = _v in
        let (_endpos : Lexing.position) = _endpos in
        ((match _menhir_s with
        | MenhirState7 ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv503 * _menhir_state * Lexing.position) * (
# 39 "parser.mly"
       (string)
# 678 "parser.ml"
            ) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (_v : 'tv_tile_list) = _v in
            let (_endpos : Lexing.position) = _endpos in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv501 * _menhir_state * Lexing.position) * (
# 39 "parser.mly"
       (string)
# 687 "parser.ml"
            ) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            let (_ : _menhir_state) = _menhir_s in
            let (l : 'tv_tile_list) = _v in
            let (_endpos_l_ : Lexing.position) = _endpos in
            ((let ((_menhir_stack, _menhir_s, _startpos__1_), id, _startpos_id_, _endpos_id_) = _menhir_stack in
            let _startpos = _startpos__1_ in
            let _endpos = _endpos_l_ in
            let _v : 'tv_decl = 
# 61 "parser.mly"
    ({decl_pos = (_startpos, _endpos);
      decl_node = Tiles (id, l)})
# 699 "parser.ml"
             in
            _menhir_goto_decl _menhir_env _menhir_stack _menhir_s _v) : 'freshtv502)) : 'freshtv504)
        | MenhirState91 ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv507 * _menhir_state * Lexing.position) * (
# 39 "parser.mly"
       (string)
# 707 "parser.ml"
            ) * Lexing.position * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (_v : 'tv_tile_list) = _v in
            let (_endpos : Lexing.position) = _endpos in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv505) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (l : 'tv_tile_list) = _v in
            let (_endpos_l_ : Lexing.position) = _endpos in
            ((let _endpos = _endpos_l_ in
            let _v : 'tv_tiles = 
# 104 "parser.mly"
                ( Tiles_list l )
# 721 "parser.ml"
             in
            _menhir_goto_tiles _menhir_env _menhir_stack _menhir_s _v _endpos) : 'freshtv506)) : 'freshtv508)
        | _ ->
            _menhir_fail ()) : 'freshtv510)) : 'freshtv512)) : 'freshtv514)
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv515 * _menhir_state) * _menhir_state * 'tv_loption_separated_nonempty_list_COMMA_tile__) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv516)) : 'freshtv518)) : 'freshtv520)

and _menhir_goto_state : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v _endpos ->
    match _menhir_s with
    | MenhirState1 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv495 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_state) = _v in
        let (_endpos : Lexing.position) = _endpos in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv493 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_ : _menhir_state) = _menhir_s in
        let (st : 'tv_state) = _v in
        let (_endpos_st_ : Lexing.position) = _endpos in
        ((let (_menhir_stack, _menhir_s, _startpos__1_) = _menhir_stack in
        let _startpos = _startpos__1_ in
        let _endpos = _endpos_st_ in
        let _v : 'tv_decl = 
# 79 "parser.mly"
                      ({decl_pos = (_startpos, _endpos);
      decl_node = Timing st})
# 755 "parser.ml"
         in
        _menhir_goto_decl _menhir_env _menhir_stack _menhir_s _v) : 'freshtv494)) : 'freshtv496)
    | MenhirState108 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv499 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_state) = _v in
        let (_endpos : Lexing.position) = _endpos in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv497 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_ : _menhir_state) = _menhir_s in
        let (st : 'tv_state) = _v in
        let (_endpos_st_ : Lexing.position) = _endpos in
        ((let (_menhir_stack, _menhir_s, _startpos__1_) = _menhir_stack in
        let _startpos = _startpos__1_ in
        let _endpos = _endpos_st_ in
        let _v : 'tv_decl = 
# 77 "parser.mly"
                     ({decl_pos = (_startpos, _endpos);
      decl_node = Debug st})
# 776 "parser.ml"
         in
        _menhir_goto_decl _menhir_env _menhir_stack _menhir_s _v) : 'freshtv498)) : 'freshtv500)
    | _ ->
        _menhir_fail ()

and _menhir_goto_algo : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_algo -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState79 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv481 * _menhir_state * Lexing.position) * _menhir_state * 'tv_algo) = Obj.magic _menhir_stack in
        ((assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        let _tok = _menhir_env._menhir_token in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv479 * _menhir_state * Lexing.position) * _menhir_state * 'tv_algo) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | IDENT _v ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv475 * _menhir_state * Lexing.position) * _menhir_state * 'tv_algo) = Obj.magic _menhir_stack in
            let (_v : (
# 39 "parser.mly"
       (string)
# 801 "parser.ml"
            )) = _v in
            let (_startpos : Lexing.position) = _menhir_env._menhir_startp in
            let (_endpos : Lexing.position) = _menhir_env._menhir_endp in
            ((let _menhir_stack = (_menhir_stack, _v, _startpos, _endpos) in
            let _tok = _menhir_discard _menhir_env in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv473 * _menhir_state * Lexing.position) * _menhir_state * 'tv_algo) * (
# 39 "parser.mly"
       (string)
# 811 "parser.ml"
            ) * Lexing.position * Lexing.position) = _menhir_stack in
            let (_tok : token) = _tok in
            ((match _tok with
            | ASCII_OUT ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : (('freshtv459 * _menhir_state * Lexing.position) * _menhir_state * 'tv_algo) * (
# 39 "parser.mly"
       (string)
# 820 "parser.ml"
                ) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
                let (_endpos : Lexing.position) = _menhir_env._menhir_endp in
                ((let _ = _menhir_discard _menhir_env in
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv457) = Obj.magic _menhir_stack in
                let (_endpos__1_ : Lexing.position) = _endpos in
                ((let _endpos = _endpos__1_ in
                let _v : 'tv_output = 
# 114 "parser.mly"
            ( Ascii )
# 831 "parser.ml"
                 in
                _menhir_goto_output _menhir_env _menhir_stack _v _endpos) : 'freshtv458)) : 'freshtv460)
            | SVG_OUT ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : (('freshtv469 * _menhir_state * Lexing.position) * _menhir_state * 'tv_algo) * (
# 39 "parser.mly"
       (string)
# 839 "parser.ml"
                ) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
                ((let _tok = _menhir_discard _menhir_env in
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : (('freshtv467 * _menhir_state * Lexing.position) * _menhir_state * 'tv_algo) * (
# 39 "parser.mly"
       (string)
# 846 "parser.ml"
                ) * Lexing.position * Lexing.position) = _menhir_stack in
                let (_tok : token) = _tok in
                ((match _tok with
                | STRING _v ->
                    let (_menhir_env : _menhir_env) = _menhir_env in
                    let (_menhir_stack : (('freshtv463 * _menhir_state * Lexing.position) * _menhir_state * 'tv_algo) * (
# 39 "parser.mly"
       (string)
# 855 "parser.ml"
                    ) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
                    let (_v : (
# 40 "parser.mly"
       (string)
# 860 "parser.ml"
                    )) = _v in
                    let (_endpos : Lexing.position) = _menhir_env._menhir_endp in
                    ((let _ = _menhir_discard _menhir_env in
                    let (_menhir_env : _menhir_env) = _menhir_env in
                    let (_menhir_stack : 'freshtv461) = Obj.magic _menhir_stack in
                    let (s : (
# 40 "parser.mly"
       (string)
# 869 "parser.ml"
                    )) = _v in
                    let (_endpos_s_ : Lexing.position) = _endpos in
                    ((let _endpos = _endpos_s_ in
                    let _v : 'tv_output = 
# 113 "parser.mly"
                      ( Svg s )
# 876 "parser.ml"
                     in
                    _menhir_goto_output _menhir_env _menhir_stack _v _endpos) : 'freshtv462)) : 'freshtv464)
                | _ ->
                    assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
                    _menhir_env._menhir_shifted <- (-1);
                    let (_menhir_env : _menhir_env) = _menhir_env in
                    let (_menhir_stack : (('freshtv465 * _menhir_state * Lexing.position) * _menhir_state * 'tv_algo) * (
# 39 "parser.mly"
       (string)
# 886 "parser.ml"
                    ) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
                    ((let ((_menhir_stack, _menhir_s, _), _, _, _) = _menhir_stack in
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv466)) : 'freshtv468)) : 'freshtv470)
            | _ ->
                assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
                _menhir_env._menhir_shifted <- (-1);
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : (('freshtv471 * _menhir_state * Lexing.position) * _menhir_state * 'tv_algo) * (
# 39 "parser.mly"
       (string)
# 897 "parser.ml"
                ) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
                ((let ((_menhir_stack, _menhir_s, _), _, _, _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv472)) : 'freshtv474)) : 'freshtv476)
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv477 * _menhir_state * Lexing.position) * _menhir_state * 'tv_algo) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv478)) : 'freshtv480)) : 'freshtv482)
    | MenhirState110 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv491 * _menhir_state * Lexing.position) * _menhir_state * 'tv_algo) = Obj.magic _menhir_stack in
        ((assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        let _tok = _menhir_env._menhir_token in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv489 * _menhir_state * Lexing.position) * _menhir_state * 'tv_algo) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | IDENT _v ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv485 * _menhir_state * Lexing.position) * _menhir_state * 'tv_algo) = Obj.magic _menhir_stack in
            let (_v : (
# 39 "parser.mly"
       (string)
# 923 "parser.ml"
            )) = _v in
            let (_startpos : Lexing.position) = _menhir_env._menhir_startp in
            let (_endpos : Lexing.position) = _menhir_env._menhir_endp in
            ((let _ = _menhir_discard _menhir_env in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv483 * _menhir_state * Lexing.position) * _menhir_state * 'tv_algo) = Obj.magic _menhir_stack in
            let (id : (
# 39 "parser.mly"
       (string)
# 933 "parser.ml"
            )) = _v in
            let (_startpos_id_ : Lexing.position) = _startpos in
            let (_endpos_id_ : Lexing.position) = _endpos in
            ((let ((_menhir_stack, _menhir_s, _startpos__1_), _, a) = _menhir_stack in
            let _startpos = _startpos__1_ in
            let _endpos = _endpos_id_ in
            let _v : 'tv_decl = 
# 75 "parser.mly"
                             ({decl_pos = (_startpos, _endpos);
      decl_node = Command (Count a, id)})
# 944 "parser.ml"
             in
            _menhir_goto_decl _menhir_env _menhir_stack _menhir_s _v) : 'freshtv484)) : 'freshtv486)
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv487 * _menhir_state * Lexing.position) * _menhir_state * 'tv_algo) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv488)) : 'freshtv490)) : 'freshtv492)
    | _ ->
        _menhir_fail ()

and _menhir_goto_bool : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_bool -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v _endpos ->
    match _menhir_s with
    | MenhirState22 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv447 * _menhir_state * Lexing.position) * (
# 41 "parser.mly"
       (int * int)
# 965 "parser.ml"
        ) * Lexing.position) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_bool) = _v in
        let (_endpos : Lexing.position) = _endpos in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv445 * _menhir_state * Lexing.position) * (
# 41 "parser.mly"
       (int * int)
# 974 "parser.ml"
        ) * Lexing.position) = Obj.magic _menhir_stack in
        let (_ : _menhir_state) = _menhir_s in
        let (b : 'tv_bool) = _v in
        let (_endpos_b_ : Lexing.position) = _endpos in
        ((let ((_menhir_stack, _menhir_s, _startpos__1_), d, _endpos_d_) = _menhir_stack in
        let _startpos = _startpos__1_ in
        let _endpos = _endpos_b_ in
        let _v : 'tv_expr = 
# 142 "parser.mly"
  ( let w,h = d in
      {expr_pos = (_startpos, _endpos);
        expr_node = Constant (Array.make h (Array.make w b))} )
# 987 "parser.ml"
         in
        _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v _startpos _endpos) : 'freshtv446)) : 'freshtv448)
    | MenhirState56 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv451 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state * (
# 41 "parser.mly"
       (int * int)
# 995 "parser.ml"
        ) * Lexing.position) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_bool) = _v in
        let (_endpos : Lexing.position) = _endpos in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv449 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state * (
# 41 "parser.mly"
       (int * int)
# 1004 "parser.ml"
        ) * Lexing.position) = Obj.magic _menhir_stack in
        let (_ : _menhir_state) = _menhir_s in
        let (b : 'tv_bool) = _v in
        let (_endpos_b_ : Lexing.position) = _endpos in
        ((let (((_menhir_stack, _menhir_s, _startpos__1_), _, e, _startpos_e_, _endpos_e_), _, d, _endpos_d_) = _menhir_stack in
        let _startpos = _startpos__1_ in
        let _endpos = _endpos_b_ in
        let _v : 'tv_expr = 
# 170 "parser.mly"
    ({expr_pos = (_startpos, _endpos);
       expr_node = SetOp (SetXY (b), d, e)} )
# 1016 "parser.ml"
         in
        _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v _startpos _endpos) : 'freshtv450)) : 'freshtv452)
    | MenhirState113 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv455 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_bool) = _v in
        let (_endpos : Lexing.position) = _endpos in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv453) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (b : 'tv_bool) = _v in
        let (_endpos_b_ : Lexing.position) = _endpos in
        ((let _endpos = _endpos_b_ in
        let _v : 'tv_boolean_expr = 
# 195 "parser.mly"
           ( Boolean b )
# 1034 "parser.ml"
         in
        _menhir_goto_boolean_expr _menhir_env _menhir_stack _menhir_s _v _endpos) : 'freshtv454)) : 'freshtv456)
    | _ ->
        _menhir_fail ()

and _menhir_goto_expr : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_expr -> Lexing.position -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v _startpos _endpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v, _startpos, _endpos) in
    match _menhir_s with
    | MenhirState36 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv317 * _menhir_state * Lexing.position) * 'tv_isometry) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        let _tok = _menhir_env._menhir_token in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv315 * _menhir_state * Lexing.position) * 'tv_isometry) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | AMPAMP ->
            _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState37
        | BARBAR ->
            _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState37
        | HAT ->
            _menhir_run40 _menhir_env (Obj.magic _menhir_stack) MenhirState37
        | MINUS ->
            _menhir_run38 _menhir_env (Obj.magic _menhir_stack) MenhirState37
        | APPLY | ASCII _ | ASSERT | COMMA | CONSTANT | COUNT | CROP | DEBUG | DIFF | DIM _ | EOF | EQUAL | EXIT | H2G2 | IDENT _ | INCLUDE | INTER | LPAR | LSBRA | MAYBE | ONE | PATTERN | PRINT | PROBLEM | RESIZE | ROT | RPAR | RSBRA | SET | SHIFT | SOLVE | SYM | TILES | TIMING | UNION | XOR ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv313 * _menhir_state * Lexing.position) * 'tv_isometry) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            ((let (((_menhir_stack, _menhir_s, _startpos__1_), iso), _, e, _startpos_e_, _endpos_e_) = _menhir_stack in
            let _startpos = _startpos__1_ in
            let _endpos = _endpos_e_ in
            let _v : 'tv_expr = 
# 182 "parser.mly"
    ({expr_pos = (_startpos, _endpos);
       expr_node = Apply (iso, e)})
# 1071 "parser.ml"
             in
            _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v _startpos _endpos) : 'freshtv314)
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState37) : 'freshtv316)) : 'freshtv318)
    | MenhirState38 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv321 * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv319 * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((_menhir_stack, _menhir_s, e1, _startpos_e1_, _endpos_e1_), _), _, e2, _startpos_e2_, _endpos_e2_) = _menhir_stack in
        let _startpos = _startpos_e1_ in
        let _endpos = _endpos_e2_ in
        let _v : 'tv_expr = 
# 158 "parser.mly"
      ({expr_pos = (_startpos, _endpos);
         expr_node = Binary (Diff, e1, e2)})
# 1090 "parser.ml"
         in
        _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v _startpos _endpos) : 'freshtv320)) : 'freshtv322)
    | MenhirState40 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv325 * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv323 * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((_menhir_stack, _menhir_s, e1, _startpos_e1_, _endpos_e1_), _), _, e2, _startpos_e2_, _endpos_e2_) = _menhir_stack in
        let _startpos = _startpos_e1_ in
        let _endpos = _endpos_e2_ in
        let _v : 'tv_expr = 
# 167 "parser.mly"
      ({expr_pos = (_startpos, _endpos);
         expr_node = Binary (Xor, e1, e2)})
# 1105 "parser.ml"
         in
        _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v _startpos _endpos) : 'freshtv324)) : 'freshtv326)
    | MenhirState42 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv329 * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv327 * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((_menhir_stack, _menhir_s, e1, _startpos_e1_, _endpos_e1_), _), _, e2, _startpos_e2_, _endpos_e2_) = _menhir_stack in
        let _startpos = _startpos_e1_ in
        let _endpos = _endpos_e2_ in
        let _v : 'tv_expr = 
# 164 "parser.mly"
      ({expr_pos = (_startpos, _endpos);
         expr_node = Binary (Union, e1, e2)})
# 1120 "parser.ml"
         in
        _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v _startpos _endpos) : 'freshtv328)) : 'freshtv330)
    | MenhirState44 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv333 * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv331 * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((_menhir_stack, _menhir_s, e1, _startpos_e1_, _endpos_e1_), _), _, e2, _startpos_e2_, _endpos_e2_) = _menhir_stack in
        let _startpos = _startpos_e1_ in
        let _endpos = _endpos_e2_ in
        let _v : 'tv_expr = 
# 161 "parser.mly"
      ({expr_pos = (_startpos, _endpos);
         expr_node = Binary (Inter, e1, e2)})
# 1135 "parser.ml"
         in
        _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v _startpos _endpos) : 'freshtv332)) : 'freshtv334)
    | MenhirState20 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv339 * _menhir_state * Lexing.position) * (
# 41 "parser.mly"
       (int * int)
# 1143 "parser.ml"
        ) * Lexing.position) * (
# 41 "parser.mly"
       (int * int)
# 1147 "parser.ml"
        ) * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        let _tok = _menhir_env._menhir_token in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv337 * _menhir_state * Lexing.position) * (
# 41 "parser.mly"
       (int * int)
# 1155 "parser.ml"
        ) * Lexing.position) * (
# 41 "parser.mly"
       (int * int)
# 1159 "parser.ml"
        ) * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | AMPAMP ->
            _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState46
        | BARBAR ->
            _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState46
        | HAT ->
            _menhir_run40 _menhir_env (Obj.magic _menhir_stack) MenhirState46
        | MINUS ->
            _menhir_run38 _menhir_env (Obj.magic _menhir_stack) MenhirState46
        | APPLY | ASCII _ | ASSERT | COMMA | CONSTANT | COUNT | CROP | DEBUG | DIFF | DIM _ | EOF | EQUAL | EXIT | H2G2 | IDENT _ | INCLUDE | INTER | LPAR | LSBRA | MAYBE | ONE | PATTERN | PRINT | PROBLEM | RESIZE | ROT | RPAR | RSBRA | SET | SHIFT | SOLVE | SYM | TILES | TIMING | UNION | XOR ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv335 * _menhir_state * Lexing.position) * (
# 41 "parser.mly"
       (int * int)
# 1176 "parser.ml"
            ) * Lexing.position) * (
# 41 "parser.mly"
       (int * int)
# 1180 "parser.ml"
            ) * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            ((let ((((_menhir_stack, _menhir_s, _startpos__1_), pos, _endpos_pos_), d, _endpos_d_), _, e, _startpos_e_, _endpos_e_) = _menhir_stack in
            let _startpos = _startpos__1_ in
            let _endpos = _endpos_e_ in
            let _v : 'tv_expr = 
# 173 "parser.mly"
    ({expr_pos = (_startpos, _endpos);
    expr_node = SetOp (Crop(pos), d, e)})
# 1189 "parser.ml"
             in
            _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v _startpos _endpos) : 'freshtv336)
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState46) : 'freshtv338)) : 'freshtv340)
    | MenhirState17 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv343 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        let _tok = _menhir_env._menhir_token in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv341 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | AMPAMP ->
            _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState47
        | APPLY ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState47 _menhir_env._menhir_startp
        | ASCII _v ->
            _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState47 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
        | BARBAR ->
            _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState47
        | CONSTANT ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState47 _menhir_env._menhir_startp
        | CROP ->
            _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState47 _menhir_env._menhir_startp
        | DIFF ->
            _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState47 _menhir_env._menhir_startp
        | HAT ->
            _menhir_run40 _menhir_env (Obj.magic _menhir_stack) MenhirState47
        | IDENT _v ->
            _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState47 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
        | INTER ->
            _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState47 _menhir_env._menhir_startp
        | LPAR ->
            _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState47 _menhir_env._menhir_startp
        | MINUS ->
            _menhir_run38 _menhir_env (Obj.magic _menhir_stack) MenhirState47
        | RESIZE ->
            _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState47 _menhir_env._menhir_startp
        | SET ->
            _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState47 _menhir_env._menhir_startp
        | SHIFT ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState47 _menhir_env._menhir_startp
        | UNION ->
            _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState47 _menhir_env._menhir_startp
        | XOR ->
            _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState47 _menhir_env._menhir_startp
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState47) : 'freshtv342)) : 'freshtv344)
    | MenhirState47 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv349 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        let _tok = _menhir_env._menhir_token in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv347 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | AMPAMP ->
            _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState48
        | BARBAR ->
            _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState48
        | HAT ->
            _menhir_run40 _menhir_env (Obj.magic _menhir_stack) MenhirState48
        | MINUS ->
            _menhir_run38 _menhir_env (Obj.magic _menhir_stack) MenhirState48
        | APPLY | ASCII _ | ASSERT | COMMA | CONSTANT | COUNT | CROP | DEBUG | DIFF | DIM _ | EOF | EQUAL | EXIT | H2G2 | IDENT _ | INCLUDE | INTER | LPAR | LSBRA | MAYBE | ONE | PATTERN | PRINT | PROBLEM | RESIZE | ROT | RPAR | RSBRA | SET | SHIFT | SOLVE | SYM | TILES | TIMING | UNION | XOR ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv345 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            ((let (((_menhir_stack, _menhir_s, _startpos__1_), _, e1, _startpos_e1_, _endpos_e1_), _, e2, _startpos_e2_, _endpos_e2_) = _menhir_stack in
            let _startpos = _startpos__1_ in
            let _endpos = _endpos_e2_ in
            let _v : 'tv_expr = 
# 152 "parser.mly"
      ({expr_pos = (_startpos, _endpos);
         expr_node = Binary (Diff, e1, e2)})
# 1270 "parser.ml"
             in
            _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v _startpos _endpos) : 'freshtv346)
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState48) : 'freshtv348)) : 'freshtv350)
    | MenhirState15 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv353 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        let _tok = _menhir_env._menhir_token in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv351 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | AMPAMP ->
            _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState49
        | APPLY ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState49 _menhir_env._menhir_startp
        | ASCII _v ->
            _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState49 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
        | BARBAR ->
            _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState49
        | CONSTANT ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState49 _menhir_env._menhir_startp
        | CROP ->
            _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState49 _menhir_env._menhir_startp
        | DIFF ->
            _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState49 _menhir_env._menhir_startp
        | HAT ->
            _menhir_run40 _menhir_env (Obj.magic _menhir_stack) MenhirState49
        | IDENT _v ->
            _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState49 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
        | INTER ->
            _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState49 _menhir_env._menhir_startp
        | LPAR ->
            _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState49 _menhir_env._menhir_startp
        | MINUS ->
            _menhir_run38 _menhir_env (Obj.magic _menhir_stack) MenhirState49
        | RESIZE ->
            _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState49 _menhir_env._menhir_startp
        | SET ->
            _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState49 _menhir_env._menhir_startp
        | SHIFT ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState49 _menhir_env._menhir_startp
        | UNION ->
            _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState49 _menhir_env._menhir_startp
        | XOR ->
            _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState49 _menhir_env._menhir_startp
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState49) : 'freshtv352)) : 'freshtv354)
    | MenhirState49 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv359 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        let _tok = _menhir_env._menhir_token in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv357 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | AMPAMP ->
            _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState50
        | BARBAR ->
            _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState50
        | HAT ->
            _menhir_run40 _menhir_env (Obj.magic _menhir_stack) MenhirState50
        | MINUS ->
            _menhir_run38 _menhir_env (Obj.magic _menhir_stack) MenhirState50
        | APPLY | ASCII _ | ASSERT | COMMA | CONSTANT | COUNT | CROP | DEBUG | DIFF | DIM _ | EOF | EQUAL | EXIT | H2G2 | IDENT _ | INCLUDE | INTER | LPAR | LSBRA | MAYBE | ONE | PATTERN | PRINT | PROBLEM | RESIZE | ROT | RPAR | RSBRA | SET | SHIFT | SOLVE | SYM | TILES | TIMING | UNION | XOR ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv355 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            ((let (((_menhir_stack, _menhir_s, _startpos__1_), _, e1, _startpos_e1_, _endpos_e1_), _, e2, _startpos_e2_, _endpos_e2_) = _menhir_stack in
            let _startpos = _startpos__1_ in
            let _endpos = _endpos_e2_ in
            let _v : 'tv_expr = 
# 149 "parser.mly"
      ({expr_pos = (_startpos, _endpos);
         expr_node = Binary (Inter, e1, e2)})
# 1351 "parser.ml"
             in
            _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v _startpos _endpos) : 'freshtv356)
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState50) : 'freshtv358)) : 'freshtv360)
    | MenhirState14 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv367 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        let _tok = _menhir_env._menhir_token in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv365 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | AMPAMP ->
            _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState51
        | BARBAR ->
            _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState51
        | HAT ->
            _menhir_run40 _menhir_env (Obj.magic _menhir_stack) MenhirState51
        | MINUS ->
            _menhir_run38 _menhir_env (Obj.magic _menhir_stack) MenhirState51
        | RPAR ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv363 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState51 in
            let (_endpos : Lexing.position) = _menhir_env._menhir_endp in
            ((let _ = _menhir_discard _menhir_env in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv361 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            let (_ : _menhir_state) = _menhir_s in
            let (_endpos__3_ : Lexing.position) = _endpos in
            ((let ((_menhir_stack, _menhir_s, _startpos__1_), _, e, _startpos_e_, _endpos_e_) = _menhir_stack in
            let _startpos = _startpos__1_ in
            let _endpos = _endpos__3_ in
            let _v : 'tv_expr = 
# 137 "parser.mly"
                       ( e )
# 1391 "parser.ml"
             in
            _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v _startpos _endpos) : 'freshtv362)) : 'freshtv364)
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState51) : 'freshtv366)) : 'freshtv368)
    | MenhirState13 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv375 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        let _tok = _menhir_env._menhir_token in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv373 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | AMPAMP ->
            _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState53
        | BARBAR ->
            _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState53
        | DIM _v ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv371 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState53 in
            let (_v : (
# 41 "parser.mly"
       (int * int)
# 1418 "parser.ml"
            )) = _v in
            let (_endpos : Lexing.position) = _menhir_env._menhir_endp in
            ((let _ = _menhir_discard _menhir_env in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv369 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            let (_ : _menhir_state) = _menhir_s in
            let (d : (
# 41 "parser.mly"
       (int * int)
# 1428 "parser.ml"
            )) = _v in
            let (_endpos_d_ : Lexing.position) = _endpos in
            ((let ((_menhir_stack, _menhir_s, _startpos__1_), _, e, _startpos_e_, _endpos_e_) = _menhir_stack in
            let _startpos = _startpos__1_ in
            let _endpos = _endpos_d_ in
            let _v : 'tv_expr = 
# 179 "parser.mly"
    ({expr_pos = (_startpos, _endpos);
     expr_node = SetOp (Resize, d, e)})
# 1438 "parser.ml"
             in
            _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v _startpos _endpos) : 'freshtv370)) : 'freshtv372)
        | HAT ->
            _menhir_run40 _menhir_env (Obj.magic _menhir_stack) MenhirState53
        | MINUS ->
            _menhir_run38 _menhir_env (Obj.magic _menhir_stack) MenhirState53
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState53) : 'freshtv374)) : 'freshtv376)
    | MenhirState12 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv383 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        let _tok = _menhir_env._menhir_token in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv381 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | AMPAMP ->
            _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState55
        | BARBAR ->
            _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState55
        | DIM _v ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv379 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState55 in
            let (_v : (
# 41 "parser.mly"
       (int * int)
# 1469 "parser.ml"
            )) = _v in
            let (_endpos : Lexing.position) = _menhir_env._menhir_endp in
            ((let _menhir_stack = (_menhir_stack, _menhir_s, _v, _endpos) in
            let _tok = _menhir_discard _menhir_env in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv377 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state * (
# 41 "parser.mly"
       (int * int)
# 1478 "parser.ml"
            ) * Lexing.position) = _menhir_stack in
            let (_tok : token) = _tok in
            ((match _tok with
            | FALSE ->
                _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState56 _menhir_env._menhir_endp
            | TRUE ->
                _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState56 _menhir_env._menhir_endp
            | _ ->
                assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
                _menhir_env._menhir_shifted <- (-1);
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState56) : 'freshtv378)) : 'freshtv380)
        | HAT ->
            _menhir_run40 _menhir_env (Obj.magic _menhir_stack) MenhirState55
        | MINUS ->
            _menhir_run38 _menhir_env (Obj.magic _menhir_stack) MenhirState55
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState55) : 'freshtv382)) : 'freshtv384)
    | MenhirState11 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv391 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        let _tok = _menhir_env._menhir_token in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv389 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | AMPAMP ->
            _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState58
        | BARBAR ->
            _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState58
        | DIM _v ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv387 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState58 in
            let (_v : (
# 41 "parser.mly"
       (int * int)
# 1518 "parser.ml"
            )) = _v in
            let (_endpos : Lexing.position) = _menhir_env._menhir_endp in
            ((let _ = _menhir_discard _menhir_env in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv385 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            let (_ : _menhir_state) = _menhir_s in
            let (d : (
# 41 "parser.mly"
       (int * int)
# 1528 "parser.ml"
            )) = _v in
            let (_endpos_d_ : Lexing.position) = _endpos in
            ((let ((_menhir_stack, _menhir_s, _startpos__1_), _, e, _startpos_e_, _endpos_e_) = _menhir_stack in
            let _startpos = _startpos__1_ in
            let _endpos = _endpos_d_ in
            let _v : 'tv_expr = 
# 176 "parser.mly"
    ({expr_pos = (_startpos, _endpos);
     expr_node = SetOp (Shift, d, e)})
# 1538 "parser.ml"
             in
            _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v _startpos _endpos) : 'freshtv386)) : 'freshtv388)
        | HAT ->
            _menhir_run40 _menhir_env (Obj.magic _menhir_stack) MenhirState58
        | MINUS ->
            _menhir_run38 _menhir_env (Obj.magic _menhir_stack) MenhirState58
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState58) : 'freshtv390)) : 'freshtv392)
    | MenhirState10 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv395 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        let _tok = _menhir_env._menhir_token in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv393 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | AMPAMP ->
            _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState60
        | APPLY ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState60 _menhir_env._menhir_startp
        | ASCII _v ->
            _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState60 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
        | BARBAR ->
            _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState60
        | CONSTANT ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState60 _menhir_env._menhir_startp
        | CROP ->
            _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState60 _menhir_env._menhir_startp
        | DIFF ->
            _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState60 _menhir_env._menhir_startp
        | HAT ->
            _menhir_run40 _menhir_env (Obj.magic _menhir_stack) MenhirState60
        | IDENT _v ->
            _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState60 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
        | INTER ->
            _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState60 _menhir_env._menhir_startp
        | LPAR ->
            _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState60 _menhir_env._menhir_startp
        | MINUS ->
            _menhir_run38 _menhir_env (Obj.magic _menhir_stack) MenhirState60
        | RESIZE ->
            _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState60 _menhir_env._menhir_startp
        | SET ->
            _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState60 _menhir_env._menhir_startp
        | SHIFT ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState60 _menhir_env._menhir_startp
        | UNION ->
            _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState60 _menhir_env._menhir_startp
        | XOR ->
            _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState60 _menhir_env._menhir_startp
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState60) : 'freshtv394)) : 'freshtv396)
    | MenhirState60 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv401 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        let _tok = _menhir_env._menhir_token in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv399 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | AMPAMP ->
            _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState61
        | BARBAR ->
            _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState61
        | HAT ->
            _menhir_run40 _menhir_env (Obj.magic _menhir_stack) MenhirState61
        | MINUS ->
            _menhir_run38 _menhir_env (Obj.magic _menhir_stack) MenhirState61
        | APPLY | ASCII _ | ASSERT | COMMA | CONSTANT | COUNT | CROP | DEBUG | DIFF | DIM _ | EOF | EQUAL | EXIT | H2G2 | IDENT _ | INCLUDE | INTER | LPAR | LSBRA | MAYBE | ONE | PATTERN | PRINT | PROBLEM | RESIZE | ROT | RPAR | RSBRA | SET | SHIFT | SOLVE | SYM | TILES | TIMING | UNION | XOR ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv397 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            ((let (((_menhir_stack, _menhir_s, _startpos__1_), _, e1, _startpos_e1_, _endpos_e1_), _, e2, _startpos_e2_, _endpos_e2_) = _menhir_stack in
            let _startpos = _startpos__1_ in
            let _endpos = _endpos_e2_ in
            let _v : 'tv_expr = 
# 146 "parser.mly"
      ({expr_pos = (_startpos, _endpos);
         expr_node = Binary (Union, e1, e2)})
# 1623 "parser.ml"
             in
            _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v _startpos _endpos) : 'freshtv398)
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState61) : 'freshtv400)) : 'freshtv402)
    | MenhirState9 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv405 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        let _tok = _menhir_env._menhir_token in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv403 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | AMPAMP ->
            _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState62
        | APPLY ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState62 _menhir_env._menhir_startp
        | ASCII _v ->
            _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState62 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
        | BARBAR ->
            _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState62
        | CONSTANT ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState62 _menhir_env._menhir_startp
        | CROP ->
            _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState62 _menhir_env._menhir_startp
        | DIFF ->
            _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState62 _menhir_env._menhir_startp
        | HAT ->
            _menhir_run40 _menhir_env (Obj.magic _menhir_stack) MenhirState62
        | IDENT _v ->
            _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState62 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
        | INTER ->
            _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState62 _menhir_env._menhir_startp
        | LPAR ->
            _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState62 _menhir_env._menhir_startp
        | MINUS ->
            _menhir_run38 _menhir_env (Obj.magic _menhir_stack) MenhirState62
        | RESIZE ->
            _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState62 _menhir_env._menhir_startp
        | SET ->
            _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState62 _menhir_env._menhir_startp
        | SHIFT ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState62 _menhir_env._menhir_startp
        | UNION ->
            _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState62 _menhir_env._menhir_startp
        | XOR ->
            _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState62 _menhir_env._menhir_startp
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState62) : 'freshtv404)) : 'freshtv406)
    | MenhirState62 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv411 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        let _tok = _menhir_env._menhir_token in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv409 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | AMPAMP ->
            _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState63
        | BARBAR ->
            _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState63
        | HAT ->
            _menhir_run40 _menhir_env (Obj.magic _menhir_stack) MenhirState63
        | MINUS ->
            _menhir_run38 _menhir_env (Obj.magic _menhir_stack) MenhirState63
        | APPLY | ASCII _ | ASSERT | COMMA | CONSTANT | COUNT | CROP | DEBUG | DIFF | DIM _ | EOF | EQUAL | EXIT | H2G2 | IDENT _ | INCLUDE | INTER | LPAR | LSBRA | MAYBE | ONE | PATTERN | PRINT | PROBLEM | RESIZE | ROT | RPAR | RSBRA | SET | SHIFT | SOLVE | SYM | TILES | TIMING | UNION | XOR ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv407 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            ((let (((_menhir_stack, _menhir_s, _startpos__1_), _, e1, _startpos_e1_, _endpos_e1_), _, e2, _startpos_e2_, _endpos_e2_) = _menhir_stack in
            let _startpos = _startpos__1_ in
            let _endpos = _endpos_e2_ in
            let _v : 'tv_expr = 
# 155 "parser.mly"
      ({expr_pos = (_startpos, _endpos);
         expr_node = Binary (Xor, e1, e2)})
# 1704 "parser.ml"
             in
            _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v _startpos _endpos) : 'freshtv408)
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState63) : 'freshtv410)) : 'freshtv412)
    | MenhirState8 | MenhirState65 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv415 * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        let _tok = _menhir_env._menhir_token in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv413 * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | AMPAMP ->
            _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState67
        | BARBAR ->
            _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState67
        | HAT ->
            _menhir_run40 _menhir_env (Obj.magic _menhir_stack) MenhirState67
        | MAYBE ->
            _menhir_run71 _menhir_env (Obj.magic _menhir_stack) MenhirState67
        | MINUS ->
            _menhir_run38 _menhir_env (Obj.magic _menhir_stack) MenhirState67
        | ONE ->
            _menhir_run70 _menhir_env (Obj.magic _menhir_stack) MenhirState67
        | ROT ->
            _menhir_run69 _menhir_env (Obj.magic _menhir_stack) MenhirState67
        | SYM ->
            _menhir_run68 _menhir_env (Obj.magic _menhir_stack) MenhirState67
        | COMMA | RSBRA ->
            _menhir_reduce47 _menhir_env (Obj.magic _menhir_stack) MenhirState67
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState67) : 'freshtv414)) : 'freshtv416)
    | MenhirState90 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv423 * _menhir_state * Lexing.position) * (
# 39 "parser.mly"
       (string)
# 1747 "parser.ml"
        ) * Lexing.position * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        let _tok = _menhir_env._menhir_token in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv421 * _menhir_state * Lexing.position) * (
# 39 "parser.mly"
       (string)
# 1755 "parser.ml"
        ) * Lexing.position * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | AMPAMP ->
            _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState91
        | BARBAR ->
            _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState91
        | HAT ->
            _menhir_run40 _menhir_env (Obj.magic _menhir_stack) MenhirState91
        | IDENT _v ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv419 * _menhir_state * Lexing.position) * (
# 39 "parser.mly"
       (string)
# 1770 "parser.ml"
            ) * Lexing.position * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState91 in
            let (_v : (
# 39 "parser.mly"
       (string)
# 1776 "parser.ml"
            )) = _v in
            let (_startpos : Lexing.position) = _menhir_env._menhir_startp in
            let (_endpos : Lexing.position) = _menhir_env._menhir_endp in
            ((let _ = _menhir_discard _menhir_env in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv417) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (id : (
# 39 "parser.mly"
       (string)
# 1787 "parser.ml"
            )) = _v in
            let (_startpos_id_ : Lexing.position) = _startpos in
            let (_endpos_id_ : Lexing.position) = _endpos in
            ((let _endpos = _endpos_id_ in
            let _v : 'tv_tiles = 
# 105 "parser.mly"
                ( Tiles_id  id )
# 1795 "parser.ml"
             in
            _menhir_goto_tiles _menhir_env _menhir_stack _menhir_s _v _endpos) : 'freshtv418)) : 'freshtv420)
        | LSBRA ->
            _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState91
        | MINUS ->
            _menhir_run38 _menhir_env (Obj.magic _menhir_stack) MenhirState91
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState91) : 'freshtv422)) : 'freshtv424)
    | MenhirState102 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv429 * _menhir_state * Lexing.position) * (
# 39 "parser.mly"
       (string)
# 1811 "parser.ml"
        ) * Lexing.position * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        let _tok = _menhir_env._menhir_token in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv427 * _menhir_state * Lexing.position) * (
# 39 "parser.mly"
       (string)
# 1819 "parser.ml"
        ) * Lexing.position * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | AMPAMP ->
            _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState103
        | BARBAR ->
            _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState103
        | HAT ->
            _menhir_run40 _menhir_env (Obj.magic _menhir_stack) MenhirState103
        | MINUS ->
            _menhir_run38 _menhir_env (Obj.magic _menhir_stack) MenhirState103
        | ASSERT | COUNT | DEBUG | EOF | EXIT | H2G2 | INCLUDE | PATTERN | PRINT | PROBLEM | SOLVE | TILES | TIMING ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv425 * _menhir_state * Lexing.position) * (
# 39 "parser.mly"
       (string)
# 1836 "parser.ml"
            ) * Lexing.position * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            ((let (((_menhir_stack, _menhir_s, _startpos__1_), id, _startpos_id_, _endpos_id_), _, e, _startpos_e_, _endpos_e_) = _menhir_stack in
            let _startpos = _startpos__1_ in
            let _endpos = _endpos_e_ in
            let _v : 'tv_decl = 
# 58 "parser.mly"
    ({decl_pos = (_startpos, _endpos);
      decl_node = Pattern (id, e)})
# 1845 "parser.ml"
             in
            _menhir_goto_decl _menhir_env _menhir_stack _menhir_s _v) : 'freshtv426)
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState103) : 'freshtv428)) : 'freshtv430)
    | MenhirState113 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv437 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        let _tok = _menhir_env._menhir_token in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv435 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | AMPAMP ->
            _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState114
        | BARBAR ->
            _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState114
        | EQUAL ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv433 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState114 in
            ((let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _tok = _menhir_discard _menhir_env in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv431 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state) = _menhir_stack in
            let (_tok : token) = _tok in
            ((match _tok with
            | APPLY ->
                _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState115 _menhir_env._menhir_startp
            | ASCII _v ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState115 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
            | CONSTANT ->
                _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState115 _menhir_env._menhir_startp
            | CROP ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState115 _menhir_env._menhir_startp
            | DIFF ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState115 _menhir_env._menhir_startp
            | IDENT _v ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState115 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
            | INTER ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState115 _menhir_env._menhir_startp
            | LPAR ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState115 _menhir_env._menhir_startp
            | RESIZE ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState115 _menhir_env._menhir_startp
            | SET ->
                _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState115 _menhir_env._menhir_startp
            | SHIFT ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState115 _menhir_env._menhir_startp
            | UNION ->
                _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState115 _menhir_env._menhir_startp
            | XOR ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState115 _menhir_env._menhir_startp
            | _ ->
                assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
                _menhir_env._menhir_shifted <- (-1);
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState115) : 'freshtv432)) : 'freshtv434)
        | HAT ->
            _menhir_run40 _menhir_env (Obj.magic _menhir_stack) MenhirState114
        | MINUS ->
            _menhir_run38 _menhir_env (Obj.magic _menhir_stack) MenhirState114
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState114) : 'freshtv436)) : 'freshtv438)
    | MenhirState115 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv443 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        let _tok = _menhir_env._menhir_token in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv441 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | AMPAMP ->
            _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState116
        | BARBAR ->
            _menhir_run42 _menhir_env (Obj.magic _menhir_stack) MenhirState116
        | HAT ->
            _menhir_run40 _menhir_env (Obj.magic _menhir_stack) MenhirState116
        | MINUS ->
            _menhir_run38 _menhir_env (Obj.magic _menhir_stack) MenhirState116
        | ASSERT | COUNT | DEBUG | EOF | EXIT | H2G2 | INCLUDE | PATTERN | PRINT | PROBLEM | SOLVE | TILES | TIMING ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv439 * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            ((let (((_menhir_stack, _menhir_s, e1, _startpos_e1_, _endpos_e1_), _), _, e2, _startpos_e2_, _endpos_e2_) = _menhir_stack in
            let _endpos = _endpos_e2_ in
            let _v : 'tv_boolean_expr = 
# 196 "parser.mly"
                              ( Comparison (Equal, e1, e2))
# 1938 "parser.ml"
             in
            _menhir_goto_boolean_expr _menhir_env _menhir_stack _menhir_s _v _endpos) : 'freshtv440)
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState116) : 'freshtv442)) : 'freshtv444)
    | _ ->
        _menhir_fail ()

and _menhir_goto_isometry : _menhir_env -> 'ttv_tail -> 'tv_isometry -> 'ttv_return =
  fun _menhir_env _menhir_stack _v ->
    let _menhir_stack = (_menhir_stack, _v) in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : ('freshtv311 * _menhir_state * Lexing.position) * 'tv_isometry) = Obj.magic _menhir_stack in
    ((assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
    let _tok = _menhir_env._menhir_token in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : ('freshtv309 * _menhir_state * Lexing.position) * 'tv_isometry) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | APPLY ->
        _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState36 _menhir_env._menhir_startp
    | ASCII _v ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState36 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | CONSTANT ->
        _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState36 _menhir_env._menhir_startp
    | CROP ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState36 _menhir_env._menhir_startp
    | DIFF ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState36 _menhir_env._menhir_startp
    | IDENT _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState36 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | INTER ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState36 _menhir_env._menhir_startp
    | LPAR ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState36 _menhir_env._menhir_startp
    | RESIZE ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState36 _menhir_env._menhir_startp
    | SET ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState36 _menhir_env._menhir_startp
    | SHIFT ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState36 _menhir_env._menhir_startp
    | UNION ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState36 _menhir_env._menhir_startp
    | XOR ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState36 _menhir_env._menhir_startp
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState36) : 'freshtv310)) : 'freshtv312)

and _menhir_goto_list_decl_ : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_list_decl_ -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState0 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv303 * _menhir_state * 'tv_list_decl_) = Obj.magic _menhir_stack in
        ((assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        let _tok = _menhir_env._menhir_token in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv301 * _menhir_state * 'tv_list_decl_) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | EOF ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv297 * _menhir_state * 'tv_list_decl_) = Obj.magic _menhir_stack in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv295 * _menhir_state * 'tv_list_decl_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, l) = _menhir_stack in
            let _v : (
# 49 "parser.mly"
       (Ast.queue)
# 2012 "parser.ml"
            ) = 
# 53 "parser.mly"
                      ( l )
# 2016 "parser.ml"
             in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv293) = _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (_v : (
# 49 "parser.mly"
       (Ast.queue)
# 2024 "parser.ml"
            )) = _v in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv291) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (_v : (
# 49 "parser.mly"
       (Ast.queue)
# 2032 "parser.ml"
            )) = _v in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv289) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (_1 : (
# 49 "parser.mly"
       (Ast.queue)
# 2040 "parser.ml"
            )) = _v in
            (Obj.magic _1 : 'freshtv290)) : 'freshtv292)) : 'freshtv294)) : 'freshtv296)) : 'freshtv298)
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv299 * _menhir_state * 'tv_list_decl_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv300)) : 'freshtv302)) : 'freshtv304)
    | MenhirState122 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv307 * _menhir_state * 'tv_decl) * _menhir_state * 'tv_list_decl_) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv305 * _menhir_state * 'tv_decl) * _menhir_state * 'tv_list_decl_) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, x), _, xs) = _menhir_stack in
        let _v : 'tv_list_decl_ = 
# 116 "/usr/share/menhir/standard.mly"
    ( x :: xs )
# 2059 "parser.ml"
         in
        _menhir_goto_list_decl_ _menhir_env _menhir_stack _menhir_s _v) : 'freshtv306)) : 'freshtv308)
    | _ ->
        _menhir_fail ()

and _menhir_run8 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _tok = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv287 * _menhir_state) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | APPLY ->
        _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState8 _menhir_env._menhir_startp
    | ASCII _v ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState8 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | CONSTANT ->
        _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState8 _menhir_env._menhir_startp
    | CROP ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState8 _menhir_env._menhir_startp
    | DIFF ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState8 _menhir_env._menhir_startp
    | IDENT _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState8 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | INTER ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState8 _menhir_env._menhir_startp
    | LPAR ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState8 _menhir_env._menhir_startp
    | RESIZE ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState8 _menhir_env._menhir_startp
    | SET ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState8 _menhir_env._menhir_startp
    | SHIFT ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState8 _menhir_env._menhir_startp
    | UNION ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState8 _menhir_env._menhir_startp
    | XOR ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState8 _menhir_env._menhir_startp
    | RSBRA ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv285) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = MenhirState8 in
        ((let _v : 'tv_loption_separated_nonempty_list_COMMA_tile__ = 
# 57 "/usr/share/menhir/standard.mly"
    ( [] )
# 2106 "parser.ml"
         in
        _menhir_goto_loption_separated_nonempty_list_COMMA_tile__ _menhir_env _menhir_stack _menhir_s _v) : 'freshtv286)
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState8) : 'freshtv288)

and _menhir_goto_decl : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_decl -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv283 * _menhir_state * 'tv_decl) = Obj.magic _menhir_stack in
    ((assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
    let _tok = _menhir_env._menhir_token in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv281 * _menhir_state * 'tv_decl) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | ASSERT ->
        _menhir_run113 _menhir_env (Obj.magic _menhir_stack) MenhirState122 _menhir_env._menhir_startp
    | COUNT ->
        _menhir_run110 _menhir_env (Obj.magic _menhir_stack) MenhirState122 _menhir_env._menhir_startp
    | DEBUG ->
        _menhir_run108 _menhir_env (Obj.magic _menhir_stack) MenhirState122 _menhir_env._menhir_startp
    | EXIT ->
        _menhir_run107 _menhir_env (Obj.magic _menhir_stack) MenhirState122 _menhir_env._menhir_startp _menhir_env._menhir_endp
    | H2G2 ->
        _menhir_run106 _menhir_env (Obj.magic _menhir_stack) MenhirState122 _menhir_env._menhir_startp _menhir_env._menhir_endp
    | INCLUDE ->
        _menhir_run104 _menhir_env (Obj.magic _menhir_stack) MenhirState122 _menhir_env._menhir_startp
    | PATTERN ->
        _menhir_run100 _menhir_env (Obj.magic _menhir_stack) MenhirState122 _menhir_env._menhir_startp
    | PRINT ->
        _menhir_run95 _menhir_env (Obj.magic _menhir_stack) MenhirState122 _menhir_env._menhir_startp
    | PROBLEM ->
        _menhir_run88 _menhir_env (Obj.magic _menhir_stack) MenhirState122 _menhir_env._menhir_startp
    | SOLVE ->
        _menhir_run79 _menhir_env (Obj.magic _menhir_stack) MenhirState122 _menhir_env._menhir_startp
    | TILES ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState122 _menhir_env._menhir_startp
    | TIMING ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState122 _menhir_env._menhir_startp
    | EOF ->
        _menhir_reduce45 _menhir_env (Obj.magic _menhir_stack) MenhirState122
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState122) : 'freshtv282)) : 'freshtv284)

and _menhir_run2 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _endpos ->
    let _ = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv279) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let (_endpos__1_ : Lexing.position) = _endpos in
    ((let _endpos = _endpos__1_ in
    let _v : 'tv_state = 
# 94 "parser.mly"
      ( On )
# 2167 "parser.ml"
     in
    _menhir_goto_state _menhir_env _menhir_stack _menhir_s _v _endpos) : 'freshtv280)

and _menhir_run3 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _endpos ->
    let _ = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv277) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let (_endpos__1_ : Lexing.position) = _endpos in
    ((let _endpos = _endpos__1_ in
    let _v : 'tv_state = 
# 95 "parser.mly"
      ( Off )
# 2182 "parser.ml"
     in
    _menhir_goto_state _menhir_env _menhir_stack _menhir_s _v _endpos) : 'freshtv278)

and _menhir_run80 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _ = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv275) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    ((let _v : 'tv_algo = 
# 91 "parser.mly"
      ( Zdd )
# 2195 "parser.ml"
     in
    _menhir_goto_algo _menhir_env _menhir_stack _menhir_s _v) : 'freshtv276)

and _menhir_run81 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _ = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv273) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    ((let _v : 'tv_algo = 
# 90 "parser.mly"
      ( Dlx )
# 2208 "parser.ml"
     in
    _menhir_goto_algo _menhir_env _menhir_stack _menhir_s _v) : 'freshtv274)

and _menhir_run9 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _tok = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv271 * _menhir_state * Lexing.position) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | APPLY ->
        _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState9 _menhir_env._menhir_startp
    | ASCII _v ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState9 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | CONSTANT ->
        _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState9 _menhir_env._menhir_startp
    | CROP ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState9 _menhir_env._menhir_startp
    | DIFF ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState9 _menhir_env._menhir_startp
    | IDENT _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState9 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | INTER ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState9 _menhir_env._menhir_startp
    | LPAR ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState9 _menhir_env._menhir_startp
    | RESIZE ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState9 _menhir_env._menhir_startp
    | SET ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState9 _menhir_env._menhir_startp
    | SHIFT ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState9 _menhir_env._menhir_startp
    | UNION ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState9 _menhir_env._menhir_startp
    | XOR ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState9 _menhir_env._menhir_startp
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState9) : 'freshtv272)

and _menhir_run10 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _tok = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv269 * _menhir_state * Lexing.position) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | APPLY ->
        _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState10 _menhir_env._menhir_startp
    | ASCII _v ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState10 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | CONSTANT ->
        _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState10 _menhir_env._menhir_startp
    | CROP ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState10 _menhir_env._menhir_startp
    | DIFF ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState10 _menhir_env._menhir_startp
    | IDENT _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState10 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | INTER ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState10 _menhir_env._menhir_startp
    | LPAR ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState10 _menhir_env._menhir_startp
    | RESIZE ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState10 _menhir_env._menhir_startp
    | SET ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState10 _menhir_env._menhir_startp
    | SHIFT ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState10 _menhir_env._menhir_startp
    | UNION ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState10 _menhir_env._menhir_startp
    | XOR ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState10 _menhir_env._menhir_startp
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState10) : 'freshtv270)

and _menhir_run23 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _endpos ->
    let _ = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv267) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let (_endpos__1_ : Lexing.position) = _endpos in
    ((let _endpos = _endpos__1_ in
    let _v : 'tv_bool = 
# 191 "parser.mly"
        ( true  )
# 2301 "parser.ml"
     in
    _menhir_goto_bool _menhir_env _menhir_stack _menhir_s _v _endpos) : 'freshtv268)

and _menhir_run11 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _tok = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv265 * _menhir_state * Lexing.position) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | APPLY ->
        _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState11 _menhir_env._menhir_startp
    | ASCII _v ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState11 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | CONSTANT ->
        _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState11 _menhir_env._menhir_startp
    | CROP ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState11 _menhir_env._menhir_startp
    | DIFF ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState11 _menhir_env._menhir_startp
    | IDENT _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState11 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | INTER ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState11 _menhir_env._menhir_startp
    | LPAR ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState11 _menhir_env._menhir_startp
    | RESIZE ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState11 _menhir_env._menhir_startp
    | SET ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState11 _menhir_env._menhir_startp
    | SHIFT ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState11 _menhir_env._menhir_startp
    | UNION ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState11 _menhir_env._menhir_startp
    | XOR ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState11 _menhir_env._menhir_startp
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState11) : 'freshtv266)

and _menhir_run12 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _tok = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv263 * _menhir_state * Lexing.position) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | APPLY ->
        _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState12 _menhir_env._menhir_startp
    | ASCII _v ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState12 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | CONSTANT ->
        _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState12 _menhir_env._menhir_startp
    | CROP ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState12 _menhir_env._menhir_startp
    | DIFF ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState12 _menhir_env._menhir_startp
    | IDENT _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState12 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | INTER ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState12 _menhir_env._menhir_startp
    | LPAR ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState12 _menhir_env._menhir_startp
    | RESIZE ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState12 _menhir_env._menhir_startp
    | SET ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState12 _menhir_env._menhir_startp
    | SHIFT ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState12 _menhir_env._menhir_startp
    | UNION ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState12 _menhir_env._menhir_startp
    | XOR ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState12 _menhir_env._menhir_startp
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState12) : 'freshtv264)

and _menhir_run13 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _tok = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv261 * _menhir_state * Lexing.position) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | APPLY ->
        _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState13 _menhir_env._menhir_startp
    | ASCII _v ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState13 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | CONSTANT ->
        _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState13 _menhir_env._menhir_startp
    | CROP ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState13 _menhir_env._menhir_startp
    | DIFF ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState13 _menhir_env._menhir_startp
    | IDENT _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState13 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | INTER ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState13 _menhir_env._menhir_startp
    | LPAR ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState13 _menhir_env._menhir_startp
    | RESIZE ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState13 _menhir_env._menhir_startp
    | SET ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState13 _menhir_env._menhir_startp
    | SHIFT ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState13 _menhir_env._menhir_startp
    | UNION ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState13 _menhir_env._menhir_startp
    | XOR ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState13 _menhir_env._menhir_startp
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState13) : 'freshtv262)

and _menhir_run14 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _tok = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv259 * _menhir_state * Lexing.position) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | APPLY ->
        _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState14 _menhir_env._menhir_startp
    | ASCII _v ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState14 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | CONSTANT ->
        _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState14 _menhir_env._menhir_startp
    | CROP ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState14 _menhir_env._menhir_startp
    | DIFF ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState14 _menhir_env._menhir_startp
    | IDENT _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState14 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | INTER ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState14 _menhir_env._menhir_startp
    | LPAR ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState14 _menhir_env._menhir_startp
    | RESIZE ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState14 _menhir_env._menhir_startp
    | SET ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState14 _menhir_env._menhir_startp
    | SHIFT ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState14 _menhir_env._menhir_startp
    | UNION ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState14 _menhir_env._menhir_startp
    | XOR ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState14 _menhir_env._menhir_startp
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState14) : 'freshtv260)

and _menhir_run15 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _tok = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv257 * _menhir_state * Lexing.position) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | APPLY ->
        _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState15 _menhir_env._menhir_startp
    | ASCII _v ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState15 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | CONSTANT ->
        _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState15 _menhir_env._menhir_startp
    | CROP ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState15 _menhir_env._menhir_startp
    | DIFF ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState15 _menhir_env._menhir_startp
    | IDENT _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState15 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | INTER ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState15 _menhir_env._menhir_startp
    | LPAR ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState15 _menhir_env._menhir_startp
    | RESIZE ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState15 _menhir_env._menhir_startp
    | SET ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState15 _menhir_env._menhir_startp
    | SHIFT ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState15 _menhir_env._menhir_startp
    | UNION ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState15 _menhir_env._menhir_startp
    | XOR ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState15 _menhir_env._menhir_startp
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState15) : 'freshtv258)

and _menhir_run16 : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 39 "parser.mly"
       (string)
# 2503 "parser.ml"
) -> Lexing.position -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v _startpos _endpos ->
    let _ = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv255) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let (id : (
# 39 "parser.mly"
       (string)
# 2513 "parser.ml"
    )) = _v in
    let (_startpos_id_ : Lexing.position) = _startpos in
    let (_endpos_id_ : Lexing.position) = _endpos in
    ((let _startpos = _startpos_id_ in
    let _endpos = _endpos_id_ in
    let _v : 'tv_expr = 
# 139 "parser.mly"
    ({expr_pos = (_startpos, _endpos);
      expr_node = Var id})
# 2523 "parser.ml"
     in
    _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v _startpos _endpos) : 'freshtv256)

and _menhir_run24 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _endpos ->
    let _ = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv253) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let (_endpos__1_ : Lexing.position) = _endpos in
    ((let _endpos = _endpos__1_ in
    let _v : 'tv_bool = 
# 190 "parser.mly"
        ( false )
# 2538 "parser.ml"
     in
    _menhir_goto_bool _menhir_env _menhir_stack _menhir_s _v _endpos) : 'freshtv254)

and _menhir_run17 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _tok = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv251 * _menhir_state * Lexing.position) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | APPLY ->
        _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState17 _menhir_env._menhir_startp
    | ASCII _v ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState17 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | CONSTANT ->
        _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState17 _menhir_env._menhir_startp
    | CROP ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState17 _menhir_env._menhir_startp
    | DIFF ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState17 _menhir_env._menhir_startp
    | IDENT _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState17 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | INTER ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState17 _menhir_env._menhir_startp
    | LPAR ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState17 _menhir_env._menhir_startp
    | RESIZE ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState17 _menhir_env._menhir_startp
    | SET ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState17 _menhir_env._menhir_startp
    | SHIFT ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState17 _menhir_env._menhir_startp
    | UNION ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState17 _menhir_env._menhir_startp
    | XOR ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState17 _menhir_env._menhir_startp
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState17) : 'freshtv252)

and _menhir_run18 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _tok = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv249 * _menhir_state * Lexing.position) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | DIM _v ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv245 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_v : (
# 41 "parser.mly"
       (int * int)
# 2595 "parser.ml"
        )) = _v in
        let (_endpos : Lexing.position) = _menhir_env._menhir_endp in
        ((let _menhir_stack = (_menhir_stack, _v, _endpos) in
        let _tok = _menhir_discard _menhir_env in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv243 * _menhir_state * Lexing.position) * (
# 41 "parser.mly"
       (int * int)
# 2604 "parser.ml"
        ) * Lexing.position) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | DIM _v ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv239 * _menhir_state * Lexing.position) * (
# 41 "parser.mly"
       (int * int)
# 2613 "parser.ml"
            ) * Lexing.position) = Obj.magic _menhir_stack in
            let (_v : (
# 41 "parser.mly"
       (int * int)
# 2618 "parser.ml"
            )) = _v in
            let (_endpos : Lexing.position) = _menhir_env._menhir_endp in
            ((let _menhir_stack = (_menhir_stack, _v, _endpos) in
            let _tok = _menhir_discard _menhir_env in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv237 * _menhir_state * Lexing.position) * (
# 41 "parser.mly"
       (int * int)
# 2627 "parser.ml"
            ) * Lexing.position) * (
# 41 "parser.mly"
       (int * int)
# 2631 "parser.ml"
            ) * Lexing.position) = _menhir_stack in
            let (_tok : token) = _tok in
            ((match _tok with
            | APPLY ->
                _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState20 _menhir_env._menhir_startp
            | ASCII _v ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState20 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
            | CONSTANT ->
                _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState20 _menhir_env._menhir_startp
            | CROP ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState20 _menhir_env._menhir_startp
            | DIFF ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState20 _menhir_env._menhir_startp
            | IDENT _v ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState20 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
            | INTER ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState20 _menhir_env._menhir_startp
            | LPAR ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState20 _menhir_env._menhir_startp
            | RESIZE ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState20 _menhir_env._menhir_startp
            | SET ->
                _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState20 _menhir_env._menhir_startp
            | SHIFT ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState20 _menhir_env._menhir_startp
            | UNION ->
                _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState20 _menhir_env._menhir_startp
            | XOR ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState20 _menhir_env._menhir_startp
            | _ ->
                assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
                _menhir_env._menhir_shifted <- (-1);
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState20) : 'freshtv238)) : 'freshtv240)
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv241 * _menhir_state * Lexing.position) * (
# 41 "parser.mly"
       (int * int)
# 2672 "parser.ml"
            ) * Lexing.position) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, _), _, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv242)) : 'freshtv244)) : 'freshtv246)
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv247 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv248)) : 'freshtv250)

and _menhir_run21 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _tok = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv235 * _menhir_state * Lexing.position) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | DIM _v ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv231 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_v : (
# 41 "parser.mly"
       (int * int)
# 2698 "parser.ml"
        )) = _v in
        let (_endpos : Lexing.position) = _menhir_env._menhir_endp in
        ((let _menhir_stack = (_menhir_stack, _v, _endpos) in
        let _tok = _menhir_discard _menhir_env in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv229 * _menhir_state * Lexing.position) * (
# 41 "parser.mly"
       (int * int)
# 2707 "parser.ml"
        ) * Lexing.position) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | FALSE ->
            _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState22 _menhir_env._menhir_endp
        | TRUE ->
            _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState22 _menhir_env._menhir_endp
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState22) : 'freshtv230)) : 'freshtv232)
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv233 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv234)) : 'freshtv236)

and _menhir_run26 : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 42 "parser.mly"
       (bool array array)
# 2730 "parser.ml"
) -> Lexing.position -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v _startpos _endpos ->
    let _ = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv227) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let (a : (
# 42 "parser.mly"
       (bool array array)
# 2740 "parser.ml"
    )) = _v in
    let (_startpos_a_ : Lexing.position) = _startpos in
    let (_endpos_a_ : Lexing.position) = _endpos in
    ((let _startpos = _startpos_a_ in
    let _endpos = _endpos_a_ in
    let _v : 'tv_expr = 
# 185 "parser.mly"
    ({expr_pos = (_startpos, _endpos);
       expr_node = Constant a})
# 2750 "parser.ml"
     in
    _menhir_goto_expr _menhir_env _menhir_stack _menhir_s _v _startpos _endpos) : 'freshtv228)

and _menhir_run27 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _tok = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv225 * _menhir_state * Lexing.position) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | DIAG1REFL ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv193 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let _ = _menhir_discard _menhir_env in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv191) = Obj.magic _menhir_stack in
        ((let _v : 'tv_isometry = 
# 123 "parser.mly"
            ( Diag1Refl )
# 2771 "parser.ml"
         in
        _menhir_goto_isometry _menhir_env _menhir_stack _v) : 'freshtv192)) : 'freshtv194)
    | DIAG2REFL ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv197 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let _ = _menhir_discard _menhir_env in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv195) = Obj.magic _menhir_stack in
        ((let _v : 'tv_isometry = 
# 124 "parser.mly"
            ( Diag2Refl )
# 2783 "parser.ml"
         in
        _menhir_goto_isometry _menhir_env _menhir_stack _v) : 'freshtv196)) : 'freshtv198)
    | HORIZREFL ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv201 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let _ = _menhir_discard _menhir_env in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv199) = Obj.magic _menhir_stack in
        ((let _v : 'tv_isometry = 
# 122 "parser.mly"
            ( HorizRefl )
# 2795 "parser.ml"
         in
        _menhir_goto_isometry _menhir_env _menhir_stack _v) : 'freshtv200)) : 'freshtv202)
    | ID ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv205 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let _ = _menhir_discard _menhir_env in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv203) = Obj.magic _menhir_stack in
        ((let _v : 'tv_isometry = 
# 117 "parser.mly"
     ( Id )
# 2807 "parser.ml"
         in
        _menhir_goto_isometry _menhir_env _menhir_stack _v) : 'freshtv204)) : 'freshtv206)
    | ROT180 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv209 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let _ = _menhir_discard _menhir_env in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv207) = Obj.magic _menhir_stack in
        ((let _v : 'tv_isometry = 
# 119 "parser.mly"
         ( Rot180 )
# 2819 "parser.ml"
         in
        _menhir_goto_isometry _menhir_env _menhir_stack _v) : 'freshtv208)) : 'freshtv210)
    | ROT270 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv213 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let _ = _menhir_discard _menhir_env in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv211) = Obj.magic _menhir_stack in
        ((let _v : 'tv_isometry = 
# 120 "parser.mly"
         ( Rot270 )
# 2831 "parser.ml"
         in
        _menhir_goto_isometry _menhir_env _menhir_stack _v) : 'freshtv212)) : 'freshtv214)
    | ROT90 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv217 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let _ = _menhir_discard _menhir_env in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv215) = Obj.magic _menhir_stack in
        ((let _v : 'tv_isometry = 
# 118 "parser.mly"
        ( Rot90 )
# 2843 "parser.ml"
         in
        _menhir_goto_isometry _menhir_env _menhir_stack _v) : 'freshtv216)) : 'freshtv218)
    | VERTREFL ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv221 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let _ = _menhir_discard _menhir_env in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv219) = Obj.magic _menhir_stack in
        ((let _v : 'tv_isometry = 
# 121 "parser.mly"
           ( VertRefl )
# 2855 "parser.ml"
         in
        _menhir_goto_isometry _menhir_env _menhir_stack _v) : 'freshtv220)) : 'freshtv222)
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv223 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv224)) : 'freshtv226)

and _menhir_discard : _menhir_env -> token =
  fun _menhir_env ->
    let lexbuf = _menhir_env._menhir_lexbuf in
    let _tok = _menhir_env._menhir_lexer lexbuf in
    _menhir_env._menhir_token <- _tok;
    _menhir_env._menhir_startp <- lexbuf.Lexing.lex_start_p;
    _menhir_env._menhir_endp <- lexbuf.Lexing.lex_curr_p;
    let shifted = Pervasives.(+) _menhir_env._menhir_shifted 1 in
    if Pervasives.(>=) shifted 0 then
      _menhir_env._menhir_shifted <- shifted;
    _tok

and _menhir_errorcase : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    match _menhir_s with
    | MenhirState122 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv93 * _menhir_state * 'tv_decl) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv94)
    | MenhirState116 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv95 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv96)
    | MenhirState115 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv97 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv98)
    | MenhirState114 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv99 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv100)
    | MenhirState113 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv101 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv102)
    | MenhirState110 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv103 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv104)
    | MenhirState108 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv105 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv106)
    | MenhirState103 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv107 * _menhir_state * Lexing.position) * (
# 39 "parser.mly"
       (string)
# 2921 "parser.ml"
        ) * Lexing.position * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv108)
    | MenhirState102 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv109 * _menhir_state * Lexing.position) * (
# 39 "parser.mly"
       (string)
# 2930 "parser.ml"
        ) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv110)
    | MenhirState91 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv111 * _menhir_state * Lexing.position) * (
# 39 "parser.mly"
       (string)
# 2939 "parser.ml"
        ) * Lexing.position * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv112)
    | MenhirState90 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv113 * _menhir_state * Lexing.position) * (
# 39 "parser.mly"
       (string)
# 2948 "parser.ml"
        ) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv114)
    | MenhirState79 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv115 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv116)
    | MenhirState72 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv117 * _menhir_state * 'tv_parser_option) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv118)
    | MenhirState67 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv119 * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv120)
    | MenhirState65 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv121 * _menhir_state * 'tv_tile) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv122)
    | MenhirState63 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv123 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv124)
    | MenhirState62 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv125 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv126)
    | MenhirState61 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv127 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv128)
    | MenhirState60 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv129 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv130)
    | MenhirState58 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv131 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv132)
    | MenhirState56 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv133 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state * (
# 41 "parser.mly"
       (int * int)
# 3002 "parser.ml"
        ) * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv134)
    | MenhirState55 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv135 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv136)
    | MenhirState53 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv137 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv138)
    | MenhirState51 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv139 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv140)
    | MenhirState50 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv141 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv142)
    | MenhirState49 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv143 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv144)
    | MenhirState48 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv145 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv146)
    | MenhirState47 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv147 * _menhir_state * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv148)
    | MenhirState46 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv149 * _menhir_state * Lexing.position) * (
# 41 "parser.mly"
       (int * int)
# 3046 "parser.ml"
        ) * Lexing.position) * (
# 41 "parser.mly"
       (int * int)
# 3050 "parser.ml"
        ) * Lexing.position) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv150)
    | MenhirState44 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv151 * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv152)
    | MenhirState42 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv153 * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv154)
    | MenhirState40 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv155 * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv156)
    | MenhirState38 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv157 * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv158)
    | MenhirState37 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv159 * _menhir_state * Lexing.position) * 'tv_isometry) * _menhir_state * 'tv_expr * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv160)
    | MenhirState36 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv161 * _menhir_state * Lexing.position) * 'tv_isometry) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv162)
    | MenhirState22 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv163 * _menhir_state * Lexing.position) * (
# 41 "parser.mly"
       (int * int)
# 3089 "parser.ml"
        ) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv164)
    | MenhirState20 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv165 * _menhir_state * Lexing.position) * (
# 41 "parser.mly"
       (int * int)
# 3098 "parser.ml"
        ) * Lexing.position) * (
# 41 "parser.mly"
       (int * int)
# 3102 "parser.ml"
        ) * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((_menhir_stack, _menhir_s, _), _, _), _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv166)
    | MenhirState17 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv167 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv168)
    | MenhirState15 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv169 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv170)
    | MenhirState14 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv171 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv172)
    | MenhirState13 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv173 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv174)
    | MenhirState12 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv175 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv176)
    | MenhirState11 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv177 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv178)
    | MenhirState10 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv179 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv180)
    | MenhirState9 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv181 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv182)
    | MenhirState8 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv183 * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv184)
    | MenhirState7 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv185 * _menhir_state * Lexing.position) * (
# 39 "parser.mly"
       (string)
# 3156 "parser.ml"
        ) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv186)
    | MenhirState1 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv187 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv188)
    | MenhirState0 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv189) = Obj.magic _menhir_stack in
        (raise _eRR : 'freshtv190)

and _menhir_reduce45 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _v : 'tv_list_decl_ = 
# 114 "/usr/share/menhir/standard.mly"
    ( [] )
# 3175 "parser.ml"
     in
    _menhir_goto_list_decl_ _menhir_env _menhir_stack _menhir_s _v

and _menhir_run1 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _tok = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv91 * _menhir_state * Lexing.position) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | OFF ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState1 _menhir_env._menhir_endp
    | ON ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState1 _menhir_env._menhir_endp
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState1) : 'freshtv92)

and _menhir_run5 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _tok = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv89 * _menhir_state * Lexing.position) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | IDENT _v ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv85 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_v : (
# 39 "parser.mly"
       (string)
# 3210 "parser.ml"
        )) = _v in
        let (_startpos : Lexing.position) = _menhir_env._menhir_startp in
        let (_endpos : Lexing.position) = _menhir_env._menhir_endp in
        ((let _menhir_stack = (_menhir_stack, _v, _startpos, _endpos) in
        let _tok = _menhir_discard _menhir_env in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv83 * _menhir_state * Lexing.position) * (
# 39 "parser.mly"
       (string)
# 3220 "parser.ml"
        ) * Lexing.position * Lexing.position) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | EQUAL ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv79 * _menhir_state * Lexing.position) * (
# 39 "parser.mly"
       (string)
# 3229 "parser.ml"
            ) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            ((let _tok = _menhir_discard _menhir_env in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv77 * _menhir_state * Lexing.position) * (
# 39 "parser.mly"
       (string)
# 3236 "parser.ml"
            ) * Lexing.position * Lexing.position) = _menhir_stack in
            let (_tok : token) = _tok in
            ((match _tok with
            | LSBRA ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState7
            | _ ->
                assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
                _menhir_env._menhir_shifted <- (-1);
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState7) : 'freshtv78)) : 'freshtv80)
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv81 * _menhir_state * Lexing.position) * (
# 39 "parser.mly"
       (string)
# 3253 "parser.ml"
            ) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, _), _, _, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv82)) : 'freshtv84)) : 'freshtv86)
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv87 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv88)) : 'freshtv90)

and _menhir_run79 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _tok = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv75 * _menhir_state * Lexing.position) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | DLX ->
        _menhir_run81 _menhir_env (Obj.magic _menhir_stack) MenhirState79
    | ZDD ->
        _menhir_run80 _menhir_env (Obj.magic _menhir_stack) MenhirState79
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState79) : 'freshtv76)

and _menhir_run88 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _tok = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv73 * _menhir_state * Lexing.position) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | IDENT _v ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv69 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_v : (
# 39 "parser.mly"
       (string)
# 3296 "parser.ml"
        )) = _v in
        let (_startpos : Lexing.position) = _menhir_env._menhir_startp in
        let (_endpos : Lexing.position) = _menhir_env._menhir_endp in
        ((let _menhir_stack = (_menhir_stack, _v, _startpos, _endpos) in
        let _tok = _menhir_discard _menhir_env in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv67 * _menhir_state * Lexing.position) * (
# 39 "parser.mly"
       (string)
# 3306 "parser.ml"
        ) * Lexing.position * Lexing.position) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | EQUAL ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv63 * _menhir_state * Lexing.position) * (
# 39 "parser.mly"
       (string)
# 3315 "parser.ml"
            ) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            ((let _tok = _menhir_discard _menhir_env in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv61 * _menhir_state * Lexing.position) * (
# 39 "parser.mly"
       (string)
# 3322 "parser.ml"
            ) * Lexing.position * Lexing.position) = _menhir_stack in
            let (_tok : token) = _tok in
            ((match _tok with
            | APPLY ->
                _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState90 _menhir_env._menhir_startp
            | ASCII _v ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState90 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
            | CONSTANT ->
                _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState90 _menhir_env._menhir_startp
            | CROP ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState90 _menhir_env._menhir_startp
            | DIFF ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState90 _menhir_env._menhir_startp
            | IDENT _v ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState90 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
            | INTER ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState90 _menhir_env._menhir_startp
            | LPAR ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState90 _menhir_env._menhir_startp
            | RESIZE ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState90 _menhir_env._menhir_startp
            | SET ->
                _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState90 _menhir_env._menhir_startp
            | SHIFT ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState90 _menhir_env._menhir_startp
            | UNION ->
                _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState90 _menhir_env._menhir_startp
            | XOR ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState90 _menhir_env._menhir_startp
            | _ ->
                assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
                _menhir_env._menhir_shifted <- (-1);
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState90) : 'freshtv62)) : 'freshtv64)
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv65 * _menhir_state * Lexing.position) * (
# 39 "parser.mly"
       (string)
# 3363 "parser.ml"
            ) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, _), _, _, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv66)) : 'freshtv68)) : 'freshtv70)
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv71 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv72)) : 'freshtv74)

and _menhir_run95 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _tok = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv59 * _menhir_state * Lexing.position) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | IDENT _v ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv39 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_v : (
# 39 "parser.mly"
       (string)
# 3389 "parser.ml"
        )) = _v in
        let (_startpos : Lexing.position) = _menhir_env._menhir_startp in
        let (_endpos : Lexing.position) = _menhir_env._menhir_endp in
        ((let _ = _menhir_discard _menhir_env in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv37 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (id : (
# 39 "parser.mly"
       (string)
# 3399 "parser.ml"
        )) = _v in
        let (_startpos_id_ : Lexing.position) = _startpos in
        let (_endpos_id_ : Lexing.position) = _endpos in
        ((let (_menhir_stack, _menhir_s, _startpos__1_) = _menhir_stack in
        let _startpos = _startpos__1_ in
        let _endpos = _endpos_id_ in
        let _v : 'tv_decl = 
# 69 "parser.mly"
                    ({decl_pos = (_startpos, _endpos);
      decl_node = Command (Print, id)})
# 3410 "parser.ml"
         in
        _menhir_goto_decl _menhir_env _menhir_stack _menhir_s _v) : 'freshtv38)) : 'freshtv40)
    | SAT ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv55 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let _tok = _menhir_discard _menhir_env in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv53 * _menhir_state * Lexing.position) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | STRING _v ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv49 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
            let (_v : (
# 40 "parser.mly"
       (string)
# 3427 "parser.ml"
            )) = _v in
            let (_endpos : Lexing.position) = _menhir_env._menhir_endp in
            ((let _menhir_stack = (_menhir_stack, _v, _endpos) in
            let _tok = _menhir_discard _menhir_env in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv47 * _menhir_state * Lexing.position) * (
# 40 "parser.mly"
       (string)
# 3436 "parser.ml"
            ) * Lexing.position) = _menhir_stack in
            let (_tok : token) = _tok in
            ((match _tok with
            | IDENT _v ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ('freshtv43 * _menhir_state * Lexing.position) * (
# 40 "parser.mly"
       (string)
# 3445 "parser.ml"
                ) * Lexing.position) = Obj.magic _menhir_stack in
                let (_v : (
# 39 "parser.mly"
       (string)
# 3450 "parser.ml"
                )) = _v in
                let (_startpos : Lexing.position) = _menhir_env._menhir_startp in
                let (_endpos : Lexing.position) = _menhir_env._menhir_endp in
                ((let _ = _menhir_discard _menhir_env in
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ('freshtv41 * _menhir_state * Lexing.position) * (
# 40 "parser.mly"
       (string)
# 3459 "parser.ml"
                ) * Lexing.position) = Obj.magic _menhir_stack in
                let (id : (
# 39 "parser.mly"
       (string)
# 3464 "parser.ml"
                )) = _v in
                let (_startpos_id_ : Lexing.position) = _startpos in
                let (_endpos_id_ : Lexing.position) = _endpos in
                ((let ((_menhir_stack, _menhir_s, _startpos__1_), s, _endpos_s_) = _menhir_stack in
                let _startpos = _startpos__1_ in
                let _endpos = _endpos_id_ in
                let _v : 'tv_decl = 
# 71 "parser.mly"
                                     ({decl_pos = (_startpos, _endpos);
      decl_node = Command (Sat s, id)})
# 3475 "parser.ml"
                 in
                _menhir_goto_decl _menhir_env _menhir_stack _menhir_s _v) : 'freshtv42)) : 'freshtv44)
            | _ ->
                assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
                _menhir_env._menhir_shifted <- (-1);
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ('freshtv45 * _menhir_state * Lexing.position) * (
# 40 "parser.mly"
       (string)
# 3485 "parser.ml"
                ) * Lexing.position) = Obj.magic _menhir_stack in
                ((let ((_menhir_stack, _menhir_s, _), _, _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv46)) : 'freshtv48)) : 'freshtv50)
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv51 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv52)) : 'freshtv54)) : 'freshtv56)
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv57 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv58)) : 'freshtv60)

and _menhir_run100 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _tok = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv35 * _menhir_state * Lexing.position) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | IDENT _v ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv31 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_v : (
# 39 "parser.mly"
       (string)
# 3518 "parser.ml"
        )) = _v in
        let (_startpos : Lexing.position) = _menhir_env._menhir_startp in
        let (_endpos : Lexing.position) = _menhir_env._menhir_endp in
        ((let _menhir_stack = (_menhir_stack, _v, _startpos, _endpos) in
        let _tok = _menhir_discard _menhir_env in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv29 * _menhir_state * Lexing.position) * (
# 39 "parser.mly"
       (string)
# 3528 "parser.ml"
        ) * Lexing.position * Lexing.position) = _menhir_stack in
        let (_tok : token) = _tok in
        ((match _tok with
        | EQUAL ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv25 * _menhir_state * Lexing.position) * (
# 39 "parser.mly"
       (string)
# 3537 "parser.ml"
            ) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            ((let _tok = _menhir_discard _menhir_env in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv23 * _menhir_state * Lexing.position) * (
# 39 "parser.mly"
       (string)
# 3544 "parser.ml"
            ) * Lexing.position * Lexing.position) = _menhir_stack in
            let (_tok : token) = _tok in
            ((match _tok with
            | APPLY ->
                _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState102 _menhir_env._menhir_startp
            | ASCII _v ->
                _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState102 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
            | CONSTANT ->
                _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState102 _menhir_env._menhir_startp
            | CROP ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState102 _menhir_env._menhir_startp
            | DIFF ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState102 _menhir_env._menhir_startp
            | IDENT _v ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState102 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
            | INTER ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState102 _menhir_env._menhir_startp
            | LPAR ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState102 _menhir_env._menhir_startp
            | RESIZE ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState102 _menhir_env._menhir_startp
            | SET ->
                _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState102 _menhir_env._menhir_startp
            | SHIFT ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState102 _menhir_env._menhir_startp
            | UNION ->
                _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState102 _menhir_env._menhir_startp
            | XOR ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState102 _menhir_env._menhir_startp
            | _ ->
                assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
                _menhir_env._menhir_shifted <- (-1);
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState102) : 'freshtv24)) : 'freshtv26)
        | _ ->
            assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
            _menhir_env._menhir_shifted <- (-1);
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv27 * _menhir_state * Lexing.position) * (
# 39 "parser.mly"
       (string)
# 3585 "parser.ml"
            ) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, _), _, _, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv28)) : 'freshtv30)) : 'freshtv32)
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv33 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv34)) : 'freshtv36)

and _menhir_run104 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _tok = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv21 * _menhir_state * Lexing.position) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | STRING _v ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv17 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_v : (
# 40 "parser.mly"
       (string)
# 3611 "parser.ml"
        )) = _v in
        let (_endpos : Lexing.position) = _menhir_env._menhir_endp in
        ((let _ = _menhir_discard _menhir_env in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv15 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (s : (
# 40 "parser.mly"
       (string)
# 3620 "parser.ml"
        )) = _v in
        let (_endpos_s_ : Lexing.position) = _endpos in
        ((let (_menhir_stack, _menhir_s, _startpos__1_) = _menhir_stack in
        let _startpos = _startpos__1_ in
        let _endpos = _endpos_s_ in
        let _v : 'tv_decl = 
# 83 "parser.mly"
                      ({decl_pos = (_startpos, _endpos);
      decl_node = Include s})
# 3630 "parser.ml"
         in
        _menhir_goto_decl _menhir_env _menhir_stack _menhir_s _v) : 'freshtv16)) : 'freshtv18)
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv19 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv20)) : 'freshtv22)

and _menhir_run106 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos _endpos ->
    let _ = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv13) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let (_startpos__1_ : Lexing.position) = _startpos in
    let (_endpos__1_ : Lexing.position) = _endpos in
    ((let _startpos = _startpos__1_ in
    let _endpos = _endpos__1_ in
    let _v : 'tv_decl = 
# 85 "parser.mly"
       ({decl_pos = (_startpos, _endpos);
      decl_node = H2g2})
# 3655 "parser.ml"
     in
    _menhir_goto_decl _menhir_env _menhir_stack _menhir_s _v) : 'freshtv14)

and _menhir_run107 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos _endpos ->
    let _ = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv11) = Obj.magic _menhir_stack in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let (_startpos__1_ : Lexing.position) = _startpos in
    let (_endpos__1_ : Lexing.position) = _endpos in
    ((let _startpos = _startpos__1_ in
    let _endpos = _endpos__1_ in
    let _v : 'tv_decl = 
# 81 "parser.mly"
       ({decl_pos = (_startpos, _endpos);
      decl_node = Exit})
# 3673 "parser.ml"
     in
    _menhir_goto_decl _menhir_env _menhir_stack _menhir_s _v) : 'freshtv12)

and _menhir_run108 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _tok = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv9 * _menhir_state * Lexing.position) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | OFF ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState108 _menhir_env._menhir_endp
    | ON ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState108 _menhir_env._menhir_endp
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState108) : 'freshtv10)

and _menhir_run110 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _tok = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv7 * _menhir_state * Lexing.position) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | DLX ->
        _menhir_run81 _menhir_env (Obj.magic _menhir_stack) MenhirState110
    | ZDD ->
        _menhir_run80 _menhir_env (Obj.magic _menhir_stack) MenhirState110
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState110) : 'freshtv8)

and _menhir_run113 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _tok = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv5 * _menhir_state * Lexing.position) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | APPLY ->
        _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState113 _menhir_env._menhir_startp
    | ASCII _v ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState113 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | CONSTANT ->
        _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState113 _menhir_env._menhir_startp
    | CROP ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState113 _menhir_env._menhir_startp
    | DIFF ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState113 _menhir_env._menhir_startp
    | FALSE ->
        _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState113 _menhir_env._menhir_endp
    | IDENT _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState113 _v _menhir_env._menhir_startp _menhir_env._menhir_endp
    | INTER ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState113 _menhir_env._menhir_startp
    | LPAR ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState113 _menhir_env._menhir_startp
    | RESIZE ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState113 _menhir_env._menhir_startp
    | SET ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState113 _menhir_env._menhir_startp
    | SHIFT ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState113 _menhir_env._menhir_startp
    | TRUE ->
        _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState113 _menhir_env._menhir_endp
    | UNION ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState113 _menhir_env._menhir_startp
    | XOR ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState113 _menhir_env._menhir_startp
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState113) : 'freshtv6)

and queue : (Lexing.lexbuf -> token) -> Lexing.lexbuf -> (
# 49 "parser.mly"
       (Ast.queue)
# 3757 "parser.ml"
) =
  fun lexer lexbuf ->
    let _menhir_env =
      let (lexer : Lexing.lexbuf -> token) = lexer in
      let (lexbuf : Lexing.lexbuf) = lexbuf in
      ((let _tok = lexer lexbuf in
      {
        _menhir_lexer = lexer;
        _menhir_lexbuf = lexbuf;
        _menhir_token = _tok;
        _menhir_startp = lexbuf.Lexing.lex_start_p;
        _menhir_endp = lexbuf.Lexing.lex_curr_p;
        _menhir_shifted = max_int;
        }) : _menhir_env)
    in
    Obj.magic (let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv3) = () in
    ((assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
    let _tok = _menhir_env._menhir_token in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv1) = _menhir_stack in
    let (_tok : token) = _tok in
    ((match _tok with
    | ASSERT ->
        _menhir_run113 _menhir_env (Obj.magic _menhir_stack) MenhirState0 _menhir_env._menhir_startp
    | COUNT ->
        _menhir_run110 _menhir_env (Obj.magic _menhir_stack) MenhirState0 _menhir_env._menhir_startp
    | DEBUG ->
        _menhir_run108 _menhir_env (Obj.magic _menhir_stack) MenhirState0 _menhir_env._menhir_startp
    | EXIT ->
        _menhir_run107 _menhir_env (Obj.magic _menhir_stack) MenhirState0 _menhir_env._menhir_startp _menhir_env._menhir_endp
    | H2G2 ->
        _menhir_run106 _menhir_env (Obj.magic _menhir_stack) MenhirState0 _menhir_env._menhir_startp _menhir_env._menhir_endp
    | INCLUDE ->
        _menhir_run104 _menhir_env (Obj.magic _menhir_stack) MenhirState0 _menhir_env._menhir_startp
    | PATTERN ->
        _menhir_run100 _menhir_env (Obj.magic _menhir_stack) MenhirState0 _menhir_env._menhir_startp
    | PRINT ->
        _menhir_run95 _menhir_env (Obj.magic _menhir_stack) MenhirState0 _menhir_env._menhir_startp
    | PROBLEM ->
        _menhir_run88 _menhir_env (Obj.magic _menhir_stack) MenhirState0 _menhir_env._menhir_startp
    | SOLVE ->
        _menhir_run79 _menhir_env (Obj.magic _menhir_stack) MenhirState0 _menhir_env._menhir_startp
    | TILES ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState0 _menhir_env._menhir_startp
    | TIMING ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState0 _menhir_env._menhir_startp
    | EOF ->
        _menhir_reduce45 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | _ ->
        assert (Pervasives.(<>) _menhir_env._menhir_shifted (-1));
        _menhir_env._menhir_shifted <- (-1);
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState0) : 'freshtv2)) : 'freshtv4))



