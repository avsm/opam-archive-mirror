let version = "0.42"
let date = "Tue Oct 16 13:38:00 CEST 2012"
