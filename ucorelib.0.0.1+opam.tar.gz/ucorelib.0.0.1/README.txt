(* OASIS_START *)
(* DO NOT EDIT (digest: d2d6c6ee7a29897d1ffb899906c3f679) *)
This is the README file for the ucorelib distribution.

A light weight Unicode library for OCaml

See the files INSTALL.txt for building and installation instructions. 


(* OASIS_STOP *)
