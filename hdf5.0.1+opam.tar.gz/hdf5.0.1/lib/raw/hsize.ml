type t = int
let unlimited = -1
