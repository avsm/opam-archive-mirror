H5R_type_t H5R_type_val(value);
value Val_h5r_type(H5R_type_t);

