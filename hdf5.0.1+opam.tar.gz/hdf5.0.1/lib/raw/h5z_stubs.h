H5Z_filter_t H5Z_filter_val(value);
value Val_h5s_class(H5Z_filter_t);
unsigned flag_val(value);
