let () =
  let person = Person_pb.{name = "foo"} in
  print_endline "testing"
