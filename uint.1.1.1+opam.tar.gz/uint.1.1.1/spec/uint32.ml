#load "uint32.cma";;
open Uint32;;
#use "spec/common.ml";;
