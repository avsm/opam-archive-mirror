int main(void) {
# 1
  int f();;
  return f() ? : 4;
}
