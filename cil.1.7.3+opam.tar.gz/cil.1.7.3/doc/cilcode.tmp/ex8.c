  int a1[5] = {1,2,3};
  struct foo { int x, y; } s1 = { 4 };
