  unsigned long foo() {
    return (unsigned long) - 1 / 8;
  }
