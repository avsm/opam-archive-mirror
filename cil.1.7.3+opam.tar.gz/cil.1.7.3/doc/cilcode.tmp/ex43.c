int main(void) {
# 1
 return ({goto L; 0;}) && ({L: 5;});
}
