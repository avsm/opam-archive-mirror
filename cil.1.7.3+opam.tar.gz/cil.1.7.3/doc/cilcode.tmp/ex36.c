int main(void) {
# 1
 return ((int []){1,2,3,4})[1];
}
