int main(void) {
# 1
  int x;
  return x == (1 && x);
}
