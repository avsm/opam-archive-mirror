typedef int int_t;
typedef int int2_t;

int_t f(int2_t int2_t[]) {
  int_t int_t = int2_t[0];
  {
    int int2_t = 2*int_t;
    return int2_t;
  }
}
