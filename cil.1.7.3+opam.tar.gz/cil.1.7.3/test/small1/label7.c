int main() {
	int x;
 _L:
	if (x || ++x) { x++; x++; x++; x++; x++; x++; }
	return 0;
}
