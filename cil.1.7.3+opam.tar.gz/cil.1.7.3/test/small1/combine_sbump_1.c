 struct f;
 static __inline__    int   sbump(struct   f *const);

