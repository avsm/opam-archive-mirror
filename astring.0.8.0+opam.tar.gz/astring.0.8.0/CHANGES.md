v0.8.0 2015-12-14 Cambridge (UK)
--------------------------------

First release.
