let package_name = "ppx_variants_conv"

let sections =
  [ ("lib",
    [ ("built_lib_ppx_variants_conv", None)
    ],
    [ ("META", None)
    ])
  ]
