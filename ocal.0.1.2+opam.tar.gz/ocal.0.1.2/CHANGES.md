### 0.1.2 (2016-01-07)

* Fix handling several command line flags (`--today`, `--plain`, `--separator`)

### 0.1.1 (2016-01-05)

* Initial release
