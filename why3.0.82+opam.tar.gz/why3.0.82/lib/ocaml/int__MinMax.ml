(* This file has been generated from Why3 theory int.MinMax *)

let min = Num.min_num
let max = Num.max_num

