(* This file has been generated from Why3 theory int.ComputerDivision *)

(* Note: documentation for Num says ``Euclidean division'' but this is
   rather a computer division *)

let div = Num.quo_num

let mod_renamed = Num.mod_num
