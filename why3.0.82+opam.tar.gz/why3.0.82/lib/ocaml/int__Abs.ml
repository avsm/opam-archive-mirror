(* This file has been generated from Why3 theory int.Abs *)

let abs = Num.abs_num



