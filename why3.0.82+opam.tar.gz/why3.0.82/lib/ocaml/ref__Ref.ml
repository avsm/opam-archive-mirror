(* This file has been generated from Why3 module ref.Ref *)

(* type ref is overridden by driver *)

(* symbol ref is overridden by driver *)

(* symbol prefix_ex is overridden by driver *)

(* symbol infix_cleq is overridden by driver *)


