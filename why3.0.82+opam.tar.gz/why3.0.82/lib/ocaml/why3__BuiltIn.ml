
type int = Num.num

let infix_eq = Pervasives.(=)

let int_constant = Num.num_of_string

