# otto
Testing library developed to automate grading.

For examples of use, see `test/test.ml`
