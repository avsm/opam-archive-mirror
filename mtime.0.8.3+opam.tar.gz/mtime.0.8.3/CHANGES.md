v0.8.3 2015-12-22 Cambridge (UK)
--------------------------------

* Fix Linux bytecode builds. Thanks to Edwin Török for the report.
* Really make js_of_ocaml an optional dependency.


v0.8.2 2015-05-17 La Forclaz (VS)
---------------------------------

* Simpler toploop support (internal change).
* Improve Linux build support by recording link flags against librt in
  the cma and cmxa (this seems to be needed in certain distributions).
  Thanks to David Scott for the report and the fix.


v0.8.1 2015-03-23 La Forclaz (VS)
---------------------------------

* Fix broken arithmetic on 32-bit platform with POSIX clocks. Thanks to
  Stephen Dolan for the report and the fix.


v0.8.0 2015-03-19 La Forclaz (VS)
---------------------------------

First release.
