#ifndef BACKTRACE_H
#define BACKTRACE_H

void backtrace_init ();

#endif
