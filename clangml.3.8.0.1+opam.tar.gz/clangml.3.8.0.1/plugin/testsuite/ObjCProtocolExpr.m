@protocol p1
@end

void f() {
  Protocol *proto = @protocol(p1);
}
