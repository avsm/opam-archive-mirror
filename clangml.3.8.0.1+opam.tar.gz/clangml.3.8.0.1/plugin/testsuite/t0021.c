// t0021.c
// c89 coverage

int foo()
{
  // implicit decl
  return not_declared();
}
