void unix_errno_reset();
int unix_errno_get();
