The Electrum Analyzer relies on the following third-party software, released
under their respective licence (shown below; see the respective OPAM
repositories for the full text of the licences):
* pprint: CeCILL-C;
* menhir generator: Q Public License v1.0 + special exception;
* menhirLib: GNU LGPL v2 + special exception;
* batteries: GNU LGPL v2.1;
* cmdliner: BSD3.
