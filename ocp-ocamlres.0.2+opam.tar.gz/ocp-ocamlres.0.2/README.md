A tool `ocp-ocamlres` to embed files and directories inside
OCaml executables, with a companion library `ocplib-ocamlres` to
manipulate them at run-time.

This is not an officially released product, it is still in design
stage and all suggestions and comments on the design are most welcome.

Both are released under the terms of the GNU Lesser General
Public License as published by the Free Software Foundation; either
version 3.0 of the License, or (at your option) any later version.

This project is part of TypeRex, developed and maintained by OCamlPro.
Documentation to install and use this tool is available on
http://www.typerex.org/ocp-ocamlres.html
