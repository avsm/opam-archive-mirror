#import "config.h"

#ifdef FOO
let x = true
#else
let y = false
#endif
