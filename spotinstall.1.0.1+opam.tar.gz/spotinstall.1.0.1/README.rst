===========================================
SpotInstall : a tool to install annot files
============================================

SpotInstall is a tool to facilitate the installation of OCaml annotation files (.cmt, .cmti, .spot, .spit). 

Introduction
===============================

Many existing OCaml libraries, applications and the compiler itself do not produce or install the annotation files (.annot, .cmt, .cmti, .spot, .spit) which are essential for subexpression type queries (caml-types.el), definition seaches and code refactoring (TypeRex and OCamlSpotter). If you want to use development tools, you have to:

* Rebuild all the software from their source, adding -annot/-bin-annot option to compiler flags in build scripts i.e. Makefile/OCamlBuild/OMakefile.
* Install those annotation files together with the library objects and signatures. (Require modification of the build scripts)

for all the programs.

I propose a workaround, consists of two things:

* A very small compiler patch which activates -annot and -bin-annot if OCAML_ANNOT environment variable is defined. (You no longder need to add -annot/-bin-annot to the build scripts.)
* A small tool to install annotation files to the library destination directory. (You no longer need to add annotation file installation to the build scripts.)

For the first workaround, you need a small patch available from::

    hg clone -b annot https://bitbucket.org/camlspotter/mutated_ocaml

or included in this directory, ocaml-annot-<version>.patch.

For the second one, you can use SpotInstall. This tool.

Installation
==============================

You need:

* omake
* spotlib ( https://bitbucket.org/camlspotter/spotlib )

First create OMakefile.root by::

    yes no | omake --install

then::

    omake 
    omake install

Synopsis
==============================

Stay in the source code directory of ``<package>``, then

::

    spotinstall <packages>

The command checks the files in the installation directory of OCamlFind package <package>, and if there are corresponding annotation files in the current and its sub directories, copy them to the installation directory.

If ``<package>`` is ``ocaml``, spotinstall works bit differently and copies the annotation files built under OCaml compiler source tree.


Notes
===============================

To use the annotation files installed by SpotInstall smoothly, you should keep your source trees and their annotation files.
