v0.6.0 2016-08-08 Zagreb
-------------------------

First release. 
