### 0.1.4 (2015-08-12)

+ Fixing OPAM and Make runes
+ Inline environment stuff for Mirage for now

### 0.1.3 (2015-07-08)

+ More OPAM and Make runes
+ Add `bin/mirage_env.ml` as it's not released yet
+ Update Oasis outputs

### 0.1.2 (2015-07-08)

+ First cut, quite basic, release
+ Basic TFTP protocol support; no options yet, mode=octet only
+ Simple Mirage unikernel server included
