#!/bin/sh

(* For compatibility with scripts, merlin should not emit errors for
   shebang on the first line *)
let () = ()
