v0.6.1 2016-09-14 Zagreb
------------------------

`browse(1)` command line tool: convert existing file paths
specified on the cli to file:// URIs.


v0.6.0 2016-08-08 Zagreb
-------------------------

First release. 
