/* This is just here for ocamlbuild to generate a correct dlludev_stubs.so object */

void libudev_nop (void) { return; }
