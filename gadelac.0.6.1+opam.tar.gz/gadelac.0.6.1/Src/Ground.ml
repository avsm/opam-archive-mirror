open Printf

module C = Utils.Choice
module D = Domain.Exact
module NaiveE = Reachability.Naive (D)

let step_vars domain depth clause vars =
  let subs = NaiveE.substitutions domain clause in
  let subs = List.map (Variable.Map.filter (fun key _ -> List.mem key vars)) subs in
  let asubs = List.map (Variable.Map.mapi (fun key term -> Ast.abstract (Generate.variable (key ^ "_")) depth term)) subs in
  Utils.PList.uniques (Utils.PList.maps (fun sub -> Desugared.apply_clause sub clause) asubs)

let expand_variables domain = step_vars domain max_int

let instantiate_context dep_map prog context : Desugared.program =
  let inst_clause clause =
    let vars = Context.to_variable context clause in
    let vars = Variable.Set.elements vars in
(*    eprintf "Ground: context %s, vars %s\n%s\n\n" (Context.print context) (Utils.Print.unspaces Utils.Print.string vars) (Desugared.Print.clause clause);*)
    expand_variables dep_map clause vars in
 Utils.PList.maps inst_clause prog

let instantiate_contexts dep_map contexts prog = List.fold_left (instantiate_context dep_map) prog contexts

let all_atoms prog = NaiveE.backward false prog
let program contexts prog = if contexts <> [] then instantiate_contexts (all_atoms prog) contexts prog else prog

let full_program prog =
  let domain = all_atoms prog in
  let full_clause clause = step_vars domain max_int clause (Desugared.get_variables_clause clause) in
  Utils.PList.uniques (Utils.PList.maps full_clause prog)

let relevant_depth param terms =
  let max_depth = List.fold_left max 0 (List.map Ast.depth_term terms) in
  if List.length terms <= param then max_depth
  else
    let var () = "" in
    let rec aux depth =
      let terms = Utils.PList.uniques (List.map (Ast.abstract var depth) terms) in
      if List.length terms <= param then aux (depth + 1)
      else depth - 1 in
    aux 1

let count_clause param domain clause =
  let subs = NaiveE.substitutions domain clause in
  let doms = Variable.Map.merges Utils.PList.uniques subs in
  let deps = Variable.Map.map (relevant_depth param) doms in
  let aux var depth clauses = Utils.PList.uniques (Utils.PList.maps (fun clause -> step_vars domain depth clause [var]) clauses) in
  Variable.Map.fold aux deps [clause]
  
let count_program param prog =
  let domain = all_atoms prog in
  Utils.PList.uniques (Utils.PList.maps (count_clause param domain) prog)
