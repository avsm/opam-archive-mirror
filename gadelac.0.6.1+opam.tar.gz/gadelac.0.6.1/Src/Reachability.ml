open Printf

let deprintf format = if false then eprintf format else ifprintf stderr format

module C = Utils.Choice

let fluent = [Ast.Variable "fluent"]
let true_init = ((Ast.True, fluent), [Desugared.Okay (Ast.Init, fluent)])
let true_next = ((Ast.True, fluent), [Desugared.Okay (Ast.Next, fluent)])
let true_neg  = ((Ast.True, fluent), [Desugared.Okay (Ast.Negative, fluent)])
let true_pos  = ((Ast.True, fluent), [Desugared.Okay (Ast.Positive, fluent)])
let does_legal =
  let player_move = [Ast.Variable "player"; Ast.Variable "move"] in
  ((Ast.Does, player_move), [Desugared.Okay (Ast.Legal, player_move)])

let add_frames rules = does_legal :: true_next :: true_init :: true_neg :: true_pos :: rules

module Naive (D : Domain.S) =
struct
  let body_filter negate domain body subs =
    let aux subs = function
      | Desugared.Okay atom -> D.compose domain subs atom
      | Desugared.Negation atom -> if negate then D.neg_compose domain subs atom else subs
      | Desugared.Distinct (var, term) -> if negate then D.dist_compose subs var term else subs in
    List.fold_left aux subs body

  let substitutions domain (head, body) = body_filter false domain (Desugared.Okay head :: body) D.unit
    
  let forw_step_rule negate domain (head, body) =
    let subs = body_filter negate domain body D.unit in
    D.add_subs subs head domain

  let back_step_rule domain negate needed (head, body) =
    deprintf "Engine: clause %s\n%!" (Desugared.Print.clause (head, body));
    let subs = body_filter negate domain body (D.unify head needed) in
    let apply_lit needs = function
      | Desugared.Okay atom | Desugared.Negation atom -> (*eprintf "Reachability: need %s, %d subs\n" (Ast.Print.atomic atom) (List.length subs);*)
        D.add_subs subs atom needs
      | Desugared.Distinct _ -> needs in
    List.fold_left apply_lit needed body

  let rec fixpoint negate step_rule domain rules =
    assert (Safety.sorted rules);
    let domain2 = List.fold_left (step_rule negate) domain rules in
    if D.equal domain2 domain then domain else fixpoint negate step_rule domain2 rules

  let stage_program program =
    let program = Safety.sort program in
    let graph = Analysis.dep_graph program in
    let scc = Pred.SCC.tarjan graph in
    let comp_rules comp = List.filter (fun ((pred, _), _) -> Pred.Set.mem pred comp) program in
    Utils.PList.map comp_rules scc

  let forward exact program =
    let program = if not exact then add_frames program else program in
    let stages = stage_program program in
    List.fold_left (fixpoint exact forw_step_rule) D.empty stages

  let needed_atoms forw =
    let facts = [(Ast.Role, [Ast.Variable "name"]);
                 (Ast.Terminal, []);
                 (Ast.Legal, [Ast.Variable "name"; Ast.Variable "action"]);
                 (Ast.Goal, [Ast.Variable "name"; Ast.Variable "score"])] in
    let subs = List.fold_left (D.compose forw) D.unit facts in
    deprintf "subs: %s\n" (D.print_subs subs);
    Utils.PList.fold_right (D.add_subs subs) facts D.empty

  let backward exact program =
    let program = if not exact then add_frames program else program in
    let stages = stage_program program in
    let forw_domain = List.fold_left (fixpoint exact forw_step_rule) D.empty stages in
    deprintf "domain: %s\n" (D.print forw_domain);
    let needed = needed_atoms forw_domain in
    deprintf "needed: %s\n" (D.print needed);
    List.fold_left (fixpoint exact (back_step_rule forw_domain)) needed (List.rev stages)

  let prune program =
    let back = backward false program in
    let useful_rule clause = D.consistent (substitutions back clause) in
    let useful, useless = List.partition useful_rule program in
    useless, useful
end

module NaiveE = Naive (Domain.Exact)
module NaiveP = Naive (Domain.Path)
module NaiveG = Naive (Domain.Graph)

type param = Trivial | Graph | Paths | Precise
let print = function
  | Trivial -> "trivial"
  | Graph -> "graph"
  | Paths -> "paths"
  | Precise -> "precise"
let make param program =
  let prune = match param with
    | Trivial -> (fun prog -> ([], prog))
    | Graph -> NaiveG.prune
    | Paths -> NaiveP.prune
    | Precise -> NaiveE.prune in
  let useless, useful = prune program in
  if useless <> [] then eprintf "REACHABILITY: The following rules are deemed useless\n%s\n%!" (Utils.Print.list Desugared.Print.clause useless);
  useful
