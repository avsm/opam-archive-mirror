include DataStructure.F (struct type t = int let compare = compare let print = Print.int end)
