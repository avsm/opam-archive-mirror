type 'a t = 'a option

let get = function
  | Some a -> a
  | None -> assert false

let gets l = 
  let rec aux accu = function
    | [] -> accu
    | None :: r -> aux accu r
    | Some  a :: r -> aux (a :: accu) r in
  List.rev (aux [] l)

let map f = function
  | Some a -> Some (f a)
  | None -> None

let default f b = function
  | Some a -> f a
  | None -> b

let perform f x = default f () x

let combine f a b = match a, b with
  | None, _ | _, None -> None
  | Some aa, Some bb -> Some (f aa bb)

let bind old f = match old with
  | Some a -> f a
  | None -> None
