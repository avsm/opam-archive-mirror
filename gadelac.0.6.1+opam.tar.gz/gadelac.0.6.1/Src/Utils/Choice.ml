open Printf

type ('a, 'b) t = Left of 'a | Right of 'b

let print pleft pright = function
  | Left  a -> pleft  a
  | Right b -> pright b

let get = function
  | Left a -> a
  | Right b -> b

let get_left b = function
  | Left  a -> a
  | Right _ -> b

let get_right a = function
  | Left  _ -> a
  | Right b -> b

let partition f l =
  let rec aux (left, right) element = match f element with
    | Left  a -> (a :: left, right)
    | Right b -> (left, b :: right) in
  let (left, right) = List.fold_left aux ([], []) l in
  (List.rev left, List.rev right)

let partition_id l =
  let rec aux (left, right) = function
    | Left  a -> (a :: left, right)
    | Right b -> (left, b :: right) in
  let (left, right) = List.fold_left aux ([], []) l in
  (List.rev left, List.rev right)
  
let map f g = function
  | Left  a -> Left  (f a)
  | Right b -> Right (g b)
let map_left f = function
  | Left  a -> Left (f a)
  | Right b -> Right b
let map_right f = function
  | Left  a -> Left a
  | Right b -> Right (f b)
