open Printf

let deprintf format = if true then eprintf format else ifprintf stderr format

module C = Utils.Choice
module DS = Variable.DisjointSet

let rename_lit map = Unification.apply_literal (Variable.Map.map Ast.variable map)

let make_eqs vars args =
  assert (List.length vars = List.length args);
  let var_args = List.combine vars args in
  let rec aux (accu_eqs, accu_sub) (var, term) =
    match Desugared.rename_variables_term accu_sub term with
    | Ast.Variable v when not (List.mem v vars) -> (accu_eqs, Variable.Map.add v var accu_sub)
    | term2 -> (Ast.Equal (Ast.Variable var, term2) :: accu_eqs, accu_sub) in 
  List.fold_left aux ([], Variable.Map.empty) var_args

let force_body vars args body =
  let (eqs, sub) = make_eqs vars args in
  Utils.PList.map (rename_lit sub) body @ eqs
  
let regroup program =
  let make_vars pred = Utils.PList.map (sprintf "inline_%d") (Utils.PList.range 0 (Ast.arity_pred pred)) in
  let add map ((pred, args), body) =
    let (vars, bodies) = Pred.Map.find_default pred (make_vars pred, []) map in
    let body = Utils.PList.map Desugared.sugar_lit body in
    let body = force_body vars args body in
    Pred.Map.add pred (vars, body :: bodies) map in
  List.fold_left add Pred.Map.empty program

let add_literal context disj_set (var_map, others) lit =
  let relevant_vars = Utils.PList.subtract (Ast.get_variables_lit lit) context in
  match relevant_vars with
  | [] -> (var_map, lit :: others)
  | var :: rest ->
    let var = DS.find var disj_set in
    assert (List.for_all (fun elt -> DS.find elt disj_set = var) rest);
    (Variable.Map.update var (Utils.PList.cons lit) [] var_map, others)

let new_predicate = Generate.predicate "inline_negation"

let make_literal context var lits (accu, new_rules) =
  assert (List.length lits > 0);
  let body_vars = Utils.PList.maps Ast.get_variables_lit lits in
  let comm_vars = List.filter (Utils.PList.memr body_vars) context in
(*  let new_rules, new_head = Generate.add_rule_ast new_rules comm_vars lits in*)
  let new_head = (new_predicate (List.length comm_vars), List.map Ast.variable comm_vars) in
  deprintf "Inline: %s %s\n" (Ast.Print.atomic new_head) (Utils.Print.list Ast.Print.literal lits);
  (Ast.Okay new_head :: accu, (new_head, lits) :: new_rules)
(*    (Ast.Okay new_head :: accu, new_rules)*)

let cluster_variables context (accu, new_rules) conj =
  let relevant_vars lit = Utils.PList.subtract (Ast.get_variables_lit lit) context in
  let use_literal dset lit = DS.unions (relevant_vars lit) dset in
  let disj_set = List.fold_left use_literal DS.empty conj in
  let (var_map, others) = List.fold_left (add_literal context disj_set) (Variable.Map.empty, []) conj in
  let lits, ruls = Variable.Map.fold (make_literal context) var_map ([], new_rules) in
  ((lits @ others) :: accu, ruls)

let inline_neg new_rules args vars bodies =
  let original_vars = Utils.PList.uniques (Utils.PList.maps Ast.get_variables args) in
  assert (List.length args = List.length vars);
  assert (Utils.PList.no_doubles vars);
  let var_args = List.combine vars args in
  let replace_bodies bodies rep = Utils.PList.map (Utils.PList.map (Ast.replace_variable_lit rep)) bodies in
  let bodies = List.fold_left replace_bodies bodies var_args in
  let bodies, rules = List.fold_left (cluster_variables original_vars) ([], new_rules) bodies in
  let bodies = Utils.PList.map (Utils.PList.map Ast.negate) bodies in
  let bodies = Utils.PList.cross_products bodies in
  (bodies, rules)

let inline_pos args vars bodies =
  assert (List.length args = List.length vars);
  let eqs = List.map2 (fun var arg -> Ast.Equal (Ast.Variable var, arg)) vars args in
  List.map ((@) eqs) bodies

let inline_literal_aux group new_rules = function
  | Desugared.Distinct (var, term) -> None
  | Desugared.Negation (Ast.Does, _) | Desugared.Okay (Ast.Does, _)
  | Desugared.Negation (Ast.True, _) | Desugared.Okay (Ast.True, _) -> None
  | Desugared.Okay (pred, args) ->
    assert (Pred.Map.mem pred group);
    let (vars, bodies) = Pred.Map.find pred group in
    Some (inline_pos args vars bodies, new_rules)
  | Desugared.Negation (pred, args) ->
    let (vars, bodies) = Pred.Map.find pred group in
    Some (inline_neg new_rules args vars bodies)

let inline_literal param group (accu_lits, new_rules) lit = match inline_literal_aux group new_rules lit with
  | None -> ([[Desugared.sugar_lit lit]] :: accu_lits, new_rules)
  | Some (lits, _) when List.length lits > param -> ([[Desugared.sugar_lit lit]] :: accu_lits, new_rules)
  | Some (lits, rules) -> (lits :: accu_lits, rules)

let is_consistent (_, body) =
  let is_fact = function | Desugared.Distinct _ -> None | Desugared.Okay fact -> Some (C.Right fact) | Desugared.Negation fact -> Some (C.Left fact) in
  let negs, poss = C.partition_id (Utils.PList.filter_map is_fact body) in
  Utils.PList.intersect negs poss = []

let inline_clause param group (accu, new_rules) (head, body) =
  let inlined_lits, rules = List.fold_left (inline_literal param group) ([], new_rules) body in
  let inlined_lits = List.rev inlined_lits in
  let bodies = Utils.PList.cross_products inlined_lits in
  let clauses = Utils.PList.uniques (Utils.PList.map (fun bod -> (head, Utils.PList.uniques (Utils.PList.flatten bod))) bodies) in
  let clauses = Utils.PList.maps Desugared.from_clause clauses in
  let clauses = Utils.PList.uniques (List.filter is_consistent clauses) in
  List.rev_append clauses accu, rules

let inline_aux param base prog =
  let group = regroup base in
(*  let rules, new_rules = List.fold_left (inline_clause param group) ([], Generate.empty new_predicate) prog in*)
  let rules, new_rules = List.fold_left (inline_clause param group) ([], []) prog in
  List.rev_append rules (Utils.PList.maps Desugared.from_clause new_rules) (*Generate.get new_rules*)

let inline_program param prog = inline_aux param prog prog

let program param prog = if param < 0 then prog else inline_program param prog
(*let make = try inline_program with _ -> assert false*)

(** Things to do: avoid recreating existing rules so that we can use a fixpoint computation. *)
