open Printf

let deprintf format = if false then eprintf format else ifprintf stderr format

module Hyps =
struct
  module Ord = struct type t = string list * Desugared.literal list 
                      let compare = compare 
                      let print = Utils.Print.couple (Utils.Print.list Utils.Print.string) (Utils.Print.unspaces Desugared.Print.literal) end
  include Utils.DataStructure.F (Ord)
end

type t = (int -> Ast.predicate) * Ast.atomic Hyps.Map.t

let make_head predicate required_vars lits =
  let vars = Utils.PList.maps Desugared.get_variables_lit lits in
  assert (List.for_all (Utils.PList.memr vars) required_vars);
  let required_vars = List.sort compare required_vars in
  let pred = predicate (List.length required_vars) in
  (pred, Utils.PList.map Ast.variable required_vars)

let replace_vars map = Utils.PList.map (Desugared.rename_variables_lit map)

let choose_one =
  let rec aux choices before = function
    | [] -> List.rev choices
    | a :: after -> aux ((a, List.rev_append before after) :: choices) (a :: before) after in
  aux [] []

let rec unify_args map b1 b2 = match b1, b2 with
  | [], [] -> Some map
  | [], _ :: _ | _ :: _, [] -> assert false
  | Ast.Fact a1 :: r1, Ast.Fact (s2, a2) :: r2 -> if a1 = (s2, Utils.PList.map (Desugared.rename_variables_term map) a2) then unify_args map r1 r2 else None
  | Ast.Fact _ :: _, Ast.Variable _ :: _ | Ast.Variable _ :: _, Ast.Fact _ :: _ -> None
  | Ast.Variable v1 :: r1, Ast.Variable v2 :: r2 -> 
    if Variable.Map.mem v2 map
    then if v1 = Variable.Map.find v2 map then unify_args map r1 r2 else None
    else if List.mem v1 (Variable.Map.values map) then None
    else unify_args (Variable.Map.add v2 v1 map) r1 r2

let rec unify_body b1 b2 map = match b1, b2 with
  | [], [] -> [map]
  | [], _ :: _ -> []
  | a :: r, _ -> Utils.PList.filter_maps (unify_hyp map (a, r)) (choose_one b2)
and unify_hyp map (a1, b1) (a2, b2) = match a1, a2 with
  | Desugared.Okay (p1, _), Desugared.Okay (p2, _)
  | Desugared.Negation (p1, _), Desugared.Negation (p2, _) when p1 <> p2 -> None
  | Desugared.Okay _, Desugared.Negation _ | Desugared.Okay _, Desugared.Distinct _
  | Desugared.Negation _, Desugared.Okay _ | Desugared.Negation _, Desugared.Distinct _
  | Desugared.Distinct _, Desugared.Okay _ | Desugared.Distinct _, Desugared.Negation _ -> None
  | Desugared.Negation (_, args1), Desugared.Negation (_, args2)
  | Desugared.Okay     (_, args1), Desugared.Okay     (_, args2) -> Utils.Option.map (unify_body b1 b2) (unify_args map args1 args2)
  | Desugared.Distinct (v1, t1),   Desugared.Distinct (v2, t2)   -> Utils.Option.map (unify_body b1 b2) (unify_args map [Ast.Variable v1; t1] [Ast.Variable v2; t2])

let unify vars1 body1 (vars2, body2) head =
  assert (Utils.PList.no_doubles vars1 && Utils.PList.no_doubles vars2);
  if List.length vars1 <> List.length vars2 then None
  else
    let vars = List.combine vars2 vars1 in
    let map = Variable.Map.from_bindings vars in
    match unify_body body1 body2 map with
    | [] -> None
    | a :: r ->
      if r <> [] then eprintf "Generate many unifs: %d %s\n" (1 + List.length r) (Utils.Print.unspaces (Variable.Map.print Utils.Print.string) (a :: r));
      Some (Desugared.rename_variables_atomic a head)

let add_rule (predicates, rules) vars body =
  let substitutions = Hyps.Map.filter_mapi (unify vars body) rules in
  match Hyps.Map.values substitutions with
  | [] -> 
    let head = make_head predicates vars body in
    deprintf "Generate created rule:\n%s\n%!" (Desugared.Print.clause (head, body));
    ((predicates, Hyps.Map.add (vars, body) head rules), head)
  | head :: [] -> ((predicates, rules), head)
  | _ :: _ :: _ -> assert false

let empty predicates = (predicates, Hyps.Map.empty)
let get (_, rules) = Hyps.Map.fold (fun (_, body) head accu -> (head, body) :: accu) rules []

let variable prefix =
  let counter = ref (-1) in
  let next () =
    incr counter;
    sprintf "%s%d" prefix !counter in
  next
let predicate prefix =
  let counter = ref (-1) in
  let next arity =
    incr counter;
    let name = sprintf "%s%d" prefix !counter in
    Ast.Constant (name, arity) in
  next
