Authors of OSM:

* Alexander Dinu