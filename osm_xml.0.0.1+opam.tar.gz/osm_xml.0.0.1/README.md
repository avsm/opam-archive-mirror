OSM
=============================

[![Build Status](https://travis-ci.org/aluuu/osm_xml.svg?branch=master)](https://travis-ci.org/aluuu/osm_xml)

OSM XML parsing library. Using streaming codec [Xmlm](http://erratique.ch/software/xmlm) for parsing.

Documentation
---------------------

API documentation can be found [here](http://aluuu.husa.su/osm_xml/).

See the file [INSTALL.md](INSTALL.md) for building and installation
instructions.

Copyright and license
---------------------

OSM is distributed under the terms of the Berkeley software distribution
license (3 clauses).
