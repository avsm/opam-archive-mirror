Because of licensing issues, no external documentation can be included.

You can run "sh fetch-doc.sh" to get required external documentation.
