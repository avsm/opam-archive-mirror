  * Improve speed of resizable float arrays by implementing a fast creation
    function that does not initialize the memory.

  * Extend the functionality of bit-vectors with efficient functions for e.g.
    "land", "lor", etc...
