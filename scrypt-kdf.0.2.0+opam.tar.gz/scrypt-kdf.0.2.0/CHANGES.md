# 0.2.0 (2016-10-31)

* Added topkg dependency
* Optimized inner loop in salsa_core to improve performance
* Replaced custom clone function by Nocrypto's implementation

# 0.1.0 (2016-03-18)

* Initial release
