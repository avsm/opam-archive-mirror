#include <stdio.h>

void f () { printf ("Called C-function!\n"); }
