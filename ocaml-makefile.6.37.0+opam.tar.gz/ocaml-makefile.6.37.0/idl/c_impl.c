#include <stdio.h>

float f (char *str, int n) {
  printf ("str is: %s\nn is: %d\n", str, n);
  return n*n;
}
