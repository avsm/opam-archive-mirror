v0.1.0 2016-11-04 Cambridge
---------------------------

Initial public release.
