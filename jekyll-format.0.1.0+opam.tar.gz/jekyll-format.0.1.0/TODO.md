* A proper YAML parser instead of the handcrafted limited one here.
* Code highlighting via a port of Pygments.rb
* Full liquid template support.
* Test it on more real-world Jekyll posts.
