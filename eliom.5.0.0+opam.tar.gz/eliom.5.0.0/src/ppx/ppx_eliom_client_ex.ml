
let () = Ast_mapper.run_main Ppx_eliom_client.mapper
