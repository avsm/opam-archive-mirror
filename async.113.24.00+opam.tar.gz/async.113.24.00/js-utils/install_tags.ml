let package_name = "async"

let sections =
  [ ("lib",
    [ ("built_lib_async", None)
    ],
    [ ("META", None)
    ])
  ]
