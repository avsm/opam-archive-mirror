A simple Lwt-based module for reading binary numbers from disk.
