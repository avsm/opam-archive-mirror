Facebook Graph API Client Library for OCaml
-------------------------------------------

Access version 1.0 of the Facebook Graph API in OCaml applications.  
The Facebook Graph API documentation is 
[here](https://developers.facebook.com/docs/graph-api/reference/v1.0).