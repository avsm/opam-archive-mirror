ocaml-xen-lowlevel-libs
=======================

Tracks the ocaml libxc et al from [xen-unstable.hg](http://xenbits.xensource.com/xen-unstable.hg).

The latest, greatest bindings should be staged here and then upstreamed and then pulled back into the 'upstream' branch.

Note: the packages generated will conflict with those from a normal xen build.
