## 113.00.00

- Added support for records where some fields are optionally displayed.

