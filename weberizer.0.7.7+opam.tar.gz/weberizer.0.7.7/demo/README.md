License
=======

The files in this directory and under are provided as an example of
what the library allows to do.  They are copyrighted by the University
of Mons and cannot be used for any purpose other than demonstrating
the use of weberizer.
