(* OASIS_START *)
(* DO NOT EDIT (digest: 5fbe2ab345898ddbc543bb4835782951) *)
This is the README file for the weberizer distribution.

HTML templating system.

Weberizer compiles HTML templates into OCaml modules.

See the files INSTALL.txt for building and installation instructions. 

Home page: https://github.com/Chris00/weberizer


(* OASIS_STOP *)
