caravan
=======

A framework for testing arbitrary systems, in OCaml. Inspired by Erlang/OTP's
[Common Test] (http://www.erlang.org/doc/apps/common_test/basics_chapter.html).
