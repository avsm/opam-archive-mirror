#ifndef _ASSERT_H
#define _ASSERT_H

#define assert(x) (void)0

#endif
