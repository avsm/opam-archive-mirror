#ifndef _FEATURES_H
#define _FEATURES_H

/* No features, isn't that nice? */

#endif
