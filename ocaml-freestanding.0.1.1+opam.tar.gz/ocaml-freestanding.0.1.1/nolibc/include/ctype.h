#ifndef _CTYPE_H
#define _CTYPE_H

int isalpha(int);
int isdigit(int);
int isprint(int);
int isspace(int);
int isupper(int);

#endif
