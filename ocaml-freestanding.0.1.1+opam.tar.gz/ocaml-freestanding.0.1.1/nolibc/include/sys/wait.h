#ifndef _SYS_WAIT_H
#define _SYS_WAIT_H

#endif
