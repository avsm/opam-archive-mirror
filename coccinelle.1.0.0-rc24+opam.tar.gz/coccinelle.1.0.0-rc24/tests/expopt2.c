void main(int i) {

  f(v, w.aa);

}
