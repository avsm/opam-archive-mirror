int main() {
  f(4294967295);
}
