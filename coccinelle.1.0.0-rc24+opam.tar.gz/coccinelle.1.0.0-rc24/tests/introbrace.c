int main() {
	if (x)
		rc = request_threaded_irq(a,
					  b);
	else
		rc = request_threaded_irq(a,
					  b);
}
