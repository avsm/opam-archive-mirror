int main () {
  f('XYZ',ab);
  f('X\nY',ab);
  f('\n',ab);
}
