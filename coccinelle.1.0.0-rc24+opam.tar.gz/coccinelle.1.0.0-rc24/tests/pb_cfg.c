void main(int i) {

  f(1);
  goto return_0;
  f(1);
label1:
  f(2);
  return;

}
