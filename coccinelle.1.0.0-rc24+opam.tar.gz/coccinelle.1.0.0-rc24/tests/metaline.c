int main () {
  static int x;
  static int y;
  if (12) f(4+3);
  g(4+3);
  m(3+3);
  g(3+3);
  r(3+4);
}
