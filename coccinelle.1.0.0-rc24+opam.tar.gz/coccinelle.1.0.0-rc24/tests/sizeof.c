int main (int param) {

  int i = sizeof(3);
  int j = sizeof 3;
  int k = sizeof (int *);

}
