#pragma xxx a b c

#pragma xxx (a, b, c)
