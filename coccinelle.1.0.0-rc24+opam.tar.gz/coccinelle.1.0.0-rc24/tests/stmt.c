int f() {
  int x;
  xxx();
}
