struct foo x = {
  .xa = 1,
  .xb = 2,
  .xc = 3,
};
