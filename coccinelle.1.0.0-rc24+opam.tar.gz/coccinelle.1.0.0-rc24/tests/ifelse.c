
int f(void)
{
if (x1)
   w++;
else if (y1)
   z--;
else if (z1)
   a--;

if (x2)
   w++;
else if (y2)
   z--;

if (x3)
   {
   w++;
   }
else if (y3)
   {
   z--;
   }

if (x4)
   w++;
else if (y4)
   z--;
else if (z4)
   a--;
else if (a4)
   a--;
}


function if_if(void)
{
if (x4)
   w++;
if (y4)
   z--;

dummy--;

if (x5)
   w++;
A++;
if (y5)
   z--;

}

