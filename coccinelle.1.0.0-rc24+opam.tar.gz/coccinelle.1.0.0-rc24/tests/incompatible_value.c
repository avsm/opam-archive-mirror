int main() { 
	f(1); 
	f(2); 
}

int main() { 
	g(1); 
	g(2); 
}



