static unsigned mii_rd(ioaddr_t ioaddr,	u_char phyaddr, u_char phyreg);

int init(void)
{
  foo();
}
