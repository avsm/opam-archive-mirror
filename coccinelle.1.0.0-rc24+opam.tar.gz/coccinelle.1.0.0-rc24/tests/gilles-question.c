void main(int i) { 

  f(0);
  if(1) {
    g(0);
  }
  g(0);
}
      
