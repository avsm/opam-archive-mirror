void foo() { return; }
