
MODULE_PARM(cm206_base, "i");	/* base */


static void do_cm206_request(request_queue_t * q)
{
	long int i;

}
