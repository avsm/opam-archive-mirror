int a(x)
  b c;
{
  y = (j)
    r;
  foo();
}
