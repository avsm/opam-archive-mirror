int main() {
  if (foo()) xxx();
  xxx();
  if (foo()) return;
  return;
}
