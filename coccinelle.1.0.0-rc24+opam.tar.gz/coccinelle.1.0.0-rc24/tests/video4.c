int main() {
  int v;
  m();
  f(1);
  x();
  v.x = 12;
  v.y = 21;
  g(1);
  f(2);
  x();
  v.xafter = 12;
  v.yafter = 21;
  g(2);
  n();
}
