void main(int i)
{

  const struct file_operations a;
  struct file_operations b;

}
