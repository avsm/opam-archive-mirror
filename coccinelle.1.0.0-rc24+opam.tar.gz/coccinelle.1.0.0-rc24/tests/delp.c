int main () {
  return
    (foo);
}
