int c;

int main () {
  int a;
  f(a);
  f(a+1);
  f(b);
  f(c);
}
