#ifndef ML_IRR_ENUMS_H
#define ML_IRR_ENUMS_H

#include "global.h"

#include "irr_enums_wrap_values.h"
#include "irr_enums_wrap_poly_values.h"
#include "irr_enums_wrap_conv.h"

#endif
