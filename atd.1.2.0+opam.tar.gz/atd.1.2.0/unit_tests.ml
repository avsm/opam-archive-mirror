let main () =
  Atd_sort.test ()

let () = main ()
