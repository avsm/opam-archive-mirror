0.1.2 / 2014-03-11
==================

  * Added oasis to opam dependencies.

0.1.1 / 2014-03-10
==================

  * Added ocaml version constraint to 4.01.0

0.1.0 / 2014-03-04
==================

  * Initial prototype working implementation.