A simple SMTP server for OCaml
------------------------------

A lightweight SMTP server component for OCaml intended for developers
who need to accept emails received via SMTP into their applications.
Accepts all emails sent to it.