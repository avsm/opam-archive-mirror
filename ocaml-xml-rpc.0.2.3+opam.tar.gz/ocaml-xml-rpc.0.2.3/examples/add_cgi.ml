

let _ =
  try
    let server = CgiSource.make () in
      Add.add_two server (+);
      XmlRPCServer.run server
  with
    | CgiSource.Done -> exit 0




