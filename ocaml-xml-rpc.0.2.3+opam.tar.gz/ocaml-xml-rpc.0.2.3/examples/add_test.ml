
let add = Add.addhttp
(* let add = Add.addcgi *)

let _ =
  try
    Printf.printf "2 + 3 = %d\n" (add 2 3)
  with XmlRPCClient.Request_fault f ->
    Printf.printf "Fault: %s\n" f.XmlRPCTypes.desc
