
let print_struct s =
  let word = XmlRPCTypes.find_elem s "word"
  and sug = XmlRPCTypes.find_elem s "suggestions" in
    Printf.printf "Misspelled word: %s\nSuggestions:"
      (XmlRPCTypes.ml_of_string word);
    let sug' = XmlRPCTypes.ml_of_array sug in
      Array.iter (function s -> print_char ' '; print_string (XmlRPCTypes.ml_of_string s)) sug';
      print_newline();;
  
try
  print_endline "Please enter some words to spellcheck, or ^D to quit.";
  while true do
    let line = read_line () in
      try
	let res = Speller.spellCheck line in
	  Array.iter print_struct res;
	  print_endline "Please enter some more words, or ^D to quit.";
      with
	  XmlRPCTypes.Bad_type -> (* See the comments in speller.idl *)
	    print_endline "No misspelt words! Go you.";
	    print_endline "Please enter some more words, or ^D to quit."
  done
with
  | End_of_file -> print_endline "Goodbye."
  | XmlRPCClient.Request_fault s ->
      Printf.printf "Error: %s\n" s.XmlRPCTypes.desc
