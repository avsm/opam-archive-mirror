Ppx_driver.standalone ()
