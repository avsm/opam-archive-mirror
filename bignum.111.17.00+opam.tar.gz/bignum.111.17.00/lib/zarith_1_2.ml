(* This module is pure silliness, but reconciles the opam zarith package naming
   conventions with the internal Jane Street zarith installation, without me having to
   edit any source files directly. *)
module Q = Q
module Z = Z
