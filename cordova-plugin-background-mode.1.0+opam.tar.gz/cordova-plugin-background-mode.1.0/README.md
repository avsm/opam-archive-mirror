# ocaml-cordova-plugin-background-mode
Binding OCaml to cordova-plugin-background-mode using gen_js_api.
