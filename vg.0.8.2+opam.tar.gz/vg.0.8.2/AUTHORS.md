* [Daniel C. Bünzli](http://erratique.ch), main developer.
* Arthur Wendling, Vgr_cairo backend.
