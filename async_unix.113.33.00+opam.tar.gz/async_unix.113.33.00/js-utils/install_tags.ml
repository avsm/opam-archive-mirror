let package_name = "async_unix"

let sections =
  [ ("lib",
    [ ("built_lib_async_unix", None)
    ],
    [ ("META", None)
    ])
  ]
