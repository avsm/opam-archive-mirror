#ifndef _SYSCALL_H
#define _SYSCALL_H

#include <asm/unistd.h>

int syscall(int number, ...);

#endif
