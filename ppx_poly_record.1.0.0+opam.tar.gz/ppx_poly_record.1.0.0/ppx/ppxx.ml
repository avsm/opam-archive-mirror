open Parsetree
open Asttypes
open Ast_mapper
open Longident
open Ast_helper

(* (@@) is too strong *)
external ( & ) : ('a -> 'b) -> 'a -> 'b = "%apply"

let (!!%) = Format.eprintf

let ($.) l s = Ldot (l, s)
let (!$) s = Lident s
let (!..) xs = 
  let rec f = function
    | [] -> assert false
    | [x] -> Lident x
    | x::xs -> Ldot (f xs, x)
  in
  f (List.rev xs)

let at ?loc txt = 
  let loc = match loc with 
      | None -> !Ast_helper.default_loc
      | Some loc -> loc
  in
  { txt; loc }

let partition p = List.partition (fun ({txt}, _payload) -> p txt)

let with_default_loc loc f = 
  let back = !Ast_helper.default_loc in
  Ast_helper.default_loc := loc;
  let res = f () in
  Ast_helper.default_loc := back;
  res

module Typ = struct
  include Typ
  let new_var =
    let cntr = ref 0 in
    fun () -> 
      incr cntr;
      var & "tvar_" ^ string_of_int !cntr
end

module Exp = struct
  include Exp
  let string ?loc ?attrs s = constant ?loc ?attrs & Const_string (s, None)
  let int ?loc ?attrs i = constant ?loc ?attrs & Const_int i
  let bool ?loc ?attrs b = construct ?loc ?attrs (at ?loc !$(if b then "true" else "false")) None
  let var ?loc ?attrs s = ident ?loc ?attrs & at ?loc !$s
  let lident ?loc ?attrs lid = ident ?loc ?attrs & at ?loc lid
  let option ?loc ?attrs = function
    | None -> construct ?loc ?attrs (at ?loc !$"None") None
    | Some e -> construct ?loc ?attrs (at ?loc !$"Some") (Some e)
  let parse s =
    try
      Parser.parse_expression Lexer.token (Lexing.from_string s)
    with
    | _e -> failwith (Printf.sprintf "parse fail: %s" s)

  let object_ ?loc ?attrs flds = object_ ?loc ?attrs (Cstr.mk (Pat.any ()) flds)
  let seqs = function
    | [] -> assert false
    | x::xs -> List.fold_right (fun x st -> sequence x st) xs x
  let mk_ignore e =
    apply (lident !..["Pervasives"; "ignore"]) ["", e]
  let assert_false () = assert_ & bool false
end

module Pat = struct
  include Pat
  let var ?loc ?attrs s = var ?loc ?attrs (at ?loc s)
end

module ExpPat = struct
  let var ?loc ?attrs s = (Exp.var ?loc ?attrs s, Pat.var ?loc ?attrs s)
end

module Cf = struct
  include Cf

  let method_concrete ?loc ?attrs name ?(priv=false) ?(override=false) e = 
    Cf.method_ ?loc ?attrs name (if priv then Private else Public)
      (Cfk_concrete ((if override then Override else Fresh), e))
  let method_virtual ?loc ?attrs name ?(priv=false) cty = 
    Cf.method_ ?loc ?attrs name (if priv then Private else Public)
      (Cfk_virtual cty)
end

module Cstr = struct
  let mk ?(self= Pat.any ()) fields = Cstr.mk self fields
end

let test mapper name = 
  try
    if Filename.check_suffix name ".ml" then (* .mlt ? *)
      let str = Pparse.parse_implementation ~tool_name:"ppx" Format.err_formatter name in
      let str = mapper.structure mapper str in
      Pprintast.structure Format.std_formatter str
    else if Filename.check_suffix name ".mli" then 
      let sg = Pparse.parse_interface ~tool_name:"ppx" Format.err_formatter name in
      let sg = mapper.signature mapper sg in
      Pprintast.signature Format.std_formatter sg
    else assert false;
    Format.fprintf Format.std_formatter "@."
  with
  | Syntaxerr.Error e ->
      !!% "%a@." Syntaxerr.report_error e

let run name mapper = 
  let debug = ref false in
  let rev_files = ref [] in 
  Arg.parse 
    [ "-debug", Arg.Set debug, "debug mode which can take .ml/.mli then print the result"
    ]
    (fun s -> rev_files := s :: !rev_files) (* will be handled by [Ast_mapper.apply] *)
    name;
  match !debug, List.rev !rev_files with
  | true, files ->
      List.iter (test mapper) files
  | false, [infile; outfile] ->
      Ast_mapper.apply ~source:infile ~target:outfile mapper
  | _ -> 
      failwith @@ name ^ " infile outfile"
