let _ =
  match a with
  | b ->
    cccccc [
      d [
        e
      ]
    ]
  | b' ->
    (ccccc' [
        d' [
          e'
        ]
      ])
