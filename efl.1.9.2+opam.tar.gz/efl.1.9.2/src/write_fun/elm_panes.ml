open Common

let funs = [
  prop "fixed" bool;
  prop "content_left_size" double;
  prop "content_right_size" double;
  prop "horizontal" bool;
]

