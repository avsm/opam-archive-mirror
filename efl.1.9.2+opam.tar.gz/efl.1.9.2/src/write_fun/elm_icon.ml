open Common

let funs = [
  simple "standard_set" [evas_object; safe_string] bool;
  prop "order_lookup" elm_icon_lookup_order
]

