open Common

let funs = [
  prop "horizontal" bool;
]

