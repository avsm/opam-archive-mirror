open Common

let funs = [
  prop "autorepeat" bool;
  prop "autorepeat_initial_timeout" double;
  prop "autorepeat_gap_timeout" double;
]

