Changelog
=========

0.1
---
* Initial alpha-release to test the concept
