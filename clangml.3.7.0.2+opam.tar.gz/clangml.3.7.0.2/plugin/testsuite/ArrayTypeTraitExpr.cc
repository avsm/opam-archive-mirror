int i = __array_rank (int[2]);
int j = __array_extent (int[2], 0);
