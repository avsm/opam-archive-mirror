void f() {

  int a = 1;

  if (a < ~0U-1) {
    a = 1;
  }
}
