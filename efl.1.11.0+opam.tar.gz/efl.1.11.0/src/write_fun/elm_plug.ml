open Common

let funs = [
  simple "connect" [evas_object; safe_string; int; bool] bool;
]

