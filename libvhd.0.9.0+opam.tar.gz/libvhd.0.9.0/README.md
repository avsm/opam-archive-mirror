OCaml bindings for libvhd
=========================

libvhd allows the construction, manipulation and querying of .vhd format
disk images. These bindings allow OCaml programs to operate on these
images, reading/writing data, creating snapshots, coalescing data etc.

