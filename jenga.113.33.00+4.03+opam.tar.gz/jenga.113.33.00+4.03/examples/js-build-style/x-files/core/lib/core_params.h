#ifndef PARAMS_H
#define PARAMS_H

/* I/O transaction size after which to release the OCaml-lock */
#define THREAD_IO_CUTOFF 65536

#endif /* PARAMS_H */
