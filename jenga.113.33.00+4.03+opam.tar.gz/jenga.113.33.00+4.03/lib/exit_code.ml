type t = int
let build_done      = 0
let build_failed    = 1
let incomplete      = 2
let cycle_abort     = 3
let cant_start      = 4
let server_locked   = 5
let persist_bad     = 6
