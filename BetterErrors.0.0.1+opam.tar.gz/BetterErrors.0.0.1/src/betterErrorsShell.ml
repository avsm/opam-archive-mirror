let () = BetterErrorsMain.parseFromStdin ~customErrorParsers:[]
