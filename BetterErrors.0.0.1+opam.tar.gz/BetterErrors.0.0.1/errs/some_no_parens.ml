let a = Some 5 + 6

(* err bc no parens *)

let a = Some (5 + 6)
