if 123 then "asd" else "a"

(* err bc ocaml if takes boolean, no casting *)

(* if true then "asd" else "a" *)
