let () = "asd" + "asd"

(* err bc type don't match, doesn't work adding () at the end *)

let () = "asd" ^ "asd"
