let a = print_endline 5

err bc func with 0 arg need to be appended () during declaration

let a () = print_endline 5
