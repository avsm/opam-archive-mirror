#load "str.cma";;

(* err bc interpreter uses load but compiler needs linking? *)

(* need to remove loads. then try:  *)
(* ocamlc str.cma yourFile.ml *)
(* ocamlc str.cma yourFile.ml *)
