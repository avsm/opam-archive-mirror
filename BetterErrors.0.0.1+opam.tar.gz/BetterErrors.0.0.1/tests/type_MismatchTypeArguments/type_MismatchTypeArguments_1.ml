type bread =
  | Coconut of string

let morning = Coconut
