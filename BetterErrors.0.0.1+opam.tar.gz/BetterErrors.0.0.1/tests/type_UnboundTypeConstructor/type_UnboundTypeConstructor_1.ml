type asd =
  | Hello of whereAmI
  | Goodbye
