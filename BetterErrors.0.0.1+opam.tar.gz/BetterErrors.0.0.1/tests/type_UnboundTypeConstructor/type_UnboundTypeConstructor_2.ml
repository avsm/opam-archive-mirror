type whereAm = {
  location: string
}
type greeting =
  | Hello of whereAmI
  | Goodbye
