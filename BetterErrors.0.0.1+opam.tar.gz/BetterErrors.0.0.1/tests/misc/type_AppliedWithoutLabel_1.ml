(* let () = print_endline "asd" "dsa" *)
let asd ?a ?b = "asd"

let () = print_endline (asd ())
