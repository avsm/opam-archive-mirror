type a = {b: int}

type a = {b: int}
