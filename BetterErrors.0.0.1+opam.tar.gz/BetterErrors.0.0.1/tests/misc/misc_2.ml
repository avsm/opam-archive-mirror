let dontCurry a b = print_endline "hi"

let () = dontCurry 1; print_endline "bye"
