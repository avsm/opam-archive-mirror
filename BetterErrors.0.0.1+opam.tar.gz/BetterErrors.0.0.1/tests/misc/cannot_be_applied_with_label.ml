let eat ~fruitName = print_endline "hi"

let () = eat ~fruitname:"apple"
