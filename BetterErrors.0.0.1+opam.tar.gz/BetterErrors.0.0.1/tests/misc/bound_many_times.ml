let cake = ("cream", "ketchup")

let () =
  match cake with
  | (ingredient1, ingredient1) -> print_endline "I'm good at cooking"
  | _ -> print_endline "I'm good at cooking"
