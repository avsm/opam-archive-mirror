type asd = {
  a: int;
  b: string;
}

let bla = {
  a = 5;
}
