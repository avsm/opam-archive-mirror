let poshanassy = 1
let poshanessy = 2
let poshanissy = 3
let poshanyssy = 4

let () = print_int poshanossy
