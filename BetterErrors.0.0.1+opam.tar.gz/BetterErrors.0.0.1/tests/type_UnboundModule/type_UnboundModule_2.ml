module HelloWorld = struct
  module ThisMorningIThink = struct
    module IWillEatSomeDelicious = struct
      module Pancake = struct
      end
    end
  end
end

open HelloWorld.ThisMorningIThink.IWillEatSomeDelicious.Pancaek
