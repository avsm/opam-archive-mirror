let longFunction a b c d e f g = a ^ b ^ c ^ d ^ e ^ f ^ g

let evenLongerCall = longFunction "a" "a" "a" "a" "a" "a" "a" "a"
