type asd = {
  a: int;
  hello: int;
}

let bla = {
  a = 5;
  helo = 6;
}
