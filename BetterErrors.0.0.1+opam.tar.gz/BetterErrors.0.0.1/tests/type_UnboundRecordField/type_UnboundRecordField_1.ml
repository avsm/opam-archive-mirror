type asd = {
  a: int;
}

let bla = {
  a = 5;
  b = 6;
}
