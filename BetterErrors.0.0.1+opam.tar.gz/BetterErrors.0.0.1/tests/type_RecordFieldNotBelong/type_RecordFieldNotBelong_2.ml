type point = {
  x: int;
  y: int;
  dog: string;
}

let myPoint: point = {
  xs = 0;
  ys = 10;
  dogs = "hi";
};
