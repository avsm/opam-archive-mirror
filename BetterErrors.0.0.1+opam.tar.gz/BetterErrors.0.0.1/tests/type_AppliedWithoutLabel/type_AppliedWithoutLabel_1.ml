let f ~a ~b c = ()

let () =
  f 1 2
