let () =
  \hahaha look at me
  roaming free
  this is a haiku
  kidding it's not
