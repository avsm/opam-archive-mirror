type asd = {
  bla: string list;
}

let takeMeAway = {
  bla = [|1|];
}
