if !true then "asd" else "a"
