let iTakeAFunction f a = f "yes" a

let () = ignore (iTakeAFunction "rebel")
