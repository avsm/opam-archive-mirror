if 123 then "asd" else "a"
