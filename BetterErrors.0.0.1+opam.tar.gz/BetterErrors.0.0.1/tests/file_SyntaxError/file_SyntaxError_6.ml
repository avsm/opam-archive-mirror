type fruits =
| apple of string
