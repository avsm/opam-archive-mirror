let a = (print_char 'a)
