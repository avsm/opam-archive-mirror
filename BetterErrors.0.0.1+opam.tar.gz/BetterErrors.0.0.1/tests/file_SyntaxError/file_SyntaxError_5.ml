let () = if true then
  print_endline "gosh";
  print_endline "so much functional purity"
else
  print_endline "that I cant even"
