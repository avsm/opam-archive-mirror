type file = {
  path: string;
  messages: message list;
}
type output = file list;
