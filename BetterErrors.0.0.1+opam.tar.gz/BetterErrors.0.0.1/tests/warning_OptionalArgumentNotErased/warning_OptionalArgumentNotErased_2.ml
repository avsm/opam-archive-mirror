let eat aNumber ?(withFork=true) =
  "Hello, world!"

let () = print_endline (eat 1 ~withFork:false)
