let thisVariableIsTotallyFine = 5
