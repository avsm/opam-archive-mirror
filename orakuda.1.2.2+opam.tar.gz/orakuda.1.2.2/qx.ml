let command s = Spotlib.Spot.Unix.Command.(shell s |> get_stdout)
