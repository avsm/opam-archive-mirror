(* 
   ocamlc -annot -I +camlp4 dynlink.cma camlp4lib.cma -pp camlp4of.opt pa_hash.ml  
   ocaml dynlink.cma camlp4o.cma pa_hash.cmo
*)
module Id = struct
  let name = "pa_hash"
  let version = "1.0"
end

open Camlp4

module Make (Syntax : Sig.Camlp4Syntax) = struct
  (* open Sig *)
  include Syntax

  (* We need Orakuda.Std.Internal_hashtbl to avoid name collisions when Hashtbl module is redefined *)
  let bigarray_hashtbl_set _loc var newval =
    match var with
    | <:expr< Bigarray.Array1.get $arr$ $c1$ >> ->
        Some <:expr< Bigarray.Array1.set $arr$ $c1$ $newval$ >>
    | <:expr< Bigarray.Array2.get $arr$ $c1$ $c2$ >> ->
        Some <:expr< Bigarray.Array2.set $arr$ $c1$ $c2$ $newval$ >>
    | <:expr< Bigarray.Array3.get $arr$ $c1$ $c2$ $c3$ >> ->
        Some <:expr< Bigarray.Array3.set $arr$ $c1$ $c2$ $c3$ $newval$ >>
    | <:expr< Bigarray.Genarray.get $arr$ [| $coords$ |] >> ->
        Some <:expr< Bigarray.Genarray.set $arr$ [| $coords$ |] $newval$ >>
    | <:expr< Orakuda.Std.Internal_hashtbl.find $e1$ $e2$ >> ->
        Some <:expr< Orakuda.Std.Internal_hashtbl.replace $e1$ $e2$ $newval$ >>
    | <:expr< Orakuda.Std.Internal_hashtbl.find_all $e1$ $e2$ >> ->
        Some <:expr< Orakuda.Std.Internal_hashtbl.add $e1$ $e2$ $newval$ >>
    | _ -> None
  ;;

  DELETE_RULE Gram expr: SELF; "<-"; expr LEVEL "top" END;

  EXTEND Gram  
    GLOBAL: expr
  ;

  expr: LEVEL "simple"
    [ 
      [ e1 = SELF; "$"; "{"; e2 = SELF; "}" 
	-> <:expr<Orakuda.Std.Internal_hashtbl.find $e1$ $e2$>> 
      | e1 = SELF; "$+"; "{"; e2 = SELF; "}" 
	-> <:expr<Orakuda.Std.Internal_hashtbl.find_all $e1$ $e2$>> 
      | e1 = SELF; "$?"; "{"; e2 = SELF; "}"
	-> <:expr<Orakuda.Std.Internal_hashtbl.mem $e1$ $e2$>> 
      ]
    ];
  expr: LEVEL ":="
    [
      [ e1 = SELF; "<-"; e2 = expr (* LEVEL "top" *) ->
        begin match bigarray_hashtbl_set _loc e1 e2 with
        | Some e -> e
        | None -> <:expr< $e1$ <- $e2$ >> 
	end
      ]
    ];
  END  
end

let module M = Register.OCamlSyntaxExtension(Id)(Make) in ()
