(*
  Pre-compiled printf format $%"....." and its use by Cformat

  Cformat.sprintf $%"..." is actually equivalent with $"...".
*)

open Orakuda.Std

let _ = 
  assert (Cformat.sprintf <:fmt<hello%dworld>> 2 = "hello2world");

  let x = 1 and y = 2 in 
  assert (Cformat.sprintf <:fmt<%d %${x}d %d %${y}d %d>> 3 4 5 = "3 1 4 2 5");

  assert (Cformat.sprintf <:fmt<%1.F>> 123.456 = "123.");
;;

let _ = <:fmt<%*.*d>>

(* special char '"' escaping *)

let _ = 
  prerr_endline "special char escaping test";
  assert (Cformat.sprintf <:fmt<hello\"%d\"world>> 2 = "hello\"2\"world");
  assert (Cformat.sprintf <:fmt<hello\"%d\"world>> 2 = "hello\"2\"world");
  assert (Cformat.sprintf <:fmt<h"ello\"%d\"world>> 2 = "h\"ello\"2\"world")
