(*
  Regexp case match

  string |! $/regexp/ as x -> ... | $/regexp/ as x -> ... | _ -> ...

*)

open Spotlib.Spot
open Orakuda.Std

let r = <:m<hello>> -> "world" | <:m<bye>> -> "universe" | _ -> "default"
;;

let _ = 
  assert (r "hello world" = "world");
  assert (r "bye universe" = "universe");
  assert (r "42" = "default")
;;

(* CR jfuruse: hmmm. Precedence seems glitchy *)

let _ = 
  let res = 
    "world bye universe" 
    |! <:m<hello>> -> "world" 
    | <:m<bye>> as x -> x#_left ^ x#_right
    | _ -> "default"
  in
  assert ("world  universe" = res)
;;

let _ = 
  let res = 
    "world bye universe" 
    |! <:m<([^ ]+) ([^ ]+) ([^ ]+)>> as x -> x#_1
    |! <:m<([^ ]+) ([^ ]+) ([^ ]+)>> as x -> (match x#_1opt with Some v -> v | None -> "")
    | <:m<(.*)>> as x -> x#_1
    | _ -> "default"
  in
  assert ("world" = res)
;;

let _ =
  "hello"
  |! <:m<^S_|\/S_>> -> true 
  | _ -> false
;;

