oasis2opam
==========

Tool to convert [OASIS](https://github.com/ocaml/oasis) metadata to
[OPAM](https://github.com/OCamlPro/opam) package descriptions.


Dependencies
------------

This tool uses the [oasis](https://github.com/ocaml/oasis) library.
It also relies on the presence of external programs: you need `wget`
or `curl`, and `tar`.
