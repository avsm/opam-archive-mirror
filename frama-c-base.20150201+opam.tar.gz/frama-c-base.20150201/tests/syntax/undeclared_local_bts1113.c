void funk(int rounds)
{
  int k[2*rounds];
  int i;
  int kk[2*rounds];

  for (i = 0; i < 2*rounds; i++)
    {
      k[i] = i;
    }
}

int main ()
{

  funk(17);
  return 0;
}
