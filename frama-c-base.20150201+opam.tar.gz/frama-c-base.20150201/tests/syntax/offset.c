/* run.config
OPT: -cpp-extra-args="-Ishare/libc" -print
*/

#include "__fc_define_off_t.h"

off_t x = 0;

off64_t y = 0;
