/* run.config
   OPT: -load-script tests/syntax/typedef_multi.ml tests/syntax/typedef_multi_2.c
*/

#include "tests/syntax/typedef_multi.h"

void f () {  while(x<y) x++; }
