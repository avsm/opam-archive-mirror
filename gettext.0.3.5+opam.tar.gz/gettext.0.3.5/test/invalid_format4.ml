open TestGettext;;
open Printf;;

let () = 
  eprintf (f_ "%b") 2
;;
