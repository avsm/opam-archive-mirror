(* OASIS_START *)
(* DO NOT EDIT (digest: 1f7364ec362701bd28a62729f5e9882e) *)
This is the README file for the csv distribution.

A pure OCaml library to read and write CSV files.

This is a pure OCaml library to read and write CSV files, including all
extensions used by Excel — e.g. quotes, newlines, 8 bit characters in
fields, \"0 etc.  The library comes with a handy command line tool called
csvtool for handling CSV files from shell scripts.

See the files INSTALL.txt for building and installation instructions. 

Home page: https://forge.ocamlcore.org/projects/csv/


(* OASIS_STOP *)
