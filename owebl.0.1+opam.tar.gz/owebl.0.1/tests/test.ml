Templatetest.test;
Requesttest.test;

Printf.printf "%d/%d tests passed.\n" !Assert.passed !Assert.total
