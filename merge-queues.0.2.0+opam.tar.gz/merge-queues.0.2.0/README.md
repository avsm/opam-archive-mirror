## MQueue

The package implements "mergeable" queues, ie. persistent
queues with a fast merge operation.
