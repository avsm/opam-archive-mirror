0.2.0:
* Port to Irmin 0.9 API changes

0.1.0:
* Initial release