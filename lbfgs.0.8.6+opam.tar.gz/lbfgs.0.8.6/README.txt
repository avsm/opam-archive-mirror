(* OASIS_START *)
(* DO NOT EDIT (digest: a6f1d66ecce27970f406d2d4c3e42ea1) *)

lbfgs - Minimization of multidimensional functions on bounded or unbounded domains.
===================================================================================

This is a binding to L-BFGS-B, a library for Large-scale Bound-constrained
Optimization.

See the file [INSTALL.txt](INSTALL.txt) for building and installation
instructions.

[Home page](https://forge.ocamlcore.org/projects/lbfgs/)

Copyright and license
---------------------

lbfgs is distributed under the terms of the GNU Lesser General Public License
version 3.0 with OCaml linking exception.

(* OASIS_STOP *)
