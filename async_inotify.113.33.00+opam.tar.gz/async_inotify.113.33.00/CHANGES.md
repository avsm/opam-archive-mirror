## 113.00.00

- Added `modify_event_selector` optional parameter to `Async_inotify.create`.

## 111.17.00

- Upgraded library to use inotify 2.0

