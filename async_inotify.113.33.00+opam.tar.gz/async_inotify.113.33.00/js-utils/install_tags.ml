let package_name = "async_inotify"

let sections =
  [ ("lib",
    [ ("built_lib_async_inotify", None)
    ],
    [ ("META", None)
    ])
  ]
