type t = {x:int;w:int} with fields
