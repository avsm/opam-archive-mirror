let () = print_endline (input_line (open_in "VERSION"))
