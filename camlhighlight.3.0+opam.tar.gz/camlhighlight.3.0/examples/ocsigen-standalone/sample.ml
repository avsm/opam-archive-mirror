type foo_t =
	| One
	| Two
	| Three
