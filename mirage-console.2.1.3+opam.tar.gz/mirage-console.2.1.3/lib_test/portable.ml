module C = Console_unix

let _ =
  Printf.printf "The console code successfully linked.\n"
