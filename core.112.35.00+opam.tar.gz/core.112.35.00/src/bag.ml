include Core_kernel.Bag
