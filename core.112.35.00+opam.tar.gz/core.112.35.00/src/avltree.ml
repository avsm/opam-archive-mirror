include Core_kernel.Avltree
