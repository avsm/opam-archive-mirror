Portia
======

A literate programming preprocessor written in literate programming style.
You need funnelweb (or portia) to compile it.


    @O@<literate_quine.sh@>==@{@-
    #!/bin/sh
    cat README.md
    @}
