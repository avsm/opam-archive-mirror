(* OASIS_START *)
(* DO NOT EDIT (digest: cf019cfe8cd8e712f7f44ea8f6c0048d) *)
This is the README file for the odepack distribution.

Binding to ODEPACK.

This is a collection of solvers for the initial value problem for ordinary
differential equation systems.

See the files INSTALL.txt for building and installation instructions. 

Home page: http://forge.ocamlcore.org/projects/odepack/


(* OASIS_STOP *)
