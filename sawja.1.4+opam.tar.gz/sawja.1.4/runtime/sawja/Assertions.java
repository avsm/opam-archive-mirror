package sawja;

public class Assertions {

    static public void assume(boolean b) {}

    static public void check(boolean b) {}

    static public void invariant(boolean b) {}

}