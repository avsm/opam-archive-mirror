v0.3.0 2016-11-25
-----------------

Split code from the rejoin tool into its own library.
