  * `check2.{ml,native}` - a "minimal" checker; should give same
    result as `check`

  * `debug.{ml,native}` - similar to `check2`, but prints debug
    information in sexp format
    
