let git_rev = "df2c71779c1b6540072608cb6805f7ec8005c11f"
let git_dirty = false
