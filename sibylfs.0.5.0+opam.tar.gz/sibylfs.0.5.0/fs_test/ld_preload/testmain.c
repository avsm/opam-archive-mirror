#include <stdio.h>

int main (void)
{
  rename("/tmp/a.txt","/tmp/b.txt");
  return 0;
}
