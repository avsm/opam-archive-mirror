(****************************************************************************)
(*  Copyright (c) 2013, 2014, 2015, Tom Ridge, David Sheets, Thomas Tuerk,  *)
(*  Andrea Giugliano (as part of the SibylFS project)                       *)
(*                                                                          *)
(*  Permission to use, copy, modify, and/or distribute this software for    *)
(*  any purpose with or without fee is hereby granted, provided that the    *)
(*  above copyright notice and this permission notice appear in all         *)
(*  copies.                                                                 *)
(*                                                                          *)
(*  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL           *)
(*  WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED           *)
(*  WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE        *)
(*  AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL    *)
(*  DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR   *)
(*  PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER          *)
(*  TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR        *)
(*  PERFORMANCE OF THIS SOFTWARE.                                           *)
(*                                                                          *)
(*  Meta:                                                                   *)
(*    - Headers maintained using headache.                                  *)
(*    - License source: http://opensource.org/licenses/ISC                  *)
(****************************************************************************)

(* Additional defns required by Lem-exported ocaml defns, which we
   don't want in Lem for some reason *)

type 'a finset = Finset of 'a list
let list_from_finset (Finset l) = l
let finset_from_list l = (Finset l)

open Sexplib.Std

module Int32 = struct
  include Int32
  let t_of_sexp = int32_of_sexp
  let sexp_of_t = sexp_of_int32
end

module Int64 = struct
  include Int64
  let t_of_sexp = int64_of_sexp
  let sexp_of_t = sexp_of_int64
end

(* FIXME move float_t here *)
(*
let float_t_of_sexp = fun _ -> failwith "lem_support: FIXME float_t"
let sexp_of_float_t = fun _ -> failwith "lem_support: FIXME float_t"
*)

(*
module MyDynArray2 = struct
  include Dynarray.MyDynArray2

  let t_of_sexp s = Sexplib.Conv.(pair_of_sexp int_of_sexp bigstring_of_sexp s)
  let sexp_of_t t = Sexplib.Conv.(sexp_of_pair sexp_of_int sexp_of_bigstring t)
end
*)
