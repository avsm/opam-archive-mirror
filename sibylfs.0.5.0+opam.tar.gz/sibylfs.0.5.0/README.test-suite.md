The test suite has been moved to https://bitbucket.org/tomridge/fs_test_suite

Clone with: 

    git clone https://tomridge@bitbucket.org/tomridge/fs_test_suite.git
    
Link (if required) with:

    ln -s fs_test_suite/test-suite .

The old STATUS.md file is in old/STATUS.md
