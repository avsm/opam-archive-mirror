call("println", "Println Called");
cmd = "ec" ++ "ho";
call(cmd, "Echo Called");
retval = echo("Value 100%");
println(retval);
