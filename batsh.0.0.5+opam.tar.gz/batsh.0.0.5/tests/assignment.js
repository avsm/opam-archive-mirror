a = "Value: " ++ 1+(4+6)*3;
println(a);
b = 3 + 4;
println(b);
c = a;
println(c);
d = b ++ c;
println(d);
