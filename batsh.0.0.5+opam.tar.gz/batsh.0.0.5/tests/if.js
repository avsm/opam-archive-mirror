if (2 < 10) {
  println("Yes");
}

if (true) {
  if (false){
    v=(4 + 1);
  } else {
    v = 2;
  }
} else {

}
println(v);

if (2 > 1)
  println("True");

if (1 === 12) {
  println("No");
}

if ("a" == "b") {
  println("No");
} else {
  println("a is not b");
}

num = 43;
if ("43" == num) {
  println("43 == num");
}
if ("43" === num) {
  println("43 === num");
}
