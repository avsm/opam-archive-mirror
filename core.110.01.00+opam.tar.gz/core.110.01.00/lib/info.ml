include Core_kernel.Info
