let () =
  PluginloaderLib.registered_plugins :=
  "plugin1" :: !PluginloaderLib.registered_plugins
