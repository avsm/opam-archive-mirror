module Farray            = Farray
module Flat_map          = Flat_map
module Tagged            = Tagged
module Traverse_map      = Traverse_map
module Type_struct       = Type_struct
module Typestructable    = Typestructable
module Tagged_generic    = Tagged_generic
include Typerep_lib.Std
