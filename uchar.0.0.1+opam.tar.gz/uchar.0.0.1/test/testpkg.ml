
let () =
  Format.printf "%a\n" Uchar.dump (Uchar.of_int 0x1F42B)