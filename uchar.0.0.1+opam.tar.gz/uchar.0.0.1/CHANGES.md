v0.0.1 2015-12-01 Cambridge (UK)
--------------------------------

First release.
