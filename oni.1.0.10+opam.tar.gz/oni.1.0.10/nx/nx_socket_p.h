/*---------------------------------------------------------------------------*
  $Change$
  Copyright (c) 2003-2010, James H. Woodyatt
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  
    Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
    
    Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in
    the documentation and/or other materials provided with the
    distribution
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
  COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
  STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
  OF THE POSSIBILITY OF SUCH DAMAGE. 
 *---------------------------------------------------------------------------*/

#ifndef _NX_SOCKET_P_H
#define _NX_SOCKET_P_H

#include "nx_common_p.h"

#include <stddef.h>
#include <sys/types.h>
#include <sys/socket.h>

#define Nx_socket_sockaddrx_struct(suffix) \
struct nx_socket_sockaddrx_##suffix##_s { \
    size_t                      sx_socklen; \
    struct sockaddr_##suffix    sx_sockaddr_##suffix; \
}

#define Nx_socket_sockaddrx_t(suffix)   Nx_socket_sockaddrx_##suffix##_t

#define Nx_socket_sockaddrx_typedef(suffix) \
typedef struct nx_socket_sockaddrx_##suffix##_s Nx_socket_sockaddrx_t(suffix)

#define Nx_socket_sockaddrx_val(suffix, v) \
    ((Nx_socket_sockaddrx_t(suffix)*) Data_custom_val(v))

Nx_socket_sockaddrx_struct(storage);
Nx_socket_sockaddrx_typedef(storage);

struct nx_socket_sockaddrx_unit_s {
    size_t              sx_socklen;
    struct sockaddr     sx_sockaddr;
};

typedef struct nx_socket_sockaddrx_unit_s Nx_socket_sockaddrx_unit_t;

#define Nx_socket_sockaddrx_unit_val(v) \
    ((Nx_socket_sockaddrx_unit_t*) Data_custom_val(v))

typedef value (*Nx_socket_sockaddrx_cons_f)
   (const struct sockaddr* saPtr, size_t saLen);

struct nx_socket_domain_s {
    int                         d_domain;   /* PF_INET, PF_LOCAL, ... */
    int                         d_family;   /* AF_INET, AF_LOCAL, ... */
    Nx_socket_sockaddrx_cons_f  d_consaddr; /* sockaddr alloc function */
    size_t                      d_socklen;  /* sizeof(sockaddr_xxx) */
};

typedef struct nx_socket_domain_s Nx_socket_domain_t;

#define Nx_socket_domain_val(v) ((Nx_socket_domain_t*) Data_custom_val(v))
extern value nx_socket_domain_alloc(const Nx_socket_domain_t* ptr);

struct nx_socket_s {
    int         s_fd;
    int         s_socktype;
    int         s_protocol;
    Nx_socket_domain_t  s_domain;
};

typedef struct nx_socket_s Nx_socket_t;

#define Nx_socket_val(v)    ((Nx_socket_t*) Data_custom_val(v))
extern value nx_socket_alloc
   (int fd, int socktype, int protocol, const Nx_socket_domain_t* domainPtr);

extern int nx_socket_msg_flags_to_int(value flagsVal);
extern value nx_socket_msg_flags_of_int(int flags);

struct nx_socket_option_context_s {
    int xopt_fd;
    int xopt_level;
    int xopt_name;
};

typedef struct nx_socket_option_context_s Nx_socket_option_context_t;

typedef value (*Nx_socket_getsockopt_f)
   (const Nx_socket_option_context_t* contextPtr);
typedef void (*Nx_socket_setsockopt_f)
   (const Nx_socket_option_context_t* contextPtr, value x);

struct nx_socket_option_s {
    int                     opt_level;
    int                     opt_name;
    Nx_socket_getsockopt_f  opt_get;
    Nx_socket_setsockopt_f  opt_set;
    const char*             opt_name_str;
};

typedef struct nx_socket_option_s Nx_socket_option_t;

struct nx_socket_sockopt_lift_s {
    value                       ol_val;
    const Nx_socket_option_t    ol_option;
};

typedef struct nx_socket_sockopt_lift_s Nx_socket_sockopt_lift_t;

#define Nx_socket_option_val(v) \
    ((const Nx_socket_option_t**) Data_custom_val(v))
extern value nx_socket_option_alloc(const Nx_socket_option_t* ptr);

extern void nx_socket_getsockopt_guard
   (const Nx_socket_option_context_t* contextPtr, void* optval,
    socklen_t* optlen);

extern void nx_socket_setsockopt_guard
   (const Nx_socket_option_context_t* contextPtr, const void* optval,
    socklen_t optlen);

extern value nx_socket_getsockopt_bool
   (const Nx_socket_option_context_t* contextPtr);

extern void nx_socket_setsockopt_bool
   (const Nx_socket_option_context_t* contextPtr, value x);

extern value nx_socket_getsockopt_int
   (const Nx_socket_option_context_t* contextPtr);

extern void nx_socket_setsockopt_int
   (const Nx_socket_option_context_t* contextPtr, value x);

extern value nx_socket_getsockopt_int_option
   (const Nx_socket_option_context_t* contextPtr);

extern void nx_socket_setsockopt_int_option
   (const Nx_socket_option_context_t* contextPtr, value x);

extern value nx_socket_getsockopt_float
   (const Nx_socket_option_context_t* contextPtr);

extern void nx_socket_setsockopt_float
   (const Nx_socket_option_context_t* contextPtr, value x);

#endif /* defined(_NX_SOCKET_P_H) */

/*--- $File$ ---*/
