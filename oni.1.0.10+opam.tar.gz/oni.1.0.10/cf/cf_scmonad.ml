(*---------------------------------------------------------------------------*
  $Change$
  Copyright (c) 2002-2010, James H. Woodyatt
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  
    Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
    
    Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in
    the documentation and/or other materials provided with the
    distribution
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
  COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
  STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
  OF THE POSSIBILITY OF SUCH DAMAGE. 
 *---------------------------------------------------------------------------*)

type ('s, 'x, 'a) t = ('s -> 'x, 'a) Cf_cmonad.t
    (* ('a -> 's -> 'x) -> 's -> 'x *)
    (* 's -> (('s * 'a) -> 'x) -> 'x *)

module Op = struct let ( >>= ) m c s = m (fun a -> c a s) end

let nil f s = f () s
let return a f s = f a s
let init x _ _ = x
let cont c f x = c (f () x)
let load f s = f s s
let store s f _ = f () s
let modify c f s = f () (c s)
let field r f s = f (r s) s
let down m s f = m (fun () -> f) s
let liftC = Op.( >>= )
let liftS m c s = let a, s = m s in c a s
let eval m s x = m (fun () _ -> x) s
let bridge x b m _ s = b (m (fun () _ -> x) s)

(*--- $File$ ---*)
