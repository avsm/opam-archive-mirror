module Abstract = struct
  type 'a t = 'a
  let fn t = t
  let app t = t
end
