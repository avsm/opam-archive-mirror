This is an OCaml implementation of the DNSCurve protocol.
