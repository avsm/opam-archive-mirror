let bye = "Bye."
let bye = bye

