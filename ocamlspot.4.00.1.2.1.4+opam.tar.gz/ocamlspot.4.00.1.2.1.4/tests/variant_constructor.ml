type t = (* constr E => *) E (* <= constr E *)

let _ = E (* ? constr E *)
