(* OASIS_START *)
(* DO NOT EDIT (digest: 660d21562d43c07edf4eccbf886fa9c4) *)
This is the README file for the integration1d distribution.

Integration of functions of one variable.

This is a binding to Quadpack.

See the files INSTALL.txt for building and installation instructions. 

Home page: http://forge.ocamlcore.org/projects/integration1d/


(* OASIS_STOP *)
