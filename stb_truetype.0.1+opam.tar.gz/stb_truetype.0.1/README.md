Stb\_truetype is an OCaml binding to stb\_truetype from Sean Barrett, [Nothings](http://nothings.org/):

  stb\_truetype.h: public domain C truetype rasterization library 

The OCaml binding is released under CC-0 license.  It has no dependency beside
working OCaml and C compilers (stb\_truetype is self-contained).

```shell
$ make
$ make install
```
