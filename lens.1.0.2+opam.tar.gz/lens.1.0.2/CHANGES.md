1.0.0 (30-Mar-2015):
* Initial public release.
