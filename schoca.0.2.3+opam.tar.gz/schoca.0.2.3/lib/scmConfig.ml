let initial_global_environment_size = 1024
let initial_local_environment_size = 32
let initial_symbol_table_size = 256
let initial_macro_table_size = 32

