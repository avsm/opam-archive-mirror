let package_name = "bin_prot"

let sections =
  [ ("lib",
    [ ("built_lib_bin_prot", None)
    ],
    [ ("META", None)
    ])
  ]
