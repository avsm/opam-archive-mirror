(*---------------------------------------------------------------------------
   Copyright (c) 2014 Daniel C. Bünzli. All rights reserved.
   Distributed under the BSD3 license, see license at the end of the file.
   uucp release 1.0.0
  ---------------------------------------------------------------------------*)

(* WARNING do not edit. This file was automatically generated. *)

open Uucp_tmap
let nfkc_fold_map_map : [ `Self | `Uchars of int list ] t = { default =
`Self; l0 = [|[|nil;nil;nil;nil;[|`Self;(`Uchars [97;]);(`Uchars [98;]);
(`Uchars [99;]);(`Uchars [100;]);(`Uchars [101;]);(`Uchars [102;]);
(`Uchars [103;]);(`Uchars [104;]);(`Uchars [105;]);(`Uchars [106;]);
(`Uchars [107;]);(`Uchars [108;]);(`Uchars [109;]);(`Uchars [110;]);
(`Uchars [111;]);|];[|(`Uchars [112;]);(`Uchars [113;]);(`Uchars [114;]);
(`Uchars [115;]);(`Uchars [116;]);(`Uchars [117;]);(`Uchars [118;]);
(`Uchars [119;]);(`Uchars [120;]);(`Uchars [121;]);(`Uchars [122;]);`Self;
`Self;`Self;`Self;`Self;|];nil;nil;nil;nil;[|(`Uchars [32;]);`Self;`Self;
`Self;`Self;`Self;`Self;`Self;(`Uchars [32;776;]);`Self;(`Uchars [97;]);
`Self;`Self;(`Uchars []);`Self;(`Uchars [32;772;]);|];[|`Self;`Self;
(`Uchars [50;]);(`Uchars [51;]);(`Uchars [32;769;]);(`Uchars [956;]);`Self;
`Self;(`Uchars [32;807;]);(`Uchars [49;]);(`Uchars [111;]);`Self;
(`Uchars [49;8260;52;]);(`Uchars [49;8260;50;]);(`Uchars [51;8260;52;]);
`Self;|];[|(`Uchars [224;]);(`Uchars [225;]);(`Uchars [226;]);
(`Uchars [227;]);(`Uchars [228;]);(`Uchars [229;]);(`Uchars [230;]);
(`Uchars [231;]);(`Uchars [232;]);(`Uchars [233;]);(`Uchars [234;]);
(`Uchars [235;]);(`Uchars [236;]);(`Uchars [237;]);(`Uchars [238;]);
(`Uchars [239;]);|];[|(`Uchars [240;]);(`Uchars [241;]);(`Uchars [242;]);
(`Uchars [243;]);(`Uchars [244;]);(`Uchars [245;]);(`Uchars [246;]);`Self;
(`Uchars [248;]);(`Uchars [249;]);(`Uchars [250;]);(`Uchars [251;]);
(`Uchars [252;]);(`Uchars [253;]);(`Uchars [254;]);(`Uchars [115;115;]);|];
nil;nil;[|(`Uchars [257;]);`Self;(`Uchars [259;]);`Self;(`Uchars [261;]);
`Self;(`Uchars [263;]);`Self;(`Uchars [265;]);`Self;(`Uchars [267;]);`Self;
(`Uchars [269;]);`Self;(`Uchars [271;]);`Self;|];[|(`Uchars [273;]);`Self;
(`Uchars [275;]);`Self;(`Uchars [277;]);`Self;(`Uchars [279;]);`Self;
(`Uchars [281;]);`Self;(`Uchars [283;]);`Self;(`Uchars [285;]);`Self;
(`Uchars [287;]);`Self;|];[|(`Uchars [289;]);`Self;(`Uchars [291;]);`Self;
(`Uchars [293;]);`Self;(`Uchars [295;]);`Self;(`Uchars [297;]);`Self;
(`Uchars [299;]);`Self;(`Uchars [301;]);`Self;(`Uchars [303;]);`Self;|];[|
(`Uchars [105;775;]);`Self;(`Uchars [105;106;]);(`Uchars [105;106;]);
(`Uchars [309;]);`Self;(`Uchars [311;]);`Self;`Self;(`Uchars [314;]);`Self;
(`Uchars [316;]);`Self;(`Uchars [318;]);`Self;(`Uchars [108;183;]);|];[|
(`Uchars [108;183;]);(`Uchars [322;]);`Self;(`Uchars [324;]);`Self;
(`Uchars [326;]);`Self;(`Uchars [328;]);`Self;(`Uchars [700;110;]);
(`Uchars [331;]);`Self;(`Uchars [333;]);`Self;(`Uchars [335;]);`Self;|];[|
(`Uchars [337;]);`Self;(`Uchars [339;]);`Self;(`Uchars [341;]);`Self;
(`Uchars [343;]);`Self;(`Uchars [345;]);`Self;(`Uchars [347;]);`Self;
(`Uchars [349;]);`Self;(`Uchars [351;]);`Self;|];[|(`Uchars [353;]);`Self;
(`Uchars [355;]);`Self;(`Uchars [357;]);`Self;(`Uchars [359;]);`Self;
(`Uchars [361;]);`Self;(`Uchars [363;]);`Self;(`Uchars [365;]);`Self;
(`Uchars [367;]);`Self;|];[|(`Uchars [369;]);`Self;(`Uchars [371;]);`Self;
(`Uchars [373;]);`Self;(`Uchars [375;]);`Self;(`Uchars [255;]);
(`Uchars [378;]);`Self;(`Uchars [380;]);`Self;(`Uchars [382;]);`Self;
(`Uchars [115;]);|];[|`Self;(`Uchars [595;]);(`Uchars [387;]);`Self;
(`Uchars [389;]);`Self;(`Uchars [596;]);(`Uchars [392;]);`Self;
(`Uchars [598;]);(`Uchars [599;]);(`Uchars [396;]);`Self;`Self;
(`Uchars [477;]);(`Uchars [601;]);|];[|(`Uchars [603;]);(`Uchars [402;]);
`Self;(`Uchars [608;]);(`Uchars [611;]);`Self;(`Uchars [617;]);
(`Uchars [616;]);(`Uchars [409;]);`Self;`Self;`Self;(`Uchars [623;]);
(`Uchars [626;]);`Self;(`Uchars [629;]);|];[|(`Uchars [417;]);`Self;
(`Uchars [419;]);`Self;(`Uchars [421;]);`Self;(`Uchars [640;]);
(`Uchars [424;]);`Self;(`Uchars [643;]);`Self;`Self;(`Uchars [429;]);`Self;
(`Uchars [648;]);(`Uchars [432;]);|];[|`Self;(`Uchars [650;]);
(`Uchars [651;]);(`Uchars [436;]);`Self;(`Uchars [438;]);`Self;
(`Uchars [658;]);(`Uchars [441;]);`Self;`Self;`Self;(`Uchars [445;]);`Self;
`Self;`Self;|];[|`Self;`Self;`Self;`Self;(`Uchars [100;382;]);
(`Uchars [100;382;]);(`Uchars [100;382;]);(`Uchars [108;106;]);
(`Uchars [108;106;]);(`Uchars [108;106;]);(`Uchars [110;106;]);
(`Uchars [110;106;]);(`Uchars [110;106;]);(`Uchars [462;]);`Self;
(`Uchars [464;]);|];[|`Self;(`Uchars [466;]);`Self;(`Uchars [468;]);`Self;
(`Uchars [470;]);`Self;(`Uchars [472;]);`Self;(`Uchars [474;]);`Self;
(`Uchars [476;]);`Self;`Self;(`Uchars [479;]);`Self;|];[|(`Uchars [481;]);
`Self;(`Uchars [483;]);`Self;(`Uchars [485;]);`Self;(`Uchars [487;]);`Self;
(`Uchars [489;]);`Self;(`Uchars [491;]);`Self;(`Uchars [493;]);`Self;
(`Uchars [495;]);`Self;|];[|`Self;(`Uchars [100;122;]);(`Uchars [100;122;]);
(`Uchars [100;122;]);(`Uchars [501;]);`Self;(`Uchars [405;]);
(`Uchars [447;]);(`Uchars [505;]);`Self;(`Uchars [507;]);`Self;
(`Uchars [509;]);`Self;(`Uchars [511;]);`Self;|];[|(`Uchars [513;]);`Self;
(`Uchars [515;]);`Self;(`Uchars [517;]);`Self;(`Uchars [519;]);`Self;
(`Uchars [521;]);`Self;(`Uchars [523;]);`Self;(`Uchars [525;]);`Self;
(`Uchars [527;]);`Self;|];[|(`Uchars [529;]);`Self;(`Uchars [531;]);`Self;
(`Uchars [533;]);`Self;(`Uchars [535;]);`Self;(`Uchars [537;]);`Self;
(`Uchars [539;]);`Self;(`Uchars [541;]);`Self;(`Uchars [543;]);`Self;|];[|
(`Uchars [414;]);`Self;(`Uchars [547;]);`Self;(`Uchars [549;]);`Self;
(`Uchars [551;]);`Self;(`Uchars [553;]);`Self;(`Uchars [555;]);`Self;
(`Uchars [557;]);`Self;(`Uchars [559;]);`Self;|];[|(`Uchars [561;]);`Self;
(`Uchars [563;]);`Self;`Self;`Self;`Self;`Self;`Self;`Self;
(`Uchars [11365;]);(`Uchars [572;]);`Self;(`Uchars [410;]);
(`Uchars [11366;]);`Self;|];[|`Self;(`Uchars [578;]);`Self;(`Uchars [384;]);
(`Uchars [649;]);(`Uchars [652;]);(`Uchars [583;]);`Self;(`Uchars [585;]);
`Self;(`Uchars [587;]);`Self;(`Uchars [589;]);`Self;(`Uchars [591;]);`Self;
|];nil;nil;nil;nil;nil;nil;[|(`Uchars [104;]);(`Uchars [614;]);
(`Uchars [106;]);(`Uchars [114;]);(`Uchars [633;]);(`Uchars [635;]);
(`Uchars [641;]);(`Uchars [119;]);(`Uchars [121;]);`Self;`Self;`Self;`Self;
`Self;`Self;`Self;|];nil;[|`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
(`Uchars [32;774;]);(`Uchars [32;775;]);(`Uchars [32;778;]);
(`Uchars [32;808;]);(`Uchars [32;771;]);(`Uchars [32;779;]);`Self;`Self;|];[|
(`Uchars [611;]);(`Uchars [108;]);(`Uchars [115;]);(`Uchars [120;]);
(`Uchars [661;]);`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
`Self;|];nil;nil;nil;nil;nil;[|(`Uchars [768;]);(`Uchars [769;]);`Self;
(`Uchars [787;]);(`Uchars [776;769;]);(`Uchars [953;]);`Self;`Self;`Self;
`Self;`Self;`Self;`Self;`Self;`Self;(`Uchars []);|];nil;nil;[|
(`Uchars [881;]);`Self;(`Uchars [883;]);`Self;(`Uchars [697;]);`Self;
(`Uchars [887;]);`Self;`Self;`Self;(`Uchars [32;953;]);`Self;`Self;`Self;
(`Uchars [59;]);(`Uchars [1011;]);|];[|`Self;`Self;`Self;`Self;
(`Uchars [32;769;]);(`Uchars [32;776;769;]);(`Uchars [940;]);
(`Uchars [183;]);(`Uchars [941;]);(`Uchars [942;]);(`Uchars [943;]);`Self;
(`Uchars [972;]);`Self;(`Uchars [973;]);(`Uchars [974;]);|];[|`Self;
(`Uchars [945;]);(`Uchars [946;]);(`Uchars [947;]);(`Uchars [948;]);
(`Uchars [949;]);(`Uchars [950;]);(`Uchars [951;]);(`Uchars [952;]);
(`Uchars [953;]);(`Uchars [954;]);(`Uchars [955;]);(`Uchars [956;]);
(`Uchars [957;]);(`Uchars [958;]);(`Uchars [959;]);|];[|(`Uchars [960;]);
(`Uchars [961;]);`Self;(`Uchars [963;]);(`Uchars [964;]);(`Uchars [965;]);
(`Uchars [966;]);(`Uchars [967;]);(`Uchars [968;]);(`Uchars [969;]);
(`Uchars [970;]);(`Uchars [971;]);`Self;`Self;`Self;`Self;|];nil;[|`Self;
`Self;(`Uchars [963;]);`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;`Self;(`Uchars [983;]);|];[|(`Uchars [946;]);(`Uchars [952;]);
(`Uchars [965;]);(`Uchars [973;]);(`Uchars [971;]);(`Uchars [966;]);
(`Uchars [960;]);`Self;(`Uchars [985;]);`Self;(`Uchars [987;]);`Self;
(`Uchars [989;]);`Self;(`Uchars [991;]);`Self;|];[|(`Uchars [993;]);`Self;
(`Uchars [995;]);`Self;(`Uchars [997;]);`Self;(`Uchars [999;]);`Self;
(`Uchars [1001;]);`Self;(`Uchars [1003;]);`Self;(`Uchars [1005;]);`Self;
(`Uchars [1007;]);`Self;|];[|(`Uchars [954;]);(`Uchars [961;]);
(`Uchars [963;]);`Self;(`Uchars [952;]);(`Uchars [949;]);`Self;
(`Uchars [1016;]);`Self;(`Uchars [963;]);(`Uchars [1019;]);`Self;`Self;
(`Uchars [891;]);(`Uchars [892;]);(`Uchars [893;]);|];[|(`Uchars [1104;]);
(`Uchars [1105;]);(`Uchars [1106;]);(`Uchars [1107;]);(`Uchars [1108;]);
(`Uchars [1109;]);(`Uchars [1110;]);(`Uchars [1111;]);(`Uchars [1112;]);
(`Uchars [1113;]);(`Uchars [1114;]);(`Uchars [1115;]);(`Uchars [1116;]);
(`Uchars [1117;]);(`Uchars [1118;]);(`Uchars [1119;]);|];[|(`Uchars [1072;]);
(`Uchars [1073;]);(`Uchars [1074;]);(`Uchars [1075;]);(`Uchars [1076;]);
(`Uchars [1077;]);(`Uchars [1078;]);(`Uchars [1079;]);(`Uchars [1080;]);
(`Uchars [1081;]);(`Uchars [1082;]);(`Uchars [1083;]);(`Uchars [1084;]);
(`Uchars [1085;]);(`Uchars [1086;]);(`Uchars [1087;]);|];[|(`Uchars [1088;]);
(`Uchars [1089;]);(`Uchars [1090;]);(`Uchars [1091;]);(`Uchars [1092;]);
(`Uchars [1093;]);(`Uchars [1094;]);(`Uchars [1095;]);(`Uchars [1096;]);
(`Uchars [1097;]);(`Uchars [1098;]);(`Uchars [1099;]);(`Uchars [1100;]);
(`Uchars [1101;]);(`Uchars [1102;]);(`Uchars [1103;]);|];nil;nil;nil;[|
(`Uchars [1121;]);`Self;(`Uchars [1123;]);`Self;(`Uchars [1125;]);`Self;
(`Uchars [1127;]);`Self;(`Uchars [1129;]);`Self;(`Uchars [1131;]);`Self;
(`Uchars [1133;]);`Self;(`Uchars [1135;]);`Self;|];[|(`Uchars [1137;]);`Self;
(`Uchars [1139;]);`Self;(`Uchars [1141;]);`Self;(`Uchars [1143;]);`Self;
(`Uchars [1145;]);`Self;(`Uchars [1147;]);`Self;(`Uchars [1149;]);`Self;
(`Uchars [1151;]);`Self;|];[|(`Uchars [1153;]);`Self;`Self;`Self;`Self;`Self;
`Self;`Self;`Self;`Self;(`Uchars [1163;]);`Self;(`Uchars [1165;]);`Self;
(`Uchars [1167;]);`Self;|];[|(`Uchars [1169;]);`Self;(`Uchars [1171;]);`Self;
(`Uchars [1173;]);`Self;(`Uchars [1175;]);`Self;(`Uchars [1177;]);`Self;
(`Uchars [1179;]);`Self;(`Uchars [1181;]);`Self;(`Uchars [1183;]);`Self;|];[|
(`Uchars [1185;]);`Self;(`Uchars [1187;]);`Self;(`Uchars [1189;]);`Self;
(`Uchars [1191;]);`Self;(`Uchars [1193;]);`Self;(`Uchars [1195;]);`Self;
(`Uchars [1197;]);`Self;(`Uchars [1199;]);`Self;|];[|(`Uchars [1201;]);`Self;
(`Uchars [1203;]);`Self;(`Uchars [1205;]);`Self;(`Uchars [1207;]);`Self;
(`Uchars [1209;]);`Self;(`Uchars [1211;]);`Self;(`Uchars [1213;]);`Self;
(`Uchars [1215;]);`Self;|];[|(`Uchars [1231;]);(`Uchars [1218;]);`Self;
(`Uchars [1220;]);`Self;(`Uchars [1222;]);`Self;(`Uchars [1224;]);`Self;
(`Uchars [1226;]);`Self;(`Uchars [1228;]);`Self;(`Uchars [1230;]);`Self;
`Self;|];[|(`Uchars [1233;]);`Self;(`Uchars [1235;]);`Self;(`Uchars [1237;]);
`Self;(`Uchars [1239;]);`Self;(`Uchars [1241;]);`Self;(`Uchars [1243;]);
`Self;(`Uchars [1245;]);`Self;(`Uchars [1247;]);`Self;|];[|(`Uchars [1249;]);
`Self;(`Uchars [1251;]);`Self;(`Uchars [1253;]);`Self;(`Uchars [1255;]);
`Self;(`Uchars [1257;]);`Self;(`Uchars [1259;]);`Self;(`Uchars [1261;]);
`Self;(`Uchars [1263;]);`Self;|];[|(`Uchars [1265;]);`Self;(`Uchars [1267;]);
`Self;(`Uchars [1269;]);`Self;(`Uchars [1271;]);`Self;(`Uchars [1273;]);
`Self;(`Uchars [1275;]);`Self;(`Uchars [1277;]);`Self;(`Uchars [1279;]);
`Self;|];[|(`Uchars [1281;]);`Self;(`Uchars [1283;]);`Self;(`Uchars [1285;]);
`Self;(`Uchars [1287;]);`Self;(`Uchars [1289;]);`Self;(`Uchars [1291;]);
`Self;(`Uchars [1293;]);`Self;(`Uchars [1295;]);`Self;|];[|(`Uchars [1297;]);
`Self;(`Uchars [1299;]);`Self;(`Uchars [1301;]);`Self;(`Uchars [1303;]);
`Self;(`Uchars [1305;]);`Self;(`Uchars [1307;]);`Self;(`Uchars [1309;]);
`Self;(`Uchars [1311;]);`Self;|];[|(`Uchars [1313;]);`Self;(`Uchars [1315;]);
`Self;(`Uchars [1317;]);`Self;(`Uchars [1319;]);`Self;(`Uchars [1321;]);
`Self;(`Uchars [1323;]);`Self;(`Uchars [1325;]);`Self;(`Uchars [1327;]);
`Self;|];[|`Self;(`Uchars [1377;]);(`Uchars [1378;]);(`Uchars [1379;]);
(`Uchars [1380;]);(`Uchars [1381;]);(`Uchars [1382;]);(`Uchars [1383;]);
(`Uchars [1384;]);(`Uchars [1385;]);(`Uchars [1386;]);(`Uchars [1387;]);
(`Uchars [1388;]);(`Uchars [1389;]);(`Uchars [1390;]);(`Uchars [1391;]);|];[|
(`Uchars [1392;]);(`Uchars [1393;]);(`Uchars [1394;]);(`Uchars [1395;]);
(`Uchars [1396;]);(`Uchars [1397;]);(`Uchars [1398;]);(`Uchars [1399;]);
(`Uchars [1400;]);(`Uchars [1401;]);(`Uchars [1402;]);(`Uchars [1403;]);
(`Uchars [1404;]);(`Uchars [1405;]);(`Uchars [1406;]);(`Uchars [1407;]);|];[|
(`Uchars [1408;]);(`Uchars [1409;]);(`Uchars [1410;]);(`Uchars [1411;]);
(`Uchars [1412;]);(`Uchars [1413;]);(`Uchars [1414;]);`Self;`Self;`Self;
`Self;`Self;`Self;`Self;`Self;`Self;|];nil;nil;[|`Self;`Self;`Self;`Self;
`Self;`Self;`Self;(`Uchars [1381;1410;]);`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;|];nil;nil;nil;nil;nil;nil;nil;nil;[|`Self;`Self;`Self;`Self;
`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;(`Uchars []);`Self;`Self;
`Self;|];nil;nil;nil;nil;nil;[|`Self;`Self;`Self;`Self;`Self;
(`Uchars [1575;1652;]);(`Uchars [1608;1652;]);(`Uchars [1735;1652;]);
(`Uchars [1610;1652;]);`Self;`Self;`Self;`Self;`Self;`Self;`Self;|];nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;[|`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
(`Uchars [2325;2364;]);(`Uchars [2326;2364;]);(`Uchars [2327;2364;]);
(`Uchars [2332;2364;]);(`Uchars [2337;2364;]);(`Uchars [2338;2364;]);
(`Uchars [2347;2364;]);(`Uchars [2351;2364;]);|];nil;nil;nil;nil;nil;nil;nil;
[|`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
(`Uchars [2465;2492;]);(`Uchars [2466;2492;]);`Self;(`Uchars [2479;2492;]);
|];nil;nil;nil;nil;nil;[|`Self;`Self;`Self;(`Uchars [2610;2620;]);`Self;
`Self;(`Uchars [2616;2620;]);`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
`Self;|];nil;[|`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
(`Uchars [2582;2620;]);(`Uchars [2583;2620;]);(`Uchars [2588;2620;]);`Self;
`Self;(`Uchars [2603;2620;]);`Self;|];nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;[|`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;`Self;`Self;(`Uchars [2849;2876;]);(`Uchars [2850;2876;]);`Self;
`Self;|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;[|`Self;`Self;`Self;
(`Uchars [3661;3634;]);`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;`Self;|];nil;nil;nil;nil;nil;nil;nil;[|`Self;`Self;`Self;
(`Uchars [3789;3762;]);`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;`Self;|];nil;[|`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;`Self;`Self;(`Uchars [3755;3737;]);(`Uchars [3755;3745;]);`Self;
`Self;|];nil;nil;[|`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;`Self;(`Uchars [3851;]);`Self;`Self;`Self;|];nil;nil;nil;[|`Self;
`Self;`Self;(`Uchars [3906;4023;]);`Self;`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;(`Uchars [3916;4023;]);`Self;`Self;|];[|`Self;`Self;
(`Uchars [3921;4023;]);`Self;`Self;`Self;`Self;(`Uchars [3926;4023;]);`Self;
`Self;`Self;`Self;(`Uchars [3931;4023;]);`Self;`Self;`Self;|];[|`Self;`Self;
`Self;`Self;`Self;`Self;`Self;`Self;`Self;(`Uchars [3904;4021;]);`Self;`Self;
`Self;`Self;`Self;`Self;|];[|`Self;`Self;`Self;(`Uchars [3953;3954;]);`Self;
(`Uchars [3953;3956;]);(`Uchars [4018;3968;]);(`Uchars [4018;3953;3968;]);
(`Uchars [4019;3968;]);(`Uchars [4019;3953;3968;]);`Self;`Self;`Self;`Self;
`Self;`Self;|];[|`Self;(`Uchars [3953;3968;]);`Self;`Self;`Self;`Self;`Self;
`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;|];[|`Self;`Self;`Self;
(`Uchars [3986;4023;]);`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
(`Uchars [3996;4023;]);`Self;`Self;|];[|`Self;`Self;(`Uchars [4001;4023;]);
`Self;`Self;`Self;`Self;(`Uchars [4006;4023;]);`Self;`Self;`Self;`Self;
(`Uchars [4011;4023;]);`Self;`Self;`Self;|];[|`Self;`Self;`Self;`Self;`Self;
`Self;`Self;`Self;`Self;(`Uchars [3984;4021;]);`Self;`Self;`Self;`Self;`Self;
`Self;|];nil;nil;nil;nil;|];[|nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;[|
(`Uchars [11520;]);(`Uchars [11521;]);(`Uchars [11522;]);(`Uchars [11523;]);
(`Uchars [11524;]);(`Uchars [11525;]);(`Uchars [11526;]);(`Uchars [11527;]);
(`Uchars [11528;]);(`Uchars [11529;]);(`Uchars [11530;]);(`Uchars [11531;]);
(`Uchars [11532;]);(`Uchars [11533;]);(`Uchars [11534;]);(`Uchars [11535;]);
|];[|(`Uchars [11536;]);(`Uchars [11537;]);(`Uchars [11538;]);
(`Uchars [11539;]);(`Uchars [11540;]);(`Uchars [11541;]);(`Uchars [11542;]);
(`Uchars [11543;]);(`Uchars [11544;]);(`Uchars [11545;]);(`Uchars [11546;]);
(`Uchars [11547;]);(`Uchars [11548;]);(`Uchars [11549;]);(`Uchars [11550;]);
(`Uchars [11551;]);|];[|(`Uchars [11552;]);(`Uchars [11553;]);
(`Uchars [11554;]);(`Uchars [11555;]);(`Uchars [11556;]);(`Uchars [11557;]);
`Self;(`Uchars [11559;]);`Self;`Self;`Self;`Self;`Self;(`Uchars [11565;]);
`Self;`Self;|];nil;nil;[|`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;`Self;`Self;(`Uchars [4316;]);`Self;`Self;`Self;|];nil;nil;nil;
nil;nil;[|`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;`Self;`Self;(`Uchars []);|];[|(`Uchars []);`Self;`Self;`Self;
`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;|];
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;[|`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;(`Uchars [5104;]);
(`Uchars [5105;]);(`Uchars [5106;]);(`Uchars [5107;]);(`Uchars [5108;]);
(`Uchars [5109;]);`Self;`Self;|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;[|`Self;`Self;`Self;`Self;
(`Uchars []);(`Uchars []);`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;|];nil;nil;nil;nil;[|`Self;`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;`Self;`Self;(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
`Self;|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;[|`Self;`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;`Self;`Self;`Self;(`Uchars [97;]);(`Uchars [230;]);
(`Uchars [98;]);`Self;|];[|(`Uchars [100;]);(`Uchars [101;]);
(`Uchars [477;]);(`Uchars [103;]);(`Uchars [104;]);(`Uchars [105;]);
(`Uchars [106;]);(`Uchars [107;]);(`Uchars [108;]);(`Uchars [109;]);
(`Uchars [110;]);`Self;(`Uchars [111;]);(`Uchars [547;]);(`Uchars [112;]);
(`Uchars [114;]);|];[|(`Uchars [116;]);(`Uchars [117;]);(`Uchars [119;]);
(`Uchars [97;]);(`Uchars [592;]);(`Uchars [593;]);(`Uchars [7426;]);
(`Uchars [98;]);(`Uchars [100;]);(`Uchars [101;]);(`Uchars [601;]);
(`Uchars [603;]);(`Uchars [604;]);(`Uchars [103;]);`Self;(`Uchars [107;]);|];
[|(`Uchars [109;]);(`Uchars [331;]);(`Uchars [111;]);(`Uchars [596;]);
(`Uchars [7446;]);(`Uchars [7447;]);(`Uchars [112;]);(`Uchars [116;]);
(`Uchars [117;]);(`Uchars [7453;]);(`Uchars [623;]);(`Uchars [118;]);
(`Uchars [7461;]);(`Uchars [946;]);(`Uchars [947;]);(`Uchars [948;]);|];[|
(`Uchars [966;]);(`Uchars [967;]);(`Uchars [105;]);(`Uchars [114;]);
(`Uchars [117;]);(`Uchars [118;]);(`Uchars [946;]);(`Uchars [947;]);
(`Uchars [961;]);(`Uchars [966;]);(`Uchars [967;]);`Self;`Self;`Self;`Self;
`Self;|];[|`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;(`Uchars [1085;]);
`Self;`Self;`Self;`Self;`Self;`Self;`Self;|];nil;[|`Self;`Self;`Self;`Self;
`Self;`Self;`Self;`Self;`Self;`Self;`Self;(`Uchars [594;]);(`Uchars [99;]);
(`Uchars [597;]);(`Uchars [240;]);(`Uchars [604;]);|];[|(`Uchars [102;]);
(`Uchars [607;]);(`Uchars [609;]);(`Uchars [613;]);(`Uchars [616;]);
(`Uchars [617;]);(`Uchars [618;]);(`Uchars [7547;]);(`Uchars [669;]);
(`Uchars [621;]);(`Uchars [7557;]);(`Uchars [671;]);(`Uchars [625;]);
(`Uchars [624;]);(`Uchars [626;]);(`Uchars [627;]);|];[|(`Uchars [628;]);
(`Uchars [629;]);(`Uchars [632;]);(`Uchars [642;]);(`Uchars [643;]);
(`Uchars [427;]);(`Uchars [649;]);(`Uchars [650;]);(`Uchars [7452;]);
(`Uchars [651;]);(`Uchars [652;]);(`Uchars [122;]);(`Uchars [656;]);
(`Uchars [657;]);(`Uchars [658;]);(`Uchars [952;]);|];nil;nil;nil;nil;[|
(`Uchars [7681;]);`Self;(`Uchars [7683;]);`Self;(`Uchars [7685;]);`Self;
(`Uchars [7687;]);`Self;(`Uchars [7689;]);`Self;(`Uchars [7691;]);`Self;
(`Uchars [7693;]);`Self;(`Uchars [7695;]);`Self;|];[|(`Uchars [7697;]);`Self;
(`Uchars [7699;]);`Self;(`Uchars [7701;]);`Self;(`Uchars [7703;]);`Self;
(`Uchars [7705;]);`Self;(`Uchars [7707;]);`Self;(`Uchars [7709;]);`Self;
(`Uchars [7711;]);`Self;|];[|(`Uchars [7713;]);`Self;(`Uchars [7715;]);`Self;
(`Uchars [7717;]);`Self;(`Uchars [7719;]);`Self;(`Uchars [7721;]);`Self;
(`Uchars [7723;]);`Self;(`Uchars [7725;]);`Self;(`Uchars [7727;]);`Self;|];[|
(`Uchars [7729;]);`Self;(`Uchars [7731;]);`Self;(`Uchars [7733;]);`Self;
(`Uchars [7735;]);`Self;(`Uchars [7737;]);`Self;(`Uchars [7739;]);`Self;
(`Uchars [7741;]);`Self;(`Uchars [7743;]);`Self;|];[|(`Uchars [7745;]);`Self;
(`Uchars [7747;]);`Self;(`Uchars [7749;]);`Self;(`Uchars [7751;]);`Self;
(`Uchars [7753;]);`Self;(`Uchars [7755;]);`Self;(`Uchars [7757;]);`Self;
(`Uchars [7759;]);`Self;|];[|(`Uchars [7761;]);`Self;(`Uchars [7763;]);`Self;
(`Uchars [7765;]);`Self;(`Uchars [7767;]);`Self;(`Uchars [7769;]);`Self;
(`Uchars [7771;]);`Self;(`Uchars [7773;]);`Self;(`Uchars [7775;]);`Self;|];[|
(`Uchars [7777;]);`Self;(`Uchars [7779;]);`Self;(`Uchars [7781;]);`Self;
(`Uchars [7783;]);`Self;(`Uchars [7785;]);`Self;(`Uchars [7787;]);`Self;
(`Uchars [7789;]);`Self;(`Uchars [7791;]);`Self;|];[|(`Uchars [7793;]);`Self;
(`Uchars [7795;]);`Self;(`Uchars [7797;]);`Self;(`Uchars [7799;]);`Self;
(`Uchars [7801;]);`Self;(`Uchars [7803;]);`Self;(`Uchars [7805;]);`Self;
(`Uchars [7807;]);`Self;|];[|(`Uchars [7809;]);`Self;(`Uchars [7811;]);`Self;
(`Uchars [7813;]);`Self;(`Uchars [7815;]);`Self;(`Uchars [7817;]);`Self;
(`Uchars [7819;]);`Self;(`Uchars [7821;]);`Self;(`Uchars [7823;]);`Self;|];[|
(`Uchars [7825;]);`Self;(`Uchars [7827;]);`Self;(`Uchars [7829;]);`Self;
`Self;`Self;`Self;`Self;(`Uchars [97;702;]);(`Uchars [7777;]);`Self;`Self;
(`Uchars [115;115;]);`Self;|];[|(`Uchars [7841;]);`Self;(`Uchars [7843;]);
`Self;(`Uchars [7845;]);`Self;(`Uchars [7847;]);`Self;(`Uchars [7849;]);
`Self;(`Uchars [7851;]);`Self;(`Uchars [7853;]);`Self;(`Uchars [7855;]);
`Self;|];[|(`Uchars [7857;]);`Self;(`Uchars [7859;]);`Self;(`Uchars [7861;]);
`Self;(`Uchars [7863;]);`Self;(`Uchars [7865;]);`Self;(`Uchars [7867;]);
`Self;(`Uchars [7869;]);`Self;(`Uchars [7871;]);`Self;|];[|(`Uchars [7873;]);
`Self;(`Uchars [7875;]);`Self;(`Uchars [7877;]);`Self;(`Uchars [7879;]);
`Self;(`Uchars [7881;]);`Self;(`Uchars [7883;]);`Self;(`Uchars [7885;]);
`Self;(`Uchars [7887;]);`Self;|];[|(`Uchars [7889;]);`Self;(`Uchars [7891;]);
`Self;(`Uchars [7893;]);`Self;(`Uchars [7895;]);`Self;(`Uchars [7897;]);
`Self;(`Uchars [7899;]);`Self;(`Uchars [7901;]);`Self;(`Uchars [7903;]);
`Self;|];[|(`Uchars [7905;]);`Self;(`Uchars [7907;]);`Self;(`Uchars [7909;]);
`Self;(`Uchars [7911;]);`Self;(`Uchars [7913;]);`Self;(`Uchars [7915;]);
`Self;(`Uchars [7917;]);`Self;(`Uchars [7919;]);`Self;|];[|(`Uchars [7921;]);
`Self;(`Uchars [7923;]);`Self;(`Uchars [7925;]);`Self;(`Uchars [7927;]);
`Self;(`Uchars [7929;]);`Self;(`Uchars [7931;]);`Self;(`Uchars [7933;]);
`Self;(`Uchars [7935;]);`Self;|];[|`Self;`Self;`Self;`Self;`Self;`Self;`Self;
`Self;(`Uchars [7936;]);(`Uchars [7937;]);(`Uchars [7938;]);
(`Uchars [7939;]);(`Uchars [7940;]);(`Uchars [7941;]);(`Uchars [7942;]);
(`Uchars [7943;]);|];[|`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
(`Uchars [7952;]);(`Uchars [7953;]);(`Uchars [7954;]);(`Uchars [7955;]);
(`Uchars [7956;]);(`Uchars [7957;]);`Self;`Self;|];[|`Self;`Self;`Self;`Self;
`Self;`Self;`Self;`Self;(`Uchars [7968;]);(`Uchars [7969;]);
(`Uchars [7970;]);(`Uchars [7971;]);(`Uchars [7972;]);(`Uchars [7973;]);
(`Uchars [7974;]);(`Uchars [7975;]);|];[|`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;(`Uchars [7984;]);(`Uchars [7985;]);(`Uchars [7986;]);
(`Uchars [7987;]);(`Uchars [7988;]);(`Uchars [7989;]);(`Uchars [7990;]);
(`Uchars [7991;]);|];[|`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
(`Uchars [8000;]);(`Uchars [8001;]);(`Uchars [8002;]);(`Uchars [8003;]);
(`Uchars [8004;]);(`Uchars [8005;]);`Self;`Self;|];[|`Self;`Self;`Self;`Self;
`Self;`Self;`Self;`Self;`Self;(`Uchars [8017;]);`Self;(`Uchars [8019;]);
`Self;(`Uchars [8021;]);`Self;(`Uchars [8023;]);|];[|`Self;`Self;`Self;`Self;
`Self;`Self;`Self;`Self;(`Uchars [8032;]);(`Uchars [8033;]);
(`Uchars [8034;]);(`Uchars [8035;]);(`Uchars [8036;]);(`Uchars [8037;]);
(`Uchars [8038;]);(`Uchars [8039;]);|];[|`Self;(`Uchars [940;]);`Self;
(`Uchars [941;]);`Self;(`Uchars [942;]);`Self;(`Uchars [943;]);`Self;
(`Uchars [972;]);`Self;(`Uchars [973;]);`Self;(`Uchars [974;]);`Self;`Self;
|];[|(`Uchars [7936;953;]);(`Uchars [7937;953;]);(`Uchars [7938;953;]);
(`Uchars [7939;953;]);(`Uchars [7940;953;]);(`Uchars [7941;953;]);
(`Uchars [7942;953;]);(`Uchars [7943;953;]);(`Uchars [7936;953;]);
(`Uchars [7937;953;]);(`Uchars [7938;953;]);(`Uchars [7939;953;]);
(`Uchars [7940;953;]);(`Uchars [7941;953;]);(`Uchars [7942;953;]);
(`Uchars [7943;953;]);|];[|(`Uchars [7968;953;]);(`Uchars [7969;953;]);
(`Uchars [7970;953;]);(`Uchars [7971;953;]);(`Uchars [7972;953;]);
(`Uchars [7973;953;]);(`Uchars [7974;953;]);(`Uchars [7975;953;]);
(`Uchars [7968;953;]);(`Uchars [7969;953;]);(`Uchars [7970;953;]);
(`Uchars [7971;953;]);(`Uchars [7972;953;]);(`Uchars [7973;953;]);
(`Uchars [7974;953;]);(`Uchars [7975;953;]);|];[|(`Uchars [8032;953;]);
(`Uchars [8033;953;]);(`Uchars [8034;953;]);(`Uchars [8035;953;]);
(`Uchars [8036;953;]);(`Uchars [8037;953;]);(`Uchars [8038;953;]);
(`Uchars [8039;953;]);(`Uchars [8032;953;]);(`Uchars [8033;953;]);
(`Uchars [8034;953;]);(`Uchars [8035;953;]);(`Uchars [8036;953;]);
(`Uchars [8037;953;]);(`Uchars [8038;953;]);(`Uchars [8039;953;]);|];[|`Self;
`Self;(`Uchars [8048;953;]);(`Uchars [945;953;]);(`Uchars [940;953;]);`Self;
`Self;(`Uchars [8118;953;]);(`Uchars [8112;]);(`Uchars [8113;]);
(`Uchars [8048;]);(`Uchars [940;]);(`Uchars [945;953;]);(`Uchars [32;787;]);
(`Uchars [953;]);(`Uchars [32;787;]);|];[|(`Uchars [32;834;]);
(`Uchars [32;776;834;]);(`Uchars [8052;953;]);(`Uchars [951;953;]);
(`Uchars [942;953;]);`Self;`Self;(`Uchars [8134;953;]);(`Uchars [8050;]);
(`Uchars [941;]);(`Uchars [8052;]);(`Uchars [942;]);(`Uchars [951;953;]);
(`Uchars [32;787;768;]);(`Uchars [32;787;769;]);(`Uchars [32;787;834;]);|];[|
`Self;`Self;`Self;(`Uchars [912;]);`Self;`Self;`Self;`Self;(`Uchars [8144;]);
(`Uchars [8145;]);(`Uchars [8054;]);(`Uchars [943;]);`Self;
(`Uchars [32;788;768;]);(`Uchars [32;788;769;]);(`Uchars [32;788;834;]);|];[|
`Self;`Self;`Self;(`Uchars [944;]);`Self;`Self;`Self;`Self;(`Uchars [8160;]);
(`Uchars [8161;]);(`Uchars [8058;]);(`Uchars [973;]);(`Uchars [8165;]);
(`Uchars [32;776;768;]);(`Uchars [32;776;769;]);(`Uchars [96;]);|];[|`Self;
`Self;(`Uchars [8060;953;]);(`Uchars [969;953;]);(`Uchars [974;953;]);`Self;
`Self;(`Uchars [8182;953;]);(`Uchars [8056;]);(`Uchars [972;]);
(`Uchars [8060;]);(`Uchars [974;]);(`Uchars [969;953;]);(`Uchars [32;769;]);
(`Uchars [32;788;]);`Self;|];|];[|[|(`Uchars [32;]);(`Uchars [32;]);
(`Uchars [32;]);(`Uchars [32;]);(`Uchars [32;]);(`Uchars [32;]);
(`Uchars [32;]);(`Uchars [32;]);(`Uchars [32;]);(`Uchars [32;]);
(`Uchars [32;]);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|`Self;(`Uchars [8208;]);`Self;`Self;`Self;`Self;`Self;
(`Uchars [32;819;]);`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;|];[|
`Self;`Self;`Self;`Self;(`Uchars [46;]);(`Uchars [46;46;]);
(`Uchars [46;46;46;]);`Self;`Self;`Self;(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars [32;]);|];[|`Self;`Self;
`Self;(`Uchars [8242;8242;]);(`Uchars [8242;8242;8242;]);`Self;
(`Uchars [8245;8245;]);(`Uchars [8245;8245;8245;]);`Self;`Self;`Self;`Self;
(`Uchars [33;33;]);`Self;(`Uchars [32;773;]);`Self;|];[|`Self;`Self;`Self;
`Self;`Self;`Self;`Self;(`Uchars [63;63;]);(`Uchars [63;33;]);
(`Uchars [33;63;]);`Self;`Self;`Self;`Self;`Self;`Self;|];[|`Self;`Self;
`Self;`Self;`Self;`Self;`Self;(`Uchars [8242;8242;8242;8242;]);`Self;`Self;
`Self;`Self;`Self;`Self;`Self;(`Uchars [32;]);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars [48;]);
(`Uchars [105;]);`Self;`Self;(`Uchars [52;]);(`Uchars [53;]);(`Uchars [54;]);
(`Uchars [55;]);(`Uchars [56;]);(`Uchars [57;]);(`Uchars [43;]);
(`Uchars [8722;]);(`Uchars [61;]);(`Uchars [40;]);(`Uchars [41;]);
(`Uchars [110;]);|];[|(`Uchars [48;]);(`Uchars [49;]);(`Uchars [50;]);
(`Uchars [51;]);(`Uchars [52;]);(`Uchars [53;]);(`Uchars [54;]);
(`Uchars [55;]);(`Uchars [56;]);(`Uchars [57;]);(`Uchars [43;]);
(`Uchars [8722;]);(`Uchars [61;]);(`Uchars [40;]);(`Uchars [41;]);`Self;|];[|
(`Uchars [97;]);(`Uchars [101;]);(`Uchars [111;]);(`Uchars [120;]);
(`Uchars [601;]);(`Uchars [104;]);(`Uchars [107;]);(`Uchars [108;]);
(`Uchars [109;]);(`Uchars [110;]);(`Uchars [112;]);(`Uchars [115;]);
(`Uchars [116;]);`Self;`Self;`Self;|];[|`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;(`Uchars [114;115;]);`Self;`Self;`Self;`Self;`Self;`Self;`Self;
|];nil;nil;nil;nil;nil;[|(`Uchars [97;47;99;]);(`Uchars [97;47;115;]);
(`Uchars [99;]);(`Uchars [176;99;]);`Self;(`Uchars [99;47;111;]);
(`Uchars [99;47;117;]);(`Uchars [603;]);`Self;(`Uchars [176;102;]);
(`Uchars [103;]);(`Uchars [104;]);(`Uchars [104;]);(`Uchars [104;]);
(`Uchars [104;]);(`Uchars [295;]);|];[|(`Uchars [105;]);(`Uchars [105;]);
(`Uchars [108;]);(`Uchars [108;]);`Self;(`Uchars [110;]);
(`Uchars [110;111;]);`Self;`Self;(`Uchars [112;]);(`Uchars [113;]);
(`Uchars [114;]);(`Uchars [114;]);(`Uchars [114;]);`Self;`Self;|];[|
(`Uchars [115;109;]);(`Uchars [116;101;108;]);(`Uchars [116;109;]);`Self;
(`Uchars [122;]);`Self;(`Uchars [969;]);`Self;(`Uchars [122;]);`Self;
(`Uchars [107;]);(`Uchars [229;]);(`Uchars [98;]);(`Uchars [99;]);`Self;
(`Uchars [101;]);|];[|(`Uchars [101;]);(`Uchars [102;]);(`Uchars [8526;]);
(`Uchars [109;]);(`Uchars [111;]);(`Uchars [1488;]);(`Uchars [1489;]);
(`Uchars [1490;]);(`Uchars [1491;]);(`Uchars [105;]);`Self;
(`Uchars [102;97;120;]);(`Uchars [960;]);(`Uchars [947;]);(`Uchars [947;]);
(`Uchars [960;]);|];[|(`Uchars [8721;]);`Self;`Self;`Self;`Self;
(`Uchars [100;]);(`Uchars [100;]);(`Uchars [101;]);(`Uchars [105;]);
(`Uchars [106;]);`Self;`Self;`Self;`Self;`Self;`Self;|];[|
(`Uchars [49;8260;55;]);(`Uchars [49;8260;57;]);(`Uchars [49;8260;49;48;]);
(`Uchars [49;8260;51;]);(`Uchars [50;8260;51;]);(`Uchars [49;8260;53;]);
(`Uchars [50;8260;53;]);(`Uchars [51;8260;53;]);(`Uchars [52;8260;53;]);
(`Uchars [49;8260;54;]);(`Uchars [53;8260;54;]);(`Uchars [49;8260;56;]);
(`Uchars [51;8260;56;]);(`Uchars [53;8260;56;]);(`Uchars [55;8260;56;]);
(`Uchars [49;8260;]);|];[|(`Uchars [105;]);(`Uchars [105;105;]);
(`Uchars [105;105;105;]);(`Uchars [105;118;]);(`Uchars [118;]);
(`Uchars [118;105;]);(`Uchars [118;105;105;]);(`Uchars [118;105;105;105;]);
(`Uchars [105;120;]);(`Uchars [120;]);(`Uchars [120;105;]);
(`Uchars [120;105;105;]);(`Uchars [108;]);(`Uchars [99;]);(`Uchars [100;]);
(`Uchars [109;]);|];[|(`Uchars [105;]);(`Uchars [105;105;]);
(`Uchars [105;105;105;]);(`Uchars [105;118;]);(`Uchars [118;]);
(`Uchars [118;105;]);(`Uchars [118;105;105;]);(`Uchars [118;105;105;105;]);
(`Uchars [105;120;]);(`Uchars [120;]);(`Uchars [120;105;]);
(`Uchars [120;105;105;]);(`Uchars [108;]);(`Uchars [99;]);(`Uchars [100;]);
(`Uchars [109;]);|];[|`Self;`Self;`Self;(`Uchars [8580;]);`Self;`Self;`Self;
`Self;`Self;(`Uchars [48;8260;51;]);`Self;`Self;`Self;`Self;`Self;`Self;|];
nil;nil;nil;nil;nil;nil;nil;nil;nil;[|`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;`Self;`Self;`Self;`Self;(`Uchars [8747;8747;]);
(`Uchars [8747;8747;8747;]);`Self;(`Uchars [8750;8750;]);|];[|
(`Uchars [8750;8750;8750;]);`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;`Self;`Self;`Self;`Self;`Self;|];nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;[|`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
`Self;(`Uchars [12296;]);(`Uchars [12297;]);`Self;`Self;`Self;`Self;`Self;|];
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
[|(`Uchars [49;]);(`Uchars [50;]);(`Uchars [51;]);(`Uchars [52;]);
(`Uchars [53;]);(`Uchars [54;]);(`Uchars [55;]);(`Uchars [56;]);
(`Uchars [57;]);(`Uchars [49;48;]);(`Uchars [49;49;]);(`Uchars [49;50;]);
(`Uchars [49;51;]);(`Uchars [49;52;]);(`Uchars [49;53;]);(`Uchars [49;54;]);
|];[|(`Uchars [49;55;]);(`Uchars [49;56;]);(`Uchars [49;57;]);
(`Uchars [50;48;]);(`Uchars [40;49;41;]);(`Uchars [40;50;41;]);
(`Uchars [40;51;41;]);(`Uchars [40;52;41;]);(`Uchars [40;53;41;]);
(`Uchars [40;54;41;]);(`Uchars [40;55;41;]);(`Uchars [40;56;41;]);
(`Uchars [40;57;41;]);(`Uchars [40;49;48;41;]);(`Uchars [40;49;49;41;]);
(`Uchars [40;49;50;41;]);|];[|(`Uchars [40;49;51;41;]);
(`Uchars [40;49;52;41;]);(`Uchars [40;49;53;41;]);(`Uchars [40;49;54;41;]);
(`Uchars [40;49;55;41;]);(`Uchars [40;49;56;41;]);(`Uchars [40;49;57;41;]);
(`Uchars [40;50;48;41;]);(`Uchars [49;46;]);(`Uchars [50;46;]);
(`Uchars [51;46;]);(`Uchars [52;46;]);(`Uchars [53;46;]);(`Uchars [54;46;]);
(`Uchars [55;46;]);(`Uchars [56;46;]);|];[|(`Uchars [57;46;]);
(`Uchars [49;48;46;]);(`Uchars [49;49;46;]);(`Uchars [49;50;46;]);
(`Uchars [49;51;46;]);(`Uchars [49;52;46;]);(`Uchars [49;53;46;]);
(`Uchars [49;54;46;]);(`Uchars [49;55;46;]);(`Uchars [49;56;46;]);
(`Uchars [49;57;46;]);(`Uchars [50;48;46;]);(`Uchars [40;97;41;]);
(`Uchars [40;98;41;]);(`Uchars [40;99;41;]);(`Uchars [40;100;41;]);|];[|
(`Uchars [40;101;41;]);(`Uchars [40;102;41;]);(`Uchars [40;103;41;]);
(`Uchars [40;104;41;]);(`Uchars [40;105;41;]);(`Uchars [40;106;41;]);
(`Uchars [40;107;41;]);(`Uchars [40;108;41;]);(`Uchars [40;109;41;]);
(`Uchars [40;110;41;]);(`Uchars [40;111;41;]);(`Uchars [40;112;41;]);
(`Uchars [40;113;41;]);(`Uchars [40;114;41;]);(`Uchars [40;115;41;]);
(`Uchars [40;116;41;]);|];[|(`Uchars [40;117;41;]);(`Uchars [40;118;41;]);
(`Uchars [40;119;41;]);(`Uchars [40;120;41;]);(`Uchars [40;121;41;]);
(`Uchars [40;122;41;]);(`Uchars [97;]);(`Uchars [98;]);(`Uchars [99;]);
(`Uchars [100;]);(`Uchars [101;]);(`Uchars [102;]);(`Uchars [103;]);
(`Uchars [104;]);(`Uchars [105;]);(`Uchars [106;]);|];[|(`Uchars [107;]);
(`Uchars [108;]);(`Uchars [109;]);(`Uchars [110;]);(`Uchars [111;]);
(`Uchars [112;]);(`Uchars [113;]);(`Uchars [114;]);(`Uchars [115;]);
(`Uchars [116;]);(`Uchars [117;]);(`Uchars [118;]);(`Uchars [119;]);
(`Uchars [120;]);(`Uchars [121;]);(`Uchars [122;]);|];[|(`Uchars [97;]);
(`Uchars [98;]);(`Uchars [99;]);(`Uchars [100;]);(`Uchars [101;]);
(`Uchars [102;]);(`Uchars [103;]);(`Uchars [104;]);(`Uchars [105;]);
(`Uchars [106;]);(`Uchars [107;]);(`Uchars [108;]);(`Uchars [109;]);
(`Uchars [110;]);(`Uchars [111;]);(`Uchars [112;]);|];[|(`Uchars [113;]);
(`Uchars [114;]);(`Uchars [115;]);(`Uchars [116;]);(`Uchars [117;]);
(`Uchars [118;]);(`Uchars [119;]);(`Uchars [120;]);(`Uchars [121;]);
(`Uchars [122;]);(`Uchars [48;]);`Self;`Self;`Self;`Self;`Self;|];nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;[|`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;(`Uchars [8747;8747;8747;8747;]);`Self;`Self;`Self;|];nil;nil;
nil;nil;nil;nil;[|`Self;`Self;`Self;`Self;(`Uchars [58;58;61;]);
(`Uchars [61;61;]);(`Uchars [61;61;61;]);`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;`Self;|];nil;nil;nil;nil;nil;[|`Self;`Self;`Self;`Self;`Self;
`Self;`Self;`Self;`Self;`Self;`Self;`Self;(`Uchars [10973;824;]);`Self;`Self;
`Self;|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;[|(`Uchars [11312;]);(`Uchars [11313;]);(`Uchars [11314;]);
(`Uchars [11315;]);(`Uchars [11316;]);(`Uchars [11317;]);(`Uchars [11318;]);
(`Uchars [11319;]);(`Uchars [11320;]);(`Uchars [11321;]);(`Uchars [11322;]);
(`Uchars [11323;]);(`Uchars [11324;]);(`Uchars [11325;]);(`Uchars [11326;]);
(`Uchars [11327;]);|];[|(`Uchars [11328;]);(`Uchars [11329;]);
(`Uchars [11330;]);(`Uchars [11331;]);(`Uchars [11332;]);(`Uchars [11333;]);
(`Uchars [11334;]);(`Uchars [11335;]);(`Uchars [11336;]);(`Uchars [11337;]);
(`Uchars [11338;]);(`Uchars [11339;]);(`Uchars [11340;]);(`Uchars [11341;]);
(`Uchars [11342;]);(`Uchars [11343;]);|];[|(`Uchars [11344;]);
(`Uchars [11345;]);(`Uchars [11346;]);(`Uchars [11347;]);(`Uchars [11348;]);
(`Uchars [11349;]);(`Uchars [11350;]);(`Uchars [11351;]);(`Uchars [11352;]);
(`Uchars [11353;]);(`Uchars [11354;]);(`Uchars [11355;]);(`Uchars [11356;]);
(`Uchars [11357;]);(`Uchars [11358;]);`Self;|];nil;nil;nil;[|
(`Uchars [11361;]);`Self;(`Uchars [619;]);(`Uchars [7549;]);(`Uchars [637;]);
`Self;`Self;(`Uchars [11368;]);`Self;(`Uchars [11370;]);`Self;
(`Uchars [11372;]);`Self;(`Uchars [593;]);(`Uchars [625;]);(`Uchars [592;]);
|];[|(`Uchars [594;]);`Self;(`Uchars [11379;]);`Self;`Self;
(`Uchars [11382;]);`Self;`Self;`Self;`Self;`Self;`Self;(`Uchars [106;]);
(`Uchars [118;]);(`Uchars [575;]);(`Uchars [576;]);|];[|(`Uchars [11393;]);
`Self;(`Uchars [11395;]);`Self;(`Uchars [11397;]);`Self;(`Uchars [11399;]);
`Self;(`Uchars [11401;]);`Self;(`Uchars [11403;]);`Self;(`Uchars [11405;]);
`Self;(`Uchars [11407;]);`Self;|];[|(`Uchars [11409;]);`Self;
(`Uchars [11411;]);`Self;(`Uchars [11413;]);`Self;(`Uchars [11415;]);`Self;
(`Uchars [11417;]);`Self;(`Uchars [11419;]);`Self;(`Uchars [11421;]);`Self;
(`Uchars [11423;]);`Self;|];[|(`Uchars [11425;]);`Self;(`Uchars [11427;]);
`Self;(`Uchars [11429;]);`Self;(`Uchars [11431;]);`Self;(`Uchars [11433;]);
`Self;(`Uchars [11435;]);`Self;(`Uchars [11437;]);`Self;(`Uchars [11439;]);
`Self;|];[|(`Uchars [11441;]);`Self;(`Uchars [11443;]);`Self;
(`Uchars [11445;]);`Self;(`Uchars [11447;]);`Self;(`Uchars [11449;]);`Self;
(`Uchars [11451;]);`Self;(`Uchars [11453;]);`Self;(`Uchars [11455;]);`Self;
|];[|(`Uchars [11457;]);`Self;(`Uchars [11459;]);`Self;(`Uchars [11461;]);
`Self;(`Uchars [11463;]);`Self;(`Uchars [11465;]);`Self;(`Uchars [11467;]);
`Self;(`Uchars [11469;]);`Self;(`Uchars [11471;]);`Self;|];[|
(`Uchars [11473;]);`Self;(`Uchars [11475;]);`Self;(`Uchars [11477;]);`Self;
(`Uchars [11479;]);`Self;(`Uchars [11481;]);`Self;(`Uchars [11483;]);`Self;
(`Uchars [11485;]);`Self;(`Uchars [11487;]);`Self;|];[|(`Uchars [11489;]);
`Self;(`Uchars [11491;]);`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
(`Uchars [11500;]);`Self;(`Uchars [11502;]);`Self;`Self;|];[|`Self;`Self;
(`Uchars [11507;]);`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;`Self;`Self;|];nil;nil;nil;nil;nil;nil;[|`Self;`Self;`Self;`Self;
`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
(`Uchars [11617;]);|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;[|`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;`Self;`Self;`Self;`Self;(`Uchars [27597;]);|];nil;nil;nil;nil;
nil;[|`Self;`Self;`Self;(`Uchars [40863;]);`Self;`Self;`Self;`Self;`Self;
`Self;`Self;`Self;`Self;`Self;`Self;`Self;|];[|(`Uchars [19968;]);
(`Uchars [20008;]);(`Uchars [20022;]);(`Uchars [20031;]);(`Uchars [20057;]);
(`Uchars [20101;]);(`Uchars [20108;]);(`Uchars [20128;]);(`Uchars [20154;]);
(`Uchars [20799;]);(`Uchars [20837;]);(`Uchars [20843;]);(`Uchars [20866;]);
(`Uchars [20886;]);(`Uchars [20907;]);(`Uchars [20960;]);|];[|
(`Uchars [20981;]);(`Uchars [20992;]);(`Uchars [21147;]);(`Uchars [21241;]);
(`Uchars [21269;]);(`Uchars [21274;]);(`Uchars [21304;]);(`Uchars [21313;]);
(`Uchars [21340;]);(`Uchars [21353;]);(`Uchars [21378;]);(`Uchars [21430;]);
(`Uchars [21448;]);(`Uchars [21475;]);(`Uchars [22231;]);(`Uchars [22303;]);
|];[|(`Uchars [22763;]);(`Uchars [22786;]);(`Uchars [22794;]);
(`Uchars [22805;]);(`Uchars [22823;]);(`Uchars [22899;]);(`Uchars [23376;]);
(`Uchars [23424;]);(`Uchars [23544;]);(`Uchars [23567;]);(`Uchars [23586;]);
(`Uchars [23608;]);(`Uchars [23662;]);(`Uchars [23665;]);(`Uchars [24027;]);
(`Uchars [24037;]);|];[|(`Uchars [24049;]);(`Uchars [24062;]);
(`Uchars [24178;]);(`Uchars [24186;]);(`Uchars [24191;]);(`Uchars [24308;]);
(`Uchars [24318;]);(`Uchars [24331;]);(`Uchars [24339;]);(`Uchars [24400;]);
(`Uchars [24417;]);(`Uchars [24435;]);(`Uchars [24515;]);(`Uchars [25096;]);
(`Uchars [25142;]);(`Uchars [25163;]);|];[|(`Uchars [25903;]);
(`Uchars [25908;]);(`Uchars [25991;]);(`Uchars [26007;]);(`Uchars [26020;]);
(`Uchars [26041;]);(`Uchars [26080;]);(`Uchars [26085;]);(`Uchars [26352;]);
(`Uchars [26376;]);(`Uchars [26408;]);(`Uchars [27424;]);(`Uchars [27490;]);
(`Uchars [27513;]);(`Uchars [27571;]);(`Uchars [27595;]);|];[|
(`Uchars [27604;]);(`Uchars [27611;]);(`Uchars [27663;]);(`Uchars [27668;]);
(`Uchars [27700;]);(`Uchars [28779;]);(`Uchars [29226;]);(`Uchars [29238;]);
(`Uchars [29243;]);(`Uchars [29247;]);(`Uchars [29255;]);(`Uchars [29273;]);
(`Uchars [29275;]);(`Uchars [29356;]);(`Uchars [29572;]);(`Uchars [29577;]);
|];[|(`Uchars [29916;]);(`Uchars [29926;]);(`Uchars [29976;]);
(`Uchars [29983;]);(`Uchars [29992;]);(`Uchars [30000;]);(`Uchars [30091;]);
(`Uchars [30098;]);(`Uchars [30326;]);(`Uchars [30333;]);(`Uchars [30382;]);
(`Uchars [30399;]);(`Uchars [30446;]);(`Uchars [30683;]);(`Uchars [30690;]);
(`Uchars [30707;]);|];[|(`Uchars [31034;]);(`Uchars [31160;]);
(`Uchars [31166;]);(`Uchars [31348;]);(`Uchars [31435;]);(`Uchars [31481;]);
(`Uchars [31859;]);(`Uchars [31992;]);(`Uchars [32566;]);(`Uchars [32593;]);
(`Uchars [32650;]);(`Uchars [32701;]);(`Uchars [32769;]);(`Uchars [32780;]);
(`Uchars [32786;]);(`Uchars [32819;]);|];[|(`Uchars [32895;]);
(`Uchars [32905;]);(`Uchars [33251;]);(`Uchars [33258;]);(`Uchars [33267;]);
(`Uchars [33276;]);(`Uchars [33292;]);(`Uchars [33307;]);(`Uchars [33311;]);
(`Uchars [33390;]);(`Uchars [33394;]);(`Uchars [33400;]);(`Uchars [34381;]);
(`Uchars [34411;]);(`Uchars [34880;]);(`Uchars [34892;]);|];[|
(`Uchars [34915;]);(`Uchars [35198;]);(`Uchars [35211;]);(`Uchars [35282;]);
(`Uchars [35328;]);(`Uchars [35895;]);(`Uchars [35910;]);(`Uchars [35925;]);
(`Uchars [35960;]);(`Uchars [35997;]);(`Uchars [36196;]);(`Uchars [36208;]);
(`Uchars [36275;]);(`Uchars [36523;]);(`Uchars [36554;]);(`Uchars [36763;]);
|];[|(`Uchars [36784;]);(`Uchars [36789;]);(`Uchars [37009;]);
(`Uchars [37193;]);(`Uchars [37318;]);(`Uchars [37324;]);(`Uchars [37329;]);
(`Uchars [38263;]);(`Uchars [38272;]);(`Uchars [38428;]);(`Uchars [38582;]);
(`Uchars [38585;]);(`Uchars [38632;]);(`Uchars [38737;]);(`Uchars [38750;]);
(`Uchars [38754;]);|];[|(`Uchars [38761;]);(`Uchars [38859;]);
(`Uchars [38893;]);(`Uchars [38899;]);(`Uchars [38913;]);(`Uchars [39080;]);
(`Uchars [39131;]);(`Uchars [39135;]);(`Uchars [39318;]);(`Uchars [39321;]);
(`Uchars [39340;]);(`Uchars [39592;]);(`Uchars [39640;]);(`Uchars [39647;]);
(`Uchars [39717;]);(`Uchars [39727;]);|];[|(`Uchars [39730;]);
(`Uchars [39740;]);(`Uchars [39770;]);(`Uchars [40165;]);(`Uchars [40565;]);
(`Uchars [40575;]);(`Uchars [40613;]);(`Uchars [40635;]);(`Uchars [40643;]);
(`Uchars [40653;]);(`Uchars [40657;]);(`Uchars [40697;]);(`Uchars [40701;]);
(`Uchars [40718;]);(`Uchars [40723;]);(`Uchars [40736;]);|];[|
(`Uchars [40763;]);(`Uchars [40778;]);(`Uchars [40786;]);(`Uchars [40845;]);
(`Uchars [40860;]);(`Uchars [40864;]);`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;`Self;`Self;|];nil;nil;|];[|[|(`Uchars [32;]);`Self;`Self;`Self;
`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;|];
nil;nil;[|`Self;`Self;`Self;`Self;`Self;`Self;(`Uchars [12306;]);`Self;
(`Uchars [21313;]);(`Uchars [21316;]);(`Uchars [21317;]);`Self;`Self;`Self;
`Self;`Self;|];nil;nil;nil;nil;nil;[|`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;`Self;`Self;`Self;(`Uchars [32;12441;]);(`Uchars [32;12442;]);
`Self;`Self;(`Uchars [12424;12426;]);|];nil;nil;nil;nil;nil;[|`Self;`Self;
`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
`Self;(`Uchars [12467;12488;]);|];nil;nil;nil;[|`Self;(`Uchars [4352;]);
(`Uchars [4353;]);(`Uchars [4522;]);(`Uchars [4354;]);(`Uchars [4524;]);
(`Uchars [4525;]);(`Uchars [4355;]);(`Uchars [4356;]);(`Uchars [4357;]);
(`Uchars [4528;]);(`Uchars [4529;]);(`Uchars [4530;]);(`Uchars [4531;]);
(`Uchars [4532;]);(`Uchars [4533;]);|];[|(`Uchars [4378;]);(`Uchars [4358;]);
(`Uchars [4359;]);(`Uchars [4360;]);(`Uchars [4385;]);(`Uchars [4361;]);
(`Uchars [4362;]);(`Uchars [4363;]);(`Uchars [4364;]);(`Uchars [4365;]);
(`Uchars [4366;]);(`Uchars [4367;]);(`Uchars [4368;]);(`Uchars [4369;]);
(`Uchars [4370;]);(`Uchars [4449;]);|];[|(`Uchars [4450;]);(`Uchars [4451;]);
(`Uchars [4452;]);(`Uchars [4453;]);(`Uchars [4454;]);(`Uchars [4455;]);
(`Uchars [4456;]);(`Uchars [4457;]);(`Uchars [4458;]);(`Uchars [4459;]);
(`Uchars [4460;]);(`Uchars [4461;]);(`Uchars [4462;]);(`Uchars [4463;]);
(`Uchars [4464;]);(`Uchars [4465;]);|];[|(`Uchars [4466;]);(`Uchars [4467;]);
(`Uchars [4468;]);(`Uchars [4469;]);(`Uchars []);(`Uchars [4372;]);
(`Uchars [4373;]);(`Uchars [4551;]);(`Uchars [4552;]);(`Uchars [4556;]);
(`Uchars [4558;]);(`Uchars [4563;]);(`Uchars [4567;]);(`Uchars [4569;]);
(`Uchars [4380;]);(`Uchars [4573;]);|];[|(`Uchars [4575;]);(`Uchars [4381;]);
(`Uchars [4382;]);(`Uchars [4384;]);(`Uchars [4386;]);(`Uchars [4387;]);
(`Uchars [4391;]);(`Uchars [4393;]);(`Uchars [4395;]);(`Uchars [4396;]);
(`Uchars [4397;]);(`Uchars [4398;]);(`Uchars [4399;]);(`Uchars [4402;]);
(`Uchars [4406;]);(`Uchars [4416;]);|];[|(`Uchars [4423;]);(`Uchars [4428;]);
(`Uchars [4593;]);(`Uchars [4594;]);(`Uchars [4439;]);(`Uchars [4440;]);
(`Uchars [4441;]);(`Uchars [4484;]);(`Uchars [4485;]);(`Uchars [4488;]);
(`Uchars [4497;]);(`Uchars [4498;]);(`Uchars [4500;]);(`Uchars [4510;]);
(`Uchars [4513;]);`Self;|];[|`Self;`Self;(`Uchars [19968;]);
(`Uchars [20108;]);(`Uchars [19977;]);(`Uchars [22235;]);(`Uchars [19978;]);
(`Uchars [20013;]);(`Uchars [19979;]);(`Uchars [30002;]);(`Uchars [20057;]);
(`Uchars [19993;]);(`Uchars [19969;]);(`Uchars [22825;]);(`Uchars [22320;]);
(`Uchars [20154;]);|];nil;nil;nil;nil;nil;nil;[|(`Uchars [40;4352;41;]);
(`Uchars [40;4354;41;]);(`Uchars [40;4355;41;]);(`Uchars [40;4357;41;]);
(`Uchars [40;4358;41;]);(`Uchars [40;4359;41;]);(`Uchars [40;4361;41;]);
(`Uchars [40;4363;41;]);(`Uchars [40;4364;41;]);(`Uchars [40;4366;41;]);
(`Uchars [40;4367;41;]);(`Uchars [40;4368;41;]);(`Uchars [40;4369;41;]);
(`Uchars [40;4370;41;]);(`Uchars [40;44032;41;]);(`Uchars [40;45208;41;]);|];
[|(`Uchars [40;45796;41;]);(`Uchars [40;46972;41;]);(`Uchars [40;47560;41;]);
(`Uchars [40;48148;41;]);(`Uchars [40;49324;41;]);(`Uchars [40;50500;41;]);
(`Uchars [40;51088;41;]);(`Uchars [40;52264;41;]);(`Uchars [40;52852;41;]);
(`Uchars [40;53440;41;]);(`Uchars [40;54028;41;]);(`Uchars [40;54616;41;]);
(`Uchars [40;51452;41;]);(`Uchars [40;50724;51204;41;]);
(`Uchars [40;50724;54980;41;]);`Self;|];[|(`Uchars [40;19968;41;]);
(`Uchars [40;20108;41;]);(`Uchars [40;19977;41;]);(`Uchars [40;22235;41;]);
(`Uchars [40;20116;41;]);(`Uchars [40;20845;41;]);(`Uchars [40;19971;41;]);
(`Uchars [40;20843;41;]);(`Uchars [40;20061;41;]);(`Uchars [40;21313;41;]);
(`Uchars [40;26376;41;]);(`Uchars [40;28779;41;]);(`Uchars [40;27700;41;]);
(`Uchars [40;26408;41;]);(`Uchars [40;37329;41;]);(`Uchars [40;22303;41;]);
|];[|(`Uchars [40;26085;41;]);(`Uchars [40;26666;41;]);
(`Uchars [40;26377;41;]);(`Uchars [40;31038;41;]);(`Uchars [40;21517;41;]);
(`Uchars [40;29305;41;]);(`Uchars [40;36001;41;]);(`Uchars [40;31069;41;]);
(`Uchars [40;21172;41;]);(`Uchars [40;20195;41;]);(`Uchars [40;21628;41;]);
(`Uchars [40;23398;41;]);(`Uchars [40;30435;41;]);(`Uchars [40;20225;41;]);
(`Uchars [40;36039;41;]);(`Uchars [40;21332;41;]);|];[|
(`Uchars [40;31085;41;]);(`Uchars [40;20241;41;]);(`Uchars [40;33258;41;]);
(`Uchars [40;33267;41;]);(`Uchars [21839;]);(`Uchars [24188;]);
(`Uchars [25991;]);(`Uchars [31631;]);`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;|];[|(`Uchars [112;116;101;]);(`Uchars [50;49;]);
(`Uchars [50;50;]);(`Uchars [50;51;]);(`Uchars [50;52;]);(`Uchars [50;53;]);
(`Uchars [50;54;]);(`Uchars [50;55;]);(`Uchars [50;56;]);(`Uchars [50;57;]);
(`Uchars [51;48;]);(`Uchars [51;49;]);(`Uchars [51;50;]);(`Uchars [51;51;]);
(`Uchars [51;52;]);(`Uchars [51;53;]);|];[|(`Uchars [4352;]);
(`Uchars [4354;]);(`Uchars [4355;]);(`Uchars [4357;]);(`Uchars [4358;]);
(`Uchars [4359;]);(`Uchars [4361;]);(`Uchars [4363;]);(`Uchars [4364;]);
(`Uchars [4366;]);(`Uchars [4367;]);(`Uchars [4368;]);(`Uchars [4369;]);
(`Uchars [4370;]);(`Uchars [44032;]);(`Uchars [45208;]);|];[|
(`Uchars [45796;]);(`Uchars [46972;]);(`Uchars [47560;]);(`Uchars [48148;]);
(`Uchars [49324;]);(`Uchars [50500;]);(`Uchars [51088;]);(`Uchars [52264;]);
(`Uchars [52852;]);(`Uchars [53440;]);(`Uchars [54028;]);(`Uchars [54616;]);
(`Uchars [52280;44256;]);(`Uchars [51452;51032;]);(`Uchars [50864;]);`Self;
|];[|(`Uchars [19968;]);(`Uchars [20108;]);(`Uchars [19977;]);
(`Uchars [22235;]);(`Uchars [20116;]);(`Uchars [20845;]);(`Uchars [19971;]);
(`Uchars [20843;]);(`Uchars [20061;]);(`Uchars [21313;]);(`Uchars [26376;]);
(`Uchars [28779;]);(`Uchars [27700;]);(`Uchars [26408;]);(`Uchars [37329;]);
(`Uchars [22303;]);|];[|(`Uchars [26085;]);(`Uchars [26666;]);
(`Uchars [26377;]);(`Uchars [31038;]);(`Uchars [21517;]);(`Uchars [29305;]);
(`Uchars [36001;]);(`Uchars [31069;]);(`Uchars [21172;]);(`Uchars [31192;]);
(`Uchars [30007;]);(`Uchars [22899;]);(`Uchars [36969;]);(`Uchars [20778;]);
(`Uchars [21360;]);(`Uchars [27880;]);|];[|(`Uchars [38917;]);
(`Uchars [20241;]);(`Uchars [20889;]);(`Uchars [27491;]);(`Uchars [19978;]);
(`Uchars [20013;]);(`Uchars [19979;]);(`Uchars [24038;]);(`Uchars [21491;]);
(`Uchars [21307;]);(`Uchars [23447;]);(`Uchars [23398;]);(`Uchars [30435;]);
(`Uchars [20225;]);(`Uchars [36039;]);(`Uchars [21332;]);|];[|
(`Uchars [22812;]);(`Uchars [51;54;]);(`Uchars [51;55;]);(`Uchars [51;56;]);
(`Uchars [51;57;]);(`Uchars [52;48;]);(`Uchars [52;49;]);(`Uchars [52;50;]);
(`Uchars [52;51;]);(`Uchars [52;52;]);(`Uchars [52;53;]);(`Uchars [52;54;]);
(`Uchars [52;55;]);(`Uchars [52;56;]);(`Uchars [52;57;]);(`Uchars [53;48;]);
|];[|(`Uchars [49;26376;]);(`Uchars [50;26376;]);(`Uchars [51;26376;]);
(`Uchars [52;26376;]);(`Uchars [53;26376;]);(`Uchars [54;26376;]);
(`Uchars [55;26376;]);(`Uchars [56;26376;]);(`Uchars [57;26376;]);
(`Uchars [49;48;26376;]);(`Uchars [49;49;26376;]);(`Uchars [49;50;26376;]);
(`Uchars [104;103;]);(`Uchars [101;114;103;]);(`Uchars [101;118;]);
(`Uchars [108;116;100;]);|];[|(`Uchars [12450;]);(`Uchars [12452;]);
(`Uchars [12454;]);(`Uchars [12456;]);(`Uchars [12458;]);(`Uchars [12459;]);
(`Uchars [12461;]);(`Uchars [12463;]);(`Uchars [12465;]);(`Uchars [12467;]);
(`Uchars [12469;]);(`Uchars [12471;]);(`Uchars [12473;]);(`Uchars [12475;]);
(`Uchars [12477;]);(`Uchars [12479;]);|];[|(`Uchars [12481;]);
(`Uchars [12484;]);(`Uchars [12486;]);(`Uchars [12488;]);(`Uchars [12490;]);
(`Uchars [12491;]);(`Uchars [12492;]);(`Uchars [12493;]);(`Uchars [12494;]);
(`Uchars [12495;]);(`Uchars [12498;]);(`Uchars [12501;]);(`Uchars [12504;]);
(`Uchars [12507;]);(`Uchars [12510;]);(`Uchars [12511;]);|];[|
(`Uchars [12512;]);(`Uchars [12513;]);(`Uchars [12514;]);(`Uchars [12516;]);
(`Uchars [12518;]);(`Uchars [12520;]);(`Uchars [12521;]);(`Uchars [12522;]);
(`Uchars [12523;]);(`Uchars [12524;]);(`Uchars [12525;]);(`Uchars [12527;]);
(`Uchars [12528;]);(`Uchars [12529;]);(`Uchars [12530;]);`Self;|];[|
(`Uchars [12450;12497;12540;12488;]);(`Uchars [12450;12523;12501;12449;]);
(`Uchars [12450;12531;12506;12450;]);(`Uchars [12450;12540;12523;]);
(`Uchars [12452;12491;12531;12464;]);(`Uchars [12452;12531;12481;]);
(`Uchars [12454;12457;12531;]);(`Uchars [12456;12473;12463;12540;12489;]);
(`Uchars [12456;12540;12459;12540;]);(`Uchars [12458;12531;12473;]);
(`Uchars [12458;12540;12512;]);(`Uchars [12459;12452;12522;]);
(`Uchars [12459;12521;12483;12488;]);(`Uchars [12459;12525;12522;12540;]);
(`Uchars [12460;12525;12531;]);(`Uchars [12460;12531;12510;]);|];[|
(`Uchars [12462;12460;]);(`Uchars [12462;12491;12540;]);
(`Uchars [12461;12517;12522;12540;]);(`Uchars [12462;12523;12480;12540;]);
(`Uchars [12461;12525;]);(`Uchars [12461;12525;12464;12521;12512;]);
(`Uchars [12461;12525;12513;12540;12488;12523;]);
(`Uchars [12461;12525;12527;12483;12488;]);(`Uchars [12464;12521;12512;]);
(`Uchars [12464;12521;12512;12488;12531;]);
(`Uchars [12463;12523;12476;12452;12525;]);
(`Uchars [12463;12525;12540;12493;]);(`Uchars [12465;12540;12473;]);
(`Uchars [12467;12523;12490;]);(`Uchars [12467;12540;12509;]);
(`Uchars [12469;12452;12463;12523;]);|];[|
(`Uchars [12469;12531;12481;12540;12512;]);
(`Uchars [12471;12522;12531;12464;]);(`Uchars [12475;12531;12481;]);
(`Uchars [12475;12531;12488;]);(`Uchars [12480;12540;12473;]);
(`Uchars [12487;12471;]);(`Uchars [12489;12523;]);(`Uchars [12488;12531;]);
(`Uchars [12490;12494;]);(`Uchars [12494;12483;12488;]);
(`Uchars [12495;12452;12484;]);(`Uchars [12497;12540;12475;12531;12488;]);
(`Uchars [12497;12540;12484;]);(`Uchars [12496;12540;12524;12523;]);
(`Uchars [12500;12450;12473;12488;12523;]);(`Uchars [12500;12463;12523;]);|];
[|(`Uchars [12500;12467;]);(`Uchars [12499;12523;]);
(`Uchars [12501;12449;12521;12483;12489;]);
(`Uchars [12501;12451;12540;12488;]);
(`Uchars [12502;12483;12471;12455;12523;]);(`Uchars [12501;12521;12531;]);
(`Uchars [12504;12463;12479;12540;12523;]);(`Uchars [12506;12477;]);
(`Uchars [12506;12491;12498;]);(`Uchars [12504;12523;12484;]);
(`Uchars [12506;12531;12473;]);(`Uchars [12506;12540;12472;]);
(`Uchars [12505;12540;12479;]);(`Uchars [12509;12452;12531;12488;]);
(`Uchars [12508;12523;12488;]);(`Uchars [12507;12531;]);|];[|
(`Uchars [12509;12531;12489;]);(`Uchars [12507;12540;12523;]);
(`Uchars [12507;12540;12531;]);(`Uchars [12510;12452;12463;12525;]);
(`Uchars [12510;12452;12523;]);(`Uchars [12510;12483;12495;]);
(`Uchars [12510;12523;12463;]);(`Uchars [12510;12531;12471;12519;12531;]);
(`Uchars [12511;12463;12525;12531;]);(`Uchars [12511;12522;]);
(`Uchars [12511;12522;12496;12540;12523;]);(`Uchars [12513;12460;]);
(`Uchars [12513;12460;12488;12531;]);(`Uchars [12513;12540;12488;12523;]);
(`Uchars [12516;12540;12489;]);(`Uchars [12516;12540;12523;]);|];[|
(`Uchars [12518;12450;12531;]);(`Uchars [12522;12483;12488;12523;]);
(`Uchars [12522;12521;]);(`Uchars [12523;12500;12540;]);
(`Uchars [12523;12540;12502;12523;]);(`Uchars [12524;12512;]);
(`Uchars [12524;12531;12488;12466;12531;]);(`Uchars [12527;12483;12488;]);
(`Uchars [48;28857;]);(`Uchars [49;28857;]);(`Uchars [50;28857;]);
(`Uchars [51;28857;]);(`Uchars [52;28857;]);(`Uchars [53;28857;]);
(`Uchars [54;28857;]);(`Uchars [55;28857;]);|];[|(`Uchars [56;28857;]);
(`Uchars [57;28857;]);(`Uchars [49;48;28857;]);(`Uchars [49;49;28857;]);
(`Uchars [49;50;28857;]);(`Uchars [49;51;28857;]);(`Uchars [49;52;28857;]);
(`Uchars [49;53;28857;]);(`Uchars [49;54;28857;]);(`Uchars [49;55;28857;]);
(`Uchars [49;56;28857;]);(`Uchars [49;57;28857;]);(`Uchars [50;48;28857;]);
(`Uchars [50;49;28857;]);(`Uchars [50;50;28857;]);(`Uchars [50;51;28857;]);
|];[|(`Uchars [50;52;28857;]);(`Uchars [104;112;97;]);(`Uchars [100;97;]);
(`Uchars [97;117;]);(`Uchars [98;97;114;]);(`Uchars [111;118;]);
(`Uchars [112;99;]);(`Uchars [100;109;]);(`Uchars [100;109;50;]);
(`Uchars [100;109;51;]);(`Uchars [105;117;]);(`Uchars [24179;25104;]);
(`Uchars [26157;21644;]);(`Uchars [22823;27491;]);(`Uchars [26126;27835;]);
(`Uchars [26666;24335;20250;31038;]);|];[|(`Uchars [112;97;]);
(`Uchars [110;97;]);(`Uchars [956;97;]);(`Uchars [109;97;]);
(`Uchars [107;97;]);(`Uchars [107;98;]);(`Uchars [109;98;]);
(`Uchars [103;98;]);(`Uchars [99;97;108;]);(`Uchars [107;99;97;108;]);
(`Uchars [112;102;]);(`Uchars [110;102;]);(`Uchars [956;102;]);
(`Uchars [956;103;]);(`Uchars [109;103;]);(`Uchars [107;103;]);|];[|
(`Uchars [104;122;]);(`Uchars [107;104;122;]);(`Uchars [109;104;122;]);
(`Uchars [103;104;122;]);(`Uchars [116;104;122;]);(`Uchars [956;108;]);
(`Uchars [109;108;]);(`Uchars [100;108;]);(`Uchars [107;108;]);
(`Uchars [102;109;]);(`Uchars [110;109;]);(`Uchars [956;109;]);
(`Uchars [109;109;]);(`Uchars [99;109;]);(`Uchars [107;109;]);
(`Uchars [109;109;50;]);|];[|(`Uchars [99;109;50;]);(`Uchars [109;50;]);
(`Uchars [107;109;50;]);(`Uchars [109;109;51;]);(`Uchars [99;109;51;]);
(`Uchars [109;51;]);(`Uchars [107;109;51;]);(`Uchars [109;8725;115;]);
(`Uchars [109;8725;115;50;]);(`Uchars [112;97;]);(`Uchars [107;112;97;]);
(`Uchars [109;112;97;]);(`Uchars [103;112;97;]);(`Uchars [114;97;100;]);
(`Uchars [114;97;100;8725;115;]);(`Uchars [114;97;100;8725;115;50;]);|];[|
(`Uchars [112;115;]);(`Uchars [110;115;]);(`Uchars [956;115;]);
(`Uchars [109;115;]);(`Uchars [112;118;]);(`Uchars [110;118;]);
(`Uchars [956;118;]);(`Uchars [109;118;]);(`Uchars [107;118;]);
(`Uchars [109;118;]);(`Uchars [112;119;]);(`Uchars [110;119;]);
(`Uchars [956;119;]);(`Uchars [109;119;]);(`Uchars [107;119;]);
(`Uchars [109;119;]);|];[|(`Uchars [107;969;]);(`Uchars [109;969;]);
(`Uchars [97;46;109;46;]);(`Uchars [98;113;]);(`Uchars [99;99;]);
(`Uchars [99;100;]);(`Uchars [99;8725;107;103;]);(`Uchars [99;111;46;]);
(`Uchars [100;98;]);(`Uchars [103;121;]);(`Uchars [104;97;]);
(`Uchars [104;112;]);(`Uchars [105;110;]);(`Uchars [107;107;]);
(`Uchars [107;109;]);(`Uchars [107;116;]);|];[|(`Uchars [108;109;]);
(`Uchars [108;110;]);(`Uchars [108;111;103;]);(`Uchars [108;120;]);
(`Uchars [109;98;]);(`Uchars [109;105;108;]);(`Uchars [109;111;108;]);
(`Uchars [112;104;]);(`Uchars [112;46;109;46;]);(`Uchars [112;112;109;]);
(`Uchars [112;114;]);(`Uchars [115;114;]);(`Uchars [115;118;]);
(`Uchars [119;98;]);(`Uchars [118;8725;109;]);(`Uchars [97;8725;109;]);|];[|
(`Uchars [49;26085;]);(`Uchars [50;26085;]);(`Uchars [51;26085;]);
(`Uchars [52;26085;]);(`Uchars [53;26085;]);(`Uchars [54;26085;]);
(`Uchars [55;26085;]);(`Uchars [56;26085;]);(`Uchars [57;26085;]);
(`Uchars [49;48;26085;]);(`Uchars [49;49;26085;]);(`Uchars [49;50;26085;]);
(`Uchars [49;51;26085;]);(`Uchars [49;52;26085;]);(`Uchars [49;53;26085;]);
(`Uchars [49;54;26085;]);|];[|(`Uchars [49;55;26085;]);
(`Uchars [49;56;26085;]);(`Uchars [49;57;26085;]);(`Uchars [50;48;26085;]);
(`Uchars [50;49;26085;]);(`Uchars [50;50;26085;]);(`Uchars [50;51;26085;]);
(`Uchars [50;52;26085;]);(`Uchars [50;53;26085;]);(`Uchars [50;54;26085;]);
(`Uchars [50;55;26085;]);(`Uchars [50;56;26085;]);(`Uchars [50;57;26085;]);
(`Uchars [51;48;26085;]);(`Uchars [51;49;26085;]);(`Uchars [103;97;108;]);|];
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;|];nil;nil;nil;nil;nil;nil;[|nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;[|(`Uchars [42561;]);
`Self;(`Uchars [42563;]);`Self;(`Uchars [42565;]);`Self;(`Uchars [42567;]);
`Self;(`Uchars [42569;]);`Self;(`Uchars [42571;]);`Self;(`Uchars [42573;]);
`Self;(`Uchars [42575;]);`Self;|];[|(`Uchars [42577;]);`Self;
(`Uchars [42579;]);`Self;(`Uchars [42581;]);`Self;(`Uchars [42583;]);`Self;
(`Uchars [42585;]);`Self;(`Uchars [42587;]);`Self;(`Uchars [42589;]);`Self;
(`Uchars [42591;]);`Self;|];[|(`Uchars [42593;]);`Self;(`Uchars [42595;]);
`Self;(`Uchars [42597;]);`Self;(`Uchars [42599;]);`Self;(`Uchars [42601;]);
`Self;(`Uchars [42603;]);`Self;(`Uchars [42605;]);`Self;`Self;`Self;|];nil;[|
(`Uchars [42625;]);`Self;(`Uchars [42627;]);`Self;(`Uchars [42629;]);`Self;
(`Uchars [42631;]);`Self;(`Uchars [42633;]);`Self;(`Uchars [42635;]);`Self;
(`Uchars [42637;]);`Self;(`Uchars [42639;]);`Self;|];[|(`Uchars [42641;]);
`Self;(`Uchars [42643;]);`Self;(`Uchars [42645;]);`Self;(`Uchars [42647;]);
`Self;(`Uchars [42649;]);`Self;(`Uchars [42651;]);`Self;(`Uchars [1098;]);
(`Uchars [1100;]);`Self;`Self;|];nil;nil;nil;nil;nil;nil;nil;nil;[|`Self;
`Self;(`Uchars [42787;]);`Self;(`Uchars [42789;]);`Self;(`Uchars [42791;]);
`Self;(`Uchars [42793;]);`Self;(`Uchars [42795;]);`Self;(`Uchars [42797;]);
`Self;(`Uchars [42799;]);`Self;|];[|`Self;`Self;(`Uchars [42803;]);`Self;
(`Uchars [42805;]);`Self;(`Uchars [42807;]);`Self;(`Uchars [42809;]);`Self;
(`Uchars [42811;]);`Self;(`Uchars [42813;]);`Self;(`Uchars [42815;]);`Self;
|];[|(`Uchars [42817;]);`Self;(`Uchars [42819;]);`Self;(`Uchars [42821;]);
`Self;(`Uchars [42823;]);`Self;(`Uchars [42825;]);`Self;(`Uchars [42827;]);
`Self;(`Uchars [42829;]);`Self;(`Uchars [42831;]);`Self;|];[|
(`Uchars [42833;]);`Self;(`Uchars [42835;]);`Self;(`Uchars [42837;]);`Self;
(`Uchars [42839;]);`Self;(`Uchars [42841;]);`Self;(`Uchars [42843;]);`Self;
(`Uchars [42845;]);`Self;(`Uchars [42847;]);`Self;|];[|(`Uchars [42849;]);
`Self;(`Uchars [42851;]);`Self;(`Uchars [42853;]);`Self;(`Uchars [42855;]);
`Self;(`Uchars [42857;]);`Self;(`Uchars [42859;]);`Self;(`Uchars [42861;]);
`Self;(`Uchars [42863;]);`Self;|];[|(`Uchars [42863;]);`Self;`Self;`Self;
`Self;`Self;`Self;`Self;`Self;(`Uchars [42874;]);`Self;(`Uchars [42876;]);
`Self;(`Uchars [7545;]);(`Uchars [42879;]);`Self;|];[|(`Uchars [42881;]);
`Self;(`Uchars [42883;]);`Self;(`Uchars [42885;]);`Self;(`Uchars [42887;]);
`Self;`Self;`Self;`Self;(`Uchars [42892;]);`Self;(`Uchars [613;]);`Self;
`Self;|];[|(`Uchars [42897;]);`Self;(`Uchars [42899;]);`Self;`Self;`Self;
(`Uchars [42903;]);`Self;(`Uchars [42905;]);`Self;(`Uchars [42907;]);`Self;
(`Uchars [42909;]);`Self;(`Uchars [42911;]);`Self;|];[|(`Uchars [42913;]);
`Self;(`Uchars [42915;]);`Self;(`Uchars [42917;]);`Self;(`Uchars [42919;]);
`Self;(`Uchars [42921;]);`Self;(`Uchars [614;]);(`Uchars [604;]);
(`Uchars [609;]);(`Uchars [620;]);`Self;`Self;|];[|(`Uchars [670;]);
(`Uchars [647;]);(`Uchars [669;]);(`Uchars [43859;]);(`Uchars [42933;]);
`Self;(`Uchars [42935;]);`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
`Self;|];nil;nil;nil;[|`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
(`Uchars [295;]);(`Uchars [339;]);`Self;`Self;`Self;`Self;`Self;`Self;|];nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;[|`Self;`Self;`Self;
`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;(`Uchars [42791;]);
(`Uchars [43831;]);(`Uchars [619;]);(`Uchars [43858;]);|];nil;[|
(`Uchars [5024;]);(`Uchars [5025;]);(`Uchars [5026;]);(`Uchars [5027;]);
(`Uchars [5028;]);(`Uchars [5029;]);(`Uchars [5030;]);(`Uchars [5031;]);
(`Uchars [5032;]);(`Uchars [5033;]);(`Uchars [5034;]);(`Uchars [5035;]);
(`Uchars [5036;]);(`Uchars [5037;]);(`Uchars [5038;]);(`Uchars [5039;]);|];[|
(`Uchars [5040;]);(`Uchars [5041;]);(`Uchars [5042;]);(`Uchars [5043;]);
(`Uchars [5044;]);(`Uchars [5045;]);(`Uchars [5046;]);(`Uchars [5047;]);
(`Uchars [5048;]);(`Uchars [5049;]);(`Uchars [5050;]);(`Uchars [5051;]);
(`Uchars [5052;]);(`Uchars [5053;]);(`Uchars [5054;]);(`Uchars [5055;]);|];[|
(`Uchars [5056;]);(`Uchars [5057;]);(`Uchars [5058;]);(`Uchars [5059;]);
(`Uchars [5060;]);(`Uchars [5061;]);(`Uchars [5062;]);(`Uchars [5063;]);
(`Uchars [5064;]);(`Uchars [5065;]);(`Uchars [5066;]);(`Uchars [5067;]);
(`Uchars [5068;]);(`Uchars [5069;]);(`Uchars [5070;]);(`Uchars [5071;]);|];[|
(`Uchars [5072;]);(`Uchars [5073;]);(`Uchars [5074;]);(`Uchars [5075;]);
(`Uchars [5076;]);(`Uchars [5077;]);(`Uchars [5078;]);(`Uchars [5079;]);
(`Uchars [5080;]);(`Uchars [5081;]);(`Uchars [5082;]);(`Uchars [5083;]);
(`Uchars [5084;]);(`Uchars [5085;]);(`Uchars [5086;]);(`Uchars [5087;]);|];[|
(`Uchars [5088;]);(`Uchars [5089;]);(`Uchars [5090;]);(`Uchars [5091;]);
(`Uchars [5092;]);(`Uchars [5093;]);(`Uchars [5094;]);(`Uchars [5095;]);
(`Uchars [5096;]);(`Uchars [5097;]);(`Uchars [5098;]);(`Uchars [5099;]);
(`Uchars [5100;]);(`Uchars [5101;]);(`Uchars [5102;]);(`Uchars [5103;]);|];
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;|];nil;nil;nil;nil;[|nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;[|(`Uchars [35912;]);(`Uchars [26356;]);
(`Uchars [36554;]);(`Uchars [36040;]);(`Uchars [28369;]);(`Uchars [20018;]);
(`Uchars [21477;]);(`Uchars [40860;]);(`Uchars [40860;]);(`Uchars [22865;]);
(`Uchars [37329;]);(`Uchars [21895;]);(`Uchars [22856;]);(`Uchars [25078;]);
(`Uchars [30313;]);(`Uchars [32645;]);|];[|(`Uchars [34367;]);
(`Uchars [34746;]);(`Uchars [35064;]);(`Uchars [37007;]);(`Uchars [27138;]);
(`Uchars [27931;]);(`Uchars [28889;]);(`Uchars [29662;]);(`Uchars [33853;]);
(`Uchars [37226;]);(`Uchars [39409;]);(`Uchars [20098;]);(`Uchars [21365;]);
(`Uchars [27396;]);(`Uchars [29211;]);(`Uchars [34349;]);|];[|
(`Uchars [40478;]);(`Uchars [23888;]);(`Uchars [28651;]);(`Uchars [34253;]);
(`Uchars [35172;]);(`Uchars [25289;]);(`Uchars [33240;]);(`Uchars [34847;]);
(`Uchars [24266;]);(`Uchars [26391;]);(`Uchars [28010;]);(`Uchars [29436;]);
(`Uchars [37070;]);(`Uchars [20358;]);(`Uchars [20919;]);(`Uchars [21214;]);
|];[|(`Uchars [25796;]);(`Uchars [27347;]);(`Uchars [29200;]);
(`Uchars [30439;]);(`Uchars [32769;]);(`Uchars [34310;]);(`Uchars [34396;]);
(`Uchars [36335;]);(`Uchars [38706;]);(`Uchars [39791;]);(`Uchars [40442;]);
(`Uchars [30860;]);(`Uchars [31103;]);(`Uchars [32160;]);(`Uchars [33737;]);
(`Uchars [37636;]);|];[|(`Uchars [40575;]);(`Uchars [35542;]);
(`Uchars [22751;]);(`Uchars [24324;]);(`Uchars [31840;]);(`Uchars [32894;]);
(`Uchars [29282;]);(`Uchars [30922;]);(`Uchars [36034;]);(`Uchars [38647;]);
(`Uchars [22744;]);(`Uchars [23650;]);(`Uchars [27155;]);(`Uchars [28122;]);
(`Uchars [28431;]);(`Uchars [32047;]);|];[|(`Uchars [32311;]);
(`Uchars [38475;]);(`Uchars [21202;]);(`Uchars [32907;]);(`Uchars [20956;]);
(`Uchars [20940;]);(`Uchars [31260;]);(`Uchars [32190;]);(`Uchars [33777;]);
(`Uchars [38517;]);(`Uchars [35712;]);(`Uchars [25295;]);(`Uchars [27138;]);
(`Uchars [35582;]);(`Uchars [20025;]);(`Uchars [23527;]);|];[|
(`Uchars [24594;]);(`Uchars [29575;]);(`Uchars [30064;]);(`Uchars [21271;]);
(`Uchars [30971;]);(`Uchars [20415;]);(`Uchars [24489;]);(`Uchars [19981;]);
(`Uchars [27852;]);(`Uchars [25976;]);(`Uchars [32034;]);(`Uchars [21443;]);
(`Uchars [22622;]);(`Uchars [30465;]);(`Uchars [33865;]);(`Uchars [35498;]);
|];[|(`Uchars [27578;]);(`Uchars [36784;]);(`Uchars [27784;]);
(`Uchars [25342;]);(`Uchars [33509;]);(`Uchars [25504;]);(`Uchars [30053;]);
(`Uchars [20142;]);(`Uchars [20841;]);(`Uchars [20937;]);(`Uchars [26753;]);
(`Uchars [31975;]);(`Uchars [33391;]);(`Uchars [35538;]);(`Uchars [37327;]);
(`Uchars [21237;]);|];[|(`Uchars [21570;]);(`Uchars [22899;]);
(`Uchars [24300;]);(`Uchars [26053;]);(`Uchars [28670;]);(`Uchars [31018;]);
(`Uchars [38317;]);(`Uchars [39530;]);(`Uchars [40599;]);(`Uchars [40654;]);
(`Uchars [21147;]);(`Uchars [26310;]);(`Uchars [27511;]);(`Uchars [36706;]);
(`Uchars [24180;]);(`Uchars [24976;]);|];[|(`Uchars [25088;]);
(`Uchars [25754;]);(`Uchars [28451;]);(`Uchars [29001;]);(`Uchars [29833;]);
(`Uchars [31178;]);(`Uchars [32244;]);(`Uchars [32879;]);(`Uchars [36646;]);
(`Uchars [34030;]);(`Uchars [36899;]);(`Uchars [37706;]);(`Uchars [21015;]);
(`Uchars [21155;]);(`Uchars [21693;]);(`Uchars [28872;]);|];[|
(`Uchars [35010;]);(`Uchars [35498;]);(`Uchars [24265;]);(`Uchars [24565;]);
(`Uchars [25467;]);(`Uchars [27566;]);(`Uchars [31806;]);(`Uchars [29557;]);
(`Uchars [20196;]);(`Uchars [22265;]);(`Uchars [23527;]);(`Uchars [23994;]);
(`Uchars [24604;]);(`Uchars [29618;]);(`Uchars [29801;]);(`Uchars [32666;]);
|];[|(`Uchars [32838;]);(`Uchars [37428;]);(`Uchars [38646;]);
(`Uchars [38728;]);(`Uchars [38936;]);(`Uchars [20363;]);(`Uchars [31150;]);
(`Uchars [37300;]);(`Uchars [38584;]);(`Uchars [24801;]);(`Uchars [20102;]);
(`Uchars [20698;]);(`Uchars [23534;]);(`Uchars [23615;]);(`Uchars [26009;]);
(`Uchars [27138;]);|];[|(`Uchars [29134;]);(`Uchars [30274;]);
(`Uchars [34044;]);(`Uchars [36988;]);(`Uchars [40845;]);(`Uchars [26248;]);
(`Uchars [38446;]);(`Uchars [21129;]);(`Uchars [26491;]);(`Uchars [26611;]);
(`Uchars [27969;]);(`Uchars [28316;]);(`Uchars [29705;]);(`Uchars [30041;]);
(`Uchars [30827;]);(`Uchars [32016;]);|];[|(`Uchars [39006;]);
(`Uchars [20845;]);(`Uchars [25134;]);(`Uchars [38520;]);(`Uchars [20523;]);
(`Uchars [23833;]);(`Uchars [28138;]);(`Uchars [36650;]);(`Uchars [24459;]);
(`Uchars [24900;]);(`Uchars [26647;]);(`Uchars [29575;]);(`Uchars [38534;]);
(`Uchars [21033;]);(`Uchars [21519;]);(`Uchars [23653;]);|];[|
(`Uchars [26131;]);(`Uchars [26446;]);(`Uchars [26792;]);(`Uchars [27877;]);
(`Uchars [29702;]);(`Uchars [30178;]);(`Uchars [32633;]);(`Uchars [35023;]);
(`Uchars [35041;]);(`Uchars [37324;]);(`Uchars [38626;]);(`Uchars [21311;]);
(`Uchars [28346;]);(`Uchars [21533;]);(`Uchars [29136;]);(`Uchars [29848;]);
|];[|(`Uchars [34298;]);(`Uchars [38563;]);(`Uchars [40023;]);
(`Uchars [40607;]);(`Uchars [26519;]);(`Uchars [28107;]);(`Uchars [33256;]);
(`Uchars [31435;]);(`Uchars [31520;]);(`Uchars [31890;]);(`Uchars [29376;]);
(`Uchars [28825;]);(`Uchars [35672;]);(`Uchars [20160;]);(`Uchars [33590;]);
(`Uchars [21050;]);|];[|(`Uchars [20999;]);(`Uchars [24230;]);
(`Uchars [25299;]);(`Uchars [31958;]);(`Uchars [23429;]);(`Uchars [27934;]);
(`Uchars [26292;]);(`Uchars [36667;]);(`Uchars [34892;]);(`Uchars [38477;]);
(`Uchars [35211;]);(`Uchars [24275;]);(`Uchars [20800;]);(`Uchars [21952;]);
`Self;`Self;|];[|(`Uchars [22618;]);`Self;(`Uchars [26228;]);`Self;`Self;
(`Uchars [20958;]);(`Uchars [29482;]);(`Uchars [30410;]);(`Uchars [31036;]);
(`Uchars [31070;]);(`Uchars [31077;]);(`Uchars [31119;]);(`Uchars [38742;]);
(`Uchars [31934;]);(`Uchars [32701;]);`Self;|];[|(`Uchars [34322;]);`Self;
(`Uchars [35576;]);`Self;`Self;(`Uchars [36920;]);(`Uchars [37117;]);`Self;
`Self;`Self;(`Uchars [39151;]);(`Uchars [39164;]);(`Uchars [39208;]);
(`Uchars [40372;]);(`Uchars [37086;]);(`Uchars [38583;]);|];[|
(`Uchars [20398;]);(`Uchars [20711;]);(`Uchars [20813;]);(`Uchars [21193;]);
(`Uchars [21220;]);(`Uchars [21329;]);(`Uchars [21917;]);(`Uchars [22022;]);
(`Uchars [22120;]);(`Uchars [22592;]);(`Uchars [22696;]);(`Uchars [23652;]);
(`Uchars [23662;]);(`Uchars [24724;]);(`Uchars [24936;]);(`Uchars [24974;]);
|];[|(`Uchars [25074;]);(`Uchars [25935;]);(`Uchars [26082;]);
(`Uchars [26257;]);(`Uchars [26757;]);(`Uchars [28023;]);(`Uchars [28186;]);
(`Uchars [28450;]);(`Uchars [29038;]);(`Uchars [29227;]);(`Uchars [29730;]);
(`Uchars [30865;]);(`Uchars [31038;]);(`Uchars [31049;]);(`Uchars [31048;]);
(`Uchars [31056;]);|];[|(`Uchars [31062;]);(`Uchars [31069;]);
(`Uchars [31117;]);(`Uchars [31118;]);(`Uchars [31296;]);(`Uchars [31361;]);
(`Uchars [31680;]);(`Uchars [32244;]);(`Uchars [32265;]);(`Uchars [32321;]);
(`Uchars [32626;]);(`Uchars [32773;]);(`Uchars [33261;]);(`Uchars [33401;]);
(`Uchars [33401;]);(`Uchars [33879;]);|];[|(`Uchars [35088;]);
(`Uchars [35222;]);(`Uchars [35585;]);(`Uchars [35641;]);(`Uchars [36051;]);
(`Uchars [36104;]);(`Uchars [36790;]);(`Uchars [36920;]);(`Uchars [38627;]);
(`Uchars [38911;]);(`Uchars [38971;]);(`Uchars [24693;]);(`Uchars [148206;]);
(`Uchars [33304;]);`Self;`Self;|];[|(`Uchars [20006;]);(`Uchars [20917;]);
(`Uchars [20840;]);(`Uchars [20352;]);(`Uchars [20805;]);(`Uchars [20864;]);
(`Uchars [21191;]);(`Uchars [21242;]);(`Uchars [21917;]);(`Uchars [21845;]);
(`Uchars [21913;]);(`Uchars [21986;]);(`Uchars [22618;]);(`Uchars [22707;]);
(`Uchars [22852;]);(`Uchars [22868;]);|];[|(`Uchars [23138;]);
(`Uchars [23336;]);(`Uchars [24274;]);(`Uchars [24281;]);(`Uchars [24425;]);
(`Uchars [24493;]);(`Uchars [24792;]);(`Uchars [24910;]);(`Uchars [24840;]);
(`Uchars [24974;]);(`Uchars [24928;]);(`Uchars [25074;]);(`Uchars [25140;]);
(`Uchars [25540;]);(`Uchars [25628;]);(`Uchars [25682;]);|];[|
(`Uchars [25942;]);(`Uchars [26228;]);(`Uchars [26391;]);(`Uchars [26395;]);
(`Uchars [26454;]);(`Uchars [27513;]);(`Uchars [27578;]);(`Uchars [27969;]);
(`Uchars [28379;]);(`Uchars [28363;]);(`Uchars [28450;]);(`Uchars [28702;]);
(`Uchars [29038;]);(`Uchars [30631;]);(`Uchars [29237;]);(`Uchars [29359;]);
|];[|(`Uchars [29482;]);(`Uchars [29809;]);(`Uchars [29958;]);
(`Uchars [30011;]);(`Uchars [30237;]);(`Uchars [30239;]);(`Uchars [30410;]);
(`Uchars [30427;]);(`Uchars [30452;]);(`Uchars [30538;]);(`Uchars [30528;]);
(`Uchars [30924;]);(`Uchars [31409;]);(`Uchars [31680;]);(`Uchars [31867;]);
(`Uchars [32091;]);|];[|(`Uchars [32244;]);(`Uchars [32574;]);
(`Uchars [32773;]);(`Uchars [33618;]);(`Uchars [33775;]);(`Uchars [34681;]);
(`Uchars [35137;]);(`Uchars [35206;]);(`Uchars [35222;]);(`Uchars [35519;]);
(`Uchars [35576;]);(`Uchars [35531;]);(`Uchars [35585;]);(`Uchars [35582;]);
(`Uchars [35565;]);(`Uchars [35641;]);|];[|(`Uchars [35722;]);
(`Uchars [36104;]);(`Uchars [36664;]);(`Uchars [36978;]);(`Uchars [37273;]);
(`Uchars [37494;]);(`Uchars [38524;]);(`Uchars [38627;]);(`Uchars [38742;]);
(`Uchars [38875;]);(`Uchars [38911;]);(`Uchars [38923;]);(`Uchars [38971;]);
(`Uchars [39698;]);(`Uchars [40860;]);(`Uchars [141386;]);|];[|
(`Uchars [141380;]);(`Uchars [144341;]);(`Uchars [15261;]);
(`Uchars [16408;]);(`Uchars [16441;]);(`Uchars [152137;]);
(`Uchars [154832;]);(`Uchars [163539;]);(`Uchars [40771;]);
(`Uchars [40846;]);`Self;`Self;`Self;`Self;`Self;`Self;|];nil;nil;[|
(`Uchars [102;102;]);(`Uchars [102;105;]);(`Uchars [102;108;]);
(`Uchars [102;102;105;]);(`Uchars [102;102;108;]);(`Uchars [115;116;]);
(`Uchars [115;116;]);`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
|];[|`Self;`Self;`Self;(`Uchars [1396;1398;]);(`Uchars [1396;1381;]);
(`Uchars [1396;1387;]);(`Uchars [1406;1398;]);(`Uchars [1396;1389;]);`Self;
`Self;`Self;`Self;`Self;(`Uchars [1497;1460;]);`Self;(`Uchars [1522;1463;]);
|];[|(`Uchars [1506;]);(`Uchars [1488;]);(`Uchars [1491;]);(`Uchars [1492;]);
(`Uchars [1499;]);(`Uchars [1500;]);(`Uchars [1501;]);(`Uchars [1512;]);
(`Uchars [1514;]);(`Uchars [43;]);(`Uchars [1513;1473;]);
(`Uchars [1513;1474;]);(`Uchars [1513;1468;1473;]);
(`Uchars [1513;1468;1474;]);(`Uchars [1488;1463;]);(`Uchars [1488;1464;]);|];
[|(`Uchars [1488;1468;]);(`Uchars [1489;1468;]);(`Uchars [1490;1468;]);
(`Uchars [1491;1468;]);(`Uchars [1492;1468;]);(`Uchars [1493;1468;]);
(`Uchars [1494;1468;]);`Self;(`Uchars [1496;1468;]);(`Uchars [1497;1468;]);
(`Uchars [1498;1468;]);(`Uchars [1499;1468;]);(`Uchars [1500;1468;]);`Self;
(`Uchars [1502;1468;]);`Self;|];[|(`Uchars [1504;1468;]);
(`Uchars [1505;1468;]);`Self;(`Uchars [1507;1468;]);(`Uchars [1508;1468;]);
`Self;(`Uchars [1510;1468;]);(`Uchars [1511;1468;]);(`Uchars [1512;1468;]);
(`Uchars [1513;1468;]);(`Uchars [1514;1468;]);(`Uchars [1493;1465;]);
(`Uchars [1489;1471;]);(`Uchars [1499;1471;]);(`Uchars [1508;1471;]);
(`Uchars [1488;1500;]);|];[|(`Uchars [1649;]);(`Uchars [1649;]);
(`Uchars [1659;]);(`Uchars [1659;]);(`Uchars [1659;]);(`Uchars [1659;]);
(`Uchars [1662;]);(`Uchars [1662;]);(`Uchars [1662;]);(`Uchars [1662;]);
(`Uchars [1664;]);(`Uchars [1664;]);(`Uchars [1664;]);(`Uchars [1664;]);
(`Uchars [1658;]);(`Uchars [1658;]);|];[|(`Uchars [1658;]);(`Uchars [1658;]);
(`Uchars [1663;]);(`Uchars [1663;]);(`Uchars [1663;]);(`Uchars [1663;]);
(`Uchars [1657;]);(`Uchars [1657;]);(`Uchars [1657;]);(`Uchars [1657;]);
(`Uchars [1700;]);(`Uchars [1700;]);(`Uchars [1700;]);(`Uchars [1700;]);
(`Uchars [1702;]);(`Uchars [1702;]);|];[|(`Uchars [1702;]);(`Uchars [1702;]);
(`Uchars [1668;]);(`Uchars [1668;]);(`Uchars [1668;]);(`Uchars [1668;]);
(`Uchars [1667;]);(`Uchars [1667;]);(`Uchars [1667;]);(`Uchars [1667;]);
(`Uchars [1670;]);(`Uchars [1670;]);(`Uchars [1670;]);(`Uchars [1670;]);
(`Uchars [1671;]);(`Uchars [1671;]);|];[|(`Uchars [1671;]);(`Uchars [1671;]);
(`Uchars [1677;]);(`Uchars [1677;]);(`Uchars [1676;]);(`Uchars [1676;]);
(`Uchars [1678;]);(`Uchars [1678;]);(`Uchars [1672;]);(`Uchars [1672;]);
(`Uchars [1688;]);(`Uchars [1688;]);(`Uchars [1681;]);(`Uchars [1681;]);
(`Uchars [1705;]);(`Uchars [1705;]);|];[|(`Uchars [1705;]);(`Uchars [1705;]);
(`Uchars [1711;]);(`Uchars [1711;]);(`Uchars [1711;]);(`Uchars [1711;]);
(`Uchars [1715;]);(`Uchars [1715;]);(`Uchars [1715;]);(`Uchars [1715;]);
(`Uchars [1713;]);(`Uchars [1713;]);(`Uchars [1713;]);(`Uchars [1713;]);
(`Uchars [1722;]);(`Uchars [1722;]);|];[|(`Uchars [1723;]);(`Uchars [1723;]);
(`Uchars [1723;]);(`Uchars [1723;]);(`Uchars [1728;]);(`Uchars [1728;]);
(`Uchars [1729;]);(`Uchars [1729;]);(`Uchars [1729;]);(`Uchars [1729;]);
(`Uchars [1726;]);(`Uchars [1726;]);(`Uchars [1726;]);(`Uchars [1726;]);
(`Uchars [1746;]);(`Uchars [1746;]);|];[|(`Uchars [1747;]);(`Uchars [1747;]);
`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;|];nil;[|`Self;`Self;`Self;(`Uchars [1709;]);(`Uchars [1709;]);
(`Uchars [1709;]);(`Uchars [1709;]);(`Uchars [1735;]);(`Uchars [1735;]);
(`Uchars [1734;]);(`Uchars [1734;]);(`Uchars [1736;]);(`Uchars [1736;]);
(`Uchars [1735;1652;]);(`Uchars [1739;]);(`Uchars [1739;]);|];[|
(`Uchars [1733;]);(`Uchars [1733;]);(`Uchars [1737;]);(`Uchars [1737;]);
(`Uchars [1744;]);(`Uchars [1744;]);(`Uchars [1744;]);(`Uchars [1744;]);
(`Uchars [1609;]);(`Uchars [1609;]);(`Uchars [1574;1575;]);
(`Uchars [1574;1575;]);(`Uchars [1574;1749;]);(`Uchars [1574;1749;]);
(`Uchars [1574;1608;]);(`Uchars [1574;1608;]);|];[|(`Uchars [1574;1735;]);
(`Uchars [1574;1735;]);(`Uchars [1574;1734;]);(`Uchars [1574;1734;]);
(`Uchars [1574;1736;]);(`Uchars [1574;1736;]);(`Uchars [1574;1744;]);
(`Uchars [1574;1744;]);(`Uchars [1574;1744;]);(`Uchars [1574;1609;]);
(`Uchars [1574;1609;]);(`Uchars [1574;1609;]);(`Uchars [1740;]);
(`Uchars [1740;]);(`Uchars [1740;]);(`Uchars [1740;]);|];[|
(`Uchars [1574;1580;]);(`Uchars [1574;1581;]);(`Uchars [1574;1605;]);
(`Uchars [1574;1609;]);(`Uchars [1574;1610;]);(`Uchars [1576;1580;]);
(`Uchars [1576;1581;]);(`Uchars [1576;1582;]);(`Uchars [1576;1605;]);
(`Uchars [1576;1609;]);(`Uchars [1576;1610;]);(`Uchars [1578;1580;]);
(`Uchars [1578;1581;]);(`Uchars [1578;1582;]);(`Uchars [1578;1605;]);
(`Uchars [1578;1609;]);|];[|(`Uchars [1578;1610;]);(`Uchars [1579;1580;]);
(`Uchars [1579;1605;]);(`Uchars [1579;1609;]);(`Uchars [1579;1610;]);
(`Uchars [1580;1581;]);(`Uchars [1580;1605;]);(`Uchars [1581;1580;]);
(`Uchars [1581;1605;]);(`Uchars [1582;1580;]);(`Uchars [1582;1581;]);
(`Uchars [1582;1605;]);(`Uchars [1587;1580;]);(`Uchars [1587;1581;]);
(`Uchars [1587;1582;]);(`Uchars [1587;1605;]);|];[|(`Uchars [1589;1581;]);
(`Uchars [1589;1605;]);(`Uchars [1590;1580;]);(`Uchars [1590;1581;]);
(`Uchars [1590;1582;]);(`Uchars [1590;1605;]);(`Uchars [1591;1581;]);
(`Uchars [1591;1605;]);(`Uchars [1592;1605;]);(`Uchars [1593;1580;]);
(`Uchars [1593;1605;]);(`Uchars [1594;1580;]);(`Uchars [1594;1605;]);
(`Uchars [1601;1580;]);(`Uchars [1601;1581;]);(`Uchars [1601;1582;]);|];[|
(`Uchars [1601;1605;]);(`Uchars [1601;1609;]);(`Uchars [1601;1610;]);
(`Uchars [1602;1581;]);(`Uchars [1602;1605;]);(`Uchars [1602;1609;]);
(`Uchars [1602;1610;]);(`Uchars [1603;1575;]);(`Uchars [1603;1580;]);
(`Uchars [1603;1581;]);(`Uchars [1603;1582;]);(`Uchars [1603;1604;]);
(`Uchars [1603;1605;]);(`Uchars [1603;1609;]);(`Uchars [1603;1610;]);
(`Uchars [1604;1580;]);|];[|(`Uchars [1604;1581;]);(`Uchars [1604;1582;]);
(`Uchars [1604;1605;]);(`Uchars [1604;1609;]);(`Uchars [1604;1610;]);
(`Uchars [1605;1580;]);(`Uchars [1605;1581;]);(`Uchars [1605;1582;]);
(`Uchars [1605;1605;]);(`Uchars [1605;1609;]);(`Uchars [1605;1610;]);
(`Uchars [1606;1580;]);(`Uchars [1606;1581;]);(`Uchars [1606;1582;]);
(`Uchars [1606;1605;]);(`Uchars [1606;1609;]);|];[|(`Uchars [1606;1610;]);
(`Uchars [1607;1580;]);(`Uchars [1607;1605;]);(`Uchars [1607;1609;]);
(`Uchars [1607;1610;]);(`Uchars [1610;1580;]);(`Uchars [1610;1581;]);
(`Uchars [1610;1582;]);(`Uchars [1610;1605;]);(`Uchars [1610;1609;]);
(`Uchars [1610;1610;]);(`Uchars [1584;1648;]);(`Uchars [1585;1648;]);
(`Uchars [1609;1648;]);(`Uchars [32;1612;1617;]);(`Uchars [32;1613;1617;]);
|];[|(`Uchars [32;1614;1617;]);(`Uchars [32;1615;1617;]);
(`Uchars [32;1616;1617;]);(`Uchars [32;1617;1648;]);(`Uchars [1574;1585;]);
(`Uchars [1574;1586;]);(`Uchars [1574;1605;]);(`Uchars [1574;1606;]);
(`Uchars [1574;1609;]);(`Uchars [1574;1610;]);(`Uchars [1576;1585;]);
(`Uchars [1576;1586;]);(`Uchars [1576;1605;]);(`Uchars [1576;1606;]);
(`Uchars [1576;1609;]);(`Uchars [1576;1610;]);|];[|(`Uchars [1578;1585;]);
(`Uchars [1578;1586;]);(`Uchars [1578;1605;]);(`Uchars [1578;1606;]);
(`Uchars [1578;1609;]);(`Uchars [1578;1610;]);(`Uchars [1579;1585;]);
(`Uchars [1579;1586;]);(`Uchars [1579;1605;]);(`Uchars [1579;1606;]);
(`Uchars [1579;1609;]);(`Uchars [1579;1610;]);(`Uchars [1601;1609;]);
(`Uchars [1601;1610;]);(`Uchars [1602;1609;]);(`Uchars [1602;1610;]);|];[|
(`Uchars [1603;1575;]);(`Uchars [1603;1604;]);(`Uchars [1603;1605;]);
(`Uchars [1603;1609;]);(`Uchars [1603;1610;]);(`Uchars [1604;1605;]);
(`Uchars [1604;1609;]);(`Uchars [1604;1610;]);(`Uchars [1605;1575;]);
(`Uchars [1605;1605;]);(`Uchars [1606;1585;]);(`Uchars [1606;1586;]);
(`Uchars [1606;1605;]);(`Uchars [1606;1606;]);(`Uchars [1606;1609;]);
(`Uchars [1606;1610;]);|];[|(`Uchars [1609;1648;]);(`Uchars [1610;1585;]);
(`Uchars [1610;1586;]);(`Uchars [1610;1605;]);(`Uchars [1610;1606;]);
(`Uchars [1610;1609;]);(`Uchars [1610;1610;]);(`Uchars [1574;1580;]);
(`Uchars [1574;1581;]);(`Uchars [1574;1582;]);(`Uchars [1574;1605;]);
(`Uchars [1574;1607;]);(`Uchars [1576;1580;]);(`Uchars [1576;1581;]);
(`Uchars [1576;1582;]);(`Uchars [1576;1605;]);|];[|(`Uchars [1576;1607;]);
(`Uchars [1578;1580;]);(`Uchars [1578;1581;]);(`Uchars [1578;1582;]);
(`Uchars [1578;1605;]);(`Uchars [1578;1607;]);(`Uchars [1579;1605;]);
(`Uchars [1580;1581;]);(`Uchars [1580;1605;]);(`Uchars [1581;1580;]);
(`Uchars [1581;1605;]);(`Uchars [1582;1580;]);(`Uchars [1582;1605;]);
(`Uchars [1587;1580;]);(`Uchars [1587;1581;]);(`Uchars [1587;1582;]);|];[|
(`Uchars [1587;1605;]);(`Uchars [1589;1581;]);(`Uchars [1589;1582;]);
(`Uchars [1589;1605;]);(`Uchars [1590;1580;]);(`Uchars [1590;1581;]);
(`Uchars [1590;1582;]);(`Uchars [1590;1605;]);(`Uchars [1591;1581;]);
(`Uchars [1592;1605;]);(`Uchars [1593;1580;]);(`Uchars [1593;1605;]);
(`Uchars [1594;1580;]);(`Uchars [1594;1605;]);(`Uchars [1601;1580;]);
(`Uchars [1601;1581;]);|];[|(`Uchars [1601;1582;]);(`Uchars [1601;1605;]);
(`Uchars [1602;1581;]);(`Uchars [1602;1605;]);(`Uchars [1603;1580;]);
(`Uchars [1603;1581;]);(`Uchars [1603;1582;]);(`Uchars [1603;1604;]);
(`Uchars [1603;1605;]);(`Uchars [1604;1580;]);(`Uchars [1604;1581;]);
(`Uchars [1604;1582;]);(`Uchars [1604;1605;]);(`Uchars [1604;1607;]);
(`Uchars [1605;1580;]);(`Uchars [1605;1581;]);|];[|(`Uchars [1605;1582;]);
(`Uchars [1605;1605;]);(`Uchars [1606;1580;]);(`Uchars [1606;1581;]);
(`Uchars [1606;1582;]);(`Uchars [1606;1605;]);(`Uchars [1606;1607;]);
(`Uchars [1607;1580;]);(`Uchars [1607;1605;]);(`Uchars [1607;1648;]);
(`Uchars [1610;1580;]);(`Uchars [1610;1581;]);(`Uchars [1610;1582;]);
(`Uchars [1610;1605;]);(`Uchars [1610;1607;]);(`Uchars [1574;1605;]);|];[|
(`Uchars [1574;1607;]);(`Uchars [1576;1605;]);(`Uchars [1576;1607;]);
(`Uchars [1578;1605;]);(`Uchars [1578;1607;]);(`Uchars [1579;1605;]);
(`Uchars [1579;1607;]);(`Uchars [1587;1605;]);(`Uchars [1587;1607;]);
(`Uchars [1588;1605;]);(`Uchars [1588;1607;]);(`Uchars [1603;1604;]);
(`Uchars [1603;1605;]);(`Uchars [1604;1605;]);(`Uchars [1606;1605;]);
(`Uchars [1606;1607;]);|];[|(`Uchars [1610;1605;]);(`Uchars [1610;1607;]);
(`Uchars [1600;1614;1617;]);(`Uchars [1600;1615;1617;]);
(`Uchars [1600;1616;1617;]);(`Uchars [1591;1609;]);(`Uchars [1591;1610;]);
(`Uchars [1593;1609;]);(`Uchars [1593;1610;]);(`Uchars [1594;1609;]);
(`Uchars [1594;1610;]);(`Uchars [1587;1609;]);(`Uchars [1587;1610;]);
(`Uchars [1588;1609;]);(`Uchars [1588;1610;]);(`Uchars [1581;1609;]);|];[|
(`Uchars [1581;1610;]);(`Uchars [1580;1609;]);(`Uchars [1580;1610;]);
(`Uchars [1582;1609;]);(`Uchars [1582;1610;]);(`Uchars [1589;1609;]);
(`Uchars [1589;1610;]);(`Uchars [1590;1609;]);(`Uchars [1590;1610;]);
(`Uchars [1588;1580;]);(`Uchars [1588;1581;]);(`Uchars [1588;1582;]);
(`Uchars [1588;1605;]);(`Uchars [1588;1585;]);(`Uchars [1587;1585;]);
(`Uchars [1589;1585;]);|];[|(`Uchars [1590;1585;]);(`Uchars [1591;1609;]);
(`Uchars [1591;1610;]);(`Uchars [1593;1609;]);(`Uchars [1593;1610;]);
(`Uchars [1594;1609;]);(`Uchars [1594;1610;]);(`Uchars [1587;1609;]);
(`Uchars [1587;1610;]);(`Uchars [1588;1609;]);(`Uchars [1588;1610;]);
(`Uchars [1581;1609;]);(`Uchars [1581;1610;]);(`Uchars [1580;1609;]);
(`Uchars [1580;1610;]);(`Uchars [1582;1609;]);|];[|(`Uchars [1582;1610;]);
(`Uchars [1589;1609;]);(`Uchars [1589;1610;]);(`Uchars [1590;1609;]);
(`Uchars [1590;1610;]);(`Uchars [1588;1580;]);(`Uchars [1588;1581;]);
(`Uchars [1588;1582;]);(`Uchars [1588;1605;]);(`Uchars [1588;1585;]);
(`Uchars [1587;1585;]);(`Uchars [1589;1585;]);(`Uchars [1590;1585;]);
(`Uchars [1588;1580;]);(`Uchars [1588;1581;]);(`Uchars [1588;1582;]);|];[|
(`Uchars [1588;1605;]);(`Uchars [1587;1607;]);(`Uchars [1588;1607;]);
(`Uchars [1591;1605;]);(`Uchars [1587;1580;]);(`Uchars [1587;1581;]);
(`Uchars [1587;1582;]);(`Uchars [1588;1580;]);(`Uchars [1588;1581;]);
(`Uchars [1588;1582;]);(`Uchars [1591;1605;]);(`Uchars [1592;1605;]);
(`Uchars [1575;1611;]);(`Uchars [1575;1611;]);`Self;`Self;|];nil;[|
(`Uchars [1578;1580;1605;]);(`Uchars [1578;1581;1580;]);
(`Uchars [1578;1581;1580;]);(`Uchars [1578;1581;1605;]);
(`Uchars [1578;1582;1605;]);(`Uchars [1578;1605;1580;]);
(`Uchars [1578;1605;1581;]);(`Uchars [1578;1605;1582;]);
(`Uchars [1580;1605;1581;]);(`Uchars [1580;1605;1581;]);
(`Uchars [1581;1605;1610;]);(`Uchars [1581;1605;1609;]);
(`Uchars [1587;1581;1580;]);(`Uchars [1587;1580;1581;]);
(`Uchars [1587;1580;1609;]);(`Uchars [1587;1605;1581;]);|];[|
(`Uchars [1587;1605;1581;]);(`Uchars [1587;1605;1580;]);
(`Uchars [1587;1605;1605;]);(`Uchars [1587;1605;1605;]);
(`Uchars [1589;1581;1581;]);(`Uchars [1589;1581;1581;]);
(`Uchars [1589;1605;1605;]);(`Uchars [1588;1581;1605;]);
(`Uchars [1588;1581;1605;]);(`Uchars [1588;1580;1610;]);
(`Uchars [1588;1605;1582;]);(`Uchars [1588;1605;1582;]);
(`Uchars [1588;1605;1605;]);(`Uchars [1588;1605;1605;]);
(`Uchars [1590;1581;1609;]);(`Uchars [1590;1582;1605;]);|];[|
(`Uchars [1590;1582;1605;]);(`Uchars [1591;1605;1581;]);
(`Uchars [1591;1605;1581;]);(`Uchars [1591;1605;1605;]);
(`Uchars [1591;1605;1610;]);(`Uchars [1593;1580;1605;]);
(`Uchars [1593;1605;1605;]);(`Uchars [1593;1605;1605;]);
(`Uchars [1593;1605;1609;]);(`Uchars [1594;1605;1605;]);
(`Uchars [1594;1605;1610;]);(`Uchars [1594;1605;1609;]);
(`Uchars [1601;1582;1605;]);(`Uchars [1601;1582;1605;]);
(`Uchars [1602;1605;1581;]);(`Uchars [1602;1605;1605;]);|];[|
(`Uchars [1604;1581;1605;]);(`Uchars [1604;1581;1610;]);
(`Uchars [1604;1581;1609;]);(`Uchars [1604;1580;1580;]);
(`Uchars [1604;1580;1580;]);(`Uchars [1604;1582;1605;]);
(`Uchars [1604;1582;1605;]);(`Uchars [1604;1605;1581;]);
(`Uchars [1604;1605;1581;]);(`Uchars [1605;1581;1580;]);
(`Uchars [1605;1581;1605;]);(`Uchars [1605;1581;1610;]);
(`Uchars [1605;1580;1581;]);(`Uchars [1605;1580;1605;]);
(`Uchars [1605;1582;1580;]);(`Uchars [1605;1582;1605;]);|];[|`Self;`Self;
(`Uchars [1605;1580;1582;]);(`Uchars [1607;1605;1580;]);
(`Uchars [1607;1605;1605;]);(`Uchars [1606;1581;1605;]);
(`Uchars [1606;1581;1609;]);(`Uchars [1606;1580;1605;]);
(`Uchars [1606;1580;1605;]);(`Uchars [1606;1580;1609;]);
(`Uchars [1606;1605;1610;]);(`Uchars [1606;1605;1609;]);
(`Uchars [1610;1605;1605;]);(`Uchars [1610;1605;1605;]);
(`Uchars [1576;1582;1610;]);(`Uchars [1578;1580;1610;]);|];[|
(`Uchars [1578;1580;1609;]);(`Uchars [1578;1582;1610;]);
(`Uchars [1578;1582;1609;]);(`Uchars [1578;1605;1610;]);
(`Uchars [1578;1605;1609;]);(`Uchars [1580;1605;1610;]);
(`Uchars [1580;1581;1609;]);(`Uchars [1580;1605;1609;]);
(`Uchars [1587;1582;1609;]);(`Uchars [1589;1581;1610;]);
(`Uchars [1588;1581;1610;]);(`Uchars [1590;1581;1610;]);
(`Uchars [1604;1580;1610;]);(`Uchars [1604;1605;1610;]);
(`Uchars [1610;1581;1610;]);(`Uchars [1610;1580;1610;]);|];[|
(`Uchars [1610;1605;1610;]);(`Uchars [1605;1605;1610;]);
(`Uchars [1602;1605;1610;]);(`Uchars [1606;1581;1610;]);
(`Uchars [1602;1605;1581;]);(`Uchars [1604;1581;1605;]);
(`Uchars [1593;1605;1610;]);(`Uchars [1603;1605;1610;]);
(`Uchars [1606;1580;1581;]);(`Uchars [1605;1582;1610;]);
(`Uchars [1604;1580;1605;]);(`Uchars [1603;1605;1605;]);
(`Uchars [1604;1580;1605;]);(`Uchars [1606;1580;1581;]);
(`Uchars [1580;1581;1610;]);(`Uchars [1581;1580;1610;]);|];[|
(`Uchars [1605;1580;1610;]);(`Uchars [1601;1605;1610;]);
(`Uchars [1576;1581;1610;]);(`Uchars [1603;1605;1605;]);
(`Uchars [1593;1580;1605;]);(`Uchars [1589;1605;1605;]);
(`Uchars [1587;1582;1610;]);(`Uchars [1606;1580;1610;]);`Self;`Self;`Self;
`Self;`Self;`Self;`Self;`Self;|];nil;nil;[|(`Uchars [1589;1604;1746;]);
(`Uchars [1602;1604;1746;]);(`Uchars [1575;1604;1604;1607;]);
(`Uchars [1575;1603;1576;1585;]);(`Uchars [1605;1581;1605;1583;]);
(`Uchars [1589;1604;1593;1605;]);(`Uchars [1585;1587;1608;1604;]);
(`Uchars [1593;1604;1610;1607;]);(`Uchars [1608;1587;1604;1605;]);
(`Uchars [1589;1604;1609;]);
(`Uchars
 [1589;1604;1609;32;1575;1604;1604;1607;32;1593;1604;1610;1607;32;1608;
  1587;1604;1605;]);
(`Uchars [1580;1604;32;1580;1604;1575;1604;1607;]);
(`Uchars [1585;1740;1575;1604;]);`Self;`Self;`Self;|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars [44;]);(`Uchars [12289;]);(`Uchars [12290;]);(`Uchars [58;]);
(`Uchars [59;]);(`Uchars [33;]);(`Uchars [63;]);(`Uchars [12310;]);
(`Uchars [12311;]);(`Uchars [46;46;46;]);`Self;`Self;`Self;`Self;`Self;`Self;
|];nil;[|(`Uchars [46;46;]);(`Uchars [8212;]);(`Uchars [8211;]);
(`Uchars [95;]);(`Uchars [95;]);(`Uchars [40;]);(`Uchars [41;]);
(`Uchars [123;]);(`Uchars [125;]);(`Uchars [12308;]);(`Uchars [12309;]);
(`Uchars [12304;]);(`Uchars [12305;]);(`Uchars [12298;]);(`Uchars [12299;]);
(`Uchars [12296;]);|];[|(`Uchars [12297;]);(`Uchars [12300;]);
(`Uchars [12301;]);(`Uchars [12302;]);(`Uchars [12303;]);`Self;`Self;
(`Uchars [91;]);(`Uchars [93;]);(`Uchars [32;773;]);(`Uchars [32;773;]);
(`Uchars [32;773;]);(`Uchars [32;773;]);(`Uchars [95;]);(`Uchars [95;]);
(`Uchars [95;]);|];[|(`Uchars [44;]);(`Uchars [12289;]);(`Uchars [46;]);
`Self;(`Uchars [59;]);(`Uchars [58;]);(`Uchars [63;]);(`Uchars [33;]);
(`Uchars [8212;]);(`Uchars [40;]);(`Uchars [41;]);(`Uchars [123;]);
(`Uchars [125;]);(`Uchars [12308;]);(`Uchars [12309;]);(`Uchars [35;]);|];[|
(`Uchars [38;]);(`Uchars [42;]);(`Uchars [43;]);(`Uchars [45;]);
(`Uchars [60;]);(`Uchars [62;]);(`Uchars [61;]);`Self;(`Uchars [92;]);
(`Uchars [36;]);(`Uchars [37;]);(`Uchars [64;]);`Self;`Self;`Self;`Self;|];[|
(`Uchars [32;1611;]);(`Uchars [1600;1611;]);(`Uchars [32;1612;]);`Self;
(`Uchars [32;1613;]);`Self;(`Uchars [32;1614;]);(`Uchars [1600;1614;]);
(`Uchars [32;1615;]);(`Uchars [1600;1615;]);(`Uchars [32;1616;]);
(`Uchars [1600;1616;]);(`Uchars [32;1617;]);(`Uchars [1600;1617;]);
(`Uchars [32;1618;]);(`Uchars [1600;1618;]);|];[|(`Uchars [1569;]);
(`Uchars [1570;]);(`Uchars [1570;]);(`Uchars [1571;]);(`Uchars [1571;]);
(`Uchars [1572;]);(`Uchars [1572;]);(`Uchars [1573;]);(`Uchars [1573;]);
(`Uchars [1574;]);(`Uchars [1574;]);(`Uchars [1574;]);(`Uchars [1574;]);
(`Uchars [1575;]);(`Uchars [1575;]);(`Uchars [1576;]);|];[|(`Uchars [1576;]);
(`Uchars [1576;]);(`Uchars [1576;]);(`Uchars [1577;]);(`Uchars [1577;]);
(`Uchars [1578;]);(`Uchars [1578;]);(`Uchars [1578;]);(`Uchars [1578;]);
(`Uchars [1579;]);(`Uchars [1579;]);(`Uchars [1579;]);(`Uchars [1579;]);
(`Uchars [1580;]);(`Uchars [1580;]);(`Uchars [1580;]);|];[|(`Uchars [1580;]);
(`Uchars [1581;]);(`Uchars [1581;]);(`Uchars [1581;]);(`Uchars [1581;]);
(`Uchars [1582;]);(`Uchars [1582;]);(`Uchars [1582;]);(`Uchars [1582;]);
(`Uchars [1583;]);(`Uchars [1583;]);(`Uchars [1584;]);(`Uchars [1584;]);
(`Uchars [1585;]);(`Uchars [1585;]);(`Uchars [1586;]);|];[|(`Uchars [1586;]);
(`Uchars [1587;]);(`Uchars [1587;]);(`Uchars [1587;]);(`Uchars [1587;]);
(`Uchars [1588;]);(`Uchars [1588;]);(`Uchars [1588;]);(`Uchars [1588;]);
(`Uchars [1589;]);(`Uchars [1589;]);(`Uchars [1589;]);(`Uchars [1589;]);
(`Uchars [1590;]);(`Uchars [1590;]);(`Uchars [1590;]);|];[|(`Uchars [1590;]);
(`Uchars [1591;]);(`Uchars [1591;]);(`Uchars [1591;]);(`Uchars [1591;]);
(`Uchars [1592;]);(`Uchars [1592;]);(`Uchars [1592;]);(`Uchars [1592;]);
(`Uchars [1593;]);(`Uchars [1593;]);(`Uchars [1593;]);(`Uchars [1593;]);
(`Uchars [1594;]);(`Uchars [1594;]);(`Uchars [1594;]);|];[|(`Uchars [1594;]);
(`Uchars [1601;]);(`Uchars [1601;]);(`Uchars [1601;]);(`Uchars [1601;]);
(`Uchars [1602;]);(`Uchars [1602;]);(`Uchars [1602;]);(`Uchars [1602;]);
(`Uchars [1603;]);(`Uchars [1603;]);(`Uchars [1603;]);(`Uchars [1603;]);
(`Uchars [1604;]);(`Uchars [1604;]);(`Uchars [1604;]);|];[|(`Uchars [1604;]);
(`Uchars [1605;]);(`Uchars [1605;]);(`Uchars [1605;]);(`Uchars [1605;]);
(`Uchars [1606;]);(`Uchars [1606;]);(`Uchars [1606;]);(`Uchars [1606;]);
(`Uchars [1607;]);(`Uchars [1607;]);(`Uchars [1607;]);(`Uchars [1607;]);
(`Uchars [1608;]);(`Uchars [1608;]);(`Uchars [1609;]);|];[|(`Uchars [1609;]);
(`Uchars [1610;]);(`Uchars [1610;]);(`Uchars [1610;]);(`Uchars [1610;]);
(`Uchars [1604;1570;]);(`Uchars [1604;1570;]);(`Uchars [1604;1571;]);
(`Uchars [1604;1571;]);(`Uchars [1604;1573;]);(`Uchars [1604;1573;]);
(`Uchars [1604;1575;]);(`Uchars [1604;1575;]);`Self;`Self;(`Uchars []);|];[|
`Self;(`Uchars [33;]);(`Uchars [34;]);(`Uchars [35;]);(`Uchars [36;]);
(`Uchars [37;]);(`Uchars [38;]);(`Uchars [39;]);(`Uchars [40;]);
(`Uchars [41;]);(`Uchars [42;]);(`Uchars [43;]);(`Uchars [44;]);
(`Uchars [45;]);(`Uchars [46;]);(`Uchars [47;]);|];[|(`Uchars [48;]);
(`Uchars [49;]);(`Uchars [50;]);(`Uchars [51;]);(`Uchars [52;]);
(`Uchars [53;]);(`Uchars [54;]);(`Uchars [55;]);(`Uchars [56;]);
(`Uchars [57;]);(`Uchars [58;]);(`Uchars [59;]);(`Uchars [60;]);
(`Uchars [61;]);(`Uchars [62;]);(`Uchars [63;]);|];[|(`Uchars [64;]);
(`Uchars [97;]);(`Uchars [98;]);(`Uchars [99;]);(`Uchars [100;]);
(`Uchars [101;]);(`Uchars [102;]);(`Uchars [103;]);(`Uchars [104;]);
(`Uchars [105;]);(`Uchars [106;]);(`Uchars [107;]);(`Uchars [108;]);
(`Uchars [109;]);(`Uchars [110;]);(`Uchars [111;]);|];[|(`Uchars [112;]);
(`Uchars [113;]);(`Uchars [114;]);(`Uchars [115;]);(`Uchars [116;]);
(`Uchars [117;]);(`Uchars [118;]);(`Uchars [119;]);(`Uchars [120;]);
(`Uchars [121;]);(`Uchars [122;]);(`Uchars [91;]);(`Uchars [92;]);
(`Uchars [93;]);(`Uchars [94;]);(`Uchars [95;]);|];[|(`Uchars [96;]);
(`Uchars [97;]);(`Uchars [98;]);(`Uchars [99;]);(`Uchars [100;]);
(`Uchars [101;]);(`Uchars [102;]);(`Uchars [103;]);(`Uchars [104;]);
(`Uchars [105;]);(`Uchars [106;]);(`Uchars [107;]);(`Uchars [108;]);
(`Uchars [109;]);(`Uchars [110;]);(`Uchars [111;]);|];[|(`Uchars [112;]);
(`Uchars [113;]);(`Uchars [114;]);(`Uchars [115;]);(`Uchars [116;]);
(`Uchars [117;]);(`Uchars [118;]);(`Uchars [119;]);(`Uchars [120;]);
(`Uchars [121;]);(`Uchars [122;]);(`Uchars [123;]);(`Uchars [124;]);
(`Uchars [125;]);(`Uchars [126;]);(`Uchars [10629;]);|];[|(`Uchars [10630;]);
(`Uchars [12290;]);(`Uchars [12300;]);(`Uchars [12301;]);(`Uchars [12289;]);
(`Uchars [12539;]);(`Uchars [12530;]);(`Uchars [12449;]);(`Uchars [12451;]);
(`Uchars [12453;]);(`Uchars [12455;]);(`Uchars [12457;]);(`Uchars [12515;]);
(`Uchars [12517;]);(`Uchars [12519;]);(`Uchars [12483;]);|];[|
(`Uchars [12540;]);(`Uchars [12450;]);(`Uchars [12452;]);(`Uchars [12454;]);
(`Uchars [12456;]);(`Uchars [12458;]);(`Uchars [12459;]);(`Uchars [12461;]);
(`Uchars [12463;]);(`Uchars [12465;]);(`Uchars [12467;]);(`Uchars [12469;]);
(`Uchars [12471;]);(`Uchars [12473;]);(`Uchars [12475;]);(`Uchars [12477;]);
|];[|(`Uchars [12479;]);(`Uchars [12481;]);(`Uchars [12484;]);
(`Uchars [12486;]);(`Uchars [12488;]);(`Uchars [12490;]);(`Uchars [12491;]);
(`Uchars [12492;]);(`Uchars [12493;]);(`Uchars [12494;]);(`Uchars [12495;]);
(`Uchars [12498;]);(`Uchars [12501;]);(`Uchars [12504;]);(`Uchars [12507;]);
(`Uchars [12510;]);|];[|(`Uchars [12511;]);(`Uchars [12512;]);
(`Uchars [12513;]);(`Uchars [12514;]);(`Uchars [12516;]);(`Uchars [12518;]);
(`Uchars [12520;]);(`Uchars [12521;]);(`Uchars [12522;]);(`Uchars [12523;]);
(`Uchars [12524;]);(`Uchars [12525;]);(`Uchars [12527;]);(`Uchars [12531;]);
(`Uchars [12441;]);(`Uchars [12442;]);|];[|(`Uchars []);(`Uchars [4352;]);
(`Uchars [4353;]);(`Uchars [4522;]);(`Uchars [4354;]);(`Uchars [4524;]);
(`Uchars [4525;]);(`Uchars [4355;]);(`Uchars [4356;]);(`Uchars [4357;]);
(`Uchars [4528;]);(`Uchars [4529;]);(`Uchars [4530;]);(`Uchars [4531;]);
(`Uchars [4532;]);(`Uchars [4533;]);|];[|(`Uchars [4378;]);(`Uchars [4358;]);
(`Uchars [4359;]);(`Uchars [4360;]);(`Uchars [4385;]);(`Uchars [4361;]);
(`Uchars [4362;]);(`Uchars [4363;]);(`Uchars [4364;]);(`Uchars [4365;]);
(`Uchars [4366;]);(`Uchars [4367;]);(`Uchars [4368;]);(`Uchars [4369;]);
(`Uchars [4370;]);`Self;|];[|`Self;`Self;(`Uchars [4449;]);(`Uchars [4450;]);
(`Uchars [4451;]);(`Uchars [4452;]);(`Uchars [4453;]);(`Uchars [4454;]);
`Self;`Self;(`Uchars [4455;]);(`Uchars [4456;]);(`Uchars [4457;]);
(`Uchars [4458;]);(`Uchars [4459;]);(`Uchars [4460;]);|];[|`Self;`Self;
(`Uchars [4461;]);(`Uchars [4462;]);(`Uchars [4463;]);(`Uchars [4464;]);
(`Uchars [4465;]);(`Uchars [4466;]);`Self;`Self;(`Uchars [4467;]);
(`Uchars [4468;]);(`Uchars [4469;]);`Self;`Self;`Self;|];[|(`Uchars [162;]);
(`Uchars [163;]);(`Uchars [172;]);(`Uchars [32;772;]);(`Uchars [166;]);
(`Uchars [165;]);(`Uchars [8361;]);`Self;(`Uchars [9474;]);(`Uchars [8592;]);
(`Uchars [8593;]);(`Uchars [8594;]);(`Uchars [8595;]);(`Uchars [9632;]);
(`Uchars [9675;]);`Self;|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);`Self;`Self;`Self;`Self;`Self;`Self;`Self;|];|];[|nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;[|(`Uchars [66600;]);(`Uchars [66601;]);(`Uchars [66602;]);
(`Uchars [66603;]);(`Uchars [66604;]);(`Uchars [66605;]);(`Uchars [66606;]);
(`Uchars [66607;]);(`Uchars [66608;]);(`Uchars [66609;]);(`Uchars [66610;]);
(`Uchars [66611;]);(`Uchars [66612;]);(`Uchars [66613;]);(`Uchars [66614;]);
(`Uchars [66615;]);|];[|(`Uchars [66616;]);(`Uchars [66617;]);
(`Uchars [66618;]);(`Uchars [66619;]);(`Uchars [66620;]);(`Uchars [66621;]);
(`Uchars [66622;]);(`Uchars [66623;]);(`Uchars [66624;]);(`Uchars [66625;]);
(`Uchars [66626;]);(`Uchars [66627;]);(`Uchars [66628;]);(`Uchars [66629;]);
(`Uchars [66630;]);(`Uchars [66631;]);|];[|(`Uchars [66632;]);
(`Uchars [66633;]);(`Uchars [66634;]);(`Uchars [66635;]);(`Uchars [66636;]);
(`Uchars [66637;]);(`Uchars [66638;]);(`Uchars [66639;]);`Self;`Self;`Self;
`Self;`Self;`Self;`Self;`Self;|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;[|(`Uchars [68800;]);(`Uchars [68801;]);
(`Uchars [68802;]);(`Uchars [68803;]);(`Uchars [68804;]);(`Uchars [68805;]);
(`Uchars [68806;]);(`Uchars [68807;]);(`Uchars [68808;]);(`Uchars [68809;]);
(`Uchars [68810;]);(`Uchars [68811;]);(`Uchars [68812;]);(`Uchars [68813;]);
(`Uchars [68814;]);(`Uchars [68815;]);|];[|(`Uchars [68816;]);
(`Uchars [68817;]);(`Uchars [68818;]);(`Uchars [68819;]);(`Uchars [68820;]);
(`Uchars [68821;]);(`Uchars [68822;]);(`Uchars [68823;]);(`Uchars [68824;]);
(`Uchars [68825;]);(`Uchars [68826;]);(`Uchars [68827;]);(`Uchars [68828;]);
(`Uchars [68829;]);(`Uchars [68830;]);(`Uchars [68831;]);|];[|
(`Uchars [68832;]);(`Uchars [68833;]);(`Uchars [68834;]);(`Uchars [68835;]);
(`Uchars [68836;]);(`Uchars [68837;]);(`Uchars [68838;]);(`Uchars [68839;]);
(`Uchars [68840;]);(`Uchars [68841;]);(`Uchars [68842;]);(`Uchars [68843;]);
(`Uchars [68844;]);(`Uchars [68845;]);(`Uchars [68846;]);(`Uchars [68847;]);
|];[|(`Uchars [68848;]);(`Uchars [68849;]);(`Uchars [68850;]);`Self;`Self;
`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;|];nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;|];[|nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;[|
(`Uchars [71872;]);(`Uchars [71873;]);(`Uchars [71874;]);(`Uchars [71875;]);
(`Uchars [71876;]);(`Uchars [71877;]);(`Uchars [71878;]);(`Uchars [71879;]);
(`Uchars [71880;]);(`Uchars [71881;]);(`Uchars [71882;]);(`Uchars [71883;]);
(`Uchars [71884;]);(`Uchars [71885;]);(`Uchars [71886;]);(`Uchars [71887;]);
|];[|(`Uchars [71888;]);(`Uchars [71889;]);(`Uchars [71890;]);
(`Uchars [71891;]);(`Uchars [71892;]);(`Uchars [71893;]);(`Uchars [71894;]);
(`Uchars [71895;]);(`Uchars [71896;]);(`Uchars [71897;]);(`Uchars [71898;]);
(`Uchars [71899;]);(`Uchars [71900;]);(`Uchars [71901;]);(`Uchars [71902;]);
(`Uchars [71903;]);|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;|];nil;nil;nil;nil;nil;nil;nil;nil;nil;[|nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;`Self;`Self;|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;|];nil;[|nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;[|`Self;`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;`Self;`Self;`Self;`Self;`Self;(`Uchars [119127;119141;]);
(`Uchars [119128;119141;]);|];[|(`Uchars [119128;119141;119150;]);
(`Uchars [119128;119141;119151;]);(`Uchars [119128;119141;119152;]);
(`Uchars [119128;119141;119153;]);(`Uchars [119128;119141;119154;]);`Self;
`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;|];[|`Self;`Self;
`Self;(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);`Self;`Self;`Self;`Self;`Self;|];nil;
nil;nil;[|`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
(`Uchars [119225;119141;]);(`Uchars [119226;119141;]);
(`Uchars [119225;119141;119150;]);(`Uchars [119226;119141;119150;]);
(`Uchars [119225;119141;119151;]);|];[|(`Uchars [119226;119141;119151;]);
`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;`Self;|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;[|(`Uchars [97;]);(`Uchars [98;]);(`Uchars [99;]);(`Uchars [100;]);
(`Uchars [101;]);(`Uchars [102;]);(`Uchars [103;]);(`Uchars [104;]);
(`Uchars [105;]);(`Uchars [106;]);(`Uchars [107;]);(`Uchars [108;]);
(`Uchars [109;]);(`Uchars [110;]);(`Uchars [111;]);(`Uchars [112;]);|];[|
(`Uchars [113;]);(`Uchars [114;]);(`Uchars [115;]);(`Uchars [116;]);
(`Uchars [117;]);(`Uchars [118;]);(`Uchars [119;]);(`Uchars [120;]);
(`Uchars [121;]);(`Uchars [122;]);(`Uchars [97;]);(`Uchars [98;]);
(`Uchars [99;]);(`Uchars [100;]);(`Uchars [101;]);(`Uchars [102;]);|];[|
(`Uchars [103;]);(`Uchars [104;]);(`Uchars [105;]);(`Uchars [106;]);
(`Uchars [107;]);(`Uchars [108;]);(`Uchars [109;]);(`Uchars [110;]);
(`Uchars [111;]);(`Uchars [112;]);(`Uchars [113;]);(`Uchars [114;]);
(`Uchars [115;]);(`Uchars [116;]);(`Uchars [117;]);(`Uchars [118;]);|];[|
(`Uchars [119;]);(`Uchars [120;]);(`Uchars [121;]);(`Uchars [122;]);
(`Uchars [97;]);(`Uchars [98;]);(`Uchars [99;]);(`Uchars [100;]);
(`Uchars [101;]);(`Uchars [102;]);(`Uchars [103;]);(`Uchars [104;]);
(`Uchars [105;]);(`Uchars [106;]);(`Uchars [107;]);(`Uchars [108;]);|];[|
(`Uchars [109;]);(`Uchars [110;]);(`Uchars [111;]);(`Uchars [112;]);
(`Uchars [113;]);(`Uchars [114;]);(`Uchars [115;]);(`Uchars [116;]);
(`Uchars [117;]);(`Uchars [118;]);(`Uchars [119;]);(`Uchars [120;]);
(`Uchars [121;]);(`Uchars [122;]);(`Uchars [97;]);(`Uchars [98;]);|];[|
(`Uchars [99;]);(`Uchars [100;]);(`Uchars [101;]);(`Uchars [102;]);
(`Uchars [103;]);`Self;(`Uchars [105;]);(`Uchars [106;]);(`Uchars [107;]);
(`Uchars [108;]);(`Uchars [109;]);(`Uchars [110;]);(`Uchars [111;]);
(`Uchars [112;]);(`Uchars [113;]);(`Uchars [114;]);|];[|(`Uchars [115;]);
(`Uchars [116;]);(`Uchars [117;]);(`Uchars [118;]);(`Uchars [119;]);
(`Uchars [120;]);(`Uchars [121;]);(`Uchars [122;]);(`Uchars [97;]);
(`Uchars [98;]);(`Uchars [99;]);(`Uchars [100;]);(`Uchars [101;]);
(`Uchars [102;]);(`Uchars [103;]);(`Uchars [104;]);|];[|(`Uchars [105;]);
(`Uchars [106;]);(`Uchars [107;]);(`Uchars [108;]);(`Uchars [109;]);
(`Uchars [110;]);(`Uchars [111;]);(`Uchars [112;]);(`Uchars [113;]);
(`Uchars [114;]);(`Uchars [115;]);(`Uchars [116;]);(`Uchars [117;]);
(`Uchars [118;]);(`Uchars [119;]);(`Uchars [120;]);|];[|(`Uchars [121;]);
(`Uchars [122;]);(`Uchars [97;]);(`Uchars [98;]);(`Uchars [99;]);
(`Uchars [100;]);(`Uchars [101;]);(`Uchars [102;]);(`Uchars [103;]);
(`Uchars [104;]);(`Uchars [105;]);(`Uchars [106;]);(`Uchars [107;]);
(`Uchars [108;]);(`Uchars [109;]);(`Uchars [110;]);|];[|(`Uchars [111;]);
(`Uchars [112;]);(`Uchars [113;]);(`Uchars [114;]);(`Uchars [115;]);
(`Uchars [116;]);(`Uchars [117;]);(`Uchars [118;]);(`Uchars [119;]);
(`Uchars [120;]);(`Uchars [121;]);(`Uchars [122;]);(`Uchars [97;]);`Self;
(`Uchars [99;]);(`Uchars [100;]);|];[|`Self;`Self;(`Uchars [103;]);`Self;
`Self;(`Uchars [106;]);(`Uchars [107;]);`Self;`Self;(`Uchars [110;]);
(`Uchars [111;]);(`Uchars [112;]);(`Uchars [113;]);`Self;(`Uchars [115;]);
(`Uchars [116;]);|];[|(`Uchars [117;]);(`Uchars [118;]);(`Uchars [119;]);
(`Uchars [120;]);(`Uchars [121;]);(`Uchars [122;]);(`Uchars [97;]);
(`Uchars [98;]);(`Uchars [99;]);(`Uchars [100;]);`Self;(`Uchars [102;]);
`Self;(`Uchars [104;]);(`Uchars [105;]);(`Uchars [106;]);|];[|
(`Uchars [107;]);(`Uchars [108;]);(`Uchars [109;]);(`Uchars [110;]);`Self;
(`Uchars [112;]);(`Uchars [113;]);(`Uchars [114;]);(`Uchars [115;]);
(`Uchars [116;]);(`Uchars [117;]);(`Uchars [118;]);(`Uchars [119;]);
(`Uchars [120;]);(`Uchars [121;]);(`Uchars [122;]);|];[|(`Uchars [97;]);
(`Uchars [98;]);(`Uchars [99;]);(`Uchars [100;]);(`Uchars [101;]);
(`Uchars [102;]);(`Uchars [103;]);(`Uchars [104;]);(`Uchars [105;]);
(`Uchars [106;]);(`Uchars [107;]);(`Uchars [108;]);(`Uchars [109;]);
(`Uchars [110;]);(`Uchars [111;]);(`Uchars [112;]);|];[|(`Uchars [113;]);
(`Uchars [114;]);(`Uchars [115;]);(`Uchars [116;]);(`Uchars [117;]);
(`Uchars [118;]);(`Uchars [119;]);(`Uchars [120;]);(`Uchars [121;]);
(`Uchars [122;]);(`Uchars [97;]);(`Uchars [98;]);(`Uchars [99;]);
(`Uchars [100;]);(`Uchars [101;]);(`Uchars [102;]);|];[|(`Uchars [103;]);
(`Uchars [104;]);(`Uchars [105;]);(`Uchars [106;]);(`Uchars [107;]);
(`Uchars [108;]);(`Uchars [109;]);(`Uchars [110;]);(`Uchars [111;]);
(`Uchars [112;]);(`Uchars [113;]);(`Uchars [114;]);(`Uchars [115;]);
(`Uchars [116;]);(`Uchars [117;]);(`Uchars [118;]);|];[|(`Uchars [119;]);
(`Uchars [120;]);(`Uchars [121;]);(`Uchars [122;]);(`Uchars [97;]);
(`Uchars [98;]);`Self;(`Uchars [100;]);(`Uchars [101;]);(`Uchars [102;]);
(`Uchars [103;]);`Self;`Self;(`Uchars [106;]);(`Uchars [107;]);
(`Uchars [108;]);|];[|(`Uchars [109;]);(`Uchars [110;]);(`Uchars [111;]);
(`Uchars [112;]);(`Uchars [113;]);`Self;(`Uchars [115;]);(`Uchars [116;]);
(`Uchars [117;]);(`Uchars [118;]);(`Uchars [119;]);(`Uchars [120;]);
(`Uchars [121;]);`Self;(`Uchars [97;]);(`Uchars [98;]);|];[|(`Uchars [99;]);
(`Uchars [100;]);(`Uchars [101;]);(`Uchars [102;]);(`Uchars [103;]);
(`Uchars [104;]);(`Uchars [105;]);(`Uchars [106;]);(`Uchars [107;]);
(`Uchars [108;]);(`Uchars [109;]);(`Uchars [110;]);(`Uchars [111;]);
(`Uchars [112;]);(`Uchars [113;]);(`Uchars [114;]);|];[|(`Uchars [115;]);
(`Uchars [116;]);(`Uchars [117;]);(`Uchars [118;]);(`Uchars [119;]);
(`Uchars [120;]);(`Uchars [121;]);(`Uchars [122;]);(`Uchars [97;]);
(`Uchars [98;]);`Self;(`Uchars [100;]);(`Uchars [101;]);(`Uchars [102;]);
(`Uchars [103;]);`Self;|];[|(`Uchars [105;]);(`Uchars [106;]);
(`Uchars [107;]);(`Uchars [108;]);(`Uchars [109;]);`Self;(`Uchars [111;]);
`Self;`Self;`Self;(`Uchars [115;]);(`Uchars [116;]);(`Uchars [117;]);
(`Uchars [118;]);(`Uchars [119;]);(`Uchars [120;]);|];[|(`Uchars [121;]);
`Self;(`Uchars [97;]);(`Uchars [98;]);(`Uchars [99;]);(`Uchars [100;]);
(`Uchars [101;]);(`Uchars [102;]);(`Uchars [103;]);(`Uchars [104;]);
(`Uchars [105;]);(`Uchars [106;]);(`Uchars [107;]);(`Uchars [108;]);
(`Uchars [109;]);(`Uchars [110;]);|];[|(`Uchars [111;]);(`Uchars [112;]);
(`Uchars [113;]);(`Uchars [114;]);(`Uchars [115;]);(`Uchars [116;]);
(`Uchars [117;]);(`Uchars [118;]);(`Uchars [119;]);(`Uchars [120;]);
(`Uchars [121;]);(`Uchars [122;]);(`Uchars [97;]);(`Uchars [98;]);
(`Uchars [99;]);(`Uchars [100;]);|];[|(`Uchars [101;]);(`Uchars [102;]);
(`Uchars [103;]);(`Uchars [104;]);(`Uchars [105;]);(`Uchars [106;]);
(`Uchars [107;]);(`Uchars [108;]);(`Uchars [109;]);(`Uchars [110;]);
(`Uchars [111;]);(`Uchars [112;]);(`Uchars [113;]);(`Uchars [114;]);
(`Uchars [115;]);(`Uchars [116;]);|];[|(`Uchars [117;]);(`Uchars [118;]);
(`Uchars [119;]);(`Uchars [120;]);(`Uchars [121;]);(`Uchars [122;]);
(`Uchars [97;]);(`Uchars [98;]);(`Uchars [99;]);(`Uchars [100;]);
(`Uchars [101;]);(`Uchars [102;]);(`Uchars [103;]);(`Uchars [104;]);
(`Uchars [105;]);(`Uchars [106;]);|];[|(`Uchars [107;]);(`Uchars [108;]);
(`Uchars [109;]);(`Uchars [110;]);(`Uchars [111;]);(`Uchars [112;]);
(`Uchars [113;]);(`Uchars [114;]);(`Uchars [115;]);(`Uchars [116;]);
(`Uchars [117;]);(`Uchars [118;]);(`Uchars [119;]);(`Uchars [120;]);
(`Uchars [121;]);(`Uchars [122;]);|];[|(`Uchars [97;]);(`Uchars [98;]);
(`Uchars [99;]);(`Uchars [100;]);(`Uchars [101;]);(`Uchars [102;]);
(`Uchars [103;]);(`Uchars [104;]);(`Uchars [105;]);(`Uchars [106;]);
(`Uchars [107;]);(`Uchars [108;]);(`Uchars [109;]);(`Uchars [110;]);
(`Uchars [111;]);(`Uchars [112;]);|];[|(`Uchars [113;]);(`Uchars [114;]);
(`Uchars [115;]);(`Uchars [116;]);(`Uchars [117;]);(`Uchars [118;]);
(`Uchars [119;]);(`Uchars [120;]);(`Uchars [121;]);(`Uchars [122;]);
(`Uchars [97;]);(`Uchars [98;]);(`Uchars [99;]);(`Uchars [100;]);
(`Uchars [101;]);(`Uchars [102;]);|];[|(`Uchars [103;]);(`Uchars [104;]);
(`Uchars [105;]);(`Uchars [106;]);(`Uchars [107;]);(`Uchars [108;]);
(`Uchars [109;]);(`Uchars [110;]);(`Uchars [111;]);(`Uchars [112;]);
(`Uchars [113;]);(`Uchars [114;]);(`Uchars [115;]);(`Uchars [116;]);
(`Uchars [117;]);(`Uchars [118;]);|];[|(`Uchars [119;]);(`Uchars [120;]);
(`Uchars [121;]);(`Uchars [122;]);(`Uchars [97;]);(`Uchars [98;]);
(`Uchars [99;]);(`Uchars [100;]);(`Uchars [101;]);(`Uchars [102;]);
(`Uchars [103;]);(`Uchars [104;]);(`Uchars [105;]);(`Uchars [106;]);
(`Uchars [107;]);(`Uchars [108;]);|];[|(`Uchars [109;]);(`Uchars [110;]);
(`Uchars [111;]);(`Uchars [112;]);(`Uchars [113;]);(`Uchars [114;]);
(`Uchars [115;]);(`Uchars [116;]);(`Uchars [117;]);(`Uchars [118;]);
(`Uchars [119;]);(`Uchars [120;]);(`Uchars [121;]);(`Uchars [122;]);
(`Uchars [97;]);(`Uchars [98;]);|];[|(`Uchars [99;]);(`Uchars [100;]);
(`Uchars [101;]);(`Uchars [102;]);(`Uchars [103;]);(`Uchars [104;]);
(`Uchars [105;]);(`Uchars [106;]);(`Uchars [107;]);(`Uchars [108;]);
(`Uchars [109;]);(`Uchars [110;]);(`Uchars [111;]);(`Uchars [112;]);
(`Uchars [113;]);(`Uchars [114;]);|];[|(`Uchars [115;]);(`Uchars [116;]);
(`Uchars [117;]);(`Uchars [118;]);(`Uchars [119;]);(`Uchars [120;]);
(`Uchars [121;]);(`Uchars [122;]);(`Uchars [97;]);(`Uchars [98;]);
(`Uchars [99;]);(`Uchars [100;]);(`Uchars [101;]);(`Uchars [102;]);
(`Uchars [103;]);(`Uchars [104;]);|];[|(`Uchars [105;]);(`Uchars [106;]);
(`Uchars [107;]);(`Uchars [108;]);(`Uchars [109;]);(`Uchars [110;]);
(`Uchars [111;]);(`Uchars [112;]);(`Uchars [113;]);(`Uchars [114;]);
(`Uchars [115;]);(`Uchars [116;]);(`Uchars [117;]);(`Uchars [118;]);
(`Uchars [119;]);(`Uchars [120;]);|];[|(`Uchars [121;]);(`Uchars [122;]);
(`Uchars [97;]);(`Uchars [98;]);(`Uchars [99;]);(`Uchars [100;]);
(`Uchars [101;]);(`Uchars [102;]);(`Uchars [103;]);(`Uchars [104;]);
(`Uchars [105;]);(`Uchars [106;]);(`Uchars [107;]);(`Uchars [108;]);
(`Uchars [109;]);(`Uchars [110;]);|];[|(`Uchars [111;]);(`Uchars [112;]);
(`Uchars [113;]);(`Uchars [114;]);(`Uchars [115;]);(`Uchars [116;]);
(`Uchars [117;]);(`Uchars [118;]);(`Uchars [119;]);(`Uchars [120;]);
(`Uchars [121;]);(`Uchars [122;]);(`Uchars [97;]);(`Uchars [98;]);
(`Uchars [99;]);(`Uchars [100;]);|];[|(`Uchars [101;]);(`Uchars [102;]);
(`Uchars [103;]);(`Uchars [104;]);(`Uchars [105;]);(`Uchars [106;]);
(`Uchars [107;]);(`Uchars [108;]);(`Uchars [109;]);(`Uchars [110;]);
(`Uchars [111;]);(`Uchars [112;]);(`Uchars [113;]);(`Uchars [114;]);
(`Uchars [115;]);(`Uchars [116;]);|];[|(`Uchars [117;]);(`Uchars [118;]);
(`Uchars [119;]);(`Uchars [120;]);(`Uchars [121;]);(`Uchars [122;]);
(`Uchars [97;]);(`Uchars [98;]);(`Uchars [99;]);(`Uchars [100;]);
(`Uchars [101;]);(`Uchars [102;]);(`Uchars [103;]);(`Uchars [104;]);
(`Uchars [105;]);(`Uchars [106;]);|];[|(`Uchars [107;]);(`Uchars [108;]);
(`Uchars [109;]);(`Uchars [110;]);(`Uchars [111;]);(`Uchars [112;]);
(`Uchars [113;]);(`Uchars [114;]);(`Uchars [115;]);(`Uchars [116;]);
(`Uchars [117;]);(`Uchars [118;]);(`Uchars [119;]);(`Uchars [120;]);
(`Uchars [121;]);(`Uchars [122;]);|];[|(`Uchars [97;]);(`Uchars [98;]);
(`Uchars [99;]);(`Uchars [100;]);(`Uchars [101;]);(`Uchars [102;]);
(`Uchars [103;]);(`Uchars [104;]);(`Uchars [105;]);(`Uchars [106;]);
(`Uchars [107;]);(`Uchars [108;]);(`Uchars [109;]);(`Uchars [110;]);
(`Uchars [111;]);(`Uchars [112;]);|];[|(`Uchars [113;]);(`Uchars [114;]);
(`Uchars [115;]);(`Uchars [116;]);(`Uchars [117;]);(`Uchars [118;]);
(`Uchars [119;]);(`Uchars [120;]);(`Uchars [121;]);(`Uchars [122;]);
(`Uchars [97;]);(`Uchars [98;]);(`Uchars [99;]);(`Uchars [100;]);
(`Uchars [101;]);(`Uchars [102;]);|];[|(`Uchars [103;]);(`Uchars [104;]);
(`Uchars [105;]);(`Uchars [106;]);(`Uchars [107;]);(`Uchars [108;]);
(`Uchars [109;]);(`Uchars [110;]);(`Uchars [111;]);(`Uchars [112;]);
(`Uchars [113;]);(`Uchars [114;]);(`Uchars [115;]);(`Uchars [116;]);
(`Uchars [117;]);(`Uchars [118;]);|];[|(`Uchars [119;]);(`Uchars [120;]);
(`Uchars [121;]);(`Uchars [122;]);(`Uchars [305;]);(`Uchars [567;]);`Self;
`Self;(`Uchars [945;]);(`Uchars [946;]);(`Uchars [947;]);(`Uchars [948;]);
(`Uchars [949;]);(`Uchars [950;]);(`Uchars [951;]);(`Uchars [952;]);|];[|
(`Uchars [953;]);(`Uchars [954;]);(`Uchars [955;]);(`Uchars [956;]);
(`Uchars [957;]);(`Uchars [958;]);(`Uchars [959;]);(`Uchars [960;]);
(`Uchars [961;]);(`Uchars [952;]);(`Uchars [963;]);(`Uchars [964;]);
(`Uchars [965;]);(`Uchars [966;]);(`Uchars [967;]);(`Uchars [968;]);|];[|
(`Uchars [969;]);(`Uchars [8711;]);(`Uchars [945;]);(`Uchars [946;]);
(`Uchars [947;]);(`Uchars [948;]);(`Uchars [949;]);(`Uchars [950;]);
(`Uchars [951;]);(`Uchars [952;]);(`Uchars [953;]);(`Uchars [954;]);
(`Uchars [955;]);(`Uchars [956;]);(`Uchars [957;]);(`Uchars [958;]);|];[|
(`Uchars [959;]);(`Uchars [960;]);(`Uchars [961;]);(`Uchars [963;]);
(`Uchars [963;]);(`Uchars [964;]);(`Uchars [965;]);(`Uchars [966;]);
(`Uchars [967;]);(`Uchars [968;]);(`Uchars [969;]);(`Uchars [8706;]);
(`Uchars [949;]);(`Uchars [952;]);(`Uchars [954;]);(`Uchars [966;]);|];[|
(`Uchars [961;]);(`Uchars [960;]);(`Uchars [945;]);(`Uchars [946;]);
(`Uchars [947;]);(`Uchars [948;]);(`Uchars [949;]);(`Uchars [950;]);
(`Uchars [951;]);(`Uchars [952;]);(`Uchars [953;]);(`Uchars [954;]);
(`Uchars [955;]);(`Uchars [956;]);(`Uchars [957;]);(`Uchars [958;]);|];[|
(`Uchars [959;]);(`Uchars [960;]);(`Uchars [961;]);(`Uchars [952;]);
(`Uchars [963;]);(`Uchars [964;]);(`Uchars [965;]);(`Uchars [966;]);
(`Uchars [967;]);(`Uchars [968;]);(`Uchars [969;]);(`Uchars [8711;]);
(`Uchars [945;]);(`Uchars [946;]);(`Uchars [947;]);(`Uchars [948;]);|];[|
(`Uchars [949;]);(`Uchars [950;]);(`Uchars [951;]);(`Uchars [952;]);
(`Uchars [953;]);(`Uchars [954;]);(`Uchars [955;]);(`Uchars [956;]);
(`Uchars [957;]);(`Uchars [958;]);(`Uchars [959;]);(`Uchars [960;]);
(`Uchars [961;]);(`Uchars [963;]);(`Uchars [963;]);(`Uchars [964;]);|];[|
(`Uchars [965;]);(`Uchars [966;]);(`Uchars [967;]);(`Uchars [968;]);
(`Uchars [969;]);(`Uchars [8706;]);(`Uchars [949;]);(`Uchars [952;]);
(`Uchars [954;]);(`Uchars [966;]);(`Uchars [961;]);(`Uchars [960;]);
(`Uchars [945;]);(`Uchars [946;]);(`Uchars [947;]);(`Uchars [948;]);|];[|
(`Uchars [949;]);(`Uchars [950;]);(`Uchars [951;]);(`Uchars [952;]);
(`Uchars [953;]);(`Uchars [954;]);(`Uchars [955;]);(`Uchars [956;]);
(`Uchars [957;]);(`Uchars [958;]);(`Uchars [959;]);(`Uchars [960;]);
(`Uchars [961;]);(`Uchars [952;]);(`Uchars [963;]);(`Uchars [964;]);|];[|
(`Uchars [965;]);(`Uchars [966;]);(`Uchars [967;]);(`Uchars [968;]);
(`Uchars [969;]);(`Uchars [8711;]);(`Uchars [945;]);(`Uchars [946;]);
(`Uchars [947;]);(`Uchars [948;]);(`Uchars [949;]);(`Uchars [950;]);
(`Uchars [951;]);(`Uchars [952;]);(`Uchars [953;]);(`Uchars [954;]);|];[|
(`Uchars [955;]);(`Uchars [956;]);(`Uchars [957;]);(`Uchars [958;]);
(`Uchars [959;]);(`Uchars [960;]);(`Uchars [961;]);(`Uchars [963;]);
(`Uchars [963;]);(`Uchars [964;]);(`Uchars [965;]);(`Uchars [966;]);
(`Uchars [967;]);(`Uchars [968;]);(`Uchars [969;]);(`Uchars [8706;]);|];[|
(`Uchars [949;]);(`Uchars [952;]);(`Uchars [954;]);(`Uchars [966;]);
(`Uchars [961;]);(`Uchars [960;]);(`Uchars [945;]);(`Uchars [946;]);
(`Uchars [947;]);(`Uchars [948;]);(`Uchars [949;]);(`Uchars [950;]);
(`Uchars [951;]);(`Uchars [952;]);(`Uchars [953;]);(`Uchars [954;]);|];[|
(`Uchars [955;]);(`Uchars [956;]);(`Uchars [957;]);(`Uchars [958;]);
(`Uchars [959;]);(`Uchars [960;]);(`Uchars [961;]);(`Uchars [952;]);
(`Uchars [963;]);(`Uchars [964;]);(`Uchars [965;]);(`Uchars [966;]);
(`Uchars [967;]);(`Uchars [968;]);(`Uchars [969;]);(`Uchars [8711;]);|];[|
(`Uchars [945;]);(`Uchars [946;]);(`Uchars [947;]);(`Uchars [948;]);
(`Uchars [949;]);(`Uchars [950;]);(`Uchars [951;]);(`Uchars [952;]);
(`Uchars [953;]);(`Uchars [954;]);(`Uchars [955;]);(`Uchars [956;]);
(`Uchars [957;]);(`Uchars [958;]);(`Uchars [959;]);(`Uchars [960;]);|];[|
(`Uchars [961;]);(`Uchars [963;]);(`Uchars [963;]);(`Uchars [964;]);
(`Uchars [965;]);(`Uchars [966;]);(`Uchars [967;]);(`Uchars [968;]);
(`Uchars [969;]);(`Uchars [8706;]);(`Uchars [949;]);(`Uchars [952;]);
(`Uchars [954;]);(`Uchars [966;]);(`Uchars [961;]);(`Uchars [960;]);|];[|
(`Uchars [945;]);(`Uchars [946;]);(`Uchars [947;]);(`Uchars [948;]);
(`Uchars [949;]);(`Uchars [950;]);(`Uchars [951;]);(`Uchars [952;]);
(`Uchars [953;]);(`Uchars [954;]);(`Uchars [955;]);(`Uchars [956;]);
(`Uchars [957;]);(`Uchars [958;]);(`Uchars [959;]);(`Uchars [960;]);|];[|
(`Uchars [961;]);(`Uchars [952;]);(`Uchars [963;]);(`Uchars [964;]);
(`Uchars [965;]);(`Uchars [966;]);(`Uchars [967;]);(`Uchars [968;]);
(`Uchars [969;]);(`Uchars [8711;]);(`Uchars [945;]);(`Uchars [946;]);
(`Uchars [947;]);(`Uchars [948;]);(`Uchars [949;]);(`Uchars [950;]);|];[|
(`Uchars [951;]);(`Uchars [952;]);(`Uchars [953;]);(`Uchars [954;]);
(`Uchars [955;]);(`Uchars [956;]);(`Uchars [957;]);(`Uchars [958;]);
(`Uchars [959;]);(`Uchars [960;]);(`Uchars [961;]);(`Uchars [963;]);
(`Uchars [963;]);(`Uchars [964;]);(`Uchars [965;]);(`Uchars [966;]);|];[|
(`Uchars [967;]);(`Uchars [968;]);(`Uchars [969;]);(`Uchars [8706;]);
(`Uchars [949;]);(`Uchars [952;]);(`Uchars [954;]);(`Uchars [966;]);
(`Uchars [961;]);(`Uchars [960;]);(`Uchars [989;]);(`Uchars [989;]);`Self;
`Self;(`Uchars [48;]);(`Uchars [49;]);|];[|(`Uchars [50;]);(`Uchars [51;]);
(`Uchars [52;]);(`Uchars [53;]);(`Uchars [54;]);(`Uchars [55;]);
(`Uchars [56;]);(`Uchars [57;]);(`Uchars [48;]);(`Uchars [49;]);
(`Uchars [50;]);(`Uchars [51;]);(`Uchars [52;]);(`Uchars [53;]);
(`Uchars [54;]);(`Uchars [55;]);|];[|(`Uchars [56;]);(`Uchars [57;]);
(`Uchars [48;]);(`Uchars [49;]);(`Uchars [50;]);(`Uchars [51;]);
(`Uchars [52;]);(`Uchars [53;]);(`Uchars [54;]);(`Uchars [55;]);
(`Uchars [56;]);(`Uchars [57;]);(`Uchars [48;]);(`Uchars [49;]);
(`Uchars [50;]);(`Uchars [51;]);|];[|(`Uchars [52;]);(`Uchars [53;]);
(`Uchars [54;]);(`Uchars [55;]);(`Uchars [56;]);(`Uchars [57;]);
(`Uchars [48;]);(`Uchars [49;]);(`Uchars [50;]);(`Uchars [51;]);
(`Uchars [52;]);(`Uchars [53;]);(`Uchars [54;]);(`Uchars [55;]);
(`Uchars [56;]);(`Uchars [57;]);|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;|];[|nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;[|(`Uchars [1575;]);(`Uchars [1576;]);(`Uchars [1580;]);
(`Uchars [1583;]);`Self;(`Uchars [1608;]);(`Uchars [1586;]);
(`Uchars [1581;]);(`Uchars [1591;]);(`Uchars [1610;]);(`Uchars [1603;]);
(`Uchars [1604;]);(`Uchars [1605;]);(`Uchars [1606;]);(`Uchars [1587;]);
(`Uchars [1593;]);|];[|(`Uchars [1601;]);(`Uchars [1589;]);(`Uchars [1602;]);
(`Uchars [1585;]);(`Uchars [1588;]);(`Uchars [1578;]);(`Uchars [1579;]);
(`Uchars [1582;]);(`Uchars [1584;]);(`Uchars [1590;]);(`Uchars [1592;]);
(`Uchars [1594;]);(`Uchars [1646;]);(`Uchars [1722;]);(`Uchars [1697;]);
(`Uchars [1647;]);|];[|`Self;(`Uchars [1576;]);(`Uchars [1580;]);`Self;
(`Uchars [1607;]);`Self;`Self;(`Uchars [1581;]);`Self;(`Uchars [1610;]);
(`Uchars [1603;]);(`Uchars [1604;]);(`Uchars [1605;]);(`Uchars [1606;]);
(`Uchars [1587;]);(`Uchars [1593;]);|];[|(`Uchars [1601;]);(`Uchars [1589;]);
(`Uchars [1602;]);`Self;(`Uchars [1588;]);(`Uchars [1578;]);
(`Uchars [1579;]);(`Uchars [1582;]);`Self;(`Uchars [1590;]);`Self;
(`Uchars [1594;]);`Self;`Self;`Self;`Self;|];[|`Self;`Self;(`Uchars [1580;]);
`Self;`Self;`Self;`Self;(`Uchars [1581;]);`Self;(`Uchars [1610;]);`Self;
(`Uchars [1604;]);`Self;(`Uchars [1606;]);(`Uchars [1587;]);
(`Uchars [1593;]);|];[|`Self;(`Uchars [1589;]);(`Uchars [1602;]);`Self;
(`Uchars [1588;]);`Self;`Self;(`Uchars [1582;]);`Self;(`Uchars [1590;]);
`Self;(`Uchars [1594;]);`Self;(`Uchars [1722;]);`Self;(`Uchars [1647;]);|];[|
`Self;(`Uchars [1576;]);(`Uchars [1580;]);`Self;(`Uchars [1607;]);`Self;
`Self;(`Uchars [1581;]);(`Uchars [1591;]);(`Uchars [1610;]);
(`Uchars [1603;]);`Self;(`Uchars [1605;]);(`Uchars [1606;]);
(`Uchars [1587;]);(`Uchars [1593;]);|];[|(`Uchars [1601;]);(`Uchars [1589;]);
(`Uchars [1602;]);`Self;(`Uchars [1588;]);(`Uchars [1578;]);
(`Uchars [1579;]);(`Uchars [1582;]);`Self;(`Uchars [1590;]);
(`Uchars [1592;]);(`Uchars [1594;]);(`Uchars [1646;]);`Self;
(`Uchars [1697;]);`Self;|];[|(`Uchars [1575;]);(`Uchars [1576;]);
(`Uchars [1580;]);(`Uchars [1583;]);(`Uchars [1607;]);(`Uchars [1608;]);
(`Uchars [1586;]);(`Uchars [1581;]);(`Uchars [1591;]);(`Uchars [1610;]);
`Self;(`Uchars [1604;]);(`Uchars [1605;]);(`Uchars [1606;]);
(`Uchars [1587;]);(`Uchars [1593;]);|];[|(`Uchars [1601;]);(`Uchars [1589;]);
(`Uchars [1602;]);(`Uchars [1585;]);(`Uchars [1588;]);(`Uchars [1578;]);
(`Uchars [1579;]);(`Uchars [1582;]);(`Uchars [1584;]);(`Uchars [1590;]);
(`Uchars [1592;]);(`Uchars [1594;]);`Self;`Self;`Self;`Self;|];[|`Self;
(`Uchars [1576;]);(`Uchars [1580;]);(`Uchars [1583;]);`Self;
(`Uchars [1608;]);(`Uchars [1586;]);(`Uchars [1581;]);(`Uchars [1591;]);
(`Uchars [1610;]);`Self;(`Uchars [1604;]);(`Uchars [1605;]);
(`Uchars [1606;]);(`Uchars [1587;]);(`Uchars [1593;]);|];[|(`Uchars [1601;]);
(`Uchars [1589;]);(`Uchars [1602;]);(`Uchars [1585;]);(`Uchars [1588;]);
(`Uchars [1578;]);(`Uchars [1579;]);(`Uchars [1582;]);(`Uchars [1584;]);
(`Uchars [1590;]);(`Uchars [1592;]);(`Uchars [1594;]);`Self;`Self;`Self;
`Self;|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;|];[|nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;[|(`Uchars [48;46;]);(`Uchars [48;44;]);(`Uchars [49;44;]);
(`Uchars [50;44;]);(`Uchars [51;44;]);(`Uchars [52;44;]);(`Uchars [53;44;]);
(`Uchars [54;44;]);(`Uchars [55;44;]);(`Uchars [56;44;]);(`Uchars [57;44;]);
`Self;`Self;`Self;`Self;`Self;|];[|(`Uchars [40;97;41;]);
(`Uchars [40;98;41;]);(`Uchars [40;99;41;]);(`Uchars [40;100;41;]);
(`Uchars [40;101;41;]);(`Uchars [40;102;41;]);(`Uchars [40;103;41;]);
(`Uchars [40;104;41;]);(`Uchars [40;105;41;]);(`Uchars [40;106;41;]);
(`Uchars [40;107;41;]);(`Uchars [40;108;41;]);(`Uchars [40;109;41;]);
(`Uchars [40;110;41;]);(`Uchars [40;111;41;]);(`Uchars [40;112;41;]);|];[|
(`Uchars [40;113;41;]);(`Uchars [40;114;41;]);(`Uchars [40;115;41;]);
(`Uchars [40;116;41;]);(`Uchars [40;117;41;]);(`Uchars [40;118;41;]);
(`Uchars [40;119;41;]);(`Uchars [40;120;41;]);(`Uchars [40;121;41;]);
(`Uchars [40;122;41;]);(`Uchars [12308;115;12309;]);(`Uchars [99;]);
(`Uchars [114;]);(`Uchars [99;100;]);(`Uchars [119;122;]);`Self;|];[|
(`Uchars [97;]);(`Uchars [98;]);(`Uchars [99;]);(`Uchars [100;]);
(`Uchars [101;]);(`Uchars [102;]);(`Uchars [103;]);(`Uchars [104;]);
(`Uchars [105;]);(`Uchars [106;]);(`Uchars [107;]);(`Uchars [108;]);
(`Uchars [109;]);(`Uchars [110;]);(`Uchars [111;]);(`Uchars [112;]);|];[|
(`Uchars [113;]);(`Uchars [114;]);(`Uchars [115;]);(`Uchars [116;]);
(`Uchars [117;]);(`Uchars [118;]);(`Uchars [119;]);(`Uchars [120;]);
(`Uchars [121;]);(`Uchars [122;]);(`Uchars [104;118;]);(`Uchars [109;118;]);
(`Uchars [115;100;]);(`Uchars [115;115;]);(`Uchars [112;112;118;]);
(`Uchars [119;99;]);|];nil;[|`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;(`Uchars [109;99;]);(`Uchars [109;100;]);`Self;`Self;`Self;`Self;
|];nil;nil;[|(`Uchars [100;106;]);`Self;`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;|];nil;nil;nil;nil;nil;nil;[|
(`Uchars [12411;12363;]);(`Uchars [12467;12467;]);(`Uchars [12469;]);`Self;
`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;|];[|
(`Uchars [25163;]);(`Uchars [23383;]);(`Uchars [21452;]);(`Uchars [12487;]);
(`Uchars [20108;]);(`Uchars [22810;]);(`Uchars [35299;]);(`Uchars [22825;]);
(`Uchars [20132;]);(`Uchars [26144;]);(`Uchars [28961;]);(`Uchars [26009;]);
(`Uchars [21069;]);(`Uchars [24460;]);(`Uchars [20877;]);(`Uchars [26032;]);
|];[|(`Uchars [21021;]);(`Uchars [32066;]);(`Uchars [29983;]);
(`Uchars [36009;]);(`Uchars [22768;]);(`Uchars [21561;]);(`Uchars [28436;]);
(`Uchars [25237;]);(`Uchars [25429;]);(`Uchars [19968;]);(`Uchars [19977;]);
(`Uchars [36938;]);(`Uchars [24038;]);(`Uchars [20013;]);(`Uchars [21491;]);
(`Uchars [25351;]);|];[|(`Uchars [36208;]);(`Uchars [25171;]);
(`Uchars [31105;]);(`Uchars [31354;]);(`Uchars [21512;]);(`Uchars [28288;]);
(`Uchars [26377;]);(`Uchars [26376;]);(`Uchars [30003;]);(`Uchars [21106;]);
(`Uchars [21942;]);`Self;`Self;`Self;`Self;`Self;|];[|
(`Uchars [12308;26412;12309;]);(`Uchars [12308;19977;12309;]);
(`Uchars [12308;20108;12309;]);(`Uchars [12308;23433;12309;]);
(`Uchars [12308;28857;12309;]);(`Uchars [12308;25171;12309;]);
(`Uchars [12308;30423;12309;]);(`Uchars [12308;21213;12309;]);
(`Uchars [12308;25943;12309;]);`Self;`Self;`Self;`Self;`Self;`Self;`Self;|];
[|(`Uchars [24471;]);(`Uchars [21487;]);`Self;`Self;`Self;`Self;`Self;`Self;
`Self;`Self;`Self;`Self;`Self;`Self;`Self;`Self;|];nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;[|
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;[|(`Uchars [20029;]);
(`Uchars [20024;]);(`Uchars [20033;]);(`Uchars [131362;]);(`Uchars [20320;]);
(`Uchars [20398;]);(`Uchars [20411;]);(`Uchars [20482;]);(`Uchars [20602;]);
(`Uchars [20633;]);(`Uchars [20711;]);(`Uchars [20687;]);(`Uchars [13470;]);
(`Uchars [132666;]);(`Uchars [20813;]);(`Uchars [20820;]);|];[|
(`Uchars [20836;]);(`Uchars [20855;]);(`Uchars [132380;]);(`Uchars [13497;]);
(`Uchars [20839;]);(`Uchars [20877;]);(`Uchars [132427;]);(`Uchars [20887;]);
(`Uchars [20900;]);(`Uchars [20172;]);(`Uchars [20908;]);(`Uchars [20917;]);
(`Uchars [168415;]);(`Uchars [20981;]);(`Uchars [20995;]);(`Uchars [13535;]);
|];[|(`Uchars [21051;]);(`Uchars [21062;]);(`Uchars [21106;]);
(`Uchars [21111;]);(`Uchars [13589;]);(`Uchars [21191;]);(`Uchars [21193;]);
(`Uchars [21220;]);(`Uchars [21242;]);(`Uchars [21253;]);(`Uchars [21254;]);
(`Uchars [21271;]);(`Uchars [21321;]);(`Uchars [21329;]);(`Uchars [21338;]);
(`Uchars [21363;]);|];[|(`Uchars [21373;]);(`Uchars [21375;]);
(`Uchars [21375;]);(`Uchars [21375;]);(`Uchars [133676;]);(`Uchars [28784;]);
(`Uchars [21450;]);(`Uchars [21471;]);(`Uchars [133987;]);(`Uchars [21483;]);
(`Uchars [21489;]);(`Uchars [21510;]);(`Uchars [21662;]);(`Uchars [21560;]);
(`Uchars [21576;]);(`Uchars [21608;]);|];[|(`Uchars [21666;]);
(`Uchars [21750;]);(`Uchars [21776;]);(`Uchars [21843;]);(`Uchars [21859;]);
(`Uchars [21892;]);(`Uchars [21892;]);(`Uchars [21913;]);(`Uchars [21931;]);
(`Uchars [21939;]);(`Uchars [21954;]);(`Uchars [22294;]);(`Uchars [22022;]);
(`Uchars [22295;]);(`Uchars [22097;]);(`Uchars [22132;]);|];[|
(`Uchars [20999;]);(`Uchars [22766;]);(`Uchars [22478;]);(`Uchars [22516;]);
(`Uchars [22541;]);(`Uchars [22411;]);(`Uchars [22578;]);(`Uchars [22577;]);
(`Uchars [22700;]);(`Uchars [136420;]);(`Uchars [22770;]);(`Uchars [22775;]);
(`Uchars [22790;]);(`Uchars [22810;]);(`Uchars [22818;]);(`Uchars [22882;]);
|];[|(`Uchars [136872;]);(`Uchars [136938;]);(`Uchars [23020;]);
(`Uchars [23067;]);(`Uchars [23079;]);(`Uchars [23000;]);(`Uchars [23142;]);
(`Uchars [14062;]);(`Uchars [14076;]);(`Uchars [23304;]);(`Uchars [23358;]);
(`Uchars [23358;]);(`Uchars [137672;]);(`Uchars [23491;]);(`Uchars [23512;]);
(`Uchars [23527;]);|];[|(`Uchars [23539;]);(`Uchars [138008;]);
(`Uchars [23551;]);(`Uchars [23558;]);(`Uchars [24403;]);(`Uchars [23586;]);
(`Uchars [14209;]);(`Uchars [23648;]);(`Uchars [23662;]);(`Uchars [23744;]);
(`Uchars [23693;]);(`Uchars [138724;]);(`Uchars [23875;]);
(`Uchars [138726;]);(`Uchars [23918;]);(`Uchars [23915;]);|];[|
(`Uchars [23932;]);(`Uchars [24033;]);(`Uchars [24034;]);(`Uchars [14383;]);
(`Uchars [24061;]);(`Uchars [24104;]);(`Uchars [24125;]);(`Uchars [24169;]);
(`Uchars [14434;]);(`Uchars [139651;]);(`Uchars [14460;]);(`Uchars [24240;]);
(`Uchars [24243;]);(`Uchars [24246;]);(`Uchars [24266;]);(`Uchars [172946;]);
|];[|(`Uchars [24318;]);(`Uchars [140081;]);(`Uchars [140081;]);
(`Uchars [33281;]);(`Uchars [24354;]);(`Uchars [24354;]);(`Uchars [14535;]);
(`Uchars [144056;]);(`Uchars [156122;]);(`Uchars [24418;]);
(`Uchars [24427;]);(`Uchars [14563;]);(`Uchars [24474;]);(`Uchars [24525;]);
(`Uchars [24535;]);(`Uchars [24569;]);|];[|(`Uchars [24705;]);
(`Uchars [14650;]);(`Uchars [14620;]);(`Uchars [24724;]);(`Uchars [141012;]);
(`Uchars [24775;]);(`Uchars [24904;]);(`Uchars [24908;]);(`Uchars [24910;]);
(`Uchars [24908;]);(`Uchars [24954;]);(`Uchars [24974;]);(`Uchars [25010;]);
(`Uchars [24996;]);(`Uchars [25007;]);(`Uchars [25054;]);|];[|
(`Uchars [25074;]);(`Uchars [25078;]);(`Uchars [25104;]);(`Uchars [25115;]);
(`Uchars [25181;]);(`Uchars [25265;]);(`Uchars [25300;]);(`Uchars [25424;]);
(`Uchars [142092;]);(`Uchars [25405;]);(`Uchars [25340;]);(`Uchars [25448;]);
(`Uchars [25475;]);(`Uchars [25572;]);(`Uchars [142321;]);(`Uchars [25634;]);
|];[|(`Uchars [25541;]);(`Uchars [25513;]);(`Uchars [14894;]);
(`Uchars [25705;]);(`Uchars [25726;]);(`Uchars [25757;]);(`Uchars [25719;]);
(`Uchars [14956;]);(`Uchars [25935;]);(`Uchars [25964;]);(`Uchars [143370;]);
(`Uchars [26083;]);(`Uchars [26360;]);(`Uchars [26185;]);(`Uchars [15129;]);
(`Uchars [26257;]);|];[|(`Uchars [15112;]);(`Uchars [15076;]);
(`Uchars [20882;]);(`Uchars [20885;]);(`Uchars [26368;]);(`Uchars [26268;]);
(`Uchars [32941;]);(`Uchars [17369;]);(`Uchars [26391;]);(`Uchars [26395;]);
(`Uchars [26401;]);(`Uchars [26462;]);(`Uchars [26451;]);(`Uchars [144323;]);
(`Uchars [15177;]);(`Uchars [26618;]);|];[|(`Uchars [26501;]);
(`Uchars [26706;]);(`Uchars [26757;]);(`Uchars [144493;]);(`Uchars [26766;]);
(`Uchars [26655;]);(`Uchars [26900;]);(`Uchars [15261;]);(`Uchars [26946;]);
(`Uchars [27043;]);(`Uchars [27114;]);(`Uchars [27304;]);(`Uchars [145059;]);
(`Uchars [27355;]);(`Uchars [15384;]);(`Uchars [27425;]);|];[|
(`Uchars [145575;]);(`Uchars [27476;]);(`Uchars [15438;]);(`Uchars [27506;]);
(`Uchars [27551;]);(`Uchars [27578;]);(`Uchars [27579;]);(`Uchars [146061;]);
(`Uchars [138507;]);(`Uchars [146170;]);(`Uchars [27726;]);
(`Uchars [146620;]);(`Uchars [27839;]);(`Uchars [27853;]);(`Uchars [27751;]);
(`Uchars [27926;]);|];[|(`Uchars [27966;]);(`Uchars [28023;]);
(`Uchars [27969;]);(`Uchars [28009;]);(`Uchars [28024;]);(`Uchars [28037;]);
(`Uchars [146718;]);(`Uchars [27956;]);(`Uchars [28207;]);(`Uchars [28270;]);
(`Uchars [15667;]);(`Uchars [28363;]);(`Uchars [28359;]);(`Uchars [147153;]);
(`Uchars [28153;]);(`Uchars [28526;]);|];[|(`Uchars [147294;]);
(`Uchars [147342;]);(`Uchars [28614;]);(`Uchars [28729;]);(`Uchars [28702;]);
(`Uchars [28699;]);(`Uchars [15766;]);(`Uchars [28746;]);(`Uchars [28797;]);
(`Uchars [28791;]);(`Uchars [28845;]);(`Uchars [132389;]);(`Uchars [28997;]);
(`Uchars [148067;]);(`Uchars [29084;]);(`Uchars [148395;]);|];[|
(`Uchars [29224;]);(`Uchars [29237;]);(`Uchars [29264;]);(`Uchars [149000;]);
(`Uchars [29312;]);(`Uchars [29333;]);(`Uchars [149301;]);
(`Uchars [149524;]);(`Uchars [29562;]);(`Uchars [29579;]);(`Uchars [16044;]);
(`Uchars [29605;]);(`Uchars [16056;]);(`Uchars [16056;]);(`Uchars [29767;]);
(`Uchars [29788;]);|];[|(`Uchars [29809;]);(`Uchars [29829;]);
(`Uchars [29898;]);(`Uchars [16155;]);(`Uchars [29988;]);(`Uchars [150582;]);
(`Uchars [30014;]);(`Uchars [150674;]);(`Uchars [30064;]);
(`Uchars [139679;]);(`Uchars [30224;]);(`Uchars [151457;]);
(`Uchars [151480;]);(`Uchars [151620;]);(`Uchars [16380;]);
(`Uchars [16392;]);|];[|(`Uchars [30452;]);(`Uchars [151795;]);
(`Uchars [151794;]);(`Uchars [151833;]);(`Uchars [151859;]);
(`Uchars [30494;]);(`Uchars [30495;]);(`Uchars [30495;]);(`Uchars [30538;]);
(`Uchars [16441;]);(`Uchars [30603;]);(`Uchars [16454;]);(`Uchars [16534;]);
(`Uchars [152605;]);(`Uchars [30798;]);(`Uchars [30860;]);|];[|
(`Uchars [30924;]);(`Uchars [16611;]);(`Uchars [153126;]);(`Uchars [31062;]);
(`Uchars [153242;]);(`Uchars [153285;]);(`Uchars [31119;]);
(`Uchars [31211;]);(`Uchars [16687;]);(`Uchars [31296;]);(`Uchars [31306;]);
(`Uchars [31311;]);(`Uchars [153980;]);(`Uchars [154279;]);
(`Uchars [154279;]);(`Uchars [31470;]);|];[|(`Uchars [16898;]);
(`Uchars [154539;]);(`Uchars [31686;]);(`Uchars [31689;]);(`Uchars [16935;]);
(`Uchars [154752;]);(`Uchars [31954;]);(`Uchars [17056;]);(`Uchars [31976;]);
(`Uchars [31971;]);(`Uchars [32000;]);(`Uchars [155526;]);(`Uchars [32099;]);
(`Uchars [17153;]);(`Uchars [32199;]);(`Uchars [32258;]);|];[|
(`Uchars [32325;]);(`Uchars [17204;]);(`Uchars [156200;]);
(`Uchars [156231;]);(`Uchars [17241;]);(`Uchars [156377;]);
(`Uchars [32634;]);(`Uchars [156478;]);(`Uchars [32661;]);(`Uchars [32762;]);
(`Uchars [32773;]);(`Uchars [156890;]);(`Uchars [156963;]);
(`Uchars [32864;]);(`Uchars [157096;]);(`Uchars [32880;]);|];[|
(`Uchars [144223;]);(`Uchars [17365;]);(`Uchars [32946;]);(`Uchars [33027;]);
(`Uchars [17419;]);(`Uchars [33086;]);(`Uchars [23221;]);(`Uchars [157607;]);
(`Uchars [157621;]);(`Uchars [144275;]);(`Uchars [144284;]);
(`Uchars [33281;]);(`Uchars [33284;]);(`Uchars [36766;]);(`Uchars [17515;]);
(`Uchars [33425;]);|];[|(`Uchars [33419;]);(`Uchars [33437;]);
(`Uchars [21171;]);(`Uchars [33457;]);(`Uchars [33459;]);(`Uchars [33469;]);
(`Uchars [33510;]);(`Uchars [158524;]);(`Uchars [33509;]);(`Uchars [33565;]);
(`Uchars [33635;]);(`Uchars [33709;]);(`Uchars [33571;]);(`Uchars [33725;]);
(`Uchars [33767;]);(`Uchars [33879;]);|];[|(`Uchars [33619;]);
(`Uchars [33738;]);(`Uchars [33740;]);(`Uchars [33756;]);(`Uchars [158774;]);
(`Uchars [159083;]);(`Uchars [158933;]);(`Uchars [17707;]);
(`Uchars [34033;]);(`Uchars [34035;]);(`Uchars [34070;]);(`Uchars [160714;]);
(`Uchars [34148;]);(`Uchars [159532;]);(`Uchars [17757;]);(`Uchars [17761;]);
|];[|(`Uchars [159665;]);(`Uchars [159954;]);(`Uchars [17771;]);
(`Uchars [34384;]);(`Uchars [34396;]);(`Uchars [34407;]);(`Uchars [34409;]);
(`Uchars [34473;]);(`Uchars [34440;]);(`Uchars [34574;]);(`Uchars [34530;]);
(`Uchars [34681;]);(`Uchars [34600;]);(`Uchars [34667;]);(`Uchars [34694;]);
(`Uchars [17879;]);|];[|(`Uchars [34785;]);(`Uchars [34817;]);
(`Uchars [17913;]);(`Uchars [34912;]);(`Uchars [34915;]);(`Uchars [161383;]);
(`Uchars [35031;]);(`Uchars [35038;]);(`Uchars [17973;]);(`Uchars [35066;]);
(`Uchars [13499;]);(`Uchars [161966;]);(`Uchars [162150;]);
(`Uchars [18110;]);(`Uchars [18119;]);(`Uchars [35488;]);|];[|
(`Uchars [35565;]);(`Uchars [35722;]);(`Uchars [35925;]);(`Uchars [162984;]);
(`Uchars [36011;]);(`Uchars [36033;]);(`Uchars [36123;]);(`Uchars [36215;]);
(`Uchars [163631;]);(`Uchars [133124;]);(`Uchars [36299;]);
(`Uchars [36284;]);(`Uchars [36336;]);(`Uchars [133342;]);(`Uchars [36564;]);
(`Uchars [36664;]);|];[|(`Uchars [165330;]);(`Uchars [165357;]);
(`Uchars [37012;]);(`Uchars [37105;]);(`Uchars [37137;]);(`Uchars [165678;]);
(`Uchars [37147;]);(`Uchars [37432;]);(`Uchars [37591;]);(`Uchars [37592;]);
(`Uchars [37500;]);(`Uchars [37881;]);(`Uchars [37909;]);(`Uchars [166906;]);
(`Uchars [38283;]);(`Uchars [18837;]);|];[|(`Uchars [38327;]);
(`Uchars [167287;]);(`Uchars [18918;]);(`Uchars [38595;]);(`Uchars [23986;]);
(`Uchars [38691;]);(`Uchars [168261;]);(`Uchars [168474;]);
(`Uchars [19054;]);(`Uchars [19062;]);(`Uchars [38880;]);(`Uchars [168970;]);
(`Uchars [19122;]);(`Uchars [169110;]);(`Uchars [38923;]);(`Uchars [38923;]);
|];[|(`Uchars [38953;]);(`Uchars [169398;]);(`Uchars [39138;]);
(`Uchars [19251;]);(`Uchars [39209;]);(`Uchars [39335;]);(`Uchars [39362;]);
(`Uchars [39422;]);(`Uchars [19406;]);(`Uchars [170800;]);(`Uchars [39698;]);
(`Uchars [40000;]);(`Uchars [40189;]);(`Uchars [19662;]);(`Uchars [19693;]);
(`Uchars [40295;]);|];[|(`Uchars [172238;]);(`Uchars [19704;]);
(`Uchars [172293;]);(`Uchars [172558;]);(`Uchars [172689;]);
(`Uchars [40635;]);(`Uchars [19798;]);(`Uchars [40697;]);(`Uchars [40702;]);
(`Uchars [40709;]);(`Uchars [40719;]);(`Uchars [40726;]);(`Uchars [40763;]);
(`Uchars [173568;]);`Self;`Self;|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;[|[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];[|(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);
(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);(`Uchars []);|];|];nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;|]}
open Uucp_tmapbool
let changes_when_casefolded_map = { default = false; l0 = [|[|
"\x00\x00\x00\x00\x00\x00\x00\x00\xFE\xFF\xFF\x07\x00\x00\x00\x00\
 \x00\x00\x00\x00\x01\xA5\x3C\x77\xFF\xFF\x7F\xFF\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\x55\x55\x55\x55\x55\x55\x5D\xAA\xAB\x56\x55\x55\x55\x55\x55\xAB\
 \xD6\xCE\xDB\xB1\xD5\xD2\xAE\x11\xF0\xBF\xAA\x4A\x55\x55\xDE\x55\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\x55\x55\x55\x55\x55\x55\x05\x6C\x7A\x55\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\xFF\x01\x00\x00\x00\x3F\x1F\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\x00\x00\x00\x00\x00\x00\x00\x00\x3B\x80\x00\x00\x00\x00\x55\xC4\
 \xF0\xD7\xFE\xFF\xFB\x0F\x00\x00\x04\x80\x7F\x55\x55\x55\xB7\xE6\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xFF\xFF\xFF\xFF\xFF\xFF\x00\x00\x00\x00\x00\x00\x55\x55\x55\x55\
 \x01\x54\x55\x55\x55\x55\x55\x55\xAB\x2A\x55\x55\x55\x55\x55\x55\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\x55\x55\x55\x55\x55\x55\xFE\xFF\xFF\xFF\x7F\x00\x00\x00\x00\x00\
 \x80\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\x00\x00\x00\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xE0\x01\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";snil;snil;
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xFF\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xB0\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\x00\x00\x00\x00\x00\x00\x48\x00\x00\x00\x00\x4E\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x30\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";snil;snil;
"\x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x08\x00\x00\x00\x00\x30\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\x00\x10\x00\x00\x00\x00\x00\x00\x08\x20\x84\x10\x00\x02\xE8\x03\
 \x02\x00\x08\x20\x84\x10\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";|];[|
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\xFF\xFF\xFF\xFF\xBF\x20\x00\x00\x00\x00\x00\x10\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x80\x01\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";snil;
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x3F\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";snil;snil;
snil;
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x30\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\x00\x78\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";snil;snil;
snil;snil;
"\x00\x00\x00\x00\x00\x70\xFF\xF7\xFF\xBF\xFF\xFF\xFF\x07\x00\x01\
 \x00\x00\x00\xF8\xFF\xFF\xFF\xFF\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\
 \x55\x55\x15\x4C\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\x00\xFF\x00\x3F\x00\xFF\x00\xFF\x00\x3F\x00\xAA\x00\xFF\xAA\x2A\
 \xFF\xFF\xFF\xFF\xFF\xFF\x9C\xFF\x9F\xFF\x08\xEF\x08\xFF\x9C\x7F\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";|];[|
"\xFF\xFF\x82\x00\x70\xFC\xD8\x50\x80\x03\x80\x80\xFF\xFF\xF3\xFF\
 \xFF\x7F\xFF\x1F\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xEF\xFE\x6F\x3E\x57\xBD\xFF\xFB\xE1\x03\xFF\xFF\xFF\xFF\xFF\xFF\
 \x08\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\x00\x00\x00\x00\x00\xB0\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\x00\x00\x00\x00\x00\x06\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\x07\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";snil;snil;
snil;snil;snil;
"\x00\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x70\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x10\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";snil;
"\xFF\xFF\xFF\xFF\xFF\x7F\x00\x00\x00\x00\x00\x00\x9D\xEA\x25\xF0\
 \x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x05\x28\x04\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x80\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x80\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x08\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\x3F\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";|];[|
"\x01\x00\x00\x00\x00\x00\x40\x07\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x98\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x80\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\x00\x00\x00\x00\x00\x00\xFE\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \xFF\x7F\xFC\xFF\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xFF\xFF\xFF\x7F\xFF\xFF\xFF\xFF\xFF\x00\xFF\xFF\xFF\xFF\xFF\x7F\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\x7F\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";snil;snil;
snil;snil;snil;snil;snil;snil;snil;snil;snil;snil;|];nil;nil;nil;nil;nil;nil;
[|snil;snil;snil;snil;snil;snil;
"\x00\x00\x00\x00\x00\x00\x00\x00\x55\x55\x55\x55\x55\x15\x00\x00\
 \x55\x55\x55\x35\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\x00\x00\x00\x00\x54\x55\x54\x55\x55\x55\x55\x55\x55\x55\x01\x6A\
 \x55\x28\x45\x55\x55\x3D\x5F\x00\x00\x00\x00\x00\x00\x00\x00\x03\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";snil;snil;
snil;
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xF0\x00\x00\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";snil;snil;
snil;snil;|];nil;nil;nil;nil;[|snil;snil;snil;snil;snil;snil;snil;snil;snil;
"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xFF\x3F\xE5\x7F\x65\xFC\xFF\xFF\xFF\xFF\xFF\xFF\xFF\x3F\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\x03\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\x7F\x00\xF8\xA0\xFF\xFF\x7F\x5F\xDB\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\x03\x00\x00\x00\xF8\xFF\xFF\xFF\xFF\xFF\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\x3F\x00\x00\xFF\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFC\xFF\xFF\xFF\xFF\xFF\xFF\x00\x00\x00\x00\x00\xFF\x1F\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xFF\xFF\xFF\x03\x00\x00\xFF\xFF\x9F\xFF\xF7\xFF\x7F\x0F\xD7\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\x9F\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xFE\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\x7F\xFC\xFC\xFC\x1C\x7F\x7F\xFF\x01\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";|];[|snil;
snil;snil;snil;
"\xFF\xFF\xFF\xFF\xFF\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";snil;snil;
snil;snil;snil;snil;snil;
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \xFF\xFF\xFF\xFF\xFF\xFF\x07\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";snil;snil;
snil;|];[|snil;snil;snil;snil;snil;snil;snil;snil;
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\xFF\xFF\xFF\xFF\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";snil;snil;
snil;snil;snil;snil;snil;|];nil;nil;nil;nil;nil;nil;nil;nil;nil;[|snil;snil;
snil;snil;snil;snil;snil;snil;snil;snil;snil;snil;
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x0F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";snil;snil;
snil;|];nil;[|snil;
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xC0\x1F\x00\xF8\x07\
 \x00\x00\x00\x00\x00\x00\x00\xF8\x01\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";snil;snil;
"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xDF\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xDF\x64\xDE\xFF\xEB\xEF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xBF\xE7\xDF\xDF\xFF\xFF\xFF\x7B\x5F\xFC\xFD\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xFF\x3F\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xCF\xFF\xFF\xFF\xFF\xFF\xFF\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";snil;snil;
snil;snil;snil;snil;snil;snil;|];[|snil;snil;snil;snil;snil;snil;snil;snil;
snil;snil;snil;snil;snil;snil;
"\xEF\xFF\xFF\xFF\x96\xFE\xF7\x0A\x84\xEA\x96\xAA\x96\xF7\xF7\x5E\
 \xFF\xFB\xFF\x0F\xEE\xFB\xFF\x0F\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";snil;|];[|
snil;
"\xFF\x07\xFF\xFF\xFF\x7F\xFF\xFF\xFF\xFF\x00\x00\x00\x0C\x00\x00\
 \x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\x07\x00\xFF\xFF\xFF\xFF\xFF\x07\xFF\x01\x03\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";snil;snil;
snil;snil;snil;snil;snil;snil;snil;snil;snil;snil;snil;|];nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;[|snil;snil;snil;snil;snil;snil;
snil;snil;
"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xFF\xFF\xFF\x3F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";snil;snil;
snil;snil;snil;|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;[|
"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
 \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";|];nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;|]}


(*---------------------------------------------------------------------------
   Copyright (c) 2014 Daniel C. Bünzli.
   All rights reserved.

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:

   1. Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

   3. Neither the name of Daniel C. Bünzli nor the names of
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
   OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
   THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
   (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
   OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  ---------------------------------------------------------------------------*)
