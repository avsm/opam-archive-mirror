Doubledouble
============

OCaml API to work with doubledouble floating point values (higher-precision
than double arithmetic).

Code is translated from [DD](http://tsusiatsoftware.net/dd/main.html) by Martin Davis.
See [tsusiatsoftware](http://tsusiatsoftware.net) for more information.

Licensed under ISC.

Installation
------------

Just run `make install` assuming you have a working ocaml/ocamlfind setup.
