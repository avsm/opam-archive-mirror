BUILD INSTRUCTIONS
==================

Build
-----

This package does not have dependencies, just do:

    make build

Install
-------

You can install the library with `ocamlfind`:

    make install

You may want to control the destination with the variable
`OCAMLFIND_DESTDIR`.

Uninstall
---------

You can uninstall the library (also `ocamlfind`):

    make uninstall


