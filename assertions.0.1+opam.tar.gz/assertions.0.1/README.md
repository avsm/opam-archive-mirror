assertions
==========

Simple assertions library for OCaml.
