fun input output -> find_in "- : string =" output
