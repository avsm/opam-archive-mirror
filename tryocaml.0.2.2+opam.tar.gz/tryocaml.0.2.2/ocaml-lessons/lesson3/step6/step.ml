fun _ output ->
  find_in  "- : unit = ()" output
