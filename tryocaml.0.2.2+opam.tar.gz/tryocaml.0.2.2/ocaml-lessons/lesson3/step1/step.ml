fun _ output ->
  find_in  "- : int = 15" output
