fun input output ->
  find_in  "string_of_int : int -> string =" output
