fun input output ->
  find_in "while" input

