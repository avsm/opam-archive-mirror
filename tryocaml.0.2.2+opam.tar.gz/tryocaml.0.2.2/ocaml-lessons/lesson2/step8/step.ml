fun input output ->
  find_in " : unit" output && find_in "next" input

