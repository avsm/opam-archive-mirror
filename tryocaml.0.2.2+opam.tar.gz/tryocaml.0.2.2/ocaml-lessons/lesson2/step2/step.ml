fun input output ->
  find_in " : int = " output && find_in " !" input

