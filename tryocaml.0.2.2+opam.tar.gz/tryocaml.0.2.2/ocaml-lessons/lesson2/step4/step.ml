fun input output ->
  find_in "4; 5" output && find_in " downto" input

