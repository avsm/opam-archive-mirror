fun input output ->
  find_in " : int = 100" output


