
fun input output ->  find_in "let open " input


