
fun input output -> find_in "val depth : 'a t -> int" output


