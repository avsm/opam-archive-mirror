fun input output -> find_in "val vect : " output


