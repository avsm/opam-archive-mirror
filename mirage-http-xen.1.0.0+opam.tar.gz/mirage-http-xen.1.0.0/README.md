mirage-http-xen
=================

Xen implementation of the Mirage HTTP client and server.  Based on the
[Cohttp](http://github.com/mirage/ocaml-cohttp) HTTP implementation,
and uses the [mirage-tcpip](http://github.com/mirage/mirage-tcpip)
networking stack.

E-mail: <mirageos-devel@lists.xenproject.org>
