0.7.0 (2016-03-13)
- depend on cstruct.ppx (from >= 1.9.0) rather than cstruct.syntax
- improve usage instructions
