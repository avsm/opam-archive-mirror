module Stream = CFStream_stream
module Streamable = CFStream_streamable
