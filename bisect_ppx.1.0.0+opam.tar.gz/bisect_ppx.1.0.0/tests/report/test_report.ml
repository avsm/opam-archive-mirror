(*
 * This file is part of Bisect_ppx.
 * Copyright (C) 2016 Anton Bachin.
 *
 * Bisect is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Bisect is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

open OUnit2
open Test_helpers

let test name f =
  test name begin fun () ->
    compile (with_bisect_args "-inexhaustive-matching") "report/source.ml";
    run "./a.out -inf 0 -sup 3 > /dev/null";
    run "./a.out -inf 7 -sup 11 > /dev/null";
    f ()
  end

let tests = "report" >::: [
  test "bisect" (fun () ->
    report "-bisect output";
    diff "report/reference.bisect");

  test "csv" (fun () ->
    report "-csv output";
    diff "report/reference.csv");

  test "dtd" (fun () ->
    report "-dump-dtd output";
    diff "report/reference.dtd");

  test "dump" (fun () ->
    report "-dump output";
    diff "report/reference.dump");

  test "html" (fun () ->
    report "-html html_dir";
    run "grep -v 'id=\"footer\"' html_dir/file0000.html > output";
    diff "report/reference.html");

  test "text" (fun () ->
    report "-text output";
    diff "report/reference.text");

  test "xml" (fun () ->
    report "-xml -" ~r:"| grep -v '<!--.*Bisect' > output";
    diff "report/reference.xml");

  test "xml-emma" (fun () ->
    report "-xml-emma -" ~r:"| grep -v '<!--.*Bisect' > output";
    diff "report/reference.xml-emma");

  test "xml.lint" (fun () ->
    report "-xml report.xml";
    report "-dump-dtd report.dtd";
    xmllint "--noout --dtdvalid report.dtd report.xml";
    report "-xml-emma report.xml-emma";
    xmllint "--noout report.xml-emma")
]
