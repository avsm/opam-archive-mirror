declare function foo(x: number): Array;
