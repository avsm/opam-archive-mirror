var qux = require('./optional');

qux(0);
