class C {
    x: ?number|string;
    constructor() {
        this.x = null;
    }
}
