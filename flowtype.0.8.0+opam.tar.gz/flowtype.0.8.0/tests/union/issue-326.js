var numberAndStringArr:Array<number|string> = [1,2];
var stringArr:Array<string> = ['a','b'];

var result = numberAndStringArr.concat(stringArr);  // no error
