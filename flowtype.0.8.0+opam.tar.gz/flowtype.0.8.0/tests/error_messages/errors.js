if (typeof define === 'function' && define.amd) { }

Object(0);
