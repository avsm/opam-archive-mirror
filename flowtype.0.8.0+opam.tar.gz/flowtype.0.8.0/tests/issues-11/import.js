/* @flow */
var e = require('./export');
var x: string = e.x;
var y: number = e.y;
