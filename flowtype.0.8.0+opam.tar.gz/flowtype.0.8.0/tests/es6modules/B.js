/* @flow */

exports.numberValue = 42;
