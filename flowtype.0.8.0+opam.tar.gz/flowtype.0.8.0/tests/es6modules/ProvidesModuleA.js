/**
 * @providesModule A
 * @flow
 */

exports.numberValue1 = 42;
exports.numberValue2 = 42;
exports.numberValue3 = 42;
exports.numberValue4 = 42;
exports.stringValue = "str";
