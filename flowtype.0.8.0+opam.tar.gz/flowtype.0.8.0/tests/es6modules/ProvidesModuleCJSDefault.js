/**
 * @providesModule CJSDefault
 * @flow
 */

module.exports = {
  numberValue: 42
};
