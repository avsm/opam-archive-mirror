/**
 * @providesModule ES6_Default_AnonFunction2
 * @flow
 */

export default function():number { return 42; }
