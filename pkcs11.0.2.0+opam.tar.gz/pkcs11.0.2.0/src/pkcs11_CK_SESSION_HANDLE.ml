type t = Pkcs11_CK_ULONG.t
let typ = Ctypes.ulong
