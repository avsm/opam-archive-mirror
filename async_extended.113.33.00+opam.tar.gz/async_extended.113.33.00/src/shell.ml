(* For backward compatibility. *)
include Async_shell
