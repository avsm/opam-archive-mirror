let package_name = "async_extended"

let sections =
  [ ("lib",
    [ ("built_lib_async_extended", None)
    ],
    [ ("META", None)
    ])
  ]
