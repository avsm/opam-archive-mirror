#!/usr/bin/env bash

corebuild display.native
cp display.native planets
