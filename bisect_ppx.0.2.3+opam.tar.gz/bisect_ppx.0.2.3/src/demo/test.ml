
open Actors

let () =
  print_endline (message Cleopatra);
  print_endline (message Anthony);
