let package_name = "bignum"

let sections =
  [ ("lib",
    [ ("built_lib_bignum", None)
    ],
    [ ("META", None)
    ])
  ]
