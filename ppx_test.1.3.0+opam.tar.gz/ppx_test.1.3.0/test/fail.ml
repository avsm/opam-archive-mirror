module PTest = Ppx_test.Test

[%%TEST_FAIL let x = raise Exit]
[%%TEST
 let x_fail = raise Exit
]

(* Tests are executed by calling [PTest.collect ()] *)      
let () = PTest.collect ()
