module A = App.Make(HardCamlExamples.Lfsr.Design)

