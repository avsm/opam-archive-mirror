module A = App.Make(HardCamlExamples.Rac.Design)

