module A = App.Make(HardCamlExamples.Prefix.Design)

