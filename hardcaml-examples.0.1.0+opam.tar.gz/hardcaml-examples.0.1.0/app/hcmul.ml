module A = App.Make(HardCamlExamples.Mul.Design)

