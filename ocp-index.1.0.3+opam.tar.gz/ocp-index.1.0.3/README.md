ocp-index is a light-weight tool and library providing easy access to the information contained in your OCaml cmi/cmt/cmti files.
It can be used to provide features like library interface browsing, auto-completion, show-type and goto-source.

ocp-index is part of TypeRex, developed and maintained by OCamlPro. Documentation to install and use this tool is available on http://www.typerex.org/ocp-index.html

It is released under LGPL v3 with linking exception.
