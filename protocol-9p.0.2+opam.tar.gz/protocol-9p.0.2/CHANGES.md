0.2 (04-Jan-2015)
- respect negotiated msize in read
- add LICENSE file

0.1 (13-Dec-2015)
- initial version
