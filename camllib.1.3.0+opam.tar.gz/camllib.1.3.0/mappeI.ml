(** Mappe specialized for keys of type int *)

include Mappe.Make(SetteI)


