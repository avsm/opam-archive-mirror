# HardCaml Verilog interface

Builds a shared library which can be loaded into the Icarus Verilog
simulator to communicate with HardCaml.  This allows an HardCaml/OCaml 
based testbench to interact with a Verilog based model.
