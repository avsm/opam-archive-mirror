LD_LIBRARY_PATH=`ocamlc -where` vvp -M`opam config var lib`/hardcaml -mcosim $1
