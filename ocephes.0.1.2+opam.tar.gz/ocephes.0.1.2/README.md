# Ocephes

Bindings to special math functions from the [Cephes](http://www.netlib.org/cephes/) library.

# Note

Stephen L. Moshier has granted permission for this code to be released under
the BSD license, [email](Mosher.txt).
All of the `C` code in this repository is Stephen L. Moshier's.
