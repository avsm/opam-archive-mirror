Version 0.1.2 (2015-10-23):
---------------------------
  - carm <carmelo.piccione@gmail.com> added power and a merlin file
  
Version 0.1.1 (2015-08-07):
---------------------------
  - Ocephes first released to opam
