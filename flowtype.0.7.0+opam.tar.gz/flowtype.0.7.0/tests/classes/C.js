var B = require('./B');

class C extends B {
  foo(x:string):void { }
}

module.exports = C;
