/**
 * @providesModule C
 * @flow
 */

module.exports = require('B');
