var B = require('./B');

class A extends B { }

module.exports = A;
