/**
 * @providesModule ES6_ExportFrom_Intermediary1
 * @flow
 */

export {
  numberValue1,
  numberValue2 as numberValue2_renamed
} from "ES6_ExportFrom_Source1";
