/**
 * @providesModule ES6_ExportFrom_Source2
 * @flow
 */

export var numberValue1 = 1, numberValue2 = 2;
