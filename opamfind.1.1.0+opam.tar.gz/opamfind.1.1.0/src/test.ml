let () =
(*
  Opam.test ();
  Ocamlfind.test ();
*)
  Assoc.test ()
    
    
