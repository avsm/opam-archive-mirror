int main (char arg[]) {
    int i = strlen(arg) - 10;
    return i;
}
