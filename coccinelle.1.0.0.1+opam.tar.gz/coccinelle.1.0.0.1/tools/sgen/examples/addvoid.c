/* A function with no arguments. */
int main() {
    return 1;
}

/* A function prototype */
void function();

/* The body of the declared function */
void function() {
    return;
}
