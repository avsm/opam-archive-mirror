void main(int i) {

    g(1);
    f(2);

    h(2);
    h2(2);
    h(3)

    foo(1);
}
