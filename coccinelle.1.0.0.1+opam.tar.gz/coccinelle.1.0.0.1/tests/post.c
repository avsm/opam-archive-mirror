int main() {
  f(3, foo + bar, 5);
  f(4, 3, 5);
  f(4, 3, 5);
  h(3, some + thing, 5);
  h(4, 3, 5);
  h(4, 3, 5);
}
