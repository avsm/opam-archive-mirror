static inline int i8042_read_data(void)
{
	return jazz_kh->data;
}
