struct ty x[] = {
  {
 a,
  }};
