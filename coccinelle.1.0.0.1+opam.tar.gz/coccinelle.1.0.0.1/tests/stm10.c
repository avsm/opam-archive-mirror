int main(int x) {
  f();
  if (x) replace();
  g();
  if (x) replace();
}
