int xbar(void) { return; }

// this is some info about bar

int bar(void) { return; }
