int f(int, int, int x) {
  return x;
}
