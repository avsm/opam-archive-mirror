static void ewx_i2c_setlines(snd_i2c_bus_t *bus, int clk, int data)
{
	ice1712_t *ice = snd_magic_cast(ice1712_t, bus->private_data, return);
	ice1712_t *ice = snd_magic_cast(ice1712_t, bus->private_data, );
	unsigned char tmp = 0;
        tmp++;
}
