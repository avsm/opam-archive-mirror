
int main(void) {

int t0 = FOO;
int t1 = BAR;
int t2 = FOOBAR;
int t3 = BARFOOBAR;
int t4 = BARFOO;

}
