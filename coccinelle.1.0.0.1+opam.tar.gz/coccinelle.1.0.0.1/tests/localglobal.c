int a;

int main(int b) {
  int c;
  int local;
  return a + b + c;
}
