#define foo 12
#undef foo
