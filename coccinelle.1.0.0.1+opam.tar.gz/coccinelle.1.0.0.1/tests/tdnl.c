void main() {
  unknown_tyepdef_1 td1;
  td1.attr = (unknown_typedef_2)
    

    td2.attr;
  foo();
}
