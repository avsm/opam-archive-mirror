int main () {
  f(c);
  g();
}
