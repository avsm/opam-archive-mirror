struct one x;

struct two y;

struct three z;
