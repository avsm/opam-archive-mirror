void main(int i) {
  
  if (!hostptr) {
    i++;
  }
}
