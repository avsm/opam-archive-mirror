int main () {
  foo(x + y);
}
