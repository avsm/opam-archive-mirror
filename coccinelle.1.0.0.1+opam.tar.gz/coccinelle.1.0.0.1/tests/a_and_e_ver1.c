void main(int i) {

  g();
  if(1) 
    f(1,2);
  else 
    f(2,2);

  // return 1;
}
