int main() {
  f(3);
  g(0x03);
}
