int main () {
  struct foo *x;
  return (struct blah *)x;
}
