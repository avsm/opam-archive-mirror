int main()
{
  int a, b;
  a <? b;
  a <?= b;
  a >? b;
  a >?= b;
}
