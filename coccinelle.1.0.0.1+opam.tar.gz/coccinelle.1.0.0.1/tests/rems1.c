int main () {
  x();
  a();
  y();
}
