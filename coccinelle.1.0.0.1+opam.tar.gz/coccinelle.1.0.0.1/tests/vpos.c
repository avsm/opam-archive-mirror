int main() {
  f(2);
  if (x) {
    g(1,1);
  }
  else {
    g(1,2);
  }
}
