### opamconfig_conf.sh -- Configuration for opamconfig testtool

# opamconfig (https://github.com/michipili/opamconfig)
# This file is part of opamconfig
#
# Copyright © 2016 Michael Grünewald
#
# This file must be used under the terms of the MIT license.
# This source file is licensed as described in the file LICENSE, which
# you should have received as part of this distribution. The terms
# are also available at
# https://opensource.org/licenses/MIT

: ${ac_path_brew:=no}
: ${ac_path_pip:=/opt/local/bin/pip}
: ${ac_path_pkg:=no}
: ${ac_path_port:=/opt/local/bin/port}
: ${ac_path_ocamlfind:=/opt/opam/4.02.3/bin/ocamlfind}

### End of file `opmaconfig_conf.sh'
