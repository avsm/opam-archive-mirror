include Core_kernel.Memo
