include Core_kernel.Equal
