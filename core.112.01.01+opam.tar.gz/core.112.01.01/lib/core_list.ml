include Core_kernel.Core_list

let to_sequence = Core_kernel.Sequence.of_list
