include Core_kernel.Option
