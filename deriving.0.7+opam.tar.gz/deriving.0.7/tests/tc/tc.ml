

type t = A of int | B of float with show
