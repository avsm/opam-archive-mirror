open Alcotest

let b_tree_tests =
    [
    ]

let () =
  Alcotest.run "BTree Tests" [
    "BTree Tests", b_tree_tests
  ]
