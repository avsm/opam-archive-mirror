# mirage-btrees

[![Build Status](https://travis-ci.org/ruhatch/mirage-btrees.svg?branch=master)](https://travis-ci.org/ruhatch/mirage-btrees)

An implementation of BTrees designed to be used with MirageOS
