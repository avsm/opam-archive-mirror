type t =
  | String of string
  | Number of float (* CR jfuruse: BUG: It cannot carry full int64 value. *)
  | Object of obj
  | Array of t list
  | Bool of bool
  | Null

and obj = (string * t) list

