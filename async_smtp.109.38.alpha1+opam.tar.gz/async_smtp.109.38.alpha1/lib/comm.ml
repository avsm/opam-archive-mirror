type t =
  | Hello of string
  | Sender of string
  | Receiver of string
  | Data
  | Quit
  | Help
  | Noop
