Xen grant table bindings for OCaml.
