open Math.Types

let make_real x = { real = x; imag = 0 }
