include Core_kernel.Fqueue
