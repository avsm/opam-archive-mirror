
let world = World.create()
let _ =
  Printf.printf "hello %s!\n" (World.to_string world)
