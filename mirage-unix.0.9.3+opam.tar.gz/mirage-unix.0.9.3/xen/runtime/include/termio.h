/* this looks horribly wrong, but glibc does it like that */

#include <termios.h>
#include <sys/ioctl.h>
