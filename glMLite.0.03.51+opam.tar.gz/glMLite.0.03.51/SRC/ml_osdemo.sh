ocaml -I ~/Documents/prog/ocaml/GFX/glMLite/SRC/ GL.cma  bigarray.cma OSMesa.cma Glu.cma osdemo.ml t2.tga ; display t2.tga
