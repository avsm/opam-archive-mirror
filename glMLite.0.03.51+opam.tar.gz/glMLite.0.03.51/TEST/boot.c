/* main on C side */

#include <caml/callback.h>

int main(int argc, char **argv)
{
  caml_main(argv);
}

