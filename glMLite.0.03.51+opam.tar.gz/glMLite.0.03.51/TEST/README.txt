
To compile and run the default demo, you can just run:
  make

To compile and run another demo, call make with DEMO defined with the source file,
for example:
  make DEMO=outline.ml

You can run some of the demo in the interpreted mode with thier associated .sh scripts.

