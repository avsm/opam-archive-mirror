make LablGL.cma
ocaml LablGL.cma -I ../SRC/ GL.cma Glu.cma Glut.cma  $1
