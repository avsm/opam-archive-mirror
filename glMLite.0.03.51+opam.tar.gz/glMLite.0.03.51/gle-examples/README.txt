The demos in this directory are some of the examples
provided with the gle library converted from C to OCaml.
The original examples are provided under Artistic License.
A copy of this license is in COPYING.artistic
COPYING.artistic
