print_string(String.capitalize Sys.argv.(1))
