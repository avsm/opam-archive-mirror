The files in this directory are supposed to be "forward compatible"
with OpenGL 3.X.

You can run or compile the 2 examples ogl3_vbo.ml and ogl3_vao.ml
with the following commands:

sh run.sh ogl3_vbo.ml
sh find.sh ogl3_vbo.ml
sh comp.sh ogl3_vbo.ml

sh run.sh ogl3_vao.ml
sh find.sh ogl3_vao.ml
sh comp.sh ogl3_vao.ml

