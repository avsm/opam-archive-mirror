ocaml -I ../SRC/ GL.cma Glu.cma Glut.cma bigarray.cma vertArray.cma aapoly.ml
