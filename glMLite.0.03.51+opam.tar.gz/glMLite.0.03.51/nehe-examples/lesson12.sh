ocaml -I +glMLite GL.cma Glu.cma Glut.cma png_loader.cma lesson12.ml
