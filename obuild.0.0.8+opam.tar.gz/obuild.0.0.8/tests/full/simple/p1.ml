let inc a = a + 1
