v0.7.0 2015-09-17 Cambridge (UK)
--------------------------------

First Release.
