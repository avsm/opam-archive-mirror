(**************************************************************************)
(*                                                                        *)
(*                          Alt-Ergo Zero                                 *)
(*                                                                        *)
(*                  Sylvain Conchon and Alain Mebsout                     *)
(*                      Universite Paris-Sud 11                           *)
(*                                                                        *)
(*  Copyright 2011. This file is distributed under the terms of the       *)
(*  Apache Software License version 2.0                                   *)
(*                                                                        *)
(**************************************************************************)

module type S = Solver_intf.S

module DummyTheory(F : Formula_intf.S) = struct
  (* We don't have anything to do since the SAT Solver already
   * does propagation and conflict detection *)

  type formula = F.t
  type proof = F.proof
  type level = unit

  let dummy = ()
  let current_level () = ()
  let assume _ = Theory_intf.Sat
  let backtrack _ = ()
  let if_sat _ = ()
end

module Plugin(E : Formula_intf.S)
    (Th : Theory_intf.S with type formula = E.t and type proof = E.proof) = struct

  type term = E.t
  type formula = E.t
  type proof = Th.proof
  type level = Th.level

  let dummy = Th.dummy

  let current_level = Th.current_level

  let assume_get s i =
    match s.Plugin_intf.get i with
    | Plugin_intf.Lit f -> f
    | _ -> assert false

  let mk_slice s = {
      Theory_intf.start = s.Plugin_intf.start;
      length = s.Plugin_intf.length;
      get = assume_get s;
      push = s.Plugin_intf.push;
    }

  let assume s = Th.assume (mk_slice s)

  let backtrack = Th.backtrack

  let if_sat s = Th.if_sat (mk_slice s)


  (* McSat specific functions *)
  let assign _ = assert false

  let iter_assignable _ _ = ()

  let eval _ = Plugin_intf.Unknown

end


module Make (E : Formula_intf.S)
    (Th : Theory_intf.S with type formula = E.t and type proof = E.proof)
    (Dummy: sig end) =
  External.Make
    (Solver_types.SatMake(E)(struct end))
    (Plugin(E)(Th))
    (struct end)


