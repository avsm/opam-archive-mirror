(******************************************************************************)
(*     The Alt-Ergo theorem prover                                            *)
(*     Copyright (C) 2006-2013                                                *)
(*     CNRS - INRIA - Universite Paris Sud                                    *)
(*                                                                            *)
(*     Sylvain Conchon                                                        *)
(*     Evelyne Contejean                                                      *)
(*                                                                            *)
(*     Francois Bobot                                                         *)
(*     Mohamed Iguernelala                                                    *)
(*     Stephane Lescuyer                                                      *)
(*     Alain Mebsout                                                          *)
(*                                                                            *)
(*   This file is distributed under the terms of the CeCILL-C licence         *)
(******************************************************************************)

Alt-Ergo is an automatic theorem prover.  Alt-Ergo's input is an arbitray
first-order formula in the Why input format.

COPYRIGHT
=========

This program is distributed under the CeCILL-C licence.
See the enclosed file COPYING.


INSTALLATION
============

See the enclosed file INSTALL.
