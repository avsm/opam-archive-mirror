type t = Pkcs11_CK_BYTE.t

let typ = Ctypes.char
