(* Example -- Example

   Rashell (https://github.com/michipili/rashell)
   This file is part of Rashell

   Copyright © 2015 Michael Grünewald

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as
   published by the Free Software Foundation, with linking exceptions;
   either version 3 of the License, or (at your option) any later
   version. See COPYING file for details.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
   02111-1307, USA. *)

let utility1 =
  Rashell_Command.command ("/usr/bin/uname", [| "/usr/bin/uname"; "-a" |])

let utility2 =
  Rashell_Command.command ("/usr/bin/uname", [| "/usr/bin/uname"; "-x" |])

let utility3 =
  Rashell_Command.command ("/usr/bin/unamex", [| "/usr/bin/uname"; "-x" |])

let utility4 =
  Rashell_Command.command
    ~workdir:"/inexistant"
    ("/usr/bin/uname", [| "/usr/bin/uname"; "-x" |])

let utility cmd =
  (fun m -> Lwt.bind m Lwt_io.printl)
    (Rashell_Command.exec_utility cmd)

let runutility cmd =
  Lwt_main.run (utility cmd)


let filter1 =
  Rashell_Command.command
    ("/usr/bin/sed", [| "/usr/bin/sed"; "-e"; "1,2{s/You/They/;s/I/You/;s/They/I/;}" |])

let filter2 =
  Rashell_Command.command
    ("/usr/bin/sed", [| "/usr/bin/sed"; "-e"; "s" |])

let filter3 =
  Rashell_Command.command
    ("/nonexistant", [| "/nonexistant"; |])

let filter cmd lines =
  Lwt_stream.iter_s Lwt_io.printl
    (Rashell_Command.exec_filter cmd lines)

let runfilter cmd =
  let lines = Lwt_stream.of_list [
      "You say yes, I say no";
      "You stay stop and I say go, go, go";
      "You say goodbye, and I say hello!";
    ]
  in
  Lwt_main.run (filter cmd lines)


let query1 =
  Rashell_Command.command ("", [| "ps"; "ax" |])

let query2 =
  Rashell_Command.command ("", [| "ps"; "-z" |])

let query3 =
  Rashell_Command.command
    ~workdir:"/inexistant" ("", [| "ps"; "ax" |])

let query4 =
  Rashell_Command.command
    ~workdir:"/etc" ("", [| "ls"; "-l" |])

let query cmd =
  Lwt_stream.iter_s Lwt_io.printl
    (Rashell_Command.exec_query cmd)

let runquery cmd =
  Lwt_main.run (query cmd)


let test1 =
  Rashell_Command.command
    ~workdir:"/Users/michael"
    ("", [| "grep"; "-F"; "localhost"; "/etc/hosts" |])

let test2 =
  Rashell_Command.command ("", [| "grep"; "-F"; "LOCALHOST"; "/etc/hosts" |])

let test3 =
  Rashell_Command.command ("", [| "/nonexistant" |])

let test cmd =
  let open Lwt.Infix in
  (fun m -> m >>= fun b -> Lwt_io.printl (if b then "true" else "false"))
    (Rashell_Command.exec_test cmd)

let runtest cmd =
  Lwt_main.run (test cmd)

let () = runquery query4
