OCaml bindings to libnl
=======================

The Netlink Protocol Library Suite
([libnl](http://www.carisma.slowglass.com/~tgr/libnl)) provides APIs to the
netlink protocol, allowing you to interact with network devices in the Linux
kernel.

