int f(int x);

int f(int x) { return 12; }
