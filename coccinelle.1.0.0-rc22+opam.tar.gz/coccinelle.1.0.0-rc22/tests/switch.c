int main () {
  switch (x) {
  default:
    break;
  case X:
    f();
  }
}
