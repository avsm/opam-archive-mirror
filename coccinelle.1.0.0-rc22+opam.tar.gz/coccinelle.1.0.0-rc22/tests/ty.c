int main () {
  struct foo x;
  return 12;
}
