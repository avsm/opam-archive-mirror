int main () {
  struct foo *a;
  print(a);
}
