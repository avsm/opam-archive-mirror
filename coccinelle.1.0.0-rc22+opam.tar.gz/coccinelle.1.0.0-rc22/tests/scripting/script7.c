int main() {
  int x;

  f(2);
  if (2 == 2) {
    x = 7;
  }

  g(2);

  q(x);

  h();
}
