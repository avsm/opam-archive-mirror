typedef struct foo { int a; } foo_t;

int main() {
  foo_t * x;
  f(x->a);
  g(x);
}
