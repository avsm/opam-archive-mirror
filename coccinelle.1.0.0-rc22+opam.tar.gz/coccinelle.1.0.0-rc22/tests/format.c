int main () {
  printf("one %d two\n", 1);
  printf("one %d two %d three\n", 1, 2);
  printf("one two three\n");
}
