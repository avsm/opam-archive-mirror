int main () {
 for(bit = 0; bit < size; bit++) {
   if (test_bit(bit, bitmap))
     x = 12;
 }
}
