int main() {
  x = FN();
  if (y)
    x->a = 12;
  else
    x->b = 15;
}
