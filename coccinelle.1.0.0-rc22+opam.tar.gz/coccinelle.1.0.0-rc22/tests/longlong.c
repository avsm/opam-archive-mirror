long long a;

int main () {
  long long b;
  return 0;
}
