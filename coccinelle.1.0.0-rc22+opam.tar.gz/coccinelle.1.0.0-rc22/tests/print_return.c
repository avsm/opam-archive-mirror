int config(struct pcmcia_device *link) {
  bar();
  return 0;
}
