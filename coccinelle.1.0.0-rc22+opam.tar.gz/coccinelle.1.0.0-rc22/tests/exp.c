int main(int i) {

  int k = foo();

  if(1) {
    foo();
  } else { 
    foo();
  }

  foo();


}
