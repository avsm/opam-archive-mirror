int foo1(void)
{
}


static int foo2(void)
{
}

float foo2(void)
{
}
