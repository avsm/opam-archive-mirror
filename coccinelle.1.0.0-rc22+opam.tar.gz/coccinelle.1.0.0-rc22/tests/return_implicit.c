void main(void)
{
	foo();
}
