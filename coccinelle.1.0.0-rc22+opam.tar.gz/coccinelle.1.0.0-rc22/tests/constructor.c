int main () {
  imx_add_platform_device_dmamask(Ename, Eid, Eres, Enum_res,
				  Edata, Esize_data, Edma_mask);
}

