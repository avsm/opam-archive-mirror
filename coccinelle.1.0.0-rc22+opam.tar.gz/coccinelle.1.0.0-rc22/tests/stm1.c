int main(int x) {
  f();
  replace();
  g();
}
