void main() 
{
  f(1,2,3);
  if(1) 
    g(1);
  else 
    g(1);
}
