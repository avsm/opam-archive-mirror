int main() {
  unsigned int x;
  int y;
  unsigned long long int a;
  long long int b;
  unsigned long long m;
  long long n;
  return 0;
}
