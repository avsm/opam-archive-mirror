

int foo(int);
