int main(int (*x)(int,int)) {
  x();
}
