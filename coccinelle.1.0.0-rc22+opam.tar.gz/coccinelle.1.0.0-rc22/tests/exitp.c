int main () {
  f(a1);
  f(a2);
  f(done);
  f(a4);
}
