let version_date = "Mon, 29 Sep 2014 16:51:46 +0200"
let configure_flags = "--enable-release --disable-python --disable-pcre-syntax"
