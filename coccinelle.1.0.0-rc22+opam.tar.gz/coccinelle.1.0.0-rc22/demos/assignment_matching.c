int first() {
  int a = f(3);
  b = f(3);
  if (c = f(3)) return 1;
  if (d = (int)f(3)) return 2;
  return 0;
}

int second() {
  int a = g(3);
  b = g(3);
  if (c = g(3)) return 1;
  if (d = (int)g(3)) return 2;
  return 0;
}

int third() {
  int a = h(3);
  b = h(3);
  if (c = h(3)) return 1;
  if (d = (int)h(3)) return 2;
  return 0;
}

int fourth() {
  int a = i(3);
  b = i(3);
  if (c = i(3)) return 1;
  if (d = (int)i(3)) return 2;
  return 0;
}

