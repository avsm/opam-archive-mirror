ocaml-pcap
==========

OCaml code for generating and analysing PCAP (packet capture) files.

This is based on Anil Madhavapeddy's "cstruct" example code.
