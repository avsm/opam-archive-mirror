ocaml-mustache
==============

mustache.js logic-less templates in OCaml

Todo/Wish List
-----------
* Support for ropes


http://mustache.github.io/
