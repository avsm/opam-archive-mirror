0.1.1 (2016-02-09):
* Term.input -> Term.event
* Option to redraw the line

0.1.0 (2016-02-09):
* Initial release
