cmitomli
========

Convert a cmi file back to an mli interface without having to pass any
`-I` or `-package` flags.
Tested with ocaml 4.00.0.

Installation
------------

Compile:

```
$ make
```

Install:

```
$ make install
```

or

```
$ make PREFIX=... install
```

or

```
$ make BINDIR=... install
```
