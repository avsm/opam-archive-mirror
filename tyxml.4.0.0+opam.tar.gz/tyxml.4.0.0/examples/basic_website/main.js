"use strict";


var handle = document.getElementById("payload");

console.log(handle);
