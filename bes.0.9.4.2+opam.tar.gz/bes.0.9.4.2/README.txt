(* OASIS_START *)
(* DO NOT EDIT (digest: 8c0b55f679076c06fe3ee223fc2292c6) *)
This is the README file for the bes distribution.

boolean expression simplifier

This is a pure OCaml library containing several algorithms to simplify
boolean expressions (boolean expression simplifier)

See the files INSTALL.txt for building and installation instructions. 

Home page: https://forge.ocamlcore.org/projects/bes/


(* OASIS_STOP *)
