let kilobyte = String.make 1024 ' '
;;
print_string kilobyte
