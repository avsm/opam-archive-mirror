print_endline "longish";
prerr_endline "short";
print_endline "longerer";
prerr_endline "very long indeed";
print_endline "short";
