let version_date = "Thu, 11 Dec 2014 15:51:26 +0100"
let configure_flags = "--enable-release --disable-python --disable-pcre-syntax"
