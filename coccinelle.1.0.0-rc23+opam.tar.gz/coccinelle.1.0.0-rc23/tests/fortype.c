int main () {
  for (int x = 0; x!=10; x++)
     return x;
}
