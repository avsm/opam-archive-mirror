! IS'' a test
! you do or don't have to save g[2,3,4], so save them to be safe.


/* For Emacs we have a separate interface which corresponds to the normal
   strftime function and does not have the extra information whether the
   TP arguments comes from a `gmtime' call or not.  */
