FOO(a2,b2,c2);

/*
int y;

struct foo {
  FOO(a,b,c);
  FOO(a1,b1,c1);
};
*/
