int main() {
  while (y) {
    if (x) {
      one();
      two();
    }
  }
}
