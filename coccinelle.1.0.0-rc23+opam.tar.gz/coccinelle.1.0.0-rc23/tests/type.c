int foo() {
  int x;
  return 0;
}

