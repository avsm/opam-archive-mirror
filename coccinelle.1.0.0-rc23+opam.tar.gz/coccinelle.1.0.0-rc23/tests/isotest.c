void main(int i) {

  char j;
  int i; // = 1;
  
  j++;
  
}
