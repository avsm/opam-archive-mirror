struct serio {
	struct semaphore drv_sem; /* mutex for mixer */

};
