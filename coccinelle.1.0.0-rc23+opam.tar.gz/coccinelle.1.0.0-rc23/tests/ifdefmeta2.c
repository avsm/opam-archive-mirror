int main() {
    buf = alloca(3


                    +5




                    +2
            );
}
