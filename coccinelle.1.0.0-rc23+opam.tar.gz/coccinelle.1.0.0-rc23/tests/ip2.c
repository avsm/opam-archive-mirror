void GetInfoDestTV(short sNoFo)
{
  if(sNoFo == 1)
    printf("one");
  else if(sNoFo == 2)
    printf("two");
  else if(sNoFo == 2)
    printf("three");
  else
    printf("other");
}
