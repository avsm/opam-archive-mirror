int main () {
  return (x) && y;
}
