int main () {
  printf("arena 0x%08x, numfree = %d\n", (unsigned)dt, dt->numfree);
}
