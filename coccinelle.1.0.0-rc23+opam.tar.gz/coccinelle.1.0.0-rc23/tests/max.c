int main () {
  if (x < 25) return i;
}
