int main () {
  int *i, i[12], i, k, r;
}

struct foo {
  int *i, i[12], i, k, r;
  int *i, i[12], i;
  int *i;
};

int main () {
  int *i, i[12], i;
}

struct foo {
  int *i, i[12], i;
};
