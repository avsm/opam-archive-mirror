void xxx(void)
{
	xxx(1);

}


void main(void)
{

	f((int) 1);
}
