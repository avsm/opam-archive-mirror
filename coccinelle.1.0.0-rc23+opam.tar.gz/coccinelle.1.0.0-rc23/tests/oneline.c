int main () {
  f();
  f();
}
