void main(int i) {
  g(1);
  g(2);
  f(1);
}
