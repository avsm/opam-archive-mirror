int main() {
  foo(12);
  bar(80);
}
