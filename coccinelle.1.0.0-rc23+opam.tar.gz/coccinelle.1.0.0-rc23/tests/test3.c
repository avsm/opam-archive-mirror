void main()
{
  /* a comment */
  f(3);

  if(1) 
    g(1);
  else 
    g(2);
}
