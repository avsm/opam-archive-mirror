int main () {
   if (x)
     GOTO(l,a = 3);
l: return;
}
