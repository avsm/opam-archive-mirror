void foo(int x,int y) { return; }
