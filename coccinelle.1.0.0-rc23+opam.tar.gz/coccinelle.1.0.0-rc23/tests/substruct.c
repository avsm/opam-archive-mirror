struct a { int a; } x[2] =
{
  { .a = 7, },
  { .a = 17, },
};
