int main() {
  long i1, i2;
  long i3;
  long  lType = (long)TYPE_OBJ_DS_REPORT, lNuPageBloc = 0L;
  unsigned char c1 = 'a', c2 = 'b';
  unsigned char c3 = 'c';
  i1 = 11;
  i2 = 22;
  i3 = 33;
  printf("%d + %d = %d\n", i1, i2, i1 + i2);
  printf("'%c', '%c', '%c'\n", c1, c2, c3);
}
