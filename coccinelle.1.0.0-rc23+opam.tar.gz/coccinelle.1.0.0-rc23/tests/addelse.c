int main () {
  if (x == 12) return 6;
}
