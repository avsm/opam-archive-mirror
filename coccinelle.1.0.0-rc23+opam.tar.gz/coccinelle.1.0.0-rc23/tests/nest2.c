int f(int i) {
  a();
  a();
  a();
}
