void main()
{

  if(1) {
    f(1);
  }

  f(3);

  /* nice comment */
}
