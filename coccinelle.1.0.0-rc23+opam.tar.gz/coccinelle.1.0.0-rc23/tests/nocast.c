int main (unsigned int __nocast gfp_mask, int x) {
  buf = kmalloc(sizeof *send_buf + buf_size, gfp_mask);
}

