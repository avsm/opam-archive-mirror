int main () {
  static int a, b, c;
}
