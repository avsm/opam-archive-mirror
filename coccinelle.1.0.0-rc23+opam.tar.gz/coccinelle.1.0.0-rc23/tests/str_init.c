struct foo x = {
  .aaa = 5,
  .rrr = 1,
  .xxx= 12,
  .bbb = 2,
  .ccc = 4,
};
