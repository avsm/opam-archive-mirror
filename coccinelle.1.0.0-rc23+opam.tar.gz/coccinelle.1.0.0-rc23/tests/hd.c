#include "hd.h"

int f(int x, int y) { return x; }
