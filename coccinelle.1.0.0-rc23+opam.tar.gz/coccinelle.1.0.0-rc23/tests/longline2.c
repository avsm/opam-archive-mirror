int main() {
  f(sdhfkjdkdsahksadsdhjkdsa,sahdjshdkjsahdkjhsakjdsh,a,shdkjsdsdhkjsa,x,y,z);
  f(sdhfkjdkdsahksadsdhjkdsa, sahdjshdkjsahdkjhsakjdsh, a, shdkjsdsdhkjsa, x, y, z);
  f(sdhfkjdkdsahksadsdhjkdsa,sahdjshdkjsahdkjhsakjdsh,aaaaaaaaaaaaaaaaaaaa,shdkjsdsdhkjsa);
  f(a,sdhfkjdkdsahksadsdhjkdsa,sahdjshdkjsahdkjhsakjdsh,aaaaaaaaaaaaaaaaaaaa,shdkjsdsdhkjsa);
  f(a,sdhfkjdkdsahksadsdhjkdsa,sahdjshdkjsahdkjhsakjdsh,aaaaaaaaaaaaaaaaaaaa,shdkjsdsdhkjsa,
    sdhfkjdkdsahksadsdhjkdsa,sahdjshdkjsahdkjhsakjdsh,aaaaaaaaaaaaaaaaaaaa,shdkjsdsdhkjsa);
}
