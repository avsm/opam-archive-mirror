#include "typeur.h"

int main () {
  int y;
  f(x + y);
}
