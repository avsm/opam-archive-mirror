static struct var_t vars[] = {
	{ CAPS_START, .u.s = {"\x01+35p"   } },
	{ CAPS_STOP, .u.s = {"\x01-35p" } },
	{ CAPS_STOP, .u.s = {45 } },
	{ RATE, .u.n = {"\x01%ds", 8, 0, 9, 0, 0, NULL } },
};



int main () {
  f("foo");
}
