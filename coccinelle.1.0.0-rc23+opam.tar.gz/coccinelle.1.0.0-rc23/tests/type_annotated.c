void f1(int z) {

  struct foo i;
  struct foo2 j;
  int k;

  j+i.foo+j.foo;

}



void f2(struct foo i) {

  struct foo2 j;
  int k;

  j+i.foo+j.foo;

}
