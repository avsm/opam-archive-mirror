int main () {
  foo();
  xxx();
  bar();
}
