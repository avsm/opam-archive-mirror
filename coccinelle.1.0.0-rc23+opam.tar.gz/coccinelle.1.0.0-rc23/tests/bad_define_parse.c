/* I830 Video support */
#define NEED_REPLIES                              /* ? */
//#define EXTENSION_PROC_ARGS void *
#include "file.h"                   /* required */
#include <X11/extensions/panoramiXproto.h>        /* required */

int main () {
  f();
  __releases(x) 
}
