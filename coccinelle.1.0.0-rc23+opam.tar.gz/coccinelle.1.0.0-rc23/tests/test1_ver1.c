void main(int foo) {

  f(1);
  f(1); // if uncoment then problems
  g(2);
  g(2);// if uncomment then problems
  if(1) {
    h(3);
  } else {
    h(4);
  }

  
}

