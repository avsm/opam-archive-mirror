void main(double z) {

  int x;
  int y;
}

int main(int z) {
}


int main2(int z);

