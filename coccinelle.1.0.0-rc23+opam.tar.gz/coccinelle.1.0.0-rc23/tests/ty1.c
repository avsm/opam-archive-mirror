int fn(int y) {
  char x;
  foo(int,char);
}
