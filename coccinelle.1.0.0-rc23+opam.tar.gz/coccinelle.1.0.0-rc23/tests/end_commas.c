static struct i2c_client client_template = {
	.name		= "adv7175_client",
	.driver		= &i2c_driver_adv7175
};
