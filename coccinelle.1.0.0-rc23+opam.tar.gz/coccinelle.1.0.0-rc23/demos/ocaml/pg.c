int main() {
  foo(12,120);
  foobar(23,230);
  barfoo(34,340);
  bar(45,450);
}
