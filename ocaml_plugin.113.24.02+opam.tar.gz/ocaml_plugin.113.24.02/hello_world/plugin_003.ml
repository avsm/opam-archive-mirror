open! Core.Std

let f s = s^s^s

let message = f "plugin_003 is a stammer "
