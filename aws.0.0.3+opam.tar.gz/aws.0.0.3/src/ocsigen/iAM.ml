module M = IAM_factory.Make (Ocsigen_HC)

include M
