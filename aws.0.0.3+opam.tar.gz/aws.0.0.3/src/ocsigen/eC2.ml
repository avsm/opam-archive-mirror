module M = EC2_factory.Make (Ocsigen_HC)

include M
