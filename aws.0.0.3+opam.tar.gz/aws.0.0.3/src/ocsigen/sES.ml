module M = SES_factory.Make (Ocsigen_HC)

include M
