module M = SDB_factory.Make (Ocsigen_HC)

include M
