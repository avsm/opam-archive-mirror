module M = SQS_factory.Make (Ocsigen_HC)

include M
