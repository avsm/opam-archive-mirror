module M = FPS_factory.Make (Ocsigen_HC)

include M
