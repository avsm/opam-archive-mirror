module M = S3_factory.Make (Ocsigen_HC)

include M
