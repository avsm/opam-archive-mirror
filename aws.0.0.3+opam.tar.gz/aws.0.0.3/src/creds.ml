type t = {
  aws_access_key_id : string ;
  aws_secret_access_key : string ;
}
