open Tiny_json
open Json

open Meta_conv.Types
open Meta_conv.Types.Error
open Meta_conv.Internal

module Encode = struct
  let int n       = Number (float n)
  let int32 n     = Number (Int32.to_float n)
  let int64 n     = Number (Int64.to_float n)
  let nativeint n = Number (Nativeint.to_float n)
  let char c      = String (String.make 1 c)
  let string s    = String s
  let float n     = Number n
  let list f xs   = Array (List.map f xs)
  let array f xs  = Array (List.map f (Array.to_list xs))
  let bool b      = Bool b
  let lazy_t f v  = f (Lazy.force v)
  let option f    = function
    | None -> Null
    | Some v -> f v
  let unit ()     = Null

  let tuple ts       = Array ts
  let variant tag = function
    | [] -> String tag
    | ts -> Object [tag, Array ts]
  let record tag_ts  = Object tag_ts
  let poly_variant = variant
  let object_ = record
end

let json_of_int       = Encode.int
let json_of_int32     = Encode.int32
let json_of_int64     = Encode.int64
let json_of_nativeint = Encode.nativeint
let json_of_char      = Encode.char
let json_of_string    = Encode.string
let json_of_float     = Encode.float
let json_of_list      = Encode.list
let json_of_array     = Encode.array
let json_of_bool      = Encode.bool
let json_of_lazy_t    = Encode.lazy_t
let json_of_option    = Encode.option
let json_of_unit      = Encode.unit

let errorf fmt = Printf.ksprintf (fun s -> raise (Failure s)) fmt

module Decode = struct
  let tuple = function 
    | Array ts -> ts
    | _ -> errorf "Array expected for tuple"

  let variant = function 
    | String tag -> tag, [] 
    | Object [tag, Array ts] -> tag, ts
    | _ -> errorf "Object expected for variant"

  let record = function
    | Object alist -> alist
    | _ -> errorf "Object expected for record"

  let poly_variant = variant
  let object_ = record
end

open Printf

type 'a decoder = ('a, Json.t) Meta_conv.Types.Decoder.t
type 'a decoder_exn = ('a, Json.t) Decoder.t_exn
exception Error of Json.t Error.t

let errorf v fmt = 
  kprintf (fun s -> `Error (Primitive_decoding_failure s, v)) fmt

let string_of_json = function
  | String s -> `Ok s
  | v -> errorf v "string_of_json: String expected"

let char_of_json = function
  | String s when String.length s = 1 -> `Ok s.[0]
  | v -> errorf v "char_of_json: a char expected"

let int_check name min max conv v = match v with
  | Number n -> 
      begin match integer_of_float min max conv n with
      | `Ok i -> `Ok i
      | `Error s -> errorf v "%s_of_json: %s" name s
      end
  | _ -> errorf v "%s_of_json: Number expected" name

let int_of_json =
  int_check "int" (float min_int) (float max_int) int_of_float

let int64_of_json =
  let open Int64 in
  int_check "int64" (to_float min_int) (to_float max_int) of_float
      
let int32_of_json =
  let open Int32 in
  int_check "int32" (to_float min_int) (to_float max_int) of_float
      
let nativeint_of_json = 
  let open Nativeint in
  int_check "nativeint" (to_float min_int) (to_float max_int) of_float
      
let float_of_json = function
  | Number n -> `Ok n
  | n -> errorf n "float_of_json: Number expected"

let bool_of_json = function
  | Bool b -> `Ok b
  | v -> errorf v "bool_of_json: Bool expected"

let unit_of_json = function
  | Null -> `Ok ()
  | v -> errorf v "unit_of_json: Null expected"
  
let list_of_json d = generic_list_of (function
  | Array xs -> Some xs
  | _ -> None) d

let array_of_json d = generic_array_of (function
  | Array xs -> Some xs
  | _ -> None) d

let option_of_json d = generic_option_of (function
  | Null -> Some None
  | v -> Some (Some v)) d

let lazy_t_of_json f = generic_lazy_t_of (fun e -> raise (Error e)) f
let mc_lazy_t_of_json = generic_mc_lazy_t_of 

type 'a named_list = (string * 'a) list

let json_of_mc_fields enc xs = Object (List.map (fun (name, a) -> (name, enc a)) xs)

let mc_fields_of_json dec = generic_mc_fields_of (function Object js -> Some js | _ -> None) dec
