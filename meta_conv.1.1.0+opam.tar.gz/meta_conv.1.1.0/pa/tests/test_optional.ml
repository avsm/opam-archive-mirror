type t = {
  foo : int mc_optional;
  boo as "Boo" : int mc_optional
} with conv(json)
