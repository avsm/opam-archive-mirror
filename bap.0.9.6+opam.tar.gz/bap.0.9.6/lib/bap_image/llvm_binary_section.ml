
type t = {
  name : string;
  addr: int64;
  size : int64;
} with fields
