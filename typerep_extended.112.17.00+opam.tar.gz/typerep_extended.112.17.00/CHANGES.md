## 112.17.00

- typerep_extended now use core_kernel

