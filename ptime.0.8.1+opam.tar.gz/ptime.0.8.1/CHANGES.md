v0.8.1 2015-07-14 Cambridge (UK)
--------------------------------

* Add `Ptime.v` and `Ptime.Span.v` to safely deal with trusted
  inputs. Thanks to Matt Gray for suggesting.
* Add `Ptime.weekday`, to help conversions to denormalized
  timestamp formats. Thanks to Romain Calascibetta for suggesting.
* Build depend on topkg.
* Relicense from BSD3 to ISC.

v0.8.0 2015-12-24 Cambridge (UK)
--------------------------------

First release. Thanks to Raphaël Proust for lodging support.
