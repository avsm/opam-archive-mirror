/* --- Generated the 4/9/2015 at 17:28 --- */
/* --- heptagon compiler, version 1.00.06 (compiled fri. sep. 4 17:4:1 CET 2015) --- */
/* --- Command line: heptc -target c -s test -hepts autohiera3.ept --- */

#ifndef AUTOHIERA3_TYPES_H
#define AUTOHIERA3_TYPES_H

#include "stdbool.h"
#include "assert.h"
#include "pervasives.h"
typedef enum {
  Autohiera3__St_1_S2,
  Autohiera3__St_1_S1
} Autohiera3__st_1;

Autohiera3__st_1 Autohiera3__st_1_of_string(char* s);

char* string_of_Autohiera3__st_1(Autohiera3__st_1 x, char* buf);

typedef enum {
  Autohiera3__St_P2,
  Autohiera3__St_P1
} Autohiera3__st;

Autohiera3__st Autohiera3__st_of_string(char* s);

char* string_of_Autohiera3__st(Autohiera3__st x, char* buf);

#endif // AUTOHIERA3_TYPES_H
