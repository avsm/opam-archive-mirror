This library implements portable support for an operating system timesource.

The following sources are used:

* The Unix version uses `gettimeofday`
* The Xen version uses the paravirtual clock source.
