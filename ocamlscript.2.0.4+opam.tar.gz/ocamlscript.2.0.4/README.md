OCamlscript is a tool which compiles OCaml scripts into native code,
thus combining mthe flexibility of scripts and the speed provided by
ocamlopt.

Examples are given in the `examples/` subdirectory.

Installation: see INSTALL file

Documentation: http://ocaml.pbwiki.com/Ocamlscript

Primary download site: http://mjambon.com/ocamlscript.html

Authors: David Mentre and Martin Jambon

Contact: Martin Jambon <martin@mjambon.com>
