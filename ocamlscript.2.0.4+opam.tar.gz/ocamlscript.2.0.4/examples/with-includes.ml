Ocaml.sources := [ "hello.ml" ]
--
Hello.hello ()
