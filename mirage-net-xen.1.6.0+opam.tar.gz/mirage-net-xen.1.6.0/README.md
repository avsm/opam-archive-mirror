mirage-net-xen
==============

This library allows an OCaml application to read and
write Ethernet frames via the `Netfront` protocol.

Note: the `Netif` module is the public API.
The `Netchannel` API is still under development.

* Web: <http://openmirage.org>
* E-mail: <mirageos-devel@lists.xenproject.org>
* Issues: <https://github.com/mirage/mirage/issues>
