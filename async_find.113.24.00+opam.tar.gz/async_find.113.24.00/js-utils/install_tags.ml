let package_name = "async_find"

let sections =
  [ ("lib",
    [ ("built_lib_async_find", None)
    ],
    [ ("META", None)
    ])
  ]
