#use "topfind";;
#camlp4o;;
#load "syntax/pa_js.cmo";;
#require "deriving.syntax.std"
#load "syntax/pa_deriving_Json.cmo";;
#load "deriving_json/deriving_Json_lexer.cmo";;
#load "deriving_json/deriving_Json.cmo";;

