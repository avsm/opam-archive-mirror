ocaml-cookie-js
===============

Simple library for setting/getting cookies in js_of_ocaml
