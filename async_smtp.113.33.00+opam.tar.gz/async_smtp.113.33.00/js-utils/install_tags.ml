let package_name = "async_smtp"

let sections =
  [ ("lib",
    [ ("built_lib_async_smtp", None)
    ; ("built_lib_async_smtp_command", None)
    ; ("built_lib_async_smtp_tools", None)
    ],
    [ ("META", None)
    ])
  ]
