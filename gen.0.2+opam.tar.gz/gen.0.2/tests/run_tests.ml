
let () =
  let _ = OUnit.run_test_tt_main Test_gen.suite in
  ()
