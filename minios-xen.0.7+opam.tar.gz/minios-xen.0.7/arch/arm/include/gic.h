void gic_init(void);
