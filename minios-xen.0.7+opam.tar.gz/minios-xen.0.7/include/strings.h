#include <string.h>

int ffs(int);
