
(* This type is split out to avoid cyclic dependencies through Common/Exn *)
type never_returns
