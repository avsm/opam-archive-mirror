1.0.0 (2014-12-27):
* Initial public release.
