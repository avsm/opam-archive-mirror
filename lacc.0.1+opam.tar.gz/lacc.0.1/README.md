lacc
====

(fat-free) list accumulators

The original idea came from the BatList module from batteries-included.

Cf. lib_test/test.ml for examples.
