obuild configure
obuild build
./dist/build/test/test
