## 113.00.00

- Extended and improved Email_message API.

## 112.17.00

Moved from janestreet-alpha

