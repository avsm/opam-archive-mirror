==============================
Installing Arakoon with PyLabs
==============================
If you want to install Arakoon with PyLabs, you only need to install PyLabs_.

The installation of PyLabs includes the Arakoon software and its PyLabs client
to easily :doc:`configure Arakoon <configuring_arakoon>`.

If you have installed Arakoon via the Q-Shell, you can find node directory in
/opt/qbase5/var/db/.

.. _PyLabs: http://www.pylabs.org/#/Installation/Home
