Work-in-progress

Basic wget-like client, based on the Citrix' [HTTP
library](https://github.com/xen-org/xen-api-libs/tree/master/http-svr).

Pure OCaml implementation.