(*---------------------------------------------------------------------------
   Copyright (c) 2014 Daniel C. Bünzli. All rights reserved.
   Distributed under the BSD3 license, see license at the end of the file.
   uucp release 0.9.0
  ---------------------------------------------------------------------------*)

(* WARNING do not edit. This file was automatically generated. *)

open Uucp_tmap
let fold_map_map : int list t = { default = []; l0 = [|[|nil;nil;nil;nil;[|
[];[97;];[98;];[99;];[100;];[101;];[102;];[103;];[104;];[105;];[106;];
[107;];[108;];[109;];[110;];[111;];|];[|[112;];[113;];[114;];[115;];[116;];
[117;];[118;];[119;];[120;];[121;];[122;];[];[];[];[];[];|];nil;nil;nil;nil;
nil;[|[];[];[];[];[];[956;];[];[];[];[];[];[];[];[];[];[];|];[|[224;];
[225;];[226;];[227;];[228;];[229;];[230;];[231;];[232;];[233;];[234;];
[235;];[236;];[237;];[238;];[239;];|];[|[240;];[241;];[242;];[243;];[244;];
[245;];[246;];[];[248;];[249;];[250;];[251;];[252;];[253;];[254;];[115;115;];
|];nil;nil;[|[257;];[];[259;];[];[261;];[];[263;];[];[265;];[];[267;];
[];[269;];[];[271;];[];|];[|[273;];[];[275;];[];[277;];[];[279;];[];[281;];
[];[283;];[];[285;];[];[287;];[];|];[|[289;];[];[291;];[];[293;];[];[295;];
[];[297;];[];[299;];[];[301;];[];[303;];[];|];[|[105;775;];[];[307;];
[];[309;];[];[311;];[];[];[314;];[];[316;];[];[318;];[];[320;];|];[|[];
[322;];[];[324;];[];[326;];[];[328;];[];[700;110;];[331;];[];[333;];[];
[335;];[];|];[|[337;];[];[339;];[];[341;];[];[343;];[];[345;];[];[347;];
[];[349;];[];[351;];[];|];[|[353;];[];[355;];[];[357;];[];[359;];[];[361;];
[];[363;];[];[365;];[];[367;];[];|];[|[369;];[];[371;];[];[373;];[];[375;];
[];[255;];[378;];[];[380;];[];[382;];[];[115;];|];[|[];[595;];[387;];
[];[389;];[];[596;];[392;];[];[598;];[599;];[396;];[];[];[477;];[601;];|];[|
[603;];[402;];[];[608;];[611;];[];[617;];[616;];[409;];[];[];[];[623;];
[626;];[];[629;];|];[|[417;];[];[419;];[];[421;];[];[640;];[424;];[];
[643;];[];[];[429;];[];[648;];[432;];|];[|[];[650;];[651;];[436;];[];
[438;];[];[658;];[441;];[];[];[];[445;];[];[];[];|];[|[];[];[];[];[454;];
[454;];[];[457;];[457;];[];[460;];[460;];[];[462;];[];[464;];|];[|[];
[466;];[];[468;];[];[470;];[];[472;];[];[474;];[];[476;];[];[];[479;];
[];|];[|[481;];[];[483;];[];[485;];[];[487;];[];[489;];[];[491;];[];[493;];
[];[495;];[];|];[|[106;780;];[499;];[499;];[];[501;];[];[405;];[447;];
[505;];[];[507;];[];[509;];[];[511;];[];|];[|[513;];[];[515;];[];[517;];
[];[519;];[];[521;];[];[523;];[];[525;];[];[527;];[];|];[|[529;];[];[531;];
[];[533;];[];[535;];[];[537;];[];[539;];[];[541;];[];[543;];[];|];[|[414;];
[];[547;];[];[549;];[];[551;];[];[553;];[];[555;];[];[557;];[];[559;];
[];|];[|[561;];[];[563;];[];[];[];[];[];[];[];[11365;];[572;];[];[410;];
[11366;];[];|];[|[];[578;];[];[384;];[649;];[652;];[583;];[];[585;];[];
[587;];[];[589;];[];[591;];[];|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;[|[];[];[];[];[];[953;];[];[];[];[];[];[];[];[];[];[];|];nil;
nil;[|[881;];[];[883;];[];[];[];[887;];[];[];[];[];[];[];[];[];[1011;];|];[|
[];[];[];[];[];[];[940;];[];[941;];[942;];[943;];[];[972;];[];[973;];
[974;];|];[|[953;776;769;];[945;];[946;];[947;];[948;];[949;];[950;];
[951;];[952;];[953;];[954;];[955;];[956;];[957;];[958;];[959;];|];[|[960;];
[961;];[];[963;];[964;];[965;];[966;];[967;];[968;];[969;];[970;];[971;];
[];[];[];[];|];[|[965;776;769;];[];[];[];[];[];[];[];[];[];[];[];[];[];
[];[];|];[|[];[];[963;];[];[];[];[];[];[];[];[];[];[];[];[];[983;];|];[|
[946;];[952;];[];[];[];[966;];[960;];[];[985;];[];[987;];[];[989;];[];
[991;];[];|];[|[993;];[];[995;];[];[997;];[];[999;];[];[1001;];[];[1003;];
[];[1005;];[];[1007;];[];|];[|[954;];[961;];[];[];[952;];[949;];[];[1016;];
[];[1010;];[1019;];[];[];[891;];[892;];[893;];|];[|[1104;];[1105;];[1106;];
[1107;];[1108;];[1109;];[1110;];[1111;];[1112;];[1113;];[1114;];[1115;];
[1116;];[1117;];[1118;];[1119;];|];[|[1072;];[1073;];[1074;];[1075;];
[1076;];[1077;];[1078;];[1079;];[1080;];[1081;];[1082;];[1083;];[1084;];
[1085;];[1086;];[1087;];|];[|[1088;];[1089;];[1090;];[1091;];[1092;];
[1093;];[1094;];[1095;];[1096;];[1097;];[1098;];[1099;];[1100;];[1101;];
[1102;];[1103;];|];nil;nil;nil;[|[1121;];[];[1123;];[];[1125;];[];[1127;];
[];[1129;];[];[1131;];[];[1133;];[];[1135;];[];|];[|[1137;];[];[1139;];
[];[1141;];[];[1143;];[];[1145;];[];[1147;];[];[1149;];[];[1151;];[];|];[|
[1153;];[];[];[];[];[];[];[];[];[];[1163;];[];[1165;];[];[1167;];[];|];[|
[1169;];[];[1171;];[];[1173;];[];[1175;];[];[1177;];[];[1179;];[];[1181;];
[];[1183;];[];|];[|[1185;];[];[1187;];[];[1189;];[];[1191;];[];[1193;];
[];[1195;];[];[1197;];[];[1199;];[];|];[|[1201;];[];[1203;];[];[1205;];
[];[1207;];[];[1209;];[];[1211;];[];[1213;];[];[1215;];[];|];[|[1231;];
[1218;];[];[1220;];[];[1222;];[];[1224;];[];[1226;];[];[1228;];[];[1230;];
[];[];|];[|[1233;];[];[1235;];[];[1237;];[];[1239;];[];[1241;];[];[1243;];
[];[1245;];[];[1247;];[];|];[|[1249;];[];[1251;];[];[1253;];[];[1255;];
[];[1257;];[];[1259;];[];[1261;];[];[1263;];[];|];[|[1265;];[];[1267;];
[];[1269;];[];[1271;];[];[1273;];[];[1275;];[];[1277;];[];[1279;];[];|];[|
[1281;];[];[1283;];[];[1285;];[];[1287;];[];[1289;];[];[1291;];[];[1293;];
[];[1295;];[];|];[|[1297;];[];[1299;];[];[1301;];[];[1303;];[];[1305;];
[];[1307;];[];[1309;];[];[1311;];[];|];[|[1313;];[];[1315;];[];[1317;];
[];[1319;];[];[1321;];[];[1323;];[];[1325;];[];[1327;];[];|];[|[];[1377;];
[1378;];[1379;];[1380;];[1381;];[1382;];[1383;];[1384;];[1385;];[1386;];
[1387;];[1388;];[1389;];[1390;];[1391;];|];[|[1392;];[1393;];[1394;];
[1395;];[1396;];[1397;];[1398;];[1399;];[1400;];[1401;];[1402;];[1403;];
[1404;];[1405;];[1406;];[1407;];|];[|[1408;];[1409;];[1410;];[1411;];
[1412;];[1413;];[1414;];[];[];[];[];[];[];[];[];[];|];nil;nil;[|[];[];
[];[];[];[];[];[1381;1410;];[];[];[];[];[];[];[];[];|];nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;|];[|nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;[|[11520;];[11521;];[11522;];[11523;];[11524;];[11525;];[11526;];
[11527;];[11528;];[11529;];[11530;];[11531;];[11532;];[11533;];[11534;];
[11535;];|];[|[11536;];[11537;];[11538;];[11539;];[11540;];[11541;];[11542;];
[11543;];[11544;];[11545;];[11546;];[11547;];[11548;];[11549;];[11550;];
[11551;];|];[|[11552;];[11553;];[11554;];[11555;];[11556;];[11557;];[];
[11559;];[];[];[];[];[];[11565;];[];[];|];nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;[|[7681;];[];[7683;];
[];[7685;];[];[7687;];[];[7689;];[];[7691;];[];[7693;];[];[7695;];[];|];[|
[7697;];[];[7699;];[];[7701;];[];[7703;];[];[7705;];[];[7707;];[];[7709;];
[];[7711;];[];|];[|[7713;];[];[7715;];[];[7717;];[];[7719;];[];[7721;];
[];[7723;];[];[7725;];[];[7727;];[];|];[|[7729;];[];[7731;];[];[7733;];
[];[7735;];[];[7737;];[];[7739;];[];[7741;];[];[7743;];[];|];[|[7745;];
[];[7747;];[];[7749;];[];[7751;];[];[7753;];[];[7755;];[];[7757;];[];
[7759;];[];|];[|[7761;];[];[7763;];[];[7765;];[];[7767;];[];[7769;];[];
[7771;];[];[7773;];[];[7775;];[];|];[|[7777;];[];[7779;];[];[7781;];[];
[7783;];[];[7785;];[];[7787;];[];[7789;];[];[7791;];[];|];[|[7793;];[];
[7795;];[];[7797;];[];[7799;];[];[7801;];[];[7803;];[];[7805;];[];[7807;];
[];|];[|[7809;];[];[7811;];[];[7813;];[];[7815;];[];[7817;];[];[7819;];
[];[7821;];[];[7823;];[];|];[|[7825;];[];[7827;];[];[7829;];[];[104;817;];
[116;776;];[119;778;];[121;778;];[97;702;];[7777;];[];[];[115;115;];[];|];[|
[7841;];[];[7843;];[];[7845;];[];[7847;];[];[7849;];[];[7851;];[];[7853;];
[];[7855;];[];|];[|[7857;];[];[7859;];[];[7861;];[];[7863;];[];[7865;];
[];[7867;];[];[7869;];[];[7871;];[];|];[|[7873;];[];[7875;];[];[7877;];
[];[7879;];[];[7881;];[];[7883;];[];[7885;];[];[7887;];[];|];[|[7889;];
[];[7891;];[];[7893;];[];[7895;];[];[7897;];[];[7899;];[];[7901;];[];
[7903;];[];|];[|[7905;];[];[7907;];[];[7909;];[];[7911;];[];[7913;];[];
[7915;];[];[7917;];[];[7919;];[];|];[|[7921;];[];[7923;];[];[7925;];[];
[7927;];[];[7929;];[];[7931;];[];[7933;];[];[7935;];[];|];[|[];[];[];
[];[];[];[];[];[7936;];[7937;];[7938;];[7939;];[7940;];[7941;];[7942;];
[7943;];|];[|[];[];[];[];[];[];[];[];[7952;];[7953;];[7954;];[7955;];
[7956;];[7957;];[];[];|];[|[];[];[];[];[];[];[];[];[7968;];[7969;];[7970;];
[7971;];[7972;];[7973;];[7974;];[7975;];|];[|[];[];[];[];[];[];[];[];
[7984;];[7985;];[7986;];[7987;];[7988;];[7989;];[7990;];[7991;];|];[|
[];[];[];[];[];[];[];[];[8000;];[8001;];[8002;];[8003;];[8004;];[8005;];
[];[];|];[|[965;787;];[];[965;787;768;];[];[965;787;769;];[];[965;787;834;];
[];[];[8017;];[];[8019;];[];[8021;];[];[8023;];|];[|[];[];[];[];[];[];
[];[];[8032;];[8033;];[8034;];[8035;];[8036;];[8037;];[8038;];[8039;];|];nil;
[|[7936;953;];[7937;953;];[7938;953;];[7939;953;];[7940;953;];[7941;953;];
[7942;953;];[7943;953;];[7936;953;];[7937;953;];[7938;953;];[7939;953;];
[7940;953;];[7941;953;];[7942;953;];[7943;953;];|];[|[7968;953;];[7969;953;];
[7970;953;];[7971;953;];[7972;953;];[7973;953;];[7974;953;];[7975;953;];
[7968;953;];[7969;953;];[7970;953;];[7971;953;];[7972;953;];[7973;953;];
[7974;953;];[7975;953;];|];[|[8032;953;];[8033;953;];[8034;953;];[8035;953;];
[8036;953;];[8037;953;];[8038;953;];[8039;953;];[8032;953;];[8033;953;];
[8034;953;];[8035;953;];[8036;953;];[8037;953;];[8038;953;];[8039;953;];|];[|
[];[];[8048;953;];[945;953;];[940;953;];[];[945;834;];[945;834;953;];
[8112;];[8113;];[8048;];[8049;];[945;953;];[];[953;];[];|];[|[];[];
[8052;953;];[951;953;];[942;953;];[];[951;834;];[951;834;953;];[8050;];
[8051;];[8052;];[8053;];[951;953;];[];[];[];|];[|[];[];[953;776;768;];
[953;776;769;];[];[];[953;834;];[953;776;834;];[8144;];[8145;];[8054;];
[8055;];[];[];[];[];|];[|[];[];[965;776;768;];[965;776;769;];[961;787;];
[];[965;834;];[965;776;834;];[8160;];[8161;];[8058;];[8059;];[8165;];
[];[];[];|];[|[];[];[8060;953;];[969;953;];[974;953;];[];[969;834;];
[969;834;953;];[8056;];[8057;];[8060;];[8061;];[969;953;];[];[];[];|];|];[|
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;[|
[];[];[];[];[];[];[969;];[];[];[];[107;];[229;];[];[];[];[];|];[|[];[];
[8526;];[];[];[];[];[];[];[];[];[];[];[];[];[];|];nil;nil;[|[8560;];[8561;];
[8562;];[8563;];[8564;];[8565;];[8566;];[8567;];[8568;];[8569;];[8570;];
[8571;];[8572;];[8573;];[8574;];[8575;];|];nil;[|[];[];[];[8580;];[];
[];[];[];[];[];[];[];[];[];[];[];|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;[|[];[];[];[];[];[];[9424;];[9425;];[9426;];[9427;];[9428;];[9429;];
[9430;];[9431;];[9432;];[9433;];|];[|[9434;];[9435;];[9436;];[9437;];
[9438;];[9439;];[9440;];[9441;];[9442;];[9443;];[9444;];[9445;];[9446;];
[9447;];[9448;];[9449;];|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;[|[11312;];[11313;];[11314;];[11315;];
[11316;];[11317;];[11318;];[11319;];[11320;];[11321;];[11322;];[11323;];
[11324;];[11325;];[11326;];[11327;];|];[|[11328;];[11329;];[11330;];[11331;];
[11332;];[11333;];[11334;];[11335;];[11336;];[11337;];[11338;];[11339;];
[11340;];[11341;];[11342;];[11343;];|];[|[11344;];[11345;];[11346;];[11347;];
[11348;];[11349;];[11350;];[11351;];[11352;];[11353;];[11354;];[11355;];
[11356;];[11357;];[11358;];[];|];nil;nil;nil;[|[11361;];[];[619;];[7549;];
[637;];[];[];[11368;];[];[11370;];[];[11372;];[];[593;];[625;];[592;];|];[|
[594;];[];[11379;];[];[];[11382;];[];[];[];[];[];[];[];[];[575;];[576;];|];[|
[11393;];[];[11395;];[];[11397;];[];[11399;];[];[11401;];[];[11403;];
[];[11405;];[];[11407;];[];|];[|[11409;];[];[11411;];[];[11413;];[];[11415;];
[];[11417;];[];[11419;];[];[11421;];[];[11423;];[];|];[|[11425;];[];[11427;];
[];[11429;];[];[11431;];[];[11433;];[];[11435;];[];[11437;];[];[11439;];
[];|];[|[11441;];[];[11443;];[];[11445;];[];[11447;];[];[11449;];[];[11451;];
[];[11453;];[];[11455;];[];|];[|[11457;];[];[11459;];[];[11461;];[];[11463;];
[];[11465;];[];[11467;];[];[11469;];[];[11471;];[];|];[|[11473;];[];[11475;];
[];[11477;];[];[11479;];[];[11481;];[];[11483;];[];[11485;];[];[11487;];
[];|];[|[11489;];[];[11491;];[];[];[];[];[];[];[];[];[11500;];[];[11502;];
[];[];|];[|[];[];[11507;];[];[];[];[];[];[];[];[];[];[];[];[];[];|];nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;|];nil;nil;nil;nil;nil;nil;nil;[|nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;[|[42561;];[];[42563;];[];[42565;];[];[42567;];[];[42569;];[];
[42571;];[];[42573;];[];[42575;];[];|];[|[42577;];[];[42579;];[];[42581;];
[];[42583;];[];[42585;];[];[42587;];[];[42589;];[];[42591;];[];|];[|[42593;];
[];[42595;];[];[42597;];[];[42599;];[];[42601;];[];[42603;];[];[42605;];
[];[];[];|];nil;[|[42625;];[];[42627;];[];[42629;];[];[42631;];[];[42633;];
[];[42635;];[];[42637;];[];[42639;];[];|];[|[42641;];[];[42643;];[];[42645;];
[];[42647;];[];[42649;];[];[42651;];[];[];[];[];[];|];nil;nil;nil;nil;nil;
nil;nil;nil;[|[];[];[42787;];[];[42789;];[];[42791;];[];[42793;];[];[42795;];
[];[42797;];[];[42799;];[];|];[|[];[];[42803;];[];[42805;];[];[42807;];
[];[42809;];[];[42811;];[];[42813;];[];[42815;];[];|];[|[42817;];[];[42819;];
[];[42821;];[];[42823;];[];[42825;];[];[42827;];[];[42829;];[];[42831;];
[];|];[|[42833;];[];[42835;];[];[42837;];[];[42839;];[];[42841;];[];[42843;];
[];[42845;];[];[42847;];[];|];[|[42849;];[];[42851;];[];[42853;];[];[42855;];
[];[42857;];[];[42859;];[];[42861;];[];[42863;];[];|];[|[];[];[];[];[];
[];[];[];[];[42874;];[];[42876;];[];[7545;];[42879;];[];|];[|[42881;];
[];[42883;];[];[42885;];[];[42887;];[];[];[];[];[42892;];[];[613;];[];
[];|];[|[42897;];[];[42899;];[];[];[];[42903;];[];[42905;];[];[42907;];
[];[42909;];[];[42911;];[];|];[|[42913;];[];[42915;];[];[42917;];[];[42919;];
[];[42921;];[];[614;];[604;];[609;];[620;];[];[];|];[|[670;];[647;];[];
[];[];[];[];[];[];[];[];[];[];[];[];[];|];nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;|];nil;nil;nil;nil;[|nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;[|[102;102;];[102;105;];[102;108;];[102;102;105;];[102;102;108;];
[115;116;];[115;116;];[];[];[];[];[];[];[];[];[];|];[|[];[];[];[1396;1398;];
[1396;1381;];[1396;1387;];[1406;1398;];[1396;1389;];[];[];[];[];[];[];
[];[];|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;[|[];[65345;];[65346;];[65347;];[65348;];
[65349;];[65350;];[65351;];[65352;];[65353;];[65354;];[65355;];[65356;];
[65357;];[65358;];[65359;];|];[|[65360;];[65361;];[65362;];[65363;];[65364;];
[65365;];[65366;];[65367;];[65368;];[65369;];[65370;];[];[];[];[];[];|];nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;|];[|nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
[|[66600;];[66601;];[66602;];[66603;];[66604;];[66605;];[66606;];[66607;];
[66608;];[66609;];[66610;];[66611;];[66612;];[66613;];[66614;];[66615;];|];[|
[66616;];[66617;];[66618;];[66619;];[66620;];[66621;];[66622;];[66623;];
[66624;];[66625;];[66626;];[66627;];[66628;];[66629;];[66630;];[66631;];|];[|
[66632;];[66633;];[66634;];[66635;];[66636;];[66637;];[66638;];[66639;];
[];[];[];[];[];[];[];[];|];nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;|];[|nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;[|[71872;];[71873;];[71874;];
[71875;];[71876;];[71877;];[71878;];[71879;];[71880;];[71881;];[71882;];
[71883;];[71884;];[71885;];[71886;];[71887;];|];[|[71888;];[71889;];[71890;];
[71891;];[71892;];[71893;];[71894;];[71895;];[71896;];[71897;];[71898;];
[71899;];[71900;];[71901;];[71902;];[71903;];|];nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;|];nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;nil;
nil;nil;nil;|]}


(*---------------------------------------------------------------------------
   Copyright (c) 2014 Daniel C. Bünzli.
   All rights reserved.

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:
     
   1. Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

   3. Neither the name of Daniel C. Bünzli nor the names of
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
   OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
   THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
   (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
   OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  ---------------------------------------------------------------------------*)
