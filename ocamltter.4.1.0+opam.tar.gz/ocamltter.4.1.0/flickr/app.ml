open OCamltter_oauth

let app = { Oauth_ex.Consumer.key = "d8243579bd0fdefef735cbd927fd5e8f";
            secret = "b1096468a673ad40" }
