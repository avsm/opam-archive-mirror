v0.1.1 2016-07-27
-----------------

Specify ocaml version as 4.03.0

v0.1 2016-07-26
---------------

Initial release.
