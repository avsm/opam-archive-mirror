type t = B.t option
