module rec A : sig [%%include "a.mli"] end = struct [%%include "a.ml"] end
and B : sig [%%include "b.mli"] end = struct [%%include "b.ml"] end
