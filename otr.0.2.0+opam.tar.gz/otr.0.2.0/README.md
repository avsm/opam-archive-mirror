[![Build Status](https://travis-ci.org/hannesm/ocaml-otr.svg?branch=master)](https://travis-ci.org/hannesm/ocaml-otr)


OCaml-OTR
=========

[Off-the-record (OTR)](https://otr.cypherpunks.ca/) messaging protocol, purely in OCaml.

Only versions 2 and 3 are supported.

Best to be used with [jackline](http://github.com/hannesm/jackline).
