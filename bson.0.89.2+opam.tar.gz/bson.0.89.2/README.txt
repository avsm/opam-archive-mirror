(* OASIS_START *)
(* DO NOT EDIT (digest: 6fe1904f991c5700dec4a476c81dba70) *)
This is the README file for the bson.ml distribution.

A bson data structure, including encoding/decoding

See the files INSTALL.txt for building and installation instructions. 


(* OASIS_STOP *)
