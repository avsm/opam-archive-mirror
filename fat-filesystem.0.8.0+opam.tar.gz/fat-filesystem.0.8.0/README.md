Pure OCaml implementation of the FAT filesystem
===============================================

This library has two purposes:
  1. to allow the easy preparation of bootable disk images
     containing [mirage](http://openmirage.org/) kernels
  2. to provide a simple filesystem layer for mirage
     applications

