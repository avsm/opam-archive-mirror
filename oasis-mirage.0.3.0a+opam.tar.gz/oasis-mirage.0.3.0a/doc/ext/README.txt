For licensing problem, no external documentation is included. 

You can run "sh fetch-doc.sh" to get required external documentation.
