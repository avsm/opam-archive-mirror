module X=A
let _ = print_endline "hello world 2"
