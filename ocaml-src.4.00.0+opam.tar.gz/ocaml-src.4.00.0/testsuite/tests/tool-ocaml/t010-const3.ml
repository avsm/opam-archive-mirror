3;;

(**
       0 CONST3 
       1 ATOM0 
       2 SETGLOBAL T010-const3
       4 STOP 
**)
