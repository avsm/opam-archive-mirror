0;;

(**
       0 CONST0 
       1 ATOM0 
       2 SETGLOBAL T010-const0
       4 STOP 
**)
