let _ = print_int(Multdef.f 1); print_newline(); exit 0
