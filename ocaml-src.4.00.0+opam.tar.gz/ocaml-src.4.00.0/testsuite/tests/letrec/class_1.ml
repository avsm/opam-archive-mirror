(* class expression are compiled to recursive bindings *)
class test =
object
  method x = 1
end
