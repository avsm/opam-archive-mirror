// @flow
var React = require('react');
(<fbt />: React.Element<*>);
(<fbt />: number); // Error: ReactElement ~> number
