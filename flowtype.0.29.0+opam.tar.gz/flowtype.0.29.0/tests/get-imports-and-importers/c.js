// @flow
require('./a.js');
require('b');
