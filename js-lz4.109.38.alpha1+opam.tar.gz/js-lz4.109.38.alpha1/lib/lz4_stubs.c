#include <lz4.h>
#include <lz4hc.h>
#include <caml/mlvalues.h>
#include <caml/memory.h>
#include <caml/alloc.h>
#include <caml/custom.h>
#include <string.h>
#include <stdio.h>
#include <caml/signals.h>
#include <caml/bigarray.h>

static inline char * get_bstr(value v_bstr, value v_pos)
{
  return (char *) Caml_ba_data_val(v_bstr) + Long_val(v_pos);
}

///////////////////////////////////////////////////////////////////////
// A ctx pointer tracked by the OCaml GC that can be used for explicit
// ctx based operations.

typedef struct _ctx_ptr {
  void * ctx;
} ctx_ptr;

// Finalize ctxs by freeing memory in the C heap.
void finalize_ctx_ptr( value v )
{
    ctx_ptr * ctx = (ctx_ptr *) Data_custom_val(v);
    if (ctx->ctx != 0)
      free( ctx->ctx );
}

// Dispatch table for the ctx_ptr type
static struct custom_operations ctx_ptr_custom_ops = {
    identifier: "ctx pointer",
    finalize:    finalize_ctx_ptr,
    compare:     custom_compare_default,
    hash:        custom_hash_default,
    serialize:   custom_serialize_default,
    deserialize: custom_deserialize_default
};

// Allocate an empty ctx. The ctx is allocated data by the LZ4 ctx
// functions.
CAMLprim value _create_ctx(value unit)
{
  CAMLparam1(unit);
  CAMLlocal1(v);

  ctx_ptr ctx;
  ctx.ctx = 0;

  v = caml_alloc_custom( &ctx_ptr_custom_ops, sizeof(ctx_ptr), 0, 1);
  memcpy( Data_custom_val(v), &ctx, sizeof(ctx_ptr) );
  CAMLreturn(v);
}

//////////////////////////////////////////////////////////////////
// Bindings for LZ4 api

CAMLprim value _LZ4_compressBound(value isize)
{
  CAMLparam1(isize);
  int osize = LZ4_compressBound(Int_val(isize));
  CAMLreturn (Val_int(osize));
}


//////////////////////////////////////////////////////////////////////
// Compress and Uncompress for OCaml Strings

CAMLprim value _LZ4_compress_string(value src, value dst, value isize)
{
  CAMLparam3(src, dst, isize);
  char* src_c = String_val(src);
  char* dst_c = String_val(dst);

  int   res   = LZ4_compress(src_c, dst_c, Int_val(isize));
  CAMLreturn (Val_int(res));
}

CAMLprim value _LZ4_compressHC_string(value src, value dst, value isize)
{
  CAMLparam3(src, dst, isize);
  char* src_c = String_val(src);
  char* dst_c = String_val(dst);

  int res = LZ4_compressHC(src_c, dst_c, Int_val(isize));
  CAMLreturn (Val_int(res));
}


CAMLprim value _LZ4_compress_limitedOutput_string(value src, value dst,
                                      value isize, value maxOutputSize)
{
  CAMLparam4(src, dst, isize, maxOutputSize);
  char* src_c = String_val(src);
  char* dst_c = String_val(dst);

  int res = LZ4_compress_limitedOutput(src_c, dst_c,
                                       Int_val(isize), Int_val(maxOutputSize));
  CAMLreturn (Val_int(res));
}


// Compress with Ctx

CAMLprim value _LZ4_compressCtx_string(value ctx, value src, value dst,
                                       value isize, value maxOutputSize)
{
  CAMLparam5(ctx, src, dst, isize, maxOutputSize);
  ctx_ptr * pctx  = (ctx_ptr *) Data_custom_val(ctx);
  char* src_c = String_val(src);
  char* dst_c = String_val(dst);

  /* printf("before *ctx %x **ctx %x ", (int)pctx->ctx, (int) &(pctx->ctx)); */
  int res = LZ4_compressCtx(&(pctx->ctx), src_c, dst_c,
                            Int_val(isize), Int_val(maxOutputSize));
  /* printf("after *ctx %x **ctx %x\n", (int)pctx->ctx, (int) &(pctx->ctx)); */

  CAMLreturn (Val_int(res));
}

CAMLprim value _LZ4_compress64kCtx_string(value ctx, value src, value dst,
                                          value isize, value maxOutputSize)
{
  CAMLparam5(ctx, src, dst, isize, maxOutputSize);
  ctx_ptr * pctx = (ctx_ptr *) Data_custom_val(ctx);
  char* src_c = String_val(src);
  char* dst_c = String_val(dst);

  /* printf("before *ctx %x **ctx %x ", (int)pctx->ctx, (int) &(pctx->ctx)); */
  int res = LZ4_compress64kCtx(&(pctx->ctx), src_c, dst_c,
                               Int_val(isize), Int_val(maxOutputSize));
  /* printf("after *ctx %x **ctx %x\n", (int)pctx->ctx, (int) &(pctx->ctx)); */
  CAMLreturn (Val_int(res));
}

// Uncompress

CAMLprim value _LZ4_uncompress_string(value src, value dst, value osize)
{
  CAMLparam3(src, dst, osize);
  char* src_c = String_val(src);
  char* dst_c = String_val(dst);

  int   res   = LZ4_uncompress(src_c, dst_c, Int_val(osize));
  CAMLreturn (Val_int(res));
}

CAMLprim value
_LZ4_uncompress_unknownOutputSize_string (value src, value dst,
                                         value isize, value maxOutputSize)
{
  CAMLparam4(src, dst, isize, maxOutputSize);
  char* src_c = String_val(src);
  char* dst_c = String_val(dst);

  int res = LZ4_uncompress_unknownOutputSize(src_c, dst_c,
                                             Int_val(isize), Int_val(maxOutputSize));
  CAMLreturn (Val_int(res));
}


//////////////////////////////////////////////////////////////////////
// Compress and Uncompress for OCaml Bigstrings

CAMLprim value _LZ4_compress_bigstring(value src, value dst, value isize)
{
  CAMLparam3(src, dst, isize);
  char* src_c = get_bstr(src, 0);
  char* dst_c = get_bstr(dst, 0);

  caml_enter_blocking_section();
  int   res   = LZ4_compress(src_c, dst_c, Int_val(isize));
  caml_leave_blocking_section();
  CAMLreturn (Val_int(res));
}

CAMLprim value _LZ4_compressHC_bigstring(value src, value dst, value isize)
{
  CAMLparam3(src, dst, isize);
  char* src_c = get_bstr(src, 0);
  char* dst_c = get_bstr(dst, 0);

  caml_enter_blocking_section();
  int res = LZ4_compressHC(src_c, dst_c, Int_val(isize));
  caml_leave_blocking_section();
  CAMLreturn (Val_int(res));
}


CAMLprim value _LZ4_compress_limitedOutput_bigstring(value src, value dst,
                                      value isize, value maxOutputSize)
{
  CAMLparam4(src, dst, isize, maxOutputSize);
  char* src_c = get_bstr(src, 0);
  char* dst_c = get_bstr(dst, 0);

  caml_enter_blocking_section();
  int res = LZ4_compress_limitedOutput(src_c, dst_c,
                                       Int_val(isize), Int_val(maxOutputSize));
  caml_leave_blocking_section();
  CAMLreturn (Val_int(res));
}


// Compress with Ctx

CAMLprim value _LZ4_compressCtx_bigstring(value ctx, value src, value dst,
                                          value isize, value maxOutputSize)
{
  CAMLparam5(ctx, src, dst, isize, maxOutputSize);
  ctx_ptr * pctx  = (ctx_ptr *) Data_custom_val(ctx);
  char* src_c = get_bstr(src, 0);
  char* dst_c = get_bstr(dst, 0);

  /* printf("before *ctx %x **ctx %x ", (int)pctx->ctx, (int) &(pctx->ctx)); */
  caml_enter_blocking_section();
  int res = LZ4_compressCtx(&(pctx->ctx), src_c, dst_c,
                            Int_val(isize), Int_val(maxOutputSize));
  caml_leave_blocking_section();
  /* printf("after *ctx %x **ctx %x\n", (int)pctx->ctx, (int) &(pctx->ctx)); */
  CAMLreturn (Val_int(res));
}

CAMLprim value _LZ4_compress64kCtx_bigstring(value ctx, value src, value dst,
                                             value isize, value maxOutputSize)
{
  CAMLparam5(ctx, src, dst, isize, maxOutputSize);
  ctx_ptr * pctx = (ctx_ptr *) Data_custom_val(ctx);
  char* src_c = get_bstr(src, 0);
  char* dst_c = get_bstr(dst, 0);

  /* printf("before *ctx %x **ctx %x ", (int)pctx->ctx, (int) &(pctx->ctx)); */
  caml_enter_blocking_section();
  int res = LZ4_compress64kCtx(&(pctx->ctx), src_c, dst_c,
                               Int_val(isize), Int_val(maxOutputSize));
  caml_leave_blocking_section();
  /* printf("after *ctx %x **ctx %x\n", (int)pctx->ctx, (int) &(pctx->ctx)); */
  CAMLreturn (Val_int(res));
}

// Uncompress

CAMLprim value _LZ4_uncompress_bigstring(value src, value dst, value osize)
{
  CAMLparam3(src, dst, osize);
  char* src_c = get_bstr(src, 0);
  char* dst_c = get_bstr(dst, 0);

  caml_enter_blocking_section();
  int   res   = LZ4_uncompress(src_c, dst_c, Int_val(osize));
  caml_leave_blocking_section();
  CAMLreturn (Val_int(res));
}

CAMLprim value
_LZ4_uncompress_unknownOutputSize_bigstring (value src, value dst,
                                            value isize, value maxOutputSize)
{
  CAMLparam4(src, dst, isize, maxOutputSize);
  char* src_c = get_bstr(src, 0);
  char* dst_c = get_bstr(dst, 0);

  caml_enter_blocking_section();
  int res = LZ4_uncompress_unknownOutputSize(src_c, dst_c,
                                             Int_val(isize), Int_val(maxOutputSize));
  caml_leave_blocking_section();
  CAMLreturn (Val_int(res));
}


