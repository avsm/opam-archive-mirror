open Core.Std

(****************************************************************************************)
(* Bound calculation *)
external compressBound: int -> int
  = "_LZ4_compressBound"

(* Ctx routines *)
type ctx

external create_ctx: unit -> ctx
  = "_create_ctx"

(****************************************************************************************)
(* String routines *)

module Lz4_string = struct

  external compress: source:string -> dest:string
    -> isize:int -> int
      = "_LZ4_compress_string"

  external compressHC: source:string -> dest:string
    -> isize:int -> int
      = "_LZ4_compressHC_string"

  external compress_limitedOutput: source:string -> dest:string
    -> isize:int -> maxOutputSize:int -> int
      = "_LZ4_compress_limitedOutput_string"

  external compressCtx: ctx -> source:string -> dest:string
    -> isize:int -> maxOutputSize:int -> int
      = "_LZ4_compressCtx_string"

  external compress64kCtx: ctx -> source:string -> dest:string
    -> isize:int -> maxOutputSize:int -> int
      = "_LZ4_compress64kCtx_string"

  external uncompress: source:string -> dest:string
    -> osize:int -> int
      = "_LZ4_uncompress_string"

  external uncompress_unknownOutputSize: source:string -> dest:string
    -> isize:int -> maxOutputSize:int -> int
      = "_LZ4_uncompress_unknownOutputSize_string"

  let make_compression_dest_from_size size =
    String.create (compressBound size)

  let make_compression_dest source =
    make_compression_dest_from_size (String.length source)

end

(****************************************************************************************)
(* Bigstring routines *)

module Lz4_bigstring = struct

  external compress: source:Bigstring.t -> dest:Bigstring.t
    -> isize:int -> int
      = "_LZ4_compress_bigstring"

  external compressHC: source:Bigstring.t -> dest:Bigstring.t
    -> isize:int -> int
      = "_LZ4_compressHC_bigstring"

  external compress_limitedOutput: source:Bigstring.t -> dest:Bigstring.t
    -> isize:int -> maxOutputSize:int -> int
      = "_LZ4_compress_limitedOutput_bigstring"

  external compressCtx: ctx -> source:Bigstring.t -> dest:Bigstring.t
    -> isize:int -> maxOutputSize:int -> int
      = "_LZ4_compressCtx_bigstring"

  external compress64kCtx: ctx -> source:Bigstring.t -> dest:Bigstring.t
    -> isize:int -> maxOutputSize:int -> int
      = "_LZ4_compress64kCtx_bigstring"

  external uncompress: source:Bigstring.t -> dest:Bigstring.t
    -> osize:int -> int
      = "_LZ4_uncompress_bigstring"

  external uncompress_unknownOutputSize: source:Bigstring.t -> dest:Bigstring.t
    -> isize:int -> maxOutputSize:int -> int
      = "_LZ4_uncompress_unknownOutputSize_bigstring"

  let make_compression_dest_from_size size =
    Bigstring.create (compressBound size)

  let make_compression_dest source =
    make_compression_dest_from_size (Bigstring.length source)

end

(****************************************************************************************)
(* Tests *)

TEST_MODULE "LZ4 test" = struct

  let str1 = "There are six CAMLparam macros: CAMLparam0 to CAMLparam5, which take
  zero to five arguments respectively. If your function has fewer than 5 parameters of
  type value, use the corresponding macros with these parameters as arguments. If your
  function has more than 5 parameters of type value, use CAMLparam5 with five of these
  parameters, and use one or more calls to the CAMLxparam macros for the remaining
  parameters (CAMLxparam1 to CAMLxparam5)."

  let str2 = "The compressed stream is composed of sequences.
  Each sequence starts with a token. The token is a one byte value, separated into two
  4-bits fields (which therefore range from 0 to 15). The first field is to indicate the
  length of literals. If it is 0, then there is no literal. If it is 15, then we need to add
  some more bytes to indicate the full length. Each additionnal
  byte then represent a value of 0 to 255, which is added to the previous value to produce a
  total length. When the byte value is 255, another byte is output. There can be any number
  of bytes following the token."

  let str3 = "The size of the hash table can be modified while respecting full format
  compatibility. For restricted memory systems, this is an important feature, since the
  hash size can be reduced to 15 bits, or 12 bits, or even 10 bits (1024 positions,
  needing only 4K). Obviously, the smaller the table, the more collisions (false positive)
  we get, reducing compression power. But it nonetheless still works, and remain fully
  compatible with more complex and memory-hungry versions. The decoder do not care of the
  method used to find matches, and requires no additional memory.
  The fast version of LZ4 hosted on Google Code uses a fast scan strategy, which is a
  single- cell wide hash table. Each position in the input stream gets hashed, using the first 4
  bytes (minmatch). Then the position is stored at the hashed position.
  The size of the hash table can be modified while respecting full format compatibility. For
  restricted memory systems, this is an important feature, since the hash size can be
  reduced to 15 bits, or 12 bits, or even 10 bits (1024 positions, needing only
  4K). Obviously, the smaller the table, the more collisions (false positive) we get,
  reducing compression power. But it nonetheless still works, and remain fully compatible
  with more complex and memory-hungry versions. The decoder do not care of the method used
  to find matches, and requires no additional memory."

  let bigstr1 = Bigstring.of_string str1
  let bigstr2 = Bigstring.of_string str2
  let bigstr3 = Bigstring.of_string str3

  let check_string_compression source compress =
    let isize = String.length source in
    let dest = Lz4_string.make_compression_dest source in
    let result_str1 = String.create isize in
    let result_str2 = String.create isize in


    let compressed_size = compress ~source ~dest ~isize in
    (* now uncompress it two different ways *)
    let bytes_read = Lz4_string.uncompress
      ~source:dest
      ~dest:result_str1
      ~osize:isize in
    let bytes_produced = Lz4_string.uncompress_unknownOutputSize
      ~source:dest
      ~dest:result_str2
      ~isize:compressed_size
      ~maxOutputSize:isize in

    (compressed_size <= (compressBound isize))
    && (String.equal result_str1 source)
    && (bytes_read = compressed_size)
    && (String.equal result_str2 source)
    && (bytes_produced = isize)
  ;;


  let check_bigstring_compression source compress =
    let isize = Bigstring.length source in
    let dest = Lz4_bigstring.make_compression_dest source in
    let result_str1 = Bigstring.create isize in
    let result_str2 = Bigstring.create isize in

    let compressed_size = compress ~source ~dest ~isize in
    let bytes_read = Lz4_bigstring.uncompress
      ~source:dest
      ~dest:result_str1
      ~osize:isize in
    let bytes_produced = Lz4_bigstring.uncompress_unknownOutputSize
      ~source:dest
      ~dest:result_str2
      ~isize:compressed_size
      ~maxOutputSize:isize in

    (* let f = (compressed_size <= (compressBound isize))
     *   && (result_str1 = source)
     *   && (bytes_read = compressed_size)
     *   && (result_str2 = source)
     *   && (bytes_produced = isize)
     * in if not f then begin
     *   printf "compressed_size %d, bytes_read %d, bytes_produced %d, isize %d"
     *     compressed_size bytes_read bytes_produced isize
     * end; *)

    (compressed_size <= (compressBound isize))
    && (result_str1 = source)
    && (bytes_read = compressed_size)
    && (result_str2 = source)
    && (bytes_produced = isize)
  ;;


  (* unit tests*)
  (* strings *)
  TEST = check_string_compression str1 Lz4_string.compress;;
  TEST = check_string_compression str2 Lz4_string.compress;;
  TEST = check_string_compression str3 Lz4_string.compress;;

  TEST = check_string_compression str1 Lz4_string.compressHC;;
  TEST = check_string_compression str2 Lz4_string.compressHC;;
  TEST = check_string_compression str3 Lz4_string.compressHC;;

  let maxOutputSize = compressBound (String.length str1);;
  TEST = check_string_compression str1 (Lz4_string.compress_limitedOutput ~maxOutputSize);;
  let maxOutputSize = compressBound (String.length str2);;
  TEST = check_string_compression str2 (Lz4_string.compress_limitedOutput ~maxOutputSize);;
  let maxOutputSize = compressBound (String.length str3);;
  TEST = check_string_compression str3 (Lz4_string.compress_limitedOutput ~maxOutputSize);;

  let ctx = create_ctx ();;

  let maxOutputSize = compressBound (String.length str1);;
  TEST = check_string_compression str1 (Lz4_string.compressCtx ctx ~maxOutputSize);;
  let maxOutputSize = compressBound (String.length str2);;
  TEST = check_string_compression str2 (Lz4_string.compressCtx ctx ~maxOutputSize);;
  let maxOutputSize = compressBound (String.length str3);;
  TEST = check_string_compression str3 (Lz4_string.compressCtx ctx ~maxOutputSize);;

  let maxOutputSize = compressBound (String.length str1);;
  TEST = check_string_compression str1 (Lz4_string.compress64kCtx ctx ~maxOutputSize);;
  let maxOutputSize = compressBound (String.length str2);;
  TEST = check_string_compression str2 (Lz4_string.compress64kCtx ctx ~maxOutputSize);;
  let maxOutputSize = compressBound (String.length str3);;
  TEST = check_string_compression str3 (Lz4_string.compress64kCtx ctx ~maxOutputSize);;


  (* bigstrings *)
  TEST = check_bigstring_compression bigstr1 Lz4_bigstring.compress;;
  TEST = check_bigstring_compression bigstr2 Lz4_bigstring.compress;;
  TEST = check_bigstring_compression bigstr3 Lz4_bigstring.compress;;

  TEST = check_bigstring_compression bigstr1 Lz4_bigstring.compressHC;;
  TEST = check_bigstring_compression bigstr2 Lz4_bigstring.compressHC;;
  TEST = check_bigstring_compression bigstr3 Lz4_bigstring.compressHC;;

  let maxOutputSize = compressBound (Bigstring.length bigstr1);;
  TEST = check_bigstring_compression bigstr1 (Lz4_bigstring.compress_limitedOutput ~maxOutputSize);;
  let maxOutputSize = compressBound (Bigstring.length bigstr2);;
  TEST = check_bigstring_compression bigstr2 (Lz4_bigstring.compress_limitedOutput ~maxOutputSize);;
  let maxOutputSize = compressBound (Bigstring.length bigstr3);;
  TEST = check_bigstring_compression bigstr3 (Lz4_bigstring.compress_limitedOutput ~maxOutputSize);;

  let ctx = create_ctx ();;

  let maxOutputSize = compressBound (Bigstring.length bigstr1);;
  TEST = check_bigstring_compression bigstr1 (Lz4_bigstring.compressCtx ctx ~maxOutputSize);;
  let maxOutputSize = compressBound (Bigstring.length bigstr2);;
  TEST = check_bigstring_compression bigstr2 (Lz4_bigstring.compressCtx ctx ~maxOutputSize);;
  let maxOutputSize = compressBound (Bigstring.length bigstr3);;
  TEST = check_bigstring_compression bigstr3 (Lz4_bigstring.compressCtx ctx ~maxOutputSize);;

  let maxOutputSize = compressBound (Bigstring.length bigstr1);;
  TEST = check_bigstring_compression bigstr1 (Lz4_bigstring.compress64kCtx ctx ~maxOutputSize);;
  let maxOutputSize = compressBound (Bigstring.length bigstr2);;
  TEST = check_bigstring_compression bigstr2 (Lz4_bigstring.compress64kCtx ctx ~maxOutputSize);;
  let maxOutputSize = compressBound (Bigstring.length bigstr3);;
  TEST = check_bigstring_compression bigstr3 (Lz4_bigstring.compress64kCtx ctx ~maxOutputSize);;

end

