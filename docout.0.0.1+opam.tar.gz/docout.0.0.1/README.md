Docout
======

This module creates a `Logging` module based on the `smart_print` library (only
dependency).

The module `Docout.Make_logger` takes a `LOGGER_CONFIGURATION` and
produces a `LOGGER` (which includes the `SmartPrint` module as well).

Example:

```ocaml
let global_debug_level = ref 2
let global_with_color = ref true
module Log = 
  Docout.Make_logger (struct
    type ('a, 'b) result = 'a
    let debug_level () = !global_debug_level
    let with_color () = !global_with_color
    let line_width = 72
    let indent = 4
    let print_string = Printf.eprintf "%s%!"
    let do_nothing () = ()
    let name = "ketrew"
  end)
```

Then one can build documents and display them:


```ocaml
Log.(s "Some string " % i 42 % sf ", %S" "quoted"
     % sp % brakets (OCaml.list f [3.14; 4.2])
     @ very_verbose);
```
