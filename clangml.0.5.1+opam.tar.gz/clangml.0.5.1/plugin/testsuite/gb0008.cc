// gb0008.cc
// refer to std::type_info without declaring

// rejected by ICC

std::type_info *p;

