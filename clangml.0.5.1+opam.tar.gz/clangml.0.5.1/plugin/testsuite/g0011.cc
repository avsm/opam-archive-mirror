// g0011.cc
// __attribute__ in a parameter list
// from Kevin Millikin

void foo(const int __attribute__ ((__unused__)) x) { return; }
