void encode_rgb_frame (int w) {
  int sample_buffer[3][w + 6];
  sizeof sample_buffer;
}
