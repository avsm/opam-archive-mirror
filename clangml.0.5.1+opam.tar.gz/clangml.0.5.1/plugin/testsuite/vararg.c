extern int Printf(const char * format, ...);
extern int printf(const char * format, ...);
