// g0001.cc
// "__restrict__" keyword
// I think this is a gnu thing

int * __restrict__ x;
