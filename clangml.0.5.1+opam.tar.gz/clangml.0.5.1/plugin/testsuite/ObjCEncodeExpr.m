struct foo{
	int a;
};

const char *encoding = @encode(struct foo);
