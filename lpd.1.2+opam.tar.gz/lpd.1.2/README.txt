(* OASIS_START *)
(* DO NOT EDIT (digest: bf74f622fe3cd06c5685622177393f18) *)
This is the README file for the lpd distribution.

A Line Printer Daemon (LPD) server library written entirely in OCaml.

Lpd is a Line Printer Daemon compliant with RFC 1179 written entirely in
OCaml. It allows to define your own actions for LPD events.  An example of a
spooler that prints jobs on win32 machines (through GSPRINT) is provided.

See the files INSTALL.txt for building and installation instructions. 

Home page: http://lpd.forge.ocamlcore.org/


(* OASIS_STOP *)
