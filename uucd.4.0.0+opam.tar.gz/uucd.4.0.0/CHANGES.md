
v4.0.0 2016-06-26 Cambridge (UK)
--------------------------------

- Updated for Unicode 9.0.0
- Build depend on topkg.
- Relicensed from BSD3 to ISC.

v3.0.0 2015-06-17 Cambridge (UK)
--------------------------------

- Updated for Unicode 8.0.0

v2.0.0 2014-06-16 Cambridge (UK)
--------------------------------

- Updated for Unicode 7.0.0

v1.0.0 2013-10-01 Lausanne
--------------------------

- Updated for Unicode 6.3.0.
- OPAM friendly workflow and drop OASIS support.

v0.9.2 2013-01-04 La Forclaz (VS)
---------------------------------

- Updated for Unicode 6.2.0.

v0.9.1 2013-01-04 La Forclaz (VS)
---------------------------------

- Fix Uucd.is_scalar_value always returning false.

v0.9.0 2012-09-07 Lausanne
--------------------------

First release.
