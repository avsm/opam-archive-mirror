<!--- OASIS_START --->
<!--- DO NOT EDIT (digest: 74e8f6e0aa3d228be4e5ff4000af2f18) --->

Authors of opam-build-revdeps:

* Sylvain Le Gall

Current maintainers of opam-build-revdeps:

* Sylvain Le Gall <sylvain@le-gall.net>>

<!--- OASIS_STOP --->
