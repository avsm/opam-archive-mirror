open! Import

type 'a t = 'a

let stage   = Fn.id
let unstage = Fn.id
