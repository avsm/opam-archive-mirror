let tag s = print_string (s^"\n") ; flush stdout
