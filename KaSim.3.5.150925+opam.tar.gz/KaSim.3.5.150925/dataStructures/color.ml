type color = Red | Grey | Lightblue | Black 

let triple_of_color = 
  function  
  | Red -> (255,0,0)
  | Grey -> (128,128,128)
  | Lightblue -> (0,0,128)
  | Black -> (0,0,0)
