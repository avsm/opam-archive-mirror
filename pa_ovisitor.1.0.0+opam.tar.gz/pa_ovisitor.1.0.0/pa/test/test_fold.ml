let sum = ref 0 

type 'a t = 
  | Foo of int list 
  | Bar of int * int * 'a
  | Goo of 'a ts
  | Gaa of 'a t2 list

and 'a ts = 'a t list

and 'a t2 = 'a t * 'a t

with ofold

class o' = object (self:'self)
  inherit [int] ofold
  method int st n = st + n
  method list = fun fa -> List.fold_left (fun st x -> fa st x) 
  method unit (st : int) () = st
end


let _ = 
  let v = new o' in
  assert (v#t v#int 0 (Foo [ 1; 2; 3; 4; 5 ]) = 15);
  assert (v#t v#int 0 (Bar (1, 2, 3)) = 6);
  assert (v#t v#unit 0 (Bar (1, 2, ())) = 3)
