exception (* E => *) E (* <= E *)
exception X = E (* ? E *) (* bug 090818 *)

