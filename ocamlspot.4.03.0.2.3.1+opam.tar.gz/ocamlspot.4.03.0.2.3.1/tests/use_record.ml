let _ = { Record.
            foo = 1;
          bar = 1.0 }
  
