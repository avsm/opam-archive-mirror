(* OASIS_START *)
(* DO NOT EDIT (digest: f3cd57cfc6dd0daa1d633b6650e65b65) *)
This is the README file for the quickcheck distribution.

OCaml port of Haskell QuickCheck for probabilistic testing

See the files INSTALL.txt for building and installation instructions. See the
file LICENSE for copying conditions. 


(* OASIS_STOP *)

SEE README.md
