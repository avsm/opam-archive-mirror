open Ppxx (* must come after Ast_helper *)
open Ast_mapper
open Parsetree
open Longident
open Location

let is_m s =
  match Longident.parse s with
  | Lident "m" -> Some None
  | Ldot (l, "m") -> Some (Some l)
  | _ -> None
  | exception _ -> None

let is_do e = match e.pexp_desc with
  | Pexp_ident {txt=Lident "do_"} -> Some None
  | Pexp_ident {txt=Ldot (lid, "do_"); loc} -> Some (Some {txt=lid; loc})
  | _ -> None
  
let is_do_clause e = match e.pexp_desc with
  | Pexp_sequence (e1, e2) -> 
      (* e1; e2; e3   is  e1; (e2; e3) *)
      begin match is_do e1 with
      | None -> None
      | Some lo -> Some (lo, e2)
      end
  | _ ->
      match is_do e with
      | None -> None
      | Some _ ->
          raise_errorf ~loc:e.pexp_loc "ppx_monadic: do_ must be followed by ;"

let desugar_do e = 
  let rec desugar = function
    | `Expr (e, None) -> 
        (* <(); e> => e *) 
        (* <e> (* last *) => e *)
        e

    | `Expr (e1, Some e2) -> 
        (* <(); e1; e2> => e1; <e2> *) 
        [%expr [%e e1] ; [%e desugar e2] ]
  
    | `Bind (loc, _, _, None) ->
        raise_errorf ~loc "The last expression of do_ cannot have the form p <-- e"
  
    | `Bind (_loc, p, e1, Some e2) ->
        (* <p <-- e1; e2> => bind e1 (fun p -> <e2>)  *)
        [%expr 
            bind [%e e1] (fun [%p p] -> [%e desugar e2])
        ]
          
    | `BindUnit (_loc, e1, e2) ->
        (* <e1; e2> => bind e1 (fun () -> <e2>) *)
        [%expr
            bind [%e e1] (fun () -> [%e desugar e2])
        ]

    | `Let (e, body) ->
        begin match e.pexp_desc with
        | Pexp_let(rf, vbs, _) ->
            (* <let p = e1 in e2> => let p = e1 in <e2> *)
            { e with pexp_desc = Pexp_let (rf, vbs, desugar body) }  
        
        | Pexp_letmodule(s, mexp, _) ->
            (* <let module M = mexp in e2> => let module M = mexp in <e2> *)
            { e with pexp_desc = Pexp_letmodule(s, mexp, desugar body) }  
        
        | Pexp_open(ov, lid, _) ->
            (* <let open M in e2> => let open M in <e2> *)
            { e with pexp_desc = Pexp_open(ov, lid, desugar body) }  
  
        | _ -> assert false
        end
    
    | `Ext (e, body) ->
        begin match e.pexp_desc with
        | Pexp_extension ( ext,
                           PStr [({ pstr_desc= Pstr_eval (_, attr) } as sitem)]) ->
            (* <let%m p = e1 in e2> => let%m p = e1 in <e2> 
               
               If you do not want ppx_monadic invades in your extension,
               use (); [%your_ext ..];
            *)
            { e with pexp_desc =
                Pexp_extension ( ext,
                                 PStr [{ sitem with pstr_desc = Pstr_eval ( desugar body, attr) }]) }
        | _ -> assert false
        end
  in
  desugar & Monadic.parse_do e

let extend super = 
  let expr self e = 
    match is_do_clause e with
    | Some (None, e) ->
        (* Format.eprintf "do_ clause: %a@." Pprintast.expression e; *)
        self.expr self & desugar_do e
    | Some (Some lid, e) ->
        (* Format.eprintf "do_ clause: %a@." Pprintast.expression e; *)
        (* self.expr self & Exp.open_ Fresh lid & desugar_do e *)
        let m_dot s = Exp.ident {txt= Ldot (lid.txt, s); loc=Location.none} in
        (* let in_m s = Exp.open_ Override lid & Exp.var s in *)
        self.expr self &
          [%expr
             let bind   = [%e m_dot "bind"] in
             let return = [%e m_dot "return"] in
             (* the following is to surpress Warning 26 *)
             let _ = bind in
             let _ = return in
             (* I believe having fail is not a good idea... *)  
             [%e desugar_do e]
          ]
               
    | None ->
        match e.pexp_desc with
        | Pexp_extension ({txt=x; loc}, PStr [{ pstr_desc= Pstr_eval ({ pexp_desc = Pexp_let(rec_flag, vbs, e)}, _attr) }]) ->
            (* let%XXX p = e1 in e2 *)
            begin match is_m x with
            | None -> super.expr self e
            | Some lidopt ->
                if rec_flag = Recursive then
                  raise_errorf ~loc:e.pexp_loc "ppx_monadic: let%%m cannot be recursive";
                match vbs with
                | [] -> assert false (* impos *)
                | [vb] ->
                    let bind = match lidopt with
                      | None -> [%expr bind]
                      | Some l -> Exp.ident ~loc {txt= Ldot (l, "bind"); loc}
                    in
                    self.expr self
                    & [%expr
                           [%e bind] [%e vb.pvb_expr] (fun [%p vb.pvb_pat] -> [%e e])
                       ]
                | _ ->
                    raise_errorf ~loc:e.pexp_loc "ppx_monadic: let%%m can take only one binding"
            end
        | _ -> super.expr self e
  in
  { super with expr }

let mapper = extend default_mapper

let () = Ppxx.run "ppx_monadic" mapper
