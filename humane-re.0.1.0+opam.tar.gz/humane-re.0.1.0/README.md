humane-re
=========

Don't have a whole lot of time to read mli's? Do you just want to quickly split a string and get on with your life?

Well you've come to the right place. Humane-re attempts to provide an easy interface for 90% of your regex needs
Courtesy of ocaml-re, it's also free of:

* C/C++ dependencies (re2, pcre)

* Global variables (str)
