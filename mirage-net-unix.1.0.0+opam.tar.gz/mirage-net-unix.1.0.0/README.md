mirage-net-unix
=================

Unix implementation of the Mirage NETWORK interface.

This interface exposes raw Ethernet frames using `ocaml-tuntap`,
suitable for use with an OCaml network stack such as the one
found at <https://github.com/mirage/mirage-net>.
