open Core.Std

let _squelch_unused_module_warning_ = ()

let concat = String.concat

let log message a sexp_of_a =
  eprintf "%s\n%!" (Sexp.to_string_hum (<:sexp_of< string * a >> (message, a)))
;;

let does_fail f = Result.is_error (Result.try_with f)

include Int.Replace_polymorphic_compare

module Poly = Polymorphic_compare
