(* Copyright (C) 2013, Thomas Leonard
 * See the README file for details, or visit http://0install.net.
 *)

(** Information about this software *)

let version = "2.6.2"

let parsed_version = Versions.parse_version version
