let x = 3

module F = struct
  let y x = x + 4
end

let z x = x + 5
