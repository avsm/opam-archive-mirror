module Api = struct
  include TelegramApi
end
