# TelegraML

OCaml implementation of the Telegram Bot API

## Documentation:

Full OCamldoc-generated documentation is available [here](http://nv-vn.github.io/TelegraML/).

## Demos, examples, and users:
[glgbot](https://github.com/nv-vn/glgbot)
