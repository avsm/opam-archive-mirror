let default_browser_command = "xdg-open"
