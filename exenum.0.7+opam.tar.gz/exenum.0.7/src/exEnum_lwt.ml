open Exenum_internals
       
let lwt_tester exen ?from ?upto ?verbose_period ~len f =
 Tester.gen_tester Lwt_io.print Lwt.bind Lwt.return_unit (ExEnum.get_exen exen) ?from ?upto ?verbose_period ~len f
