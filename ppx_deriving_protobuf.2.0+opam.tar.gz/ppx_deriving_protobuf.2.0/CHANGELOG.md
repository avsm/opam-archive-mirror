Changelog
=========

2.0
---

  * Update to accomodate syntactic changes in _deriving_ 1.0.

1.0.0
-----

  * First stable release and initial release as _deriving Protobuf_.
