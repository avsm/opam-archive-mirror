let package_name = "async_rpc_kernel"

let sections =
  [ ("lib",
    [ ("built_lib_async_rpc_kernel", None)
    ],
    [ ("META", None)
    ])
  ]
