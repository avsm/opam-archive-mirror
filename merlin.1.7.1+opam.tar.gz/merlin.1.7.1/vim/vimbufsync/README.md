vimbufsync
==========

Collection of heuristics to help quickly detect modifications in vim buffers
