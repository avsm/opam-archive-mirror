[![Build Status](https://travis-ci.org/slegrand45/mysql_protocol.svg?branch=master)](https://travis-ci.org/slegrand45/mysql_protocol)


mysql_protocol
==============

OCaml implementation of the native MySQL Protocol with the Bitstring library.

- [Tutorial][tutorial]

[tutorial]: https://github.com/slegrand45/mysql_protocol/blob/master/tutorials/tutorial.pdf?raw=true

