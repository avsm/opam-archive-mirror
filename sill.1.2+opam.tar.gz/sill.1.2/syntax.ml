module Full = struct include Fullsyntax end
module Core = struct include Coresyntax end
