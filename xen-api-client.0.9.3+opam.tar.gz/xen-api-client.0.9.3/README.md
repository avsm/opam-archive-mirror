Ocaml client for the Xen API.

Depends on: Xmlm, Lwt, SSL

Check out the example in: lwt_test/list_vms.ml


