# CI scripts for OCaml projects

Supported CI:

- **stable**: [Travis CI](/README-travis.md) Ubuntu, Debian and OSX workers.
- **experimental**: [Appveyor](/README-appveyor.md) Windows Server 2012 R2 (x64) workers.
