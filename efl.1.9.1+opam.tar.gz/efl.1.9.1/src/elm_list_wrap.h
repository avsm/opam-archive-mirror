#ifndef ELM_LIST_H
#define ELM_LIST_H

#include "include.h"

inline Elm_List_Mode Elm_List_Mode_val(value v);
inline value Val_Elm_List_Mode(Elm_List_Mode m);

#endif
