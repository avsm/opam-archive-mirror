(* Vectors *)
#install_printer Pp.Toplevel.gen_pp_vec

(* Matrices *)
#install_printer Pp.Toplevel.gen_pp_mat

(* Array3 *)
#install_printer Pp.Toplevel.gen_pp_ar3

(* Genarray *)
#install_printer Pp.Toplevel.gen_pp_gen
