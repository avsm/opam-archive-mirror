Version 0.0.2 (2016-04-17):
---------------------------
  _ Added support for 4.03.0
  - Made operation an argument in fold_ppx.
  - Added labeled arguments.

Version 0.0.1 (2016-01-06):
---------------------------
  - Release to the world: Pretty printers, generators and folds via ppx.
