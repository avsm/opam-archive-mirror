let x = 1

external foo : unit -> unit = "foo_stub"
