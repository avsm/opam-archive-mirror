# Solvuu_build release notes

## solvuu_build 0.0.2 2016-02-23
* Support compilation of C files.
* Installation of each sub-library of a project now goes into its own
  sub-directory.

## solvuu_build 0.0.1 2016-02-15
* Initial release.
