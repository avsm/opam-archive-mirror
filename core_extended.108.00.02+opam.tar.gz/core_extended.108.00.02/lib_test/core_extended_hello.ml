open Core.Std
open Core_extended.Std

let () =
  print_endline "This binary is only used to check what gets linked in by core_extended"
