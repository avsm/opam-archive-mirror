## v0.0.1 2016-10-26

First release.

Synced to `mirage-types-2.80`.
