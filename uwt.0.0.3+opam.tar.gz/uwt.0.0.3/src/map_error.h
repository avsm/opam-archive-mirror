#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wenum-compare"
_Static_assert( UV_E2BIG < 0 && UV_E2BIG >= INT16_MIN,"out of range");
_Static_assert( UV_E2BIG != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_E2BIG != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_E2BIG != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_E2BIG != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_E2BIG != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_E2BIG != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_E2BIG != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_E2BIG != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EACCES < 0 && UV_EACCES >= INT16_MIN,"out of range");
_Static_assert( UV_EACCES != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EACCES != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EACCES != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EACCES != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EACCES != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EACCES != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EACCES != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EACCES != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EADDRINUSE < 0 && UV_EADDRINUSE >= INT16_MIN,"out of range");
_Static_assert( UV_EADDRINUSE != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EADDRINUSE != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EADDRINUSE != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EADDRINUSE != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EADDRINUSE != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EADDRINUSE != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EADDRINUSE != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EADDRINUSE != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EADDRNOTAVAIL < 0 && UV_EADDRNOTAVAIL >= INT16_MIN,"out of range");
_Static_assert( UV_EADDRNOTAVAIL != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EADDRNOTAVAIL != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EADDRNOTAVAIL != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EADDRNOTAVAIL != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EADDRNOTAVAIL != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EADDRNOTAVAIL != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EADDRNOTAVAIL != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EADDRNOTAVAIL != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EAFNOSUPPORT < 0 && UV_EAFNOSUPPORT >= INT16_MIN,"out of range");
_Static_assert( UV_EAFNOSUPPORT != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EAFNOSUPPORT != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EAFNOSUPPORT != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EAFNOSUPPORT != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EAFNOSUPPORT != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EAFNOSUPPORT != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EAFNOSUPPORT != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EAFNOSUPPORT != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EAGAIN < 0 && UV_EAGAIN >= INT16_MIN,"out of range");
_Static_assert( UV_EAGAIN != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EAGAIN != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EAGAIN != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EAGAIN != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EAGAIN != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EAGAIN != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EAGAIN != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EAGAIN != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EAI_ADDRFAMILY < 0 && UV_EAI_ADDRFAMILY >= INT16_MIN,"out of range");
_Static_assert( UV_EAI_ADDRFAMILY != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EAI_ADDRFAMILY != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EAI_ADDRFAMILY != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EAI_ADDRFAMILY != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EAI_ADDRFAMILY != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EAI_ADDRFAMILY != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EAI_ADDRFAMILY != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EAI_ADDRFAMILY != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EAI_AGAIN < 0 && UV_EAI_AGAIN >= INT16_MIN,"out of range");
_Static_assert( UV_EAI_AGAIN != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EAI_AGAIN != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EAI_AGAIN != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EAI_AGAIN != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EAI_AGAIN != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EAI_AGAIN != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EAI_AGAIN != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EAI_AGAIN != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EAI_BADFLAGS < 0 && UV_EAI_BADFLAGS >= INT16_MIN,"out of range");
_Static_assert( UV_EAI_BADFLAGS != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EAI_BADFLAGS != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EAI_BADFLAGS != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EAI_BADFLAGS != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EAI_BADFLAGS != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EAI_BADFLAGS != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EAI_BADFLAGS != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EAI_BADFLAGS != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EAI_BADHINTS < 0 && UV_EAI_BADHINTS >= INT16_MIN,"out of range");
_Static_assert( UV_EAI_BADHINTS != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EAI_BADHINTS != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EAI_BADHINTS != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EAI_BADHINTS != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EAI_BADHINTS != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EAI_BADHINTS != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EAI_BADHINTS != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EAI_BADHINTS != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EAI_CANCELED < 0 && UV_EAI_CANCELED >= INT16_MIN,"out of range");
_Static_assert( UV_EAI_CANCELED != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EAI_CANCELED != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EAI_CANCELED != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EAI_CANCELED != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EAI_CANCELED != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EAI_CANCELED != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EAI_CANCELED != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EAI_CANCELED != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EAI_FAIL < 0 && UV_EAI_FAIL >= INT16_MIN,"out of range");
_Static_assert( UV_EAI_FAIL != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EAI_FAIL != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EAI_FAIL != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EAI_FAIL != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EAI_FAIL != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EAI_FAIL != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EAI_FAIL != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EAI_FAIL != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EAI_FAMILY < 0 && UV_EAI_FAMILY >= INT16_MIN,"out of range");
_Static_assert( UV_EAI_FAMILY != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EAI_FAMILY != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EAI_FAMILY != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EAI_FAMILY != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EAI_FAMILY != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EAI_FAMILY != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EAI_FAMILY != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EAI_FAMILY != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EAI_MEMORY < 0 && UV_EAI_MEMORY >= INT16_MIN,"out of range");
_Static_assert( UV_EAI_MEMORY != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EAI_MEMORY != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EAI_MEMORY != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EAI_MEMORY != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EAI_MEMORY != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EAI_MEMORY != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EAI_MEMORY != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EAI_MEMORY != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EAI_NODATA < 0 && UV_EAI_NODATA >= INT16_MIN,"out of range");
_Static_assert( UV_EAI_NODATA != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EAI_NODATA != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EAI_NODATA != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EAI_NODATA != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EAI_NODATA != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EAI_NODATA != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EAI_NODATA != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EAI_NODATA != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EAI_NONAME < 0 && UV_EAI_NONAME >= INT16_MIN,"out of range");
_Static_assert( UV_EAI_NONAME != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EAI_NONAME != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EAI_NONAME != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EAI_NONAME != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EAI_NONAME != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EAI_NONAME != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EAI_NONAME != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EAI_NONAME != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EAI_OVERFLOW < 0 && UV_EAI_OVERFLOW >= INT16_MIN,"out of range");
_Static_assert( UV_EAI_OVERFLOW != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EAI_OVERFLOW != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EAI_OVERFLOW != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EAI_OVERFLOW != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EAI_OVERFLOW != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EAI_OVERFLOW != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EAI_OVERFLOW != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EAI_OVERFLOW != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EAI_PROTOCOL < 0 && UV_EAI_PROTOCOL >= INT16_MIN,"out of range");
_Static_assert( UV_EAI_PROTOCOL != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EAI_PROTOCOL != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EAI_PROTOCOL != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EAI_PROTOCOL != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EAI_PROTOCOL != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EAI_PROTOCOL != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EAI_PROTOCOL != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EAI_PROTOCOL != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EAI_SERVICE < 0 && UV_EAI_SERVICE >= INT16_MIN,"out of range");
_Static_assert( UV_EAI_SERVICE != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EAI_SERVICE != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EAI_SERVICE != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EAI_SERVICE != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EAI_SERVICE != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EAI_SERVICE != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EAI_SERVICE != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EAI_SERVICE != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EAI_SOCKTYPE < 0 && UV_EAI_SOCKTYPE >= INT16_MIN,"out of range");
_Static_assert( UV_EAI_SOCKTYPE != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EAI_SOCKTYPE != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EAI_SOCKTYPE != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EAI_SOCKTYPE != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EAI_SOCKTYPE != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EAI_SOCKTYPE != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EAI_SOCKTYPE != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EAI_SOCKTYPE != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EALREADY < 0 && UV_EALREADY >= INT16_MIN,"out of range");
_Static_assert( UV_EALREADY != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EALREADY != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EALREADY != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EALREADY != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EALREADY != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EALREADY != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EALREADY != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EALREADY != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EBADF < 0 && UV_EBADF >= INT16_MIN,"out of range");
_Static_assert( UV_EBADF != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EBADF != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EBADF != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EBADF != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EBADF != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EBADF != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EBADF != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EBADF != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EBUSY < 0 && UV_EBUSY >= INT16_MIN,"out of range");
_Static_assert( UV_EBUSY != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EBUSY != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EBUSY != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EBUSY != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EBUSY != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EBUSY != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EBUSY != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EBUSY != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ECANCELED < 0 && UV_ECANCELED >= INT16_MIN,"out of range");
_Static_assert( UV_ECANCELED != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ECANCELED != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ECANCELED != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ECANCELED != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ECANCELED != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ECANCELED != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ECANCELED != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ECANCELED != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ECHARSET < 0 && UV_ECHARSET >= INT16_MIN,"out of range");
_Static_assert( UV_ECHARSET != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ECHARSET != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ECHARSET != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ECHARSET != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ECHARSET != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ECHARSET != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ECHARSET != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ECHARSET != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ECONNABORTED < 0 && UV_ECONNABORTED >= INT16_MIN,"out of range");
_Static_assert( UV_ECONNABORTED != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ECONNABORTED != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ECONNABORTED != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ECONNABORTED != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ECONNABORTED != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ECONNABORTED != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ECONNABORTED != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ECONNABORTED != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ECONNREFUSED < 0 && UV_ECONNREFUSED >= INT16_MIN,"out of range");
_Static_assert( UV_ECONNREFUSED != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ECONNREFUSED != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ECONNREFUSED != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ECONNREFUSED != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ECONNREFUSED != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ECONNREFUSED != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ECONNREFUSED != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ECONNREFUSED != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ECONNRESET < 0 && UV_ECONNRESET >= INT16_MIN,"out of range");
_Static_assert( UV_ECONNRESET != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ECONNRESET != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ECONNRESET != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ECONNRESET != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ECONNRESET != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ECONNRESET != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ECONNRESET != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ECONNRESET != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EDESTADDRREQ < 0 && UV_EDESTADDRREQ >= INT16_MIN,"out of range");
_Static_assert( UV_EDESTADDRREQ != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EDESTADDRREQ != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EDESTADDRREQ != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EDESTADDRREQ != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EDESTADDRREQ != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EDESTADDRREQ != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EDESTADDRREQ != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EDESTADDRREQ != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EEXIST < 0 && UV_EEXIST >= INT16_MIN,"out of range");
_Static_assert( UV_EEXIST != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EEXIST != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EEXIST != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EEXIST != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EEXIST != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EEXIST != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EEXIST != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EEXIST != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EFAULT < 0 && UV_EFAULT >= INT16_MIN,"out of range");
_Static_assert( UV_EFAULT != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EFAULT != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EFAULT != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EFAULT != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EFAULT != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EFAULT != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EFAULT != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EFAULT != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EFBIG < 0 && UV_EFBIG >= INT16_MIN,"out of range");
_Static_assert( UV_EFBIG != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EFBIG != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EFBIG != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EFBIG != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EFBIG != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EFBIG != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EFBIG != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EFBIG != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EHOSTUNREACH < 0 && UV_EHOSTUNREACH >= INT16_MIN,"out of range");
_Static_assert( UV_EHOSTUNREACH != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EHOSTUNREACH != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EHOSTUNREACH != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EHOSTUNREACH != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EHOSTUNREACH != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EHOSTUNREACH != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EHOSTUNREACH != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EHOSTUNREACH != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EINTR < 0 && UV_EINTR >= INT16_MIN,"out of range");
_Static_assert( UV_EINTR != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EINTR != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EINTR != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EINTR != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EINTR != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EINTR != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EINTR != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EINTR != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EINVAL < 0 && UV_EINVAL >= INT16_MIN,"out of range");
_Static_assert( UV_EINVAL != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EINVAL != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EINVAL != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EINVAL != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EINVAL != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EINVAL != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EINVAL != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EINVAL != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EIO < 0 && UV_EIO >= INT16_MIN,"out of range");
_Static_assert( UV_EIO != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EIO != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EIO != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EIO != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EIO != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EIO != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EIO != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EIO != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EISCONN < 0 && UV_EISCONN >= INT16_MIN,"out of range");
_Static_assert( UV_EISCONN != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EISCONN != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EISCONN != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EISCONN != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EISCONN != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EISCONN != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EISCONN != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EISCONN != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EISDIR < 0 && UV_EISDIR >= INT16_MIN,"out of range");
_Static_assert( UV_EISDIR != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EISDIR != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EISDIR != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EISDIR != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EISDIR != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EISDIR != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EISDIR != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EISDIR != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ELOOP < 0 && UV_ELOOP >= INT16_MIN,"out of range");
_Static_assert( UV_ELOOP != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ELOOP != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ELOOP != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ELOOP != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ELOOP != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ELOOP != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ELOOP != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ELOOP != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EMFILE < 0 && UV_EMFILE >= INT16_MIN,"out of range");
_Static_assert( UV_EMFILE != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EMFILE != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EMFILE != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EMFILE != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EMFILE != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EMFILE != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EMFILE != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EMFILE != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EMSGSIZE < 0 && UV_EMSGSIZE >= INT16_MIN,"out of range");
_Static_assert( UV_EMSGSIZE != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EMSGSIZE != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EMSGSIZE != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EMSGSIZE != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EMSGSIZE != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EMSGSIZE != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EMSGSIZE != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EMSGSIZE != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ENAMETOOLONG < 0 && UV_ENAMETOOLONG >= INT16_MIN,"out of range");
_Static_assert( UV_ENAMETOOLONG != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ENAMETOOLONG != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ENAMETOOLONG != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ENAMETOOLONG != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ENAMETOOLONG != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ENAMETOOLONG != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ENAMETOOLONG != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ENAMETOOLONG != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ENETDOWN < 0 && UV_ENETDOWN >= INT16_MIN,"out of range");
_Static_assert( UV_ENETDOWN != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ENETDOWN != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ENETDOWN != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ENETDOWN != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ENETDOWN != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ENETDOWN != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ENETDOWN != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ENETDOWN != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ENETUNREACH < 0 && UV_ENETUNREACH >= INT16_MIN,"out of range");
_Static_assert( UV_ENETUNREACH != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ENETUNREACH != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ENETUNREACH != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ENETUNREACH != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ENETUNREACH != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ENETUNREACH != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ENETUNREACH != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ENETUNREACH != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ENFILE < 0 && UV_ENFILE >= INT16_MIN,"out of range");
_Static_assert( UV_ENFILE != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ENFILE != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ENFILE != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ENFILE != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ENFILE != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ENFILE != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ENFILE != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ENFILE != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ENOBUFS < 0 && UV_ENOBUFS >= INT16_MIN,"out of range");
_Static_assert( UV_ENOBUFS != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ENOBUFS != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ENOBUFS != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ENOBUFS != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ENOBUFS != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ENOBUFS != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ENOBUFS != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ENOBUFS != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ENODEV < 0 && UV_ENODEV >= INT16_MIN,"out of range");
_Static_assert( UV_ENODEV != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ENODEV != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ENODEV != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ENODEV != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ENODEV != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ENODEV != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ENODEV != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ENODEV != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ENOENT < 0 && UV_ENOENT >= INT16_MIN,"out of range");
_Static_assert( UV_ENOENT != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ENOENT != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ENOENT != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ENOENT != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ENOENT != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ENOENT != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ENOENT != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ENOENT != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ENOMEM < 0 && UV_ENOMEM >= INT16_MIN,"out of range");
_Static_assert( UV_ENOMEM != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ENOMEM != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ENOMEM != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ENOMEM != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ENOMEM != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ENOMEM != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ENOMEM != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ENOMEM != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ENONET < 0 && UV_ENONET >= INT16_MIN,"out of range");
_Static_assert( UV_ENONET != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ENONET != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ENONET != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ENONET != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ENONET != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ENONET != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ENONET != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ENONET != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ENOPROTOOPT < 0 && UV_ENOPROTOOPT >= INT16_MIN,"out of range");
_Static_assert( UV_ENOPROTOOPT != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ENOPROTOOPT != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ENOPROTOOPT != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ENOPROTOOPT != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ENOPROTOOPT != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ENOPROTOOPT != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ENOPROTOOPT != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ENOPROTOOPT != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ENOSPC < 0 && UV_ENOSPC >= INT16_MIN,"out of range");
_Static_assert( UV_ENOSPC != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ENOSPC != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ENOSPC != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ENOSPC != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ENOSPC != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ENOSPC != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ENOSPC != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ENOSPC != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ENOSYS < 0 && UV_ENOSYS >= INT16_MIN,"out of range");
_Static_assert( UV_ENOSYS != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ENOSYS != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ENOSYS != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ENOSYS != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ENOSYS != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ENOSYS != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ENOSYS != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ENOSYS != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ENOTCONN < 0 && UV_ENOTCONN >= INT16_MIN,"out of range");
_Static_assert( UV_ENOTCONN != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ENOTCONN != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ENOTCONN != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ENOTCONN != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ENOTCONN != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ENOTCONN != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ENOTCONN != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ENOTCONN != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ENOTDIR < 0 && UV_ENOTDIR >= INT16_MIN,"out of range");
_Static_assert( UV_ENOTDIR != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ENOTDIR != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ENOTDIR != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ENOTDIR != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ENOTDIR != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ENOTDIR != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ENOTDIR != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ENOTDIR != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ENOTEMPTY < 0 && UV_ENOTEMPTY >= INT16_MIN,"out of range");
_Static_assert( UV_ENOTEMPTY != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ENOTEMPTY != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ENOTEMPTY != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ENOTEMPTY != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ENOTEMPTY != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ENOTEMPTY != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ENOTEMPTY != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ENOTEMPTY != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ENOTSOCK < 0 && UV_ENOTSOCK >= INT16_MIN,"out of range");
_Static_assert( UV_ENOTSOCK != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ENOTSOCK != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ENOTSOCK != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ENOTSOCK != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ENOTSOCK != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ENOTSOCK != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ENOTSOCK != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ENOTSOCK != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ENOTSUP < 0 && UV_ENOTSUP >= INT16_MIN,"out of range");
_Static_assert( UV_ENOTSUP != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ENOTSUP != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ENOTSUP != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ENOTSUP != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ENOTSUP != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ENOTSUP != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ENOTSUP != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ENOTSUP != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EPERM < 0 && UV_EPERM >= INT16_MIN,"out of range");
_Static_assert( UV_EPERM != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EPERM != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EPERM != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EPERM != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EPERM != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EPERM != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EPERM != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EPERM != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EPIPE < 0 && UV_EPIPE >= INT16_MIN,"out of range");
_Static_assert( UV_EPIPE != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EPIPE != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EPIPE != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EPIPE != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EPIPE != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EPIPE != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EPIPE != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EPIPE != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EPROTO < 0 && UV_EPROTO >= INT16_MIN,"out of range");
_Static_assert( UV_EPROTO != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EPROTO != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EPROTO != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EPROTO != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EPROTO != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EPROTO != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EPROTO != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EPROTO != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EPROTONOSUPPORT < 0 && UV_EPROTONOSUPPORT >= INT16_MIN,"out of range");
_Static_assert( UV_EPROTONOSUPPORT != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EPROTONOSUPPORT != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EPROTONOSUPPORT != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EPROTONOSUPPORT != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EPROTONOSUPPORT != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EPROTONOSUPPORT != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EPROTONOSUPPORT != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EPROTONOSUPPORT != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EPROTOTYPE < 0 && UV_EPROTOTYPE >= INT16_MIN,"out of range");
_Static_assert( UV_EPROTOTYPE != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EPROTOTYPE != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EPROTOTYPE != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EPROTOTYPE != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EPROTOTYPE != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EPROTOTYPE != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EPROTOTYPE != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EPROTOTYPE != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ERANGE < 0 && UV_ERANGE >= INT16_MIN,"out of range");
_Static_assert( UV_ERANGE != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ERANGE != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ERANGE != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ERANGE != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ERANGE != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ERANGE != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ERANGE != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ERANGE != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EROFS < 0 && UV_EROFS >= INT16_MIN,"out of range");
_Static_assert( UV_EROFS != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EROFS != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EROFS != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EROFS != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EROFS != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EROFS != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EROFS != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EROFS != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ESHUTDOWN < 0 && UV_ESHUTDOWN >= INT16_MIN,"out of range");
_Static_assert( UV_ESHUTDOWN != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ESHUTDOWN != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ESHUTDOWN != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ESHUTDOWN != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ESHUTDOWN != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ESHUTDOWN != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ESHUTDOWN != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ESHUTDOWN != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ESPIPE < 0 && UV_ESPIPE >= INT16_MIN,"out of range");
_Static_assert( UV_ESPIPE != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ESPIPE != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ESPIPE != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ESPIPE != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ESPIPE != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ESPIPE != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ESPIPE != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ESPIPE != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ESRCH < 0 && UV_ESRCH >= INT16_MIN,"out of range");
_Static_assert( UV_ESRCH != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ESRCH != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ESRCH != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ESRCH != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ESRCH != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ESRCH != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ESRCH != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ESRCH != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ETIMEDOUT < 0 && UV_ETIMEDOUT >= INT16_MIN,"out of range");
_Static_assert( UV_ETIMEDOUT != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ETIMEDOUT != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ETIMEDOUT != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ETIMEDOUT != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ETIMEDOUT != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ETIMEDOUT != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ETIMEDOUT != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ETIMEDOUT != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ETXTBSY < 0 && UV_ETXTBSY >= INT16_MIN,"out of range");
_Static_assert( UV_ETXTBSY != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ETXTBSY != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ETXTBSY != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ETXTBSY != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ETXTBSY != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ETXTBSY != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ETXTBSY != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ETXTBSY != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EXDEV < 0 && UV_EXDEV >= INT16_MIN,"out of range");
_Static_assert( UV_EXDEV != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EXDEV != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EXDEV != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EXDEV != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EXDEV != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EXDEV != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EXDEV != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EXDEV != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_UNKNOWN < 0 && UV_UNKNOWN >= INT16_MIN,"out of range");
_Static_assert( UV_UNKNOWN != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_UNKNOWN != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_UNKNOWN != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_UNKNOWN != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_UNKNOWN != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_UNKNOWN != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_UNKNOWN != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_UNKNOWN != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EOF < 0 && UV_EOF >= INT16_MIN,"out of range");
_Static_assert( UV_EOF != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EOF != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EOF != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EOF != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EOF != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EOF != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EOF != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EOF != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_ENXIO < 0 && UV_ENXIO >= INT16_MIN,"out of range");
_Static_assert( UV_ENXIO != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_ENXIO != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_ENXIO != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_ENXIO != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_ENXIO != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_ENXIO != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_ENXIO != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_ENXIO != UV_UWT_EUNAVAIL ,"error code reuse");
_Static_assert( UV_EMLINK < 0 && UV_EMLINK >= INT16_MIN,"out of range");
_Static_assert( UV_EMLINK != UV_UWT_UNKNOWN ,"error code reuse");
_Static_assert( UV_EMLINK != UV_UWT_EFATAL ,"error code reuse");
_Static_assert( UV_EMLINK != UV_UWT_EBADF ,"error code reuse");
_Static_assert( UV_EMLINK != UV_UWT_EINVAL ,"error code reuse");
_Static_assert( UV_EMLINK != UV_UWT_ENOTACTIVE ,"error code reuse");
_Static_assert( UV_EMLINK != UV_UWT_EBUSY ,"error code reuse");
_Static_assert( UV_EMLINK != UV_UWT_ENOENT ,"error code reuse");
_Static_assert( UV_EMLINK != UV_UWT_EUNAVAIL ,"error code reuse");
#pragma GCC diagnostic pop

value
Val_uwt_error(int n)
{
  value erg;
  switch (n) {
  case UV_E2BIG: erg = Val_long(0) ; break;
  case UV_EACCES: erg = Val_long(1) ; break;
  case UV_EADDRINUSE: erg = Val_long(2) ; break;
  case UV_EADDRNOTAVAIL: erg = Val_long(3) ; break;
  case UV_EAFNOSUPPORT: erg = Val_long(4) ; break;
  case UV_EAGAIN: erg = Val_long(5) ; break;
  case UV_EAI_ADDRFAMILY: erg = Val_long(6) ; break;
  case UV_EAI_AGAIN: erg = Val_long(7) ; break;
  case UV_EAI_BADFLAGS: erg = Val_long(8) ; break;
  case UV_EAI_BADHINTS: erg = Val_long(9) ; break;
  case UV_EAI_CANCELED: erg = Val_long(10) ; break;
  case UV_EAI_FAIL: erg = Val_long(11) ; break;
  case UV_EAI_FAMILY: erg = Val_long(12) ; break;
  case UV_EAI_MEMORY: erg = Val_long(13) ; break;
  case UV_EAI_NODATA: erg = Val_long(14) ; break;
  case UV_EAI_NONAME: erg = Val_long(15) ; break;
  case UV_EAI_OVERFLOW: erg = Val_long(16) ; break;
  case UV_EAI_PROTOCOL: erg = Val_long(17) ; break;
  case UV_EAI_SERVICE: erg = Val_long(18) ; break;
  case UV_EAI_SOCKTYPE: erg = Val_long(19) ; break;
  case UV_EALREADY: erg = Val_long(20) ; break;
  case UV_EBADF: erg = Val_long(21) ; break;
  case UV_EBUSY: erg = Val_long(22) ; break;
  case UV_ECANCELED: erg = Val_long(23) ; break;
  case UV_ECHARSET: erg = Val_long(24) ; break;
  case UV_ECONNABORTED: erg = Val_long(25) ; break;
  case UV_ECONNREFUSED: erg = Val_long(26) ; break;
  case UV_ECONNRESET: erg = Val_long(27) ; break;
  case UV_EDESTADDRREQ: erg = Val_long(28) ; break;
  case UV_EEXIST: erg = Val_long(29) ; break;
  case UV_EFAULT: erg = Val_long(30) ; break;
  case UV_EFBIG: erg = Val_long(31) ; break;
  case UV_EHOSTUNREACH: erg = Val_long(32) ; break;
  case UV_EINTR: erg = Val_long(33) ; break;
  case UV_EINVAL: erg = Val_long(34) ; break;
  case UV_EIO: erg = Val_long(35) ; break;
  case UV_EISCONN: erg = Val_long(36) ; break;
  case UV_EISDIR: erg = Val_long(37) ; break;
  case UV_ELOOP: erg = Val_long(38) ; break;
  case UV_EMFILE: erg = Val_long(39) ; break;
  case UV_EMSGSIZE: erg = Val_long(40) ; break;
  case UV_ENAMETOOLONG: erg = Val_long(41) ; break;
  case UV_ENETDOWN: erg = Val_long(42) ; break;
  case UV_ENETUNREACH: erg = Val_long(43) ; break;
  case UV_ENFILE: erg = Val_long(44) ; break;
  case UV_ENOBUFS: erg = Val_long(45) ; break;
  case UV_ENODEV: erg = Val_long(46) ; break;
  case UV_ENOENT: erg = Val_long(47) ; break;
  case UV_ENOMEM: erg = Val_long(48) ; break;
  case UV_ENONET: erg = Val_long(49) ; break;
  case UV_ENOPROTOOPT: erg = Val_long(50) ; break;
  case UV_ENOSPC: erg = Val_long(51) ; break;
  case UV_ENOSYS: erg = Val_long(52) ; break;
  case UV_ENOTCONN: erg = Val_long(53) ; break;
  case UV_ENOTDIR: erg = Val_long(54) ; break;
  case UV_ENOTEMPTY: erg = Val_long(55) ; break;
  case UV_ENOTSOCK: erg = Val_long(56) ; break;
  case UV_ENOTSUP: erg = Val_long(57) ; break;
  case UV_EPERM: erg = Val_long(58) ; break;
  case UV_EPIPE: erg = Val_long(59) ; break;
  case UV_EPROTO: erg = Val_long(60) ; break;
  case UV_EPROTONOSUPPORT: erg = Val_long(61) ; break;
  case UV_EPROTOTYPE: erg = Val_long(62) ; break;
  case UV_ERANGE: erg = Val_long(63) ; break;
  case UV_EROFS: erg = Val_long(64) ; break;
  case UV_ESHUTDOWN: erg = Val_long(65) ; break;
  case UV_ESPIPE: erg = Val_long(66) ; break;
  case UV_ESRCH: erg = Val_long(67) ; break;
  case UV_ETIMEDOUT: erg = Val_long(68) ; break;
  case UV_ETXTBSY: erg = Val_long(69) ; break;
  case UV_EXDEV: erg = Val_long(70) ; break;
  case UV_UNKNOWN: erg = Val_long(71) ; break;
  case UV_EOF: erg = Val_long(72) ; break;
  case UV_ENXIO: erg = Val_long(73) ; break;
  case UV_EMLINK: erg = Val_long(74) ; break;
  case UV_UWT_UNKNOWN: erg = Val_long(75) ; break;
  case UV_UWT_EFATAL: erg = Val_long(76) ; break;
  case UV_UWT_EBADF: erg = Val_long(77) ; break;
  case UV_UWT_EINVAL: erg = Val_long(78) ; break;
  case UV_UWT_ENOTACTIVE: erg = Val_long(79) ; break;
  case UV_UWT_EBUSY: erg = Val_long(80) ; break;
  case UV_UWT_ENOENT: erg = Val_long(81) ; break;
  case UV_UWT_EUNAVAIL: erg = Val_long(82) ; break;
  default: erg = VAL_UWT_ERROR_UWT_UNKNOWN;
  }
  return erg;
}

value
Val_uwt_int_result(int n)
{
  value erg;
  if ( n > 0 ){
    return Val_long(n);
  }
  switch (n) {
  case UV_E2BIG: erg = Val_long(-1) ; break;
  case UV_EACCES: erg = Val_long(-2) ; break;
  case UV_EADDRINUSE: erg = Val_long(-3) ; break;
  case UV_EADDRNOTAVAIL: erg = Val_long(-4) ; break;
  case UV_EAFNOSUPPORT: erg = Val_long(-5) ; break;
  case UV_EAGAIN: erg = Val_long(-6) ; break;
  case UV_EAI_ADDRFAMILY: erg = Val_long(-7) ; break;
  case UV_EAI_AGAIN: erg = Val_long(-8) ; break;
  case UV_EAI_BADFLAGS: erg = Val_long(-9) ; break;
  case UV_EAI_BADHINTS: erg = Val_long(-10) ; break;
  case UV_EAI_CANCELED: erg = Val_long(-11) ; break;
  case UV_EAI_FAIL: erg = Val_long(-12) ; break;
  case UV_EAI_FAMILY: erg = Val_long(-13) ; break;
  case UV_EAI_MEMORY: erg = Val_long(-14) ; break;
  case UV_EAI_NODATA: erg = Val_long(-15) ; break;
  case UV_EAI_NONAME: erg = Val_long(-16) ; break;
  case UV_EAI_OVERFLOW: erg = Val_long(-17) ; break;
  case UV_EAI_PROTOCOL: erg = Val_long(-18) ; break;
  case UV_EAI_SERVICE: erg = Val_long(-19) ; break;
  case UV_EAI_SOCKTYPE: erg = Val_long(-20) ; break;
  case UV_EALREADY: erg = Val_long(-21) ; break;
  case UV_EBADF: erg = Val_long(-22) ; break;
  case UV_EBUSY: erg = Val_long(-23) ; break;
  case UV_ECANCELED: erg = Val_long(-24) ; break;
  case UV_ECHARSET: erg = Val_long(-25) ; break;
  case UV_ECONNABORTED: erg = Val_long(-26) ; break;
  case UV_ECONNREFUSED: erg = Val_long(-27) ; break;
  case UV_ECONNRESET: erg = Val_long(-28) ; break;
  case UV_EDESTADDRREQ: erg = Val_long(-29) ; break;
  case UV_EEXIST: erg = Val_long(-30) ; break;
  case UV_EFAULT: erg = Val_long(-31) ; break;
  case UV_EFBIG: erg = Val_long(-32) ; break;
  case UV_EHOSTUNREACH: erg = Val_long(-33) ; break;
  case UV_EINTR: erg = Val_long(-34) ; break;
  case UV_EINVAL: erg = Val_long(-35) ; break;
  case UV_EIO: erg = Val_long(-36) ; break;
  case UV_EISCONN: erg = Val_long(-37) ; break;
  case UV_EISDIR: erg = Val_long(-38) ; break;
  case UV_ELOOP: erg = Val_long(-39) ; break;
  case UV_EMFILE: erg = Val_long(-40) ; break;
  case UV_EMSGSIZE: erg = Val_long(-41) ; break;
  case UV_ENAMETOOLONG: erg = Val_long(-42) ; break;
  case UV_ENETDOWN: erg = Val_long(-43) ; break;
  case UV_ENETUNREACH: erg = Val_long(-44) ; break;
  case UV_ENFILE: erg = Val_long(-45) ; break;
  case UV_ENOBUFS: erg = Val_long(-46) ; break;
  case UV_ENODEV: erg = Val_long(-47) ; break;
  case UV_ENOENT: erg = Val_long(-48) ; break;
  case UV_ENOMEM: erg = Val_long(-49) ; break;
  case UV_ENONET: erg = Val_long(-50) ; break;
  case UV_ENOPROTOOPT: erg = Val_long(-51) ; break;
  case UV_ENOSPC: erg = Val_long(-52) ; break;
  case UV_ENOSYS: erg = Val_long(-53) ; break;
  case UV_ENOTCONN: erg = Val_long(-54) ; break;
  case UV_ENOTDIR: erg = Val_long(-55) ; break;
  case UV_ENOTEMPTY: erg = Val_long(-56) ; break;
  case UV_ENOTSOCK: erg = Val_long(-57) ; break;
  case UV_ENOTSUP: erg = Val_long(-58) ; break;
  case UV_EPERM: erg = Val_long(-59) ; break;
  case UV_EPIPE: erg = Val_long(-60) ; break;
  case UV_EPROTO: erg = Val_long(-61) ; break;
  case UV_EPROTONOSUPPORT: erg = Val_long(-62) ; break;
  case UV_EPROTOTYPE: erg = Val_long(-63) ; break;
  case UV_ERANGE: erg = Val_long(-64) ; break;
  case UV_EROFS: erg = Val_long(-65) ; break;
  case UV_ESHUTDOWN: erg = Val_long(-66) ; break;
  case UV_ESPIPE: erg = Val_long(-67) ; break;
  case UV_ESRCH: erg = Val_long(-68) ; break;
  case UV_ETIMEDOUT: erg = Val_long(-69) ; break;
  case UV_ETXTBSY: erg = Val_long(-70) ; break;
  case UV_EXDEV: erg = Val_long(-71) ; break;
  case UV_UNKNOWN: erg = Val_long(-72) ; break;
  case UV_EOF: erg = Val_long(-73) ; break;
  case UV_ENXIO: erg = Val_long(-74) ; break;
  case UV_EMLINK: erg = Val_long(-75) ; break;
  case UV_UWT_UNKNOWN: erg = Val_long(-76) ; break;
  case UV_UWT_EFATAL: erg = Val_long(-77) ; break;
  case UV_UWT_EBADF: erg = Val_long(-78) ; break;
  case UV_UWT_EINVAL: erg = Val_long(-79) ; break;
  case UV_UWT_ENOTACTIVE: erg = Val_long(-80) ; break;
  case UV_UWT_EBUSY: erg = Val_long(-81) ; break;
  case UV_UWT_ENOENT: erg = Val_long(-82) ; break;
  case UV_UWT_EUNAVAIL: erg = Val_long(-83) ; break;
  default: erg = Val_long(-76) ;
  }
  return erg;
}

static const int16_t error_rev_map[] = {
 UV_E2BIG,
 UV_EACCES,
 UV_EADDRINUSE,
 UV_EADDRNOTAVAIL,
 UV_EAFNOSUPPORT,
 UV_EAGAIN,
 UV_EAI_ADDRFAMILY,
 UV_EAI_AGAIN,
 UV_EAI_BADFLAGS,
 UV_EAI_BADHINTS,
 UV_EAI_CANCELED,
 UV_EAI_FAIL,
 UV_EAI_FAMILY,
 UV_EAI_MEMORY,
 UV_EAI_NODATA,
 UV_EAI_NONAME,
 UV_EAI_OVERFLOW,
 UV_EAI_PROTOCOL,
 UV_EAI_SERVICE,
 UV_EAI_SOCKTYPE,
 UV_EALREADY,
 UV_EBADF,
 UV_EBUSY,
 UV_ECANCELED,
 UV_ECHARSET,
 UV_ECONNABORTED,
 UV_ECONNREFUSED,
 UV_ECONNRESET,
 UV_EDESTADDRREQ,
 UV_EEXIST,
 UV_EFAULT,
 UV_EFBIG,
 UV_EHOSTUNREACH,
 UV_EINTR,
 UV_EINVAL,
 UV_EIO,
 UV_EISCONN,
 UV_EISDIR,
 UV_ELOOP,
 UV_EMFILE,
 UV_EMSGSIZE,
 UV_ENAMETOOLONG,
 UV_ENETDOWN,
 UV_ENETUNREACH,
 UV_ENFILE,
 UV_ENOBUFS,
 UV_ENODEV,
 UV_ENOENT,
 UV_ENOMEM,
 UV_ENONET,
 UV_ENOPROTOOPT,
 UV_ENOSPC,
 UV_ENOSYS,
 UV_ENOTCONN,
 UV_ENOTDIR,
 UV_ENOTEMPTY,
 UV_ENOTSOCK,
 UV_ENOTSUP,
 UV_EPERM,
 UV_EPIPE,
 UV_EPROTO,
 UV_EPROTONOSUPPORT,
 UV_EPROTOTYPE,
 UV_ERANGE,
 UV_EROFS,
 UV_ESHUTDOWN,
 UV_ESPIPE,
 UV_ESRCH,
 UV_ETIMEDOUT,
 UV_ETXTBSY,
 UV_EXDEV,
 UV_UNKNOWN,
 UV_EOF,
 UV_ENXIO,
 UV_EMLINK,
 UV_UWT_UNKNOWN,
 UV_UWT_EFATAL,
 UV_UWT_EBADF,
 UV_UWT_EINVAL,
 UV_UWT_ENOTACTIVE,
 UV_UWT_EBUSY,
 UV_UWT_ENOENT,
 UV_UWT_EUNAVAIL,
};

CAMLprim value
uwt_strerror(value i)
{
  int t = Long_val(i);
  if ( t < 0 ||
       t >= (int)(sizeof(error_rev_map) / sizeof(error_rev_map[0]))){
     t = UV_UWT_EFATAL;
  }
  else {
     t = error_rev_map[t];
  }
  const char * msg;
  switch(t){
  case UV_UWT_UNKNOWN : msg = "unknown uv error"; break; 
  case UV_UWT_EFATAL : msg = "fatal uwt error"; break; 
  case UV_UWT_EBADF : msg = "bad uwt handle"; break; 
  case UV_UWT_EINVAL : msg = "invalid parameter"; break; 
  case UV_UWT_ENOTACTIVE : msg = "handle not active"; break; 
  case UV_UWT_EBUSY : msg = "handle busy"; break; 
  case UV_UWT_ENOENT : msg = "entry not found"; break; 
  case UV_UWT_EUNAVAIL : msg = "libuv version too old or too recent"; break; 
  default: msg = uv_strerror(t);
  }
  return (caml_copy_string(msg));
}
