CAMLextern value
uwt_unix_blit(value,value,value,value,value);

CAMLprim value
uwt_unix_blit_from_bytes(value,value,value,value,value);

CAMLprim value
uwt_unix_blit_to_bytes(value,value,value,value,value);

CAMLprim value
uwt_unix_fill_bytes(value,value,value,value);

CAMLprim value
uwt_unix_memchr(value,value,value,value);

CAMLprim value
uwt_unix_unsafe_setbuf(value,value,value);

CAMLprim value
uwt_unix_unsafe_getbuf(value,value);

CAMLprim value
uwt_unix_read_int(value,value,value);

CAMLprim value
uwt_unix_read_int16(value,value,value);

CAMLprim value
uwt_unix_read_int32(value,value,value);

CAMLprim value
uwt_unix_read_int64(value,value,value);

CAMLprim value
uwt_unix_read_float32(value,value,value);

CAMLprim value
uwt_unix_read_float64(value,value,value);

CAMLprim value
uwt_unix_write_int(value,value,value,value);

CAMLprim value
uwt_unix_write_int16(value,value,value,value);

CAMLprim value
uwt_unix_write_int32(value,value,value,value);

CAMLprim value
uwt_unix_write_int64(value,value,value,value);

CAMLprim value
uwt_unix_write_float32(value,value,value,value);

CAMLprim value
uwt_unix_write_float64(value,value,value,value);
