v0.8.0 2015-12-24 Cambridge (UK)
--------------------------------

First release. Thanks to Raphaël Proust for lodging support.
