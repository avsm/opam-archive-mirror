open Printf

module C = Utils.Choice

type t =
  { perms : GAtomic.Set.t;
    inits : GTerm.Set.t;
    strats : Ast.predicate list * Ast.predicate list;
    predicates : Pred.Set.t;
    atoms : Symbol.Set.t;
    roles : Symbol.Set.t;
    frequency : Frequency.t Pred.Map.t; }

let print annot =
  let perms = GAtomic.Set.print annot.perms in
  let inits = GTerm.Set.print annot.inits in
  let strats = Utils.Print.couple (Utils.Print.list Ast.Print.predicate) (Utils.Print.list Ast.Print.predicate) annot.strats in
  let predicates = Pred.Set.print annot.predicates in
  let atoms = Symbol.Set.print annot.atoms in
  let roles = Symbol.Set.print annot.roles in
  let frequency = Pred.Map.print Frequency.print annot.frequency in
  sprintf "perms: %s\ninits: %s\n\nstrats:\n%s\n\npredicates:\n%s\n\natoms:\n%s\n\nroles:\n%s\n\nfrequency:\n%s\n\n"
    perms inits strats predicates atoms roles frequency

let starting prog =
  let perm_rules = ComputeRigids.get prog in
  let make_perm = function
    | (head, []) -> assert (Desugared.get_variables_lit (Desugared.Okay head) = []); Some (Desugared.ground_clause (head, []))
    | (_, _ :: _) -> None in
  let perms = Utils.PList.filter_map make_perm perm_rules in
  let is_init_role = function
    | (Ast.Init, [gterm]) -> C.Right gterm
    | (Ast.Init, _) -> assert false
    | (Ast.Role, (Desugared.Fct (x, []) :: [])) -> C.Left (C.Right x)
    | (Ast.Role, _) -> assert false
    | atom -> C.Left (C.Left atom) in
  let atoms, gterms = C.partition is_init_role perms in
  let atoms, roles  = C.partition_id atoms in
  GAtomic.Set.from_list atoms, GTerm.Set.from_list gterms, Symbol.Set.from_list roles
