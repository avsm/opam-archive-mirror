open Printf

type program = { rules : Desugared.program;
                 strats : (Ast.predicate list * Ast.predicate list) }

let print prog =
  sprintf "%s\n%s\n" (Desugared.Print.program prog.rules) (Utils.Print.couple (Utils.Print.list Pred.print) (Utils.Print.list Pred.print) prog.strats)

let stratified prog =
  let dep_graph = Analysis.transitive_dep_graph prog in
  let forbidden_lit head = function
    | Desugared.Okay _ | Desugared.Distinct _ -> None
    | Desugared.Negation (pred, _) -> Some (head, pred) in
  let forbidden_rule (head, body) = Utils.PList.filter_map (forbidden_lit (fst head)) body in
  let forbidden = Utils.PList.maps forbidden_rule prog in
  let safe (head, pred) = not (Pred.Set.mem head (Pred.Map.find pred dep_graph)) in
  List.for_all safe forbidden

let strat_terms_gen rules =
  let start = Analysis.start_map rules (fun _ -> 0) in
  let f old poss negs = List.fold_left max old (Utils.PList.append (Utils.PList.map ((+) 1) negs) poss) in
  Analysis.fixpoint rules start f

let next_does = (Ast.Next, []), [Desugared.Okay (Ast.Does, [])]
let does_legal = (Ast.Does, []), [Desugared.Okay (Ast.Legal, [])]

let strat_terms prog =
  if not (stratified prog) then invalid_arg "Not stratified input!";
  let prog = does_legal :: next_does :: prog in
  assert (stratified prog);
  strat_terms_gen prog

let strat_fun i = Ast.Constant (sprintf "strat%d" i, 0)

let add_stratificator strats frequency (ccl, hyps) =
  let aux accu lit = match lit with
    | Desugared.Okay _
    | Desugared.Distinct _ -> lit :: accu
    | Desugared.Negation (predicate, _) ->
      assert (Pred.Map.mem predicate strats);
      let strat = Pred.Map.find predicate strats in
      let strat_hyp = Desugared.Okay (strat_fun strat, []) in
      if List.mem strat_hyp accu then lit :: accu else lit :: strat_hyp :: accu in
  match hyps with
  | [] -> if Pred.Map.find (fst ccl) frequency = Frequency.Ephemeral then (ccl, [Desugared.Okay (strat_fun 0, [])]) else (ccl, [])
  | _ -> (ccl, List.rev (List.fold_left aux [] hyps))

let add_stratificators param rules =
  let strats = strat_terms rules in
  let frequency = Frequency.frequency param rules in
  assert (Pred.Map.mem Ast.Legal strats && Pred.Map.mem Ast.Next strats);
  let earl_strat = List.map strat_fun (Utils.PList.range 0 (Pred.Map.find Ast.Legal strats))
  and late_strat = List.map strat_fun (Utils.PList.range (Pred.Map.find Ast.Legal strats) (Pred.Map.find Ast.Next strats)) in
  let rules = List.map (add_stratificator strats frequency) rules in
  (rules, earl_strat, late_strat)

let make param prog = 
  let rules, earl_strats, late_strats = add_stratificators param prog in
  { rules;
    strats = (earl_strats, late_strats) }

