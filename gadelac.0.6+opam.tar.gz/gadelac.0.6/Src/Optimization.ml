open Printf

module C = Utils.Choice

let mscho = true

type param =
  { specialize_tempo  : bool ref;
    specialize_bound  : bool ref;
    ground_all   : bool ref ;
    ground     : (string * int) list ref;
    ground_count : int ref;
    specialize : (string * int) list ref;
    reachability : bool ref;
    compute_rigids : bool ref;
    merge_rigids : bool ref;
    inlining : int ref;
    frame_translation : bool ref;
    noop_move : string ref }

let default_param () =
  { specialize_tempo = ref false;
    specialize_bound = ref false;
    ground_all = ref false;
    ground = ref [];
    ground_count = ref 0;
    specialize = ref [];
    reachability = ref false;
    compute_rigids = ref true;
    merge_rigids = ref true;
    inlining = ref (-1);
    frame_translation = ref false;
    noop_move = ref "" }

let set_zero param =
  param.specialize_tempo := false;
  param.specialize_bound := false;
  param.ground_all := false;
  param.ground := [];
  param.ground_count := 0;
  param.specialize := [];
  param.reachability := false;
  param.compute_rigids := false;
  param.merge_rigids := false;
  param.inlining := -1;
  param.frame_translation := false;
  param.noop_move := ""

let set_full param =
  param.specialize_tempo := true;
  param.specialize_bound := true;
  param.ground_all := true;
  param.reachability := true;
  param.compute_rigids := true;
  param.merge_rigids := true;
  param.inlining := 10

let set_level param lvl =
  if lvl <= 0 then set_zero param
  else if lvl >= 2 then set_full param
  else ()

module Print =
struct

  let param { specialize_tempo; specialize_bound; ground_all; ground; ground_count; specialize; reachability; compute_rigids; merge_rigids; inlining; frame_translation; noop_move } =
    (if !specialize_tempo then "specialize_tempo" else "")
    ^ (if !specialize_bound then "specialize_bound" else "")
    ^ (if !ground_all then "ground_all" else "")
    ^ (if !ground <> [] then "ground" ^ Utils.Print.list (Utils.Print.couple Utils.Print.string Utils.Print.int) !ground else "")
    ^ (if !ground_count <> 0 then "ground count" ^ Utils.Print.int !ground_count else "")
    ^ (if !specialize <> [] then "specialize" ^ Utils.Print.list (Utils.Print.couple Utils.Print.string Utils.Print.int) !specialize else "")
    ^ (if !reachability then "reachability" else "")
    ^ (if !compute_rigids then "compute_rigids" else "")
    ^ (if !merge_rigids then "merge_rigids" else "")
    ^ (if !inlining >= 0 then sprintf "inlining %d" !inlining else "")
    ^ (if !frame_translation then sprintf "frame_translation" else "")
    ^ (if !noop_move <> "" then sprintf "noop_move %s" !noop_move else "")

  module NaiveP = Reachability.Naive (Domain.Path)

  let print_strats rules =
    let next_does = (Ast.Next, []), [Desugared.Okay (Ast.Does, [])]
    and does_legal = (Ast.Does, []), [Desugared.Okay (Ast.Legal, [])]
    and does_term = (Ast.Does, []), [Desugared.Okay (Ast.Terminal, [])] in
    let scc = Pred.SCC.tarjan (Analysis.dep_graph (next_does :: does_legal :: does_term :: rules)) in
    let print_one i pred = sprintf "(strat %d %s/%d)" i (Pred.print pred) (Ast.arity_pred pred) in
    let print_class i l = Pred.Set.unlines (print_one i) l in
    String.concat "\n" (List.mapi print_class scc)

  let program rules =
    let paths = NaiveP.forward false rules in
    let strats = print_strats rules in
    let result = ref "" in
    let append x = result := !result ^ x in
    append (sprintf ";;;; RULES  \n\n%s\n\n" (Desugared.Print.program rules));
    if mscho then append (sprintf ";;;; STRATS \n\n%s\n\n" strats);
    if mscho then append (sprintf ";;;; PATHS  \n\n%s\n\n" (Domain.Path.print paths));
    !result
end

module TemporizationFriendly =
struct
  let instant_persistent_variables_context rule = match rule with
    | ((Ast.Next, [Ast.Fact atom]), Desugared.Okay (Ast.True, [Ast.Fact atom2]) :: Desugared.Distinct (var, _) :: [])
    | ((Ast.Next, [Ast.Fact atom]), Desugared.Distinct (var, _) :: Desugared.Okay (Ast.True, [Ast.Fact atom2]) :: []) ->
      if atom = atom2 then Context.from_variable var rule else []
    | _ -> []

  let instant_extract = Utils.PList.maps instant_persistent_variables_context

  let special_persistent_variables_context = function
    | ((Ast.Next, [Ast.Fact atom]), Desugared.Okay (Ast.True, [Ast.Fact atom2]) :: []) when atom = atom2 -> Context.non_variables atom
    | _ -> []

  let special_extract = Utils.PList.maps special_persistent_variables_context
end

module AllContexts =
struct
  let extract rules = Symbol.Set.maps Context.associated (Analysis.symbols rules)
end

module BoundArgs =
struct
  let rec free_term context = function
    | Ast.Variable _ -> false
    | Ast.Fact (symb, terms) ->
      (fst context = symb && Desugared.is_variable (Utils.PList.nth (snd context) terms)) || List.exists (free_term context) terms

  let free_atomic (pred, terms) = function
    | C.Left  (pred', i) -> pred' = pred && Desugared.is_variable (Utils.PList.nth i terms)
    | C.Right context -> List.exists (free_term context) terms      
      
  let free_lite context = function
    | Desugared.Distinct (_, term) -> C.get_right false (C.map_right (fun context -> free_term context term) context)
    | Desugared.Okay atom | Desugared.Negation atom -> free_atomic atom context

  let free_rule context (head, body) = free_atomic head context || List.exists (free_lite context) body
      
  let bound_program rules context = not (List.exists (free_rule context) rules)
    
  let bound rules =
    let all_contexts = Symbol.Set.maps Context.associated (Analysis.symbols rules) in
    List.filter (bound_program rules) all_contexts
end

let grounding_contexts param prog = 
  let tempo = if !(param.specialize_tempo) then TemporizationFriendly.instant_extract prog else [] in
  tempo

let specialization_contexts param prog =
  let tempo = if !(param.specialize_tempo) then TemporizationFriendly.special_extract prog else []
  and bound = if !(param.specialize_bound) then BoundArgs.bound prog else [] in
  tempo @ bound

let user_contexts param prog =
  let get_context_pred pred (req_name, req_index) =
    let (name, arity) = (Ast.Print.predicate pred, Ast.arity_pred pred) in
    if name = req_name && arity > req_index then Some (C.Left  (pred, req_index)) else None in
  let get_context_symb ((name, arity) as symb) (req_name, req_index) =
    if name = req_name && arity > req_index then Some (C.Right (symb, req_index)) else None in
  let from_pred symb = Utils.PList.filter_map (get_context_pred symb) param in
  let from_symb symb = Utils.PList.filter_map (get_context_symb symb) param in
  Pred.Set.maps from_pred (Analysis.predicates prog) @ Symbol.Set.maps from_symb (Analysis.symbols prog)
let user_grounding param prog =
  let contexts = user_contexts !(param.ground) prog in
  Ground.program contexts prog
let user_specialization param prog =
  let contexts = user_contexts !(param.specialize) prog in
(*  eprintf "Optimization: contexts %s\n\n%s\n\n%!" (Utils.Print.list Context.print contexts) (Desugared.Print.program (Instantiation.program prog contexts));*)
  Specialization.make contexts (Ground.program contexts prog)

let optimize name switch f prog =
  if switch then
    (eprintf "%s %!" name;
     let (prog, time) = Utils.Time.measure f prog in
     eprintf "%f\n%!" time;
     prog)
  else prog

let make param prog =
  let prog = optimize "compute rigids" !(param.compute_rigids) ComputeRigids.get prog in
  let prog = optimize "merge rigids" !(param.merge_rigids) MergeRigids.program prog in
  let prog = optimize "compute rigids" (!(param.compute_rigids) && !(param.merge_rigids)) ComputeRigids.get prog in
  let prog = optimize "frame" !(param.frame_translation) (Frame.make !(param.noop_move)) prog in
  let prog = optimize "reachability" !(param.reachability) Reachability.make prog in
  let prog = optimize "ground" true (Ground.program (grounding_contexts param prog)) prog in
  let prog = optimize "ground count" (!(param.ground_count) > 0) (Ground.count_program !(param.ground_count)) prog in
  let prog = optimize "ground all" !(param.ground_all) Ground.full_program prog in
  let prog = optimize "specialize" true (Specialization.make (specialization_contexts param prog)) prog in
  let prog = optimize "user ground" (!(param.ground) <> []) (user_grounding param) prog in
  let prog = optimize "user specialize" (!(param.specialize) <> []) (user_specialization param) prog in
  let prog = optimize "inline" (!(param.inlining) >= 0) (Inlining.program !(param.inlining)) prog in
  let prog = optimize "reachability" !(param.reachability) Reachability.make prog in
  prog
