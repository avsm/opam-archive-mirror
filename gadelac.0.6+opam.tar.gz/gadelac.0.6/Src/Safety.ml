let is_safe' safe_vars = function
  | Desugared.Okay _ -> None
  | Desugared.Negation t -> Utils.PList.except (Utils.PList.memr safe_vars) (Ast.get_variables_atomic t)
  | Desugared.Distinct (s, t) -> Utils.PList.except (Utils.PList.memr safe_vars) (s :: Ast.get_variables t)

let is_safe safe_vars lit = is_safe' safe_vars lit = None

let get_safe_variables = function
  | Desugared.Okay atom -> Ast.get_variables_atomic atom
  | Desugared.Negation _ | Desugared.Distinct _ -> []

let sort_literals body =
  let rec aux stored safe_vars rest =
    match Utils.PList.find_first (is_safe safe_vars) rest with
    | None -> assert (List.length stored = List.length body); List.rev stored
    | Some (before, lit, after) -> aux (lit :: stored) (get_safe_variables lit @ safe_vars) (List.rev_append before after) in
  aux [] [] body

let sort_clause (head, body) = (head, sort_literals body)
let sort = Utils.PList.map sort_clause

let check_clause (head, body) =
  let safe_vars = Utils.PList.maps get_safe_variables body in
  Utils.PList.find' (is_safe' safe_vars) (Desugared.Okay head :: body)

let program = 
  let aux cl = Utils.Option.map (fun v -> v, cl) (check_clause cl) in
  Utils.PList.find' aux

let sorted_clause clause = sort_clause clause = clause
let sorted = List.for_all sorted_clause
