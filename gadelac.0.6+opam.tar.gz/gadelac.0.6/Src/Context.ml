open Printf

module C = Utils.Choice

type t = (Ast.predicate * int, Ast.symbol * int) C.t
let print = C.print (Utils.Print.couple' "(" " " ")" Ast.Print.predicate Utils.Print.int) (Utils.Print.couple' "(" " " ")" Ast.Print.symbol Utils.Print.int)

let associated f =
  let arity = Ast.arity f in
  assert (arity >= 0);
  List.map (fun i -> C.Right (f, i)) (Utils.PList.range 0 arity)

let associated_pred f =
  let arity = Ast.arity_pred f in
  assert (arity >= 0);
  List.map (fun i -> C.Left (f, i)) (Utils.PList.range 0 arity)

let non_variables (f, terms) =
  let f (accu, i) = function
    | Ast.Variable _ -> (accu, i + 1)
    | Ast.Fact _ -> (C.Right (f, i) :: accu, i + 1) in
  let (contexts, _) = List.fold_left f ([], 0) terms in
  List.rev contexts

let rec from_variable_term var fct i = function
  | Ast.Fact (fct2, terms) -> Utils.PList.flatten (Utils.PList.mapi (from_variable_term var fct2) 0 terms)
  | Ast.Variable var2 -> if var = var2 then [C.Right (fct, i)] else []
let from_variable_atom var (pred, terms) =
  let find i = function
    | Ast.Fact (fct, terms) -> Utils.PList.flatten (Utils.PList.mapi (from_variable_term var fct) 0 terms)
    | Ast.Variable var2 -> if var = var2 then [C.Left (pred, i)] else [] in
  let results = Utils.PList.mapi find 0 terms in
  Utils.PList.flatten results
let from_variable_lit var = function
  | Desugared.Okay atom -> from_variable_atom var atom
  | Desugared.Negation _ | Desugared.Distinct _ -> []
let from_variable var (head, body) =
  let head = from_variable_atom var head in
  let body = Utils.PList.maps (from_variable_lit var) body in
  let results = Utils.PList.uniques (head @ body) in
  assert (List.for_all (function | C.Right (f, i) -> Ast.arity f > i | C.Left (f, i) -> Ast.arity_pred f > i) results);
  results

let rec to_variable_term (f, i) = function
  | Ast.Variable _ -> Variable.Set.empty
  | Ast.Fact (symbol, terms) ->
    if f = symbol then Variable.Set.from_list (Ast.get_variables (Utils.PList.nth i terms))
    else Variable.Set.maps_union (to_variable_term (f, i)) terms
let to_variable_atomic context (pred, terms) = match context with
  | C.Left (pred', i) -> if pred <> pred' then Variable.Set.empty else Variable.Set.from_list (Ast.get_variables (Utils.PList.nth i terms))
  | C.Right context -> Variable.Set.maps_union (to_variable_term context) terms
let to_variable_lit con = function
  | Desugared.Okay atom | Desugared.Negation atom -> to_variable_atomic con atom
  | Desugared.Distinct (_, term) -> C.get_right Variable.Set.empty (C.map_right (fun con -> to_variable_term con term) con)
let to_variable con (head, body) =
  let head = to_variable_atomic con head 
  and body = Variable.Set.maps_union (to_variable_lit con) body in
  Variable.Set.union head body
