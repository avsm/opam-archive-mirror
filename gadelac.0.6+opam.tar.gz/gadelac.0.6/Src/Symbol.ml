include Utils.DataStructure.F (struct type t = Ast.symbol let compare = compare let print = Ast.Print.symbol end)
