include Utils.DataStructure.F (struct type t = Desugared.gterm let compare = compare let print = Desugared.Print.gterm end)
