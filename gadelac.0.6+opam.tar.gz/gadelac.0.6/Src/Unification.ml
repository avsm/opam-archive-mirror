open Printf

type substitution = Ast.term Variable.Map.t
type t = substitution option

let print_sub = Variable.Map.print Ast.Print.term
let print = Utils.Print.option print_sub

let empty_sub = Variable.Map.empty
let empty = Some empty_sub

let apply_var sub var = Variable.Map.find_default var (Ast.Variable var) sub 
let rec apply_term sub = function
  | Ast.Variable var -> apply_var sub var
  | Ast.Fact (symb, terms) -> Ast.Fact (symb, List.map (apply_term sub) terms)
let apply_atomic sub (pred, args) = (pred, List.map (apply_term sub) args)
let apply_literal sub = function
  | Ast.Okay atom -> Ast.Okay (apply_atomic sub atom)
  | Ast.Negation atom -> Ast.Negation (apply_atomic sub atom)
  | Ast.Distinct (t1, t2) -> Ast.Distinct (apply_term sub t1, apply_term sub t2)
  | Ast.Equal (t1, t2) -> Ast.Equal (apply_term sub t1, apply_term sub t2)
let equalities = Utils.Option.map Variable.Map.bindings

let codomains sub =
  let dom, terms = Utils.PList.split (Variable.Map.bindings sub) in
  let free_vars = Utils.PList.maps Ast.get_variables terms in
  let cod = Utils.PList.uniques free_vars in
  assert (Utils.PList.intersect dom cod = []);
  assert (Utils.PList.no_doubles dom);
  dom, cod

let compose_aux tau theta =
  let dom1, cod1 = codomains tau
  and dom2, cod2 = codomains theta in
  if (Utils.PList.intersect dom1 dom2 <> []) then eprintf "Unification:%s %s\n" (print_sub tau) (print_sub theta);
  assert (Utils.PList.intersect dom1 dom2 = []);
  assert (Utils.PList.intersect dom1 cod2 = []);
  let add_one key term accu = Variable.Map.add key (apply_term theta term) accu in
  Variable.Map.fold add_one tau theta
let compose = Utils.Option.combine compose_aux

let rec unify_sequence_aux l1 l2 =
  assert (List.length l1 = List.length l2);
  let aux t1 t2 = function
    | None -> None
    | Some tau -> 
      let theta = unify (apply_term tau t1) (apply_term tau t2) in
      Utils.Option.map (compose_aux tau) theta in
  List.fold_right2 aux l1 l2 empty
and unify term1 term2 = match term1, term2 with
  | Ast.Variable v1, Ast.Variable v2 when (v1 = v2) -> empty
  | Ast.Variable var, term | term, Ast.Variable var ->
    let vars = Ast.get_variables term in
    if List.mem var vars then None
    else Some (Variable.Map.singleton var term)
  | Ast.Fact (f1, _), Ast.Fact (f2, _) when f1 <> f2 -> None
  | Ast.Fact (f1, l1), Ast.Fact (f2, l2) ->
    assert (f1 = f2 && List.length l1 = List.length l2);
    unify_sequence_aux l1 l2

let unify_sequence l1 l2 =
  assert (List.length l1 = List.length l2);
  unify_sequence_aux l1 l2

let add_equality sub (t1, t2) =
  let term1 = apply_term sub t1
  and term2 = apply_term sub t2 in
  compose (Some sub) (unify term1 term2)
