open Printf

module C = Utils.Choice

let rec get_and_remove_ith i l = match l with
  | [] -> assert false
  | a :: r when i <= 0 -> a, r
  | a :: r -> 
    let (a', r') = get_and_remove_ith (i - 1) r in
    (a', a :: r')

let rec get_and_remove_aux is l = match is with
  | [] -> ([], l)
  | i :: r ->
    let (a, l') = get_and_remove_ith i l in
    let r' = List.map (fun i' -> i' - 1) r in
    let (ass, l'') = get_and_remove_aux r' l' in
    (a :: ass, l'')

(** [get_and_remove is l] returns a pair [(selected, other)] where [selected] is a list of elements of [l] at index [is] and [other] is the remaining list. *)
let get_and_remove is l =
  assert (is = List.sort compare is);
  get_and_remove_aux is l

(* Bug in the following line if the gterm is complex? *)
let fun_cst_one (fct_name, arity) (_, gterm) = (sprintf "%s_%s" fct_name (Desugared.Print.gterm gterm), arity - 1)
let fun_cst (fct, is) gterms =
  assert (List.length is = List.length gterms);
  let igs = List.combine is gterms in
  List.fold_left fun_cst_one fct igs

let rec term_aux context (f, ts) = 
  let (fct, is) = context in
  if f <> fct then (f, List.map (term context) ts)
  else
    (assert (is <> []); assert (List.length ts > (Utils.PList.max compare is));
     let (ass, ts') = get_and_remove is ts in
     let ground_as = Utils.PList.filter_map Desugared.ground ass in
     if List.length ground_as <> List.length ass
     then (eprintf "%s\n%s\n%s\n%s\n" (Utils.Print.list Ast.Print.term ass) (Utils.Print.list Desugared.Print.gterm ground_as)
             (Utils.Print.list Utils.Print.int is) (Ast.Print.term (Ast.Fact (f, ts))); assert false);
     let new_fct = fun_cst context ground_as in
     (new_fct, List.map (term context) ts'))
and term context t = match t with
  | Ast.Variable _ -> t
  | Ast.Fact at -> Ast.Fact (term_aux context at)

let atomic context (pred, ts) = (pred, List.map (term context) ts)

let literal context = function
  | Desugared.Distinct (s, t) -> Desugared.Distinct (s, term context t)
  | Desugared.Negation atom   -> Desugared.Negation (atomic context atom)
  | Desugared.Okay     atom   -> Desugared.Okay     (atomic context atom)

let clause context (head, body) = (atomic context head, List.map (literal context) body)

let program_con key is rules = List.map (clause (key, is)) rules

let regroup_contexts l =
  let add (pmap, smap) = function
    | C.Left  (f, i) -> (Pred.Map.update f (Utils.Int.Set.add i) Utils.Int.Set.empty pmap, smap)
    | C.Right (f, i) -> (pmap, Symbol.Map.update f (Utils.Int.Set.add i) Utils.Int.Set.empty smap) in
  List.fold_left add (Pred.Map.empty, Symbol.Map.empty) l

let make contexts rules =
  let (_, contexts) = regroup_contexts contexts in
  let remove_double_contexts is = List.sort compare (Utils.Int.Set.elements is) in
  let contexts = Symbol.Map.map remove_double_contexts contexts in
  let rules = Symbol.Map.fold program_con contexts rules in
  rules
