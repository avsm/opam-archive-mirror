open Printf

module C = Utils.Choice

let curr time = Ast.Variable time
(*let zero = Ast.Fact (("0", 0), [])
let next time = Ast.Fact (("+", 2), [Ast.Fact (("1", 0), []); curr time])*)
let zero = Ast.Fact (("__gad_zero", 0), [])
let next time = Ast.Fact (("__gad_incr", 1), [curr time])

let time_pred = Ast.Constant ("time", 0)
let current time = Desugared.Okay (time_pred, [curr time])

let time_var prog =
  let vars = Utils.PList.maps Desugared.get_variables_clause prog in
  let vars = Variable.Set.from_list vars in
  let base = "t" in
  if not (Variable.Set.mem base vars) then base
  else
    let i = ref 0 in
    while Variable.Set.mem (sprintf "%s%d" base !i) vars do incr i done;
    sprintf "%s%d" base !i

let atomic time perms (pred, args) = match pred with
  | Ast.Next  -> (Ast.True,  next time :: args)
  | Ast.Init  -> (Ast.True,  zero :: args)
  | _ when Pred.Set.mem pred perms -> (pred, args)
  | _ -> (pred, curr time :: args)

let literal time perms = function
  | Desugared.Okay     atom -> Desugared.Okay     (atomic time perms atom)
  | Desugared.Negation atom -> Desugared.Negation (atomic time perms atom)
  | Desugared.Distinct dist -> Desugared.Distinct dist

let clause time perms (head, body) = 
  let body = Utils.PList.map (literal time perms) body in
  let body = if Pred.Set.mem (fst head) perms then body else current time :: body in
  (atomic time perms head, body)

let program prog =
  let symbols = Analysis.symbols prog in
  if Symbol.Set.exists (fun symb -> fst symb = "+") symbols then failwith "Can't do a Time transformation with an existing \"+\" symbol";
  let predicates = Analysis.predicates prog in
  if Pred.Set.mem time_pred predicates then failwith "Can't do a Time transformation with an existing \"time\" predicate";
  let perms = Frequency.permanents prog in
  let perms = Pred.Set.remove Ast.Legal perms in (** in case all the moves are rigidely legals *)
  let time = time_var prog in
  Utils.PList.map (clause time perms) prog
