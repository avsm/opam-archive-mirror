include Utils.DataStructure.F (struct type t = Ast.predicate let compare = compare let print = Ast.Print.predicate end)
