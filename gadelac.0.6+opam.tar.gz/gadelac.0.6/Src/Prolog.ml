open Printf

(*  let escape = Utils.MString.escape ['_'; '+'; '-'; '<'; '>'; '='; '/'; '\''; '\\'] '_'*)
let escape = Utils.MString.escape ['+'; '-'; '<'; '>'; '='; '/'; '\''; '\\'] '_'

let variable capitalize v = if capitalize then String.capitalize v else "V" ^ v
(*let symbol fct = escape (Ast.Print.symbol fct)*)
let symbol fct = if fst fct = "__gad_zero" then "0" else escape (Ast.Print.symbol fct)
let predicate fct = "d_" ^ escape (Ast.Print.predicate fct)

let rec term capitalize = function
  | Ast.Variable var -> variable capitalize var
  | Ast.Fact (symb, []) -> symbol symb
  | Ast.Fact (("__gad_incr", 1), [time]) -> sprintf "1+%s" (term capitalize time)
  | Ast.Fact (symb, l) -> sprintf "%s%s" (symbol symb) (Utils.Print.list' "(" "," ")" (term capitalize) l)
let atomic capitalize (pred, terms) = match terms with
  | [] -> predicate pred
  | _ :: _ -> sprintf "%s%s" (predicate pred) (Utils.Print.list' "(" "," ")" (term capitalize) terms)

let literal capitalize = function
  | Desugared.Okay     atom -> atomic capitalize atom
  | Desugared.Negation atom -> sprintf "\\+ %s" (atomic capitalize atom)
  | Desugared.Distinct (var, t) -> sprintf "%s \\= %s" (variable capitalize var) (term capitalize t)

let clause (head, body) =
  let capitalize = ASP.clean_vars (head, body) in
  let head = atomic capitalize head in
  if body = [] then head ^ "."
  else sprintf "%s :- %s." head (Utils.Print.list' "" ", " "" (literal capitalize) body)

let program = Utils.Print.unlines clause
