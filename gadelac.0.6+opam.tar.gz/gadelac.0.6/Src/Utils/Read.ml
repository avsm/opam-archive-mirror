let bool s = match String.lowercase s with
  | "yes" | "true" | "y" | "t" -> Some true
  | "no" | "false" | "n" | "f" -> Some false
  | _ -> None

let int s = try Some (int_of_string s) with Failure "int_of_string" -> None
