include Utils.DataStructure.F (struct type t = Desugared.gatomic let compare = compare let print = Desugared.Print.gatomic end)
