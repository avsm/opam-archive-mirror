open Printf

type literal = Okay of (Ast.predicate * Ast.term list) | Negation of (Ast.predicate * Ast.term list) | Distinct of (string * Ast.term)
type clause = (Ast.predicate * Ast.term list) * literal list
type program = clause list
      
type gterm = Fct of (Ast.symbol * gterm list)
type gatomic = Ast.predicate * gterm list

let get_fun = function Fct (s, _) -> s

let get_variables_lit = function
  | Okay atom | Negation atom -> Utils.PList.uniques (Ast.get_variables_atomic atom)
  | Distinct (var, term) -> Utils.PList.uniques (var :: Ast.get_variables term)
let get_variables_clause (head, body) =
  let head_vars = get_variables_lit (Okay head)
  and body_vars = Utils.PList.uniques (Utils.PList.maps get_variables_lit body) in
  assert (List.for_all (Utils.PList.memr body_vars) head_vars);
  body_vars

let is_variable = function
  | Ast.Variable _ -> true
  | Ast.Fact _ -> false

let only_free_arguments (_, ts) = List.for_all is_variable ts && Utils.PList.no_doubles (Utils.PList.maps Ast.get_variables ts)

module Print =
struct      
  let rec gterm = function
    | Fct (f, []) -> Ast.Print.symbol f
    | Fct (f, ts) -> sprintf "(%s %s)" (Ast.Print.symbol f) (Utils.Print.unspaces gterm ts)

  let gatomic = function
    | (pred, []) -> Ast.Print.predicate pred
    | (pred, ts) -> sprintf "(%s %s)" (Ast.Print.predicate pred) (Utils.Print.unspaces gterm ts)

  let literal = function
    | Okay t -> Ast.Print.atomic t
    | Negation t -> sprintf "(not %s)" (Ast.Print.atomic t)
    | Distinct (s, t) -> sprintf "(distinct ?%s %s)" s (Ast.Print.term t)

  let clause (l, rs) =
    if rs = [] then Ast.Print.atomic l
    else sprintf "(<= %s %s)" (Ast.Print.atomic l) (Utils.Print.unspaces literal rs)

  let program rules = Utils.Print.unlines clause rules
end

module C = Utils.Choice

let distincts dist =
  let rec aux = function
    | Ast.Variable var1, Ast.Variable var2 when var1 = var2 -> []
    | Ast.Variable var, term | term, Ast.Variable var -> [[(var, term)]]
    | Ast.Fact (symb1, _), Ast.Fact (symb2, _) when symb1 <> symb2 -> [[]]
    | Ast.Fact (_, terms1), Ast.Fact (_, terms2) ->
      assert (List.length terms1 = List.length terms2);
      Utils.PList.maps aux (List.combine terms1 terms2) in
  Utils.PList.uniques (aux dist)

let partition_literals body =
  let aux (accu_sub, accu_body) = function
    | Ast.Okay fact -> accu_sub, C.Right (C.Right fact) :: accu_body
    | Ast.Negation fact -> accu_sub, C.Right (C.Left fact) :: accu_body
    | Ast.Distinct dist -> accu_sub, C.Left dist :: accu_body
    | Ast.Equal eq -> Utils.Option.bind accu_sub (fun sub -> Unification.add_equality sub eq), accu_body in
  let sub, body = List.fold_left aux (Unification.empty, []) body in
  match sub with
  | None -> None
  | Some sub -> Some (sub, body)

let simplify_distinct sub (t1, t2) = distincts (Unification.apply_term sub t1, Unification.apply_term sub t2)

let from_clause (head, (body : Ast.literal list)) = match partition_literals body with
  | None -> []
  | Some (sub, body) ->
    let aux accu = function
      | C.Right C.Right fact -> Utils.PList.map (Utils.PList.cons (Okay     (Unification.apply_atomic sub fact))) accu
      | C.Right C.Left  fact -> Utils.PList.map (Utils.PList.cons (Negation (Unification.apply_atomic sub fact))) accu
      | C.Left dist ->
        let distincts = simplify_distinct sub dist in
        Utils.PList.cross_product_map (fun dists acc -> Utils.PList.map (fun (v, t) -> Distinct (v, t)) dists @ acc) distincts accu in
    let bodies = List.fold_left aux [[]] body in
    let head = Unification.apply_atomic sub head in
    Utils.PList.map (fun body -> (head, body)) bodies

let from_logic_rule (head, (logic : Ast.literal Logic.t)) =
  let logs = Logic.dnf logic in
  let logs = Utils.PList.map (fun log -> (head, log)) logs in
  Utils.PList.maps from_clause logs

let from_logic_program (rules : Ast.program) = Utils.PList.maps from_logic_rule rules

let rec ground = function
  | Ast.Variable _ -> None
  | Ast.Fact (f, ts) ->
    try let gts = Utils.PList.filter_map ground ts in
        assert (List.length gts = List.length ts);
        Some (Fct (f, gts))
    with Assert_failure _ -> None

let ground_clause (head, body) =
  assert (body = []);
  let grounds = Utils.PList.filter_map ground (snd head) in
  assert (List.length grounds = List.length (snd head));
  (fst head, grounds)

let rec abground' = function
  | Fct (f, ts) -> Ast.Fact (f, List.map abground' ts)
let rec abground = function
  | Fct (f, ts) -> (f, List.map abground' ts)
      
let rec abground_atomic = function
  | (f, ts) -> (f, List.map abground' ts)

let make () prog = from_logic_program prog

module Parse =
struct
  let print_error name lexer =
    let position = Lexing.lexeme_start_p lexer in
    let line = position.Lexing.pos_lnum
    and char = position.Lexing.pos_cnum - position.Lexing.pos_bol in
    sprintf "%s: Parser : at line %d, column %d: syntax error.\n" name line char
        
  let from_file () name =
    let input = if name <> "-" then open_in name else stdin in
    let close () = if name <> "-" then close_in input in
    let lexer = Lexing.from_channel input in
    let tree =
      try Parser.program Lexer.token lexer with
      | Lexer.Error msg -> close (); invalid_arg (sprintf "%s: %s" name msg)
      | Parser.Error -> close (); invalid_arg (print_error name lexer)
      | exn -> close (); raise exn in
    close ();
    Ast.program tree
end

let sugar_lit = function
  | Okay arg -> Ast.Okay arg
  | Negation arg -> Ast.Negation arg
  | Distinct (v, t) -> Ast.Distinct (Ast.Variable v, t)

let rename_variables_term map term =
  let aux key elt = Ast.replace_variable_term (key, Ast.Variable elt) in
  Variable.Map.fold aux map term
let rename_variables_atomic map atom = Unification.apply_atomic (Variable.Map.map Ast.variable map) atom
let rename_variables_lit map = function
  | Okay atom -> Okay (rename_variables_atomic map atom)
  | Negation atom -> Negation (rename_variables_atomic map atom)
  | Distinct (v, term) -> Distinct (Variable.Map.find_default v v map, rename_variables_term map term)

let apply_clause sub (head, body) =
  let head = Unification.apply_atomic sub head
  and body = List.map (fun lit -> Unification.apply_literal sub (sugar_lit lit)) body in
  from_clause (head, body)

let get_positive (_, body) =
  let aux accu = function
    | Okay atom -> atom :: accu
    | Negation _ | Distinct _ -> accu in
  List.rev (List.fold_left aux [] body)
