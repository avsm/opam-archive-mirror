
struct term {
  int predicate;
  term *arguments[];
} term;

typedef term partialKB[];

typedef partialKB KB[3];
