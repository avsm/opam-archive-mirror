1.1.0 (19 Jun 2015):
* If the `annot` file cannot be found, just output the
  fully qualified pathname (#8 from Cedric Cellier).
* Add `opam` file for local pinning workflow.

1.0.0 (02 Sep 2012):
* Initial public release.
