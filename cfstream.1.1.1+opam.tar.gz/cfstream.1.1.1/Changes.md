CFStream Release Notes

cfstream-1.1.1 2014-03-02
-------------------------
* Fix doc build bug.

cfstream-1.1.0 2014-03-02
-------------------------
* Provide concat_map.
* New About module.

cfstream-1.0.0 2013-08-09
-------------------------
* First release.
