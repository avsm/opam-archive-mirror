lib/cow contains modules useful for writing web applications.
