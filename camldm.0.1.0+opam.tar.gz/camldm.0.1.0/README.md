OCaml bindings to libdevicemapper.

See example code in lib/testcamldm.ml


