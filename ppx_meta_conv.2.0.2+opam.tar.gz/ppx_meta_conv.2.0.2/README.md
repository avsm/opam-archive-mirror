Meta_conv for ppx
==============================

`ppx_meta_conv` is a wrapper for `ppx_deriving` to provide data conversion between OCaml values and tree formed data structures such as JSON, Sexp, pseudo OCaml value code and so on.

`ppx_meta_conv` is a PPX port of `meta_conv` for CamlP4, which is a generalization of `type_conv`. The first objective of `meta_conv` and `ppx_meta_conv` is to provide an easy way to implement conversions of data formats as possible. If you get performance problems probably you should check other ppx based data converters specific to one data format. 

Basic
==========

```
type 'a t = <definition> [@@deriving conv{name}]
```

Multiple targets
==================

```
type t = <definition> [@@deriving conv{ocaml; json}]
```

Using special name
=====================

```
type 'a t = Zee                          (* The default name "Zee" is used *)
          | Foo [@conv.as foo]           (* "foo" *)
          | Bar [@conv.as "bar"]         (* "bar" *)
          | Boo [@conv.as {ocaml="boo"}] (* only for 'ocaml' target *)
          [@@deriving conv{name}]
```

```
type t = { x [@conv.as X] : int;
           y [@conv.as {ocaml="Y"}] : float } 
         [@@deriving conv{name}]
```

Field for Leftovers
======================

`t mc_leftovers` is a special type. 

```
type 'a mc_leftovers = (string * 'a) list
type t = { x : int;
           y : float;
           rest : Ocaml.t mc_leftovers;
         [@@deriving conv{name}]
```

Ignore unknown fields
===========================

```
type t = {
    foo: int;
    bar: float;
  } [@conv.ignore_unknown_fields] (* t_of_ocaml does not fail even if the source contains fields other than foo and bar *)
    [@@deriving conv{ocaml}]
```

Optional field 
============================

`t mc_option` is a special type.

```
type t = { x : int;
           y : float mc_option  (* the source may have a field y of type float,
                                   or may not have it at all. *)
         } 
         [@@deriving conv{name}]
```
