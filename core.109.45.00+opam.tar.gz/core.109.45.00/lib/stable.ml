include Core_kernel.Stable

module Date           = Date          .Stable
module Interval       = Interval      .Stable
module Ofday          = Ofday         .Stable
module Span           = Span          .Stable
module Time           = Time          .Stable
module User_and_group = User_and_group.Stable
module Zone           = Zone          .Stable
