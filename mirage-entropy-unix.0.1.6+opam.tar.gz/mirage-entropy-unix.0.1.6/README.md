mirage-entropy
==============

Entropy sources for MirageOS unikernels, following
the `V1_LWT` module type from:

<https://github.com/mirage/mirage> (in the `types/` directory)

* WWW: <http://openmirage.org>
* E-mail: <mirageos-devel@lists.xenproject.org>
* Issues: <https://github.com/mirage/mirage/issues>
* IRC: `#mirage` on Freenode
