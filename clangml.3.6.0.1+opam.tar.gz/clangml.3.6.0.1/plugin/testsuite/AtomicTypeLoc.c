void foo(int x)
{
  _Atomic(int) i = 0;
}
