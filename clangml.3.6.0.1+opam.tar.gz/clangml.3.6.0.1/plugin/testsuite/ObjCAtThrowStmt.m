@interface Object
{
}
@end

void test (Object* sendPort)
{
  @throw sendPort;
}
