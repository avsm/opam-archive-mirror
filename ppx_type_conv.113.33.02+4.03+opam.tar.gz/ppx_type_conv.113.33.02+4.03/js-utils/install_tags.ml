let package_name = "ppx_type_conv"

let sections =
  [ ("lib",
    [ ("built_lib_ppx_type_conv", None)
    ; ("built_lib_ppx_type_conv_deriving", None)
    ],
    [ ("META", None)
    ])
  ]
