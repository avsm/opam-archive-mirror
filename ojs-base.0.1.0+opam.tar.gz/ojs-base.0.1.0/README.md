ojs-base
========

Base library for developing OCaml web apps based on websockets and js_of_ocaml
