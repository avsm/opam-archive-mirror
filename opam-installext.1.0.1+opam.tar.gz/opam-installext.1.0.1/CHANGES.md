1.0.1 (2015-01-02):
* Fix CentOS 6 distribution detection (#1).
* Fix Debian distribution detection.

1.0.0 (2014-12-27):
* Initial public release.
