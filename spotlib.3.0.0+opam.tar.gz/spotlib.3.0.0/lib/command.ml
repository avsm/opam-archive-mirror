open Unix
open Base

(*
let stream_read fd = 
  let buflen = 4096 in
  let buf = Bytes.create buflen in
  let open SpotStream in
  let rec f () = lazy begin
    match read fd buf 0 buflen with
    | exception Unix_error ((EAGAIN | EWOULDBLOCK), _, _) -> 
        Cons (`Ok "", f ())
    | exception Unix_error (EPIPE, _, _) -> 
        (* eof in Windows pipe *)
        Null
    | exception e ->
        (* error *)
        Cons (`Error (`Exn e), f ())
    | 0 -> 
        (* eof *)
        Null
    | len -> 
        (* Not good if the inputs are in small chunks *)
        Cons (`Ok (String.sub buf 0 len), f ())
  end
  in
  f ()
*)

let liner ?(cut_threshold=10000) () =
  let buf = Buffer.create 1024 in
  fun eof s ->
    let len = String.length s in
    let rec get_lines pos =
      if pos >= len then [], "" 
      else
        match 
          Xstring.index_from_to s pos (len-1) '\n'
        with
        | None when eof -> [String.sub s pos (len-pos)], ""
        | None -> [], String.sub s pos (len-pos)
        | Some pos' ->
            let lines, rem = get_lines (pos'+1) in
            String.sub s pos (pos'+1-pos) :: lines, rem
    in
    let lines, rem = get_lines 0 in
    match lines with
    | [] -> (* no new line in s *)
        Buffer.add_string buf rem;
        if Buffer.length buf > cut_threshold then begin
          let s = Buffer.contents buf in
          Buffer.clear buf;
          [s]
        end else []
    | l::ls ->
        let l = Buffer.contents buf ^ l in
        Buffer.clear buf;
        Buffer.add_string buf rem;
        l::ls

let multi_stream_read xs = 
  let buflen = 4096 in
  let buf = Bytes.create buflen in
  let open Stream in
  let rec f xs = lazy begin
    if xs = [] then Null
    else
      let fds = List.map (fun (fd, _, _) -> fd) xs in 
      let readables, _, _ =
        let rec f () =
          try select fds [] [](*?*) (-1.0)(*?*) with
          | Unix_error (EINTR, _, _) -> f ()
        in
        f ()
      in
      let rev_tks, rev_xs =
        List.fold_left (fun (rev_tks, rev_xs) (fd, fattr, ftknize as x) ->
          if not (List.mem fd readables) then
            rev_tks, x::rev_xs
          else 
            match read fd buf 0 buflen with
            | exception Unix_error ((EAGAIN | EINTR | EWOULDBLOCK), _, _) -> 
                rev_tks, 
                x :: rev_xs
            | exception Unix_error (EPIPE, _, _) -> 
                (* eof in Windows pipe *)
                (* Exn.try_ignore Unix.close fd; *)
                let tkns = ftknize true "" in
                List.(rev_append 
                        (rev_map (fun x -> fattr (`Read x)) tkns)
                        (fattr `EOF :: rev_tks)), 
                rev_xs
            | 0 -> 
                (* eof in Windows pipe *)
                (* Exn.try_ignore Unix.close fd; *)
                let tkns = ftknize true "" in
                List.(rev_append 
                        (rev_map (fun x -> fattr (`Read x)) tkns)
                        (fattr `EOF :: rev_tks)), 
                rev_xs
            | len -> 
                let tkns = ftknize false & String.sub buf 0 len in
                List.(rev_append 
                        (rev_map (fun x -> fattr (`Read x)) tkns)
                        rev_tks), 
                x :: rev_xs
            | exception (Unix_error _ as e) -> 
                (* error *)
                (* Exn.try_ignore Unix.close fd;  *)
                let tkns = ftknize true "" in
                List.(rev_append
                        (rev_map (fun x -> fattr (`Read x)) tkns)
                        (fattr (`Error e) :: rev_tks)),
                rev_xs)
          ([], []) xs
      in
      assert (rev_tks <> []);
      let s = f & List.rev rev_xs in
      let rev_append rev s = 
        let rec f s = function
          | [] -> s
          | t::ts -> f (Lazy.from_val (Cons (t, s))) ts
        in
        f s rev
      in
      Lazy.force & rev_append rev_tks s
  end
  in
  f xs

(*
let by_lines ?(cut_threshold=10000) ss = 
  let open Stream in
  (* rev_len = List.(fold_left (+) 0 (map String.length rev) *)
  let rec f rev_len rev = function
    | lazy Null ->
        begin match rev with
        | [] -> Null
        | _ -> 
            let s = String.concat "" & List.rev rev in
            if s = "" then Null
            else Cons (`Ok s, null)
        end
    | lazy (Cons (`Ok s, ss)) ->
        let len = String.length s in
        let rec get_lines rev_len rev pos =
          match
            if pos >= len then None
            else Xstring.index_from_to s pos (len-1) '\n'
          with
          | None ->
              let rev = String.sub s pos (len - pos) :: rev in
              let rev_len = rev_len + len - pos in
              if rev_len > cut_threshold then
                Cons (`Ok (String.concat "" & List.rev rev),
                      lazy (f 0 [] ss))
              else
                f rev_len rev ss
          | Some pos' ->
              let rev = String.sub s pos (pos'+1-pos) :: rev in
              Cons (`Ok (String.concat "" & List.rev rev), 
                    lazy (get_lines 0 [] (pos'+1)))
        in
        get_lines rev_len rev 0
    | lazy (Cons (`Error e, ss)) ->
        Cons (`Ok (String.concat "" & List.rev rev),
              cons (`Error e) (lazy (f 0 [] ss)))
  in
  lazy (f 0 [] ss)

let %TEST by_lines = 
  let test () = 
    let create_random_string len =
      let s = Bytes.create len in
      let cs = "abcdefghijklmnopqrstuvwxyz\n" in
      let cs_len = String.length cs in
      for i = 0 to len - 1 do
        s.[i] <- cs.[Random.int (cs_len-1)]
      done;
      s
    in
    let s =
      Stream.create (fun len ->
        if len = 0 then None
        else Some (`Ok (create_random_string (Random.int 100)), len-1))
      & Random.int 300
    in
    let str = String.concat "" & List.map Result.from_Ok & Stream.to_list s in
    let s' = by_lines ~cut_threshold:10 s in
    let str' = String.concat "" & List.map Result.from_Ok &  Stream.to_list s' in
    str = str'
  in
  let rec f = function
    | 0 -> true
    | n ->
        if test () then f (n-1) else false
  in
  f 1000
*)

type output =
  [ `Err of [ `EOF | `Error of exn | `Read of string ]
  | `Out of [ `EOF | `Error of exn | `Read of string ]
  ]

let raw_exec ?env cmd =
  let env = Option.default env environment in
  let ic, oc, ec = open_process_full cmd env in
  close_out oc;
  let ifd = descr_of_in_channel ic in
  let efd = descr_of_in_channel ec in
  (multi_stream_read 
    [ ifd, (fun x -> `Out x), liner ()
    ; efd, (fun x -> `Err x), liner () ],
   fun () -> close_process_full (ic, oc, ec) (* close failure of oc is ignored *))

let shell_exec ?env cmd exit f =
  let s, closer = raw_exec ?env cmd in
  let res = Exn.catch f s in
  let w = closer () in
  exit w res

(* Unix.open_process_* only takes concatenated command string... *)
let escape s =
  let b = Buffer.create & String.length s + 2 in
  Buffer.add_char b '\'';
  for i = 0 to String.length s - 1 do
    match String.unsafe_get s i with
    | '\'' -> Buffer.add_string b "'\\''"
    | c -> Buffer.add_char b c
  done;
  Buffer.add_char b '\'';
  Buffer.contents b

let escape_for_shell ss = String.concat " " & List.map escape ss

let exec ?env cmd exit f = shell_exec ?env (escape_for_shell cmd) exit f

let fail = function
  | WEXITED n   -> Exn.failwithf "process exited with id %d" n
  | WSIGNALED n -> Exn.failwithf "process killed by signal %d" n
  | WSTOPPED n  -> Exn.failwithf "process stopped by signal %d" n

let must_exit_with n w res = 
  match w with
  | WEXITED m when n = m ->
      begin match res with
      | `Ok v -> v
      | `Error (`Exn e) -> raise e
      end
  | _ -> fail w

let force_lines s = 
  Stream.filter_map (function
    | `Out (`Read s) | `Err (`Read s) -> Some s
    | _ -> None) s
  |> Stream.to_list

let force_stdout s = 
  Stream.filter_map (function
    | `Out (`Read s) -> Some s
    | _ -> None) s
  |> Stream.to_list

let force_stderr s = 
  Stream.filter_map (function
    | `Err (`Read s) -> Some s
    | _ -> None) s
  |> Stream.to_list

