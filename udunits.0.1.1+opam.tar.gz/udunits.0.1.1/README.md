## ocaml-udunits - OCaml bindings to the UDUNITS-2 library

[UDUNITS-2][udunits] is a library that converts between unit specifications.
The API currently closely follows the [C API][c_api].

[udunits]: http://www.unidata.ucar.edu/software/udunits/
[c_api]: http://www.unidata.ucar.edu/software/udunits/udunits-2/udunits2lib.html

