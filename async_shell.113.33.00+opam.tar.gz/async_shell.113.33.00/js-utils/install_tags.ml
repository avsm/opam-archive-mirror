let package_name = "async_shell"

let sections =
  [ ("lib",
    [ ("built_lib_async_shell", None)
    ],
    [ ("META", None)
    ])
  ]
