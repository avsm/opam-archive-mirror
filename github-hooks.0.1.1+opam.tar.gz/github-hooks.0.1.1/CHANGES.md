### 0.1.1

- Update for github 2.0.1 which fixes a GitHub hook config type issue

### 0.1.0

- initial release, extracted from datakit, itself extracted from ocamlot
