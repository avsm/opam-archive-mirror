(* OASIS_START *)
(* DO NOT EDIT (digest: 2b4acad02b220fb3ce239079d07524d1) *)
This is the README file for the omd distribution.

A Markdown frontend in pure OCaml.

This Markdown library is implemented using only pure OCaml (including I/O
operations provided by the standard OCaml compiler distribution). OMD is
meant to be as faithful as possible to the original Markdown. Additionally,
OMD implements a few Github markdown features, an extension mechanism, and a
few other features. Note that the opam package installs both the OMD library
and the command line tool `omd`. Note that The library interface of 1.0.x is
only partially compatible with 0.9.x.

See the files INSTALL.txt for building and installation instructions. 

Home page: https://github.com/ocaml/omd


(* OASIS_STOP *)
