(*---------------------------------------------------------------------------*
  $Change$
  Copyright (c) 2006-2010, James H. Woodyatt
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  
    Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
    
    Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in
    the documentation and/or other materials provided with the
    distribution
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
  COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
  STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
  OF THE POSSIBILITY OF SUCH DAMAGE. 
 *---------------------------------------------------------------------------*)

(*
let jout = Cf_journal.stdout
*)

open Cf_cmonad.Op

class ['af] connection more socket = object
    method more: Iom_stream.more = more
    method socket: ('af, [ `SOCK_STREAM ]) Nx_socket.t = socket
end

class virtual ['control, 'notify, 'connect] connector ~k ~s:socket ~rwx pad =
    let _ = (socket : 'socket) in
    let fd = Nx_socket.to_unix_file_descr socket in
    let connectTx, (controlRx, notifyTx) = pad in
    let notifyTx = (notifyTx : 'notify Iom_gadget.tx) in
    let pad = (controlRx, connectTx) in
    object(self:'self)
        inherit ['control, 'connect] Iom_reactor.source ~k pad as super
        inherit [unit Iom_gadget.t] Nx_poll.file rwx fd as poll
        
        constraint 'socket = ('af, Nx_socket.SOCK_STREAM.tag) Nx_socket.t
        constraint 'connect = 'af #connection
        
        val mutable initiated_ = false
        
        method virtual private bind: unit
                
        method private stop =
            Nx_socket.close socket;
            super#stop
        
        method private fail: 'a. exn -> 'a Iom_gadget.t = fun x ->
            notifyTx#put (`Failed x) >>= fun () ->
            self#stop
            
        method private ready =
            initiated_ <- true;
            super#ready
        
        method start =
            try
                Unix.set_nonblock fd;
                self#bind;
                super#start
            with
            | x ->
                self#fail x
    end

class virtual ['control, 'notify, 'connect] initiator ~k ~s pad =
    let connectTx, _ = pad in
    object(self:'self)
        inherit ['control, 'notify, 'connect] connector
            ~k ~s ~rwx:`W pad as super
                
        method virtual private connect: 'connect
        
        method private source = Some self#connect
        
        method private service p =
            try
                match super#service p with
                | Nx_poll.Working (_, out) -> Nx_poll.Final out
                | s -> s
            with
            | x ->
                Nx_poll.Final (self#fail x)
        
        method private ready =
            match initiated_ with
            | true ->
                super#ready
            | false ->
                try connectTx#put self#connect with
                | Unix.Unix_error (Unix.EINPROGRESS, _, _) -> super#ready
                | x -> self#fail x
    end

type 'address listen = [ `Listen of 'address ]
type 'address listener_notify = [ 'address listen | Iom_stream.failed ]

let seqput_ acc tx =
    let tx = (tx :> 'a Iom_gadget.tx) in
    Cf_seq.C.sequence (Cf_seq.map tx#put (Cf_seq.of_list (List.rev acc)))

class virtual ['control, 'notify, 'connect] listener ~k ~s ~backlog pad =
    let connectTx, (_, notifyTx) = pad in
    object(self:'self)
        inherit ['control, 'notify, 'connect] connector
            ~k ~s ~rwx:`R pad as super
        
        constraint 'notify = [> 'address listener_notify ]
        
        val mutable stack_ = []
        
        method virtual private getsockname: 'address
        method virtual private accept: 'connection
        
        method private source =
            stack_ <- self#accept :: stack_;
            self#source
        
        method private service p =
            assert source_;
            stack_ <- [];
            try
                ignore self#source;
                assert (not true);
                Nx_poll.Unloaded
            with
            | Unix.Unix_error (code, _, _)
              when Iom_reactor.retry_needed code ->
                let out = seqput_ stack_ connectTx in
                stack_ <- [];
                Nx_poll.Working (p, out)
            | x ->
                let out =
                    seqput_ stack_ connectTx >>= fun () ->
                    self#fail x
                in
                stack_ <- [];
                match x with
                | Unix.Unix_error ((Unix.EMFILE | Unix.ENFILE), _, _) ->
                    Nx_poll.Working (p, out)
                | _ ->
                    Nx_poll.Final out
        
        method private ready =
            match initiated_ with
            | true ->
                super#ready
            | false ->
                try
                    Nx_socket.listen s backlog;
                    let address = self#getsockname in
                    notifyTx#put (`Listen address) >>= fun () ->
                    super#ready
                with
                | x ->
                    self#fail x
    end

class ['control, 'notify] receiver ~k ~s:socket ~limits pad =
    let _ = (socket : ('af, [ `SOCK_STREAM ]) Nx_socket.t) in
    let fd = Nx_socket.to_unix_file_descr socket in
    let fragmentTx, (_, notifyTx) = pad in
    object(self)
        inherit ['control, 'notify] Iom_reactor.reader ~k ~fd ~limits pad
        
        method private octets n =
            let v =
                Nx_socket.recv socket buffer_ cursor_ n
                    Nx_socket.msg_flags_none
            in
            if v = 0 then raise End_of_file;
            v
        
        method private service p =
            assert source_;
            try
                match self#source with
                | None ->
                    Nx_poll.Loaded p
                | Some fragment ->
                    let more = fragment#more in
                    let out = fragmentTx#put fragment in
                    match more with
                    | Iom_stream.More ->
                        Nx_poll.Working (p, out)
                    | Iom_stream.Last ->
                        let out = out >>= fun () -> notifyTx#put `Finished in
                        Nx_poll.Final out
            with
            | Unix.Unix_error (code, _, _)
              when Iom_reactor.retry_needed code ->
                Nx_poll.Loaded p
            | x ->
                Nx_poll.Final (notifyTx#put (`Failed x))
    end

class ['control, 'notify] sender ~k ~s:socket pad =
    let _ = (socket : ('af, [ `SOCK_STREAM ]) Nx_socket.t) in
    let fd = Nx_socket.to_unix_file_descr socket in
    object
        constraint 'notify = [> `Finished ]
        
        inherit [Iom_octet_stream.fragment, 'control, 'notify]
            Iom_reactor.writer ~k ~fd pad as super
        
        method private octets buf pos len =
            Nx_socket.send socket buf pos len Nx_socket.msg_flags_none
        
        method private complete =
            Unix.shutdown fd Unix.SHUTDOWN_SEND;
            super#complete
    end

type ('ci, 'co, 'ni, 'no, 'x, 'cx, 'nx) state = [
    | ('ci, 'co, 'ni, 'no) Iom_socket.state
    | `S_receiving of ('ci, 'ni) Iom_gadget.fix
    | `S_sending of ('co, 'no) Iom_gadget.fix
    | `S_initiating of ('x, 'cx, 'nx) Iom_stream.ifix * 'ci
]
constraint 'ni = [> `Finished ]
constraint 'no = [> `Finished ]

class virtual ['i, 'o, 'control, 'notify, 'af] endpoint ~k ~s ?addrs pad =
    let _, (_, notifyTx) = pad in
    object(self:'self)
        inherit ['i, 'o, 'control, 'notify, 'state, 'af, 'st]
            Iom_socket.endpoint ~k ~s pad as super
        
        constraint 'i = #Iom_octet_stream.fragment
        constraint 'o = #Iom_octet_stream.fragment
        constraint 'state = ('ci, 'co, 'ni, 'no, 'x, 'cx, 'nx) state
        constraint 'st = Nx_socket.SOCK_STREAM.tag
        
        method virtual private initiator:
            src:'af Nx_socket.sockaddr -> dst:'af Nx_socket.sockaddr ->
            ('x, 'cx, 'nx) Iom_stream.ipad -> #Iom_gadget.start
        
        method private state0 =
            match addrs with
            | None ->
                self#establish
            | Some (src, dst) ->
                Iom_gadget.simplex >>= fun (rx, tx) ->
                Iom_gadget.duplex >>= fun (xJack, xPlug) ->
                let _, ctrlTx = xJack in
                ctrlTx#put `Ready >>= fun () ->
                let xJack = rx, xJack and xPlug = tx, xPlug in
                let m = (self#initiator ~src ~dst xPlug :> Iom_gadget.start) in
                m#start >>= fun () ->
                Cf_cmonad.return (`S_initiating (xJack, `Wait))
        
        method private connected rdCtrl (_ : 'connection) =
            self#establish >>= function
            | `S_established ((_, rdTx), _) as state ->
                rdTx#put rdCtrl >>= fun () ->
                {< state_ = state >}#next
            | _ ->
                assert (not true);
                Iom_gadget.abort
        
        method private close =
            match state_ with
            | `S_initiating _ ->
                Iom_gadget.abort
            | _ ->
                super#close
        
        method private xnotify = function
            | #Iom_stream.failed as event ->
                notifyTx#put event >>= fun () ->
                self#close
            | _ ->
                assert (not true);
                self#next
        
        method private inotify c =
            match c, state_ with
            | `Finished, `S_established (_, wr) ->
                {< state_ = `S_sending wr >}#next
            | `Finished, `S_receiving _ ->
                self#close
            | _ ->
                super#inotify c
        
        method private onotify c =
            match c, state_ with
            | `Finished, `S_established (rd, _) ->
                notifyTx#put `Wait >>= fun () ->
                {< state_ = `S_receiving rd >}#next
            | `Finished, `S_sending _ ->
                notifyTx#put `Wait >>= fun () ->
                self#close
            | _ ->
                super#onotify c
        
        method private control c =
            match c, state_ with
            | `Stop as c, `S_initiating ((_, (_, ctrlTx)), _) ->
                ctrlTx#put c >>= fun () ->
                self#close
            | `Stop as c, `S_receiving (_, stopTx) ->
                stopTx#put c >>= fun () ->
                self#reset
            | `Stop as c, `S_sending (_, stopTx) ->
                stopTx#put c >>= fun () ->
                self#reset
            | #Iom_stream.readywait as c, `S_initiating (xJack, _) ->
                {< state_ = `S_initiating (xJack, c) >}#next
            | #Iom_stream.readywait as c, `S_receiving (_, rdTx) ->
                rdTx#put c >>= fun () ->
                self#next
            | _, _ ->
                super#control c
        
        method private stateguard =
            match state_ with
            | `S_initiating ((connectRx, (notifyRx, _)), rdCtrl) ->
                connectRx#get (self#connected rdCtrl) >>= fun () ->
                notifyRx#get self#xnotify
            | `S_receiving (readerRx, _) ->
                readerRx#get self#inotify
            | `S_sending (writerRx, _) ->
                writerRx#get self#onotify
            | _ ->
                super#stateguard
    end

module Aux = struct
    class ['af] connection_aux = ['af] connection
    
    class virtual ['control, 'notify, 'connect] initiator_aux
        ~k ~s ~src ~dst pad =
        object(self)
            inherit ['control, 'notify, 'connect] initiator ~k ~s pad
            constraint 'connect = 'af #connection_aux
            
            method virtual private aux:
                ('af, Nx_socket.SOCK_STREAM.tag) Nx_socket.t -> 'connect
            
            method private bind = Nx_socket.bind s src
            
            method private connect =
                begin
                    try Nx_socket.connect s dst
                    with Unix.Unix_error (Unix.EISCONN, _, _) -> ()
                end;
                self#aux s
        end
    
    class virtual ['control, 'notify, 'connect] listener_aux
        ~k ~s ~src ~backlog pad =
        object(self)
            inherit ['control, 'notify, 'connect] listener ~k ~s ~backlog pad
            constraint 'connect = 'af #connection_aux
            
            method virtual private aux:
                ('af, Nx_socket.SOCK_STREAM.tag) Nx_socket.t -> 'connect
            
            method private bind = Nx_socket.bind s src
            
            method private accept =
                let s, _ = Nx_socket.accept s in
                self#aux s
        end
    
    class virtual ['i, 'o, 'control, 'notify, 'af] endpoint_aux =
        ['i, 'o, 'control, 'notify, 'af] endpoint
end

type endpoint_fix =
    (Iom_octet_stream.fragment, Iom_octet_stream.fragment,
    Iom_stream.flowcontrol, Iom_stream.flownotify) Iom_stream.iofix

type 'af initiator_fix =
    ('af connection, Iom_stream.flowcontrol, Iom_stream.failed)
    Iom_stream.ifix

type 'af listener_fix =
    ('af connection, Iom_stream.flowcontrol, 'af Nx_socket.sockaddr
    listener_notify) Iom_stream.ifix

class ['af] initiator0 ~k ~s ~src ~dst pad = object
    inherit [Iom_stream.flowcontrol, Iom_stream.failed, 'af connection]
        Aux.initiator_aux ~k ~s ~src ~dst pad
    
    method private aux s = new connection Iom_stream.Last s
end

let initiator ~s ~src ~dst k =
    Iom_stream.ifix (new initiator0 ~k ~s ~src ~dst)

class ['af] listener0 ~k ~s ~src ~backlog pad = object
    inherit [Iom_stream.flowcontrol, 'af Nx_socket.sockaddr listener_notify,
        'af connection] Aux.listener_aux ~k ~s ~backlog ~src pad
        
    method getsockname = Nx_socket.getsockname s
    method private aux s = new connection Iom_stream.More s
end

let listener ~s ~src ~backlog k =
    Iom_stream.ifix (new listener0 ~k ~s ~src ~backlog)

class ['af] endpoint0 ~k ~s ?addrs ~limits pad = object
    inherit [Iom_octet_stream.fragment, Iom_octet_stream.fragment,
        Iom_stream.flowcontrol, Iom_stream.flownotify, 'af] endpoint ~k ~s
        ?addrs pad
    
    method private initiator = new initiator0 ~k ~s
    method private sender = new sender ~k ~s
    method private receiver = new receiver ~k ~s ~limits
end

let endpoint ~s ?addrs ~limits k =
    Iom_stream.iofix (new endpoint0 ~k ~s ?addrs ~limits)

module type T = sig
    include Iom_socket.T with module P.ST = Nx_socket.SOCK_STREAM
        
    class connection: Iom_stream.more -> t -> object
        inherit [P.AF.tag] Aux.connection_aux
        method local: address
        method remote: address
    end
    
    type initiator =
        (connection, Iom_stream.flowcontrol, Iom_stream.failed) Iom_stream.ifix
    
    type listener =
        (connection, Iom_stream.flowcontrol, address listener_notify)
        Iom_stream.ifix
    
    type endpoint = endpoint_fix
    
    val initiator:
        ?s:t -> ?src:address -> dst:address -> Iom_gadget.kernel ->
        initiator Iom_gadget.t
    
    val listener:
        ?s:t -> ?src:address -> backlog:int -> Iom_gadget.kernel ->
        listener Iom_gadget.t
    
    val endpoint:
        ?s:t -> ?addrs:(address * address) -> limits:Iom_octet_stream.limits ->
        Iom_gadget.kernel -> endpoint Iom_gadget.t
end

module Create(P: Nx_socket.P with module ST = Nx_socket.SOCK_STREAM) = struct
    include Iom_socket.Create(P)
        
    class connection more socket =
        let local = P.AF.of_sockaddr (Nx_socket.getsockname socket) in
        let remote = P.AF.of_sockaddr (Nx_socket.getpeername socket) in
        object
            inherit [P.AF.tag] Aux.connection_aux more socket
            
            method local = local
            method remote = remote
        end
    
    type initiator =
        (connection, Iom_stream.flowcontrol, Iom_stream.failed) Iom_stream.ifix
    
    type listener =
        (connection, Iom_stream.flowcontrol, address listener_notify)
        Iom_stream.ifix
    
    type endpoint = endpoint_fix
    
    let addrsoptmap_ = function
        | None ->
            None
        | Some (src, dst) ->
            let src = P.AF.to_sockaddr src in
            let dst = P.AF.to_sockaddr dst in
            Some (src, dst)
    
    class initiator0
      ~k ?(s = create ()) ?(src = unspecified_address) ~dst pad =
        let src = P.AF.to_sockaddr src in
        let dst = P.AF.to_sockaddr dst in
        object
            inherit [Iom_stream.flowcontrol, Iom_stream.failed, connection]
                Aux.initiator_aux ~k ~s ~src ~dst pad
            
            method private aux s = new connection Iom_stream.Last s
        end
    
    let initiator ?s ?src ~dst k =
        Iom_stream.ifix (new initiator0 ~k ?s ?src ~dst)
    
    class listener0
      ~k ?(s = create ()) ?(src = unspecified_address) ~backlog pad =
        let src = P.AF.to_sockaddr src in
        object
            inherit [Iom_stream.flowcontrol, 'address listener_notify,
                connection] Aux.listener_aux ~k ~s ~backlog ~src pad
                
            method getsockname = P.AF.of_sockaddr (Nx_socket.getsockname s)
            method private aux s = new connection Iom_stream.More s
        end
    
    let listener ?s ?src ~backlog k =
        Iom_stream.ifix (new listener0 ~k ?s ?src ~backlog)
    
    class endpoint0 ~k ?(s = create ()) ?addrs ~limits pad =
        let addrs = addrsoptmap_ addrs in
        object
            inherit [Iom_octet_stream.fragment, Iom_octet_stream.fragment,
                Iom_stream.flowcontrol, Iom_stream.flownotify, P.AF.tag]
                endpoint ~k ~s ?addrs pad
            
            method private initiator ~src ~dst =
                let src = P.AF.of_sockaddr src in
                let dst = P.AF.of_sockaddr dst in
                new initiator0 ~k ~s ~src ~dst
            
            method private sender = new sender ~k ~s
            method private receiver = new receiver ~k ~s ~limits
        end
    
    let endpoint ?s ?addrs ~limits k =
        Iom_stream.iofix (new endpoint0 ~k ?s ?addrs ~limits)
end

(*--- $File$ ---*)
