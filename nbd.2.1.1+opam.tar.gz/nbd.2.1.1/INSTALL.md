The easiest way to fetch the dependencies and build is to use
[opam](https://opam.ocaml.org/).

To install the latest stable version:
```
opam install nbd
```

To install the latest unstable development version:
```
git clone git://github.com/xapi-project/nbd
cd nbd
opam pin add nbd .
```
