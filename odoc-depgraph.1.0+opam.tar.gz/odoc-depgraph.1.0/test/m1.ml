let f x = M2.M.f x;;
let h x = M2.M.O.h ;;
include M2.M.O;;
let h = h;;
module M4 = M4