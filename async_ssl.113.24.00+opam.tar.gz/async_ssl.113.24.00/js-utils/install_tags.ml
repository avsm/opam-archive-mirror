let package_name = "async_ssl"

let sections =
  [ ("lib",
    [ ("built_lib_async_ssl", None)
    ; ("built_lib_async_ssl_bindings", None)
    ],
    [ ("META", None)
    ])
  ]
