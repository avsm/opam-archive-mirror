1.1.0 (2016-06-28)
- don't call `close` on `Eof`
- add `read_exactly`
- add LICENSE
- add conflict with old versions of tcpip
