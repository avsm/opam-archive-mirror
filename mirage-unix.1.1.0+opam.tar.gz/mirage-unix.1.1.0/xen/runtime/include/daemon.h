#ifndef _DAEMON_H
#define _DAEMON_H

#include <unistd.h>

#endif
