# Spacetime_lib

`spacetime_lib` is a library providing some simple operations for
handling OCaml "spacetime" profiles.

## Installation

The easiest way to install `spacetime_lib` is using OPAM:

    opam install spacetime_lib

For installing from source see the dependencies and build instructions
in the `opam` file.

## Documentation

For now you'll just have to read `spacetime_lib.mli`.