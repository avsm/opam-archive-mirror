include Capital_idents

let _ = (E (* ? exception E *) : exn)
