module type (* S2 => *) S (* <= S2 *) = sig
  val x : int
end
