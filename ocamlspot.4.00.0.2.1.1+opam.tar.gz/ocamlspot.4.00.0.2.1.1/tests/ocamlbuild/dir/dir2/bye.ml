let bye = "Bye."

