open Xlazy

type 'a t = 'a desc lazy_t

and 'a desc =
  | Cons of 'a * 'a t
  | Null

let null = from_val Null
let cons v t = from_val (Cons (v, t))
let (^^) = cons
let singleton v = cons v null

let peek = function
  | lazy Null -> None
  | lazy (Cons (v, t)) -> Some (v, t)

let is_null = function
  | lazy Null -> true
  | _ -> false

let rec create f st = lazy (match f st with
  | Some (v, st) -> Cons (v, create f st)
  | None -> Null)

let rec of_list = function
  | [] -> null
  | x::xs -> cons x (of_list xs)

let to_list t = 
  let rec to_list st = function
    | lazy Null -> List.rev st
    | lazy (Cons (v, t)) -> to_list (v :: st) t
  in
  to_list [] t
  
let rec iter f = function
  | lazy Null -> ()
  | lazy (Cons (v, t)) -> f v; iter f t

let rec fold_right f lst st = match lst with
  | lazy Null -> st
  | lazy (Cons (v, lst)) -> f v (fold_right f lst st)

let rec map f lst = lazy (match lst with
  | lazy Null -> Null
  | lazy (Cons (v, lst')) -> Cons (f v, map f lst'))

let rec append xs ys = lazy (match xs with
  | lazy Null -> !!ys
  | lazy (Cons (x, xs)) -> Cons (x, append xs ys))
      
  

(* [t2] must be a postfix of [t1] otherwise, it loops forever *)
let rev_between t1 t2 =
  let rec loop st t =
    if t == t2 then st (* CR jfuruse: we cannot always use pointer eq *)
    else 
      match t with
      | lazy (Cons (v, t')) -> loop (v::st) t'
      | lazy Null -> st
  in
  loop [] t1

let between t1 t2 = List.rev (rev_between t1 t2)

