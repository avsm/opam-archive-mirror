time ../../spdiff.opt -specfile specfile -depth 2 -fixed -strict -patterns -malign -only_changes $@ 2> err_out 
