time ../../spdiff.opt -specfile specfile -top 40 -depth 4 -fixed -strict -threshold 3 $@ 2> err_out 
