int foo2(int p) {
	  int y;
	  y = f(y,GFP);
		foo();
	  return y+y;
	}

