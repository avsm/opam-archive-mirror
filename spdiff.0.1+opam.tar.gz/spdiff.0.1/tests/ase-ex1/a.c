int foo(void) {
				int x;
				x = f(x);
				bar();
				return x;
}

