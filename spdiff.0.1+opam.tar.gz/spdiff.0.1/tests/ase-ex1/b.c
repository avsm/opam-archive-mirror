int foo(void) {
				int x;
				foo();
				x = f(x,GFP);
				bar();
				return x+x;
}
