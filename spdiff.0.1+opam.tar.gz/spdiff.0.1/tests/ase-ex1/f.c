int smoz(int y) {
	  int x;
		x = f(x,GFP);
	  return x+x;
	}

