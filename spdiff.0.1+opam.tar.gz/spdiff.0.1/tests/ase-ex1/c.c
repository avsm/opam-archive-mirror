int foo2(int p) {
	  int y;
	  y = f(y);
		foo();
	  return y;
	}

