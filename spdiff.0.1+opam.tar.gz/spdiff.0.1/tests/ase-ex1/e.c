int smoz(int y) {
	  int x;
	  x = f(x);
	  return x;
	}


