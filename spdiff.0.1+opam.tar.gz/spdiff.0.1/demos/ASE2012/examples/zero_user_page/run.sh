spdiff.opt -macro_file standard.h -spatch -show_support -only_changes -focus_function memclear_highpage_flush -filter_spatches
