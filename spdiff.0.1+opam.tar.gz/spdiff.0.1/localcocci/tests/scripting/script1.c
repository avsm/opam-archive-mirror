int main() {
  int buf[20];
  int i;

  for (i = 0; i <= 20; ++i)
    buf[i] = i;

  f();
}
