#include "multi_inc1.h"

int main () {
  f(xxx);
}
