struct foo {int a;};

typedef struct blah {int a;} name;

typedef struct {int a;} xxx;
