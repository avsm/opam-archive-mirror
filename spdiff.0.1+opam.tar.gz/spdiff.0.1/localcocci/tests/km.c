int main() {
  int *data = kmalloc(element->string.length + 1, GFP_KERNEL);
  foo();
  memset(data, 0, element->string.length + 1);
}
