inline void foo(int x) { return; }
