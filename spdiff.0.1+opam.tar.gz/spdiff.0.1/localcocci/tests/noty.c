int main(int *x) {
  if (NULL == x) { return; }
}
