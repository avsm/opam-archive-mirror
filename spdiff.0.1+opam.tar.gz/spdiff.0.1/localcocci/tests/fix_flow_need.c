void main(int i) {

  foobar();

  if(1) { 
    foo(); 
  }
  bar();

  foobar();
}
