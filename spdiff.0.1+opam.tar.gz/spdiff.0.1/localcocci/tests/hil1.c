#define FUNC(funct, funct_arg, zero_rc, neg_rc, pos_rc) \
{ HILSE_FUNC,		{ func: &funct }, funct_arg, zero_rc },

int main () {
  return 12;
}
