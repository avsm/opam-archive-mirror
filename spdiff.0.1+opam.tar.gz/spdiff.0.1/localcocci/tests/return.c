void foo(int y) {
  int x;
  if (x) { aaa(); bbb(); return; }
  if (x) { aaa(); bbb(); return; }
  ccc();
}
