int main () {
  const int x;
  int y;
  f(x,int);
  f(y,int);
  f(x,const int);
}
