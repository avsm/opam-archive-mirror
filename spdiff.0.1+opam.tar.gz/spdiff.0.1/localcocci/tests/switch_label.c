int main () {
  switch (event) {
  case CS_EVENT_CARD_REMOVAL:
    one();
    two();
    three();
    break;
  }
}
