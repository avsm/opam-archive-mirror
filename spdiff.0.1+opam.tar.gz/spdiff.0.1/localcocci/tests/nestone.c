int foo() {
  if (x) { xxx(); return;}
  yyy();
}
