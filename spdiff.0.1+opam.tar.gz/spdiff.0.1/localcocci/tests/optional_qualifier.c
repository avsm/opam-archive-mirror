int a;
const int b;
