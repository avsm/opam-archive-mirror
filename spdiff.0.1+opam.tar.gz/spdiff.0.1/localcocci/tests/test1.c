void main(int foo) {

  f(1);
  x();
  g(2);
  x();
  if(1) {
    //    h(3);
    h(3);
  } else {
    h(4);
  }

  
}

