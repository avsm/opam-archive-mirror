int __init
snd_pmac_awacs_init(struct snd_pmac *chip)
{
	struct awacs_amp *amp = kmalloc(sizeof(*amp));
	memset(sizeof(*amp));
}
