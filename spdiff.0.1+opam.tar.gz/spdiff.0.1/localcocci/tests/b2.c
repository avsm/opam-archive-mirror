int main () {
 if (1) {
    if (x > 1 ) { foo(); brk(); }
    } else aaa();
  if (1)
    while (x > 1 ) { foo(); brk(); }
  else aaa();
  foo(); brk();
}
