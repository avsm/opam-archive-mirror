void main(int i) {
  f(1);
  f(1);
  g(1);
  g(1); // if comment then should work
  h(1);
  h(1);

}
