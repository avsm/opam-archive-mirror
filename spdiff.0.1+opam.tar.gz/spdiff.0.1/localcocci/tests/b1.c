int main () {
  while (1) {
    if (x > 1 ) { foo(); break; }
    }
  while (1)
    if (x > 1 ) { foo(); break; }
}
