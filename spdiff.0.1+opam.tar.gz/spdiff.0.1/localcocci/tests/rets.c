int main () {
  foo();
  return 12;
}
