int main () {
  f(1);
  h(2);
  i(2);
}
