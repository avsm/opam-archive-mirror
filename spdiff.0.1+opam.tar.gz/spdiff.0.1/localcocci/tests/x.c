int main () {
  foo(x);
  foo(x);
  foo(x);
}

