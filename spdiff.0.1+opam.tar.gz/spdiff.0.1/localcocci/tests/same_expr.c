void main(int i)
{
	f(1,1);
	f(1,2);
	
}
