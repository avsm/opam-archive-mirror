void main(int foo) {
  
  f(1);
  foo();
  g(2);

}

