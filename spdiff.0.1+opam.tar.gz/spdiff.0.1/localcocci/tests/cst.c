int main(int x) {
  emu10k1_t *emu = snd_magic_cast(1, 2, return -ENXIO);
  int z = 12;
  return y;
}
