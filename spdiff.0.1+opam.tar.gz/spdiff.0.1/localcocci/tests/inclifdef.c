#include <linux/foo.h>
#ifdef CONFIG
#include <linux/bar.h>
#endif
