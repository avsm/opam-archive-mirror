void main(int i) {
  f(1);
  g(1);
  g(1); // if comment then simpler
  h(1);

}
