int main () {
  foo(sizeof (struct xxx));
}
