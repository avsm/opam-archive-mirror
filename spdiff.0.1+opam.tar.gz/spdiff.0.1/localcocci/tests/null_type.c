int main(int i) {

  int *x;

  g(x);
  g(NULL);

}
