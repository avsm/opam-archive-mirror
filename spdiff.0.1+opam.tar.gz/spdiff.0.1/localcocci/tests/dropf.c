int main() {
  x = f(1) + f(3);
}
