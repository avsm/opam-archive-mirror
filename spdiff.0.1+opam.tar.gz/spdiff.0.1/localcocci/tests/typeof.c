int main() {
  int x;
  f(x);
  f(sizeof(struct foo));
  f(sizeof(int));
}
