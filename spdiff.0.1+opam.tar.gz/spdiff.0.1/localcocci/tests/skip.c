int main () {
  f(1);
  f(2);
  g();
}
