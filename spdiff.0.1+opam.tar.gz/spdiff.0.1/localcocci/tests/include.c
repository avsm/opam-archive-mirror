
#include <stdio.h>
#include <stdio2.h>
#include <devfs_kernel.h>
#include   <devfs_kernel.h>


void main(int i) {
  i++;
}
