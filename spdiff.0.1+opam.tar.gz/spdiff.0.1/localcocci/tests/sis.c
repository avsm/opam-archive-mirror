DECLARE_MUTEX(disconnect_sem);
/*int foo() { return; }*/
// if uncomment, and erase newline, then have Line ID EOF and
// some patterns in parsing_hacks don't apply anymore :(


