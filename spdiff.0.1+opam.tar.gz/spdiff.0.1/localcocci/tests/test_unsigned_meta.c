int main () {
  unsigned int x;
  signed int y;
  unsigned char q;
  char m;
  return 0;
}

