
void f(int i) {

  if(x > 0) return x;

}
