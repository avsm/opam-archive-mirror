int main () {
  if (x)
    return;
}
