static int az_ioctl(int cmd, void *arg)
{
  return 0;
}

