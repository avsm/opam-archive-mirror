int main(int x) {
  f();
  if(1) {
    replace();
  }
  g();
}
