int main() {
  f();
  x();
  a();
  g();
  if (q) y();
}
