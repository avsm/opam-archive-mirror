struct saa5249_device
{
	struct i2c_client *client;
};
