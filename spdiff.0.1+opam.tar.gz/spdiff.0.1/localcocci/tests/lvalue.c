int main() {
  x = x + 1;
  *x = 12;
}
