#define foo 3
#define xxx 4
