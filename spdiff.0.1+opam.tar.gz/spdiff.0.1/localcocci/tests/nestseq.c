int main () {
  f();
  g(12);
  h();
}
