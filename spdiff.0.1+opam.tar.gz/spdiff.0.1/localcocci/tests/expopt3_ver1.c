static int pcm20_ioctl(struct video_device *dev, unsigned int cmd, void *arg)
{
	struct video_tuner v;
        //&v.field;
	f(&v.field1, &v.field2, &v.field3, &v.field4);
}
