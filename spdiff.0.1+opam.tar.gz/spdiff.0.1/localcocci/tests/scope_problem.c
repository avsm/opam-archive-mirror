void main(int i) {

  int a;
  foo(a);
  a = 1;

  if(1) {
    int a;
    a = 2;
  }

  a = 3;


}
