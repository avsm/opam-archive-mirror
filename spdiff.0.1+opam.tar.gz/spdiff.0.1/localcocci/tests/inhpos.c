int main () {
  g(3);
}
