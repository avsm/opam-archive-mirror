int f() { switch (x) { case FOO: return; } }
