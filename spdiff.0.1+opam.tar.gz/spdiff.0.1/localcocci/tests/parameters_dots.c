void main(int i) {

  f(1);
  g(3);
  f(1,2);
  f();
}
