int main() {
  foo();
  bar();
}
