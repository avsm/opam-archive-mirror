static int f () { int x = 12; int y; return x + y; }
