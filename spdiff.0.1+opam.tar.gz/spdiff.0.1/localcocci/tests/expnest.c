int main() {
  x = 3 + 4;
  x = f() + 15;
  x = 15 + g();
  x = f() + g();
}
