void main(int i) {
  f(1);
  f(1);
  g(1);
  //g(1);
  h(1);
  h(1);

}
