int main(int i) {

  f(0);
  if(1) {
    g(2);
  } else { 
    g(3);
  }
  h(4);

}
