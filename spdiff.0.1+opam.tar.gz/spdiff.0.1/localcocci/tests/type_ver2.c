int foo() {
  int x[10];
  return 0;
}

