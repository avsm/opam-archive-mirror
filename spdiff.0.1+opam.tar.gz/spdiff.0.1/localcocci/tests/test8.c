void main(int foo) {
  
  float k;
  int i;
  float j;

  {
    j++;
  }
  
}

