#define MAX_SETUP_STRINGS (sizeof(setup_strings) / sizeof(char *))
#define SETUP_BUFFER_SIZE 200
