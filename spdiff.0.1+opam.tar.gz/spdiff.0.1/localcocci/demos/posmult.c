int main() {
  int *x = NULL;
  int *y = NULL;
  if (r) x = ALLOC();
  y = ALLOC();
  if (!x) return;
  if (!y) return;
}
