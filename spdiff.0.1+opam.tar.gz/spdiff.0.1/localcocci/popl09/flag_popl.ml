let mark_all = ref false
let keep_all_wits = ref false
