let x = 3
module M = struct let y = 5 end
