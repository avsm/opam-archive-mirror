(* empty file *)

(**
       0 ATOM0 
       1 SETGLOBAL T000
       3 STOP 
**)
