

def get_int():
	return 42