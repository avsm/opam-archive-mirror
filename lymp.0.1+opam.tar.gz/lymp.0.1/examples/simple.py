

def get_message():
	return "hi there"

def get_integer():
	return 42

def sum(a, b):
	return a + b