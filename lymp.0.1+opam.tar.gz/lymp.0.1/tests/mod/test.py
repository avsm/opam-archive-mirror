

def get_msg():
	return "hi there"
