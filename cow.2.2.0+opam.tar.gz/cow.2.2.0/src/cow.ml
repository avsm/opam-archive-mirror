module Xml = Cow_xml
module Json = Cow_json
module Markdown = Cow_markdown
module Html = Cow_html
module Xhtml = Cow_xhtml
module Atom = Cow_atom
