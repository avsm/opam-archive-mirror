This is an OCaml implementation of the DNSCurve protocol.

This codebase is *UNAUDITED*. Use at your own risk.
