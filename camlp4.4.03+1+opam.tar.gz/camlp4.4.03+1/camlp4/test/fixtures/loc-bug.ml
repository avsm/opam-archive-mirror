#default_quotation "expr";;
Lwt.return
  << 3 + >>
