type t1 = ();;
type t2 = unit;;
let x : t1 = ();;
let y : t2 = ();;
