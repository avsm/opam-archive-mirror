(* Dummy strings.ml *)
let docs = []
