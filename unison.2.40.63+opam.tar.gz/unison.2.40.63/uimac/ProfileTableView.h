/* ProfileTableView */

#import <Cocoa/Cocoa.h>
#import "MyController.h"

@interface ProfileTableView : NSTableView
{
    IBOutlet MyController *myController;
}
@end
