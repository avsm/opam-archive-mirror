ocaml-semver
============

Semantic Versioning module for OCaml