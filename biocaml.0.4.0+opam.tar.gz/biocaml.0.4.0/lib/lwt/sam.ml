open Future_lwt.Std

include Biocaml_unix.Std.Sam
include MakeIO(Future)
