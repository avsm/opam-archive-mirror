open Future_lwt.Std

include Biocaml_unix.Std.Lines
include MakeIO(Future)
