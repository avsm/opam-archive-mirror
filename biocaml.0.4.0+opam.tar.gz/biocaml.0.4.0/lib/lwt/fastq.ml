open Future_lwt.Std

include Biocaml_unix.Std.Fastq
include MakeIO(Future)
