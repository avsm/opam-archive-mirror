open Future_async.Std

include Biocaml_unix.Std.Sam
include MakeIO(Future)
