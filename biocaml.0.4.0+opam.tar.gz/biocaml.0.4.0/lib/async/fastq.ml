open Future_async.Std

include Biocaml_unix.Std.Fastq
include MakeIO(Future)
