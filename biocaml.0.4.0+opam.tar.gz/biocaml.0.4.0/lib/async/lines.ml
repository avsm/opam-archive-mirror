open Future_async.Std

include Biocaml_unix.Std.Lines
include MakeIO(Future)
