#include <caml/mlvalues.h>
#include <time.h>
CAMLextern value core_kernel_time_ns_format_tm (struct tm * tm, value v);
