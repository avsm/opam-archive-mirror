#include <caml/mlvalues.h>

/* Defined in <caml/mlvalues.h> */
#if defined(ARCH_SIXTYFOUR)
"ARCH_SIXTYFOUR_IS_DEFINED"
#endif
