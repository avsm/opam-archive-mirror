let hello_string = "hello"

let hello name = Printf.printf "hello %s!\n" name
