(*
 * (c) 2010 Anastasia Gornostaeva
 *
 *)
