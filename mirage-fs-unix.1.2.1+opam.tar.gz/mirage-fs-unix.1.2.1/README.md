This is a pass-through Mirage filesystem to an underlying Unix directory.  The
interface is intended to support eventual privilege separation (e.g. via the
Casper daemon in FreeBSD 11).

The current version supports `KV_RO` and `FS`, as defined in [the mirage-types package](https://github.com/mirage/mirage).

* WWW: <https://openmirage.org>
* E-mail: <mirageos-devel@lists.xenproject.org>
