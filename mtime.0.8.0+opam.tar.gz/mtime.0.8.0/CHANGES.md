v0.8.0 2015-03-19 La Forclaz (VS)
---------------------------------

First release.
