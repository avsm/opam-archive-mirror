
int extunix_open_flags(value);
