/* @providesModule IncrModuleA */

var x:string = 0;
