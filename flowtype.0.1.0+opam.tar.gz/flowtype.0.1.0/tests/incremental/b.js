/* @providesModule IncrModuleB
   @flow
*/

var A = require('IncrModuleA');
