
/* @providesModule FlowSA */

function check(x:string) { }

function FlowSA() {
  var x = 0;
  x = "...";
  check(x);
}

module.exports = FlowSA;
