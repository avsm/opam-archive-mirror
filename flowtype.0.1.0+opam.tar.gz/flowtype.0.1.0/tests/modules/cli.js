/* @flow */

var f = require('./lib');

var y:number = f(0);
