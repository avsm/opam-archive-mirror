declare class C {
    static x: number;
    static foo(x: number): void;
}

C.x = "";
C.foo("");
