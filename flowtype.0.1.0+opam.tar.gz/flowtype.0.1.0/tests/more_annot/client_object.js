var o = require('./object');

var a:number = o.w.z.y;
