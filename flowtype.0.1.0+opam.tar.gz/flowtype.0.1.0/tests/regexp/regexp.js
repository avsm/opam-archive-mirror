var patt=/Hello/g
var match:number = patt.test("Hello world!");
