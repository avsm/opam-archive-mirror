var x = Boolean(4);
function foo(fn:(value:any)=>boolean) { }
foo(Boolean);
