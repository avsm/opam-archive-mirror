var A = require('Demo');

var z = new A("42").getX();
