/* demo */

function f(x) { return 42/x; }

var x = null;
//...

f(x);
