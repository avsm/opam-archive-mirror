class C {
    x: number;
    constructor(x: number) { this.x = x; }
}

module.exports = C;
