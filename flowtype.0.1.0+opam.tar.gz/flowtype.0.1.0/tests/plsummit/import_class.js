var C = require('./export_class');

var c = new C("");
