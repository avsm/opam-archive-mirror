
/* @providesModule Arrays */

function foo(x:string) { }

var a = [];
a[0] = 1;
a[1] = "...";

foo(a[1]);


module.exports = "arrays";
