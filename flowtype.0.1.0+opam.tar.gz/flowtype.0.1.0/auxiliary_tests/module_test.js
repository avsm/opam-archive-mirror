/* @flow */
var Foo = require('Foo');
var Bar = require('Bar');

var x:number = Foo.x;
var y:number = Bar.y;
