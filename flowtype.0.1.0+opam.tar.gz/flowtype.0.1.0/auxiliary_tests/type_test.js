/* @flow */
var _:number = XXX;
