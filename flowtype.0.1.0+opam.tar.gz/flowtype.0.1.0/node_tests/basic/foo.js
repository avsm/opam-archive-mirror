var x = require('./bar.js');
console.log(x);
