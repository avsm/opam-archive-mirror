module.exports = "bar_lib";
