var x: string = require('./bar_lib'); // 'bar_lib' does not work!
console.log(x);
