var x = require('./bar_lib'); // 'bar_lib' does not work!
console.log(x);
