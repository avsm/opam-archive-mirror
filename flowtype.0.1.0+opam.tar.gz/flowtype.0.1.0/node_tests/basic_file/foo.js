var x = require('./bar'); // bar.js does not work
console.log(x);
