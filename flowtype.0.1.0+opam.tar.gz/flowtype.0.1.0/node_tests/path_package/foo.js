var x = require('bar_lib/src/lib');
console.log(x);
