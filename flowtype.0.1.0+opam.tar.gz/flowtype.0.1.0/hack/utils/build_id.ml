external get_build_id : unit -> string = "hh_get_build_id"

let build_id_ohai = get_build_id ()
