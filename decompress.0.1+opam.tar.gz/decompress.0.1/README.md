Decompress
==========

Pur OCaml implementation of Zlib

Documentation
=============

Not yet!

Build Requirements
==================

 * OCaml >= 4.01.0

[![Build Status](https://travis-ci.org/dinosaure/Decompress.svg)](https://travis-ci.org/dinosaure/Decompress)
