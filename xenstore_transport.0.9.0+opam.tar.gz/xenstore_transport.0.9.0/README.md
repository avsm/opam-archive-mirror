ocaml-xenstore-clients
======================

Unix client tools for accessing xenstore.

So far we have:
  1. a CLI for interacting with xenstore
  2. a benchmarking tool for measuring performance
  3. libraries for Unix applications to connect to xenstore

