ocaml-rrdd-plugin
-----------------

[![Build status](https://travis-ci.org/xapi-project/ocaml-rrdd-plugin.png?branch=master)](https://travis-ci.org/xapi-project/ocaml-rrdd-plugin)

A plugin library for the XCP RRD daemon - see [xcp-rrdd](https://github.com/xen-org/xcp-rrdd)
