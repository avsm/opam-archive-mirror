
(* Simple rules for building exe from bunch of ocaml files.
   - no libraries
   - DOES determine deps between files
   - DOES setup rules correctly as determined by existence of *.mli
   - desired .exe configured by the user
   - link order determined automatically
*)
