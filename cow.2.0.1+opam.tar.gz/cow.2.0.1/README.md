Writing web-applications requires a lot of skills: HTML, XML, JSON and
Markdown, to name but a few!  This library provides OCaml combinators
for these web formats by:

See more explanation at: http://mirage.github.io/ocaml-cow

This library is in beta, and full documentation is still being written.
Some repositories which use it include:

* Mirage website: http://github.com/mirage/mirage-www
* Opam2web: http://github.com/OCamlpro/opam2web
