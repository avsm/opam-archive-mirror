* Now that we have Size1 and Box1, consider whether V1 should be introduced.
  for example right know we cannot use the Box_tests functor because
  of this. But is it needless bureaucracy ?
* Raster.sub, maybe add an optional ?copy argument to make a tight copy
  of the buffer data.
