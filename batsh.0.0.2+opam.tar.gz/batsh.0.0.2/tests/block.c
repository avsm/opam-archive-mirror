//Level 0 Start
println("Hello");
{
  //Level 1 Start
  println("Lo");
  {
    //Level 2 Start
    println("and behold");
    //Level 2 End
  }
  //Level 1 End
}
println("End");
//Level 0 End
