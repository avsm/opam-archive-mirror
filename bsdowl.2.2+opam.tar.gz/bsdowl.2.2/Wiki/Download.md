# Download BSD Owl Scripts

You can get a distribution tarball suitable for installation from the
[download area](https://bitbucket.org/michipili/bsdowl/downloads).

If you are interested in modifying the software, you can clone the GIT
repository:

```
https://michipili@bitbucket.org/michipili/bsdowl.git
```

If you are running a Linux based
system, or any system but FreeBSD, NetBSD and MAC OS-X, you also shall
consider getting Simon J. Garrety's following software:
[bmake.tar.gz](http://void.crufty.net/ftp/pub/sjg/bmake.tar.gz)
and
[mk.tar.gz](http://void.crufty.net/ftp/pub/sjg/mk.tar.gz).
