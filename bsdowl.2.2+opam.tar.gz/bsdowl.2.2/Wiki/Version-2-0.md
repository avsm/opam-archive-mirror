# Preparation of version 2.0

We are preparing version 2.0.  There is several tasks associated to
this version which needs special tracking.

- #2 Translate and standardise comments
- #1 Translate and improve documentation
- #4 Extend OCaml support with phony variables


Remove references to GNA!

Remove the INSTALL file, it should only apply to current software.
Move content to the wiki.
