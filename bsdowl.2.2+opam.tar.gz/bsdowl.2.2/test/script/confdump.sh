### confdump.sh -- Écrire des variables

echo 'TMPDIR=%%TMPDIR%%'

### End of file `confdump.sh'
