The example files:

dhcp.pcap

come from the wireshark wiki

http://wiki.wireshark.org/DHCP

and are licensed under the GPL.
