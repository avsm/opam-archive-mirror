(* OASIS_START *)
(* DO NOT EDIT (digest: b2c4734cd8551c7876d9c33f76279aac) *)

gammu - Cell phone and SIM card access.
=======================================

Gammu is a binding to libGammu which allows to manage data in your cell phone
such as contacts, calendar or messages.

See the file [INSTALL.txt](INSTALL.txt) for building and installation
instructions.

[Home page](https://github.com/Chris00/ocaml-gammu)

Copyright and license
---------------------

gammu is distributed under the terms of the GNU Lesser General Public License
version 3.0 with OCaml linking exception.

(* OASIS_STOP *)
