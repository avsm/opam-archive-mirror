let max_udp_length = 65507 (* IP datagram (65535) - IP header(20) - UDP header(8) *)
