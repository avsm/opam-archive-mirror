/**@constructor*/
function Foo() {
	/**
		@public
		@static
		@field
	*/
	var bar = function(x) {
	}
}