// /**#=+
//  * {
//  *	'D': 'Date.prototype',
//  *	'$N': 'Number'
//  * }
//  */
// var D = Date.prototype,
// $N = Number;
// 
// D.locale = function(){
// };
// 
// /**
// 	@return {string} The cardinal number string.
// */
// $N.nth = function(n){
// };
// 
// LOAD.file = function(){
// }
// 
// /**#=-*/