xmllint -dtdvalid /usr/share/kde4/apps/katepart/syntax/language.dtd ocaml.xml #> /dev/null

cp -i ocaml.xml ocaml--save$RANDOM.xml