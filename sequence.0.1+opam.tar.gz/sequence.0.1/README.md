Sequence
========

Simple sequence abstract datatype, intented to transfer a finite number of elements from one data structure to another.

Build
=====

You need OCaml, say OCaml 3.12 or OCaml 4.0.

    $ make

To see how to use it, check `tests.ml`. `sequence.ml` has a few examples of how to convert
data structures into sequences, and conversely.

License
=======

Sequence is available under the BSD license.
