type t = ..

type t +=
  | Bool of bool
  | Int of int
  | Float of float
  | String of string
  | Blob of bytes
