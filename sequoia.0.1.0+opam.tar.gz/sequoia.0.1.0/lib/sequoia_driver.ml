module type S = sig
  val placeholder : int -> string
end
