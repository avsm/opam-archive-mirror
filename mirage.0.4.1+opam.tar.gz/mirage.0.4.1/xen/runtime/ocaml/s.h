#define OCAML_OS_TYPE "xen"
#define OCAML_STDLIB_DIR "/usr/local/lib/ocaml"
#define POSIX_SIGNALS
//#define HAS_GETRUSAGE
#define HAS_TIMES
//#define HAS_SOCKETS
//#define HAS_SOCKLEN_T
//#define HAS_INET_ATON
//#define HAS_IPV6
//#define HAS_UNISTD
//#define HAS_OFF_T
//#define HAS_DIRENT
//#define HAS_REWINDDIR
//#define HAS_LOCKF
//#define HAS_MKFIFO
#define HAS_GETCWD
#define HAS_EXPM1_LOG1P
//#define HAS_GETWD
//#define HAS_GETPRIORITY
//#define HAS_UTIME
//#define HAS_UTIMES
//#define HAS_DUP2
//#define HAS_FCHMOD
//#define HAS_TRUNCATE
//#define HAS_SYS_SELECT_H
//#define HAS_SELECT
//#define HAS_SYMLINK
//#define HAS_WAITPID
//#define HAS_WAIT4
//#define HAS_GETGROUPS
//#define HAS_TERMIOS
//#define HAS_SETITIMER
//#define HAS_GETHOSTNAME
//#define HAS_UNAME
#define HAS_GETTIMEOFDAY
//#define HAS_MKTIME
//#define HAS_SETSID
//#define HAS_PUTENV
//#define HAS_LOCALE
//#define HAS_MMAP
//#define HAS_GETHOSTBYNAME_R 6
//#define HAS_GETHOSTBYADDR_R 8
//#define HAS_STACK_OVERFLOW_DETECTION
