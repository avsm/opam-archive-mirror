# clangml-transforms
Transformations from Clang AST to MemCAD AST.

This library is a dependency of the MemCAD abstract interpreter for shape analyzis.
