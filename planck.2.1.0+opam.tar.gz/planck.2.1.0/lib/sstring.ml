include Stream.Make(struct
  module Pos = Position.None
  module Attr = struct
    type t = Pos.t
    let position x = x
  end
  module Elem = struct
    type t = string
    let show = Printf.sprintf "%S"
    let format ppf = Format.fprintf ppf "%S"
    let equal (x : string) y = x = y
    let compare (x : string) y = compare x y
    let position _ = Position.None.none
  end
end)

let attr_default = ()

let the_null_desc = null_desc attr_default
let the_null = null attr_default

let from_string str = Lazy.lazy_from_val (cons_desc str attr_default the_null)

let from_chan ic =
  let len = 1024 in
  let rec read () = lazy begin
    let buf = String.create len in
    let read_bytes = input ic buf 0 len in
    if read_bytes = 0 then null_desc attr_default
    else
      let str = String.sub buf 0 read_bytes in
      cons_desc str attr_default (read ())
  end
  in
  read ()
