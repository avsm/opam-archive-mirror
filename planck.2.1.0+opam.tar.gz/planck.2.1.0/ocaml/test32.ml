let _ = v && w = g

