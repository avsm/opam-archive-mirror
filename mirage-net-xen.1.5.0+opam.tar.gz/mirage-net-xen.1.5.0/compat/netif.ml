include Netchannel.Frontend.Make(Netchannel.Xenstore.Make(OS.Xs))
