let package_name = "core_bench"

let sections =
  [ ("lib",
    [ ("built_lib_core_bench", None)
    ; ("built_lib_inline_benchmarks", None)
    ],
    [ ("META", None)
    ])
  ]
