# Change Log

## NEXT

## 0.1.1 (09 September 2016)
* Fix a bug with nested repetitions. Also avoid some copying of the original string.
* Add Tyre.execp

## 0.1 (11 August 2016)
First version :tada:
