#include <stdlib.h>
#define D(f) void f () { exit(1); }
D(caml_unwrap_value_from_string)
