# ocp-build

ocp-build is a build tool for OCaml.

ocp-build is part of TypeRex, developed and maintained by OCamlPro.
Documentation to install and use this tool is available on
[http://www.typerex.org/ocp-build.html](http://www.typerex.org/ocp-build.html)
