ocaml-mustache
==============

mustache.js logic-less templates in OCaml

Todo/Wish List
-----------
* Don't depend on re.str (not threadsafe)
* Inverted sections
* Support for ropes


http://mustache.github.io/
