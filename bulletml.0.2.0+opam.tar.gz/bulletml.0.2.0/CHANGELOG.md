## v0.2.0

*2016-07-04*

- install .cmt and .mli files (#45)
- remove dependency on SDL (#31)
- compile with debug info

## v0.1.0

*2016-05-22*

- initial release
