1.0.0 (01/12/2014):
* Initial public release.
