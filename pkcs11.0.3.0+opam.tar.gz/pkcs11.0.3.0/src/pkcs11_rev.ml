module Make(X:Pkcs11.RAW) = Pkcs11_rev_decl.Rev_bindings(X)(Pkcs11_rev_generated)
