v0.0.3
------

* Compile using `debug`to get backtraces.
* Improve ocamldoc.
* Do not shadow Result.t on older compilers to avoid warning.
* Add the `build` shell script into dev repo for convenience.

v0.0.2
------

* support OCaml version 4.02.3 in addition to 4.03.0

v0.0.1
------

* initial release of independent parse-argv library (previously in mirage-bootvar-xen, mirage-bootvar-solo5)
