# ocaml-libutp (WIP)

OCaml bindings for [`libutp`](https://github.com/bittorrent/libutp).

```
make
make install
```

## Usage

See [online docs](https://nojb.github.io/ocaml-libutp) and read through
[`bin/ucat.ml`](https://github.com/nojb/ocaml-libutp/blob/master/bin/ucat.ml).

When this is more stable I will add better usage docs.

## License

MIT.

## Contact

Nicolas Ojeda Bar (<n.oje.bar@gmail.com>)
