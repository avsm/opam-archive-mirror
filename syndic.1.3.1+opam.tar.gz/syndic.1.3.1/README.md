Syndic
======

RSS and Atom feed parsing

Documentation
=============

You can find it [here](http://cumulus.github.io/Syndic/doc).

Build Requirements
==================

 * OCaml >= 4.01.0
 * Calendar >= 2.03.2
 * Xmlm >= 1.2.0
 * Uri >= 1.3.1

[![Build Status](https://travis-ci.org/Cumulus/Syndic.svg?branch=master)](https://travis-ci.org/Cumulus/Syndic)
