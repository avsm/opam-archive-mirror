
module Rss1 = Syndic_rss1
module Rss2 = Syndic_rss2
module Atom = Syndic_atom
module Opml1 = Syndic_opml1

module Date = Syndic_date
module XML = Syndic_xml
