/* @flow */

function foo(x) {
  return x*10;
}

foo("Hello, world!");
