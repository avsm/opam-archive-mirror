/* @providesModule test-lib */

class C { }
module.exports = C;
