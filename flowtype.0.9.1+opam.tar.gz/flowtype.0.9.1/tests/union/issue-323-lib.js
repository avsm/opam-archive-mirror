/* @flow */
class Foo {}
module.exports = Foo;
