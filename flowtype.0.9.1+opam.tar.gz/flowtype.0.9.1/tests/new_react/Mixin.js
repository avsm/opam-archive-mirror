/* @providesModule Mixin */
module.exports = {
    success: function() { }
};
