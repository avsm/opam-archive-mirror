/**
 * @providesModule ES6_ExportAllFrom_Source2
 * @flow
 */

export var numberValue1 = 1;
