/**
 * @providesModule ES6Default
 * @flow
 */

/*
export default {
  numberValue: 42,
};
*/
