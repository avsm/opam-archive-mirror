vector3
=======

module for 3D vectors (implemented as records of x, y and z floats)
