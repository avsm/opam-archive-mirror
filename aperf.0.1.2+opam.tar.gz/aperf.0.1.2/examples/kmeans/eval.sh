#!/usr/bin/env zsh

./eval.native < kmeans.out
