#!/usr/bin/env sh

ocamlfind ocamlopt -o $2 $1
