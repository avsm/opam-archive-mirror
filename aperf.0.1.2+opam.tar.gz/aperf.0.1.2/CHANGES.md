v0.1.2 ____-
-------------------

- Expose aperf as a library
- Offer handles into approximation for array and list iter
- Run the program 10 times and take the average to get the running time


v0.1.1 2016-07-27
-----------------

Specify ocaml version as 4.03.0

v0.1 2016-07-26
---------------

Initial release.
