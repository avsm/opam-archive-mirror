function loop(num) {
  println(num);
  if (num > 0) {
    loop(num - 1);
  }
}
loop(10);

function fact(num) {
  if (num === 0) {
    return 1;
  } else {
    return fact(num - 1) * num;
  }
}
println(fact(5));

function fibonacci(num) {
  if (num === 0) {
    return 0;
  } else if (num === 1) {
    return 1;
  } else {
    return fibonacci(num - 2) + fibonacci(num - 1);
  }
}

i = 0;
while (i < 7) {
  println(fibonacci(i));
  i = i + 1;
}
