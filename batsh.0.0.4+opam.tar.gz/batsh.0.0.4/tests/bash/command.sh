"echo" "-e" "Println Called"
cmd="ec""ho"
$cmd "Echo Called"
"echo" "-e" $("expr" $((36)) "+" $((6)))
