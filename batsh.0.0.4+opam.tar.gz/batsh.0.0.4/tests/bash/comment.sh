a=$((3))
# This is comment 1
a=$(($a * 5))
# This is comment 2
"echo" "-e" $a
#This is comment 3
