"echo" "-e" "BYVoid"
"echo" "-e" "Slash/"
"echo" "-e" "Backslash\\"
"echo" "-e" "Quote\"'"
"echo" "-e" "Tab	Tab"
#println("Newline\nLine2");
#println("!");
"echo" "-e" "http://""www.""byvoid"".com"
"echo" "-e" $((6 / 2))"BYVoid"$((3 + 5))
_0="3"
"echo" "-e" $((3 + $_0))
_1="3"
"echo" "-e" $((3 + $_1))"2"
_2="3""2"
"echo" "-e" $((3 + $_2))
[ "BYVoid" == "BYVoid" ]
_3=$((!$?))
"echo" "-e" $_3
