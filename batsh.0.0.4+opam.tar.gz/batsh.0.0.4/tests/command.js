call("println", "Println Called");
cmd = "ec" ++ "ho";
call(cmd, "Echo Called");
println(expr(36, "+", 6));
