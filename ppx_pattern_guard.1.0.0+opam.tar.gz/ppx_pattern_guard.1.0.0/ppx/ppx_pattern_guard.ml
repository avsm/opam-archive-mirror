open Ast_mapper

let extend super =
  let expr self e = super.expr self @@ Desugar_pattern_guard.desugar_expr e in 
  { super with expr }

let mapper = extend default_mapper

let () = Ppxx.run "ppx_pattern_guard" mapper
