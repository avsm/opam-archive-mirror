let ocaml_version = "3.13.0"
let ast_impl_magic_number = "Caml1999M014"
let ast_intf_magic_number = "Caml1999N013"
