print_string [%netblob "https://goo.gl/nTD9Oc"]
