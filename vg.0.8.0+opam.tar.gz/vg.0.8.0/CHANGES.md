v0.8.0 2013-09-24 Lausanne
--------------------------

First release.   
Sponsored by Citrix Systems R&D and OCaml Labs.
