/* @flow */

exports.num = 42;
