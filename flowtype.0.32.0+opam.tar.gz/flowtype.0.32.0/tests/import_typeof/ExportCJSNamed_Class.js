/**
 * @flow
 */

class ClassFoo4 {}

exports.ClassFoo4 = ClassFoo4;
