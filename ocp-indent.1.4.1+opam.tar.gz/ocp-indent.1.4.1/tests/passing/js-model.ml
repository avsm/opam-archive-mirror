
val f
  :  int
  -> int

type t =
  | A
  | B

let height = function
  | A -> 0
  | B -> 1

let _ =
  if x then begin
    y
  end else if x then
    y
  else z

let _ =
  if x then y else
  if x then y else
    x

type t
  =  int
  -> int
