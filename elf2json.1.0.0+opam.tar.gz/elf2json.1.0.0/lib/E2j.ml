module Header = E2j_ElfHeader
module ProgramHeader = E2j_ElfProgramHeader
module SectionHeader = E2j_ElfSectionHeader
module SymbolTable = E2j_ElfSymbolTable
module Dynamic = E2j_ElfDynamic
module Reloc = E2j_ElfReloc
module Coverage = E2j_ByteCoverage
module Json = E2j_Json
