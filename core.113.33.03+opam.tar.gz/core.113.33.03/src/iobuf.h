/* WHEN YOU CHANGE THIS, CHANGE T.t IN iobuf.ml AS WELL!!! */
enum iobuf_fields { iobuf_buf, iobuf_lo_min, iobuf_lo, iobuf_hi, iobuf_hi_max };
