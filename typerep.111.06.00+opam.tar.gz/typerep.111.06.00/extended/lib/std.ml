module Flat_map          = Flat_map
module Pre_core          = Pre_core
module Tagged            = Tagged
module Type_struct       = Type_struct
module Typestructable    = Typestructable
module Tagged_generic    = Tagged_generic
include Typerep_lib.Std
