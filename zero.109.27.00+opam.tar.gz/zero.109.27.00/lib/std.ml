module Flat_tuple_array = Flat_tuple_array
module Pool             = Pool
module Pooled_hashtbl   = Pooled_hashtbl
module Timing_wheel     = Timing_wheel

let _make_sure_pool_pointer_is_an_int x = (x : _ Pool.Obj_array.Pointer.t :> int)
