(* OASIS_START *)
(* DO NOT EDIT (digest: 1e1d8e08e9e7f7535a69899543c23cb0) *)
This is the README file for the frag distribution.

File fragment extraction

A tool to extract fragments from a file.

See the files INSTALL.txt for building and installation instructions. 

Home page: https://github.com/pw374/frag


(* OASIS_STOP *)
