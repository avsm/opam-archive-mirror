let package_name = "textutils"

let sections =
  [ ("lib",
    [ ("built_lib_textutils", None)
    ],
    [ ("META", None)
    ])
  ]
