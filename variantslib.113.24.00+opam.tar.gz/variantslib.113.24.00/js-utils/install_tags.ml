let package_name = "variantslib"

let sections =
  [ ("lib",
    [ ("built_lib_variantslib", None)
    ],
    [ ("META", None)
    ])
  ]
