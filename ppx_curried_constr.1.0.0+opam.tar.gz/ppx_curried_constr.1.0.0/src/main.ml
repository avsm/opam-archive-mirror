open Utils
open Ast_mapper

(* Pre-conversion. If you need some PPX before typing. *)

let preconvert_structure x = x
let preconvert_signature x = x

(* The PPX mapper *)
  
let mapper = match Ast_mapper.tool_name () with
  | "ocamldep" ->
      (* If the tool is ocamldep, we do not type-check *)
      (* Note that for very complex typeful ppx, this is not the case *)
      default_mapper
  | _ ->
      let structure _x str =
        Clflags.dont_write_files := true;
        Warnings.parse_options false "a"; (* print warning *)
        Warnings.parse_options true  "a"; (* warning as error *)
        Compile.implementation
          Format.err_formatter
          "papa" (* dummy *)
          (preconvert_structure str)
          "gaga" (* dummy *)
      in
      let signature _x sg =
        Clflags.dont_write_files := true;
        Warnings.parse_options false "a"; (* print warning *)
        Warnings.parse_options true  "a"; (* warning as error *)
        Compile.interface
          Format.err_formatter
          "papa" (* dummy *)
          (preconvert_signature sg)
          "gaga" (* dummy *)
      in
      { default_mapper with structure; signature }

let handle_error f =
  try f () with
  | Syntaxerr.Error e ->
      !!% "%a@." Syntaxerr.report_error e;
      exit 2
  | e ->
      Format.eprintf "%a@."  Location.report_exception e;
      exit 2

let tool_name = "ppx_curried_constr"

let impl mapper fname =
  handle_error & fun () ->
    let str = Pparse.parse_implementation ~tool_name Format.err_formatter fname in
    let str = mapper.structure mapper str in
    Pprintast.structure Format.std_formatter str;
    Format.fprintf Format.std_formatter "@."

let intf mapper fname =
  handle_error & fun () ->
    let sg = Pparse.parse_interface ~tool_name Format.err_formatter fname in
    let sg = mapper.signature mapper sg in
    Pprintast.signature Format.std_formatter sg;
    Format.fprintf Format.std_formatter "@."

let anonymous mapper fname =
  if Filename.check_suffix fname ".ml" then impl mapper fname (* .mlt ? *)
  else if Filename.check_suffix fname ".mli" then intf mapper fname
  else assert false

(* Options *)
    
let debug_pre = ref false
let debug_resolve = ref false
let debug_unif = ref false

let option_list =
  let module Options = Compilerlib.BytecompOptions(struct
    let impl = impl mapper
    let intf = intf mapper
    let anonymous = anonymous mapper
  end) in
  let inappropriate =
    [ "-a"
    ; "-c"
    ; "-cc"
    ; "-cclib"
    ; "-ccopt"
    ; "-compat-32"
    ; "-custom"
    ; "-dllib"
    ; "-dllpath"
    ; "-for-pack"
    ; "-g"
    (* ; "-i" *)
    ; "-linkall"
    ; "-make-runtime"
    ; "-make_runtime"
    ; "-noassert"
    ; "-noautolink"
    ; "-o"
    ; "-output-obj"
    ; "-pack"
    ; "-pp"
    ; "-ppx"
    ; "-runtime-variant"
    ; "-use-runtime"
    ; "-use_runtime"
    ; "-where"
    ; "-"
    ; "-nopervasives"
    ; "-use-prims"
    ; "-drawlambda"
    ; "-dlambda"
    ; "-dinstr"
    ]
  in

  List.filter (fun (n,_,_) ->
    not & List.mem n inappropriate) Options.list

let run name mapper =
  let debug = ref false in
  let rev_files = ref [] in
  Arg.parse
    ([ "-debug", Arg.Set debug, "debug mode which can take .ml/.mli then print the result"
     ; "-debug-pre", Arg.Set debug_pre, "debug pre-preprocessing"
     ; "-debug-resolve", Arg.Set debug_resolve, "debug mode to print overload resolution"
     ; "-debug-unif", Arg.Set debug_unif, "debug mode to print unification results"
     ] @ option_list)
    (fun s -> rev_files := s :: !rev_files) (* will be handled by [Ast_mapper.apply] *)
    name;
  try
    match !debug, List.rev !rev_files with
    | true, files ->
        List.iter (anonymous mapper) files
    | false, [infile; outfile] ->
        Ast_mapper.apply ~source:infile ~target:outfile mapper
    | _ ->
        failwith & name ^ " infile outfile"
  with
  | Location.Error e -> Location.report_error Format.err_formatter e


let () = run "ppx_curried_constr" mapper
