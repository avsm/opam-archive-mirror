(* OASIS_START *)
(* DO NOT EDIT (digest: c8653772272fe46f095f741fabef65b2) *)
This is the README file for the mpp distribution.

A preprocessor meant to blend languages.

MPP is a meta processor that is meant to bring any programming language to
the preprocessing level. You can easily use OCaml as a preprocessor language
for any text-based document. If you want to use another language, you just
need to tell MPP how to use it. MPP also works as a simple preprocessor, as
it provides its own (tiny) language.

See the files INSTALL.txt for building and installation instructions. 

Home page: https://github.com/pw374/MPP-language-blender


(* OASIS_STOP *)
