#!/bin/bash -eux
eval `opam config env`
make
