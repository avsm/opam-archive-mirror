0.2.0 / 2014-11-14
==================

  * Removed dependency on Core (now Core\_kernel).
  * Package name change: Tumblr -> Sociaml\_tumblr\_api.
  * Licence change to GPL-V3.

0.1.0 / 2014-06-18
==================

  * Initial commit, the complete (documented) Tumblr API is supported.