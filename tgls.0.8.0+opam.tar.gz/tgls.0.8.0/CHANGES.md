v0.8.0 2014-05-18 La Forclaz (VS)
---------------------------------

First release.
