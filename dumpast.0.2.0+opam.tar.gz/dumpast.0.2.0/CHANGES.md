## 0.2.0
* Support for 4.02
* Safer serialization

## 0.1.0
* Inital release