Changelog
=========

0.2
---

  * Add `[@key]`, `[@name]` and `[@default]` attributes.
  * Add support for `Yojson.Safe.json` values.

0.1
---

  * Initial release.
