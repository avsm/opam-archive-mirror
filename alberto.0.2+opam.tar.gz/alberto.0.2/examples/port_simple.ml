(** A simple echo-server example. *)

let () = Alberto.interact (fun x -> x)
