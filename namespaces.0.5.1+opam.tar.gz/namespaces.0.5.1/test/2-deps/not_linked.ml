let () =
  Printf.printf "%i\n" Namespace.Nested.Bar.v
