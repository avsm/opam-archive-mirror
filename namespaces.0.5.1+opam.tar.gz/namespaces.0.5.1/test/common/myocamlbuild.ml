let () = Ocamlbuild_plugin.dispatch Namespaces.handler
