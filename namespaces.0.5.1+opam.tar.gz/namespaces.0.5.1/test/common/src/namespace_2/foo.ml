let v = Namespace.Nested.Foo.v + 2
