let v = Namespace.Nested.Bar.v + 2
