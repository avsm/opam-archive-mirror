let () =
  print_endline "This module should not have been linked in";
  exit 1

let v = -1
