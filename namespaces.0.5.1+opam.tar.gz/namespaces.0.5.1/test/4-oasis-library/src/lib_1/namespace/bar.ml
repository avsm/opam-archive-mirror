let () =
  print_endline "This module should not have been linked in"
