let () =
  Printf.printf "%i\n" Namespace.Nested.Bar.v

let () =
  Printf.printf "%i\n" Foo.v

let () =
  Printf.printf "%i\n" Namespace.Nested.Foo.v

let () =
  Printf.printf "%i\n" Namespace_2.Foo.v
