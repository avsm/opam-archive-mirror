module ExtString = Decompress_common.ExtString
module ExtBytes  = Decompress_common.ExtBytes

module Inflate = Decompress_inflate
module Deflate = Decompress_deflate
