Decompress
==========

Pur OCaml implementation of Zlib

Documentation
=============

You can find it [here](http://oklm-wsh.github.io/Decompress/).

Build Requirements
==================

 * OCaml >= 4.02.0

[![Build Status](https://travis-ci.org/oklm-wsh/Decompress.svg)](https://travis-ci.org/oklm-wsh/Decompress)
