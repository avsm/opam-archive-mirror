include Bindings.Stubs(Decompress_bindings)
