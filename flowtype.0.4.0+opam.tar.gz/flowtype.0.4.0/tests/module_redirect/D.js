/**
 * @providesModule D
 * @flow
 */

var bar1: string = require('A');
var bar2: string = require('B');
var bar3: string = require('C');
