function foo() {
    return;
    var x = 1;
}
