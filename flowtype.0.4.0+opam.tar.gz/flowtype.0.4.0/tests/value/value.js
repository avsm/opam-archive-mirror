var o = {};
o["x"] = 4;
var y:string = o["x"];

var table: { [_: string]: number } = {};
table["x"] = "hello";
