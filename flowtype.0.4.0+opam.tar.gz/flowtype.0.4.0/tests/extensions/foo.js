var imp = require('./bar');
imp(1337);
