
var f = require('./Abs');

f(0);
