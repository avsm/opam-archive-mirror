
function f(x:string) { }

module.exports = f;
