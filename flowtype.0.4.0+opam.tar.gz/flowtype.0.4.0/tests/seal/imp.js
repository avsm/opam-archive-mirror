/* @flow */

var imp = require('./obj_annot');
imp({ name: "imp" });
