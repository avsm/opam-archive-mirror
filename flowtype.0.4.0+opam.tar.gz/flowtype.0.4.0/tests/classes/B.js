var A = require('./A');

class B extends A { }

module.exports = B;
