(* Automatically generated file - don't edit!  See the Makefile.  *)
Sundials_top.install_printers [
 "Nvector_parallel.pp";
];;
