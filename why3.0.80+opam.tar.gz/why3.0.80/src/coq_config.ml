(********************************************************************)
(*                                                                  *)
(*  The Why3 Verification Platform   /   The Why3 Development Team  *)
(*  Copyright 2010-2012   --   INRIA - CNRS - Paris-Sud University  *)
(*                                                                  *)
(*  This software is distributed under the terms of the GNU Lesser  *)
(*  General Public License version 2.1, with the special exception  *)
(*  on linking described in file LICENSE.                           *)
(*                                                                  *)
(********************************************************************)

let realized_theories = [
  ["int"; "Abs"];
  ["int"; "ComputerDivision"];
  ["int"; "EuclideanDivision"];
  ["int"; "Int"];
  ["int"; "MinMax"];
  ["real"; "Abs"];
  ["real"; "FromInt"];
  ["real"; "MinMax"];
  ["real"; "Real"];
  ["real"; "Square"];
  ["floating_point"; "Rounding"];
  ["floating_point"; "Single"];
  ["floating_point"; "Double"];
]
