#!/bin/sh

cd /src
opam pin add mirage-xen . -y
