let () = LOG "msg" NAME 0 LEVEL DEBUG
