## v0.0.2 2016-10-27

Fix the wrong dependencies in META.

## v0.0.1 2016-10-26

First release. 
