* Provide per-CPU discovery?
* Widen discovery to other CPUID-leaves (power management, &c)?
* Generalize beyond CPUID (ARM)?
