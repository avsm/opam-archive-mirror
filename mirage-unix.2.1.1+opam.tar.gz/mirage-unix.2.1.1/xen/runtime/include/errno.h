#include_next <errno.h>

extern int errno;
