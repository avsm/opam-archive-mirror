/*	$NetBSD: math.h,v 1.3 2005/12/11 12:16:25 christos Exp $	*/

#include <x86/math.h>
