include String
let sub_string = sub
let of_string = copy
let blit_string = blit

let unsafe_to_string s = s
let to_string = copy
let cat b1 b2 = b1 ^ b2

