(* OASIS_START *)
(* DO NOT EDIT (digest: b01141a7828db3a04adc42a7efa4df8b) *)

deriving-yojson - Parse/convert ocaml value from/to yojson ast
==============================================================

See the file [INSTALL.txt](INSTALL.txt) for building and installation
instructions.

[Home page](https://github.com/hhugo/deriving-yojson)

Copyright and license
---------------------

deriving-yojson is distributed under the terms of the GNU Lesser General
Public License version 2.1 with OCaml linking exception.

(* OASIS_STOP *)
