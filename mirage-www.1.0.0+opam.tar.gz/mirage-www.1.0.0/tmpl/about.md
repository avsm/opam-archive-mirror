### Core Team

One of us will review every patch that goes into the main distribution.  Get in
touch with any of us individually if you're interested in a Mirage-related internship
at our respective institutions.

* **[Anil Madhavapeddy](http://anil.recoil.org)**, University of Cambridge
* **[David Scott](http://dave.recoil.org)**, Citrix Systems R&D
* **[Thomas Gazagnaire](http://thomas.gazagnaire.org)**, University of Cambridge
* **[Richard Mortier](http://www.cs.nott.ac.uk/~rmm/)**, University of Nottingham
