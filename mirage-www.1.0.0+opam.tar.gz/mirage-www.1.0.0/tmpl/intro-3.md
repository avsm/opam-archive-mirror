Mirage 1.0 is [being released through December 2013](http://openmirage.org/blog/announcing-mirage10),
and the infrastructure you see here is [self-hosted](https://github.com/mirage/mirage-www).
Check out the [documentation](/wiki), compile your [hello world
microkernel](/wiki/hello-world), get started with the [public cloud](/wiki/xen-boot), or watch the [talks](/wiki/talks).
