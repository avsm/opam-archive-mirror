Mirage uses the [OCaml](http://ocaml.org/) language, with libraries that
provide networking, storage and concurrency support that work under Unix during
development, but become operating system drivers when being compiled for
production deployment. The framework is fully event-driven, with no support for
preemptive threading.
