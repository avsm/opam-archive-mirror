# Mirage Website

This repository contains the Mirage public website, <http://openmirage.org/>.

It provides information about the project as well as the blog and wiki.

It also serves as a good first self-hosting test case.
