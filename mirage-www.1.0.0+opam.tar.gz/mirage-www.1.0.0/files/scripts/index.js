$(document).ready(function() {
	
	// Image Slider Script
	
	$("#featured_imgs").easySlider({
		continuous: false,
		auto: false,
		speed: 400,
		pause: 2500,
		prevText: ' ',
		nextText: ' ',
                numeric: true,
	});

});
