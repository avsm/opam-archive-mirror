class C {
    foo() { }
    bar() { return; }
    fn(x:number) { return x; }
}

module.exports = C;

//function fn(x:number) { return x; }
//module.exports = fn;
