declare module A {
  declare function foo(): string;
}
