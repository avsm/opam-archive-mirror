declare class C { x: number; }

var x: string = new C().x;
