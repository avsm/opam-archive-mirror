var M = require('M');
var N = require('N');
N.x = M(N.x);
