/**
 * @flow
 */

function foo(x: ?number): boolean {
    try {
    } catch (e) {
        return false;
    }
    console.log();
    return true;
}
