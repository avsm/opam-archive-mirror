/**
 * @providesModule ArityError.react
 */
var React = require('react');
var AudienceInsightsContainer = React.createClass({
  renderComponent(AudienceInsights: ReactClass): any {
    return <AudienceInsights />;
  },
});

module.exports = AudienceInsightsContainer;
