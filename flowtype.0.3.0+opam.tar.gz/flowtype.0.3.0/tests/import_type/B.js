/**
 * @flow
 */

class Foo {
}

class Bar {
}

module.exports = {
  Foo: Foo,
  Bar: Bar
};
