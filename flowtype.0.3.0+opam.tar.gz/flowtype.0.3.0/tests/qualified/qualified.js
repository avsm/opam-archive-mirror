class C { }
var M = { C: C };

var x:M.C = 0;
