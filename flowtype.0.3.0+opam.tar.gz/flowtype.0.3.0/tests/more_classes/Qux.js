
/* @providesModule Qux */

class Qux {
  w:number;

  qux() { return this.w; }

  fooqux(x:number) { }
}

module.exports = Qux;
