foo(123);
bar(123);
