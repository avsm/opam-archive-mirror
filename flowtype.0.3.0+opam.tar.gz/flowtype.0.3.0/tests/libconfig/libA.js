declare function foo(x: number): void;
