declare function bar(x: string): void;
