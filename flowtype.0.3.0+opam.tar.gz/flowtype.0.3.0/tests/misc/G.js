var a = { length: "duck" };
a.length = 123;
a.length();

var b = [ 123 ];
b.length = "duck";
b.length();
