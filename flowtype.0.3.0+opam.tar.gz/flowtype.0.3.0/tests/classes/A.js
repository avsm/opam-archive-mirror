class A {
  foo(x:number):void { }
}

module.exports = A;
