/*
@providesModule Window1
*/
module.exports = window.history;
