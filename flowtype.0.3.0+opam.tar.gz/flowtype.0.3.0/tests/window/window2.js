/* @providesModule Window2 */

module.exports = window.parent;
