var a: [] = [];
var b: [] = [123];
var c: [number] = [];
var d: [number, string] = [123,'duck'];
var e: [number, string,] = [123,'duck'];
var f: [number, string] = [123, 456];
