(**
 * Copyright (c) 2014, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the "hack" directory of this source tree. An additional grant
 * of patent rights can be found in the PATENTS file in the same directory.
 *
 *)

let identify content line char =
  let result = ref None in
  IdentifySymbolService.attach_hooks result line char;
  let funs, classes = ServerIdeUtils.declare Relative_path.default content in
  ServerIdeUtils.fix_file_and_def Relative_path.default content;
  ServerIdeUtils.revive funs classes;
  IdentifySymbolService.detach_hooks ();
  match !result with
  | Some result -> Utils.strip_ns result.IdentifySymbolService.name
  | _ -> ""

let go content line char oc =
  let result = identify content line char in
  Printf.fprintf oc "%s\n" result; flush oc
