(* Copyright (c) 2014-2016 David Kaloper Meršinjak. All rights reserved.
   See LICENSE.md. *)

open OUnit2

let () = run_test_tt_main Testlib.suite


