let package_name = "ppx_enumerate"

let sections =
  [ ("lib",
    [ ("built_lib_ppx_enumerate", None)
    ],
    [ ("META", None)
    ])
  ]
