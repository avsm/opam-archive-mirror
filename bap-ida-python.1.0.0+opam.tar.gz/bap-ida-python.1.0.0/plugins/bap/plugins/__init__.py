"""This module contains all the plugins that will be loaded by BAP-Loader."""

__all__ = ('bap_bir_attr', 'bap_taint', 'bap_view', 'pseudocode_bap_comment',
           'pseudocode_bap_taint')
