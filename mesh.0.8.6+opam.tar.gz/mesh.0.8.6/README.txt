(* OASIS_START *)
(* DO NOT EDIT (digest: a935f9aae4a0f40df6f2ae3a16943abe) *)

mesh - Triangular mesh generation and manipulation.
===================================================

This is an interface to various mesh generators, in particular triangle.  It
also provides functions to optimize the numbering of mesh points and to
export meshes and piecewise linear functions defined on them to TikZ, Scilab,
Matlab, and Mathematica formats.

See the file [INSTALL.txt](INSTALL.txt) for building and installation
instructions.

[Home page](https://github.com/Chris00/mesh)

Copyright and license
---------------------

mesh is distributed under the terms of the GNU Lesser General Public License
version 2.0 with OCaml linking exception.

(* OASIS_STOP *)
