0.2 (2016-05-06)
- Enable build on OCaml 3.12.1
- `Win_error.error_message` now behaves differently depending on
  `Sys.os_type`

0.1 (2016-05-05)
- Initial release
