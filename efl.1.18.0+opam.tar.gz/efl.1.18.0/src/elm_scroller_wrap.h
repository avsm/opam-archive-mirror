#ifndef ELM_SCROLLER_H
#define ELM_SCROLLER_H

#include "include.h"

 Elm_Scroller_Movement_Block Elm_Scroller_Movement_Block_val_list(
        value v_list);
 value copy_Elm_Scroller_Movement_Block(Elm_Scroller_Movement_Block m);

#endif
