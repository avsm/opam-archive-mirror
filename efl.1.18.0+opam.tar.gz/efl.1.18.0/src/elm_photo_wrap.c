#include "include.h"

PREFIX value ml_elm_photo_add(value v_parent)
{
        Evas_Object* obj = elm_photo_add(Evas_Object_val(v_parent));
        if(obj == NULL) caml_failwith("elm_photo_add");
        return copy_Evas_Object(obj);
}

PREFIX value ml_elm_photo_file_set_null(value v_obj)
{
        return Val_bool(elm_photo_file_set(Evas_Object_val(v_obj), NULL));
}

PREFIX value ml_elm_photo_thumb_set(
        value v_obj, value v_file, value v_group, value v_unit CAMLunused)
{
        const char* group;
        if(v_group == Val_int(0)) group = NULL;
        else group = String_val(Field(v_group, 0));
        elm_photo_thumb_set(Evas_Object_val(v_obj), String_val(v_file), group);
        return Val_unit;
}

PREFIX value ml_elm_photo_thumb_set_null(
        value v_obj, value v_group, value v_unit CAMLunused)
{
        const char* group;
        if(v_group == Val_int(0)) group = NULL;
        else group = String_val(Field(v_group, 0));
        elm_photo_thumb_set(Evas_Object_val(v_obj), NULL, group);
        return Val_unit;
}

