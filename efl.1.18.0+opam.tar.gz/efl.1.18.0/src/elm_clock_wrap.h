#include "include.h"

 Elm_Clock_Edit_Mode Elm_Clock_Edit_Mode_val_list(value v);

 value copy_Elm_Clock_Edit_Mode(Elm_Clock_Edit_Mode m);

