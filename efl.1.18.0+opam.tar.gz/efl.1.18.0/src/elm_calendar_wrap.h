#include "include.h"

 Elm_Calendar_Selectable Elm_Calendar_Selectable_val_list(value v);
 value copy_Elm_Calendar_Selectable(Elm_Calendar_Selectable s);

