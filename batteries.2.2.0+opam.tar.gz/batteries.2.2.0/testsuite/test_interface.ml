
(*module X1 : module type of Arg = BatArg REMOVE BATARG?  REIMPLEMENT?*)
module X15 : module type of List = BatList
(*
module X2 : module type of Array = BatArray
module X3 : module type of Bigarray = BatBigarray
module X4 : module type of Big_int = BatBig_int
 *)
(* module X5 : module type of Buffer = BatBuffer FAIL - channel -> input *)
module X6 : module type of Complex = BatComplex
(*
module X7 : module type of Digest = BatDigest
module X8 : module type of Format = BatFormat
 *)
(* module X9 : module type of Gc = BatGc FAIL channel -> output *)
(*
module X10 : module type of Genlex = BatGenlex
 *)
(* module X11 : module type of Hashtbl = BatHashtbl FAIL missing fields?*)
module X12 : module type of Int32 = BatInt32
module X13 : module type of Int64 = BatInt64
(*
module X14 : module type of Lexing = BatLexing
 *)
(* module X16 : module type of Map = BatMap FAIL - missing fields? *)
(*
module X17 : module type of Marshal = BatMarshal
 *)
module X18 : module type of Nativeint = BatNativeint
(*
module X19 : module type of Num = BatNum
module X20 : module type of Oo = BatOo
(* PERVASIVES? *)
module X21 : module type of Printexc = BatPrintexc
module X22 : module type of Printf = BatPrintf
module X23 : module type of Queue = BatQueue
 *)
module X24 : module type of Random = BatRandom
(*
module X25 : module type of Scanf = BatScanf
 *)
(* module X26 : module type of Set = BatSet FAIL - missing fields? *)
(*
module X27 : module type of Stack = BatStack
module X28 : module type of Stream = BatStream
module X29 : module type of String = BatString
module X30 : module type of Str = BatStr
module X31 : module type of Sys = BatSys
(* UNIX? *)
 *)
