let package_name = "async_extra"

let sections =
  [ ("lib",
    [ ("built_lib_async_extra", None)
    ],
    [ ("META", None)
    ])
  ]
