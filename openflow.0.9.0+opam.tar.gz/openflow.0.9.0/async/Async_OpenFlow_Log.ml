open Core.Std
open Async.Std

module Log = Log.Make_global ()
include Log