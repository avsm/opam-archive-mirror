type t = unit

let empty = ()

let union _ _ = ()

let print fmt _ =
  Format.fprintf fmt "[no explanations for this example]"
