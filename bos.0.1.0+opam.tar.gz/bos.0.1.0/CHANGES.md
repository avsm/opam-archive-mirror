v0.1.0 2016-05-23 La Forclaz (VS)
---------------------------------

First release.
