if test -e "ROOT/OPAM/envuser/pre-artifact-copy"; then
  ROOT/OPAM/envuser/pre-artifact-copy
fi
