let vo2s = function
  | None -> "None"
  | Some v -> Printf.sprintf "Some %s" v
