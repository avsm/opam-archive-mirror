external set_size_unsafe : string -> int -> unit = "Caml_set_size_unsafe"
external size_from_unsafe: string -> int -> int  = "Caml_size_from_unsafe"
