// empty compound-statement expression

// originally found in package opencdk

// error: `({ ... })' cannot be empty

int main() {
    ({});
}
