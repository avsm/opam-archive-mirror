@interface WeakClass1 @end

@implementation WeakClass1(Categ1) @end
