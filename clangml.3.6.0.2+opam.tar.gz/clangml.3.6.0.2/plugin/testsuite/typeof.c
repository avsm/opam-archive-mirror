void foo(void);


__typeof(foo) afun;  
void afun(void) {}
