let _ = Cpdfcommand.go ()
