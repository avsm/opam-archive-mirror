open TestGettext;;
open Printf;;

let () = 
  eprintf (f_ "%ld") 2
;;
