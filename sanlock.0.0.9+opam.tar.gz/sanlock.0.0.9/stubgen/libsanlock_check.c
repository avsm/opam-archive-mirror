#include <sanlock_rv.h>

int main() { return SANLK_NONE; }
