ocaml-sanlock
=============

[![Build Status](https://travis-ci.org/simonjbeaumont/ocaml-sanlock.svg?branch=master)](https://travis-ci.org/simonjbeaumont/ocaml-sanlock)
[![Coverage Status](https://coveralls.io/repos/simonjbeaumont/ocaml-sanlock/badge.svg?branch=master)](https://coveralls.io/r/simonjbeaumont/ocaml-sanlock?branch=master)

An OCaml library exposing an API over bindings to `sanlock`[1].

[1]: https://fedorahosted.org/sanlock/
