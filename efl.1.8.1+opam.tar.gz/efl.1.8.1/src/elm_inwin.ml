external add : Evas.obj -> Evas.obj = "ml_elm_win_inwin_add"

external activate : Evas.obj -> unit = "ml_elm_win_inwin_activate"

external content_set : Evas.obj -> Evas.obj -> unit =
  "ml_elm_win_inwin_content_set"
  
external content_get : Evas.obj -> Evas.obj = "ml_elm_win_inwin_content_get"

external content_unset : Evas.obj -> Evas.obj = "ml_elm_win_inwin_content_unset"

