#ifndef ELM_SCROLLER_H
#define ELM_SCROLLER_H

#include "include.h"

PREFIX inline Elm_Scroller_Policy Elm_Scroller_Policy_val(value v);
PREFIX inline value Val_Elm_Scroller_Policy(Elm_Scroller_Policy p);

#endif
