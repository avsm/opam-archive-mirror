#ifndef ELM_LIST_H
#define ELM_LIST_H

#include "include.h"

PREFIX inline Elm_List_Mode Elm_List_Mode_val(value v);
PREFIX inline value Val_Elm_List_Mode(Elm_List_Mode m);

#endif
