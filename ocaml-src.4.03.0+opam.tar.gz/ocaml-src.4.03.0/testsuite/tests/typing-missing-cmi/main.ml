let _ = A.a = B.b
