type a = int
type b = a
