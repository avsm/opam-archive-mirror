 type _ t =
     X of string
   | Y : bytes t

let y : string t = Y
