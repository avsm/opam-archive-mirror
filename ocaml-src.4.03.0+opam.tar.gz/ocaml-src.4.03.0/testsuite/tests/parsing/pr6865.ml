let%foo x = 42
let%foo _ = () and _ = ()
let%foo _ = ()
