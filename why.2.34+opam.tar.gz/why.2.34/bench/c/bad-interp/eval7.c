void f (){
  int x = 1000000000000000llu;
}
