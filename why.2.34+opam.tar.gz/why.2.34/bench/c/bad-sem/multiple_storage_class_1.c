extern static int x;
