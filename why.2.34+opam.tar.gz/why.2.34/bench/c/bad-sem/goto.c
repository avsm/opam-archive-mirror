

int f() {
  goto l;
}
