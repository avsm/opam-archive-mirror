struct S { int x; };
struct S { doubld f; };
