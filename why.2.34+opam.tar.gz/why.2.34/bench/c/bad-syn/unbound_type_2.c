
struct { t x; } y;

