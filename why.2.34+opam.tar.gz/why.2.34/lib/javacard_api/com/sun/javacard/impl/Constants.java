
package com.sun.javacard.impl;


public interface Constants {

  public static final short APDU_BUFFER_LENGTH;

}