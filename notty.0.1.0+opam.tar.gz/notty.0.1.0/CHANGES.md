0.1.0 (2016-02-09):
* Initial release
