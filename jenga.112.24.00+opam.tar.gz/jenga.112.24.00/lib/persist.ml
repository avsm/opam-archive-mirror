
open Core.Std
open No_polymorphic_compare let _ = _squelch_unused_module_warning_
open Async.Std

module Digest = Db.Digest

let saves_done = Effort.Counter.create "db-save"

let jenga_show_persist =
  match Core.Std.Sys.getenv "JENGA_SHOW_PERSIST" with
  | None -> false
  | Some _ -> true

let trace = Message.(if jenga_show_persist then message else trace)
let trace fmt = ksprintf (fun s -> trace "Persist: %s" s) fmt

let time_async f =
  let start_time = Time.now() in
  f () >>= fun res ->
  let duration = Time.diff (Time.now()) start_time in
  return (res,duration)

(* avoid saving persistent db unless it has been modified *)
let r_is_modified = ref false
let is_modified () = !r_is_modified
let set_is_saved () = r_is_modified := false
let modify who x =
  if !r_is_modified
  then x
  else (trace "setting MODIFIED flag, for: %s" who; r_is_modified := true ; x)

module Quality = struct
  type t = [`initial | `format_changed | `good] with sexp_of
  let to_string t = Sexp.to_string (sexp_of_t t)
end

module State : sig

  type t with bin_io
  val snapshot : Db.t -> t
  val value : t -> Db.t

end = struct

  type t = Db.t Digest.With_store.t Path.With_store.t
  with bin_io

  let snapshot db =
    let x = db in
    let x = Digest.With_store.snapshot x in
    let x = Path.With_store.snapshot x in
    x

  let value t =
    let x = t in
    let x = Path.With_store.value x in
    let x = Digest.With_store.value x in
    x

end

module Ops : sig

  val load_db_with_quality : db_filename:string -> (Db.t * Quality.t) Deferred.t
  val save_db : Db.t -> db_filename:string -> unit Deferred.t

end = struct

  let max_len = 800 * 1024 * 1024 (* default 100Mb is too small *)

  let load_db_with_quality ~db_filename =
    Sys.file_exists db_filename >>= function
    | `No | `Unknown ->
      trace "load: %s: does not exist" db_filename;
      return (Db.create(), `initial)
    | `Yes ->
    try_with (fun () ->
      Reader.with_file db_filename ~f:(fun r ->
        Reader.read_bin_prot ~max_len r State.bin_reader_t
      )
    ) >>= fun res ->
      match (
        match res with
        | Ok (`Ok state) -> Some state (* successful load *)
        | Ok `Eof -> trace "load: %s: `Eof" db_filename; None
        | Error exn -> trace "load: %s:\n%s" db_filename (Exn.to_string exn); None
      ) with
      | Some state -> return (State.value state, `good)
      | None -> return (Db.create(), `format_changed)

  let save_db db ~db_filename =
    Effort.track saves_done (fun () ->
      Monitor.try_with (fun () ->
        Writer.with_file_atomic db_filename ~f:(fun w ->
          (* snapshot & write must be in same async-block *)
          let state = State.snapshot db in
          Writer.write_bin_prot w State.bin_writer_t state;
          set_is_saved();
          return ()
        )
      ) >>| function
      | Ok () -> ()
      | Error exn ->
        Message.error "exception thrown while saving %s:\n%s"
          db_filename (Exn.to_string exn)
    )

end

let load_db_as_sexp ~db_filename =
  Ops.load_db_with_quality ~db_filename >>| fun (db,_quality) -> Db.sexp_of_t db

type t = {
  db : Db.t;
  quality : Quality.t;
  db_filename : string;
  mutable save_status : [ `saving of unit Deferred.t | `not_saving ];
  mutable periodic_saving_enabled : bool;
} with fields

let create ~root_dir =
  let db_filename = root_dir ^/ Misc.db_basename in

  trace "LOAD_DB: %s..." db_filename;
  time_async (fun () -> Ops.load_db_with_quality ~db_filename)
  >>= fun ((db,quality),duration) ->
  trace "LOAD_DB: %s... done (%s), quality=%s"
    db_filename (Time.Span.to_string duration)
    (Quality.to_string quality);

  let t = {
    db;
    quality;
    db_filename;
    save_status = `not_saving;
    periodic_saving_enabled = true;
  } in

  return t

let save_if_changed t =
  match is_modified() with
  | false ->
    trace "SAVE_DB: unchanged so not saving";
    Deferred.unit
  | true ->
    trace "SAVE_DB: %s..." (db_filename t);
    time_async (fun () ->
      Ops.save_db (db t) ~db_filename:(db_filename t)
    ) >>= fun ((),duration) ->
    trace "SAVE_DB: %s... done (%s)" (db_filename t) (Time.Span.to_string duration);
    return ()

let rec save_now t =
  match t.save_status with

  | `saving wait ->
    trace "waiting for in-flight save to complete";
    wait >>= fun () ->
    trace "doing save again";
    save_now t

  | `not_saving ->
    let ivar = Ivar.create () in
    t.save_status <- `saving (Ivar.read ivar);
    save_if_changed t >>= fun () ->
    Ivar.fill ivar ();
    t.save_status <- `not_saving;
    return ()

let save_periodically ~save_span t =
  don't_wait_for (
    let rec loop () =
      Clock.after save_span >>= fun () ->
      if t.periodic_saving_enabled
      then (
        save_now t >>= fun () ->
        loop ()
      )
      else loop ()
    in
    loop ()
  )

let create_saving_periodically ~root_dir save_span =
  create ~root_dir >>= fun t ->
  save_periodically ~save_span t;
  return t

let disable_periodic_saving_and_save_now t =
  t.periodic_saving_enabled <- false;
  save_now t

let re_enable_periodic_saving t = t.periodic_saving_enabled <- true
