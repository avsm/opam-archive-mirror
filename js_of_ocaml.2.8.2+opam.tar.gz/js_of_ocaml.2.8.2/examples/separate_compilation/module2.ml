let () = Module1.hello "world"
