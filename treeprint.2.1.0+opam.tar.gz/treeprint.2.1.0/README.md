# treeprint

Treeprint is a small pretty printing combinator library based on Format,
with automatic parenthese ('(' and ')') insertion: building printing objects
with their associativity (left/right/nonassoc) and connectivity precedences,
objects are pretty-printed with parenthese when necessary.
