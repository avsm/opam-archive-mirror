module M : sig
  type t [@@deriving conv{ocaml}]

end = struct
  type t = { x [@conv.as X] : int;
             y [@conv.as {ocaml=Y}] : float }
      [@@deriving conv{ocaml}]

end
