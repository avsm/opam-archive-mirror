open Camlp4                                             (* -*- camlp4of -*- *)

module Id : Sig.Id = struct
  let name = "pa_xprintf"
  let version = "1.0"
end

module Make (Syntax : Sig.Camlp4Syntax) = struct
  (* open Sig *)
  include Syntax

  (* open Ast *)
  (* open Printf *)
  (* open Lexformat *)

  module Pa_format = Pa_format.Make(Syntax) 

  let parse _loc _loc_var_opt s =
    match Pa_format.parse ['"'] _loc _loc_var_opt s with
    | `Const c -> c
    | `Fun (_abss, f) -> f <:expr<Printf.sprintf>>
  ;;

  let _ = 
    Syntax.Quotation.add "qq"
      Syntax.Quotation.DynAst.expr_tag parse;

    Syntax.Quotation.add "qq"
      Syntax.Quotation.DynAst.str_item_tag
      (fun _loc _loc_var_opt s ->
	let e = parse _loc _loc_var_opt s in
	<:str_item< $exp:e$ >>);
  ;;
    
end

let module M = Register.OCamlSyntaxExtension(Id)(Make) in ()
