(*
  we want the error report to tell us the correct file, with the correct line
*)

let f x = 4513^&#$%1645!#^$$
