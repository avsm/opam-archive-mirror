let compare = compare
let (<) = (<)
let (<=) = (<=)
let (>) = (>)
let (>=) = (>=)
let (=) = (=)
let (<>) = (<>)
let equal = (=)
let min = min
let max = max

