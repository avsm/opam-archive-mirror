let _ = <:value< 1 + true >>
