let view foo = << $bar:foo$ >>
