v0.9.1 2014-12-23 Cugy (VD)
---------------------------

- Add access to the `Line_break`, `Grapheme_cluster_break`, `Word_break` and
  `Sentence_break` Unicode properties. See the `Uucp.Break` module.
- Improvements and fixes to the minimal Unicode Introduction. 


v0.9.0 2014-06-28 Cambridge (UK)
-------------------------------

First release. Part of the work was sponsored by OCaml Labs.
