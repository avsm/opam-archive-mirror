(* < > variant types *)
type poly6 = [< `A > `B]
    deriving (Eq)
