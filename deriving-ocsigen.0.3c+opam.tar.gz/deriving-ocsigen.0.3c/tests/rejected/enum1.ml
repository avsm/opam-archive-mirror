(* enum for records *)
type r = { x : int } deriving (Enum)
