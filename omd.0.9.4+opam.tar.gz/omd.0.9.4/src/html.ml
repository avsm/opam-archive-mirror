type html =
  | Tag of name * attribute list * html list
  | Text of string
and attribute = name * string
and name = string


let rec clean_spaces = function
  | (Space | Spaces _ | Newline | Newlines _) :: tl -> clean_spaces tl
  | x -> x

let extract_tag_name =
  let rec loop res = function
    | (Space | Spaces _ | Newline | Newlines _
      | Greaterthan | Greaterthans _ ) :: _ as l ->
      Some(res, l)
    | Word w :: tl ->
      loop (res ^ w) tl
    | 
  in
  x

let parse_html = function
  | Lessthan::tl ->
    let tl = clean_spaces tl in
    begin match tl with
      | Word tagname::_ ->
        begin match tl with
          | 
        end
      | _ -> None
    end
  | _ -> None
