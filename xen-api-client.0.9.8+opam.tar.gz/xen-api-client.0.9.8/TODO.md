Library enhancements:

  * simplify the marshalling/unmarshalling
  * allow session_id to be managed by the library so expiry can be hidden

API enhancements:

  * streaming APIs
  * SQL joins, projections
