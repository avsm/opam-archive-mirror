let libdir = "/usr/local/share/menhir"
let ocamlfind = true
