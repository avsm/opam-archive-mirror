# Ocephes

Bindings to special math functions from the [Cephes](http://www.netlib.org/cephes/) library.
Only the probability and special functions are exposed (at this point).

[Online API documentation](https://rleonid.github.io/Ocephes).

# Note

Stephen L. Moshier has granted permission for this code to be released under
the BSD license, [email](Mosher.txt).
All of the `C` code in this repository is Stephen L. Moshier's.
