
let () = Printf.printf "%f\n" (Ocephes.bdtr ~k:2 ~n:3 0.5)
