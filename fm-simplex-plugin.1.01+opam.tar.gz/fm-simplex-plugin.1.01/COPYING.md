## Copyright

These software are distributed in the hope that they will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

The resources are licensed as follows:

### The "non-free" Directory

Tools and plugins provided in the "non-free" directory are licensed
under a Non-Commercial License. You are NOT allowed to redistribute
them, to distribute the binaries resulting from their compilation, to
modify the licensing, or to use them/the binaries for a commercial
purpose without an approval from OCamlPro. See
non-free/Non-Commercial-License.pdf for more details.

### The Other Resources

The other resources of this software are provided under the CeCILL-C
(version 1) license. You can redistribute and/or modify them under the
terms of the CeCILL-C FREE SOFTWARE LICENSE AGREEMENT. See enclosed
CeCILL-C for more details.

Please, do not use enclosed software until you have read and
accepted the terms of the licensing above. The use of these
software implies that you automatically agree with our terms and
conditions.