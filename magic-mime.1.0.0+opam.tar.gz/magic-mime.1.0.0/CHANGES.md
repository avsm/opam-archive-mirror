1.0.0 (2015-02-08):
* Initial public release.
