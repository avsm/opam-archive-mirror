#load "omd.cma";;
let slurp filename =
  let file = open_in filename in
  let size = in_channel_length file in
  let buf = String.create size in
  begin
    really_input file buf 0 size;
    buf
  end
let test f = let md = Omd.of_string (slurp f) in   let round_trip = Omd.of_string(Omd.to_markdown md) in md, round_trip;;
