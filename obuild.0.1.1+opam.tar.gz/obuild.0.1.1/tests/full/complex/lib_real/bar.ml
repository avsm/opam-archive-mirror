
let real_list l = List.map Foo.make_real l
