open QmlContext

class virtual historyModel = object

end[@@itemmodel][@@qtclass]

