module Int32Map = 
  Map.Make(struct type t = int32 let compare = Int32.compare end)

