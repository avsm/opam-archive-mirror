Query CDROM devices
===================

Simple OCaml bindings for functions to query the state of CDROM devices.
These functions allow an application to find out if media is present.
