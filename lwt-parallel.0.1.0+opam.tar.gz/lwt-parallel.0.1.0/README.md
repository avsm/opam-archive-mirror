parallel
========

Lwt-enabled distributed computing library
