(* OASIS_START *)
(* DO NOT EDIT (digest: 26ab0dc91868743ee758ecb45b268d43) *)

lwt_parallel - Lwt-enabled parallel computing library
=====================================================

See the file [INSTALL.txt](INSTALL.txt) for building and installation
instructions.

Copyright and license
---------------------

lwt_parallel is distributed under the terms of the MIT License.

(* OASIS_STOP *)
