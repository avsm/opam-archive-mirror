type foo =
    | One
    | Two
    | Three
