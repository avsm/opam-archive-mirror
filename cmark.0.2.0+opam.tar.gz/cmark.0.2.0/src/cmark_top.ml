(* begin mk topgen *)
let () = UTop_main.main ()
(* end *)
