0.2 (3-Aug-2016)
- export a `flush` function
- use `Cstruct.memset`

0.1 (3-Nov-2015)
- initial release with support for `resize` and sparseness info
