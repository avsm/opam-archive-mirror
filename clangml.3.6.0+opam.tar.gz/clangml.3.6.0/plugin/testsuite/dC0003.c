struct A *x;
struct B {
  struct A {};
};

struct A2 *x2;
struct B2 {
  struct A2 {} A2;
};
