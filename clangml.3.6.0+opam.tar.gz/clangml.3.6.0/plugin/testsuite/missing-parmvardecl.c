typedef ft(int);
fn1(ft __attribute__((noreturn)));
