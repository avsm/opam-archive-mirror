(* OASIS_START *)
(* DO NOT EDIT (digest: e26ea56b0590091110d0bf6d320860db) *)

lbfgs - Minimization of multidimensional functions on bounded or unbounded domains.
===================================================================================

This is a binding to L-BFGS-B, a library for Large-scale Bound-constrained
Optimization.

See the file [INSTALL.txt](INSTALL.txt) for building and installation
instructions.

[Home page](https://github.com/Chris00/L-BFGS-ocaml)

Copyright and license
---------------------

lbfgs is distributed under the terms of the GNU Lesser General Public License
version 3.0 with OCaml linking exception.

(* OASIS_STOP *)
