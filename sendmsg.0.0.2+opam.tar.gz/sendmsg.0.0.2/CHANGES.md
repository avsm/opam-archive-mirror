## v0.0.2 2016-11-05

* Fast-forward the C compiler by a couple of decades.

## v0.0.1 2016-11-04

First release. 
