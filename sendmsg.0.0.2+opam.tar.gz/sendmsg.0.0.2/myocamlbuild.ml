let () = Ocamlbuild_plugin.dispatch Ocb_stubblr.init
