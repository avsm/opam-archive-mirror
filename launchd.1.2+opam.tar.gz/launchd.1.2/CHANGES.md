1.2 (2016-01-14)
- don't install the example programs, they're for documentation only
- fix inconsistent use of `caml_strdup` (cakeplus)
