open Core_kernel.Std
open Bap.Std
open Bap_plugins.Std
open Or_error

(** list of posix regexes of files that are ignored during
    training.  *)
let ignored = [
  ".*\\.git.*";
  ".*/README.*";
  sprintf ".*\\.(%s)" @@ String.concat ~sep:"|" [
    "txt"; "html"; "htm"; "md"; "py"; "pyc"; "sh"
  ];
]

module BW = Bap.Std.Byteweight.Bytes

let train_on_file meth length db path : unit t =
  Image.create path >>| fun (img,warns) ->
  let arch = Image.arch img in
  let symtab = Addr.Table.create () in
  Table.iteri (Image.symbols img) ~f:(fun mem _ ->
      Addr.Table.add_exn symtab ~key:(Memory.min_addr mem) ~data:());
  let test mem = Addr.Table.mem symtab (Memory.min_addr mem) in
  let bw = if not (Sys.file_exists db) then BW.create ()
    else match Signatures.load ~mode:"bytes" ~path:db arch with
      | Some s when meth = `update ->
        Binable.of_string (module BW) s
      | _ -> BW.create () in
  Table.iteri (Image.sections img) ~f:(fun mem sec ->
      if Image.Sec.is_executable sec then
        BW.train bw ~max_length:length test mem);
  let data = Binable.to_string (module BW) bw in
  Signatures.save ~mode:"bytes" ~path:db arch data

let matching =
  let open FileUtil in
  let ignored =
    List.map ignored ~f:Re_posix.re |> Re.alt |> Re.compile in
  let matches s = Re.execp ignored s in
  let ignored = Custom matches in
  FileUtil.(And (Is_file, Not ignored))

let train meth length comp db paths =
  let db = Option.value db ~default:"sigs.zip" in
  let collect path =
    FileUtil.find matching path (fun xs x -> x :: xs) [] in
  let files = List.map paths
      ~f:(fun f -> if Sys.is_directory f then collect f else [f]) |>
              List.concat |> List.sort ~cmp:String.compare in
  let total = List.length files in
  let start = Sys.time () in
  let errors = ref 0 in
  List.iteri files ~f:(fun n path ->
      printf "[%3d / %3d] %-66s%!" (n+1) total path;
      let r = match train_on_file meth length db path with
        | Ok () -> "OK"
        | Error err ->
          Format.eprintf "Error: %a\n%!" Error.pp err;
          (incr errors); "SKIPPED" in
      printf "%6s\n%!" r);
  printf "Processed %d files out of %d in %g seconds\n"
    (total - !errors) total (Sys.time () -. start);
  printf "Signatures are stored in %s\n%!" db;
  Ok ()

let find threshold length comp path input : unit t =
  Image.create input >>= fun (img,_warns) ->
  let arch = Image.arch img in
  let data = Signatures.load ?path ~mode:"bytes" arch in
  Result.of_option data
    ~error:(Error.of_string "failed to read signatures from database")
  >>= fun data ->
  let bw = Binable.of_string (module BW) data in
  Table.iteri (Image.sections img) ~f:(fun mem sec ->
      if Image.Sec.is_executable sec then
        let start = Memory.min_addr mem in
        let rec loop n =
          match BW.next bw ~length ~threshold mem n with
          | Some n -> printf "%a\n" Addr.ppo Addr.(start ++ n); loop (n+1)
          | None -> () in
        loop 0);
  Ok ()

let symbols print_name print_size input : unit t =
  Image.create input >>| fun (img,_warns) ->
  let syms = Image.symbols img in
  Table.iteri syms ~f:(fun mem sym ->
      let addr = Memory.min_addr mem in
      let name = if print_name then Image.Sym.name sym else "" in
      let size = if print_size
        then sprintf "%4d " (Memory.length mem) else "" in
      printf "%a %s%s\n" Addr.ppo addr size name);
  printf "Outputted %d symbols\n" (Table.length syms)


let create_parent_dir dst =
  let dir = if Filename.(check_suffix dst dir_sep)
    then dst else Filename.dirname dst in
  FileUtil.mkdir ~parent:true dir


let fetch fname url =
  let tmp,fd = Filename.open_temp_file "bap_" ".sigs" in
  let write s = Out_channel.output_string fd s; String.length s in
  let conn = Curl.init () in
  Curl.set_writefunction conn (write);
  Curl.set_failonerror conn true;
  Curl.set_followlocation conn true;
  Curl.set_sslverifypeer conn false;
  Curl.set_url conn url;
  Curl.perform conn;
  Curl.cleanup conn;
  Out_channel.close fd;
  create_parent_dir fname;
  FileUtil.mv tmp fname;
  printf "Successfully downloaded to %s\n" fname

let fetch fname url = try Ok (fetch fname url) with
  | Curl.CurlException (err,n,_) ->
    errorf "failed to fetch: %s" (Curl.strerror err)
  | exn -> Or_error.of_exn exn

let install src dst = try_with begin fun () ->
    create_parent_dir dst;
    FileUtil.cp [src] dst;
    printf "Installed signatures to %s\n" dst;
  end

let update url dst =
  let old = Filename.temp_file "bap_old_sigs" ".zip" in
  if Sys.file_exists dst
  then FileUtil.cp [dst] old;
  fetch dst url >>| fun () ->
  if FileUtil.cmp old dst = None
  then printf "Already up-to-date.\n"
  else printf "Installed new signatures.\n";
  if Sys.file_exists old then FileUtil.rm [old]

module Cmdline = struct
  open Cmdliner

  let filename : string Term.t =
    let doc = "Input filename." in
    Arg.(required & pos 0 (some non_dir_file) None &
         info [] ~doc ~docv:"FILE")

  let database_in : string option Term.t =
    let doc = "Path to signature database" in
    Arg.(value & opt (some non_dir_file) None &
         info ["db"; "d"] ~doc)

  let database : string option Term.t =
    let doc = "Update or create database at $(docv)" in
    Arg.(value & opt (some string) None &
         info ["db"; "d"] ~doc ~docv:"DBPATH")

  let files : string list Term.t =
    let doc = "Input files and directories" in
    Arg.(non_empty & pos_all file [] & info [] ~doc ~docv:"FILE")

  let compiler : string option Term.t =
    let doc = "Assume the training set is compiled by $(docv)" in
    Arg.(value & opt (some string) None &
         info ["comp"] ~doc ~docv:"COMPILER")

  let length : int Term.t =
    let doc = "Maximum prefix length" in
    Arg.(value & opt int 16 & info ["length"; "l"] ~doc)

  let meth : [`update | `rewrite] Term.t =
    let enums = ["update", `update; "rewrite", `rewrite] in
    let doc = sprintf "If entry exists then %s it." @@
      Arg.doc_alts_enum enums in
    Arg.(value & opt (enum enums) `update &
         info ["method"; "m"] ~doc)

  let threshold : float Term.t =
    let doc = "Decide that sequence starts a function \
               if m / n > $(docv),  where n is the total \
               number of occurences of a given sequence in \
               the training set, and m is how many times \
               it has occured at the function start position." in
    Arg.(value & opt float 0.5 &
         info ["threshold"; "t"] ~doc ~docv:"THRESHOLD")

  let url : string Term.t =
    let doc = "Url of the binary signatures" in
    let default = sprintf
        "https://github.com/BinaryAnalysisPlatform/bap/\
         releases/download/v%s/sigs.zip" Config.pkg_version in
    Arg.(value & opt string default & info ["url"] ~doc)

  let src : string Term.t =
    Arg.(value & pos 0 non_dir_file "sigs.zip" & info []
           ~doc:"Signatures file" ~docv:"SRC")
  let dst : string Term.t =
    Arg.(value & pos 1 string Signatures.default_path &
         info [] ~doc:"Destination" ~docv:"DST")

  let output : string Term.t =
    let doc = "Output filename" in
    Arg.(value & opt string "sigs.zip" & info ["o"] ~doc)

  let print_name : bool Term.t =
    let doc = "Print symbol's name." in
    Arg.(value & flag & info ["print-name"; "n"] ~doc)

  let print_size : bool Term.t =
    let doc = "Print symbol's size." in
    Arg.(value & flag & info ["print-size"; "s"] ~doc)

  let train =
    let doc = "Train byteweight on the specified set of files" in
    Term.(pure train $meth $length $compiler $database $files),
    Term.info "train" ~doc

  let find =
    let doc = "Output all function starts in a given executable" in
    Term.(pure find $threshold $length $compiler $database_in $filename),
    Term.info "find" ~doc

  let fetch =
    let doc = "Fetch signatures from the specified url" in
    Term.(pure fetch $output $url), Term.info "fetch" ~doc

  let install =
    let doc = "Install signatures" in
    Term.(pure install $src $dst), Term.info "install" ~doc

  let update =
    let doc = "Download and install latest signatures" in
    Term.(pure update $url $dst), Term.info "update" ~doc

  let symbols =
    let doc = "Print file's symbol table if any." in
    Term.(pure symbols $print_name $print_size $filename),
    Term.info "symbols" ~doc

  let usage choices =
    eprintf "usage: bap-byteweight [--version] [--help] \
             <command> [<args>]\n";
    eprintf "where <command> := %s.\n"
      (String.concat ~sep:" | " choices);
    Ok ()

  let default =
    let doc = "Byteweight Toolkit" in
    let man = [
      `S "DESCRIPTION";
      `P "bap-byteweight is a toolkit for training, fetching, testing\
          and installing byteweight signatures."
    ] in
    Term.(pure usage $ choice_names),
    Term.info "bap-byteweight"
      ~version:Config.pkg_version ~doc ~man

  let eval () = Term.eval_choice default
      [train; find; fetch; install; update; symbols]
end

let () =
  Plugins.load ();
  match Cmdline.eval () with
  | `Ok Ok () -> ()
  | `Ok Error err -> eprintf "Program failed: %s\n"
                       Error.(to_string_hum err)
  | _ -> exit 1
