type ('a, 'error) t = [`Ok of 'a | `Error of 'error]

let catch f = 
  let module Error = struct exception Error end in
  let error = ref None in
  let fail e = error := Some e; raise Error.Error in
  try `Ok (f ~fail) with
  | Error.Error -> 
      match !error with
      | Some e -> `Error e
      | None -> assert false

let catch_exn f = catch (fun ~fail -> try f () with e -> fail e)
  
let from_Ok to_exn = function
  | `Ok v -> v
  | `Error e -> raise (to_exn e)
