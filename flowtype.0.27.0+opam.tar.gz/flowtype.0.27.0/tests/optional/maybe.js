function foo(x?: string): ?string {
    return x;
}
