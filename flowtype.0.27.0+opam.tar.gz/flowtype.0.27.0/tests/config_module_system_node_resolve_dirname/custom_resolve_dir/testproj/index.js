// @flow

export var name: "otherdir/testproj" = "otherdir/testproj";
