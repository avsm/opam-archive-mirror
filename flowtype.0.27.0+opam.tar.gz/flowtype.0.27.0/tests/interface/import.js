interface I { x: number }
export type J = I; // workaround for export interface
