/* TODO - we currently say that a function's statics are an AnyObjT and
 * anything goes. When we start enforcing the statics properly, we'll need to
 * know that .name exists
 */
