// @flow
var x: C = f (5);
var y: string = f(1, "test");
