// @flow
var P = require("module-P");
var x : string = (new P.C()).y;
