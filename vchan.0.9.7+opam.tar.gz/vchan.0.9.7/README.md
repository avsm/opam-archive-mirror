This is an implementation of the Xen "libvchan" or "vchan" communication
protocol in OCaml. It allows fast inter-domain communication using shared
memory.
