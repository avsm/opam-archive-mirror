(* File generated from piqi_c.idl *)


external piqi_strtoull : string -> int64
	= "camlidl_piqi_c_piqi_strtoull"

