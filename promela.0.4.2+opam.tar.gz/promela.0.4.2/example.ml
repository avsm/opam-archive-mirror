let _ =
   let module P = Promela in
   let id = P.Identifier.create in
   let d1 = P.Declaration.create (id "A1") (P.Type.Bit) in
   let d2 = P.Declaration.create (id "A2") (P.Type.Bit) in
   let ds0 = P.DeclarationSet.singleton d1 in
   let ds1 = P.DeclarationSet.add d1 (P.DeclarationSet.singleton d2) in
   let i = id "A1" in
   let e = P.Expression.Variable i in
   let s = P.Statement.Assign (i, None, e) in
   let a = P.Statement.Atomic [s;s;s] in
   let p0= P.Process.create ~active:true ~globals:ds0 (id "R0") [a;s;a] in
   let p1 = P.Process.create ~active:true ~globals:ds1 (id "R1") [a;s;a] in
   let ps = P.Program.add (P.Program.add P.Program.empty p0) p1 in
   let () = P.Program.to_channel stdout ps in
   0
