(* OASIS_START *)
(* DO NOT EDIT (digest: bb34d23cfb2bb95c679918cde216c0cd) *)
This is the README file for the promela distribution.

generate, rewrite and analyze PROMELA models

See the files INSTALL.txt for building and installation instructions. 


(* OASIS_STOP *)
