module Patience_diff = Patience_diff
module Plain_diff    = Plain_diff
