vX.Y.Z YYYY-MM-DD Location
--------------------------

First release. 
