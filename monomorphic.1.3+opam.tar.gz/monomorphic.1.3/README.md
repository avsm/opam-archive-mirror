ocaml-monomorphic is a small library used to shadow polymorphic operators (and functions) contained in Pervasives.
It can be useful to avoid some mistakes and runtime errors due to OCaml's polymorphic comparison functions.

[![Build Status](https://travis-ci.org/jpdeplaix/ocaml-monomorphic.png?branch=master)](https://travis-ci.org/jpdeplaix/ocaml-monomorphic)
