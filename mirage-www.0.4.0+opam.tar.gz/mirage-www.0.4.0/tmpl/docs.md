!! Documentation

Mirage is still under heavy development, and so there is no detailed documentation available.  However, if you are keen to hack, you can read the [INSTALL](http://github.com/avsm/mirage/blob/master/INSTALL) file and give it a shot.

Feedback and questions are always welcome via e-mail to `cl-mirage@lists.cam.ac.uk` or catch us on `#mirage` on FreeNode IRC.

The best way to wait for a release is to [watch](http://github.com/avsm/mirage/toggle_watch) the project on [GitHub](http://github.com/avsm/mirage).
