!!The Channels

* *E-mail*: developer mailing list at [http://www.xenproject.org/help/mailing-list.html](http://lists.xenproject.org/cgi-bin/mailman/listinfo/mirageos-devel) and [archive](http://lists.xenproject.org/archives/html/mirageos-devel/)
* *IRC*: `#mirage` on `irc.freenode.org`
* *Twitter*: [openmirage](http://twitter.com/openmirage)
* *Meetings*: [Kingston Arms](http://www.kingston-arms.co.uk/)
