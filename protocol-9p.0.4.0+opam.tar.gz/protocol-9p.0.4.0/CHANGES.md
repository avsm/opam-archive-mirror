0.4.0 (2016-01-25):
* Remove OASIS from build system
* Remove use of -pack, now use the index module Protocol_9p with aliases
* Expose previously hidden Response.sizeof_header
* Expose previously hidden Response.Read.sizeof_header
* Add Request.sizeof_header
* Add Request.Write.sizeof_header

0.3 (2016-01-20):
* Add version/attach mount debug messages
* Pass initial connection attach to receive callback handler

0.2 (2016-01-04):
* Respect negotiated msize in read
* Add LICENSE file

0.1 (2015-12-13):
* Initial version
