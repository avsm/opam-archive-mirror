?package(arakoon):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="arakoon" command="/usr/bin/arakoon"
