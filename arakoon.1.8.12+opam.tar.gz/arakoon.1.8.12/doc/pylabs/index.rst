============================
Managing Arakoon with PyLabs
============================
In the previous sections you have seen how you can install, configure, and
manage Arakoon. Incubaid offers an alternative way by using PyLabs.

In this section you find the PyLabs way to configure and manage Arakoon.

In this Chapter...
==================
.. toctree::
   :maxdepth: 1

   installing_arakoon_with_pylabs
   configuring_arakoon
   cloning_a_node
   arakoon_pylabs_client
   nursery_pylabs_client
