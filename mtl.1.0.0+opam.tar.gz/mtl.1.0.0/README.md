# ocaml-mtl - A Monad Transformers Library for OCaml

This is a packaged up and slightly cleaned up version of the original "monads"
library that can be found [here](http://lambda.jimpryor.net/monad_library/).
