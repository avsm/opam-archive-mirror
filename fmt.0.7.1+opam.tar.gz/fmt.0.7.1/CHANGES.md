v0.7.1 2015-12-03 Cambridge (UK)
--------------------------------

* Add optional cmdliner support. See the `Fmt_cli` module provided
  by the package `fmt.cli`.


v0.7.0 2015-09-17 Cambridge (UK)
--------------------------------

First Release.
