ojwidgets
=========

Widgets for browser applications written in OCaml (also see Eliom widgets)

Just do a "make" and "make install". Everything is going to be alright.

Then, if you want to use it, compile your project with the package jswidgets.
