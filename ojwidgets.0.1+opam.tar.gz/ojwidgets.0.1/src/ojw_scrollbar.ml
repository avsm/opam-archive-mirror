(* Copyright Université Paris Diderot

Author : Vincent Balat
   Christophe Lecointe
*)


include
  Ojw_scrollbar_f.Make
    (Ojw_dom.T)
