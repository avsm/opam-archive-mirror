(* Copyright Université Paris Diderot.

   Author : Charly Chevalier
*)

include Ojw_popup_f.Make(Ojw_dom.T)(Ojw_alert)
