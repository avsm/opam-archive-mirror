
include
  Ojw_button_f.Make
    (Ojw_dom.T)
    (Ojw_alert)
