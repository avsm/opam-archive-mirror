v0.8.1 2014-05-22 La Forclaz (VS)
---------------------------------

* Fix compilation on 32 bits platforms. 
* Support for ctypes 0.3. Thanks to Jeremy Yallop for the patch.


v0.8.0 2014-05-19 La Forclaz (VS)
---------------------------------

First release.
Part of the work was sponsored by OCaml Labs.
