0.1.3 (2016-03-22):
* tls-0.7.1 compatibility (do not depend on Tls.Printer)

0.1.2 (2016-02-11):
* HAProxy protocol support (version 1, via --haproxy1 flag), #22 contributed by @cfcs

0.1.1 (2015-07-02):
* log RFC3339 compatible, using UTC
* log exceptions in read_write
* avoid reusing the read/write buffer

0.1.0 (2015-05-05):
* Initial public release.
