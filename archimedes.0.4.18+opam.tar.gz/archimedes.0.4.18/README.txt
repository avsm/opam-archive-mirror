(* OASIS_START *)
(* DO NOT EDIT (digest: 1df5d97d361593aa9e858cb383a7abd6) *)

archimedes - Extensible 2D plotting library.
============================================

Archimedes is a high quality, platform-independent, extensible 2D plotting
library.  It provides dynamically loaded backends such as Graphics and Cairo.

See the file [INSTALL.txt](INSTALL.txt) for building and installation
instructions.

[Home page](http://forge.ocamlcore.org/projects/archimedes/)

Copyright and license
---------------------

archimedes is distributed under the terms of the GNU Lesser General Public
License version 3.0 with OCaml linking exception.

(* OASIS_STOP *)

Acknowledgments
---------------

This project was started in June 2009 thanks to financial support of
Jane Street Capital <http://www.janestcapital.com/>.  It was also
sponsored during the summer 2011 by the Faculty of Science of the
University of Mons.  We are very grateful to both organizations for
their support.
