int main(){
  int a;
  int b;
  a = 1;
  b = 7;
  while (a < b){
    a = a + 1;
  }
  assert(a >= b);
}
