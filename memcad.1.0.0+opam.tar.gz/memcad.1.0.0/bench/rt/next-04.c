// some basic arithmetic tests
void main( )
{
  int x ;
  if( x < 10 ){
    assert( x != 10 );
  } else if( x > 10 ){
    assert( x != 10 );
  } else {
    assert( x == 10 );
  }
}
