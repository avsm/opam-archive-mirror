// double variable creation, read write
void main( )
{
  double y ;
  y = 3.5 ;
  assert( y <= 4 );
  assert( 3.2 <= y );
}
