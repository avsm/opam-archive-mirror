// Ex-58: empty main (segmentation fault in some Clang versions)
void main( ){
}
