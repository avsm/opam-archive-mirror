// Ex c-micro-05: very basic arithmetics
void main( ){
  int i;
  int j;
  int k;
  i = 0;
  j = 10;
  while( i < j ){
    i = i + 1;
  }
  i = 0;
  j = 13;
  while( i < j ){
    i = i + 2;
  }
  k = j;
}
