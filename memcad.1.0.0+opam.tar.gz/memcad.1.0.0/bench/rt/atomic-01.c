// char variable creation, read write
void main( )
{
  char y ;
  y = 64 ;
  assert( y == 64 );
}
