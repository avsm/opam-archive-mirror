typedef struct list {
  char c;
  int data ;
  struct list * next ;
} list ;
