// Ex c-micro-04: basic arithmetics
void main( ){
  int x ;
  x = 42 ;
  int y ;
  int z ;
  x = x + 1 ;
  if( y > x ){
    assert( y >= 44 );
  } else {
    y = - y ;
  }
  z = y ;
}
