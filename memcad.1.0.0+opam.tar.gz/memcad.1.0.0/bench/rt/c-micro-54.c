
void main() {
  char* s = "abc";
  char a = s[0];

  char array[3];
  char* start = array;
}
