// Ex c-micro-03: char variable creation, read write
void main( )
{
  int x ;
  x = 10 ;
  assert( x == 10 );
}
