// set-00: set operations
void main( ){
  int a;
  _memcad( "decl_setvars( E, F )" );
  a = a + 1;
}
