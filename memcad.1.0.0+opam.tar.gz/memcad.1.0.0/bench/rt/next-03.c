// Ex next-03: some basic arithmetic tests
void main( )
{
  int x ;
  if( x < 10 ){
    assert( x <= 9 );
  } else {
    assert( x >= 10 );
  }
}
