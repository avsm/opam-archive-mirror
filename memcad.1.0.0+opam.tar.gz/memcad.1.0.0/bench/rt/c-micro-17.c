// Ex c-micro-17: tests that should be performed in the graph

void main( ){
  int x;
  int y;
  int * p;
  int * q;
  p = &x;
  q = &y;
  assert( p != null );
  assert( p != q);
}
