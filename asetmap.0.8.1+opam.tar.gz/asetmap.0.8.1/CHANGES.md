v0.8.1 2016-09-27 Zagreb
------------------------

* Add type-level compatibility with stdlib sets and maps.
  Thanks to Hezekiah M. Carty for the idea and the patch.

v0.8.0 2016-08-26 Zagreb
------------------------

First release. 
