Backend using xenctrl/xenguest/xenstore
=======================================

A xenops plugin which knows how to use xenstore, xenctrl and
xenguest to manage VMs on a xen host.
