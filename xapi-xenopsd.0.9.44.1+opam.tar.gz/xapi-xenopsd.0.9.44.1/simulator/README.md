Simulation backend
==================

This backend allows testing of the higher-level xenops logic.
