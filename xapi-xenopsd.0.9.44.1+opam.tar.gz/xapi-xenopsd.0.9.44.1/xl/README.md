Backend using xenlight
=======================================

A xenops plugin which knows how to use xenlight to manage
VMs on a xen host.
