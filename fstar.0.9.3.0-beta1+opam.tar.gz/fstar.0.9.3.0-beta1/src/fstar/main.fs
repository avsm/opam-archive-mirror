#light "off"
module FStar.Main
let _ = FStar.main ()

