type uint8 = int
type byte = uint8
