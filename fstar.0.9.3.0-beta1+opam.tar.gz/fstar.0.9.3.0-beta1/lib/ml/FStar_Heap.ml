type heap = unit

type aref = unit

let emp =
  ()
