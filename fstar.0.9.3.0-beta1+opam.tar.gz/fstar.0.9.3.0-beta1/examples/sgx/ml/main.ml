open Interpreter

let debug = true

let () =
   let _ = main debug in
   ()

