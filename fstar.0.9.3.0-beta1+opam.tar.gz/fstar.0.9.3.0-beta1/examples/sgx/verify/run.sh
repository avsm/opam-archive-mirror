
# Setup fstar.exe in the path and run this command
fstar.exe --z3timeout 30 VerInterpreter.fst
