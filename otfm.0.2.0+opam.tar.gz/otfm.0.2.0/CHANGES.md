v0.2.0 2014-08-23 Cambridge (UK)
--------------------------------

- Add `loca` and `glyf` table decoding.


v0.1.0 2013-09-24 Lausanne
--------------------------

First release.  
Sponsored by Citrix Systems R&D and OCaml Labs.
