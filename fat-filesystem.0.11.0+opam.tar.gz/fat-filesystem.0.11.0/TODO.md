* add concurrency monad
* use the result monad properly
* be consistent about sector size (replace 512 with bytes_per_sector)

