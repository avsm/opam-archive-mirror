let package_name = "ppx_core"

let sections =
  [ ("lib",
    [ ("built_lib_ppx_core", None)
    ],
    [ ("META", None)
    ])
  ]
