let n="0.23"
let d="Thu Oct 24 12:04:01 BST 2013"
