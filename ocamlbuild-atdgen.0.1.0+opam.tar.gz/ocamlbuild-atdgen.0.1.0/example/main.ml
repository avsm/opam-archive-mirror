
let () =
  let date = Hello_t.({ year=2005 ; month=12; day=2 }) in
  print_endline "testing"
