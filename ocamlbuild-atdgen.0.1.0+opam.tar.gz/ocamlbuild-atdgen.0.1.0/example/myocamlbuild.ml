let _ = Ocamlbuild_plugin.dispatch Ocamlbuild_atdgen.dispatcher
