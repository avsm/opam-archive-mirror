* myocamlbuild.ml static linking 
    flag ["link"; "static"; "ocaml"; tag] 
    (S [A "-cclib"; A "/usr/local/lib/libSDL2.a"])





