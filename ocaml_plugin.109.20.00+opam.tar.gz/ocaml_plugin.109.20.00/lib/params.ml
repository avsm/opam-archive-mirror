let build_info_available = false

let build_info_as_sexp = Sexplib.Sexp.Atom "no_build_info"
let version = "(no version info)"
let build_info = "(no build info)"
