ppx_getenv
==========

A sample syntax extension that uses OCaml's new extension points API.

Take a look at [the guide to extension points in OCaml][guide].

[guide]: http://whitequark.org/blog/2014/04/16/a-guide-to-extension-points-in-ocaml/

License
-------

[Public domain](LICENSE.txt)
