10-09-2016 0.2
    - New call `unregister_and_flush` lets a node wait for all its listener
      callbacks to return before unregistering from the backend (#4)
    - Support more than 254 connected nodes

30-04-2015 0.1
    - First release
