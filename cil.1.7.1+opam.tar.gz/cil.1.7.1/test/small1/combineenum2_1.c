/* Make sure that enumeration items get renamed */
enum e1 {
  FIRST,
  SECOND,
} x1;


int main() {
  return x1;
}
