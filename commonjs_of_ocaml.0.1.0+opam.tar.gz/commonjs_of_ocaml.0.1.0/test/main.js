console.log(require('./ocaml_required'));
