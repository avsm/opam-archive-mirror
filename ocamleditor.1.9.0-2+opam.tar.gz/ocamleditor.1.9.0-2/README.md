# OCamlEditor @ github

This is a fork of the original ocamleditor by Francesco Tovagliari, which can be
found at:

https://forge.ocamlcore.org/projects/ocamleditor/

It's by no means intended to be a concurrent fork, but rather to propose patches
to the upstream and improve the visibility and integration of the project.

See file [README](README) (without extension) for the original project's README.
