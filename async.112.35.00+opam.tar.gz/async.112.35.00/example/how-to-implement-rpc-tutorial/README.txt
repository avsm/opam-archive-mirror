A small example that was used as part of a class on RPC.  The
structure of the class was to explain how one might implement RPC,
rather than just describing the API.  The file here contains a small
almost-implementation of an RPC like library.
