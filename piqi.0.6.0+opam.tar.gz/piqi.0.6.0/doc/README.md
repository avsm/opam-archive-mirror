This directory contains the primary copy of the Piqi project documentation.

The up-to-date copy of documentation for the most recent stable version of Piqi
is published on the [project's website](http:/piqi.org/doc/).

Note that documents are written using
[Pandoc](http://johnmacfarlane.net/pandoc/) variation of Markdown syntax.
