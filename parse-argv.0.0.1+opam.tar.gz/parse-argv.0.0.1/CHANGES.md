0.0.1
=====

* initial release of independent parse-argv library (previously in mirage-bootvar-xen, mirage-bootvar-solo5)
