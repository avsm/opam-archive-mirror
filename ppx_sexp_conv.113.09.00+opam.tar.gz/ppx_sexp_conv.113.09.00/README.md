Generation of S-expression conversion functions from type definitions.

For documentation & examples, see: 
    ../../lib/sexplib/README.md
