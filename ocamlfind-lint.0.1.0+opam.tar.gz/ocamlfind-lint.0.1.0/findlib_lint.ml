(*************************************************************************************)
(*  Copyright (c)2015, Zoggy                                                         *)
(*  All rights reserved.                                                             *)
(*                                                                                   *)
(*  Redistribution and use in source and binary forms, with or without               *)
(*  modification, are permitted provided that the following conditions are met:      *)
(*      * Redistributions of source code must retain the above copyright             *)
(*        notice, this list of conditions and the following disclaimer.              *)
(*      * Redistributions in binary form must reproduce the above copyright          *)
(*        notice, this list of conditions and the following disclaimer in the        *)
(*        documentation and/or other materials provided with the distribution.       *)
(*      * Neither the name of the <organization> nor the                             *)
(*        names of its contributors may be used to endorse or promote products       *)
(*        derived from this software without specific prior written permission.      *)
(*                                                                                   *)
(*  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND  *)
(*  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED    *)
(*  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE           *)
(*  DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY               *)
(*  DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES       *)
(*  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;     *)
(*  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND      *)
(*  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *)
(*  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS    *)
(*  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.                     *)
(*************************************************************************************)

module P = Fl_package_base
module S = Fl_metascanner

let () = Findlib.init ()

let is_prefix s1 s2 =
  let len1 = String.length s1 and len2 = String.length s2 in
  len2 >= len1 && String.sub s2 0 len1 = s1

let native_archives pkg =
  let f acc def =
    let preds = def.S.def_preds in
    if def.S.def_var = "archive"
    && List.mem (`Pred "native") preds
    && not (List.mem (`Pred "plugin") preds)
    then
      preds :: acc
    else
      acc
  in
  List.fold_left f [] pkg.P.package_defs

let archive_plugin_exists pkg nat_archive_preds =
  let preds = (`Pred "plugin") :: nat_archive_preds in
  let pred def =
    let mem p = List.mem p def.S.def_preds in
    List.for_all mem preds
  in
  List.exists pred pkg.P.package_defs

let check_archive pkg acc preds =
  if archive_plugin_exists pkg preds then
    acc
  else
    preds :: acc

let check_pkg acc pkg =
  let missing = List.fold_left (check_archive pkg) [] (native_archives pkg) in
  match missing with
    [] -> acc
  | _ -> (pkg, missing) :: acc

let filter_packages name =
  let name_dot = name^"." in
  let pred pkg_name =
    pkg_name = name ||
    is_prefix name_dot pkg_name
  in
  List.filter pred

let string_of_missing pkg missing_preds =
  let string_of_pred = function
    `NegPred s -> "-"^s
  | `Pred s -> s
  in
  let string_of_preds list =
    Printf.sprintf "archive(plugin,%s)"
      (String.concat "," (List.map string_of_pred list))
  in
  Printf.sprintf "%s:\n  %s"
    pkg.P.package_name
    (String.concat "\n  " (List.map string_of_preds missing_preds))

let usage = Printf.sprintf "Usage: %s [<package>]" Sys.argv.(0)
let () =
  try
    let args = ref [] in
    Arg.parse [] (fun s -> args := s :: !args) usage;
    let pkg_names =
      match List.rev !args with
        [] -> P.list_packages ()
      | [name] -> 
          begin
            match filter_packages name (P.list_packages ()) with
              [] -> Printf.ksprintf failwith "No such package %S" name
            | l -> l          
          end
      | _ -> failwith usage
    in
    let pkg_missing = List.fold_left check_pkg [] (List.map P.query pkg_names) in
    match pkg_missing with
      [] -> exit 0
    | _ ->
        let pkg_missing = List.sort Pervasives.compare pkg_missing in
        prerr_endline "Some archive variables are missing in the following packages:";
        List.iter
          (fun (pkg, missing_preds) ->
             prerr_endline (string_of_missing pkg missing_preds))
          pkg_missing;
        exit 1
  with
    e ->
      let msg =
        match e with
        | Failure msg | Sys_error msg -> msg
        | P.No_such_package (p, msg) -> Printf.sprintf "No such package %S: %s" p msg
        | P.Package_loop p -> Printf.sprintf "Package loop: %S" p
        | _ -> Printexc.to_string e
      in
      prerr_endline msg ;
      exit 1
  