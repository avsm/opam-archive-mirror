#!/bin/sh

${POLYGLOT} < in.xml
