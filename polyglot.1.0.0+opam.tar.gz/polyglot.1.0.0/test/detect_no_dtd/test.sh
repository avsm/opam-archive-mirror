#!/bin/sh

${POLYGLOT} --detect < in.xml
