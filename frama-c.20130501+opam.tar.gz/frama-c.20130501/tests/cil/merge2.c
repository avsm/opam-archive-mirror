/* run.config
   OPT: tests/cil/merge.c -print
 */
int x =2;
