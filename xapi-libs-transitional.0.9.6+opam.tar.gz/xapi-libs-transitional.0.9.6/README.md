Deprecated standard library extension
=====================================

These functions are needed by several 'xapi toolstack' services
but they should not be used by other projects. Most of the code
here will either be spun out into separate mini-libraries OR
will be replaced by existing mini-libraries.
