open! Core_kernel.Std
open! Import

include Types.External_job

let sexp_of_t _ = Sexp.Atom "<job>"
