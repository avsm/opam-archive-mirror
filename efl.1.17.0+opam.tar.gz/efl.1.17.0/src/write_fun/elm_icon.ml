open Common

let lookup_order = simple_ty "Elm_Icon" "Lookup_Order"

let funs = [
  simple "standard_set" [evas_object; safe_string] bool;
  prop "order_lookup" lookup_order
]

