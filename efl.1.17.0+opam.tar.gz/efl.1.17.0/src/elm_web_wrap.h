#ifndef ELM_WEB_H
#define ELM_WEB_H

#include "include.h"

inline value copy_Elm_Web_Download(Elm_Web_Download* d);

inline value copy_Elm_Web_Frame_Load_Error(Elm_Web_Frame_Load_Error* fle);

inline value copy_Elm_Web_Frame_Load_Error_opt(Elm_Web_Frame_Load_Error* fle);

inline value copy_Elm_Web_Menu(Elm_Web_Menu* m);

#endif

