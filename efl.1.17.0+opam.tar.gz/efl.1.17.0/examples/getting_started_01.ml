open Efl

let () =
  Elm.init ();

  (* create window(s) here and do any application init *)

  Elm.run (); (* run main loop *)
  Elm.shutdown (); (* after mainloop finishes eunning, shutdown *)

