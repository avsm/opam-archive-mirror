* Make it dependent on Uucp ? Assert what kind of performance
  loss/size of executable increase do we get by exchanging the
  Uucp.decomp representation with a more generic one ?
  
