type a =
  | A
and b = int
