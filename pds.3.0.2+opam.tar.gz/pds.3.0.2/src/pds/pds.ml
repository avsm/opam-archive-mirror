module File_set = Set.Make(String)

let pds_mk = "pds.mk"
let src_makefile = "src_Makefile"
let test_makefile= "test_Makefile"
let ocamlrules_mk = "Ocamlrules.mk.in"
let pds_conf = "pds.conf"
let src_dir = "src"
let tests_dir = "tests"

let printf = Printf.printf
let fprintf = Printf.fprintf
let sprintf = Printf.sprintf

let value_opt ~default = function
  | Some v -> v
  | None -> default

let value_exn ~msg = function
  | Some v -> v
  | None -> failwith msg

let endswith suffix str =
  let suffix_len = String.length suffix in
  let str_len = String.length str in
  if str_len >= suffix_len then
    suffix = String.sub str (str_len - suffix_len) suffix_len
  else
    false

let readdir dir =
  Sys.readdir dir
    |> Array.to_list
    |> List.map (Filename.concat dir)

let load_builds_conf () =
  let conf_name =
    if Array.length Sys.argv > 1 then
      Sys.argv.(1)
    else
      pds_conf
  in
  if Sys.file_exists conf_name then
    Toml.Parser.(from_filename conf_name |> unsafe)
  else
    failwith (sprintf "Build config file, %s, must exist" conf_name)

let get_dirs d =
  Sys.readdir d
  |> Array.to_list
  |> List.filter (fun f -> Sys.is_directory (Filename.concat src_dir f))

(*
 * Builds are directories in the src directory
 *)
let get_builds () = get_dirs src_dir

(*
 * Tests are directories in the tests dir
 *)
let get_tests () =
  if Sys.file_exists tests_dir then
    get_dirs tests_dir
  else
    []

(*
 * Project types can be third-party, which involves doing nothing wiht them
 * or ocaml which pds generates configs for.
 *)
let get_project_type builds_conf build =
  let project_type =
    TomlLenses.(key "src" |-- table
                   |-- key build |-- table
                   |-- key "project_type" |-- string)
  in
  match TomlLenses.get builds_conf project_type with
    | Some "third-party" ->
      `Third_party
    | Some "ocaml"
    | None ->
      `Ocaml
    | Some project_type ->
      failwith (sprintf "Unknown project type %s for build %s" project_type build)

(*
 * For ocaml projects, a build can be a library or an executable
 *)
let get_build_type builds_conf build =
  let build_type =
    TomlLenses.(key "src" |-- table
                   |-- key build |-- table
                   |-- key "type" |-- string)
  in
  match get_project_type builds_conf build with
    | `Ocaml -> begin
      match TomlLenses.get builds_conf build_type with
        | Some "exec" ->
          `Exec
        | Some "library" | None ->
          `Library
        | Some build_type ->
          failwith (sprintf "Unknown build type %s for build %s" build_type build)
    end
    | `Third_party ->
      failwith (sprintf "Third party project %s has no build type" build)

(*
 * A "lib module" is one which has a .mli file.  Since any .mli file needs to
 * have a .ml file associated with it, we just take the .mli files and replace
 * the end with .ml.
 *)
let calculate_lib_modules mli_files =
  File_set.fold
    (fun f acc -> (Filename.chop_extension f ^ ".ml")::acc)
    mli_files
    []

let calculate_non_lib_modules ml_files mli_files =
  let lib_modules_set = File_set.of_list (calculate_lib_modules mli_files) in
  File_set.fold
    (fun f acc -> f::acc)
    (File_set.diff ml_files lib_modules_set)
    []

let calculate_byte_target name = function
  | `Library -> name ^ ".cma"
  | `Exec -> name ^ ".byte"

let calculate_native_target name = function
  | `Library -> name ^ ".cmxa"
  | `Exec -> name ^ ".native"

let is_internal_package = List.mem

let get_ocaml_targets builds_conf b =
  match get_project_type builds_conf b with
    | `Ocaml ->
      let build_type = get_build_type builds_conf b in
      [ calculate_byte_target b build_type
      ; calculate_native_target b build_type
      ]
    | `Third_party ->
      []

(*
 * If a build depends on other builds that are in this configuration then we need
 * to generate the objects that those dependencies will emit so we can properly
 * depend on them in the build being generated, that way if the dependenceis get
 * rebuilt, so does the build being generated.
 *)
let calculate_external_targets base_dir builds_conf builds deps =
  deps
    |> List.filter (fun b -> is_internal_package b builds)
    |> List.map (fun b -> (b, get_ocaml_targets builds_conf b))
    |> List.map
        (fun (b, targets) ->
          let path = Filename.concat base_dir b in
          List.map (Filename.concat path) targets)
    |> List.concat

let get_build_deps builds_conf build =
  value_opt
    ~default:[]
    TomlLenses.(
      get
        builds_conf
        (key "src" |-- table
            |-- key build |-- table
            |-- key "deps" |-- array |-- strings))

let get_compile_build_deps builds_conf build =
  value_opt
    ~default:[]
    TomlLenses.(
      get
        builds_conf
        (key "src" |-- table
            |-- key build |-- table
            |-- key "compile_deps" |-- array |-- strings))

let get_test_deps builds_conf test =
  value_opt
    ~default:[]
    TomlLenses.(
      get
        builds_conf
        (key "tests" |-- table
            |-- key test |-- table
            |-- key "deps" |-- array |-- strings))

(*
 * Generates a the makefiles for can ocaml build.  This just collects all of the
 * build information for this build and spits it out into a Makefile.  Some
 * things that have to be computed are:
 *
 * - The dependencies from other builds in this project.
 * - What install command to use, if it's a library it's predefined otherwise the
 * user must specific
 *)
let emit_ocaml_build build_type builds_conf builds build =
  let dir = Filename.concat src_dir build in
  let build_table = TomlLenses.(key "src" |-- table |-- key build |-- table) in
  let files = Sys.readdir dir |> Array.to_list in
  let deps = get_build_deps builds_conf build in
  let external_targets = calculate_external_targets ".." builds_conf builds deps in
  let ml_files = File_set.of_list (List.filter (endswith ".ml") files) in
  let mli_files = File_set.of_list (List.filter (endswith ".mli") files) in
  let oc = open_out (Filename.concat dir "Makefile") in
  let lib_modules = calculate_lib_modules mli_files in
  let non_lib_modules = calculate_non_lib_modules ml_files mli_files in
  let byte_targets = calculate_byte_target build build_type in
  let native_targets = calculate_native_target build build_type in
  let extra_compiler_opts =
    value_opt
      ~default:""
      TomlLenses.(get
                    builds_conf
                    (build_table |-- key "extra_compiler_opts" |-- string))
  in
  let extra_ocamldep_opts =
    value_opt
      ~default:""
      TomlLenses.(get
                    builds_conf
                    (build_table |-- key "extra_ocamldep_opts" |-- string))
  in
  output_string
    oc
    (String.concat
       "\n\n"
       [ "CAMLP4="
       ; "PACKAGES=" ^ String.concat " " deps
       ; "LIB_MODULES=" ^ String.concat " " lib_modules
       ; "NON_LIB_MODULES=" ^ String.concat " " non_lib_modules
       ; "EXTERNAL_DEPS=" ^ String.concat " \\\n\t" external_targets
       ; "BYTE_TARGETS=" ^ byte_targets
       ; "NATIVE_TARGETS=" ^ native_targets
       ; "EXTRA_COMPILER_OPTS=" ^ extra_compiler_opts
       ; "EXTRA_OCAMLDEP_OPTS=" ^ extra_ocamldep_opts
       ; value_exn ~msg:"Error finding makefile template" (Pds_template.read src_makefile)
       ]);
  output_char oc '\n';
  let install =
    value_exn
      ~msg:"install is required for all builds"
      TomlLenses.(get builds_conf (build_table |-- key "install" |-- bool))
  in
  let install_output =
    match (get_build_type builds_conf build, install) with
      | (`Library, true) ->
        ["all: META"; ""; "install: install_lib"; ""; "remove: remove_lib"]
      | (`Library, false) ->
        ["all: META"; ""; "install: all"; ""; "remove:"]
      | (`Exec, true) ->
        let install_cmd =
          value_exn
            ~msg:"Installing executables requires an install_cmd"
            TomlLenses.(get builds_conf (build_table |-- key "install_cmd" |-- string))
        in
        (*
         * Currently we do not make use of remove_cmd as it's only really
         * valuable for the opam package
         *)
        let remove_cmd =
          value_exn
            ~msg:"Installing executables requires a remove_cmd"
            TomlLenses.(get builds_conf (build_table |-- key "remove_cmd" |-- string))
        in
        ["install: all"; "\t" ^ install_cmd; ""; "remove:"; "\t" ^ remove_cmd]
      | (`Exec, false) ->
        ["install: all"; ""; "remove:"]
  in
  output_string oc (String.concat "\n" install_output);
  let extra_makefile_lines =
    value_opt
      ~default:[]
      TomlLenses.(get builds_conf (build_table |-- key "extra_makefile_lines" |-- array |-- strings))
  in
  output_string
    oc
    (String.concat
       "\n\n"
       ([""] @ extra_makefile_lines @ ["include ../../Ocamlrules.mk.in"]));
  output_char oc '\n';
  close_out oc

  let emit_build builds_conf builds build =
    match get_project_type builds_conf build with
      | `Third_party ->
      (* Nothing to do for third-party builds *)
      ()
    | `Ocaml ->
      emit_ocaml_build (get_build_type builds_conf build) builds_conf builds build

let emit_builds builds_conf builds =
  List.iter (emit_build builds_conf builds) builds

(*
 * Emit a test Makefile.  Like emiting an ocaml makefile, this does some
 * dependency calculation, specifically so th test gets rebuilt if one of the
 * things it depends on changes.
 *)
let emit_test_makefile builds_conf builds test =
  let test_path = Filename.concat tests_dir test in
  let oc = open_out (Filename.concat test_path "Makefile") in
  let files = Sys.readdir test_path |> Array.to_list |> List.filter (endswith ".ml") in
  let deps = get_test_deps builds_conf test in
  let external_targets =
    calculate_external_targets
      (Filename.concat ".." (Filename.concat ".." src_dir))
      builds_conf
      builds
      deps
  in
  output_string
    oc
    (String.concat
       "\n\n"
       [ "PACKAGES=" ^ (String.concat " " deps)
       ; "TEST_MODULES=" ^ (String.concat " " files)
       ; "EXTERNAL_DEPS=" ^ (String.concat "\\\n\t" external_targets)
       ]);
  output_string oc "\n\n";
  output_string
    oc
    (value_exn
       ~msg:"Could not load test makefile template"
       (Pds_template.read test_makefile));
  close_out oc

let emit_tests builds_conf builds tests =
  List.iter (emit_test_makefile builds_conf builds) tests

let emit_pds_mk_deps oc builds_conf builds =
  List.iter
    (fun b ->
      let build_deps = get_build_deps builds_conf b in
      let internal_deps = List.filter (fun b -> is_internal_package b builds) build_deps in
      let all_deps = internal_deps @ get_compile_build_deps builds_conf b in
      match all_deps with
        | [] -> ()
        | deps -> fprintf oc "%s: %s\n\n" b (String.concat " " deps))
    builds

(*
 * pds.mk orchestrate running tests and building.  This contains all of the
 * dependency information between builds, which order they should be built in,
 * etc.
 *)
let emit_pds_mk builds_conf builds tests =
  let oc = open_out pds_mk in
  let test_targets = List.map (fun t -> "test_" ^ t) tests in
  let test_clean_targets = List.map (fun t -> "test_clean_" ^ t) tests in
  fprintf oc "all:\n\nPROJECTS = %s\n\n" (String.concat " " builds);
  emit_pds_mk_deps oc builds_conf builds;
  output_string oc (value_exn ~msg:"Could not load pds.mk template" (Pds_template.read pds_mk));
  output_char oc '\n';
  fprintf oc "test: all %s\n\n" (String.concat " " test_targets);
  fprintf oc "test_clean: %s\n\n" (String.concat " " test_clean_targets);
  List.iter
    (fun t ->
      let path = Filename.concat tests_dir t in
      fprintf oc "test_%s: all\n\t$(MAKE) -C %s test\n\n" t path;
      fprintf oc "test_clean_%s:\n\t$(MAKE) -C %s clean\n\n" t path)
    tests;
  close_out oc

let emit_ocamlrules_mk () =
  let oc = open_out ocamlrules_mk in
  output_string
    oc
    (value_exn ~msg:"Could not load Ocamlrules.mk" (Pds_template.read ocamlrules_mk));
  close_out oc

let main () =
  let builds_conf = load_builds_conf () in
  let builds = get_builds () in
  emit_builds builds_conf builds;
  let tests = get_tests () in
  emit_tests builds_conf builds tests;
  emit_pds_mk builds_conf builds tests;
  emit_ocamlrules_mk ()

let () = main ()
