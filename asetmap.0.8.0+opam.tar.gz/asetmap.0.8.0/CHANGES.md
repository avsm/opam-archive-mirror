v0.8.0 2016-08-26 Zagreb
------------------------

First release. 
