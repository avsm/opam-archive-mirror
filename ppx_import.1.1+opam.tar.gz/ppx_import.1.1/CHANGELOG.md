Changelog
=========

1.0
---

  * Allow extracting types from module types.

0.1
---

  * Initial release.
