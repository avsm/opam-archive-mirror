fun a -> x <- !x + 1; x <- !x + 2
