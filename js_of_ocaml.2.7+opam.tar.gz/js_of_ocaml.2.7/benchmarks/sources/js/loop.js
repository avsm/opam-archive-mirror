for (var i = 1; i <= 1000000000; i++) {};
//for (var i = 1;;) {i=i+1|0; if (i <= 1000000000) continue; break;};
//for (var i = 1; i <= 1000000000; i=i+1|0) {};
//for (var i = 1; i <= 1000000000; i=i+1) {};

