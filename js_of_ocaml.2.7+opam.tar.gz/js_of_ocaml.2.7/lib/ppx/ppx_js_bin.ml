
let () = Ast_mapper.run_main Ppx_js.js_mapper
