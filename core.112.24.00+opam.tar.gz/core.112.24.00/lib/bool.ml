include Core_kernel.Bool
