#!/bin/sh

cd /src
opam pin add vchan . -y
