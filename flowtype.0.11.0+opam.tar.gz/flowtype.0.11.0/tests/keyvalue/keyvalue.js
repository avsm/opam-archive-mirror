var files = new FileList();
var x: number = files[""];
