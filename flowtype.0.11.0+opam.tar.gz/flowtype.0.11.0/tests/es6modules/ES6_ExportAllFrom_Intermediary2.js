/**
 * @providesModule ES6_ExportAllFrom_Intermediary2
 * @flow
 */

export * from "ES6_ExportAllFrom_Source2";
