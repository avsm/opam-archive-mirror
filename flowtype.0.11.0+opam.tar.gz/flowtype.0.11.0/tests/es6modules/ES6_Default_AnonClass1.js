/**
 * @providesModule ES6_Default_AnonClass1
 * @flow
 */

// TODO: Support anonymous class declarations
//export default class { givesANum(): number { return 42; }};
