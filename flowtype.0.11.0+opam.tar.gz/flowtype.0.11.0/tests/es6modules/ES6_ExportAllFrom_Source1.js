/**
 * @providesModule ES6_ExportAllFrom_Source1
 * @flow
 */

export var numberValue1 = 1;
