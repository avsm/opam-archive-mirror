/**
 * @providesModule CommonJS_Clobbering_Lit
 * @flow
 */

module.exports = {
  numberValue1: 1,
  numberValue2: 2,
  numberValue3: 3,
  numberValue4: 4,
  numberValue5: 5
};
