# 1 "lexformat.mll"
 
open Lexing

type ctype =
    | Cd (* [d], [i], [n], [l], [L], or [N]: convert an integer
	    argument to signed decimal. *)
    | Cu (* [u]: convert an integer argument to unsigned decimal. *)
    | Cx (* [x]: convert an integer argument to unsigned hexadecimal, 
	   using lowercase letters. *)
    | CX (* [X]: convert an integer argument to unsigned hexadecimal, 
	    using uppercase letters. *)
    | Co (* [o]: convert an integer argument to unsigned octal. *)
    | Cs (* [s]: insert a string argument. *)
    | CS (* [S]: insert a string argument in Caml syntax (double
	    quotes, escapes). *)
    | Cc (* [c]: insert a character argument. *)
    | CC (* [C]: insert a character argument in Caml syntax (single
	    quotes, escapes). *)
    | Cf (* [f]: convert a floating-point argument to decimal notation,
	    in the style [dddd.ddd]. *)
    | CF (* [F]: convert a floating-point argument to Caml syntax ([dddd.]
	    or [dddd.ddd] or [d.ddd e+-dd]). *)
    | Ce | CE (* [e] or [E]: convert a floating-point argument to decimal
	    notation, in the style [d.ddd e+-dd] (mantissa and
	    exponent). *)
    | Cg | CG (* [g] or [G]: convert a floating-point argument to decimal
	    notation, in style [f] or [e], [E] (whichever is more
	    compact). *)
    | CB (* [B]: convert a boolean argument to the string [true] or
	    [false] *)
    | Cld | Clu | Clx | ClX | Clo 
          (* [ld], [li], [lu], [lx], [lX], [lo]: convert an [int32]
	     argument to the format specified by the second letter
	     (decimal, hexadecimal, etc). *)
    | Cnd | Cnu | Cnx | CnX | Cno
	  (* [nd], [ni], [nu], [nx], [nX], [no]: convert a
	     [nativeint] argument to the format specified by the
	     second letter. *)
    | CLd | CLu | CLx | CLX | CLo
	  (* [Ld], [Li], [Lu], [Lx], [LX], [Lo]: convert an
	     [int64] argument to the format specified by the
	     second letter. *)
    | Ca (* [a]: user-defined printer. Takes two arguments and applies the
	    first one to [outchan] (the current output channel) and to the
	    second argument. The first argument must therefore have type
	    [out_channel -> 'b -> unit] and the second ['b].
	    The output produced by the function is inserted in the output of
	    [fprintf] at the current point. *)
    | Ct (* [t]: same as [%a], but takes only one argument (with type
	    [out_channel -> unit]) and apply it to [outchan]. *)
    | Cformat of t
	(* [\{ fmt %\}]: convert a format string argument. The argument must
	   have the same type as the internal format string [fmt]. *)
    | Cformat_subst of t
	(* [( fmt %)]: format string substitution. Takes a format string
	   argument and substitutes it to the internal format string [fmt]
	   to print following arguments. The argument must have the same
	   type as [fmt]. *)
    | Cflush (* [!]: take no argument and flush the output. *)
    | Cpercent (* [%]: take no argument and output one [%] character. *)

and flag =
    | Fminus
    | Fzero
    | Fplus
    | Fspace
    | Fsharp

and width_precision =
    | WPint of int
    | WPstar

and inlined_arg = 
    | Arg_expr of string
    | Arg_var of string
    | Arg_rex_ref of char
        
and conversion = {
  flags : flag list;
  width : width_precision option;
  precision : width_precision option option; 
    (** Some (Some _) : ".1", ".*"
	Some None : "."
	None : "" *)
  ctype : ctype;
  inlined_arg : (inlined_arg * int (* pos *)) option;
}

and token =
    | String of string (* invariant: no $ % *)
    | Char of char (* invariant: no $ % *)
    | Conv of conversion
    | Escaped of char

and t = token list

let flag_to_char = function
  | Fminus -> '-'
  | Fzero -> '0'
  | Fplus -> '+'
  | Fspace -> ' '
  | Fsharp -> '#'

let width_precision_to_string = function
  | WPint n -> string_of_int n
  | WPstar -> "*"

let option_to_string f = function
  | Some v -> f v
  | None -> ""

(*
   [% \[${arg_inlined}\] \[flags\] \[width\] \[.precision\] type]

  $var => %${var}s
  ${exp} => %${exp}s 
*)

let rec ctype_to_string = function
  | Cd -> "d"
  | Cu -> "u"
  | Cx -> "x"
  | CX -> "X"
  | Co -> "o"
  | Cs -> "s"
  | CS -> "S"
  | Cc -> "c"
  | CC -> "C"
  | Cf -> "f"
  | CF -> "F"
  | Ce -> "e"
  | CE -> "E"
  | Cg -> "g"
  | CG -> "G"
  | CB -> "B"
  | Cld -> "ld"
  | Clu -> "lu"
  | Clx -> "lx"
  | ClX -> "lX"
  | Clo -> "lo"
  | Cnd -> "nd"
  | Cnu -> "nu"
  | Cnx -> "nx"
  | CnX -> "nX"
  | Cno -> "no"
  | CLd -> "Ld"
  | CLu -> "Lu"
  | CLx -> "Lx"
  | CLX -> "LX"
  | CLo -> "Lo"
  | Ca -> "a"
  | Ct -> "t"
  | Cformat t -> Printf.sprintf "{%s%%}" (to_string t)
  | Cformat_subst t -> Printf.sprintf "(%s%%)" (to_string t)
  | Cflush -> "%!"
  | Cpercent -> "%%"

and conversion_to_string conv =
  let buf = Buffer.create 2 in
  Buffer.add_char buf '%';
  List.iter 
    (fun f -> Buffer.add_char buf (flag_to_char f))
    conv.flags;
  (match conv.inlined_arg with
  | None -> ()
  | Some (Arg_expr s, _pos) -> 
      Buffer.add_string buf "${";
      Buffer.add_string buf s;
      Buffer.add_string buf "}"
  | Some (Arg_var s, _pos) -> 
      Buffer.add_string buf "$";
      Buffer.add_string buf s;
      Buffer.add_string buf ""
  | Some (Arg_rex_ref char, _pos) -> 
      Buffer.add_string buf "$";
      Buffer.add_char buf char;
      Buffer.add_string buf "");
  Buffer.add_string buf 
    (option_to_string width_precision_to_string conv.width);
  (match conv.precision with
  | None -> ()
  | Some p ->
      Buffer.add_char buf '.';
      Buffer.add_string buf (option_to_string width_precision_to_string p));
  Buffer.add_string buf (ctype_to_string conv.ctype);
  Buffer.contents buf
    
and compile_conversion conv =
  let tokens = 
    let buf = Buffer.create 2 in
    let token_flags = 
      Buffer.add_char buf '%';
      List.iter 
        (fun f -> Buffer.add_char buf (flag_to_char f))
        conv.flags;
      `String (Buffer.contents buf)
    in
    let token_width =
      match conv.width with
      | None -> `String ""
      | Some WPint n -> `String (string_of_int n)
      | Some WPstar -> `Star
    in
    let tokens_precision =
      match conv.precision with
      | None -> [`String ""]
      | Some None -> [`String "."]
      | Some (Some (WPint n)) -> [`String ("." ^ string_of_int n)]
      | Some (Some WPstar) -> [`String "."; `Star]
    in
    let token_type = `String (ctype_to_string conv.ctype) in
    token_flags :: token_width :: tokens_precision @ [token_type]
  in
  let rec simplif string tokens = function
    | `String s :: xs -> simplif (string ^ s) tokens xs
    | `Star :: xs ->
	if string = "" then simplif "" (`Star :: tokens) xs
	else simplif "" (`Star :: `String string :: tokens) xs
    | [] -> 
	let tokens = 
	  if string = "" then tokens
	  else `String string :: tokens
	in
	List.rev tokens
  in
  simplif "" [] tokens

and token_to_string = function
  | String s -> s
  | Escaped '"' -> "\\\""
  | Escaped '\\' -> "\\\\"
  | Char char | Escaped char -> String.make 1 char
  | Conv conv -> conversion_to_string conv

and to_string tokens =
  (* CR jfuruse: Char tends to continue! Inefficient! Use Buffer! *)
  String.concat "" (List.map token_to_string tokens)

exception Error of int * int * string

let errorf lexbuf fmt =
  Printf.ksprintf (fun s -> raise (Error (lexeme_start lexbuf, lexeme_end lexbuf, s)))
    fmt

let errorf_at start end_ fmt =
  Printf.ksprintf (fun s -> raise (Error (start, end_, s)))
    fmt

let check_conversion lexbuf conv =
  let no_inlined_arg () =
    if conv.inlined_arg <> None then
      errorf lexbuf "This conversion cannot take an inlined argument"
  in
  let no_flag_width_precision () =
    if conv.flags <> [] then 
      errorf lexbuf "This conversion cannot take flags";
    if conv.width <> None then
      errorf lexbuf "This conversion cannot take a width";
    if conv.precision <> None then
      errorf lexbuf "This conversion cannot take a precision";
  in
  (* just no perfect quick checks *)
  begin match conv.ctype with
  | Cflush | Cpercent | Ca ->
      no_inlined_arg ();
      no_flag_width_precision ()
  | Ct ->
      no_flag_width_precision ()
  | _ -> ()
  end;
  conv
;;

# 276 "lexformat.ml"
let __ocaml_lex_tables = {
  Lexing.lex_base = 
   "\000\000\217\255\218\255\219\255\220\255\221\255\222\255\223\255\
    \239\255\240\255\241\255\242\255\243\255\244\255\245\255\246\255\
    \247\255\248\255\249\255\250\255\251\255\252\255\253\255\254\255\
    \255\255\007\000\021\000\025\000\229\255\230\255\231\255\232\255\
    \233\255\234\255\235\255\236\255\237\255\238\255\224\255\225\255\
    \226\255\227\255\228\255\001\000\003\000\255\255\000\000\251\255\
    \252\255\253\255\254\255\255\255\004\000\254\255\098\000\001\000\
    \255\255\118\000\253\255\254\255\209\000\000\000\255\255\014\000\
    \248\255\249\255\084\000\254\255\255\255\250\255\037\001\135\000\
    \253\255\060\001\070\001\252\255\092\001\251\255\012\000\250\255\
    \175\000\004\000\255\255\254\255";
  Lexing.lex_backtrk = 
   "\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\000\000\000\000\000\000\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\005\000\255\255\
    \255\255\255\255\255\255\255\255\002\000\255\255\000\000\001\000\
    \255\255\003\000\255\255\255\255\000\000\001\000\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\005\000\005\000\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \003\000\002\000\255\255\255\255";
  Lexing.lex_default = 
   "\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\255\255\255\255\255\255\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\255\255\255\255\000\000\255\255\000\000\
    \000\000\000\000\000\000\000\000\255\255\000\000\255\255\255\255\
    \000\000\255\255\000\000\000\000\255\255\255\255\000\000\067\000\
    \000\000\000\000\069\000\000\000\000\000\000\000\255\255\255\255\
    \000\000\255\255\255\255\000\000\255\255\000\000\080\000\000\000\
    \080\000\255\255\000\000\000\000";
  Lexing.lex_trans = 
   "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \048\000\003\000\000\000\047\000\062\000\002\000\044\000\000\000\
    \004\000\000\000\000\000\049\000\045\000\051\000\053\000\056\000\
    \050\000\000\000\065\000\068\000\054\000\054\000\054\000\054\000\
    \054\000\054\000\054\000\054\000\054\000\054\000\000\000\000\000\
    \000\000\000\000\009\000\016\000\000\000\012\000\014\000\010\000\
    \000\000\000\000\000\000\000\000\025\000\000\000\024\000\000\000\
    \000\000\000\000\000\000\018\000\000\000\000\000\000\000\000\000\
    \021\000\000\000\000\000\000\000\000\000\000\000\000\000\039\000\
    \000\000\007\000\008\000\017\000\024\000\013\000\015\000\011\000\
    \081\000\024\000\066\000\042\000\026\000\034\000\027\000\020\000\
    \042\000\029\000\000\000\019\000\006\000\023\000\038\000\000\000\
    \022\000\037\000\000\000\005\000\041\000\032\000\037\000\040\000\
    \045\000\083\000\032\000\000\000\033\000\000\000\000\000\000\000\
    \028\000\082\000\036\000\000\000\000\000\035\000\031\000\000\000\
    \000\000\030\000\054\000\054\000\054\000\054\000\054\000\054\000\
    \054\000\054\000\054\000\054\000\059\000\059\000\000\000\000\000\
    \000\000\059\000\000\000\000\000\000\000\000\000\059\000\059\000\
    \059\000\059\000\059\000\059\000\059\000\059\000\059\000\059\000\
    \072\000\000\000\000\000\000\000\000\000\000\000\072\000\073\000\
    \073\000\073\000\073\000\073\000\073\000\073\000\073\000\073\000\
    \073\000\000\000\072\000\071\000\000\000\000\000\072\000\000\000\
    \072\000\000\000\000\000\000\000\070\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\060\000\059\000\060\000\
    \060\000\060\000\060\000\060\000\060\000\060\000\060\000\060\000\
    \060\000\060\000\060\000\060\000\060\000\060\000\060\000\060\000\
    \060\000\060\000\060\000\060\000\060\000\060\000\060\000\060\000\
    \060\000\058\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \060\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \255\255\060\000\060\000\060\000\060\000\060\000\060\000\060\000\
    \060\000\060\000\060\000\255\255\079\000\000\000\064\000\000\000\
    \000\000\000\000\060\000\060\000\060\000\060\000\060\000\060\000\
    \060\000\060\000\060\000\060\000\060\000\060\000\060\000\060\000\
    \060\000\060\000\060\000\060\000\060\000\060\000\060\000\060\000\
    \060\000\060\000\060\000\060\000\255\255\000\000\000\000\000\000\
    \060\000\000\000\060\000\060\000\060\000\060\000\060\000\060\000\
    \060\000\060\000\060\000\060\000\060\000\060\000\060\000\060\000\
    \060\000\060\000\060\000\060\000\060\000\060\000\060\000\060\000\
    \060\000\060\000\060\000\060\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\255\255\076\000\076\000\076\000\
    \076\000\076\000\076\000\076\000\076\000\076\000\076\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\076\000\076\000\
    \076\000\076\000\076\000\076\000\074\000\074\000\074\000\074\000\
    \074\000\074\000\074\000\074\000\074\000\074\000\075\000\075\000\
    \075\000\075\000\075\000\075\000\075\000\075\000\075\000\075\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\076\000\076\000\
    \076\000\076\000\076\000\076\000\077\000\077\000\077\000\077\000\
    \077\000\077\000\077\000\077\000\077\000\077\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\077\000\077\000\077\000\
    \077\000\077\000\077\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\255\255\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\077\000\077\000\077\000\
    \077\000\077\000\077\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000";
  Lexing.lex_check = 
   "\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \046\000\000\000\255\255\046\000\061\000\000\000\043\000\255\255\
    \000\000\255\255\255\255\046\000\044\000\046\000\052\000\055\000\
    \046\000\255\255\063\000\063\000\052\000\052\000\052\000\052\000\
    \052\000\052\000\052\000\052\000\052\000\052\000\255\255\255\255\
    \255\255\255\255\000\000\000\000\255\255\000\000\000\000\000\000\
    \255\255\255\255\255\255\255\255\000\000\255\255\000\000\255\255\
    \255\255\255\255\255\255\000\000\255\255\255\255\255\255\255\255\
    \000\000\255\255\255\255\255\255\255\255\255\255\255\255\025\000\
    \255\255\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \078\000\000\000\063\000\025\000\000\000\026\000\000\000\000\000\
    \025\000\027\000\255\255\000\000\000\000\000\000\025\000\255\255\
    \000\000\026\000\255\255\000\000\025\000\027\000\026\000\025\000\
    \044\000\081\000\027\000\255\255\026\000\255\255\255\255\255\255\
    \027\000\078\000\026\000\255\255\255\255\026\000\027\000\255\255\
    \255\255\027\000\054\000\054\000\054\000\054\000\054\000\054\000\
    \054\000\054\000\054\000\054\000\057\000\057\000\255\255\255\255\
    \255\255\057\000\255\255\255\255\255\255\255\255\057\000\057\000\
    \057\000\057\000\057\000\057\000\057\000\057\000\057\000\057\000\
    \066\000\255\255\255\255\255\255\255\255\255\255\066\000\071\000\
    \071\000\071\000\071\000\071\000\071\000\071\000\071\000\071\000\
    \071\000\255\255\066\000\066\000\255\255\255\255\066\000\255\255\
    \066\000\255\255\255\255\255\255\066\000\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\057\000\057\000\057\000\
    \057\000\057\000\057\000\057\000\057\000\057\000\057\000\057\000\
    \057\000\057\000\057\000\057\000\057\000\057\000\057\000\057\000\
    \057\000\057\000\057\000\057\000\057\000\057\000\057\000\057\000\
    \057\000\057\000\255\255\255\255\255\255\255\255\255\255\255\255\
    \060\000\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \000\000\060\000\060\000\060\000\060\000\060\000\060\000\060\000\
    \060\000\060\000\060\000\080\000\078\000\255\255\063\000\255\255\
    \255\255\255\255\060\000\060\000\060\000\060\000\060\000\060\000\
    \060\000\060\000\060\000\060\000\060\000\060\000\060\000\060\000\
    \060\000\060\000\060\000\060\000\060\000\060\000\060\000\060\000\
    \060\000\060\000\060\000\060\000\080\000\255\255\255\255\255\255\
    \060\000\255\255\060\000\060\000\060\000\060\000\060\000\060\000\
    \060\000\060\000\060\000\060\000\060\000\060\000\060\000\060\000\
    \060\000\060\000\060\000\060\000\060\000\060\000\060\000\060\000\
    \060\000\060\000\060\000\060\000\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\066\000\070\000\070\000\070\000\
    \070\000\070\000\070\000\070\000\070\000\070\000\070\000\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\070\000\070\000\
    \070\000\070\000\070\000\070\000\073\000\073\000\073\000\073\000\
    \073\000\073\000\073\000\073\000\073\000\073\000\074\000\074\000\
    \074\000\074\000\074\000\074\000\074\000\074\000\074\000\074\000\
    \255\255\255\255\255\255\255\255\255\255\255\255\070\000\070\000\
    \070\000\070\000\070\000\070\000\076\000\076\000\076\000\076\000\
    \076\000\076\000\076\000\076\000\076\000\076\000\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\076\000\076\000\076\000\
    \076\000\076\000\076\000\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\080\000\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\076\000\076\000\076\000\
    \076\000\076\000\076\000\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255";
  Lexing.lex_base_code = 
   "";
  Lexing.lex_backtrk_code = 
   "";
  Lexing.lex_default_code = 
   "";
  Lexing.lex_trans_code = 
   "";
  Lexing.lex_check_code = 
   "";
  Lexing.lex_code = 
   "";
}

let rec ctype stopat lexbuf =
    __ocaml_lex_ctype_rec stopat lexbuf 0
and __ocaml_lex_ctype_rec stopat lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
# 276 "lexformat.mll"
                                          ( Cd )
# 489 "lexformat.ml"

  | 1 ->
# 277 "lexformat.mll"
        ( Cu )
# 494 "lexformat.ml"

  | 2 ->
# 278 "lexformat.mll"
        ( Cx )
# 499 "lexformat.ml"

  | 3 ->
# 279 "lexformat.mll"
        ( CX )
# 504 "lexformat.ml"

  | 4 ->
# 280 "lexformat.mll"
        ( Co )
# 509 "lexformat.ml"

  | 5 ->
# 281 "lexformat.mll"
        ( Cs )
# 514 "lexformat.ml"

  | 6 ->
# 282 "lexformat.mll"
        ( CS )
# 519 "lexformat.ml"

  | 7 ->
# 283 "lexformat.mll"
        ( Cc )
# 524 "lexformat.ml"

  | 8 ->
# 284 "lexformat.mll"
        ( CC )
# 529 "lexformat.ml"

  | 9 ->
# 285 "lexformat.mll"
        ( Cf )
# 534 "lexformat.ml"

  | 10 ->
# 286 "lexformat.mll"
        ( CF )
# 539 "lexformat.ml"

  | 11 ->
# 287 "lexformat.mll"
        ( Ce )
# 544 "lexformat.ml"

  | 12 ->
# 288 "lexformat.mll"
        ( CE )
# 549 "lexformat.ml"

  | 13 ->
# 289 "lexformat.mll"
        ( Cg )
# 554 "lexformat.ml"

  | 14 ->
# 290 "lexformat.mll"
        ( CG )
# 559 "lexformat.ml"

  | 15 ->
# 291 "lexformat.mll"
        ( CB )
# 564 "lexformat.ml"

  | 16 ->
# 292 "lexformat.mll"
        ( CB )
# 569 "lexformat.ml"

  | 17 ->
# 293 "lexformat.mll"
                    ( Cld )
# 574 "lexformat.ml"

  | 18 ->
# 294 "lexformat.mll"
         ( Clu )
# 579 "lexformat.ml"

  | 19 ->
# 295 "lexformat.mll"
         ( Clx )
# 584 "lexformat.ml"

  | 20 ->
# 296 "lexformat.mll"
         ( ClX )
# 589 "lexformat.ml"

  | 21 ->
# 297 "lexformat.mll"
         ( Clo )
# 594 "lexformat.ml"

  | 22 ->
# 298 "lexformat.mll"
                    ( Cnd )
# 599 "lexformat.ml"

  | 23 ->
# 299 "lexformat.mll"
         ( Cnu )
# 604 "lexformat.ml"

  | 24 ->
# 300 "lexformat.mll"
         ( Cnx )
# 609 "lexformat.ml"

  | 25 ->
# 301 "lexformat.mll"
         ( CnX )
# 614 "lexformat.ml"

  | 26 ->
# 302 "lexformat.mll"
         ( Cno )
# 619 "lexformat.ml"

  | 27 ->
# 303 "lexformat.mll"
                    ( CLd )
# 624 "lexformat.ml"

  | 28 ->
# 304 "lexformat.mll"
         ( CLu )
# 629 "lexformat.ml"

  | 29 ->
# 305 "lexformat.mll"
         ( CLx )
# 634 "lexformat.ml"

  | 30 ->
# 306 "lexformat.mll"
         ( CLX )
# 639 "lexformat.ml"

  | 31 ->
# 307 "lexformat.mll"
         ( CLo )
# 644 "lexformat.ml"

  | 32 ->
# 308 "lexformat.mll"
        ( Ca )
# 649 "lexformat.ml"

  | 33 ->
# 309 "lexformat.mll"
        ( Ct )
# 654 "lexformat.ml"

  | 34 ->
# 310 "lexformat.mll"
        ( 
      match format stopat [] lexbuf with
      | fmt, None -> 
          enclose '}' lexbuf;
          Cformat fmt 
      | _, Some (pos, c) ->
          errorf_at pos (pos+1) "illegal format type %C" c
    )
# 666 "lexformat.ml"

  | 35 ->
# 318 "lexformat.mll"
        ( 
      match format stopat [] lexbuf with
      | fmt, None -> 
          enclose ')' lexbuf;
          Cformat_subst fmt
      | _, Some (pos, c) -> 
          errorf_at pos (pos+1) "illegal format type %C" c
    )
# 678 "lexformat.ml"

  | 36 ->
# 326 "lexformat.mll"
        ( Cflush )
# 683 "lexformat.ml"

  | 37 ->
# 327 "lexformat.mll"
        ( Cpercent )
# 688 "lexformat.ml"

  | 38 ->
let
# 328 "lexformat.mll"
         c
# 694 "lexformat.ml"
= Lexing.sub_lexeme_char lexbuf lexbuf.Lexing.lex_start_pos in
# 328 "lexformat.mll"
           ( errorf lexbuf "illegal format type %C" c )
# 698 "lexformat.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf; 
      __ocaml_lex_ctype_rec stopat lexbuf __ocaml_lex_state

and enclose str lexbuf =
    __ocaml_lex_enclose_rec str lexbuf 43
and __ocaml_lex_enclose_rec str lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
let
# 331 "lexformat.mll"
                        s
# 711 "lexformat.ml"
= Lexing.sub_lexeme_char lexbuf (lexbuf.Lexing.lex_start_pos + 1) in
# 331 "lexformat.mll"
                           (
      if s = str then ()
      else errorf lexbuf "wrong format closing (%%%c expected)" str
    )
# 718 "lexformat.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf; 
      __ocaml_lex_enclose_rec str lexbuf __ocaml_lex_state

and flag lexbuf =
    __ocaml_lex_flag_rec lexbuf 46
and __ocaml_lex_flag_rec lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
# 337 "lexformat.mll"
        ( Some Fminus )
# 730 "lexformat.ml"

  | 1 ->
# 338 "lexformat.mll"
        ( Some Fzero )
# 735 "lexformat.ml"

  | 2 ->
# 339 "lexformat.mll"
        ( Some Fplus )
# 740 "lexformat.ml"

  | 3 ->
# 340 "lexformat.mll"
        ( Some Fspace )
# 745 "lexformat.ml"

  | 4 ->
# 341 "lexformat.mll"
        ( Some Fsharp )
# 750 "lexformat.ml"

  | 5 ->
# 342 "lexformat.mll"
       ( None )
# 755 "lexformat.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf; 
      __ocaml_lex_flag_rec lexbuf __ocaml_lex_state

and width_precision lexbuf =
    __ocaml_lex_width_precision_rec lexbuf 52
and __ocaml_lex_width_precision_rec lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
let
# 345 "lexformat.mll"
                   num
# 768 "lexformat.ml"
= Lexing.sub_lexeme lexbuf lexbuf.Lexing.lex_start_pos lexbuf.Lexing.lex_curr_pos in
# 345 "lexformat.mll"
                        ( Some (WPint (int_of_string num)) )
# 772 "lexformat.ml"

  | 1 ->
# 346 "lexformat.mll"
        ( Some WPstar )
# 777 "lexformat.ml"

  | 2 ->
# 347 "lexformat.mll"
       ( None )
# 782 "lexformat.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf; 
      __ocaml_lex_width_precision_rec lexbuf __ocaml_lex_state

and precision lexbuf =
    __ocaml_lex_precision_rec lexbuf 55
and __ocaml_lex_precision_rec lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
# 350 "lexformat.mll"
          ( Some (width_precision lexbuf) )
# 794 "lexformat.ml"

  | 1 ->
# 351 "lexformat.mll"
         ( None )
# 799 "lexformat.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf; 
      __ocaml_lex_precision_rec lexbuf __ocaml_lex_state

and dollared lexbuf =
    __ocaml_lex_dollared_rec lexbuf 57
and __ocaml_lex_dollared_rec lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
let
# 354 "lexformat.mll"
                                                                    var
# 812 "lexformat.ml"
= Lexing.sub_lexeme lexbuf lexbuf.Lexing.lex_start_pos lexbuf.Lexing.lex_curr_pos in
# 355 "lexformat.mll"
      ( 
	let pos = lexeme_start lexbuf in
	Arg_var var, pos
      )
# 819 "lexformat.ml"

  | 1 ->
let
# 359 "lexformat.mll"
                                     var
# 825 "lexformat.ml"
= Lexing.sub_lexeme_char lexbuf lexbuf.Lexing.lex_start_pos in
# 360 "lexformat.mll"
      (
	let pos = lexeme_start lexbuf in
	Arg_rex_ref var, pos
      )
# 832 "lexformat.ml"

  | 2 ->
# 365 "lexformat.mll"
      ( let pos = lexeme_start lexbuf + 1 in
        let exp = exp "" lexbuf in
	Arg_expr exp, pos
      )
# 840 "lexformat.ml"

  | 3 ->
# 369 "lexformat.mll"
       (
      errorf lexbuf "illegal $-expression"
    )
# 847 "lexformat.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf; 
      __ocaml_lex_dollared_rec lexbuf __ocaml_lex_state

and inlined_arg lexbuf =
    __ocaml_lex_inlined_arg_rec lexbuf 61
and __ocaml_lex_inlined_arg_rec lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
# 374 "lexformat.mll"
        ( Some (dollared lexbuf) )
# 859 "lexformat.ml"

  | 1 ->
# 375 "lexformat.mll"
       ( None )
# 864 "lexformat.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf; 
      __ocaml_lex_inlined_arg_rec lexbuf __ocaml_lex_state

and format specials st lexbuf =
    __ocaml_lex_format_rec specials st lexbuf 63
and __ocaml_lex_format_rec specials st lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
# 378 "lexformat.mll"
        ( 
      let inlined_arg = inlined_arg lexbuf in
      let flags = 
	let rec get_flag () = 
	  match flag lexbuf with
	  | None -> []
	  | Some f -> f :: get_flag ()
	in
	get_flag ()
      in
      let width = width_precision lexbuf in
      let precision = precision lexbuf in
      let ctype = ctype specials lexbuf in
      format specials
	(Conv (check_conversion lexbuf
		  { flags = flags;
		    width = width;
		    precision = precision;
		    ctype = ctype;
		    inlined_arg = inlined_arg }) :: st) lexbuf
    )
# 896 "lexformat.ml"

  | 1 ->
let
# 400 "lexformat.mll"
                         c
# 902 "lexformat.ml"
= Lexing.sub_lexeme_char lexbuf lexbuf.Lexing.lex_start_pos in
# 400 "lexformat.mll"
                            ( 
      if List.mem c specials then
        (* Special char. We must stop here *)
        List.rev st, Some (lexeme_start lexbuf (* the char is already loaded! *), c)
      else
        format specials (Char c :: st) lexbuf 
    )
# 912 "lexformat.ml"

  | 2 ->
let
# 408 "lexformat.mll"
                                     char
# 918 "lexformat.ml"
= Lexing.sub_lexeme_char lexbuf (lexbuf.Lexing.lex_start_pos + 1) in
# 408 "lexformat.mll"
                                           (
      format specials 
        (Escaped (match char with
        | 'n' -> '\n'
        | 't' -> '\t'
        | 'r' -> '\r'
        | 'b' -> '\b'
        | '"' | '\\' -> char
        | _ -> assert false) :: st) lexbuf
    )
# 931 "lexformat.ml"

  | 3 ->
let
# 420 "lexformat.mll"
                                          s
# 937 "lexformat.ml"
= Lexing.sub_lexeme lexbuf (lexbuf.Lexing.lex_start_pos + 2) (lexbuf.Lexing.lex_start_pos + 5) in
# 420 "lexformat.mll"
                                             (
      let c = Char.chr (Scanf.sscanf s "%o" (fun x -> x)) in (* CR jfuruse; error recovery *)
      format specials (Escaped c :: st) lexbuf
    )
# 944 "lexformat.ml"

  | 4 ->
let
# 425 "lexformat.mll"
                                                                 s
# 950 "lexformat.ml"
= Lexing.sub_lexeme lexbuf (lexbuf.Lexing.lex_start_pos + 2) (lexbuf.Lexing.lex_start_pos + 4) in
# 425 "lexformat.mll"
                                                                    (
      let c = Char.chr (Scanf.sscanf s "%x" (fun x -> x)) in (* CR jfuruse; error recovery *)
      format specials (Escaped c :: st) lexbuf
    )
# 957 "lexformat.ml"

  | 5 ->
let
# 430 "lexformat.mll"
               char
# 963 "lexformat.ml"
= Lexing.sub_lexeme_char lexbuf (lexbuf.Lexing.lex_start_pos + 1) in
# 430 "lexformat.mll"
                     (
        format specials (Escaped char :: st) lexbuf
      )
# 969 "lexformat.ml"

  | 6 ->
# 435 "lexformat.mll"
      ( 
	let exp_pos = dollared lexbuf in
	format specials
          (Conv (check_conversion lexbuf
		    { flags = [];
		      width = None;
		      precision = None;
		      ctype = Cs;
		      inlined_arg = Some exp_pos }) :: st) lexbuf 
      )
# 983 "lexformat.ml"

  | 7 ->
# 445 "lexformat.mll"
        ( List.rev st, None )
# 988 "lexformat.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf; 
      __ocaml_lex_format_rec specials st lexbuf __ocaml_lex_state

and exp st lexbuf =
    __ocaml_lex_exp_rec st lexbuf 78
and __ocaml_lex_exp_rec st lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
# 448 "lexformat.mll"
        ( st )
# 1000 "lexformat.ml"

  | 1 ->
# 449 "lexformat.mll"
          ( exp (st ^ "}") lexbuf )
# 1005 "lexformat.ml"

  | 2 ->
# 450 "lexformat.mll"
         ( exp (st ^ "\\") lexbuf )
# 1010 "lexformat.ml"

  | 3 ->
let
# 451 "lexformat.mll"
                      s
# 1016 "lexformat.ml"
= Lexing.sub_lexeme lexbuf lexbuf.Lexing.lex_start_pos lexbuf.Lexing.lex_curr_pos in
# 451 "lexformat.mll"
                         ( exp (st ^ s) lexbuf )
# 1020 "lexformat.ml"

  | 4 ->
let
# 452 "lexformat.mll"
         c
# 1026 "lexformat.ml"
= Lexing.sub_lexeme_char lexbuf lexbuf.Lexing.lex_start_pos in
# 452 "lexformat.mll"
           ( 
      errorf lexbuf "illegal char in ${exp}: %C" c )
# 1031 "lexformat.ml"

  | 5 ->
# 454 "lexformat.mll"
        ( 
      errorf lexbuf "unterminated ${exp}"
    )
# 1038 "lexformat.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf; 
      __ocaml_lex_exp_rec st lexbuf __ocaml_lex_state

;;

# 458 "lexformat.mll"
 

let from_string specials s = 
  let lexbuf = Lexing.from_string s in
  let tokens, rest = format specials [] lexbuf in
  let rems = match rest with
    | Some (pos, _) -> Some (String.sub s pos (String.length s - pos))
    | None -> None
  in
  tokens, rems
;;


let rec parameters_conv conv =
  let params_width =
    match conv.width with
    | Some WPstar -> [ `Int ]
    | Some _ | None -> []
  in
  let params_precision =
    match conv.precision with
    | Some (Some WPstar) -> [ `Int ]
    | Some (Some _ | None) | None -> []
  in
  let params_ctype, conv' =
    let params_ctype, ctype' = 
      match conv.ctype with
      | Cformat_subst t -> 
	  let params, t' = parameters t in
	  `Format :: params, Cformat_subst t'
      | _ ->
	  (match conv.ctype with
	  | Cformat_subst _ -> assert false
	  | Cd | Cu | Cx | CX | Co -> [ `Int ]
	  | Cs | CS -> [ `String ]
	  | Cc | CC -> [ `Char ]
	  | Cf | CF | Ce | CE | Cg | CG -> [ `Float ]
	  | CB -> [ `Bool ]
	  | Cld | Clu | Clx | ClX | Clo -> [ `Int32 ]
	  | Cnd | Cnu | Cnx | CnX | Cno -> [ `Natint ]
	  | CLd | CLu | CLx | CLX | CLo -> [ `Int64 ]
	  | Ca -> [ `Formatter; `Argument ]
	  | Ct -> [ `Unit_formatter ]
	  | Cformat _ -> [ `Format ]  (* ? *)
	  | Cflush -> []
	  | Cpercent -> []),
	  conv.ctype
    in
    match conv.inlined_arg with
    | None -> params_ctype, { conv with ctype = ctype' }
    | Some e -> 
	match params_ctype with
	| [] -> assert false
	| x::xs -> 
	    `Applied (x,e) :: xs, 
	    { conv with 
	      ctype = ctype';
	      inlined_arg = None }
  in
  params_width @ params_precision @ params_ctype, 
  conv'

and parameters_token token = match token with
  | String _ | Char _ | Escaped _ -> [], token
  | Conv conv -> 
      let params, conv' = parameters_conv conv in
      params, Conv conv'

and parameters t = 
  let parameters_list, t' = List.split (List.map parameters_token t) in
  List.flatten parameters_list, t'

let parameters_to_application params =
  let cntr = ref 0 in
  let rev_abss, rev_apps =
    let rec reduce (rev_abss, rev_apps) =
      match rev_abss, rev_apps with
      | x::xs, `Var y::ys when x = y -> reduce (xs, ys)
      | _ -> rev_abss, rev_apps
    in
    reduce 
      (List.fold_left (fun (rev_abss, rev_apps) -> function
	| `Applied (_, e_pos) -> rev_abss, `Applied e_pos :: rev_apps
	| _ -> 
	    incr cntr;
	    !cntr :: rev_abss, `Var !cntr :: rev_apps)
	  ([], []) params)
  in
  List.rev rev_abss, List.rev rev_apps
;;

(* CR jfuruse: bad name *)
let from_string_to_classic specials s =
  let t, rems = from_string specials s in
  let parameters, t' = parameters t in
  let application = parameters_to_application parameters in
  t, application, to_string t', rems
;;

# 1145 "lexformat.ml"
