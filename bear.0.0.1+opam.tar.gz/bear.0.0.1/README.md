Bare essentials on top of OCaml's stdlib
========================================

Experimental work in progress
