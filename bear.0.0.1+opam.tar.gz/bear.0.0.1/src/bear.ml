module Option = Bear_option

include Bear_pervasives
