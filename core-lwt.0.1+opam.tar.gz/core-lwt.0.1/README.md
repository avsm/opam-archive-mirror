Overview
========

A wrapper over lwt library in the style of Janestreet's
Core library. Start with

```ocaml
open Core_lwt.Std
```

To gen an access to `Lwt_some` module use `Some` name, e.g.,
`Lwt_stream` is accessible as `Stream`.

Documentation
=============

TBD
