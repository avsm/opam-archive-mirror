mirage-block-unix
=================

[![Build Status](https://travis-ci.org/mirage/mirage-block-unix.png?branch=master)](https://travis-ci.org/mirage/mirage-block-unix) [![Coverage Status](https://coveralls.io/repos/mirage/mirage-block-unix/badge.png?branch=master)](https://coveralls.io/r/mirage/mirage-block-unix?branch=master)

Unix implementation of the Mirage `BLOCK_DEVICE` interface.

This module provides raw I/O to files and block devices with as little
caching as possible.

E-mail: <mirageos-devel@lists.xenproject.org>
