`mirage-tcpip` provides a networking stack for the Mirage operating
system that supports IPv4, IPv6, ARPv4, DHCPv4 and TCP/IP.

* WWW: <http://openmirage.org>
* E-mail: <mirageos-devel@lists.xenproject.org>
* Issues: <https://github.com/mirage/mirage-tcpip/issues>

### License

`mirage-tcpip` is distributed under the ISC license.
