//concat SPOC.js Kernel.js Mem.js 
//# 1 "SPOC.js"
//Cuda functions
var noCuda = 1


//Provides: caml_sys_system_command
function caml_sys_system_command() {
    //console.log("caml_sys_system_command");
    return 0;
}

//Provides: spoc_cuInit
 function spoc_cuInit() {
    //console.log(" spoc_cuInit");
    return 0;
}
//Provides: spoc_cuda_compile
function spoc_cuda_compile() {
    //console.log(" spoc_cuda_compile");
    return 0;
}

//Provides: spoc_cuda_debug_compile
function spoc_cuda_debug_compile() {
    //console.log(" spoc_cuda_debug_compile");
    return 0;
}

//Provides: spoc_getCudaDevice
function spoc_getCudaDevice(i) {
    //console.log("spoc_getCudaDevice");
    return 0;
}

//Provides: spoc_getCudaDevicesCount
function spoc_getCudaDevicesCount() {
    //console.log(" spoc_getCudaDevicesCount");
    return 0;
}

///////////////

//Provides:  custom_getsizeofbool
function custom_getsizeofbool() {
    return 0;
}


var noCL = 0;

//Provides: spoc_clInit
function spoc_clInit() {
    if (window.webcl == undefined) {
      alert("Unfortunately your system does not support WebCL. " +
            "Make sure that you have both the OpenCL driver " +
            "and the WebCL browser extension installed.");
	noCL = 1;
    }
    else 
    {
        /*alert("CONGRATULATIONS! Your system supports WebCL");*/
	//console.log ("INIT OPENCL");
	noCL = 0;
    }

    return 0;
}




//Provides: spoc_getOpenCLDevice

function spoc_getOpenCLDevice(relative_i, absolute_i) {
    //console.log(" spoc_getOpenCLDevice");

 var infos = [ [ "DEVICE_ADDRESS_BITS", WebCL.DEVICE_ADDRESS_BITS ],
      [ "DEVICE_AVAILABLE", WebCL.DEVICE_AVAILABLE ],
      [ "DEVICE_COMPILER_AVAILABLE", WebCL.DEVICE_COMPILER_AVAILABLE ],
      [ "DEVICE_ENDIAN_LITTLE", WebCL.DEVICE_ENDIAN_LITTLE ],
      [ "DEVICE_ERROR_CORRECTION_SUPPORT", WebCL.DEVICE_ERROR_CORRECTION_SUPPORT ],
      [ "DEVICE_EXECUTION_CAPABILITIES", WebCL.DEVICE_EXECUTION_CAPABILITIES ],
      [ "DEVICE_EXTENSIONS", WebCL.DEVICE_EXTENSIONS ],
      [ "DEVICE_GLOBAL_MEM_CACHE_SIZE", WebCL.DEVICE_GLOBAL_MEM_CACHE_SIZE ],
      [ "DEVICE_GLOBAL_MEM_CACHE_TYPE", WebCL.DEVICE_GLOBAL_MEM_CACHE_TYPE ],
      [ "DEVICE_GLOBAL_MEM_CACHELINE_SIZE", WebCL.DEVICE_GLOBAL_MEM_CACHELINE_SIZE ],
      [ "DEVICE_GLOBAL_MEM_SIZE", WebCL.DEVICE_GLOBAL_MEM_SIZE ],
      [ "DEVICE_HALF_FP_CONFIG", WebCL.DEVICE_HALF_FP_CONFIG ],
      [ "DEVICE_IMAGE_SUPPORT", WebCL.DEVICE_IMAGE_SUPPORT ],
      [ "DEVICE_IMAGE2D_MAX_HEIGHT", WebCL.DEVICE_IMAGE2D_MAX_HEIGHT ],
      [ "DEVICE_IMAGE2D_MAX_WIDTH", WebCL.DEVICE_IMAGE2D_MAX_WIDTH ],
      [ "DEVICE_IMAGE3D_MAX_DEPTH", WebCL.DEVICE_IMAGE3D_MAX_DEPTH ],
      [ "DEVICE_IMAGE3D_MAX_HEIGHT", WebCL.DEVICE_IMAGE3D_MAX_HEIGHT ],
      [ "DEVICE_IMAGE3D_MAX_WIDTH", WebCL.DEVICE_IMAGE3D_MAX_WIDTH ],
      [ "DEVICE_LOCAL_MEM_SIZE", WebCL.DEVICE_LOCAL_MEM_SIZE ],
      [ "DEVICE_LOCAL_MEM_TYPE", WebCL.DEVICE_LOCAL_MEM_TYPE ],
      [ "DEVICE_MAX_CLOCK_FREQUENCY", WebCL.DEVICE_MAX_CLOCK_FREQUENCY ],
      [ "DEVICE_MAX_COMPUTE_UNITS", WebCL.DEVICE_MAX_COMPUTE_UNITS ],
      [ "DEVICE_MAX_CONSTANT_ARGS", WebCL.DEVICE_MAX_CONSTANT_ARGS ],
      [ "DEVICE_MAX_CONSTANT_BUFFER_SIZE", WebCL.DEVICE_MAX_CONSTANT_BUFFER_SIZE ],
      [ "DEVICE_MAX_MEM_ALLOC_SIZE", WebCL.DEVICE_MAX_MEM_ALLOC_SIZE ],
      [ "DEVICE_MAX_PARAMETER_SIZE", WebCL.DEVICE_MAX_PARAMETER_SIZE ],
      [ "DEVICE_MAX_READ_IMAGE_ARGS", WebCL.DEVICE_MAX_READ_IMAGE_ARGS ],
      [ "DEVICE_MAX_SAMPLERS", WebCL.DEVICE_MAX_SAMPLERS ],
      [ "DEVICE_MAX_WORK_GROUP_SIZE", WebCL.DEVICE_MAX_WORK_GROUP_SIZE ],
      [ "DEVICE_MAX_WORK_ITEM_DIMENSIONS", WebCL.DEVICE_MAX_WORK_ITEM_DIMENSIONS ],
      [ "DEVICE_MAX_WORK_ITEM_SIZES", WebCL.DEVICE_MAX_WORK_ITEM_SIZES ],
      [ "DEVICE_MAX_WRITE_IMAGE_ARGS", WebCL.DEVICE_MAX_WRITE_IMAGE_ARGS ],
      [ "DEVICE_MEM_BASE_ADDR_ALIGN", WebCL.DEVICE_MEM_BASE_ADDR_ALIGN ],
      [ "DEVICE_NAME", WebCL.DEVICE_NAME ],
      [ "DEVICE_PLATFORM", WebCL.DEVICE_PLATFORM ],
      [ "DEVICE_PREFERRED_VECTOR_WIDTH_CHAR", WebCL.DEVICE_PREFERRED_VECTOR_WIDTH_CHAR ],
      [ "DEVICE_PREFERRED_VECTOR_WIDTH_SHORT", WebCL.DEVICE_PREFERRED_VECTOR_WIDTH_SHORT ],
      [ "DEVICE_PREFERRED_VECTOR_WIDTH_INT", WebCL.DEVICE_PREFERRED_VECTOR_WIDTH_INT ],
      [ "DEVICE_PREFERRED_VECTOR_WIDTH_LONG", WebCL.DEVICE_PREFERRED_VECTOR_WIDTH_LONG ],
      [ "DEVICE_PREFERRED_VECTOR_WIDTH_FLOAT", WebCL.DEVICE_PREFERRED_VECTOR_WIDTH_FLOAT ],
      [ "DEVICE_PROFILE", WebCL.DEVICE_PROFILE ],
      [ "DEVICE_PROFILING_TIMER_RESOLUTION", WebCL.DEVICE_PROFILING_TIMER_RESOLUTION ],
      [ "DEVICE_QUEUE_PROPERTIES", WebCL.DEVICE_QUEUE_PROPERTIES ],
      [ "DEVICE_SINGLE_FP_CONFIG", WebCL.DEVICE_SINGLE_FP_CONFIG ],
      [ "DEVICE_TYPE", WebCL.DEVICE_TYPE ],
      [ "DEVICE_VENDOR", WebCL.DEVICE_VENDOR ],
      [ "DEVICE_VENDOR_ID", WebCL.DEVICE_VENDOR_ID ],
      [ "DEVICE_VERSION", WebCL.DEVICE_VERSION ],
      [ "DRIVER_VERSION", WebCL.DRIVER_VERSION ] ];


    var total_num_devices = 0;

    var general_info = [0];
    var opencl_info = [1];

    var specific_info = new Array (48);
    specific_info[0] = 0;

    var platform_info = [0];

    var platforms = webcl.getPlatforms ();

     for (var z in platforms) {
	var plat = platforms[z];
	var devices = plat.getDevices ();
	total_num_devices += devices.length;
    }


    var current = 0;

    platforms = webcl.getPlatforms ();
    for (var i in platforms) {
	//console.log("here "+i);
	var plat = platforms[i];
	var devices = plat.getDevices ();
	var num_devices = devices.length;
	//console.log("there "+current+" "+num_devices+" "+relative_i);
	if ( (current + num_devices) >= relative_i) {
	    for (var d in devices){
		// looking at current device
		var dev = devices[d];
		if (current == relative_i ){
		    //console.log("current ----------"+current);
		    //general info
		    general_info[1] = caml_new_string(dev.getInfo(WebCL.DEVICE_NAME));
		    //console.log (general_info[1]);
		    general_info[2] = dev.getInfo(WebCL.DEVICE_GLOBAL_MEM_SIZE);
		    general_info[3] = dev.getInfo(WebCL.DEVICE_LOCAL_MEM_SIZE);
		    general_info[4] = dev.getInfo(WebCL.DEVICE_MAX_CLOCK_FREQUENCY);
		    general_info[5] = dev.getInfo(WebCL.DEVICE_MAX_CONSTANT_BUFFER_SIZE);
		    general_info[6] = dev.getInfo(WebCL.DEVICE_MAX_COMPUTE_UNITS);
		    general_info[7] = dev.getInfo(WebCL.DEVICE_ERROR_CORRECTION_SUPPORT);
		    general_info[8] = absolute_i;

		    var context = new Array(3); //cl_contex + 2 queues
		    context[0] = webcl.createContext (dev);
		    context[1] = context[0].createCommandQueue();
		    context[2] = context[0].createCommandQueue();
		    general_info[9] = context;


		    //platform info
		    platform_info[1] = caml_new_string(plat.getInfo(WebCL.PLATFORM_PROFILE));
		    platform_info[2] = caml_new_string(plat.getInfo(WebCL.PLATFORM_VERSION));
		    platform_info[3] = caml_new_string(plat.getInfo(WebCL.PLATFORM_NAME));
		    platform_info[4] = caml_new_string(plat.getInfo(WebCL.PLATFORM_VENDOR));
		    platform_info[5] = caml_new_string(plat.getInfo(WebCL.PLATFORM_EXTENSIONS));
		    platform_info[6] = num_devices;

		    //specific info
		    var infoType = dev.getInfo(WebCL.DEVICE_TYPE);
		    var type = 0;
		    if (infoType & WebCL.DEVICE_TYPE_CPU) 
			specific_info[2] = 0;
		    if (infoType & WebCL.DEVICE_TYPE_GPU) 
			specific_info[2] = 1;
		    if (infoType & WebCL.DEVICE_TYPE_ACCELERATOR) 
			specific_info[2] = 2;
		    if (infoType & WebCL.DEVICE_TYPE_DEFAULT) 
			specific_info[2] = 3;
		    specific_info[3] = caml_new_string(dev.getInfo(WebCL.DEVICE_PROFILE));
		    specific_info[4] = caml_new_string(dev.getInfo(WebCL.DEVICE_VERSION));
		    specific_info[5] = caml_new_string(dev.getInfo(WebCL.DEVICE_VENDOR));
		    var ext = dev.getInfo(WebCL.DEVICE_EXTENSIONS);
		    specific_info[6] = caml_new_string(ext);
		    specific_info[7] = dev.getInfo(WebCL.DEVICE_VENDOR_ID);
		    specific_info[8] = dev.getInfo(WebCL.DEVICE_MAX_WORK_ITEM_DIMENSIONS);
		    specific_info[9] = dev.getInfo(WebCL.DEVICE_ADDRESS_BITS);
		    specific_info[10] = dev.getInfo(WebCL.DEVICE_MAX_MEM_ALLOC_SIZE);
		    specific_info[11] = dev.getInfo(WebCL.DEVICE_IMAGE_SUPPORT);
		    specific_info[12] = dev.getInfo(WebCL.DEVICE_MAX_READ_IMAGE_ARGS);
		    specific_info[13] = dev.getInfo(WebCL.DEVICE_MAX_WRITE_IMAGE_ARGS);
		    specific_info[14] = dev.getInfo(WebCL.DEVICE_MAX_SAMPLERS);
		    specific_info[15] = dev.getInfo(WebCL.DEVICE_MEM_BASE_ADDR_ALIGN);
		    specific_info[16] = 0;//dev.getInfo(WebCL.DEVICE_MIN_DATA_TYPE_ALIGN_SIZE);
		    specific_info[17] = dev.getInfo(WebCL.DEVICE_GLOBAL_MEM_CACHELINE_SIZE);
		    specific_info[18] = dev.getInfo(WebCL.DEVICE_GLOBAL_MEM_CACHE_SIZE);
		    specific_info[19] = dev.getInfo(WebCL.DEVICE_MAX_CONSTANT_ARGS);
		    specific_info[20] = dev.getInfo(WebCL.DEVICE_ENDIAN_LITTLE);
		    specific_info[21] = dev.getInfo(WebCL.DEVICE_AVAILABLE);
		    specific_info[22] = dev.getInfo(WebCL.DEVICE_COMPILER_AVAILABLE);
		    specific_info[23] = dev.getInfo(WebCL.DEVICE_SINGLE_FP_CONFIG);
		    specific_info[24] = dev.getInfo(WebCL.DEVICE_GLOBAL_MEM_CACHE_TYPE);
		    specific_info[25] = dev.getInfo(WebCL.DEVICE_QUEUE_PROPERTIES);
		    specific_info[26] = dev.getInfo(WebCL.DEVICE_LOCAL_MEM_TYPE);
		    specific_info[27] = 0;//dev.getInfo(WebCL.DEVICE_DOUBLE_FP_CONFIG);
		    specific_info[28] = dev.getInfo(WebCL.DEVICE_MAX_CONSTANT_BUFFER_SIZE);
		    specific_info[29] = dev.getInfo(WebCL.DEVICE_EXECUTION_CAPABILITIES);
		    specific_info[30] = 0; //dev.getInfo(WebCL.DEVICE_HALF_FP_CONFIG);
		    specific_info[31] = dev.getInfo(WebCL.DEVICE_MAX_WORK_GROUP_SIZE);
		    specific_info[32] = dev.getInfo(WebCL.DEVICE_IMAGE2D_MAX_HEIGHT);
		    specific_info[33] = dev.getInfo(WebCL.DEVICE_IMAGE2D_MAX_WIDTH);
		    specific_info[34] = dev.getInfo(WebCL.DEVICE_IMAGE3D_MAX_DEPTH);
		    specific_info[35] = dev.getInfo(WebCL.DEVICE_IMAGE3D_MAX_HEIGHT);
		    specific_info[36] = dev.getInfo(WebCL.DEVICE_IMAGE3D_MAX_WIDTH);
		    specific_info[37] = dev.getInfo(WebCL.DEVICE_MAX_PARAMETER_SIZE);
		    specific_info[38] = [0]
		    var dim_sizes = dev.getInfo(WebCL.DEVICE_MAX_WORK_ITEM_SIZES);
		    specific_info[38][1] = dim_sizes[0];
		    specific_info[38][2] = dim_sizes[1];
		    specific_info[38][3] = dim_sizes[2];

		    specific_info[39] = dev.getInfo(WebCL.DEVICE_PREFERRED_VECTOR_WIDTH_CHAR);
		    specific_info[40] = dev.getInfo(WebCL.DEVICE_PREFERRED_VECTOR_WIDTH_SHORT);
		    specific_info[41] = dev.getInfo(WebCL.DEVICE_PREFERRED_VECTOR_WIDTH_INT);
		    specific_info[42] = dev.getInfo(WebCL.DEVICE_PREFERRED_VECTOR_WIDTH_LONG);
		    specific_info[43] = dev.getInfo(WebCL.DEVICE_PREFERRED_VECTOR_WIDTH_FLOAT);
		    specific_info[44] = 0; //dev.getInfo(WebCL.DEVICE_PREFERRED_VECTOR_WIDTH_DOUBLE );
		    specific_info[45] = dev.getInfo(WebCL.DEVICE_PROFILING_TIMER_RESOLUTION);
		    specific_info[46] = caml_new_string(dev.getInfo(WebCL.DRIVER_VERSION));
		    current++;

		    break;
		}
		else 
		{
		    current++;
		}
	    }
	}
	else 
	{
	    current += num_devices;
	}
    }
    var dev = [0];
    specific_info[1] = platform_info;
    opencl_info[1] = specific_info;
    dev[1] = general_info;
    dev[2] = opencl_info;

    return dev;
    
}



//Provides: spoc_getOpenCLDevicesCount
function spoc_getOpenCLDevicesCount() {
    //console.log(" spoc_getOpenCLDevicesCount");
    var nb_devices = 0;
    var platforms = webcl.getPlatforms ();
    for (var i in platforms) {
	var plat = platforms[i];
	var devices = plat.getDevices ();
	nb_devices += devices.length;
    }
    return nb_devices;
}

//Provides: spoc_opencl_compile
function spoc_opencl_compile() {
    //console.log(" spoc_opencl_compile");
    return 0;
}

//Provides: spoc_opencl_is_available
function spoc_opencl_is_available() {
    //console.log(" spoc_opencl_is_available");
    return (!noCL);
}



//Provides: caml_thread_initialize
function caml_thread_initialize() {
    //console.log("caml_thread_initialize");
    return 0;
}


//Provides: caml_mutex_new
function caml_mutex_new() {
    //console.log("caml_mutex_new");
    return 0;
}


//Provides: caml_thread_cleanup
function caml_thread_cleanup() {
    //console.log("caml_thread_cleanup");
    return 0;
}
//# 1 "Kernel.js"
//Provides: spoc_opencl_flush
function spoc_opencl_flush(gi, queue_id) {
    //console.log("spoc_opencl_flush");
    var queue = gi[9][queue_id+1];
    queue.flush();
    gi[9][queue_id+1] = queue;
    return 0;
}

//Provides: spoc_opencl_load_param_vec
function spoc_opencl_load_param_vec(off, ker, idx, A, gi) {
    //console.log("spoc_opencl_load_param_vec");
    var d_A = A[2];
    ker.setArg (off[1], d_A);
    off[1] = off[1]+1;
    return 0;
}

//Provides: spoc_opencl_load_param_int
function spoc_opencl_load_param_int(off, ker, val, gi) {
    //console.log("spoc_opencl_load_param_int");
    ker.setArg (off[1], new Uint32Array([val]));
    off[1] = off[1]+1;
    return 0;
}

//Provides: spoc_opencl_launch_grid
function spoc_opencl_launch_grid(kern, grid, block, gi, queue_id) {
    //console.log("spoc_opencl_launch_grid");
    var gridX = grid[1];
    var gridY = grid[2];
    var gridZ = grid[3];
    
    var blockX = block[1];
    var blockY = block[2];
    var blockZ = block[3];

    var global_dimension = new Array(3);
    global_dimension[0] = gridX*blockX;
    global_dimension[1] = gridY*blockY;
    global_dimension[2] = gridZ*blockZ;


    var work_size = new Array (3);
    work_size[0] = blockX;
    work_size[1] = blockY;
    work_size[2] = blockZ;
    var ctx = gi[9];

    var queue = ctx[queue_id+1];

    if ((blockX == 1) && (blockY == 1) && (blockZ == 1))
	queue.enqueueNDRangeKernel(kern, work_size.length, null, global_dimension);
    else
	
	queue.enqueueNDRangeKernel(kern, work_size.length, null, global_dimension, 
				   work_size);

    return 0;
}


//Provides: spoc_debug_opencl_compile
function spoc_debug_opencl_compile(src, fname, gi) {
    //console.log(" spoc_debug_opencl_compile");
    //console.log(src.bytes);
    var spoc_ctx = gi[9];
    var ctx = spoc_ctx[0];
    var program = ctx.createProgram(src.bytes);
    var devs = program.getInfo(WebCL.PROGRAM_DEVICES);
    program.build(devs);
    var kernel = program.createKernel(fname.bytes);
    
    spoc_ctx[0] = ctx;
    gi[9] = spoc_ctx;
    return kernel;
}
//# 1 "Mem.js"
// Cuda functions

//Provides: spoc_init_cuda_device_vec
function spoc_init_cuda_device_vec() {
    //console.log("spoc_init_opencl_device_vec");
    return 0;
}



// WebCL

//Provides: spoc_init_opencl_device_vec
function spoc_init_opencl_device_vec() {
    //console.log("spoc_init_opencl_device_vec");
    var ret = new Array (3);
    ret[0] = 0;
    return ret;
}

function typesize (b) {
    if ((b.data instanceof Float32Array) || (b.data.constructor.name == "Float32Array"))
	return 4;
    if ((b.data instanceof Int32Array) || (b.data.constructor.name == "Int32Array"))
	return 4;
    {
	//console.log ("unimplemented vector type");
	//console.log(b.data.constructor.name);
	return 4;
    }
}

//Provides: spoc_opencl_alloc_vect
function spoc_opencl_alloc_vect(vector, nb_device, gi) {
    //console.log("spoc_opencl_alloc_vect");
    var bigarray = vector[2][1];
    var dev_vec_array = vector[4];
    var dev_vec = dev_vec_array[nb_device+1];
    var size = vector[5];
    var type_size = typesize(bigarray);
    var spoc_ctx = gi[9];
    var ctx = spoc_ctx[0];
    var spoc_ctx = gi[9];
    var ctx = spoc_ctx[0];
	
    var d_A = ctx.createBuffer(WebCL.MEM_READ_WRITE, size*type_size);
    
    dev_vec[2] = d_A;
    spoc_ctx[0] = ctx;
    gi[9] = spoc_ctx;
    return 0;
}


//Provides: spoc_opencl_cpu_to_device
function spoc_opencl_cpu_to_device(vector, nb_device, gi, queue_id) {
    //console.log("spoc_opencl_cpu_to_device");
    var bigarray = vector[2][1];
    var dev_vec_array = vector[4];
    var dev_vec = dev_vec_array[nb_device+1];
    var size = vector[5];
    var type_size = typesize(bigarray);
    var spoc_ctx = gi[9];
    var ctx=spoc_ctx[0];
    var queue=spoc_ctx[queue_id+1];
    var d_A = dev_vec[2];
    
    queue.enqueueWriteBuffer(d_A, false, 0, (size*type_size), 
			     bigarray.data);
    
    
    spoc_ctx[queue_id+1] = queue;
    spoc_ctx[0] = ctx;
    gi[9] = spoc_ctx;
    return 0;
}

//Provides: spoc_opencl_device_to_cpu
function spoc_opencl_device_to_cpu(vector, nb_device, gi, si, 
				   queue_id) {
    //console.log("spoc_opencl_device_to_cpu");
    var bigarray = vector[2][1];
    var dev_vec_array = vector[4];
    var dev_vec = dev_vec_array[nb_device+1];
    var size = vector[5];
    var type_size = typesize(bigarray);
    var spoc_ctx = gi[9];
    var ctx=spoc_ctx[0];
    var queue=spoc_ctx[queue_id+1];
    var d_A = dev_vec[2];
    var h_A = bigarray.data;
    
    queue.enqueueReadBuffer(d_A, true, 0, size*type_size, h_A);
    //console.log ("release buffer after transfer to CPU");
    d_A.release();

    spoc_ctx[queue_id+1] = queue;
    spoc_ctx[0] = ctx;
    gi[9] = spoc_ctx;
    return 0;
}
