#!/bin/sh -x

eval `opam config env`
tlstunnel --version

# TODO actually test it
