bash -ex .travis-opam.sh
## Add more stuff here
