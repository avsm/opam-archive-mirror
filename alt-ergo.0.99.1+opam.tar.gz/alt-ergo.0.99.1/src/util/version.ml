let version="0.99.1"
let release_commit = "11114fe3988a98b64e34db8c8f30455ce9f82f27"
let release_date = "Tue Dec 30 12:12:50 CET 2014"
