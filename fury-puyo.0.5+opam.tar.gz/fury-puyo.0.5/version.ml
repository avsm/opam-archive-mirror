(** Game version information *)

let string = "0.5"
