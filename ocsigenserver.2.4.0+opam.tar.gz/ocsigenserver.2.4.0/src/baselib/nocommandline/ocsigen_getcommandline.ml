let commandline  = Array.sub Sys.argv 0 1
