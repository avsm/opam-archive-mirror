Bindings to [Assimp](http://assimp.sourceforge.net), Open Asset Import Library.

Assimp is released under 3-clause BSD license.
The OCaml binding is released under CC-0 license.

Make sure assimp is installed. Then:

```shell
$ make
$ make install
```
