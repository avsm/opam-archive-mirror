void f() {
  __label__ TestLabelDecl;
  TestLabelDecl: goto TestLabelDecl;
}
