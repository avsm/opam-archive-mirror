__asm__ ("foo1");
__asm__ ("foo2");
__asm__ ("foo3");
