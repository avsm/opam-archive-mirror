(**************************************************************************)
(*                                                                        *)
(*                               GlSurf                                   *)
(*                                                                        *)
(*                   C. Raffalli, Universite de Savoie                    *)
(*                                                                        *)
(* Copyright 2003, 2004 Christohe Raffalli                                *)
(*                                                                        *)
(*  This file is part of GlSurf.                                          *)
(*                                                                        *)
(*  GlSurf is free software; you can redistribute it and/or modify        *)
(*  it under the terms of the GNU General Public License as published by  *)
(*  the Free Software Foundation; either version 2 of the License, or     *)
(*  (at your option) any later version.                                   *)
(*                                                                        *)
(*  GlSurf is distributed in the hope that it will be useful,             *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *)
(*  GNU General Public License for more details.                          *)
(*                                                                        *) 
(*  You should have received a copy of the GNU General Public License     *)
(*  along with GlSurf; if not, write to the Free Software                 *)
(*  Foundation, Inc., 59 Temple Place, Suite 330, Boston,                 *)
(*  MA  02111-1307  USA                                                   *)
(**************************************************************************)

open Vect3
open Glarrays
open Dirty
open Format

type top_info =
    Link of top_info ref
  | Component of int * int * int

let euler triangles =
  match triangles with None -> []
  | Some triangles ->
  let tbl = Hashtbl.create 10001 in
  let etbl = Hashtbl.create 10001 in
  let rec find (p : point) =
    let rec fn v = 
      match !v with
	Link v' ->
	  let v'',r = fn v' in
	  if v' != v'' then v := Link v'';
	  v'', r
      | Component _ as r -> v, r
    in
    try fn (Hashtbl.find tbl p)
    with Not_found ->
      let r = Component (1,0,0) in
      let v = ref r in
      Hashtbl.add tbl p v;
      v, r
  in
  let count_edge e =
    try
      ignore (Hashtbl.find etbl e);
      Hashtbl.remove etbl e;
      0
    with
      Not_found ->
	Hashtbl.add etbl e ();
	1
  in
  let count_edges es =
    List.fold_left (fun acc e -> acc + count_edge e) 0 es
  in
  let fn p1 p2 p3 = 
    let v1, Component (s1, t1, e1) = find p1 
    and v2, Component (s2, t2, e2) = find p2 
    and v3, Component (s3, t3, e3) = find p3 in
    let s, t, e = 
      if v1 == v2 then s1, t1, e1 else s1 + s2, t1 + t2, e1 + e2
    in
    let s, t, e =
      if v1 == v3 || v2 == v3 then s, t, e else s + s3, t + t3, e + e3
    in
    let e = e + count_edges [(if p1 < p2 then p1,p2 else p2,p1);
			     (if p2 < p3 then p2,p3 else p3,p2);
			     (if p3 < p1 then p3,p1 else p1,p3)]
    in 
    let nv = Component (s,t+1,e) in
    v1 := nv;
    if v2 != v1 then v2 := Link v1;
    if v3 != v1 && v3 != v2 then v3 := Link v1;
  in
  iter_surface_shared fn triangles;
  let all = Hashtbl.fold 
      (fun _ c l -> 
	match !c with 
	  Component(v,t,e) -> (v,t,e)::l
	| _ -> l) tbl [] in
  Hashtbl.clear tbl;
  let print_result (nbv,nbt,nbe) = 
    let r = nbv - nbe + nbt in
    print_string "Faces: "; print_int nbt;
    print_string ", Edges: "; print_int nbe;
    print_string ", Vertices: "; print_int nbv;
    print_string ", V - E + F: "; print_int r;
    print_newline ();
    r
  in
  List.map print_result all

let quality a b c =
  let x = norm (b -- a) 
  and y = norm (c -- b) 
  and z = norm (a -- c) in
  max (max x y) z /. min (min x y) z

let evaluate_quality s =
  match s with None -> 1.0, 1.0
  | Some s ->
  let worst = ref 1.0 in
  let worst_pos = ref [|0.;0.;0.;|] in
  let sum = ref 0.0 in
  let sum2 = ref 0.0 in
  let num = ref 0.0 in
  let fn a b c = 
    let c = quality a b c in
    if c > !worst then (worst := c; worst_pos := a);
    num := !num +. 1.0;
    sum := !sum +. c;
    sum2 := !sum2 +. c *. c;
  in
  iter_surface fn s;
  print_string "Worst triangle : "; print_float !worst; print_string " at "; print_vector !worst_pos; print_newline ();
  let mean = !sum /. !num in
  print_string "Average triangle : "; print_float mean; print_newline ();
  print_string "Mean deviation : "; print_float (sqrt ((!sum2 /. !num) -. mean *. mean)); print_newline ();
  !worst, mean

let area surf =
  match surf with None -> 0.0
  | Some surf ->
  let total = ref 0.0 in
  let fn v1 v2 v3 = 
    total := !total +. norm (vector_prod (v2 -- v1) (v3 -- v2))

  in
  iter_surface fn surf;
  total := !total /. 2.0;
  print_string "Area: "; print_float !total; print_newline ();
  !total

let largeur surf =
  match surf with None -> 0.0, 0.0
  | Some surf ->
  let max_largeur = ref 0.0 in
  let min_largeur = ref 1e100 in

  let fn v1 v2 v3 =
    let ma = ref 0.0 in
    let gn x1 x2 x3 =
      let d1 = norm (x1 -- v1) in
      let d2 = norm (x2 -- v1) in
      let d3 = norm (x3 -- v1) in
      let ma1 = max d1 (max d2 d3) in
      let d1 = norm (x1 -- v2) in
      let d2 = norm (x2 -- v2) in
      let d3 = norm (x3 -- v2) in
      let ma2 = max d1 (max d2 d3) in
      let d1 = norm (x1 -- v3) in
      let d2 = norm (x2 -- v3) in
      let d3 = norm (x3 -- v3) in
      let ma3 = max d1 (max d2 d3) in
      let ma' = max ma1 (max ma2 ma3) in
      if ma' > !ma then ma := ma'
    in
    iter_surface gn surf;
    if !ma > !max_largeur then max_largeur := !ma;
    if !ma < !min_largeur then min_largeur := !ma;
  in
  iter_surface fn surf;
  !max_largeur, !min_largeur

let flip_diagonals grad triangles =
  let quality x gx y gy z gz =
    (min
       (min (angle (vector_prod (y -- x) gx) (vector_prod (z -- x) gx))
	  (angle (vector_prod (x -- y) gy) (vector_prod (z -- y) gy)))
       (angle (vector_prod (x -- z) gz) (vector_prod (y -- z) gz)))
  in
  let quality2 x gx z1 gz1 y gy z2 gz2 =
    let a = quality x gx z1 gz1 y gy in
    let b = quality y gy z2 gz2 x gx in
    let e1x = (angle (vector_prod (z1 -- y) (y -- x)) gx) in
    let e1y = (angle (vector_prod (z1 -- y) (y -- x)) gy) in
    let e1z = (angle (vector_prod (z1 -- y) (y -- x)) gz1) in
    let e2x = (angle (vector_prod (z2 -- x) (x -- y)) gx) in
    let e2y = (angle (vector_prod (z2 -- x) (x -- y)) gy) in
    let e2z = (angle (vector_prod (z2 -- x) (x -- y)) gz2) in
    let d = max 
	(min (min (pi /. 3. -. e1x) (pi /. 3. -. e2x)) 
	   (min (min (pi /. 3. -. e1y) (pi /. 3. -. e2y)) 
	      (min (pi /. 3. -. e1z) (pi /. 3. -. e2z)))) 
	(min (min (e1x -. 2. *. pi /. 3.) (e2x -. 2. *. pi /. 3.)) 
	   (min (min (e1y -. 2. *. pi /. 3.) (e2y -. 2. *. pi /. 3.)) 
	      (min (e1z -. 2. *. pi /. 3.) (e2z -. 2. *. pi /. 3.)))) in
    min a (min b d)
  in
  let tbl = Hashtbl.create 1001 in
  let add edge triangle =
    try
      let l = Hashtbl.find tbl edge in
      if not (List.mem triangle l) then
	Hashtbl.replace tbl edge (triangle::l) 
    with 
      Not_found ->
	Hashtbl.add tbl edge [triangle]
  in
  let remove edge triangle =
    let l = Hashtbl.find tbl edge in
    let l = List.filter (fun t -> t != triangle) l in
    if l <> [] then Hashtbl.replace tbl edge l
	else Hashtbl.remove tbl edge
  in
  let mke x y = 
    if x < y then x, y else y, x in
  let add_all (x1, x2, x3 as t) =
    add (mke x1 x2) t;
    add (mke x1 x3) t;
    add (mke x2 x3) t;
  in
  let remove_all (x1, x2, x3 as t) =
    remove (mke x1 x2) t;
    remove (mke x1 x3) t;
    remove (mke x2 x3) t;
  in
  List.iter add_all triangles;
  let count = ref 0 in
  let nb_flip = ref 0 in
  let cmod = ref 0 in
  let q = Stack.create () in
  let pr () = 
    if !cmod mod 20 = 0 then begin 
      print_string "\rRemaining edges to test: "; 
      print_int !count; 
      print_string "           ";
      print_flush ();
    end;
    incr cmod;
  in
  print_string "Loading edges ..."; print_flush ();
  Hashtbl.iter (fun e _ -> incr count; Stack.push e q) tbl;
  
  let do_one ((x : float array),(y : float array)) t1 t2 =
    assert (t1 != t2);
    let find_third (x1, x2, x3) =
      if x == x1 then
	if y == x2 then true,x3
	else if y == x3 then false,x2 else assert false
      else if x == x2 then
	if y == x1 then false, x3
	else if y == x3 then true, x1 else assert false
      else if x == x3 then
	if y == x1 then true, x2
	else if y == x2 then false, x1 else assert false
      else assert false
    in
    let b1,z1 = find_third t1 in
    let b2,z2 = find_third t2 in
    try
      let gx = grad x and gy = grad y and gz1 = grad z1 and gz2 = grad z2 in
      let q1 = quality2 x gx z1 gz1 y gy z2 gz2 in
      let q2 = quality2 z1 gz1 x gx z2 gz2 y gy in
      if q1 < q2 && q2 > 0.0 then begin
	remove_all t1;
	remove_all t2;
	let t1' = (z1,x,z2) in 
	let t2' = (z2,y,z1) in 
	add_all t1';
	add_all t2';
	count := !count + 4;
	incr nb_flip;
	Stack.push (mke z1 x) q;
	Stack.push (mke z1 y) q;
	Stack.push (mke z2 x) q;
	Stack.push (mke z2 y) q;
	true
      end else
	false
    with Exit -> false
  in
  let rec do_all_pairs e l =
    match l with 
    | [] | [_] -> ()
    | t1::l' ->
	let rec gn acc = function
	  | [] -> acc
	  | t2::l'' ->
	      if do_one e t1 t2 then acc@l''
	      else gn (t2::acc) l''
	in
	do_all_pairs e (gn [] l')
  in
  try
    while true do
      let e = Stack.pop q in
      decr count;
      pr ();
      try 
	let l = Hashtbl.find tbl e in
	do_all_pairs e l 
      with
	Not_found -> ()
    done;
    assert false
  with Stack.Empty ->
  
  let tbt = Hashtbl.create 1001 in
  let rec fn t =
    try
      ignore (Hashtbl.find tbt t)
    with
      Not_found -> Hashtbl.add tbt t ()
  in
  print_string "\r";
  print_int !nb_flip; print_string " edges flipped                            ";
  print_newline ();
  Hashtbl.iter (fun _ l -> List.iter fn l) tbl;
  Hashtbl.fold (fun k () acc -> k::acc) tbt []
    
      
(*
let optimize_curve svertex curve keep_condition add_condition =

  let rec last = function
      [x] -> x
    | x::l -> last l
    | _ -> assert false
  in
  let closed = last curve = List.hd curve in

  let to_add = ref closed in

  let coor i = Raw.get_float svertex ~pos:i in

  let rec fn acc = function 
      x::(y::(z::_ as l') as l) ->
	if keep_condition x y z then
	  match add_condition x y with
	    Some c -> 
	      fn acc (x::c::l)
	  | None ->
	      let l = 
		if !to_add then 
		  (to_add := false; l@[y])
		else l
	      in
	      fn (y::acc) l
	else fn acc (x::l')
    | [_;y] -> y::acc
    | _ -> assert false
  in
  
  fn (if closed then [] else [List.hd curve]) curve
*)

