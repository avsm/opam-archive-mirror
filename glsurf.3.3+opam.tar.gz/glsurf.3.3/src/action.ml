(**************************************************************************)
(*                                                                        *)
(*                               GlSurf                                   *)
(*                                                                        *)
(*                   C. Raffalli, Universite de Savoie                    *)
(*                                                                        *)
(* Copyright 2003, 2004 Christohe Raffalli                                *)
(*                                                                        *)
(*  This file is part of GlSurf.                                          *)
(*                                                                        *)
(*  GlSurf is free software; you can redistribute it and/or modify        *)
(*  it under the terms of the GNU General Public License as published by  *)
(*  the Free Software Foundation; either version 2 of the License, or     *)
(*  (at your option) any later version.                                   *)
(*                                                                        *)
(*  GlSurf is distributed in the hope that it will be useful,             *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *)
(*  GNU General Public License for more details.                          *)
(*                                                                        *)
(*  You should have received a copy of the GNU General Public License     *)
(*  along with GlSurf; if not, write to the Free Software                 *)
(*  Foundation, Inc., 59 Temple Place, Suite 330, Boston,                 *)
(*  MA  02111-1307  USA                                                   *)
(**************************************************************************)

open Format
open Vect3
open Function
open Draw
open Marching_cube
open Curve
open Input_util
open Parameters
open Triangulation_tools
open Dirty
open Glarrays
open Algebra
open Optimisation
open Printf
open Interval
open Pivot
open Expression

let all_surfaces = Hashtbl.create 101
let all_vectors =  ref (Hashtbl.create 101)
let cur_stexture = ref None
let cur_ctexture = ref None

let do_delete name =
  try
    ignore (Hashtbl.find all_surfaces name);
    Hashtbl.remove all_surfaces name;
  with Not_found -> failwith ("Unknown surface: "^name)

let saved_tables = ref []

let do_begin () =
  saved_tables :=
    (!all_vectors,
     !Expr.fun_table,
     List.map (fun (_,ptr) -> !ptr) string_params,
     !cur_stexture,
     !cur_ctexture)::!saved_tables;
  all_vectors := Hashtbl.copy !all_vectors

let do_end () =
  match !saved_tables with
    [] -> failwith "No matching end"
  | (allv,allf,alls,cst,cct)::st ->
      saved_tables := st;
      all_vectors := allv;
      Expr.fun_table := allf;
      cur_stexture := cst;
      cur_ctexture := cct;
      List.iter2 (fun (_,ptr) v -> ptr := v) string_params alls

let get_string param =
  !(List.assoc param string_params)

let get_vector3 default name =
  try
    let r = Hashtbl.find !all_vectors name in
    if Array.length r != 3 then
      failwith ("Wrong size for vector "^name);
    r
  with
    Not_found -> default

let get_vector4 default name =
  try
    let r = Hashtbl.find !all_vectors name in
    if Array.length r != 4 then
      failwith ("Wrong size for vector "^name);
    r
  with
    Not_found -> default

let get_tuple3 default name =
  try
    let r = Hashtbl.find !all_vectors name in
    match r with
      [|x;y;z|] -> (x,y,z)
    | _ -> failwith ("Wrong size for vector "^name)
  with
    Not_found -> default

let get_tuple4 default name =
  try
    let r = Hashtbl.find !all_vectors name in
    match r with
      [|x;y;z;t|] -> (x,y,z,t)
    | _ -> failwith ("Wrong size for vector "^name)
  with
    Not_found -> default

let get_val default name =
  try
    let e = (StringMap.find name !Expr.fun_table).Expr.value in
    try
      Expr.eval e []
    with _ ->
      failwith ("Bad value for variable: "^name)
  with
    Not_found -> default

let get_bool default name =
  let b = get_val (if default then 1.0 else 0.0) name in
  match b with
    0.0 -> false
  | 1.0 -> true
  | _ -> failwith ("Bad value for bool variable: "^name^" is "^string_of_float b)

let fastest = 0.0 and nicest = 1.0 and dont_care = -1.0 and off = -2.0

let get_hint default name =
  let b = get_val default name in
  match b with
    0.0 -> `fastest
  | 1.0 -> `nicest
  | -1.0 -> `dont_care
  | -2.0 -> `off
  | _ -> failwith ("Bad value for hint variable: "^name^" is "^string_of_float b)

let get_int default name =
  let b = get_val ((float) default) name in
  let b' = truncate b in
  if (float) b' -. b <> 0.0 then  failwith ("Bad value for int variable: "^name^" is "^string_of_float b);
  b'

let do_make_mesh e =
  let module F =
    struct
      let f = e
      let min_size = get_val (0.01 *. !gl_size) "min_size"
      let epsilon = get_val (0.01 *. min_size) "epsilon"
      let compile = can_compile && get_bool true "compile"
      let hessian = false
      let third = false
    end
  in

  let module Fun = Function.Make_Function_From_Expr(F) in

  let transparent = get_bool false "transparent" in

  let module P = struct

    let compute_origin =
      get_vector3  (get_vector3  [|0.0;0.0;0.0|] "origin") "compute_origin"
    let compute_size = get_val (get_val 2.0 "size") "compute_size"

    let min_size = get_val (0.01 *. !gl_size) "min_size"
    let max_angle = get_val (get_val (pi /. 8.0) "max_angle") "surface_max_angle"
    let adjust_angle = get_val (pi /. 4.) "adjust_angle"
    let out_max_angle = get_val (pi /. 4.) "out_max_angle"
    let min_depth = get_int 2 "min_depth"
    let max_division_diff = get_int 2 "max_division_diff"
    let adjust_factor = get_val 2.0 "adjust_factor"
    let adjust_try_newton = get_bool true "adjust_try_newton"
    let flip = get_bool true "flip_diagonals"
    let nb_random_points = get_int 0 "nb_random_points"

    let split_cond_roots other a l =
      let test (v1,p1,g1) (v2,p2,g2) =
	let alpha = angle g1 g2 in
	alpha > a
      in
      let rec fn acc = function
	  [] -> false
	| x::l -> List.exists (test x) acc || fn (x::acc) l
      in
      fn other l

    let split_cond vertices roots =
      split_cond_roots [] max_angle roots ||
       let _,v1,_ = List.nth vertices 0 and
	   _,v2,_ = List.nth vertices 1 in
       let center = (v1 ++ v2) // 2.0 in
       let diameter = norm (v1 -- v2) in
       let dia' = diameter /. 1.5 in
       let filter_vertice signe (v,p,g) =
	 ((v > 0.0 && signe) || (v < 0.0 && not signe)) &&
	 let d = (-. v /. norm2 g) ** g in
	 norm (p ++ d -- center) < dia'
       in
       let cvg_vertices_pos = List.filter (filter_vertice true) vertices in
       let cvg_vertices_neg = List.filter (filter_vertice false) vertices in
       split_cond_roots roots out_max_angle cvg_vertices_pos ||
       split_cond_roots roots out_max_angle cvg_vertices_neg

   let split_cond_roots other a l =
      let test (p1,g1) (p2,g2) =
	let alpha = angle g1 g2 in
	alpha > a
      in
      let rec fn acc = function
	  [] -> false
	| x::l -> List.exists (test x) acc || fn (x::acc) l
      in
      fn other l

    let keep_split_cond vertices roots =
      split_cond_roots [] max_angle roots ||
       let _,v1,_ = List.nth vertices 0 and
	   _,v2,_ = List.nth vertices 1 in
       let diameter = norm (v1 -- v2) in
       let fn (_,p,g) =
	 try
	   let x = Fun.newton (diameter /. (2. *. sqrt 3.))
	       (diameter *. 10e-3) p in
	   Some(x,Fun.grad x)
	 with Not_found ->
	   None
       in
       let nr = filter_map fn vertices in
       split_cond_roots nr max_angle roots

    let treatment = fun _ _ -> ()

  end in
  let module BL = Make_mesh(P)(Fun) in
  let ts, es, ps = BL.build_mesh () in
  let front_diffuse = get_tuple4 (0.7, 0.3, 0.2, 1.0) "front_diffuse" in
  let back_diffuse = get_tuple4 (0.3, 0.7, 0.2, 1.0) "back_diffuse" in
  let line_color = get_tuple4 (1.0, 1.0, 1.0, 1.0) "line_color" in
  let line_width = get_val 2.0 "line_width" in
  let text_color = get_tuple4 (1.0, 1.0, 1.0, 1.0) "text_color" in
  let point_color = get_tuple4 (1.0, 1.0, 0.0, 1.0) "point_color" in
  let point_size = get_val 4.0 "point_size" in
  let result = {
   poly = e;
   ts = Glarrays.triangles_to_surface !cur_stexture Fun.grad ts;
   es = Glarrays.lines_to_curve es;
   ps = None;
   text = [];
   handle = Fun.handle;
   grad = Fun.grad;
   eval = Fun.value;
   hessian = Fun.hessian;
   hessian_mat = Fun.hessian_mat;
   ihessian = Fun.ihessian;
   third = Fun.third;
   newton = Fun.newton;
   next_eq = None;
   front_diffuse = front_diffuse;
   back_diffuse = back_diffuse;
   front_ambient =  get_tuple4 (0.2, 0.2, 0.2, 1.0) "front_ambient";
   back_ambient =  get_tuple4 (0.2, 0.2, 0.2, 1.0) "back_ambient";
   front_shininess =   get_val 30.0 "front_shininess";
   back_shininess =   get_val 30.0 "back_shininess";
   front_specular  =   get_tuple4 (0.3, 0.3, 0.3, 1.0) "front_specular";
   back_specular  =   get_tuple4 (0.3, 0.3, 0.3, 1.0) "back_specular";
   transparent = transparent;
   line_color = line_color;
   line_width = line_width;
   text_color = text_color;
   point_color = point_color;
   point_size = point_size;
   pov_surface_texture = get_string "pov_surface_texture";
   pov_line_texture = get_string "pov_surface_texture";
   pov_point_texture = get_string "pov_surface_texture";
   pov_poly = get_bool true "pov_poly";
   pov_isosurface = get_bool false "pov_isosurface";
   pov_grad_coef = get_val 1.5 "pov_grad_coef";
   sorigin = get_vector3  [|0.0;0.0;0.0|] "origin";
   ssize = get_val 2.0 "size";
   auto_hide = get_bool true "auto_hide";
  } in
  result

(*
let do_make_mesh_correct e =
  let module F =
    struct
      let f = e
      let min_size = get_val (0.01 *. !gl_size) "min_size"
      let epsilon = get_val (0.01 *. min_size) "epsilon"
      let compile = can_compile && get_bool true "compile"
      let hessian = true
    end
  in

  let module Fun = Function.Make_Function_From_Expr(F) in

  let transparent = get_bool false "transparent" in

  let module P = struct

    let compute_origin =
      get_vector3  (get_vector3  [|0.0;0.0;0.0|] "origin") "compute_origin"
    let compute_size = get_val (get_val 2.0 "size") "compute_size"

    let min_size = get_val (0.01 *. !gl_size) "min_size"
    let max_angle = get_val (get_val (pi /. 8.0) "max_angle") "surface_max_angle"
    let adjust_angle = get_val (pi /. 4.) "adjust_angle"
    let out_max_angle = get_val (pi /. 4.) "out_max_angle"
    let min_depth = get_int 2 "min_depth"
    let max_division_diff = get_int 2 "max_division_diff"
    let adjust_factor = get_val 2.0 "adjust_factor"
    let adjust_try_newton = get_bool true "adjust_try_newton"
    let flip = get_bool true "flip_diagonals"
    let nb_random_points = get_int 0 "nb_random_points"

    let p = Expr.develop Fun.f
    let px = Expr.develop Fun.fx
    let py = Expr.develop Fun.fy
    let pz = Expr.develop Fun.fz
    let envp = [("x",Expr.Var("x'")); ("y",Expr.Var("y'"));
		("z",Expr.Var("z'"))]
    let px' = Expr.subst px envp
    let py' = Expr.subst py envp
    let pz' = Expr.subst pz envp
    let scal = Expr.develop (Expr.Add (Expr.Mul(px, px'),
				       Expr.Add (Expr.Mul(py, py'),
						 Expr.Mul(pz, pz'))))


    let split_cond vertices _ =
      let [(_,[|x1;y1;z1|],_); (_,[|x2;y2;z2|],_); (_,[|x3;y3;z3|],_)]
	  = vertices in
      let env1 = [("x", (min x1 (min x2 x3), max x1 (max x2 x3)));
		 ("y", (min y1 (min y2 y3), max y1 (max y2 y3)));
		 ("z", (min z1 (min z2 z3), max z1 (max z2 z3)))] in
      let env2 = [("x'", (min x1 (min x2 x3), max x1 (max x2 x3)));
		 ("y'", (min y1 (min y2 y3), max y1 (max y2 y3)));
		 ("z'", (min z1 (min z2 z3), max z1 (max z2 z3)))]@env1 in
      not (is_non_zero e env1) &&
      is_positive scal env2

    let keep_split_cond vertices roots =
      true

  end in
  let module BL = Make_mesh(P)(Fun) in
  let ts, es, ps = BL.build_mesh () in
  let front_diffuse = get_tuple4 (0.7, 0.3, 0.2, 1.0) "front_diffuse" in
  let back_diffuse = get_tuple4 (0.3, 0.7, 0.2, 1.0) "back_diffuse" in
  let line_color = get_tuple4 (1.0, 1.0, 1.0, 1.0) "line_color" in
  let line_width = get_val 2.0 "line_width" in
  let text_color = get_tuple4 (1.0, 1.0, 1.0, 1.0) "text_color" in
  let point_color = get_tuple4 (1.0, 1.0, 0.0, 1.0) "point_color" in
  let point_size = get_val 4.0 "point_size" in
  let result = {
   poly = e;
   ts = Glarrays.triangles_to_surface !cur_stexture Fun.grad ts;
   es = Glarrays.lines_to_curve es;
   ps = None;
   text = [];
   handle = Fun.handle;
   grad = Fun.grad;
   eval = Fun.value;
   newton = Fun.newton;
   next_eq = None;
   front_diffuse = front_diffuse;
   back_diffuse = back_diffuse;
   front_ambient =  get_tuple4 (0.2, 0.2, 0.2, 1.0) "front_ambient";
   back_ambient =  get_tuple4 (0.2, 0.2, 0.2, 1.0) "back_ambient";
   front_shininess =   get_val 30.0 "front_shininess";
   back_shininess =   get_val 30.0 "back_shininess";
   front_specular  =   get_tuple4 (0.3, 0.3, 0.3, 1.0) "front_specular";
   back_specular  =   get_tuple4 (0.3, 0.3, 0.3, 1.0) "back_specular";
   transparent = transparent;
   line_color = line_color;
   line_width = line_width;
   text_color = text_color;
   point_color = point_color;
   point_size = point_size;
   pov_surface_texture = get_string "pov_surface_texture";
   pov_line_texture = get_string "pov_surface_texture";
   pov_point_texture = get_string "pov_surface_texture";
   pov_poly = get_bool true "pov_poly";
   pov_isosurface = get_bool false "pov_isosurface";
   pov_grad_coef = get_val 1.5 "pov_grad_coef";
   sorigin = get_vector3  [|0.0;0.0;0.0|] "origin";
   ssize = get_val 2.0 "size";
   auto_hide = get_bool true "auto_hide";
  } in
  result
*)

let optimize_curve curve prepare keep_condition add_condition add_vertex =

  let rec last = function
      [x] -> x
    | x::l -> last l
    | _ -> assert false
  in
  let closed = last curve = List.hd curve in
  let curve = List.map prepare curve in
  let to_add = ref closed in

  let rec fn force_keep = function
      x::(y::(z::_ as l') as l) ->
	if force_keep > 0 || keep_condition x y z then
	  match add_condition x y with
	    Some c ->
	      if force_keep > 30 then
		(print_string "Exceed"; print_newline (); raise Not_found);
	      fn (force_keep + 1) (x::c::l)
	  | None ->
	      let l =
		if !to_add then
		  (to_add := false; l@[y])
		else l
	      in
	      add_vertex y;
	      fn (if force_keep > 0 then force_keep - 1 else force_keep) l
	else
	  fn 0 (x::l')
    | [_;y] ->
	if not closed then add_vertex y
    | _ -> assert false
  in
  if not closed then add_vertex (List.hd curve);

  fn 0 curve;
  closed


let adapt curve poly max_angle max_proxi max_rnorm epsilon =
  print_string "start adapt"; print_newline ();
  let module M =
    struct
      let f = poly
      let epsilon = epsilon
      let compile = curve.handle <> None
      let hessian = false
      let third = false
    end
  in
  let module Poly = Make_Function_From_Expr(M) in
  let curves = match curve.es with
    None -> raise Not_found
  | Some c -> c
  in
  let vertexes = curves.cvertex in
  let new_vertexes = ref [] in
  let nindex = ref 0 in

  let prepare i =
    let x0 = Raw.gets_float vertexes ~pos:(3*i) ~len:3 in
    let x1 = Poly.newton max_float epsilon x0 in
    if angle (curve.grad x0) (Poly.grad x1) > pi /. 2. then begin
      print_string "Angle to big";
      print_newline ();
      raise Not_found;
    end;
    x1
  in
  let sgrad =
    match curve.next_eq with
      None -> assert false
    | Some s -> s.grad
  in
  let out_angle x y =
    let m = (x ++ y) // 2.0 in
    let d = vector_prod (y -- x) (sgrad m) in
    let d = d // norm d in
    let p1 = m ++ (max_proxi *. norm (y -- x)) ** d in
    let p2 = m -- (max_proxi *. norm (y -- x)) ** d in
    let g = Poly.grad m in
    max (angle g (Poly.grad p1)) (angle g (Poly.grad p2))
  in
  let add_condition x y =
    let gx = Poly.grad x and gy = Poly.grad y in
    let a = max (angle gx gy) (angle x y) in
    let b = out_angle x y in
    if a > max_angle || b > pi /. 2.0 then
      let rec fn lim x0 y0 =
	if lim > 30 then
	  (print_string "Exceed"; print_newline (); raise Not_found);
	let m = (x0 ++ y0) // 2.0 in
	let m =
	  try
	    Poly.newton max_float epsilon m
	  with Not_found ->
	    print_string "Newton_failed";
	    raise Not_found
	in
	let gm = Poly.grad m in
	let ax = max (angle gx gm) (angle x m) in
	let ay = max (angle gm gy) (angle m y) in
	if ax <= max_angle /. 2.5 && a > max_angle then
	  fn (lim + 1) m y0
	else if ay <= max_angle /. 2.5 && a > max_angle then
	  fn (lim + 1) x0 m
	else Some m
      in fn 0 x y
    else
      None
  in
  let keep_condition x y z =
    let gx = Poly.grad x and gy = Poly.grad y and gz = Poly.grad z in
    let a1 = max (angle gx gy) (angle x y) in
    let a2 = max (angle gy gz) (angle y z) in
    let b = out_angle x z in
    (a1 > max_angle /. 2.5 && a2 > max_angle /. 2.5) || b > pi /. 2.0
  in


  let do_one_component c =
    let acc = ref [] in
    let total = ref 0 in
    let add_vertex x =
      new_vertexes:=x::!new_vertexes;
      acc:=!nindex::!acc;
      incr total; incr nindex;
    in
    let rec fn acc i =
      if i < 0 then acc
      else fn ((Raw.get c i)::acc) (i - 1)
    in
    let lc = fn [] (Raw.length c - 1) in
    let closed = optimize_curve lc prepare keep_condition add_condition add_vertex in
    let component = raw_create `uint (if closed then !total + 1 else !total) in
    let pos = ref 0 in
    List.iter (fun v -> Raw.set component ~pos:!pos v; incr pos) !acc;
    if !acc = [] then begin
      print_string "Bug in action.ml (acc = [])";
      raise Not_found;
    end;
    if closed then Raw.set component ~pos:!total (List.hd !acc);
    component
  in
  let new_components = List.map do_one_component curves.celements in
  let new_vertex = raw_create `double (!nindex * 3) in
  List.iter (fun v -> decr nindex;
    Raw.sets_float new_vertex ~pos:(!nindex * 3) v) !new_vertexes;
  print_string "end adapt"; print_newline ();
  let new_curve = { cvertex = new_vertex; ctexture = None; celements = new_components } in
  { curve with
    es = Some new_curve;
    eval = Poly.value;
    grad = Poly.grad;
    newton = Poly.newton;
    handle = Poly.handle;
    poly = poly
  }

let do_adapt_curve curve poly =
  let max_angle = get_val (get_val (pi /. 8.0) "max_angle") "curve_max_angle" in
  let min_size = get_val (0.01 *. !gl_size) "min_size" in
  let epsilon = get_val (0.01 *. min_size) "epsilon" in
  let max_proxi = get_val 1.0 "max_proxi" in
  let max_rnorm = get_val 1.2 "max_rnorm" in

  adapt curve poly max_angle max_proxi max_rnorm epsilon

let do_make_curve refine surf e =
  let module F =
    struct
      let f = e
      let min_size = get_val (0.01 *. !gl_size) "min_size"
      let epsilon = get_val (0.01 *. min_size) "epsilon"
      let compile = can_compile && get_bool true "compile"
      let hessian = false
      let third = false
    end
  in

  let module Fun = Function.Make_Function_From_Expr(F) in

  let transparent = get_bool false "transparent" in

  let module P = struct
    let compute_origin =
      get_vector3  (get_vector3  [|0.0;0.0;0.0|] "origin") "compute_origin"
    let compute_size = get_val (get_val 2.0 "size") "compute_size"

    let min_size = get_val (0.01 *. !gl_size) "min_size"
    let max_angle = get_val (get_val (pi /. 8.0) "max_angle") "curve_max_angle"
    let _ = print_float max_angle; print_newline ()
    let adjust_angle = get_val (pi /. 2.0) "adjust_angle"
    let out_max_angle = get_val (pi /. 4.0) "out_max_angle"
    let min_depth = get_int 2 "min_depth"
    let max_division_diff = get_int 2 "max_division_diff"
    let adjust_factor = get_val 2.0 "adjust_factor"
    let adjust_try_newton = get_bool true "adjust_try_newton"
    let flip = get_bool true "flip_diagonals"
    let nb_random_points = get_int 0 "nb_random_points"

    let split_cond_roots nt other a l =
      let test (v1,p1,g1) (v2,p2,g2) =
	let alpha = angle (vector_prod nt g1) (vector_prod nt g2) in
	alpha > a
      in
      let rec fn acc = function
	  [] -> false
	| x::l -> List.exists (test x) acc || fn (x::acc) l
      in
      fn other l

    let split_cond_roots' nt other a l =
      let test (p1,g1) (p2,g2) =
	let alpha = angle (vector_prod nt g1) (vector_prod nt g2) in
	alpha > a
      in
      let rec fn acc = function
	  [] -> false
	| x::l -> List.exists (test x) acc || fn (x::acc) l
      in
      fn other l

    let split_cond vertices roots =
      let _,v1,_ = List.nth vertices 0 and
	  _,v2,_ = List.nth vertices 1 and
	  _,v3,_ = List.nth vertices 2 in
      let center = (v1 ++ v2 ++ v3) // 3.0 in
      let nt = surf.grad center in
      let nt = Vect3.( // ) nt (norm nt) in
      let diameter = 2.0 *. max (norm (v1 -- center)) (max (norm (v2 -- center)) (norm (v3 -- center))) in
      let filter_vertice signe (v,p,g) =
	((v > 0.0 && signe) || (v < 0.0 && not signe)) &&
	let d = -. v ** g in
(*	let d = (-. v /. norm2 g) ** g in*)
	norm (p ++ d -- center) < diameter
      in
      let cvg_vertices_pos = List.filter (filter_vertice true) vertices in
      let cvg_vertices_neg = List.filter (filter_vertice false) vertices in
      split_cond_roots nt [] max_angle roots ||
      split_cond_roots nt roots out_max_angle cvg_vertices_pos ||
      split_cond_roots nt roots out_max_angle cvg_vertices_neg

    let keep_split_cond vertices roots =
      let _,v1,_ = List.nth vertices 0 and
	  _,v2,_ = List.nth vertices 1 and
	  _,v3,_ = List.nth vertices 2 in
      let center = (v1 ++ v2 ++ v3) // 3.0 in
      let nt = surf.grad center in
      let nt = Vect3.( // ) nt (norm nt) in
      split_cond_roots' nt [] max_angle roots

    let treatment = fun _ _ -> ()
  end in
  let module BL = Make_curve(P)(Fun) in
  let refine_return =
    match refine with
      None -> None
    | Some _ -> Some (ref [])
  in

  let ts, es, ps = BL.build_curve refine_return surf in
  let front_diffuse = get_tuple4 (0.7, 0.3, 0.2, 1.0) "front_diffuse" in
  let back_diffuse = get_tuple4 (0.3, 0.7, 0.2, 1.0) "back_diffuse" in
  let line_color = get_tuple4 (1.0, 1.0, 1.0, 1.0) "line_color" in
  let line_width = get_val 2.0 "line_width" in
  let text_color = get_tuple4 (1.0, 1.0, 1.0, 1.0) "text_color" in
  let point_color = get_tuple4 (1.0, 1.0, 0.0, 1.0) "point_color" in
  let point_size = get_val 4.0 "point_size" in
  let surf =
    match refine, refine_return with
      Some name, Some ts ->
	let texture = match surf.ts with
	  None -> assert false
	| Some ts -> match ts.stexture with
	    None -> None
	  | Some(i,tbl,c,mode) ->
	      let rec fn = function
		  (fmt, id)::m -> if i == id then fmt else fn m
		| _ -> assert false
	      in
	      let fmt, typ = fn !tex_ids in
	      let fn _ = failwith "no texture for refined surface" in
	      Some(fmt,typ,fn,fn,fn,c,mode)
	in
	let refined_surf =
	  {surf with ts = Glarrays.triangles_to_surface texture surf.grad !ts}
	in
	Hashtbl.replace all_surfaces name refined_surf;
	refined_surf
    | _ -> surf
  in
  let r = {
   poly = e;
   ts = Glarrays.triangles_to_surface !cur_stexture Fun.grad ts;
   es = Glarrays.lines_to_curve es;
   ps = None;
   text = [];
   handle = Fun.handle;
   grad = Fun.grad;
   eval = Fun.value;
   hessian = Fun.hessian;
   hessian_mat = Fun.hessian_mat;
   ihessian = Fun.ihessian;
   third = Fun.third;
   newton = Fun.newton;
   next_eq = Some surf;
   front_diffuse = front_diffuse;
   back_diffuse = back_diffuse;   front_ambient =  get_tuple4 (0.2, 0.2, 0.2, 1.0) "front_ambient";
   back_ambient =  get_tuple4 (0.2, 0.2, 0.2, 1.0) "back_ambient";
   front_shininess =   get_val 30.0 "front_shininess";
   back_shininess =   get_val 30.0 "back_shininess";
   front_specular  =   get_tuple4 (0.3, 0.3, 0.3, 1.0) "front_specular";
   back_specular  =   get_tuple4 (0.3, 0.3, 0.3, 1.0) "back_specular";
   transparent = transparent;
   line_color = line_color;
   line_width = line_width;
   text_color = text_color;
   point_color = point_color;
   point_size = point_size;
   pov_surface_texture = get_string "pov_surface_texture";
   pov_line_texture = get_string "pov_surface_texture";
   pov_point_texture = get_string "pov_surface_texture";
   pov_poly = get_bool true "pov_poly";
   pov_isosurface = get_bool false "pov_isosurface";
   pov_grad_coef = get_val 1.5 "pov_grad_coef";
   sorigin = get_vector3  [|0.0;0.0;0.0|] "origin";
   ssize = get_val 2.0 "size";
   auto_hide = get_bool true "auto_hide";
  } in
  r

let do_make_curve_correct treatment refine surf e =
  let module F =
    struct
      let f = e
      let min_size = get_val (0.01 *. !gl_size) "min_size"
      let epsilon = get_val (0.01 *. min_size) "epsilon"
      let compile = can_compile && get_bool true "compile"
      let hessian = true
      let third = false
    end
  in

  let module Fun = Function.Make_Function_From_Expr(F) in

  let transparent = get_bool false "transparent" in

  let module P = struct
    open Expr

    let compute_origin =
      get_vector3  (get_vector3  [|0.0;0.0;0.0|] "origin") "compute_origin"
    let compute_size = get_val (get_val 2.0 "size") "compute_size"

    let min_size = get_val (0.01 *. !gl_size) "min_size"
    let max_angle = get_val (get_val (pi /. 8.0) "max_angle") "curve_max_angle"
    let adjust_angle = get_val (pi /. 2.0) "adjust_angle"
    let out_max_angle = get_val (pi /. 4.0) "out_max_angle"
    let min_depth = get_int 2 "min_depth"
    let max_division_diff = get_int 2 "max_division_diff"
    let adjust_factor = get_val 2.0 "adjust_factor"
    let adjust_try_newton = get_bool true "adjust_try_newton"
    let flip = get_bool true "flip_diagonals"
    let nb_random_points = get_int 0 "nb_random_points"

    let split_cond vertices _ =
	  let abs2 (mi, ma) = max (abs_float mi) (abs_float ma) in
(*
	  let absmin (mi, ma) =
	    if mi *. ma <= 0.0 then 0.0 else
	    min (abs_float mi) (abs_float ma) in
*)
	  let merge (mi,ma) (mi',ma') = min mi mi', max ma ma' in
	  let mergel (mi,ma) x = min mi x, max ma x in
	  let mergev [|x1;y1;z1|] [|x2;y2;z2|] = [|merge x1 x2; merge y1 y2; merge z1 z2|] in
(*
	  let mergec x y = min x y, max x y in
	  let mergevl [|x1;y1;z1|] [|x2;y2;z2|] = [|mergel x1 x2; mergel y1 y2; mergel z1 z2|] in
	  let mergevc [|x1;y1;z1|] [|x2;y2;z2|] = [|mergec x1 x2; mergec y1 y2; mergec z1 z2|] in
*)
	  let (|||) [|xi;yi;zi|] [| x;y;z |] =
	    Interval.addi(Interval.addi(Interval.mulil(xi,x),
					Interval.mulil(yi,y)),Interval.mulil(zi,z)) in
	  let (||||) [|xi;yi;zi|] [| x;y;z |] =
	    Interval.addi(Interval.addi(Interval.muli(xi,x),
					Interval.muli(yi,y)),Interval.muli(zi,z)) in
	  let addv [|x1;y1;z1|] [|x2;y2;z2|] = [|addil(x1, x2); addil(y1, y2); addil(z1, z2)|] in
	  let zerov = 	[|(0.0,0.0);(0.0,0.0);(0.0,0.0)|] in
	  let mulh (fxx'', fyy'', fzz'', fxy'', fxz'', fyz'') v =
	    [| Interval.addi(Interval.addi(Interval.mulil(fxx'',v.(0)),
					   Interval.mulil(fxy'',v.(1))),
			     Interval.mulil(fxz'',v.(2)));
	       Interval.addi(Interval.addi(Interval.mulil(fxy'',v.(0)),
					   Interval.mulil(fyy'',v.(1))),
			     Interval.mulil(fyz'',v.(2)));
	       Interval.addi(Interval.addi(Interval.mulil(fxz'',v.(0)),
					   Interval.mulil(fyz'',v.(1))),
			     Interval.mulil(fzz'',v.(2)))|] in

	  let [(f1,([|x1;y1;z1|] as v1),f1');
	       (f2,([|x2;y2;z2|] as v2),f2');
	       (f3,([|x3;y3;z3|] as v3),f3')]
	      = vertices in
	  let xb = (x1 +. x2 +. x3) /. 3.0 in
	  let yb = (y1 +. y2 +. y3) /. 3.0 in
	  let zb = (z1 +. z2 +. z3) /. 3.0 in
	  let h1 = [|x1 -. xb; y1 -. yb; z1 -. zb|] in
	  let h2 = [|x2 -. xb; y2 -. yb; z2 -. zb|] in
	  let h3 = [|x3 -. xb; y3 -. yb; z3 -. zb|] in
	  let (x1,x2) = min x1 (min x2 x3),  max x1 (max x2 x3) in
	  let (y1,y2) = min y1 (min y2 y3),  max y1 (max y2 y3) in
	  let (z1,z2) = min z1 (min z2 z3),  max z1 (max z2 z3) in
	  let center = [|xb;yb;zb|] in
(*
	  let f0 = Fun.value center in
*)
	  let f0' = Fun.grad center in
	  let f0'' = Fun.ihessian x1 x2 y1 y2 z1 z2 in
(*
	  let nt = surf.grad center in
	  let nt = Vect3.( // ) nt (norm nt) in
*)
	  let v12 = Vect3.(--) v2 v1 in
	  let v23 = Vect3.(--) v3 v2 in
	  let v31 = Vect3.(--) v1 v3 in
	  let t1 = [Vect3.( ** ) (-1.0) h1; Vect3.( ** ) (0.5) v12; Vect3.( ** ) (-0.5) v31] in
	  let t2 = [Vect3.( ** ) (-1.0) h2; Vect3.( ** ) (0.5) v23; Vect3.( ** ) (-0.5) v12] in
	  let t3 = [Vect3.( ** ) (-1.0) h3; Vect3.( ** ) (0.5) v31; Vect3.( ** ) (-0.5) v23] in
(*
	  let hh = mergev (mergev (mulh h1) (mulh h2)) (mulh h3) in
*)
	  let encadre_f f f' f'' hl =
	    let d1 = List.fold_left (fun a h -> mergel a (f' |. h)) (0.0,0.0) hl in
	    let dh2 = List.fold_left (fun a h -> mergev a (mulh f'' h))
		zerov hl in
	    let d2 =  List.fold_left (fun a h -> merge a (dh2 ||| h)) (0.0,0.0) hl in
	    addi(addil(d1,f),mulil(d2,0.5))
	  in
	  let encadre_f' f' f'' hl =
	    let dh2 = List.fold_left (fun a h -> mergev a (mulh f'' h)) zerov hl in
	    addv dh2 f'
	  in
(*
	  let hhh =  (max (max (abs2 (hh ||| h1))
						 (abs2 (hh ||| h2))) (abs2 (hh ||| h3))) in

	  let f0h1 = f0' || h1 in
	  let f0h2 = f0' || h2 in
	  let f0h3 = f0' || h3 in
	  let f0min = f0 +. min f0h1 (min f0h2 f0h3) -. 0.5 *. hhh in
	  let f0max = f0 +. max f0h1 (max f0h2 f0h3) +. 0.5 *. hhh in
*)
	  let f0min, f0max = merge (encadre_f f1 f1' f0'' t1)
	      (merge (encadre_f f2 f2' f0'' t2) (encadre_f f3 f3' f0'' t3)) in
(*
	  let f0min, f0max = encadre_f f0 f0' [h1;h2;h3] in
*)
	  (*Printf.printf "f0 in [%f, %f]\n" f0min f0max;*)
	  (f0min *. f0max <= 0.0) &&
(*
	  let [|ix;iy;iz|] = addv hh f0' in (* il faudrait un produit vectoriel avec la normale
                                               du triangle ou de la surface ... *)
*)
	  let [|ix;iy;iz|] as df =  encadre_f' f0' f0'' [h1;h2;h3] in
	  let numerator = fst (df |||| df)
	    (* ix *. snd ix +. fst iy *. snd iy +. fst iz *. snd iz *) in
	  (*Printf.printf "dh = %f\n" dh;*)
	  (numerator <= 0.0 ||
	  let denominator =
	    let sq x = x *. x in
	    sq (abs2 ix) +. sq (abs2 iy) +. sq (abs2 iz)
	  in
	  let v12 = Vect3.(//) v12 (norm v12) in
	  let v23 = Vect3.(//) v23 (norm v23) in
	  let v31 = Vect3.(//) v31 (norm v31) in
	  let ct = max (max (v12 |. v23) (v23 |. v31)) (v31 |. v12) in
	  numerator <= ct *. denominator)

    let keep_split_cond =
      if get_bool false "keep_all" then
	fun vertices roots -> true
      else
	fun vertices roots -> List.length roots > 2

    let treatment = treatment
  end in
  let module BL = Make_curve(P)(Fun) in
  let refine_return =
    match refine with
      None -> None
    | Some _ -> Some (ref [])
  in

  let ts, es, ps = BL.build_curve refine_return surf in
  let front_diffuse = get_tuple4 (0.7, 0.3, 0.2, 1.0) "front_diffuse" in
  let back_diffuse = get_tuple4 (0.3, 0.7, 0.2, 1.0) "back_diffuse" in
  let line_color = get_tuple4 (1.0, 1.0, 1.0, 1.0) "line_color" in
  let line_width = get_val 2.0 "line_width" in
  let text_color = get_tuple4 (1.0, 1.0, 1.0, 1.0) "text_color" in
  let point_color = get_tuple4 (1.0, 1.0, 0.0, 1.0) "point_color" in
  let point_size = get_val 4.0 "point_size" in
  let surf =
    match refine, refine_return with
      Some name, Some ts ->
	let texture = match surf.ts with
	  None -> assert false
	| Some ts -> match ts.stexture with
	    None -> None
	  | Some(i,tbl,c,mode) ->
	      let rec fn = function
		  (fmt, id)::m -> if i == id then fmt else fn m
		| _ -> assert false
	      in
	      let fmt, typ = fn !tex_ids in
	      let fn _ = failwith "no texture for refined surface" in
	      Some(fmt,typ,fn,fn,fn,c,mode)
	in
	let refined_surf =
	  {surf with ts = Glarrays.triangles_to_surface texture surf.grad !ts}
	in
	Hashtbl.replace all_surfaces name refined_surf;
	refined_surf
    | _ -> surf
  in
  let r = {
   poly = e;
   ts = Glarrays.triangles_to_surface !cur_stexture Fun.grad ts;
   es = Glarrays.lines_to_curve es;
   ps = None;
   text = [];
   handle = Fun.handle;
   grad = Fun.grad;
   eval = Fun.value;
   hessian = Fun.hessian;
   hessian_mat = Fun.hessian_mat;
   ihessian = Fun.ihessian;
   third = Fun.third;
   newton = Fun.newton;
   next_eq = Some surf;
   front_diffuse = front_diffuse;
   back_diffuse = back_diffuse;   front_ambient =  get_tuple4 (0.2, 0.2, 0.2, 1.0) "front_ambient";
   back_ambient =  get_tuple4 (0.2, 0.2, 0.2, 1.0) "back_ambient";
   front_shininess =   get_val 30.0 "front_shininess";
   back_shininess =   get_val 30.0 "back_shininess";
   front_specular  =   get_tuple4 (0.3, 0.3, 0.3, 1.0) "front_specular";
   back_specular  =   get_tuple4 (0.3, 0.3, 0.3, 1.0) "back_specular";
   transparent = transparent;
   line_color = line_color;
   line_width = line_width;
   text_color = text_color;
   point_color = point_color;
   point_size = point_size;
   pov_surface_texture = get_string "pov_surface_texture";
   pov_line_texture = get_string "pov_surface_texture";
   pov_point_texture = get_string "pov_surface_texture";
   pov_poly = get_bool true "pov_poly";
   pov_isosurface = get_bool false "pov_isosurface";
   pov_grad_coef = get_val 1.5 "pov_grad_coef";
   sorigin = get_vector3  [|0.0;0.0;0.0|] "origin";
   ssize = get_val 2.0 "size";
   auto_hide = get_bool true "auto_hide";
  } in
  r

let do_gl_start () =
  let gl_parameters = {
    origin = get_vector3  [|0.0;0.0;0.0|] "origin";
    size = get_val 2.0 "size"
  } in
  let draw_parameters = {
    lmodel_ambient  =   get_tuple4 (0.2, 0.2, 0.2, 1.0) "lmodel_ambient";
    lmodel_twoside  =   get_bool true "lmodel_twoside";
    background = get_tuple3 (0.1, 0.1, 0.3) "background";
    fog = get_hint off "fog";
    perspective_correction = get_hint fastest "perspective_correction";
    line_smooth = get_hint off "line_smooth";
    point_smooth = get_hint off "point_smooth";
    polygon_smooth = get_hint off "polygon_smooth";
    smooth_shade =  get_bool true "smooth_shade"
  } in
  start_gl gl_parameters draw_parameters


let do_draw time surfaces =
  let gl_parameters = {
    origin = get_vector3  [|0.0;0.0;0.0|] "origin";
    size = get_val 2.0 "size"
  } in
  let draw_parameters = {
    lmodel_ambient  =   get_tuple4 (0.2, 0.2, 0.2, 1.0) "lmodel_ambient";
    lmodel_twoside  =   get_bool true "lmodel_twoside";
    background = get_tuple3 (0.1, 0.1, 0.3) "background";
    fog = get_hint off "fog";
    perspective_correction = get_hint fastest "perspective_correction";
    line_smooth = get_hint off "line_smooth";
    point_smooth = get_hint off "line_smooth";
    polygon_smooth = get_hint off "polygon_smooth";
    smooth_shade =  get_bool true "smooth_shade"
  } in
  draw time gl_parameters draw_parameters surfaces

type save_option =
    Binary | Ascii | Glsurf

let save_surface save_option filename s =
  match save_option with
    Binary ->
      let ch = open_out_bin filename in
      let rec fn s =
	output_value ch s.poly;
	output_value ch s.front_diffuse;
	output_value ch s.back_diffuse;
	output_value ch s.front_ambient;
	output_value ch s.back_ambient;
	output_value ch s.front_shininess;
	output_value ch s.back_shininess;
	output_value ch s.front_specular;
	output_value ch s.back_specular;
	output_value ch s.transparent;
	output_value ch s.line_width;
	output_value ch s.line_color;
	output_value ch s.text_color;
	output_value ch s.point_size;
	output_value ch s.point_color;
	output_value ch s.pov_surface_texture;
	output_value ch s.pov_line_texture;
	output_value ch s.pov_point_texture;
	output_value ch s.pov_poly;
	output_value ch s.pov_isosurface;
	output_value ch s.pov_grad_coef;
	output_value ch s.sorigin;
	output_value ch s.ssize;
	output_value ch s.auto_hide;
	write_surface ch s.ts;
	write_curve ch s.es;
	write_points ch s.ps;
	match s.next_eq with
	  None -> output_value ch false
	| Some s' -> output_value ch true; fn s'
      in
      fn s;
      close_out ch
  | Ascii ->
      let ch = open_out filename in
      begin match s.ts with
	None -> ()
      | Some s ->
	  let size = Raw.length s.svertex in
	  fprintf ch "%d\n" (size / 3);
	  for i=0 to size - 1 do
	    fprintf ch "%f" (Raw.get_float s.svertex ~pos:i);
	    if (i+1) mod 3 = 0 then fprintf ch "\n" else fprintf ch " "
	  done;
	  let size = Raw.length s.selements in
	  fprintf ch "%d\n" (size / 3);
	  for i=0 to size - 1 do
	    fprintf ch "%d" (Raw.get s.selements ~pos:i);
	    if (i+1) mod 3 = 0 then fprintf ch "\n" else fprintf ch " "
	  done;
      end;
      close_out ch;
  | Glsurf ->
      failwith "Save option \"glsurf\" not yet implemented"


let load_surface filename =
  let ch = open_in_bin filename in
  let rec fn () =
    let poly = input_value ch in
    let module F =
      struct
	let f = poly
	let min_size = get_val (0.01 *. !gl_size) "min_size"
	let epsilon = get_val (0.01 *. min_size) "epsilon"
	let compile = can_compile && get_bool true "compile"
	let hessian = false
	let third = false
      end
    in
    let fd = input_value ch in
    let bd = input_value ch in
    let fa = input_value ch in
    let ba = input_value ch in
    let fsh = input_value ch in
    let bsh = input_value ch in
    let fsp = input_value ch in
    let bsp = input_value ch in
    let tr = input_value ch in
    let lw = input_value ch in
    let lc = input_value ch in
    let tc = input_value ch in
    let pw = input_value ch in
    let pc = input_value ch in
    let povs = input_value ch in
    let povl = input_value ch in
    let povp = input_value ch in
    let povpo = input_value ch in
    let poviso = input_value ch in
    let povgc = input_value ch in
    let ori = input_value ch in
    let size = input_value ch in
    let ts = read_surface ch in
    let es = read_curve ch in
    let ps = read_points ch in
    let ah = input_value ch in
    let module Fun = Function.Make_Function_From_Expr(F) in
    let b = input_value ch in
    let neq = if b then Some (fn ()) else None in
    {
     poly = poly;
     eval = Fun.value;
     grad = Fun.grad;
     hessian = Fun.hessian;
     hessian_mat = Fun.hessian_mat;
     ihessian = Fun.ihessian;
     third = Fun.third;
     newton = Fun.newton;
     handle = Fun.handle;
     next_eq = neq;
     front_diffuse = fd;
     back_diffuse = bd;
     front_ambient = fa;
     back_ambient = ba;
     front_shininess = fsh;
     back_shininess = bsh;
     front_specular = fsp;
     back_specular = bsp;
     transparent = tr;
     line_width = lw;
     line_color = lc;
     text_color = tc;
     point_size = pw;
     point_color = pc;
     ts = ts;
     es = es;
     ps = ps;
     text = [];
     pov_surface_texture = povs;
     pov_line_texture = povl;
     pov_point_texture = povp;
     pov_poly = povpo;
     pov_isosurface = poviso;
     pov_grad_coef = povgc;
     sorigin = ori;
     ssize = size;
     auto_hide = ah;
   }
  in
  let s = fn () in
  close_in ch;
  s

let create_point name pt =
  let rvertices = [pt] in
  let gs = None in
  let es, ps = object_to_curve_and_points rvertices [] [0] in
  let front_diffuse = get_tuple4 (0.7, 0.3, 0.2, 1.0) "front_diffuse" in
  let back_diffuse = get_tuple4 (0.3, 0.7, 0.2, 1.0) "back_diffuse" in
  let line_color = get_tuple4 (1.0, 1.0, 1.0, 1.0) "line_color" in
  let line_width = get_val 2.0 "line_width" in
  let text_color = get_tuple4 (1.0, 1.0, 1.0, 1.0) "text_color" in
  let transparent = get_bool false "transparent" in
  let point_color = get_tuple4 (1.0, 1.0, 0.0, 1.0) "point_color" in
  let point_size = get_val 4.0 "point_size" in
  let s =  {
    poly = Expr.cst Field_R.zero;
    ts = gs;
    es = es;
    ps = ps;
    text = [];
    handle = None;
    next_eq = None;
    grad = (fun _ -> failwith "not a surface");
    eval = (fun _ -> failwith "not a surface");
    hessian = (fun _ -> failwith "not a surface");
    hessian_mat = (fun _ -> failwith "not a surface");
    ihessian = (fun _ -> failwith "not a surface");
    third = (fun _ -> failwith "not a surface");
    newton = (fun _ -> failwith "not a surface");
    front_diffuse = front_diffuse;
    back_diffuse = back_diffuse;
    front_ambient =  get_tuple4 (0.2, 0.2, 0.2, 1.0) "front_ambient";
    back_ambient =  get_tuple4 (0.2, 0.2, 0.2, 1.0) "back_ambient";
    front_shininess =   get_val 30.0 "front_shininess";
    back_shininess =   get_val 30.0 "back_shininess";
    front_specular  =   get_tuple4 (0.3, 0.3, 0.3, 1.0) "front_specular";
    back_specular  =   get_tuple4 (0.3, 0.3, 0.3, 1.0) "back_specular";
    transparent = transparent;
    line_color = line_color;
    line_width = line_width;
    text_color = text_color;
    point_color = point_color;
    point_size = point_size;
    pov_surface_texture = get_string "pov_surface_texture";
    pov_line_texture = get_string "pov_surface_texture";
    pov_point_texture = get_string "pov_surface_texture";
    pov_poly = get_bool true "pov_poly";
    pov_isosurface = get_bool false "pov_isosurface";
    pov_grad_coef = get_val 1.5 "pov_grad_coef";
    sorigin = get_vector3  [|0.0;0.0;0.0|] "origin";
    ssize = get_val 2.0 "size";
    auto_hide = get_bool true "auto_hide";
  }
  in
  Hashtbl.replace all_surfaces name s;
  match ps with
    None -> assert false
  | Some ps -> s, ps.pvertex

let create_points name pts =
  let rvertices = pts in
  let length = List.length pts in
  let r = ref [] in
  for i = 0 to length - 1 do
    r := i::!r;
  done;
  let gs = None in
  let es, ps = object_to_curve_and_points rvertices [] !r in
  let front_diffuse = get_tuple4 (0.7, 0.3, 0.2, 1.0) "front_diffuse" in
  let back_diffuse = get_tuple4 (0.3, 0.7, 0.2, 1.0) "back_diffuse" in
  let line_color = get_tuple4 (1.0, 1.0, 1.0, 1.0) "line_color" in
  let line_width = get_val 2.0 "line_width" in
  let text_color = get_tuple4 (1.0, 1.0, 1.0, 1.0) "text_color" in
  let transparent = get_bool false "transparent" in
  let point_color = get_tuple4 (1.0, 1.0, 0.0, 1.0) "point_color" in
  let point_size = get_val 4.0 "point_size" in
  let s =  {
    poly = Expr.cst Field_R.zero;
    ts = gs;
    es = es;
    ps = ps;
    text = [];
    handle = None;
    next_eq = None;
    grad = (fun _ -> failwith "not a surface");
    eval = (fun _ -> failwith "not a surface");
    newton = (fun _ -> failwith "not a surface");
    hessian = (fun _ -> failwith "not a surface");
    hessian_mat = (fun _ -> failwith "not a surface");
    ihessian = (fun _ -> failwith "not a surface");
    third = (fun _ -> failwith "not a surface");
    front_diffuse = front_diffuse;
    back_diffuse = back_diffuse;
    front_ambient =  get_tuple4 (0.2, 0.2, 0.2, 1.0) "front_ambient";
    back_ambient =  get_tuple4 (0.2, 0.2, 0.2, 1.0) "back_ambient";
    front_shininess =   get_val 30.0 "front_shininess";
    back_shininess =   get_val 30.0 "back_shininess";
    front_specular  =   get_tuple4 (0.3, 0.3, 0.3, 1.0) "front_specular";
    back_specular  =   get_tuple4 (0.3, 0.3, 0.3, 1.0) "back_specular";
    transparent = transparent;
    line_color = line_color;
    line_width = line_width;
    text_color = text_color;
    point_color = point_color;
    point_size = point_size;
    pov_surface_texture = get_string "pov_surface_texture";
    pov_line_texture = get_string "pov_surface_texture";
    pov_point_texture = get_string "pov_surface_texture";
    pov_poly = get_bool true "pov_poly";
    pov_isosurface = get_bool false "pov_isosurface";
    pov_grad_coef = get_val 1.5 "pov_grad_coef";
    sorigin = get_vector3  [|0.0;0.0;0.0|] "origin";
    ssize = get_val 2.0 "size";
    auto_hide = get_bool true "auto_hide";
  }
  in
  Hashtbl.replace all_surfaces name s;
  s

let create_curve name l =
  let rec fn acc i = function
      [] -> acc
    | x::l -> fn (i::acc) (i+1) l
  in
  let gs = None in
  let lp = fn [] 0 l in
  let es, ps = object_to_curve_and_points l [lp] lp in
  let front_diffuse = get_tuple4 (0.7, 0.3, 0.2, 1.0) "front_diffuse" in
  let back_diffuse = get_tuple4 (0.3, 0.7, 0.2, 1.0) "back_diffuse" in
  let line_color = get_tuple4 (1.0, 1.0, 1.0, 1.0) "line_color" in
  let line_width = get_val 2.0 "line_width" in
  let text_color = get_tuple4 (1.0, 1.0, 1.0, 1.0) "text_color" in
  let transparent = get_bool false "transparent" in
  let point_color = get_tuple4 (1.0, 1.0, 0.0, 1.0) "point_color" in
  let point_size = get_val 4.0 "point_size" in
  let s =  {
    poly = Expr.cst Field_R.zero;
    ts = gs;
    es = es;
    ps = ps;
    text = [];
    handle = None;
    next_eq = None;
    grad = (fun _ -> failwith "not a surface");
    eval = (fun _ -> failwith "not a surface");
    newton = (fun _ -> failwith "not a surface");
    hessian = (fun _ -> failwith "not a surface");
    hessian_mat = (fun _ -> failwith "not a surface");
    ihessian = (fun _ -> failwith "not a surface");
    third = (fun _ -> failwith "not a surface");
    front_diffuse = front_diffuse;
    back_diffuse = back_diffuse;
    front_ambient =  get_tuple4 (0.2, 0.2, 0.2, 1.0) "front_ambient";
    back_ambient =  get_tuple4 (0.2, 0.2, 0.2, 1.0) "back_ambient";
    front_shininess =   get_val 30.0 "front_shininess";
    back_shininess =   get_val 30.0 "back_shininess";
    front_specular  =   get_tuple4 (0.3, 0.3, 0.3, 1.0) "front_specular";
    back_specular  =   get_tuple4 (0.3, 0.3, 0.3, 1.0) "back_specular";
    transparent = transparent;
    line_color = line_color;
    line_width = line_width;
    text_color = text_color;
    point_color = point_color;
    point_size = point_size;
    pov_surface_texture = get_string "pov_surface_texture";
    pov_line_texture = get_string "pov_surface_texture";
    pov_point_texture = get_string "pov_surface_texture";
    pov_poly = get_bool true "pov_poly";
    pov_isosurface = get_bool false "pov_isosurface";
    pov_grad_coef = get_val 1.5 "pov_grad_coef";
    sorigin = get_vector3  [|0.0;0.0;0.0|] "origin";
    ssize = get_val 2.0 "size";
    auto_hide = get_bool true "auto_hide";
  }
  in
  Hashtbl.replace all_surfaces name s;
  s

let move_point ptr pos =
  Raw.sets_float ptr 0 pos;
  !add_to_queue [Redisplay]

open Vector

module Environment =
  struct
    let dim = -1
    module D = struct
      let dim = dim
    end

    type scalar = float
    type elem = (string * float) list (* sorted by first key *)

    let (==) = (=)
    let normalize l = List.sort (fun x y -> compare (fst x) (fst y))
	(List.filter (fun (_,x) -> x <> 0.0) l)

    let write formatter l =
      pp_print_string formatter "[";
      pp_open_box formatter 2;
      let first = ref true in
      List.iter
	(fun (n,x) ->
	  if not !first then pp_print_string formatter "," else first := false;
	  pp_print_space formatter ();
	  pp_print_string formatter n;
	  pp_print_space formatter ();
	  pp_print_string formatter ":";
	  pp_print_space formatter ();
	  pp_print_float formatter x)
	l;
      pp_print_cut formatter ();
      pp_close_box formatter ();
      pp_print_string formatter "]"

    let print = write std_formatter

    let write_bin ch v =
      output_value ch v

    let read_bin = input_value

    let parse str = match str with parser
      [< ''['; _ = parse_spaces >] ->
	let rec fn acc =
	  match str with parser
	    [< n = parse_ident; _ = parse_spaces; '':';  _ = parse_spaces;
	       x = parse_float; _ = parse_spaces >] ->
		 gn ((n,x)::acc)
	and gn acc =
	  match str with parser
	    [< '','; _ = parse_spaces >] -> fn acc
	  | [< '']'; _ = parse_spaces >] -> acc
	in
	fn []

    let read ch = parse (Stream.of_channel ch)

    let zero = []

    let rec (++) l1 l2 = match l1, l2 with
	((n1,x1)::l1), ((n2,x2)::l2) when n1 = n2 ->
	  (n1,x1+.x2)::(l1 ++ l2)
      | ((n1,_ as c)::l1), ((n2,_)::_ as l2) when n1 < n2 ->
	  c::(l1 ++ l2)
      | ((n1,_)::_ as l1), ((n2,_ as c)::l2) ->
	  c::(l1 ++ l2)
      | ([], l) | (l, []) -> l

    let rec (--) l1 l2 = match l1, l2 with
	((n1,x1)::l1), ((n2,x2)::l2) when n1 = n2 ->
	  (n1,x1-.x2)::(l1 -- l2)
      | ((n1,_ as c)::l1), ((n2,_)::_ as l2) when n1 < n2 ->
	  c::(l1 -- l2)
      | ((n1,_)::_ as l1), ((n2,_ as c)::l2) ->
	  c::(l1 -- l2)
      | ([], l) | (l, []) -> l


    let opp = List.map (fun (n,x) -> (n, -.x))

    let (@) scal = List.map (fun (n,x) -> (n, scal *. x))

    let rec (|.) l1 l2 = match l1, l2 with
	((n1,x1)::l1), ((n2,x2)::l2) when n1 = n2 ->
	  (x1 *. x2) +. (l1 |. l2)
      | ((n1,_)::l1), ((n2,_)::_ as l2) when n1 < n2 ->
	  l1 |. l2
      | ((n1,_)::_ as l1), ((n2,_)::l2) ->
	  l1 |. l2
      | ([], l) | (l, []) ->
	  0.0

    let conjugate x = x

    type norm = float

    let norm v = List.fold_left (fun a (_,x) -> x*.x +. a) 0.0 v

    let abs v = sqrt (norm v)
  end

let optimise poly xpos ypos zpos init_env param =
  let points = ref [] in
  let module O_Space =
    struct
      open Vector

      module Scalar = Field_R
      module Space = Environment
      type scalar = float
      type elem = Environment.elem

      type precomputation = elem

      exception Exit_domain

      let vis_pos env =
	[| Expr.eval xpos env; Expr.eval ypos env; Expr.eval zpos env|]

      let xp = vis_pos init_env
      let surf, point = create_point "the_point" xp

      let _ =
	!add_to_queue [Add_surfaces [surf]];
	points:=xp::!points

      let change (env, _) =
	let xp = vis_pos env in
	move_point point xp;
	points:=xp::!points

      let precompute x = x

      let functional x =
	Expr.eval poly x

      let vars =
	List.map fst init_env

      let base =
	List.map (fun v -> Expr.derive poly v) vars

      let differential _ x =
	List.map2 (fun v e -> v, Expr.eval e x) vars base

      let invhessian v x d =
	failwith "invhessian unimplemented"

      let project x = x
    end in
    let module M = Descent (O_Space) in
    let r = M.optimise init_env param in
    let surf = create_curve "the_curve" !points in
    !add_to_queue [Add_surfaces [surf]];
    fst r

let newton_solve eq vars x0 =
  let eq = Array.of_list eq in
  let vars = Array.of_list vars in
  let x0 = Array.of_list x0 in
  let jacobian = Array.map (fun e ->
    Array.map (fun v -> Expr.derive e v) vars) eq in
  let next x =
    let env = Array.mapi (fun i v ->
      (v, x.(i))) vars in
    let env = Array.to_list env in
    let v = Array.map (fun e -> Expr.eval e env) eq in
    print_vector x; print_string " -> ";  print_vector v; print_newline ();
    print_newline ();
    let mat = Array.map (fun l -> Array.map (fun e -> Expr.eval e env) l) jacobian in
    let d = solve mat v in
    let n2 = vector_vector_product v v in
    let x' = vector_sub x d in
    n2, x'
  in
  let rec fn n2 x =
    let n2', x' = next x in
    if n2' < n2 then fn n2' x' else x'
  in
  let res = fn max_float x0 in
  print_vector res; print_newline ();
  res
