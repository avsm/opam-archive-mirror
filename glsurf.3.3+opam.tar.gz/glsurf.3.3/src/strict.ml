
exception Bug of string

exception Minsize

let strict = ref false


