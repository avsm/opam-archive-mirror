(**************************************************************************)
(*                                                                        *)
(*                               GlSurf                                   *)
(*                                                                        *)
(*                   C. Raffalli, Universite de Savoie                    *)
(*                                                                        *)
(* Copyright 2003, 2004 Christohe Raffalli                                *)
(*                                                                        *)
(*  This file is part of GlSurf.                                          *)
(*                                                                        *)
(*  GlSurf is free software; you can redistribute it and/or modify        *)
(*  it under the terms of the GNU General Public License as published by  *)
(*  the Free Software Foundation; either version 2 of the License, or     *)
(*  (at your option) any later version.                                   *)
(*                                                                        *)
(*  GlSurf is distributed in the hope that it will be useful,             *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *)
(*  GNU General Public License for more details.                          *)
(*                                                                        *) 
(*  You should have received a copy of the GNU General Public License     *)
(*  along with GlSurf; if not, write to the Free Software                 *)
(*  Foundation, Inc., 59 Temple Place, Suite 330, Boston,                 *)
(*  MA  02111-1307  USA                                                   *)
(**************************************************************************)

let set_cdr (l : 'a list) (x : 'a list) = match l with
    [] -> raise (Invalid_argument "set_cdr")
  | _::_ as l -> Obj.set_field (Obj.repr l) 1 (Obj.repr x)

let set_car (l : 'a list) (x : 'a) = match l with
    [] -> raise (Invalid_argument "set_cdr")
  | _::_ as l -> Obj.set_field (Obj.repr l) 0 (Obj.repr x)

let rec filter_map f l =
  match l with 
    [] -> []
  | x::l -> match f x with
      None -> filter_map f l
    | Some y -> y::filter_map f l

exception Supress

let rec filter_exc_map f l =
  match l with 
    [] -> []
  | x::l -> 
      try
	 let x' = f x in
	 x':: filter_exc_map f l
      with
	Supress -> filter_exc_map f l

let rec unionq l1 l2 =
  match l1 with
    [] -> l2
  | x::l ->
      if not (List.memq x l2) then x::unionq l l2 else unionq l l2

let get_reset p =
  let r = !p in
  p := [];
  r
