#include <stdlib.h> 
#include <stdio.h> 
#ifdef _WIN32
#include <wtypes.h>
#endif
#include <string.h>

#if defined(__APPLE__) && !defined(__APPLE_X11)
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include <math.h>
#if defined(_WIN32)
#include <windows.h>
#elif defined(__APPLE__)
#include <mach-o/dyld.h>
#else
#include <dlfcn.h>
#endif

#include <caml/mlvalues.h>
#include <caml/alloc.h>
#include <caml/memory.h>
#include <caml/signals.h>

#ifdef EXTENDED
typedef long double number
#else
typedef double number
#endif

number (*f)(number, number, number);
number* (*ffst)(number, number, number);
number* (*fsnd)(number, number, number);
number* (*fthd)(number, number, number); 
number* (*fi)(number, number, number, 
	      number, number, number); 

void readPixels(value dest, value width, value line)
{
  GLint y = Int_val(line);
  GLint w = Int_val(width);
  char *dst = String_val(dest);
  
  glReadPixels(0,y,w,1,GL_RGB,GL_UNSIGNED_BYTE,dst);
}

value readDepth(value x, value y)
{
  GLint xi = Int_val(x);
  GLint yi = Int_val(y);
  float dst = 0.0;
  value v = alloc_small(Double_wosize, Double_tag);      
  glReadPixels(xi,yi,1,1,GL_DEPTH_COMPONENT,GL_FLOAT,&dst);
  GLdouble projection[16];
  glGetDoublev(GL_PROJECTION_MATRIX, projection);
  GLdouble model[16];
  glGetDoublev(GL_MODELVIEW_MATRIX, model);
  GLint viewport[4];
  glGetIntegerv(GL_VIEWPORT, viewport);
  GLdouble xv,yv,zv;
  gluUnProject(xi,yi,dst,model,projection,viewport,&xv,&yv,&zv);

  printf("x = %f, y = %f, z = %f\n",xv,yv,zv);
  Store_double_val(v,(double) zv);
  return v;
}

#ifdef __APPLE__
#define HLIB NSModule
#elif defined _WIN32
#define HLIB HMODULE
#else
#define HLIB void*
#endif

typedef struct {
  HLIB handle;
  void* f;
  void* ffst;
  void* fsnd;
  void* fthd;
  void* fi;
} fun_handle;

/*
#ifdef __APPLE__
void* dlsym(HLIB handle,char* symname) {
  NSSymbol symbol;
  char *symname2 = (char*)malloc(sizeof(char)*(strlen(symname)+2));
  sprintf(symname2, "_%s", symname);
  symbol = NSLookupSymbolInModule(handle,symname2);
  free(symname2);
  return NSAddressOfSymbol(symbol);
}
#endif
*/

void set_functions(fun_handle *handle)
{
#ifdef WIN32
#define dlsym GetProcAddress
#endif
  f =  handle->f;
  ffst = handle->ffst;
  fsnd = handle->fsnd;
  fthd = handle->fthd;
  fi = handle->fi;
}

HLIB load_file(value filename)
{
  char* name = String_val(filename);
  HLIB handle=NULL;
  fun_handle *h; 
#ifdef WIN32
  handle = LoadLibrary(name);
#elif defined(__APPLE__)
  NSObjectFileImage image;
  if (NSCreateObjectFileImageFromFile(name, &image) !=
      NSObjectFileImageSuccess) {
    fprintf(stderr,"Cant load dynamic library");
    return NULL;
  }
  handle = NSLinkModule(image, name, TRUE);
  NSDestroyObjectFileImage(image);
#else
  handle = dlopen(name,RTLD_NOW);
#endif
  h = (fun_handle*) malloc(sizeof(fun_handle));
  h->handle = handle;
  h->f = (void*) dlsym(handle,"f");
  h->ffst = (void*) dlsym(handle,"ffst");
  h->fsnd = (void*) dlsym(handle,"fsnd");
  h->fthd = (void*) dlsym(handle,"fthd");
  h->fi = (void*) dlsym(handle,"fi");
  return(h);
}

#ifdef WIN32
void dlclose(HLIB handle)
{
  FreeLibrary(handle);
}
#endif

void fun_dlclose(fun_handle *h)
{
#ifdef __APPLE__ 
  NSUnLinkModule(h->handle,FALSE);
#else
  dlclose(h->handle);
#endif
  free(h);
}

value sf(value x, value y, value z) {
  return copy_double ((*f) (Double_val(x), Double_val(y), Double_val(z)));
}
value sffst(value x, value y, value z) {
  CAMLparam3(x,y,z);
  CAMLlocal1(v);
  number* tbl = (*ffst) (Double_val(x),Double_val(y),Double_val(z));
  v = alloc_small(3 * Double_wosize, Double_array_tag);    
  Store_double_field(v, 0, tbl[0]);
  Store_double_field(v, 1, tbl[1]);
  Store_double_field(v, 2, tbl[2]);
  free(tbl);
  CAMLreturn(v);
}
value sfsnd(value x, value y, value z) {
  CAMLparam3(x,y,z);
  CAMLlocal1(v);
  number* tbl = (*fsnd) (Double_val(x),Double_val(y),Double_val(z));
  v = alloc_small(6 * Double_wosize, Double_array_tag);    
  Store_double_field(v, 0, tbl[0]);
  Store_double_field(v, 1, tbl[1]);
  Store_double_field(v, 2, tbl[2]);
  Store_double_field(v, 3, tbl[3]);
  Store_double_field(v, 4, tbl[4]);
  Store_double_field(v, 5, tbl[5]);
  free(tbl);
  CAMLreturn(v);
}
value sfi(value *argv, int argc) {
  CAMLparamN(argv,argc);
  CAMLlocal1(v);
  number* tbl = (*fi) (Double_val(argv[0]),Double_val(argv[1]),Double_val(argv[2]),
		       Double_val(argv[3]),Double_val(argv[4]),Double_val(argv[5]));
  v = alloc_small(12 * Double_wosize, Double_array_tag);    
  Store_double_field(v, 0, tbl[0]);
  Store_double_field(v, 1, tbl[1]);
  Store_double_field(v, 2, tbl[2]);
  Store_double_field(v, 3, tbl[3]);
  Store_double_field(v, 4, tbl[4]);
  Store_double_field(v, 5, tbl[5]);
  Store_double_field(v, 6, tbl[6]);
  Store_double_field(v, 7, tbl[7]);
  Store_double_field(v, 8, tbl[8]);
  Store_double_field(v, 9, tbl[9]);
  Store_double_field(v, 10, tbl[10]);
  Store_double_field(v, 11, tbl[11]);
  free(tbl);
  CAMLreturn(v);
}
value sfthd(value *argv, int argc) {
  CAMLparamN(argv,argc);
  CAMLlocal1(v);
  number* tbl = (*fthd) (Double_val(argv[0]),Double_val(argv[1]),Double_val(argv[2]));
  v = alloc_small(10 * Double_wosize, Double_array_tag);    
  Store_double_field(v, 0, tbl[0]);
  Store_double_field(v, 1, tbl[1]);
  Store_double_field(v, 2, tbl[2]);
  Store_double_field(v, 3, tbl[3]);
  Store_double_field(v, 4, tbl[4]);
  Store_double_field(v, 5, tbl[5]);
  Store_double_field(v, 6, tbl[6]);
  Store_double_field(v, 7, tbl[7]);
  Store_double_field(v, 8, tbl[8]);
  Store_double_field(v, 9, tbl[9]);
  free(tbl);
  CAMLreturn(v);
}


double ff(double x, double y, double z) {
  return (*f) (x,y,z);
}

value fffst(value x, value y, value z) {  
  CAMLparam3(x,y,z);
  CAMLlocal1(v);
  number* tbl = (*ffst) (Double_val(x),Double_val(y),Double_val(z));
  v = alloc_small(3 * Double_wosize, Double_array_tag);    
  Store_double_field(v, 0, tbl[0]);
  Store_double_field(v, 1, tbl[1]);
  Store_double_field(v, 2, tbl[2]);
  free(tbl);
  CAMLreturn(v);
}
value ffsnd(value x, value y, value z) {  
  CAMLparam3(x,y,z);
  CAMLlocal1(v);
  number* tbl = (*fsnd) (Double_val(x),Double_val(y),Double_val(z));
  v = alloc_small(6 * Double_wosize, Double_array_tag);    
  Store_double_field(v, 0, tbl[0]);
  Store_double_field(v, 1, tbl[1]);
  Store_double_field(v, 2, tbl[2]);
  Store_double_field(v, 3, tbl[3]);
  Store_double_field(v, 4, tbl[4]);
  Store_double_field(v, 5, tbl[5]);
  free(tbl);
  CAMLreturn(v);
}
value ffi(value x1, value x2, value y1, value y2, value z1, value z2) {
  CAMLparam3(x1,x2,y1);
  CAMLxparam3(y2,z1,z2);
  CAMLlocal1(v);
  number* tbl = (*fi) (Double_val(x1),Double_val(x2),Double_val(y1),
		       Double_val(y2),Double_val(z1),Double_val(z2));
  v = alloc_small(12 * Double_wosize, Double_array_tag);    
  Store_double_field(v, 0, tbl[0]);
  Store_double_field(v, 1, tbl[1]);
  Store_double_field(v, 2, tbl[2]);
  Store_double_field(v, 3, tbl[3]);
  Store_double_field(v, 4, tbl[4]);
  Store_double_field(v, 5, tbl[5]);
  Store_double_field(v, 6, tbl[6]);
  Store_double_field(v, 7, tbl[7]);
  Store_double_field(v, 8, tbl[8]);
  Store_double_field(v, 9, tbl[9]);
  Store_double_field(v, 10, tbl[10]);
  Store_double_field(v, 11, tbl[11]);
  free(tbl);
  CAMLreturn(v);
}
value ffthd(value x, value y, value z) {
  CAMLparam3(x,y,z);
  CAMLlocal1(v);
  number* tbl = (*fthd) (Double_val(x),Double_val(y),Double_val(z));
  v = alloc_small(10 * Double_wosize, Double_array_tag);    
  Store_double_field(v, 0, tbl[0]);
  Store_double_field(v, 1, tbl[1]);
  Store_double_field(v, 2, tbl[2]);
  Store_double_field(v, 3, tbl[3]);
  Store_double_field(v, 4, tbl[4]);
  Store_double_field(v, 5, tbl[5]);
  Store_double_field(v, 6, tbl[6]);
  Store_double_field(v, 7, tbl[7]);
  Store_double_field(v, 8, tbl[8]);
  Store_double_field(v, 9, tbl[9]);
  free(tbl);
  CAMLreturn(v);
}

static value* caml_glutTimerFunc_cb = NULL;

static void myglutTimerFunc_cb(int val)
{
  caml_leave_blocking_section ();
  callback (*caml_glutTimerFunc_cb, Val_int(val));
  caml_enter_blocking_section ();
}

CAMLprim value myml_glutTimerFunc(value millis_val, value v) // set Timer callback
{
    glutTimerFunc(Int_val(millis_val), &myglutTimerFunc_cb, Int_val(v));
    return Val_unit;
}

CAMLprim value myinit_glutTimerFunc(value v) {
  if (caml_glutTimerFunc_cb)   {       
    caml_remove_global_root(caml_glutTimerFunc_cb);
  } else { 
    caml_glutTimerFunc_cb = (value*) malloc(sizeof(value));
  }
  *caml_glutTimerFunc_cb = v;
  caml_register_global_root(caml_glutTimerFunc_cb);
  return Val_unit;
}

