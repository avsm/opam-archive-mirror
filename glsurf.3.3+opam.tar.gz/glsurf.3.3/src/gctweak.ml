let debug = ref 0 (* between 0 and 4, 2 and above is for debugging only *)

(* adjustable parameters. *)
type interactive_parameters = {
  gamma : float; (* time in major slice attached to a minor GC  / time for minor GC
                : should use a better estimation, here just one mesurement !!! *)
  no_change_ratio : float; (* between 0.0 and 1.0. does not try to change the minor heap
			     if the percentage of promoted words in the minor heap at each
                             minor GC is below this value. *)
}

let default_interactive_parameters = {
  gamma = 7.3;
  no_change_ratio = 0.05;
}

type batch_parameters = {
  double_ratio : float; (* if the ratio of promoted word is above this value and if other parameters
                          agree, then double mino heap *)
  halve_ratio : float;  (* if the ratio of promoted word is below this value and if other parameters
                          agree, then halve mino heap *)
}

let default_batch_parameters = {
  double_ratio = 0.15;
  halve_ratio = 0.05;
}

type minor_heap_policy =
  | Interactive of interactive_parameters
  | Batch of batch_parameters
type major_heap_policy =
  | Proportional of float (* proportional heap increment ratio *)
  | Constant of int (* as in OCaml *)

type gctweak_param = {
  space_overhead : int; (* as in Gc.mli *)
  max_minor_heap_size : int; (* the names is clear (32Mb),
                                      rounded to the power of 2 below *)
  max_minor_major_ratio : float; (* maximum ratio between minor and major heap size *)

  minor_heap_policy : minor_heap_policy;
  major_heap_policy : major_heap_policy;
}

let interactive_default =  {
  space_overhead = 100;
  max_minor_heap_size = 1 lsl 25;
  max_minor_major_ratio = 0.20;
  minor_heap_policy = Interactive default_interactive_parameters;
  major_heap_policy = Proportional 0.5;
}

let batch_default = {
  interactive_default with
  minor_heap_policy = Batch default_batch_parameters;
}

(* Justification of the interactive case:
We use a model saying that the time in each GC slice is

T = K * (m + gamma * r * m * f) where

m = minor heap size (goes away in O())
gamma = define above
r = ratio of promoted word at each minor cycle
f = (space_overhead + 100) / space_overhead used as an estimation
    of free space in major heap after collection
K a time constant

in the sum abobe:
- K * m is the time in the minor GC
- K * gamma * r * m * f is the time in the major GC slice for each minor GC

If gamma * f is more than 1 (which is likely), it is easy to see that
increasing m, if it decreases r enough, will both increase overall speed and
time is a GC slice, increasing therefore both speed and reactivity.

More precisely, the model says that this is OK to double the size of the
minor heap when 1 + gamma * f * r > 2*(1 + gamma * f * r') where r is the ratio
associated to m and r' is the ratio associated to 2*m.

The code below keeps and update a table of ponderated average value of
1 + gamma * f * r for all used heap size and tries to make sensible decision
looking at it.
*)

(* Gamma estimation:

On binary_tree.ml from Shootout with all defaults from shootout (on my Mac)
14.39s in caml_major_collectio_clice over 19.15s for caml_minor_collection (2318 calls)
f = 1.8 (default OCaml)
r = 0.231
gamma = 14.39 / (19.15 - 14.39) / (f*r) = 7.27
*)

let alarm = ref None

(* tranlated log2 of the minor heap size, used at initialization only *)
let index m =
  let rec fn i m =
    if m <= 32768 then i else fn (i + 1) (m / 2)
  in
  fn 0 m

let set ps =
  let param = Gc.get () in
  let _ = Gc.set { param with Gc.space_overhead = ps.space_overhead } in

  let old_heap_words = ref (Gc.quick_stat ()).Gc.heap_words in
  let old_promoted_words = ref 0.0 in
  let old_minor_collections = ref 0 in
  let minor_heap_size = ref param.Gc.minor_heap_size in

  begin
    match ps.major_heap_policy with
      Constant s ->
	Gc.set { (Gc.get ()) with Gc.major_heap_increment = s; }
    | _ -> ()
  end;

  let do_major_heap s ps =
    match ps.major_heap_policy with
      Proportional f ->
	if !old_heap_words <> s.Gc.heap_words then begin
	  old_heap_words := s.Gc.heap_words;
	  let major_heap_increment = max (124*1024) (int_of_float (float s.Gc.heap_words *. f)) in
	  if !debug > 1 then begin
	    Printf.fprintf stderr "MHI <- %d \n" major_heap_increment;
	    flush stderr;
	  end;
	  Gc.set { (Gc.get ()) with Gc.major_heap_increment = major_heap_increment; }
	end
    | _ -> ()
  in

  let max_index = index ps.max_minor_heap_size in
  let minor_heap_index_size = ref (index param.Gc.minor_heap_size) in

  let compute_ratio s =
    let promoted_words = s.Gc.promoted_words in
    let minor_collections = s.Gc.minor_collections in
    let delta_promoted_words = promoted_words -. !old_promoted_words in
    let delta_minor_collections = minor_collections - !old_minor_collections in
    old_promoted_words := promoted_words;
    old_minor_collections := minor_collections;
    delta_promoted_words /. (float) delta_minor_collections
    /. (float) !minor_heap_size
  in

  begin
    match !alarm with
    | None -> ()
    | Some a -> Gc.delete_alarm a
  end;

  match ps.minor_heap_policy with
  | Batch pb ->
      Gc.create_alarm
	(fun () ->
	   let s = Gc.quick_stat () in
	   let ratio = compute_ratio s in
	   let i = !minor_heap_index_size in
	   if i > 0 && (ratio < pb.halve_ratio ||
			  (float) s.Gc.heap_words *. ps.max_minor_major_ratio < (float) !minor_heap_size) then begin
	     minor_heap_size := !minor_heap_size / 2;
	     minor_heap_index_size := i - 1;
	     if !debug > 0 then begin
	       Printf.fprintf stderr "MHS HALFED <- %d (ratio %f)\n" !minor_heap_size ratio;
	       flush stderr;
	     end;
	     Gc.set { (Gc.get ()) with Gc.minor_heap_size = !minor_heap_size }
	   end else
	     if i < max_index && ratio > pb.double_ratio &&
	       ((float) s.Gc.heap_words *. ps.max_minor_major_ratio >= (float) !minor_heap_size *. 2.0) then begin
		 minor_heap_size := !minor_heap_size * 2;
		 minor_heap_index_size := i + 1;
		 if !debug > 0 then begin
		   Printf.fprintf stderr "MHS DOUBLED <- %d (ratio %f)\n" !minor_heap_size ratio;
		   flush stderr;
		 end;
		 Gc.set { (Gc.get ()) with Gc.minor_heap_size = !minor_heap_size }
	       end else
		 if !debug > 1 then begin
		   Printf.fprintf stderr "MHS UNCHANGED (ratio %f)\n" ratio;
		   flush stderr;
		 end;

	   (* tweak major heap increment to be a fraction of major heap size if necessary*)
	   do_major_heap s ps)

  | Interactive pi ->
      (* a table to store 1 + gamma * f * r for each heap size *)
      let model_table = Array.make (max_index+1) None in
      (* a table to store value ages *)
      let age_table = Array.make (max_index+1) 0 in

      let current_cycle = ref 0 in

      Gc.create_alarm
	(fun () ->
	   let s = Gc.quick_stat () in
	   let ratio = compute_ratio s in
	   let new_model = 1.0 +. pi.gamma *. ratio in
	   let i = !minor_heap_index_size in
	   incr current_cycle;
	   let age = !current_cycle - age_table.(i) in
	   age_table.(i) <- !current_cycle;
	   let mean_model = match model_table.(i) with None -> new_model |
	       Some r -> (r +. (float) age *. new_model) /. (1.0 +. (float) age)
	   in
	   model_table.(i) <- Some mean_model;
	   if !debug > 2 then begin
	     let i = ref 0 in
	     while !i <= max_index && model_table.(!i) <> None do
               match model_table.(!i) with
               | None -> assert false
               | Some r ->  Printf.fprintf stderr "model(%d) = %f - " !i r; incr i
	     done;
	     Printf.fprintf stderr "\n"; flush stderr;
	   end;
	   let lower_change =
	     if i <= 0 then 1e-1 else
               match model_table.(i-1) with
               | None -> -5e-2
               | Some r ->  (r -. (2.0 *. mean_model)) /. (float) (!current_cycle - age_table.(i-1))
	   in
	   let upper_change =
	     if i >= max_index then -5e-2 else
	       match model_table.(i+1) with
	       | None -> 1e-1
	       | Some r -> (mean_model -. (2.0 *. r)) /. (float) (!current_cycle - age_table.(i+1))
	   in
	   if !debug > 2 then begin
	     Printf.fprintf stderr "lc = %f, uc = %f, hw = %d, mhs = %d\n"
	       lower_change upper_change s.Gc.heap_words !minor_heap_size;
	     flush stderr;
	   end;
	   let change = lower_change +. upper_change in
	   if i > 0 && (change < 0.0 ||
			  (float) s.Gc.heap_words *. ps.max_minor_major_ratio < (float) !minor_heap_size) then begin
	     minor_heap_size := !minor_heap_size / 2;
	     minor_heap_index_size := i - 1;
	     if !debug > 0 then begin
	       Printf.fprintf stderr "MHS HALFED <- %d (model %f, ratio %f)\n" !minor_heap_size mean_model ratio;
	       flush stderr;
	     end;
	     Gc.set { (Gc.get ()) with Gc.minor_heap_size = !minor_heap_size }
	   end else
	     if change > 0.0 && i < max_index && ratio > pi.no_change_ratio &&
	       ((float) s.Gc.heap_words *. ps.max_minor_major_ratio >= (float) !minor_heap_size *. 2.0) then begin
		 minor_heap_size := !minor_heap_size * 2;
		 minor_heap_index_size := i + 1;
		 if !debug > 0 then begin
		   Printf.fprintf stderr "MHS DOUBLED <- %d (model %f, ratio %f)\n" !minor_heap_size mean_model ratio;
		   flush stderr;
		 end;
		 Gc.set { (Gc.get ()) with Gc.minor_heap_size = !minor_heap_size }
	       end else
		 if !debug > 1 then begin
		   Printf.fprintf stderr "MHS UNCHANGED (model %f, ratio %f)\n" mean_model ratio;
		   flush stderr;
		 end;

	   (* tweak major heap increment to be a fraction of major heap size if necessary*)
	   do_major_heap s ps;
	)
