open Parameters
open Parser
open Function
open Draw
open Action


let _ = 
(*  ignore (Gc.create_alarm (fun () -> Gc.print_stat stdout; flush stdout)); *)
  ignore (Gctweak.set Gctweak.interactive_default);
  Gctweak.debug := 0;
  Sys.catch_break true

let _ = batch := (Sys.argv.(0) = "glsurf-batch")

let argv = List.filter (fun str ->
			  if str.[0] = '-' then begin
			    match str with
			      "-batch" -> batch := true; false
			    | str -> true
			  end else true)
  (Array.to_list Sys.argv)

let argv = 
  if !batch then begin
    add_to_queue := (fun x -> ());
    argv 
  end else 
    Array.to_list (gl_init ())

let work () = 
  Mutex.lock gl_started;
  begin try
    let names = List.tl argv in
    let fn name =
      print_string "Reading file: ";
      print_string name;
      print_newline ();
      try
	let ch = open_in name in
	try
	  let str = Stream.of_channel ch in
	  while true do 
	    parse_cmd str
	  done;
	with
	  Exit -> close_in ch
	| Stream.Error s ->
	    close_in ch;
	    prerr_string ("line "^string_of_int !Input_util.line_number^": Syntax error: "^s);
	    prerr_newline ();
	    exit 1
	| Stream.Failure ->
	    close_in ch;
	    prerr_string ("line "^string_of_int !Input_util.line_number^": Syntax error");
	    prerr_newline ();
	    exit 1
	| Failure s ->
	    prerr_string ("line "^string_of_int !Input_util.line_number^": Error: "^s);
	    prerr_newline ()
	| Invalid_argument s ->
	    prerr_string ("line "^string_of_int !Input_util.line_number^": Error: "^s);
	    prerr_newline ()
      with 
	Sys_error s->
	  prerr_string ("Error: failed to open file: "^name ^"("^s^")");
	  prerr_newline ();
	  exit 1
    in
    List.iter fn names;
    print_string "Reading standard input (wait for commands).\n";
    print_newline ();
    Input_util.prompt := ">GlSurf> ";
    Input_util.interactive := true;
    print_string !Input_util.prompt; flush stdout;

    let str = Stream.of_channel stdin in	
    try
      while true do
	    try
	      parse_cmd str;
	    with
	      Stream.Error s ->
		prerr_string (Sys.argv.(0)^ ": Syntax error: "^s);
		prerr_newline ()
	    | Stream.Failure ->
		prerr_string (Sys.argv.(0)^ ": Syntax error");
		prerr_newline ()
	    | Failure s ->
		prerr_string (Sys.argv.(0)^ ": Error: "^s);
		prerr_newline ()
	    | Invalid_argument s ->
		prerr_string ("line "^string_of_int !Input_util.line_number^": Error: "^s);
		prerr_newline ()
	  done
    with Exit | Sys.Break -> 
      print_string "Work thread: Bye!" ;
      print_newline ();
      !add_to_queue [Quit];
  with e -> 
    prerr_newline ();
    prerr_string (Printexc.to_string e); prerr_newline ();
    Printexc.print_backtrace stderr; prerr_newline ()
  end

let _ = 
  Sys.set_signal Sys.sigvtalrm Sys.Signal_ignore;
  (* on NVidia card, it seems that the GL thread MUST BE the main thread.
     on ATI card inverting work and do_gl_start works *)
  if !batch then 
    work () 
  else begin
    Mutex.lock gl_started; 
    ignore (Thread.create work ());
    try
      do_gl_start ();
    with
    | Failure s ->
	prerr_string (Sys.argv.(0)^ ": Error: "^s);
	prerr_newline ();
	Gc.full_major ();
	print_string "GL thread: Bye";
	print_newline ();
    | Invalid_argument s ->
	prerr_string ("line "^string_of_int !Input_util.line_number^": Error: "^s);
	prerr_newline ();
	Gc.full_major ();
	print_string "GL thread: Bye";
	print_newline ();
    | Exit | Sys.Break ->
	Gc.full_major ();
	print_string "GL thread: Bye";
	print_newline ();
  end

