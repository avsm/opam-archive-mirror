(**************************************************************************)
(*                                                                        *)
(*                               GlSurf                                   *)
(*                                                                        *)
(*                   C. Raffalli, Universite de Savoie                    *)
(*                                                                        *)
(* Copyright 2003, 2004 Christohe Raffalli                                *)
(*                                                                        *)
(*  This file is part of GlSurf.                                          *)
(*                                                                        *)
(*  GlSurf is free software; you can redistribute it and/or modify        *)
(*  it under the terms of the GNU General Public License as published by  *)
(*  the Free Software Foundation; either version 2 of the License, or     *)
(*  (at your option) any later version.                                   *)
(*                                                                        *)
(*  GlSurf is distributed in the hope that it will be useful,             *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *)
(*  GNU General Public License for more details.                          *)
(*                                                                        *)
(*  You should have received a copy of the GNU General Public License     *)
(*  along with GlSurf; if not, write to the Free Software                 *)
(*  Foundation, Inc., 59 Temple Place, Suite 330, Boston,                 *)
(*  MA  02111-1307  USA                                                   *)
(**************************************************************************)

open Input_util
open Format
open Algebra

module type Optimisation_Space =
sig
  type scalar
  type elem
  module Scalar : Normed_Field with type elem = scalar and type norm = scalar
  module Space : Banach with
    type scalar = scalar and type norm = scalar and type elem = elem

  type precomputation

  exception Exit_domain

  val precompute : elem -> precomputation
  val functional : precomputation -> scalar
  val differential : scalar -> precomputation -> elem
  val invhessian : scalar -> precomputation -> elem -> elem

  (* side effect called at each step of optimisation *)
  val change : elem * precomputation -> unit

 (* called each time we advance some step, may be the identity,
  simplification ... or a projection for constrained optimisation *)
  val project : elem -> elem
end

module type Atype =
sig
  type elem
end

module Linear_optimisation =
  functor (Atype : Atype) ->
  functor (Scalar : Normed_Field with
type elem = Atype.elem and type norm = Atype.elem ) ->
struct
  open Scalar

  let linear_optimisation change func precision s0 f0 s1 f1 c1 =
    let rec fn s0 f0 s1 f1 c1 =
      if leq (s1 -- s0) precision then s1, f1, c1 else
	let s2 = ((s0 ++  s1) // t_of_int 2) in
	let c2, f2 = func s2 in
	if not (leq f1 f2) && not (leq f0 f2) then begin
	  change c2;
	  gn s0 f0 s2 f2 c2 s1 f1
	end else
	  if leq f0 f1 then
	    fn s0 f0 s2 f2 c2
	  else
	    fn s2 f2 s1 f1 c1
    and gn s0 f0 s1 f1 c1 s2 f2 =
      if leq (s2 -- s0) precision then s1, f1, c1 else
      let sm1 = (s0 ++ s1) // t_of_int 2 in
      let cm1, fm1 = func sm1 in
      if not (leq f1 fm1) then (change cm1; gn s0 f0 sm1 fm1 cm1 s1 f1)
      else
      let sm2 = (s1 ++ s2) // t_of_int 2 in
      let cm2, fm2 = func sm2 in
      if not (leq f1 fm2) then (change cm2; gn s1 f1 sm2 fm2 cm2 s2 f2) else
      gn sm1 fm1 s1 f1 c1 sm2 fm2
    in
    fn s0 f0 s1 f1 c1
end

type cg_kind =
  | Fletcher_Reeves
  | Polak_Ribiere
  | Hestenes_Stiefel
  | Dai_Yuan

type algorithm =
  | Gradient
  | Conjugate_gradient of cg_kind * int
  | AvGrad
  | Newton of algorithm

let rec parse_algorithm str =
  match str with parser
  [< s = parse_ident; _ = parse_spaces >] ->
    begin
      match s with
	"Steepest" -> Gradient
      | "Newton" -> (match str with parser
	  [< a = parse_algorithm; _ = parse_spaces >] ->
	    Newton a)
      | "CGFR" -> (match str with parser
	  [< n = parse_int; _ = parse_spaces >] ->
	    Conjugate_gradient(Fletcher_Reeves,n))
      | "CGPR" -> (match str with parser
	  [< n = parse_int; _ = parse_spaces >] ->
	    Conjugate_gradient(Polak_Ribiere,n))
      | "CGHS" -> (match str with parser
	  [< n = parse_int; _ = parse_spaces >] ->
	    Conjugate_gradient(Hestenes_Stiefel,n))
      | "CGDY" -> (match str with parser
	  [< n = parse_int; _ = parse_spaces >] ->
	    Conjugate_gradient(Dai_Yuan,n))
      | "AverageSteepest" ->
	  AvGrad
      | s ->
	  failwith ("Unknown algorithm: "^s)
    end
| [< >] -> Gradient

type ('a) parameters =
    {
     initial_lambda : 'a;
     stop_condition : 'a;
     algorithm : algorithm;
     linear_search_precision : 'a;
     min_lambda : 'a;
     max_lambda : 'a;
    log : formatter option;
   }

module type Descent =
  sig
    type scalar
    type elem

    val default : (scalar) parameters
    val optimise : elem -> (scalar) parameters -> elem * scalar
  end

module Descent =
  functor (O : Optimisation_Space) ->
struct
  open O

  type scalar = Scalar.elem
  type elem = Space.elem

  module Elem = struct
    type elem = scalar
  end

  let linear_optimisation =
    let module L = Linear_optimisation(Elem)(Scalar) in
    L.linear_optimisation

  let rec power_int x n =
    if n < 0 then
      Scalar.inv (power_int x (-n))
    else if n = 0 then
      Scalar.one
    else if n = 1 then
      x
    else if n mod 2 = 0 then
      let r = power_int x (n / 2) in Scalar.( ** ) r r
    else
      let r = power_int x (n / 2) in Scalar.( ** ) x (Scalar.( ** ) r r)

  let default =
    {
     initial_lambda = Scalar.(//) Scalar.one (Scalar.t_of_int 1000);
     stop_condition = Scalar.(//) Scalar.one (Scalar.t_of_int 1000);
     algorithm = Gradient;
     linear_search_precision = Scalar.(//) Scalar.one (Scalar.t_of_int 10);
     min_lambda = power_int (Scalar.t_of_int 10) (-9);
     max_lambda = power_int (Scalar.t_of_int 10) (10);
     log = Some (formatter_of_out_channel stdout);
   }

  let optimise (o : elem) (parameters : (scalar) parameters) =
    let log = parameters.log in

    let o = project o in
    let obj = ref o in
    let prev_obj = ref o in
    let pprev_obj = ref o in
    let precomputation = ref (precompute o) in
    let functional_value = ref (functional !precomputation) in
    let lambda = ref (parameters.initial_lambda) in
    change (!obj,!precomputation);

    let continue = ref true in
    let previous_grad = ref Space.zero in
    let previous_dir = ref Space.zero in

    let do_direction func =
      let s1 = !lambda in
      let tpl, f1 = func s1 in
      try
	let s,f,(c,pc) = linear_optimisation change func
	    parameters.linear_search_precision
	    parameters.stop_condition !functional_value s1 f1 tpl in
	Printf.printf "coucou\n";
	obj := c;
	precomputation := pc;
	functional_value := f;
	lambda := s;
	begin match log with None -> () | Some log ->
	  pp_print_string log "(*";
	  pp_print_newline log ();
	  pp_print_string log "polynomial: "; Space.write log c;
	  pp_print_newline log ();
	  pp_print_string log "lambda: ";
	  Scalar.write log !lambda; pp_print_newline log ();
	  pp_print_newline log ();
	  Scalar.write log f;
	  pp_print_newline log ();
	  pp_print_string log "*)";
	  pp_print_newline log ();
	end
      with
	Exit -> 	Printf.printf "Exit\n"; ()
    in

    let step = ref 0 in
    let stop2 = Scalar.( ** ) parameters.stop_condition parameters.stop_condition in
    let first = ref true in
    (try while true
    do
      let grad = differential !functional_value !precomputation in
      if !first then begin
	let ng = Space.norm grad in
	let is_newton = match parameters.algorithm with Newton _ -> true | _ -> false in
	if not is_newton && ng <> Scalar.zero then
	  lambda :=
	    max parameters.min_lambda (Scalar.( ** )
	      (Scalar.(//) !lambda ng) !functional_value);
	first := false;
      end;

(*
      let r = (Scalar.(//) (Space.norm grad)
		 (Scalar.abs !functional_value)) in
      if (Scalar.leq r parameters.min_lambda)
      then begin
	begin match log with None -> () | Some log ->
	  pp_print_string log "lambda too small";
	  pp_print_newline log ();
	end;
	raise Exit
      end;
      if not !continue && (Scalar.leq r parameters.stop_condition)
      then begin
	begin match log with None -> () | Some log ->
	  pp_print_string log "stopping: ";
	  Scalar.write log r;
	  pp_print_string log " <= ";
	  Scalar.write log parameters.stop_condition;
	  pp_print_newline log ();
	  pp_print_string log "gradient: "; Space.write log grad;
	  pp_print_newline log ();
	end;
	raise Exit;
      end;
*)
      continue := false;

      let func_usual dir =
	begin match log with None -> () | Some log ->
	  pp_print_string log "(*";
	  pp_print_newline log ();
	  pp_print_string log "gradient: "; Space.write log grad;
	  pp_print_newline log ();
	  pp_print_string log "direction: "; Space.write log dir;
	  pp_print_newline log ();
	  pp_print_string log "*)";
	  pp_print_newline log ();
	end;
	fun lambda ->
	try
	  begin match log with None -> () | Some log ->
	    pp_print_string log "lambda: ";
	    Scalar.write log lambda;
	    pp_print_newline log ();
	  end;
	  let r = Scalar.( ** ) lambda (Scalar.(//) (Space.norm dir)
		     (Space.norm !obj)) in
	  if (Scalar.leq r parameters.min_lambda)
	  then begin
	    begin match log with None -> () | Some log ->
	      pp_print_string log "lambda too small";
	      pp_print_newline log ();
	      print_string "lambda too small";
	      print_newline ();
	    end;
	    raise Exit
	  end;
	  let new_obj = project
	      (Space.(++) (Space.(@) lambda dir) !obj) in
	  let new_precomputation = precompute new_obj in
	  let f = functional new_precomputation in
	  begin match log with None -> () | Some log ->
	    Scalar.write log f;
	    pp_print_string log "<";
	    Scalar.write log !functional_value;
	    pp_print_newline log ();
	  end;
	  (new_obj, new_precomputation), f
	with Exit_domain ->
	  (!obj, !precomputation), Scalar.( ** ) !functional_value (Scalar.t_of_int 10)
      in

      let func =
	let rec compute_dir = function
	    Gradient -> Space.opp grad
	  | AvGrad ->
	      if !step = 0 then Space.opp grad else
	      let c0 = Space.abs grad and c1 = Space.abs !previous_grad in
	      let sum = Scalar.(++) c0 c1 in
	      Space.opp (
	      Space.(@) (Scalar.inv sum)
		(Space.(++) (Space.(@) c1 grad)
		   (Space.(@) c0 !previous_grad)))
	  | Newton (alt) ->
	      let dir = invhessian !functional_value !precomputation grad in
	      if Space.(|.) grad dir < Scalar.zero then
		(Printf.printf "Keep newton direction\n"; step := 0; dir)
	      else
		compute_dir alt
	  | Conjugate_gradient (kind, reset) ->
	      if !step mod reset = 0 then Space.opp grad else
	      let numerator =
		if kind = Fletcher_Reeves || kind = Dai_Yuan then
		  Space.norm grad
		else
		  Space.(|.) grad (Space.(--) grad !previous_grad)
	      in
	      let denominator =
		if kind = Hestenes_Stiefel || kind = Dai_Yuan then
		  Space.(|.) !previous_dir (Space.(--) grad !previous_grad)
		else
		  Space.norm !previous_grad
	      in
	      let beta = Scalar.(//) numerator denominator in
	      let beta = if beta < Scalar.zero then Scalar.zero else beta in
	      let dir = Space.(--) (Space.(@) beta !previous_dir) grad in
	      let dir =
		if Space.(|.) grad dir >= Scalar.zero then
		  (step := 0; Space.opp grad)
		else
		  dir
	      in
	      previous_dir := dir;
	      dir
	in
	func_usual (compute_dir parameters.algorithm)
      in
      incr step;
      do_direction func;
      if Space.norm (Space.(--) !pprev_obj !obj) < Scalar.( ** ) stop2 (Space.norm !obj) then
	raise Exit;
      if Space.norm (Space.(--) !prev_obj !obj) < Scalar.( ** ) stop2 (Space.norm !obj) then
	step := 0;
      previous_grad := grad;
      pprev_obj := !prev_obj;
      prev_obj := !obj;

    done with Exit -> ());

    !obj, !functional_value

end
