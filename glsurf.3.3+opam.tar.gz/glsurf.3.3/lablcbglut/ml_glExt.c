/* $Id: ml_gl.c,v 1.47 2005/10/14 13:35:32 garrigue Exp $ */

#ifdef _WIN32
#include <wtypes.h>
#endif
#include <string.h>
#ifdef __APPLE__
#include <OpenGL/gl.h>
#else
#include <GL/gl.h>
#endif
#include <caml/misc.h>
#include <caml/mlvalues.h>
#include <caml/callback.h>
#include <caml/memory.h>
#include <caml/alloc.h>
#include <caml/fail.h>
#include "ml_raw.h"
#include "ml_gl.h"
#include "gl_tags.h"

struct record {
    value key; 
    GLenum data;
};

static struct record input_table[] = {
#include "gl_tags.c"
};

static struct record *tag_table = NULL;

#define TABLE_SIZE (TAG_NUMBER*2+1)

CAMLprim value ml_glext_make_table (value unit)
{
    int i;
    unsigned int hash;

    tag_table = stat_alloc (TABLE_SIZE * sizeof(struct record));
    memset ((char *) tag_table, 0, TABLE_SIZE * sizeof(struct record));
    for (i = 0; i < TAG_NUMBER; i++) {
	hash = (unsigned long) input_table[i].key % TABLE_SIZE;
	while (tag_table[hash].key != 0) {
	    hash ++;
	    if (hash == TABLE_SIZE) hash = 0;
	}
	tag_table[hash].key = input_table[i].key;
	tag_table[hash].data = input_table[i].data;
    }
    return Val_unit;
}

GLenum GLExtenum_val(value tag)
{
    unsigned int hash = (unsigned long) tag % TABLE_SIZE;

    if (!tag_table) ml_glext_make_table (Val_unit);
    while (tag_table[hash].key != tag) {
	if (tag_table[hash].key == 0) ml_raise_gl ("Unknown tag");
	hash++;
	if (hash == TABLE_SIZE) hash = 0;
    }
    /*
    fprintf(stderr, "Converted %ld to %d", Int_val(tag), tag_table[hash].data);
    */
    return tag_table[hash].data;
}

ML_1 (glEnable, GLExtenum_val)
ML_1 (glDisable, GLExtenum_val)
ML_1_ (glIsEnabled, GLExtenum_val, Val_int)

CAMLprim value ml_glTexImage3D (value proxy, value level, value internal,
                                value width, value height, value depth,
				value border, value format, value data)
{
    /* printf("p=%x,l=%d,i=%d,w=%d,h=%d,d=%d,b=%d,f=%x,t=%x,d=%x\n", */
	       glTexImage3D ( proxy == Val_int(1)
		  ? GL_PROXY_TEXTURE_3D : GL_TEXTURE_3D,
		  Int_val(level), Int_val(internal), Int_val(width),
		  Int_val(height), Int_val(depth), Int_val(border), 
		  GLExtenum_val(format), Type_raw(data), Void_raw(data));
    /*    fflush(stdout); */
    return Val_unit;
}

ML_bc9 (ml_glTexImage3D)

CAMLprim value mlext_glBindTexture (value target, value texture_id)
{
    GLenum targ = GLExtenum_val(target);
    GLuint id = Int32_val(texture_id);
    glBindTexture(targ,id);
    return Val_unit;
}

CAMLprim value mlext_glTexParameter (value target, value param)
{
    GLenum targ = GLExtenum_val(target);
    GLenum pname = GLExtenum_val(Field(param,0));
    value params = Field(param,1);
    GLfloat color[4];
    int i;

    switch (pname) {
    case GL_TEXTURE_BORDER_COLOR:
	for (i = 0; i < 4; i++) color[i] = Float_val(Field(params,i));
	glTexParameterfv (targ, pname, color);
	break;
    case GL_TEXTURE_PRIORITY:
	glTexParameterf (targ, pname, Float_val(params));
	break;
    case GL_GENERATE_MIPMAP:
#ifdef GL_VERSION_1_4
        glTexParameteri (targ, pname, Int_val(params));
#else
        ml_raise_gl ("Parameter: GL_GENERATE_MIPMAP not available"); 
#endif
        break;
    default:
	glTexParameteri (targ, pname, GLExtenum_val(params));
	break;
    }
    return Val_unit;
}
