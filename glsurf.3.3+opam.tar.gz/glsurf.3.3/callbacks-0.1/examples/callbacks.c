#include <caml/mlvalues.h>
#include <caml/callback.h>
#include <caml/memory.h>
#include <caml/signals.h>


#include <mlvalues.h>
#include <alloc.h>
#include <stdio.h>
#include <stdlib.h>

#define Extended_wosize ((sizeof(long double) / sizeof(value)))

value add_extended(value x, value y) {
  CAMLparam2(x,y);
  CAMLlocal1(res);
  res = alloc_small(Extended_wosize, Abstract_tag);
   *(long double *) res = *(long double *) x + *(long double *) y;
  CAMLreturn(res);
}

value float_of_int_extended(value x) {
  CAMLparam1(x);
  CAMLlocal1(res);
  res = alloc_small(Extended_wosize, Abstract_tag);
   *(long double *) res = (long double) (Long_val(x));
  CAMLreturn(res);
}

value float_of_string_extended(value x) {
  CAMLparam1(x);
  CAMLlocal1(res);
  res = alloc_small(Extended_wosize, Abstract_tag);
  sscanf(String_val(x),"%Le",(long double *) res);
  CAMLreturn(res);
}

value string_of_float_extended(value x) {
  CAMLparam1(x);
  CAMLlocal1(res);
  char str[48];
  sprintf(str,"%.22Le",*(long double *)x);
  res = caml_copy_string(str);
  CAMLreturn(res);
}

CAMLprim value add_extended_cfun(value arg1, value arg2)
{
	caml_register_global_root(&arg1);
	caml_register_global_root(&arg2);
	enter_blocking_section ();
	value  c_result = add_extended(arg1, arg2);
	leave_blocking_section ();
	caml_remove_global_root(&arg1);
	caml_remove_global_root(&arg2);
	return c_result;
}

CAMLprim value float_of_int_extended_cfun(value arg1)
{
	caml_register_global_root(&arg1);
	enter_blocking_section ();
	value  c_result = float_of_int_extended(arg1);
	leave_blocking_section ();
	caml_remove_global_root(&arg1);
	return c_result;
}

CAMLprim value float_of_string_extended_cfun(value arg1)
{
	caml_register_global_root(&arg1);
	enter_blocking_section ();
	value  c_result = float_of_string_extended(arg1);
	leave_blocking_section ();
	caml_remove_global_root(&arg1);
	return c_result;
}

CAMLprim value string_of_float_extended_cfun(value arg1)
{
	caml_register_global_root(&arg1);
	enter_blocking_section ();
	value  c_result = string_of_float_extended(arg1);
	leave_blocking_section ();
	caml_remove_global_root(&arg1);
	return c_result;
}

