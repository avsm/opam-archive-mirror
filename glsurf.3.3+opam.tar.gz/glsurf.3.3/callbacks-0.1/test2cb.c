#include <caml/mlvalues.h>
#include <caml/callback.h>
#include <caml/memory.h>
#include <caml/signals.h>

value fcb_cpointer = (value) NULL; 
void fcb_cfun(void)
{
	leave_blocking_section ();
	caml_callback(fcb_cpointer,Val_unit); 
	enter_blocking_section ();
}

CAMLprim value fcb_set_cpointer (value cb) {
	if (fcb_cpointer == cb) return Val_unit;
	if (!fcb_cpointer) caml_register_global_root(&fcb_cpointer);
	fcb_cpointer=cb;
	return (value) &fcb_cfun;
}

value gcb_cpointer = (value) NULL; 
int  gcb_cfun(int arg1)
{
	leave_blocking_section ();
	value caml_result = caml_callback(gcb_cpointer,Val_int(arg1)); 
int result = Int_val(caml_result);
	enter_blocking_section ();
return result;}

CAMLprim value gcb_set_cpointer (value cb) {
	if (gcb_cpointer == cb) return Val_unit;
	if (!gcb_cpointer) caml_register_global_root(&gcb_cpointer);
	gcb_cpointer=cb;
	return (value) &gcb_cfun;
}


int f(int n; int m) { return n + m; }

CAMLprim value f_cfun(value arg1)
{
	enter_blocking_section ();
	int  c_result = f(Int_val(arg1));
	leave_blocking_section ();
	return Val_int(result);
}


value idt(value x) { return x; }

CAMLprim value idt_cfun(value arg1)
{
	caml_register_global_root(&arg1);
	enter_blocking_section ();
	value c_result = idt(arg1);
	leave_blocking_section ();
	caml_unregister_global_root(&arg1);
	return result;
}

