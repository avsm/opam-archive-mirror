#!/bin/sh

cd /src
opam pin add mirage-block-xen . -y
