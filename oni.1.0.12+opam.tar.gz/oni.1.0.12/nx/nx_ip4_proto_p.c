/*---------------------------------------------------------------------------*
  $Change$
  Copyright (c) 2003-2016, James H. Woodyatt
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  
    Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
    
    Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in
    the documentation and/or other materials provided with the
    distribution
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
  COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
  STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
  OF THE POSSIBILITY OF SUCH DAMAGE. 
 *---------------------------------------------------------------------------*/

#include "nx_ip4_proto_p.h"

#include <string.h>
#include <errno.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>

#define FAILWITH(S)             (failwith("Nx_ip4_proto." S))
#define INVALID_ARGUMENT(S)     (invalid_argument("Nx_ip4_proto." S))

static int nx_ip4_proto_sockaddr_compare(value v1, value v2)
{
    CAMLparam2(v1, v2);
    const struct sockaddr_in* sinAddr1Ptr;
    const struct sockaddr_in* sinAddr2Ptr;
    const uint8_t* addr1Ptr;
    const uint8_t* addr2Ptr;
    int i, result;
    
    sinAddr1Ptr = &Nx_socket_sockaddrx_val(in, v1)->sx_sockaddr_in;
    sinAddr2Ptr = &Nx_socket_sockaddrx_val(in, v2)->sx_sockaddr_in;
    
    addr1Ptr = (uint8_t*)(&sinAddr1Ptr->sin_addr) + 3;
    addr2Ptr = (uint8_t*)(&sinAddr2Ptr->sin_addr) + 3;
    
    for (i = 4; i >= 0; --i, --addr1Ptr, --addr2Ptr) {
        result = *addr1Ptr - *addr2Ptr;
        if (result) goto done;
    }
    
    addr1Ptr = (uint8_t*) &(sinAddr1Ptr->sin_port) + 1;
    addr2Ptr = (uint8_t*) &(sinAddr2Ptr->sin_port) + 1;
    
    for (i = 2; i >= 0; --i, --addr1Ptr, --addr2Ptr) {
        result = *addr1Ptr - *addr2Ptr;
        if (result) goto done;
    }
    
  done:
    CAMLreturn(result);
}

static long nx_ip4_proto_sockaddr_hash(value sxVal)
{
    CAMLparam1(sxVal);
    const struct sockaddr_in* sinPtr;
    long result;
    
    sinPtr = &Nx_socket_sockaddrx_val(in, sxVal)->sx_sockaddr_in;
    result = (long) ntohl(sinPtr->sin_addr.s_addr);
    result ^= ntohs(sinPtr->sin_port);
    
    CAMLreturn(result);
}

static void nx_ip4_proto_sockaddr_serialize
   (value sxVal, unsigned long* size32Ptr, unsigned long* size64Ptr)
{
    CAMLparam1(sxVal);
    const struct sockaddr_in* sinPtr;
    
    sinPtr = &Nx_socket_sockaddrx_val(in, sxVal)->sx_sockaddr_in;
    serialize_int_4(ntohl(sinPtr->sin_addr.s_addr));
    serialize_int_2(ntohs(sinPtr->sin_port));
    
    *size32Ptr = sizeof *sinPtr;
    *size64Ptr = sizeof *sinPtr;
    
    CAMLreturn0;
}

static unsigned long nx_ip4_proto_sockaddr_deserialize(void* bufferPtr)
{
    struct sockaddr_in* sinPtr;
    
    sinPtr = (struct sockaddr_in*) bufferPtr;
    sinPtr->sin_family = AF_INET;
    sinPtr->sin_addr.s_addr = deserialize_uint_4();
    sinPtr->sin_addr.s_addr = htonl(sinPtr->sin_addr.s_addr);
    sinPtr->sin_port = deserialize_uint_2();
    sinPtr->sin_port = htons(sinPtr->sin_port);
    
    return sizeof *sinPtr;
}

static struct custom_operations nx_ip4_proto_sockaddr_op = {
    "org.conjury.oni.cf.sockaddr_in",
    custom_finalize_default,
    nx_ip4_proto_sockaddr_compare,
    nx_ip4_proto_sockaddr_hash,
    nx_ip4_proto_sockaddr_serialize,
    nx_ip4_proto_sockaddr_deserialize
};

value nx_ip4_proto_sockaddr_cons(const struct sockaddr* saPtr, size_t saLen)
{
    value sxVal;
    Nx_socket_sockaddrx_in_t* sxPtr;
    const size_t sxLen =
        offsetof(Nx_socket_sockaddrx_in_t, sx_sockaddr_in) +
        sizeof(struct sockaddr_in);
            
    sxVal = alloc_custom(&nx_ip4_proto_sockaddr_op, sxLen, 0, 1);
    sxPtr = Nx_socket_sockaddrx_val(in, sxVal);
    if (sxPtr) {
        sxPtr->sx_socklen = saLen;
        memcpy(&sxPtr->sx_sockaddr_in, saPtr, saLen);
    }
    
    return sxVal;
}

static value nx_ip4_proto_domain_val = Val_unit;

/*---
    external domain_: unit -> 'a Nx_socket.domain_t = "nx_ip4_proto_domain"
  ---*/
CAMLprim value nx_ip4_proto_domain(value unit)
{
    CAMLparam0();
    (void) unit;
    CAMLreturn(nx_ip4_proto_domain_val);
}

/*---
    external to_sockaddr:
        Nx_ip4_addr.opaque Nx_ip4_addr.t * int ->
        [`AF_INET] Nx_socket.sockaddr_t = "nx_ip4_proto_to_sockaddr"
  ---*/
CAMLprim value nx_ip4_proto_to_sockaddr(value addrVal)
{
    CAMLparam1(addrVal);
    CAMLlocal1(resultVal);
    
    struct sockaddr_in sin;
    int port;
    
    port = Int_val(Field(addrVal, 1));
    if (port < 0 || port > 65535)
        INVALID_ARGUMENT("to_sockaddr: invalid port number");
    
    memset(&sin, 0, sizeof sin);
    sin.sin_family = AF_INET;
    sin.sin_port = htons(port);
    sin.sin_addr = *Nx_ip4_addr_val(Field(addrVal, 0));
    
    resultVal =
        nx_ip4_proto_sockaddr_cons((struct sockaddr*) &sin, sizeof sin);
    CAMLreturn(resultVal);
}

/*---
    external of_sockaddr:
        [`AF_INET] Nx_socket.sockaddr_t ->
        Nx_ip4_addr.opaque Nx_ip4_addr.t * int = "nx_ip4_proto_of_sockaddr"
  ---*/
CAMLprim value nx_ip4_proto_of_sockaddr(value sxVal)
{
    CAMLparam1(sxVal);
    CAMLlocal2(addrVal, resultVal);
    
    const Nx_socket_sockaddrx_in_t* sxPtr;
    const struct sockaddr_in* sinPtr;
    
    sxPtr = Nx_socket_sockaddrx_val(in, sxVal);
    sinPtr = &sxPtr->sx_sockaddr_in;
    addrVal = nx_ip4_addr_alloc(&sinPtr->sin_addr);
    
    resultVal = alloc_small(2, 0);
    Field(resultVal, 0) = addrVal;
    Field(resultVal, 1) = Val_int(ntohs(sinPtr->sin_port));

    CAMLreturn(resultVal);
}

/*---
    external siocgifaddr:
        ([ `AF_INET ], 'st) Nx_socket.t -> string ->
        [> Nx_ip4_addr.unicast ] Nx_ip4_addr.t = "nx_ip4_proto_siocgifaddr"
  ---*/
CAMLprim value nx_ip4_proto_siocgifaddr(value sockVal, value nameVal)
{
    CAMLparam2(sockVal, nameVal);
    CAMLlocal1(resultVal);
    const char* namePtr;
    const Nx_socket_t* sockPtr;
    char buffer[IF_NAMESIZE + sizeof(struct sockaddr_storage)];
    struct ifreq* ifrPtr;
    const struct sockaddr_in* sinPtr;
    int v;
    
    namePtr = String_val(nameVal);
    if (string_length(nameVal) > IF_NAMESIZE || strlen(namePtr) >= IF_NAMESIZE)
        invalid_argument("ioctl[SIOCGIFADDR]: name too long.");
    
    memset(buffer, 0, sizeof buffer);
    ifrPtr = (struct ifreq*) buffer;
    strcpy(ifrPtr->ifr_name, String_val(nameVal));
    sockPtr = Nx_socket_val(sockVal);
    
    v = ioctl(sockPtr->s_fd, SIOCGIFADDR, buffer);
    if (v == -1) unix_error(errno, "ioctl[SIOCGIFADDR]", Nothing);
    
    sinPtr = (const struct sockaddr_in*) &ifrPtr->ifr_addr;
    resultVal = nx_ip4_addr_alloc(&sinPtr->sin_addr);
    CAMLreturn(resultVal);
}

value nx_ip4_proto_getsockopt_uchar
   (const Nx_socket_option_context_t* contextPtr)
{
    u_char optval;
    socklen_t optlen;
    
    memset(&optval, 0, sizeof optval);
    optlen = sizeof optval;
    nx_socket_getsockopt_guard(contextPtr, &optval, &optlen);
    
    return Val_int(optval);
}

void nx_ip4_proto_setsockopt_uchar
   (const Nx_socket_option_context_t* contextPtr, value x)
{
    u_char optval;
    int n;
    
    n = Int_val(x);
    if (n < 0 || n > 0xFF)
        invalid_argument("Nx_ip4_proto.setsockopt[uchar]: range error.");
    
    optval = n;
    nx_socket_setsockopt_guard(contextPtr, &optval, sizeof optval);
}

value nx_ip4_proto_getsockopt_addr
   (const Nx_socket_option_context_t* contextPtr)
{
    struct in_addr optval;
    socklen_t optlen;
    
    memset(&optval, 0, sizeof optval);
    optlen = sizeof optval;
    nx_socket_getsockopt_guard(contextPtr, &optval, &optlen);
        
    return nx_ip4_addr_alloc(&optval);
}

void nx_ip4_proto_setsockopt_addr
   (const Nx_socket_option_context_t* contextPtr, value x)
{
    struct in_addr optval;
    
    optval = *Nx_ip4_addr_val(x);
    nx_socket_setsockopt_guard(contextPtr, &optval, sizeof optval);
}

value nx_ip4_proto_getsockopt_mreq
   (const Nx_socket_option_context_t* contextPtr)
{
    CAMLparam0();
    CAMLlocal3(multiaddrVal, interfaceVal, resultVal);
    struct ip_mreq optval;
    socklen_t optlen;
    
    memset(&optval, 0, sizeof optval);
    optlen = sizeof optval;
    nx_socket_getsockopt_guard(contextPtr, &optval, &optlen);
    
    multiaddrVal = nx_ip4_addr_alloc(&optval.imr_multiaddr);
    interfaceVal = nx_ip4_addr_alloc(&optval.imr_interface);
    
    resultVal = alloc_small(2, 0);
    Field(resultVal, 0) = multiaddrVal;
    Field(resultVal, 0) = interfaceVal;

    CAMLreturn(resultVal);
}

void nx_ip4_proto_setsockopt_mreq
   (const Nx_socket_option_context_t* contextPtr, value x)
{
    struct ip_mreq optval;
    
    optval.imr_multiaddr = *Nx_ip4_addr_val(Field(x, 0));
    optval.imr_interface = *Nx_ip4_addr_val(Field(x, 1));
    nx_socket_setsockopt_guard(contextPtr, &optval, sizeof optval);
}

/*---
    type sockopt_index_t =
        IP_TTL | IP_ADD_MEMBERSHIP | IP_DROP_MEMBERSHIP | IP_MULTICAST_IF |
        IP_MULTICAST_TTL | IP_MULTICAST_LOOP
  ---*/
static Nx_socket_sockopt_lift_t nx_ip4_proto_sockopt_lift_array[] = {
    { /* IP_TTL */
        Val_unit,
        {
            IPPROTO_IP, IP_TTL,
            nx_socket_getsockopt_int, nx_socket_setsockopt_int
        }
    },
    
    { /* IP_ADD_MEMBERSHIP */
        Val_unit,
        {
            IPPROTO_IP, IP_ADD_MEMBERSHIP,
            nx_ip4_proto_getsockopt_mreq, nx_ip4_proto_setsockopt_mreq
        }
    },
    
    { /* IP_DROP_MEMBERSHIP */
        Val_unit,
        {
            IPPROTO_IP, IP_DROP_MEMBERSHIP,
            nx_ip4_proto_getsockopt_mreq, nx_ip4_proto_setsockopt_mreq
        }
    },
    
    { /* IP_MULTICAST_IF */
        Val_unit,
        {
            IPPROTO_IP, IP_MULTICAST_IF,
            nx_ip4_proto_getsockopt_addr, nx_ip4_proto_setsockopt_addr
        }
    },
    
    { /* IP_MULTICAST_TTL */
        Val_unit,
        {
            IPPROTO_IP, IP_MULTICAST_TTL,
            nx_ip4_proto_getsockopt_uchar, nx_ip4_proto_setsockopt_uchar
        }
    },
    
    { /* IP_MULTICAST_LOOP */
        Val_unit,
        {
            IPPROTO_IP, IP_MULTICAST_LOOP,
            nx_ip4_proto_getsockopt_uchar, nx_ip4_proto_setsockopt_uchar
        }
    },
};

#define NX_IP4_PROTO_SOCKOPT_LIFT_ARRAY_SIZE \
    (sizeof nx_ip4_proto_sockopt_lift_array / \
        sizeof nx_ip4_proto_sockopt_lift_array[0])

/*---
    external sockopt_lift:
        sockopt_index_t -> ('a, 'b, 'c) Nx_socket.sockopt_t =
        "nx_ip4_proto_sockopt_lift"
  ---*/
CAMLprim value nx_ip4_proto_sockopt_lift(value indexVal)
{
    CAMLparam1(indexVal);
    CAMLreturn(nx_ip4_proto_sockopt_lift_array[Int_val(indexVal)].ol_val);
}

/*---
  Initialization primitive
  ---*/
CAMLprim value nx_ip4_proto_init(value unit)
{
    int i;
    
    static Nx_socket_domain_t domain = {
        PF_INET, AF_INET, nx_ip4_proto_sockaddr_cons,
        sizeof(struct sockaddr_in)
    };
    
    (void) unit;
    register_custom_operations(&nx_ip4_proto_sockaddr_op);
    
    register_global_root(&nx_ip4_proto_domain_val);
    nx_ip4_proto_domain_val = nx_socket_domain_alloc(&domain);
    
    for (i = 0; i < NX_IP4_PROTO_SOCKOPT_LIFT_ARRAY_SIZE; ++i) {        
        Nx_socket_sockopt_lift_t* liftPtr;
        
        liftPtr = &nx_ip4_proto_sockopt_lift_array[i];
        register_global_root(&liftPtr->ol_val);
        liftPtr->ol_val = nx_socket_option_alloc(&liftPtr->ol_option);
    }
    
    return Val_unit;
}

/*--- $File$ ---*/
