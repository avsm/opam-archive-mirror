(*---------------------------------------------------------------------------*
  $Change$
  Copyright (c) 2003-2014, James H. Woodyatt
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  
    Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
  
    Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in
    the documentation and/or other materials provided with the
    distribution
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
  COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
  STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
  OF THE POSSIBILITY OF SUCH DAMAGE. 
 *---------------------------------------------------------------------------*)

Random.self_init ();;

let jout = Cf_journal.stdout
let _ = jout#setlimit `Notice

(*
Gc.set {
    (Gc.get ()) with
    (* Gc.verbose = 0x3ff; *)
    Gc.verbose = 0x14;
};;

Gc.create_alarm begin fun () ->
    let min, pro, maj = Gc.counters () in
    Printf.printf "[Gc] minor=%f promoted=%f major=%f\n" min pro maj;
    flush stdout
end
*)

module T1 = struct
    module V6 = Nx_ip6_addr
    open Printf
    
    let v6_unicast_cases = [
        "::DEAD:BEEF:D00D", V6.U_reserved;
        "::1", V6.U_loopback;
        "4000::1", V6.U_unassigned;
        "::10.0.1.1", V6.U_v4compat;
        "::FFFF:17.201.23.45", V6.U_v4mapped;
        "2002::1", V6.U_global;
        "FE80::203:93ff:feba:7eba", V6.U_link;
        "FEC0::1", V6.U_site;
        "::224.0.0.1", V6.U_reserved;
    ]
    
    let v6_unicast_test () =
        List.iter begin fun (addr, fmt) ->
            match V6.pton addr with
            | Some addr' ->
                if fmt <> V6.unicast_format (V6.is_unicast addr') then
                    failwith (sprintf "V6.unicast_format %s" addr)
            | None ->
                failwith (sprintf "unrecognized %s" addr)
        end v6_unicast_cases
    
    let test () =
        v6_unicast_test ()
end

module T2 = struct
    let len = 10
    
    let test () =
        try
            let bind =
                (Nx_ip4_addr.loopback :> Nx_ip4_addr.opaque Nx_ip4_addr.t), 0
            in
            let listen = new Nx_tcp4_socket.listener bind in
            listen#listen 1;
            let bind = listen#getsockname in
            let active = new Nx_tcp4_socket.initiator bind in
            active#connect;
            let a, _ = listen#accept in
            let a = new Nx_tcp4_socket.endpoint a in
            let b = new Nx_tcp4_socket.endpoint (active#socket) in
            let laddr = a#getpeername and raddr = b#getsockname in
            let lhost, lport = laddr in
            let rhost, rport = raddr in
            if lhost <> rhost then
                failwith "T2 error: host a#getpeername <> b#getsockname";
            if lport <> rport then
                failwith "T2 error: port a#getpeername <> b#getsockname";
            let laddr = a#getsockname and raddr = b#getpeername in
            let lhost, lport = laddr in
            let rhost, rport = raddr in
            if lhost <> rhost then
                failwith "T2 error: host a#getsockname <> b#getpeername";
            if lport <> rport then
                failwith "T2 error: port a#getsockname <> b#getpeername";
            let tx = String.make len 'x' and rx = Bytes.create len in
            let n = a#send tx 0 len in
            if n <> len then failwith "T2 error: tx incomplete!";
            a#shutdown Unix.SHUTDOWN_SEND;
            let n = b#recv rx 0 len in
            if n <> len then failwith "T2 error: rx incomplete!";
            let rx = Bytes.to_string rx in
            if tx <> rx then failwith "T2 error: tx <> rx!";
            a#close;
            b#close;
            listen#close
        with
        | Unix.Unix_error (e, fn, _) ->
            failwith (Printf.sprintf "T2 error: %s in %s.\n"
                (Unix.error_message e) fn)
end

module T3 = struct
    let len = 10
    
    let test () =
        try
            let bind =
                (Nx_ip6_addr.loopback :> Nx_ip6_addr.opaque Nx_ip6_addr.t),
                0, 0l
            in
            let listen = new Nx_tcp6_socket.listener bind in
            listen#listen 1;
            let bind = listen#getsockname in
            let active = new Nx_tcp6_socket.initiator bind in
            active#connect;
            let a = new Nx_tcp6_socket.endpoint (active#socket) in
            let b, _ = listen#accept in
            let b = new Nx_tcp6_socket.endpoint b in
            let laddr = a#getpeername and raddr = b#getsockname in
            let lhost, lport, lscope = laddr in
            let rhost, rport, rscope = raddr in
            if lhost <> rhost then
                failwith "T3 error: host a#getpeername <> b#getsockname";
            if lport <> rport then
                failwith "T3 error: port a#getpeername <> b#getsockname";
            if lscope <> rscope then
                failwith "T3 error: port a#getpeername <> b#getsockname";
            let laddr = a#getsockname and raddr = b#getpeername in
            let lhost, lport, lscope = laddr in
            let rhost, rport, rscope = raddr in
            if lhost <> rhost then
                failwith "T3 error: host a#getsockname <> b#getpeername";
            if lport <> rport then
                failwith "T3 error: port a#getsockname <> b#getpeername";
            if lscope <> rscope then
                failwith "T3 error: port a#getsockname <> b#getpeername";
            let tx = String.make len 'x' and rx = Bytes.create len in
            let n = a#send tx 0 len in
            if n <> len then failwith "T3 error: tx incomplete!";
            a#shutdown Unix.SHUTDOWN_SEND;
            let n = b#recv rx 0 len in
            if n <> len then failwith "T3 error: rx incomplete!";
            let rx = Bytes.to_string rx in
            if tx <> rx then failwith "T3 error: tx <> rx!";
            a#close;
            b#close;
            listen#close
        with
        | Unix.Unix_error (e, fn, _) ->
            failwith (Printf.sprintf "T3 error: %s in %s.\n"
                (Unix.error_message e) fn)
end

module T4 = struct
    open Nx_poll
    
    class clock n dt =
        object
            inherit [unit] time dt as super
            
            val mutable count_ = n
                        
            method private service _ =
                let tai, frac = Cf_tai64n.decompose epoch_ in
                let utc = Cf_stdtime.utc_of_tai64 tai in
                jout#info
                    "T4.clock#service: %04u-%02u-%02u %02u:%02u:%02u.%06u "
                    utc.Cf_stdtime.year utc.Cf_stdtime.month utc.Cf_stdtime.day
                    utc.Cf_stdtime.hour utc.Cf_stdtime.minute
                    utc.Cf_stdtime.second frac;
                if count_ > 0 then begin
                    count_ <- pred count_;
                    state_
                end
                else
                    Nx_poll.Final ()
            
            method count = count_
        end
    
    class interrupt n dt =
        object(self:'self)
            inherit [int] signal Sys.sigint as super
            
            val clock_ = new clock n dt
            
            method private load_ p =
                clock_#load p;
                super#load_ p
            
            method private unload_ p =
                super#unload_ p;
                clock_#unload
            
            method private service _ =
                clock_#unload;
                Nx_poll.Final clock_#count
            
            method canget =
                if not super#canget then begin
                    if not clock_#canget then
                        false
                    else begin
                        self#unload;
                        state_ <- Nx_poll.Final 0;
                        true
                    end
                end
                else begin
                    clock_#unload;
                    true
                end
        end
    
    let test () =
        let e = new interrupt 10 0.05 in
        let p = create () in
        e#load p;
        let save = Unix.sigprocmask Unix.SIG_SETMASK [] in
        let more = ref More in
        while not e#canget do
            if !more <> More then failwith "!More";
            more := cycle p
        done;
        if !more = More then more := cycle p;
        if !more <> Last then failwith "!Last";
        ignore (Unix.sigprocmask Unix.SIG_SETMASK save)
end

let main () =
    let tests = [ T1.test; T2.test; T3.test; T4.test ] in
    Printf.printf "1..%d\n" (List.length tests);
    flush stdout;
    
    let test i f =
        begin
            try
                (* let tms0 = Unix.times () in *)
                f ();
                (*
                let tms1 = Unix.times () in
                let ut = tms1.Unix.tms_utime -. tms0.Unix.tms_utime in
                let st = tms1.Unix.tms_stime -. tms0.Unix.tms_stime in
                Printf.printf "ok %d (ut=%f st=%f)\n" i ut st
                *)
                Printf.printf "ok %d\n" i
            with
            | Failure(s) ->
                Printf.printf "not ok %d (Failure \"%s\")\n" i s
            | x ->
                Printf.printf "not ok %d\n" i;
                flush stdout;
                raise x
        end;
        flush stdout;
        succ i
    in
    let _ = List.fold_left test 1 tests in
    exit 0
;;

main ();;

(*--- $File$ ---*)
