(*---------------------------------------------------------------------------*
  $Change$
  Copyright (c) 2003-2016, James H. Woodyatt
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  
    Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
    
    Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in
    the documentation and/or other materials provided with the
    distribution
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
  COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
  STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
  OF THE POSSIBILITY OF SUCH DAMAGE. 
 *---------------------------------------------------------------------------*)

Random.self_init ();;

let signalF n = failwith (Printf.sprintf "signal %d" n)
let _ = Sys.signal Sys.sigpipe (Sys.Signal_handle signalF)

(**)
let jout = Cf_journal.stdout
let () = jout#setlimit `Info
(**)

(*
Gc.set {
    (Gc.get ()) with
    Gc.verbose = 0x3ff;
    (* Gc.verbose = 0x14; *)
};;

Gc.create_alarm begin fun () ->
    let min, pro, maj = Gc.counters () in
    Printf.printf "[Gc] minor=%f promoted=%f major=%f\n" min pro maj;
    flush stdout
end
*)

let test_run r =
    let okay = ref false in
    try
        Iom_gadget.run (r okay);
        if not !okay then failwith "reactor: processing completed early."
    with
    | Unix.Unix_error (error, fname, arg) ->
        let error = Unix.error_message error in
        jout#fail "Unix error \"%s\" in %s(%s)" error fname arg
    | x ->
        raise x

module T1 = struct
    open Cf_cmonad.Op
    module G = Iom_gadget
    
    let limits = { Iom_octet_stream.low = 1; high = 100 }
    
    let msg =
        let s = String.make 50001 'x' in
        [ s, 0, String.length s ]
    
    let fragment count =
        let more = if count > 0 then Iom_stream.More else Iom_stream.Last in
        new Iom_octet_stream.fragment more msg
    
    class top ~okay ~count readJack writeJack timeJack idleJack =
        let expected = count * (Cf_message.length msg) in
        let wrTx, (wrNtfyRx, _) = writeJack in
        let rdRx, (rdNtfyRx, rdCtrlTx) = readJack in
        let timeRx, timeTx = timeJack in
        let idleRx, idleTx = idleJack in
        object(self:'self)
            inherit Iom_gadget.start as super
            inherit Iom_gadget.next as subnext
            
            val count_ = count
            val nbytes_ = 0
            
            method next = subnext#next
            
            method private rnotify (`Failed x) =
                jout#fail "T1.top#rnotify: failed! [%s]" (Printexc.to_string x)
            
            method private wnotify = function
                | `Complete ->
                    self#next
                | `Failed x ->
                    jout#fail "T1.top#wnotify: failed! [%s]"
                        (Printexc.to_string x)
                | (`Ready | `Wait) ->
                    self#next
            
            method private rd fragment =
                let more = fragment#more and data = fragment#data in
                assert begin
                    jout#debug "T1.top#rd: fragment received [%u, %s]"
                    (Cf_message.length data)
                    (match more with Iom_stream.More -> "More" | _ -> "Last")
                end;
                let nbytes = nbytes_ + Cf_message.length data in
                match more with
                | Iom_stream.More ->
                    let s = ({< nbytes_ = nbytes >} :> Iom_gadget.next) in
                    s#next
                | Iom_stream.Last ->
                    if nbytes <> expected then
                        jout#fail "T1.top#rd: size mismatch %u <> %u"
                            nbytes expected;
                    okay := true;
                    if count_ > 0 then self#next else Cf_cmonad.nil
            
            method private timer (`Time tm) =
                let tai, frac = Cf_tai64n.decompose tm in
                let utc = Cf_stdtime.utc_of_tai64 tai in
                assert begin
                    jout#debug
                    "T1.top#timer: %04u-%02u-%02u %02u:%02u:%02u.%06u "
                    utc.Cf_stdtime.year utc.Cf_stdtime.month utc.Cf_stdtime.day
                    utc.Cf_stdtime.hour utc.Cf_stdtime.minute
                    utc.Cf_stdtime.second (frac / 1000)
                end;
                let count = pred count_ in
                let s = ({< nbytes_ = count >} :> Iom_gadget.next) in
                let continue = s#next in
                if count > 0 then
                    wrTx#put (fragment count) >>= fun () ->
                    continue
                else begin
                    timeTx#put `Stop >>= fun () ->
                    idleTx#put `Stop >>= fun () ->
                    continue
                end
            
            method private idle (`Idle tm) =
                let tai, frac = Cf_tai64n.decompose tm in
                let utc = Cf_stdtime.utc_of_tai64 tai in
                assert begin
                    jout#debug
                    "T1.top#idle: %04u-%02u-%02u %02u:%02u:%02u.%06u "
                    utc.Cf_stdtime.year utc.Cf_stdtime.month utc.Cf_stdtime.day
                    utc.Cf_stdtime.hour utc.Cf_stdtime.minute
                    utc.Cf_stdtime.second (frac / 1000)
                end;
                self#next
            
            method private guard =
                rdNtfyRx#get self#rnotify >>= fun () ->
                wrNtfyRx#get self#wnotify >>= fun () ->
                rdRx#get self#rd >>= fun () ->
                timeRx#get self#timer >>= fun () ->
                idleRx#get self#idle
            
            method private start =
                wrTx#put (fragment (pred count_)) >>= fun () ->
                rdCtrlTx#put `Ready >>= fun () ->
                timeTx#put `Ready >>= fun () ->
                idleTx#put `Ready >>= fun () ->
                super#start
        end
        
    let reactor okay k =
        Iom_pipe.create ~limits k >>= fun (readJack, writeJack) ->
        Iom_reactor.timer ~dt:0.5 k >>= fun timeJack ->
        Iom_reactor.idler k >>= fun idleJack ->
        let count = 1 in
        let top = new top ~okay ~count readJack writeJack timeJack idleJack in
        top#start

    let test () =
        test_run reactor
end

module F0(S: Iom_sock_stream.T) = struct
    open Cf_cmonad.Op
    
    let backlog = 1
    let limits = { Iom_octet_stream.low = 1; high = 1000 }
    
    type complete = [ `Complete ]
    
    type exchange_jack = [ Iom_stream.failed | complete ] Iom_gadget.rx
    
    let fragment s =
        new Iom_octet_stream.fragment Iom_stream.Last (Cf_message.create s)
    
    class exchange upTx socketJack =
        let upTx = (upTx :> 'up Iom_gadget.tx) in
        let ((upRx, dnTx), (notifyRx, controlTx)) = socketJack in
        object(self)
            inherit Iom_gadget.start as super
            inherit Iom_gadget.next as subnext
            
            method next = subnext#next
            
            method private fail: 'a. exn -> 'a Iom_gadget.t = fun x ->
                upTx#put (`Failed x) >>= fun () ->
                Iom_gadget.abort
            
            method private notify = function
                | `Failed x ->
                    self#fail x
                | `Ready ->
                    assert (jout#debug "F0.exchange#notify: `Ready");
                    self#next
                | `Wait ->
                    assert (jout#debug "F0.exchange#notify: `Wait");
                    self#next
            
            method private up fragment =
                match fragment#more with
                | Iom_stream.Last ->
                    upTx#put `Complete
                | Iom_stream.More ->
                    assert begin
                        jout#debug "F0.exchange#up: receive! \"%s\""
                        (Cf_message.contents fragment#data)
                    end;
                    self#next
            
            method private guard =
                notifyRx#get self#notify >>= fun () ->
                upRx#get self#up
            
            method start =
                dnTx#put (fragment "this is a test!") >>= fun () ->
                controlTx#put `Ready >>= fun () ->
                super#start
        end
    
    let exchange socketJack =
        Iom_gadget.simplex >>= fun (upRx, upTx) ->
        let x = new exchange upTx socketJack in
        x#start >>= fun () ->
        Cf_cmonad.return upRx
    
    type state =
        | S_listening of S.listener
        | S_initiating of S.listener * exchange_jack
        | S_established of exchange_jack * exchange_jack * int
    
    class top ~okay listenJack k =
        object(self)
            inherit Iom_gadget.start as super
            inherit Iom_gadget.next
            
            val state_ = S_listening listenJack
            
            method private listen = function
                | `Listen dst ->
                    let addrs = (S.unspecified_address, dst) in
                    S.endpoint ~addrs ~limits k >>= fun socketJack ->
                    exchange socketJack >>= fun exchangeRx ->
                    let state = S_initiating (listenJack, exchangeRx) in
                    let s = ({< state_ = state >} :> Iom_gadget.next) in
                    s#next
                | `Failed x ->
                    jout#fail "F0.top#listen: failed! [%s]"
                        (Printexc.to_string x)
            
            method private connect c =
                match state_ with
                | S_initiating (listenJack, exch1Rx) ->
                    let _, (_, listenTx) = listenJack in
                    listenTx#put `Stop >>= fun () ->
                    S.endpoint ~s:c#socket ~limits k >>= fun socketJack ->
                    exchange socketJack >>= fun exch2Rx ->
                    let state = S_established (exch1Rx, exch2Rx, 1) in
                    let s = ({< state_ = state >} :> Iom_gadget.next) in
                    s#next
                | _ ->
                    jout#fail "F0.top#connect: state processing error!"
            
            method private exchange = function
                | `Failed x ->
                    jout#fail "F0.top#listen: failed! [%s]"
                        (Printexc.to_string x)
                | `Complete ->
                    match state_ with
                    | S_established (_, _, 0) ->
                        okay := true;
                        Iom_gadget.abort
                    | S_established (e1, e2, count) ->
                        let state = S_established (e1, e2, pred count) in
                        let s = ({< state_ = state >} :> Iom_gadget.next) in
                        s#next
                    | _ ->
                        jout#fail "F0.top#exchange: state processing error!"
            
            method private guard =
                match state_ with
                | S_listening (connectRx, (listenRx, _)) ->
                    connectRx#get self#connect >>= fun () ->
                    listenRx#get self#listen
                | S_initiating ((connectRx, (listenRx, _)), exchangeRx) ->
                    connectRx#get self#connect >>= fun () ->
                    listenRx#get self#listen >>= fun () ->
                    exchangeRx#get self#exchange
                | S_established (exchange1Rx, exchange2Rx, _) ->
                    exchange1Rx#get self#exchange >>= fun () ->
                    exchange2Rx#get self#exchange
            
            method start =
                let _, (_, controlTx) = listenJack in
                controlTx#put `Ready >>= fun () ->
                super#start
        end
    
    let reactor okay k =
        okay := false;
        S.listener ~backlog k >>= fun listenJack ->
        let top = new top ~okay listenJack k in
        top#start
    
    let test () =
        test_run reactor
end

module T2 = F0(Iom_tcp4_socket)
module T3 = F0(Iom_tcp6_socket)

module T4 = struct
    open Cf_cmonad.Op
    module S8 = Iom_octet_stream
    
    let data = "this is a test string!\n"
    
    module F = struct
        open Cf_parser.Op
                
        let lex () =
            Cf_parser.lit data () >>= fun () ->
            Cf_parser.fin >>= fun () ->
            ~:((), String.length data)
    end
    
    class parse flowTx readRx okayTx = object
        inherit [Iom_octet_stream.fragment, unit] Iom_octet_stream.scanner
            flowTx readRx okayTx as super
        
        val lex_ = F.lex ()
        
        method lex _ s = lex_ s
    end
    
    let limits0 = { Iom_octet_stream.low = 1; high = 5 }
    
    class emit flowTx dataRx writeTx = object(self)
        inherit [string, Iom_octet_stream.fragment] Iom_octet_stream.emitter
            ~limits:limits0 flowTx dataRx writeTx as super
        
        method private fragment x = Iom_stream.Last, (Cf_message.create x)
        
        method private pop acc len m =
            let pos = limits0.Iom_octet_stream.high in 
            if len > pos then begin
                let m1, m2 = Cf_message.split ~pos m in
                self#pop (m1 :: acc) (len - pos) m2
            end
            else begin
                let y =
                    List.map (new Iom_octet_stream.fragment Iom_stream.More)
                    acc
                in
                let y =
                    match more_ with
                    | Iom_stream.Last ->
                        let m = new Iom_octet_stream.fragment more_ m in
                        m :: y
                    | Iom_stream.More ->
                        y
                in
                List.rev y, mark_
            end
        
        method private emit = self#pop [] mark_ (Cf_message.drain buffer_)
    end
        
    class final okayRef jack =
        let okayRx, (_, controlTx) = jack in
        object
            inherit Iom_gadget.start as super
            inherit Iom_gadget.next
            
            method private guard =
                okayRx#get begin fun () ->
                    okayRef := true;
                    controlTx#put `Stop >>= fun () ->
                    Iom_gadget.abort
                end
            
            method start =
                controlTx#put `Ready >>= fun () ->
                super#start
        end
    
    let reactor okayRef k =
        okayRef := false;
        let limits = { Iom_octet_stream.low = 1; high = 3 } in
        Iom_pipe.create ~limits k >>= fun (ijack, ojack) ->
        Iom_layer.ingest ijack (new parse) >>= fun ijack ->
        Iom_layer.render ojack (new emit) >>= fun ojack ->
        let dataTx, _ = ojack in
        dataTx#put data >>= fun () ->
        let final = new final okayRef ijack in
        final#start
    
    let test () =
        test_run reactor
end
 
let main () =
    let tests = [
        T1.test;
        T2.test;
        T3.test;
        T4.test;
    ] in
    Printf.printf "1..%d\n" (List.length tests);
    flush stdout;
        
    let test i f =
        begin
            try
                f ();
                Printf.printf "ok %d\n" i
            with
            | Failure(s) ->
                Printf.printf "not ok %d (Failure \"%s\")\n" i s
            | x ->
                Printf.printf "not ok %d\n" i;
                flush stdout;
                raise x
        end;
        flush stdout;
        succ i
    in
    let _ = List.fold_left test 1 tests in
    exit 0
;;

main ();;

(*--- $File$ ---*)
