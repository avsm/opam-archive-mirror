(*---------------------------------------------------------------------------*
  $Change$
  Copyright (c) 2006-2016, James H. Woodyatt
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  
    Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
    
    Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in
    the documentation and/or other materials provided with the
    distribution
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
  COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
  STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
  OF THE POSSIBILITY OF SUCH DAMAGE. 
 *---------------------------------------------------------------------------*)

(*
let jout = Cf_journal.stdout
*)

open Cf_cmonad.Op

type stop = [ `Stop ]
type failed = [ `Failed of exn ]
type ready = [ `Ready ]
type wait = [ `Wait ]

type readywait = [ ready | wait ]
type flowcontrol = [ stop | readywait ]
type flownotify = [ failed | readywait ]

type more = Last | More
class type event = object method more: more end

type ('x, 'c, 'n) pad = 'x * ('c, 'n) Iom_gadget.pad
    constraint 'c = [> stop ]
    constraint 'n = [> failed ]

type ('x, 'c, 'n) fix = 'x * ('c, 'n) Iom_gadget.fix
    constraint 'c = [> stop ]
    constraint 'n = [> failed ]

type ('i, 'c, 'n) ipad = ('i Iom_gadget.tx, 'c, 'n) pad
    constraint 'c = [> readywait ]
    
type ('i, 'c, 'n) ifix = ('i Iom_gadget.rx, 'c, 'n) fix
    constraint 'c = [> readywait ]

type ('o, 'c, 'n) opad = ('o Iom_gadget.rx, 'c, 'n) pad
    constraint 'n = [> readywait ]

type ('o, 'c, 'n) ofix = ('o Iom_gadget.tx, 'c, 'n) fix
    constraint 'n = [> readywait ]

type ('i, 'o, 'c, 'n) iopad = (('o, 'i) Iom_gadget.pad, 'c, 'n) pad
    constraint 'c = [> readywait ]
    constraint 'n = [> readywait ]

type ('i, 'o, 'c, 'n) iofix = (('o, 'i) Iom_gadget.fix, 'c, 'n) fix
    constraint 'c = [> readywait ]
    constraint 'n = [> readywait ]

let ifix f =
    Iom_gadget.simplex >>= fun (inRx, inTx) ->
    Iom_gadget.create (fun pad -> f (inTx, pad)) >>= fun fix ->
    Cf_cmonad.return (inRx, fix)

let ofix f =
    Iom_gadget.simplex >>= fun (inRx, inTx) ->
    Iom_gadget.createM begin fun pad ->
        let _, notifyTx = pad in
        notifyTx#put `Ready >>= fun () ->
        Cf_cmonad.return (f (inRx, pad))
    end >>= fun fix ->
    Cf_cmonad.return (inTx, fix)

let iofix f =
    Iom_gadget.duplex >>= fun (iofix, iopad) ->
    Iom_gadget.createM begin fun pad ->
        let _, notifyTx = pad in
        notifyTx#put `Ready >>= fun () ->
        Cf_cmonad.return (f (iopad, pad))
    end >>= fun fix ->
    Cf_cmonad.return (iofix, fix)

class virtual ['c, 'n] substate =
    object(self:'self)
        constraint 'self = #Iom_gadget.next
        constraint 'c = [> stop ]
        constraint 'n = [> failed ]
        
        method virtual next: 'a. 'a Iom_gadget.t
        
        method private stop: 'a. 'a Iom_gadget.t = Iom_gadget.abort
        method private fail: 'a. exn -> 'a Iom_gadget.t = fun _ -> self#stop
    end

class virtual ['c, 'n] control pad =
    let controlRx, notifyTx = (pad :> ('c, 'n) Iom_gadget.pad) in
    object(self)
        inherit ['c, 'n] substate as super
        
        method virtual next: 'a. 'a Iom_gadget.t
        
        method! private stop = super#stop
        
        method private fail: 'a. exn -> 'a Iom_gadget.t = fun x ->
            notifyTx#put (`Failed x) >>= fun () ->
            self#stop
        
        method private control = function
            | #stop -> self#stop
            | _ -> self#next
        
        method private guard = controlRx#get self#control
    end

class virtual ['c, 'n] notify fix =
    let notifyRx, _ = (fix :> ('c, 'n) Iom_gadget.fix) in
    object(self)
        inherit ['c, 'n] substate as super
        
        method virtual next: 'a. 'a Iom_gadget.t
        
        method! private fail = super#fail
        
        method private notify = function
            | `Failed x -> self#fail x
            | _ -> self#next
        
        method private guard = notifyRx#get self#notify
    end

class ['c, 'n] engine fix = object
    inherit ['c, 'n] notify fix
    inherit Iom_gadget.start
    inherit Iom_gadget.next
end

class ['c, 'n] driver pad = object
    inherit ['c, 'n] control pad
    inherit Iom_gadget.start
    inherit Iom_gadget.next
end

class ['c, 'n] process fix pad =
    let fix = (fix :> ('c, 'n) Iom_gadget.fix) in
    let pad = (pad :> ('c, 'n) Iom_gadget.pad) in
    let (_, controlTx : ('c, 'n) Iom_gadget.fix) = fix in
    let (_, notifyTx : ('c, 'n) Iom_gadget.pad) = pad in
    object(self)
        inherit ['c, 'n] notify fix as notify
        method virtual private stop: 'a. 'a Iom_gadget.t
        method virtual private fail: 'a. exn -> 'a Iom_gadget.t
        method virtual private guard: unit Iom_gadget.guard
        inherit ['c, 'n] control pad as control
        inherit Iom_gadget.start
        inherit Iom_gadget.next as subnext
        
        method! next = subnext#next
        
        method private fail x =
            controlTx#put `Stop >>= fun () ->
            control#fail x
        
        method private notify n =
            notifyTx#put n >>= fun () ->
            match n with
            | #failed -> self#stop
            | _ -> self#next
        
        method private control c =
            controlTx#put c >>= fun () ->
            control#control c
        
        method private guard =
            control#guard >>= fun () ->
            notify#guard
    end

(*--- $File$ ---*)
