(*---------------------------------------------------------------------------*
  $Change$
  Copyright (c) 2006-2016, James H. Woodyatt
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  
    Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
    
    Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in
    the documentation and/or other materials provided with the
    distribution
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
  COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
  STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
  OF THE POSSIBILITY OF SUCH DAMAGE. 
 *---------------------------------------------------------------------------*)

(*
let jout = Cf_journal.stdout
*)

open Cf_cmonad.Op

type ('ci, 'co, 'ni, 'no) state = [
        | `S_failed of exn
        | `S_established of
            ('ci, 'ni) Iom_gadget.fix * ('co, 'no) Iom_gadget.fix
    ]
    constraint 'ci = [> Iom_stream.flowcontrol ]
    constraint 'co = [> Iom_stream.stop ]
    constraint 'ni = [> Iom_stream.failed ]
    constraint 'no = [> Iom_stream.flownotify ]

class virtual ['i, 'o, 'control, 'notify, 'state, 'af, 'st]
    endpoint ~k ~s iopad =
    let iopad = (iopad : ('i, 'o, 'control, 'notify) Iom_stream.iopad) in
    let (dnRx, upTx), (controlRx, notifyTx) = iopad in
    let _ = (k : Iom_gadget.kernel) in
    object(self:'self)
        inherit Iom_gadget.start
        inherit Iom_gadget.next as subnext
        
        constraint 'control = [> Iom_stream.flowcontrol ]
        constraint 'notify = [> Iom_stream.flownotify ]
        constraint 'state = [> ('ci, 'co, 'ni, 'no) state ]
        
        val state_: 'state =
            `S_failed (Failure "Iom_socket.endpoint: uninitialized state!")
        
        method virtual private state0: 'state Iom_gadget.t
        
        method virtual private receiver:
            ('i, 'ci, 'ni) Iom_stream.ipad -> #Iom_gadget.start
        
        method virtual private sender:
            ('o, 'co, 'no) Iom_stream.opad -> #Iom_gadget.start
        
        method private receiver_aux_ pad = self#receiver (upTx, pad)
        method private sender_aux_ pad = self#sender (dnRx, pad)
        
        method private establish: 'state Iom_gadget.t =
            Iom_gadget.create self#receiver_aux_ >>= fun iJack ->
            Iom_gadget.create self#sender_aux_ >>= fun oJack ->
            let _, iCtrlTx = iJack in
            iCtrlTx#put `Ready >>= fun () ->
            Cf_cmonad.return (`S_established (iJack, oJack))
        
        method private state0 = self#establish
        
        method private close: 'a. 'a Iom_gadget.t =
            Nx_socket.close s;
            Iom_gadget.abort
        
        method private reset: 'a. 'a Iom_gadget.t =
            let fd = Nx_socket.to_unix_file_descr s in
            Unix.shutdown fd Unix.SHUTDOWN_ALL;
            self#close
        
        method private fail: 'a. exn -> 'a Iom_gadget.t = fun x ->
            notifyTx#put (`Failed x) >>= fun () ->
            self#reset
        
        method private inotify event =
            match state_, event with
            | `S_established (_, (_, writerTx)), `Failed x ->
                let writerTx = (writerTx :> 'co Iom_gadget.tx) in
                writerTx#put `Stop >>= fun () ->
                self#fail x
            | _, `Failed x ->
                self#fail x
            | _, _ ->
                self#next
        
        method private onotify event =
            match state_, event with
            | `S_established ((_, readerTx), _), `Failed x ->
                let readerTx = (readerTx :> 'ci Iom_gadget.tx) in
                readerTx#put `Stop >>= fun () ->
                self#fail x
            | _, `Failed x ->
                self#fail x
            | _, _ ->
                self#next
        
        method private control c =
            match state_, c with
            | `S_established ((_, rdTx), (_, wrTx)), `Stop ->
                let rdTx = (rdTx :> 'ci Iom_gadget.tx) in
                let wrTx = (wrTx :> 'co Iom_gadget.tx) in
                rdTx#put `Stop >>= fun () ->
                wrTx#put `Stop >>= fun () ->
                self#reset
            | `S_established ((_, rdTx), _),
              (#Iom_stream.readywait as c) ->
                let rdTx = (rdTx :> 'ci Iom_gadget.tx) in
                rdTx#put c >>= fun () ->
                self#next
            | _ ->
                self#next
        
        method private stateguard =
            match state_ with
            | `S_established ((readerRx, _), (writerRx, _)) ->
                let readerRx = (readerRx :> 'ni Iom_gadget.rx) in
                let writerRx = (writerRx :> 'no Iom_gadget.rx) in
                readerRx#get self#inotify >>= fun () ->
                writerRx#get self#onotify
            | _ ->
                Cf_cmonad.nil
        
        method private guard =
            controlRx#get self#control >>= fun () ->
            self#stateguard
        
        method start: unit Iom_gadget.t =
            self#state0 >>= function
            | `S_failed x ->
                self#fail x
            | state0 ->
                let obj = ({< state_ = state0 >} :> Iom_gadget.next) in
                Iom_gadget.start obj#next
        
        method next = subnext#next
    end

module type T = sig
    module P: Nx_socket.P
    type t = (P.AF.tag, P.ST.tag) Nx_socket.t
    type address = P.AF.address
    val unspecified_address: address
    val create: unit -> t
    val createpair: unit -> t * t
end

module Create(P: Nx_socket.P) = struct
    module P = P
    type t = (P.AF.tag, P.ST.tag) Nx_socket.t
    type address = P.AF.address
    let unspecified_address = P.AF.of_sockaddr P.AF.unspecified
    
    let create () = 
        (Nx_socket.create P.AF.domain P.ST.socktype P.protocol : t)
    
    let createpair () = 
        (Nx_socket.createpair P.AF.domain P.ST.socktype P.protocol : t * t)
end

(*--- $File$ ---*)
