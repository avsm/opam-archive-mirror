(*---------------------------------------------------------------------------*
  $Change$
  Copyright (c) 2006-2016, James H. Woodyatt
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  
    Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
    
    Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in
    the documentation and/or other materials provided with the
    distribution
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
  COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
  STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
  OF THE POSSIBILITY OF SUCH DAMAGE. 
 *---------------------------------------------------------------------------*)

(*
let jout = Cf_journal.stdout
*)

open Cf_cmonad.Op

class virtual ['x, 'y] transform consumeRx produceTx =
    let consumeRx = (consumeRx :> 'x Iom_gadget.rx) in
    let produceTx = (produceTx :> 'y Iom_gadget.tx) in
    object(self:'self)
        val consume_ = false
        val produce_ = false
        
        method virtual push: 'x -> 'self Iom_gadget.t
        method virtual shift: ('y list * 'self option) Cf_exnopt.t Iom_gadget.t
        
        method consume f =
            match consume_ with
            | false ->
                Cf_cmonad.nil
            | true ->
                consumeRx#get begin fun event ->
                    try
                        self#push event >>= fun obj ->
                        f (Cf_exnopt.U obj)
                    with
                    | x ->
                        f (Cf_exnopt.X x)
                end
        
        method produce =
            match produce_ with
            | false ->
                Cf_cmonad.return (Cf_exnopt.U (Some self))
            | true ->
                self#shift >>= function
                | Cf_exnopt.X x ->
                    Cf_cmonad.return (Cf_exnopt.X x)
                | Cf_exnopt.U (s, obj) ->
                    let z = Cf_seq.map produceTx#put (Cf_seq.of_list s) in
                    Cf_seq.C.sequence z >>= fun () ->
                    Cf_cmonad.return (Cf_exnopt.U obj)
        
        method unblock: 'self Iom_gadget.t =
            Cf_cmonad.return {< produce_ = true >}
        method block: 'self Iom_gadget.t =
            Cf_cmonad.return {< produce_ = false >}
                
        method wait: 'self Iom_gadget.t =
            Cf_cmonad.return {< consume_ = false >}
        method ready: 'self Iom_gadget.t =
            Cf_cmonad.return {< consume_ = true >}
    end

class ['xy, 'c, 'n] simplex transform jack plug =
    object(self:'self)
        inherit ['c, 'n] Iom_stream.process jack plug as super
        constraint 'xy = ('x, 'y) #transform
        
        val transform_: 'xy = transform
        
        method! private stop = super#stop
        method! private fail x = super#fail x
        
        method private loop: 'xy -> unit Iom_gadget.t = fun obj ->
            let s = ({< transform_ = obj >} :> Iom_gadget.next) in
            s#next
        
        method private drain: 'xy -> unit Iom_gadget.t = fun obj ->
            obj#produce >>= function
            | Cf_exnopt.X x -> self#fail x
            | Cf_exnopt.U None -> self#stop
            | Cf_exnopt.U (Some obj) -> self#loop obj
        
        method private unblock = transform_#unblock >>= self#drain
        method private block = transform_#block >>= self#loop
        method private wait = transform_#wait >>= self#loop
        method private ready = transform_#ready >>= self#loop
        
        method private push = function
            | Cf_exnopt.X x -> self#fail x
            | Cf_exnopt.U obj -> self#drain obj
        
        method private guard =
            super#guard >>= fun () ->
            transform_#consume self#push
    end

class ['xy, 'c, 'n] isimplex xy jack plug = object(self)
    inherit ['xy, 'c, 'n] simplex xy jack plug as super
    
    method private control = function
        | #Iom_stream.ready -> self#unblock
        | #Iom_stream.wait -> self#block
        | c -> super#control c
end

class ['xy, 'c, 'n] osimplex xy jack plug = object(self)
    inherit ['xy, 'c, 'n] simplex xy jack plug as super
    
    method private notify = function
        | #Iom_stream.ready -> self#unblock
        | #Iom_stream.wait -> self#block
        | n -> super#notify n
end

class ['i, 'o, 'c, 'n] duplex itransform otransform jack plug =
    object(self:'self)
        inherit ['c, 'n] Iom_stream.process jack plug as super
        constraint 'i = ('ix, 'iy) #transform
        constraint 'o = ('oy, 'ox) #transform
        
        val itransform_: 'i option = Some itransform
        val otransform_: 'o option = Some otransform
        
        method! private stop = super#stop
        method! private fail x = super#fail x
        
        method private iloop: 'i option -> unit Iom_gadget.t = fun objOpt ->
            match otransform_, objOpt with
            | None, None ->
                self#stop
            | _, _ ->
                let s = ({< itransform_ = objOpt >} :> Iom_gadget.next) in
                s#next
        
        method private idrain: 'i -> unit Iom_gadget.t = fun obj ->
            obj#produce >>= function
            | Cf_exnopt.X x -> self#fail x
            | Cf_exnopt.U objOpt -> self#iloop objOpt
        
        method private oloop: 'o option -> unit Iom_gadget.t = fun objOpt ->
            match itransform_, objOpt with
            | None, None ->
                self#stop
            | _, _ ->
                let s = ({< otransform_ = objOpt >} :> Iom_gadget.next) in
                s#next
        
        method private odrain: 'o -> unit Iom_gadget.t = fun obj ->
            obj#produce >>= function
            | Cf_exnopt.X x -> self#fail x
            | Cf_exnopt.U objOpt -> self#oloop objOpt
        
        method private isignal f =
            match itransform_ with
            | Some obj -> f obj >>= self#idrain
            | None -> assert (not true); self#iloop None
        
        method private iunblock = self#isignal (fun obj -> obj#unblock)
        method private iblock = self#isignal (fun obj -> obj#block)
        method private iwait = self#isignal (fun obj -> obj#wait)
        method private iready = self#isignal (fun obj -> obj#ready)
        
        method private osignal f =
            match otransform_ with
            | Some obj -> f obj >>= self#odrain
            | None -> assert (not true); self#oloop None
                
        method private ounblock = self#osignal (fun obj -> obj#unblock)
        method private oblock = self#osignal (fun obj -> obj#block)
        method private owait = self#osignal (fun obj -> obj#wait)
        method private oready = self#osignal (fun obj -> obj#ready)
        
        method private ipush = function
            | Cf_exnopt.U obj -> self#idrain obj
            | Cf_exnopt.X x -> self#fail x
        
        method private opush = function
            | Cf_exnopt.U obj -> self#odrain obj
            | Cf_exnopt.X x -> self#fail x
        
        method private iguard =
            match itransform_ with
            | None -> Cf_cmonad.return ()
            | Some obj -> obj#consume self#ipush
        
        method private oguard =
            match otransform_ with
            | None -> Cf_cmonad.return ()
            | Some obj -> obj#consume self#opush
        
        method private guard =
            super#guard >>= fun () ->
            self#iguard >>= fun () ->
            self#oguard
        
        method private control = function
            | #Iom_stream.ready -> self#ounblock
            | #Iom_stream.wait -> self#oblock
            | c -> super#control c
        
        method private notify = function
            | #Iom_stream.ready -> self#iunblock
            | #Iom_stream.wait -> self#iblock
            | n -> super#notify n
    end

let ingest xJack cons =
    Iom_gadget.duplex >>= fun (yJack, yPlug) ->
    Iom_gadget.simplex >>= fun (yRx, yTx) ->
    let xRx, (_, xCtrl as xJack) = xJack in
    let xy = (cons xCtrl xRx yTx :> ('x, 'y) transform) in
    xy#ready >>= fun xy ->
    let m = new isimplex xy xJack yPlug in
    m#start >>= fun () ->
    xCtrl#put `Ready >>= fun () ->
    Cf_cmonad.return (yRx, yJack)

let render xJack cons =
    Iom_gadget.duplex >>= fun (yJack, yPlug) ->
    Iom_gadget.simplex >>= fun (yRx, yTx) ->
    let xTx, xJack = xJack in
    let _, yNtfy = yPlug in
    let xy = (cons yNtfy yRx xTx :> ('x, 'y) transform) in
    xy#ready >>= fun xy ->
    let m = new osimplex xy xJack yPlug in
    m#start >>= fun () ->
    yNtfy#put `Ready >>= fun () ->
    Cf_cmonad.return (yTx, yJack)

let duplex xJack iCons oCons =
    Iom_gadget.duplex >>= fun (yJack, yPlug) ->
    Iom_gadget.duplex >>= fun ((yoRx, yiTx), (yiRx, yoTx)) ->
    let (xiRx, xoTx), (_, xCtrl as xJack) = xJack in
    let _, yNtfy = yPlug in
    let ixy = (iCons xCtrl xiRx yiTx :> ('xi, 'yi) transform) in
    let oxy = (oCons yNtfy yoRx xoTx :> ('yo, 'xo) transform) in
    ixy#ready >>= fun ixy ->
    oxy#ready >>= fun oxy ->
    let m = new duplex ixy oxy xJack yPlug in
    m#start >>= fun () ->
    xCtrl#put `Ready >>= fun () ->
    yNtfy#put `Ready >>= fun () ->
    Cf_cmonad.return ((yiRx, yoTx), yJack)

(*--- $File$ ---*)
