open Mpp_charstream

let f = charstream_of_inchannel "stdin" stdin

let _ =
  try
    while true do
      match f.take() with
        | Some c -> output_char stdout c
        | None -> flush stdout; raise End_of_file
    done
  with End_of_file -> ()

