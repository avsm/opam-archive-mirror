type location = { sl : int; sc : int; el : int; ec : int }

type t = { loc : location; token : token }
and token =
  | Space of string
  | Int of string
  | Float of string
  | Upper of string
  | Lower of string
  | String of string
  | Char of string
  | Infix of string
  | Prefix of string
  | Operator of string
  | Comment of string
  | And
  | As
  | Begin
  | Class
  | Constraint
  | Do
  | Done
  | Downto
  | Else
  | End
  | Exception
  | External
  | False
  | For
  | Fun
  | Function
  | Functor
  | If
  | In
  | Include
  | Inherit
  | Initializer
  | Lazy
  | Let
  | Match
  | Method
  | Mod
  | Module
  | Mutable
  | New
  | Object
  | Of
  | Open
  | Private
  | Rec
  | Sig
  | Struct
  | Then
  | To
  | True
  | Try
  | Type
  | Val
  | Virtual
  | When
  | While
  | With
  | Abstract
  | EpEq
  | Sharp
  | Amp
  | AmpAmp
  | Quote
  | OpenP
  | CloseP
  | Star
  | Plus
  | Comma
  | Hyphen
  | HyphenDot
  | HyphenGt
  | Dot
  | DotDot
  | Colon
  | ColonColon
  | ColonEq
  | ColonGt
  | SemiColon
  | SemiColonSemiColon
  | Lt
  | LtHyphen
  | Eq
  | Gt
  | GtCloseSB
  | GtCloseCB
  | Im
  | ImIm
  | OpenSB
  | OpenSBLt
  | OpenSBGt
  | OpenSBVertLine
  | CloseSB
  | Underscore
  | BackQuote
  | OpenCB
  | OpenCBLt
  | VertLine
  | VertLineCloseSB
  | CloseCB
  | Tild
  | Lor
  | Lsl
  | Lsr
  | Asr
  | Or
  | Lxor
  | Land
  | Xor
  | Eof
  | VertLineVertLine


let keyops =
  ["!=", EpEq; "#", Sharp; "&", Amp; "&&", AmpAmp; "'", Quote; "(", OpenP;
   ")", CloseP; "*", Star; "+", Plus; ",", Comma; "-", Hyphen;
   "-.", HyphenDot; "->", HyphenGt; ".", Dot; "..", DotDot; ":", Colon;
   "::", ColonColon; ":=", ColonEq; ":>", ColonGt; ";", SemiColon;
   ";;", SemiColonSemiColon; "<", Lt; "<-", LtHyphen; "=", Eq; ">", Gt;
   ">]", GtCloseSB; ">}", GtCloseCB; "?", Im; "??", ImIm; "[", OpenSB;
   "[<", OpenSBLt; "[>", OpenSBGt; "[|", OpenSBVertLine; "]", CloseSB;
   "_", Underscore; "`", BackQuote; "{<", OpenCBLt; "|]", VertLineCloseSB;
   "||", VertLineVertLine; "|", VertLine; "{", OpenCB; "}", CloseCB;
   "~", Tild; "land", Land; "lor", Lor; "lsl", Lsl; "lsr", Lsr; "lxor", Lxor;
   "asr", Asr; "or", Or; "xor", Xor; "mod", Mod]

let keywords =
  ["and", And; "as", As; "lazy", Lazy; "EOF", Eof; "begin", Begin;
   "class", Class; "constraint", Constraint; "do", Do; "done", Done;
   "downto", Downto; "else", Else; "end", End; "exception", Exception;
   "external", External; "false", False; "for", For; "fun", Fun;
   "function", Function; "functor", Functor; "if", If; "in", In;
   "include", Include; "inherit", Inherit; "initializer", Initializer;
   "let", Let; "match", Match; "method", Method; "module", Module;
   "mutable", Mutable; "new", New; "object", Object; "of", Of; "open", Open;
   "private", Private; "abstract", Abstract; "rec", Rec; "sig", Sig;
   "struct", Struct; "then", Then; "to", To; "true", True; "try", Try;
   "type", Type; "val", Val; "virtual", Virtual; "when", When; "while", While;
   "with", With]



let rec list_assoc_inv e = function
  | (a,b)::tail -> if b = e then a else list_assoc_inv e tail
  | [] -> raise Not_found


let keyops_keywords = keyops @ keywords 


let token_to_any anyfunc = function
    Int of_string -> anyfunc of_string
  | Float of_string -> anyfunc of_string
  | Upper of_string -> anyfunc of_string
  | Lower of_string -> anyfunc of_string
  | String of_string -> anyfunc of_string
  | Char of_string -> anyfunc of_string
  | Infix of_string -> anyfunc of_string
  | Prefix of_string -> anyfunc of_string
  | Operator of_string -> anyfunc of_string
  | Comment of_string -> anyfunc of_string
  | And 
  | As 
  | Begin 
  | Class 
  | Constraint 
  | Do 
  | Done 
  | Downto 
  | Else 
  | End 
  | Exception 
  | External 
  | False 
  | For 
  | Fun 
  | Function 
  | Functor 
  | If 
  | In 
  | Include 
  | Inherit 
  | Initializer 
  | Lazy 
  | Let 
  | Match 
  | Method 
  | Mod 
  | Module 
  | Mutable 
  | New 
  | Object 
  | Of 
  | Open 
  | Private 
  | Rec 
  | Sig 
  | Struct 
  | Then 
  | To 
  | True 
  | Try 
  | Type 
  | Val 
  | Virtual 
  | When 
  | While 
  | With 
  | Abstract 
  | EpEq 
  | Sharp 
  | Amp 
  | AmpAmp 
  | Quote 
  | OpenP 
  | CloseP 
  | Star 
  | Plus 
  | Comma 
  | Hyphen 
  | HyphenDot 
  | HyphenGt 
  | Dot 
  | DotDot 
  | Colon 
  | ColonColon 
  | ColonEq 
  | ColonGt 
  | SemiColon 
  | SemiColonSemiColon 
  | Lt 
  | LtHyphen 
  | Eq 
  | Gt 
  | GtCloseSB 
  | GtCloseCB 
  | Im 
  | ImIm 
  | OpenSB 
  | OpenSBLt 
  | OpenSBGt 
  | OpenSBVertLine 
  | CloseSB 
  | Underscore 
  | BackQuote 
  | OpenCB 
  | OpenCBLt 
  | VertLine 
  | VertLineCloseSB 
  | CloseCB 
  | Tild 
  | Lor 
  | Lsl 
  | Lsr 
  | Asr 
  | Or 
  | Lxor 
  | Land 
  | Xor 
  | Eof 
  | VertLineVertLine as c ->
      list_assoc_inv c keyops_keywords


type 'a buffer =
  { mutable buffer : char list;
    stream : 'a;
    mutable line : int;
    mutable column : int;
    pop : unit -> char;
    push : char -> unit;
    mutable widths : int list }

exception Lexical_error of location

type position = { name : string; mutable lin : int; mutable col : int }


type string2 = {
          string_val : string;
  mutable string_pos : int;
}

type string2_lexbuf =
  { mutable lex_start_p : position;
    mutable lex_curr_p : position;
    lex_buf : string2 buffer }


let error loc m =
  ignore
    begin
      Printf.sprintf "Characters %d:%d - %d:%d :\nError: %s\n"
        loc.sl loc.sc loc.el loc.ec m
    end


let create_buffer_from_string source =
  let input_char ({string_val=s; string_pos=i} as v) =
    v.string_pos <- succ i;
    try s.[i] with _ -> raise End_of_file
  in
  let rec x =
    {buffer = []; stream = {string_val=source; string_pos=0}; widths = []; line = 1; column = 0;
     pop =
       (fun () ->
          match x.buffer with
            [] ->
              begin match input_char x.stream with
                '\n' as c ->
                  x.widths <- x.column :: x.widths;
                  x.line <- x.line + 1;
                  x.column <- 0;
                  c
              | c -> x.column <- x.column + 1; c
              end
          | c :: tl ->
              match c with
                '\n' ->
                  x.widths <- x.column :: x.widths;
                  x.line <- x.line + 1;
                  x.column <- 0;
                  x.buffer <- tl;
                  c
              | _ -> x.column <- x.column + 1; x.buffer <- tl; c);
     push =
       fun c ->
         begin match c with
           '\n' ->
             x.column <- List.hd x.widths;
             x.widths <- List.tl x.widths;
             x.line <- x.line - 1
         | _ -> x.column <- x.column - 1
         end;
         match x.buffer with
           [] -> x.buffer <- [c]
         | l -> x.buffer <- c :: l}
  in
  x



let read_number stream =
  let loc =
    {sl = stream.line; sc = stream.column; el = stream.line;
     ec = stream.column}
  in
  let string_of_char c = let s = " " in s.[0] <- c; s in
  let float = ref false in
  let int = ref false in
  let dot = ref false in
  let rec f res =
    try
      match stream.pop () with
        '0' ->
          begin match stream.pop () with
            'O' | 'o' | 'x' | 'X' | 'b' | 'B' as c ->
              if res <> "" or !float or !int then
                begin
                  error {loc with el = stream.line; ec = stream.column}
                    "Lexical error: you gave a weird number"
                end
              else int := true;
              f ("0" ^ string_of_char c)
          | '0'..'9' as c -> f (res ^ "0" ^ string_of_char c)
          | c -> stream.push c; f (res ^ "0")
          end
      | '1'..'9' as c -> f (res ^ string_of_char c)
      | 'E' | 'e' as e ->
          if res = "" or !float or !int then begin stream.push e; res end
          else
            begin
              float := true;
              match stream.pop () with
                '0'..'9' as c -> f (res ^ "e" ^ string_of_char c)
              | c -> stream.push c; stream.push e; res
            end
      | '.' as c ->
          if res = "" or !float or !int then
            error {loc with el = stream.line; ec = stream.column}
              "Lexical error: you gave a weird number"
          else dot := true;
          f (res ^ string_of_char c)
      | '_' -> f res
      | c -> stream.push c; res
    with
      End_of_file -> res
  in
  let r = f "" in
  let n =
    if !float or !dot then
      Float
        (try ignore(float_of_string r); r with
           _ ->
             error loc "Lexical error while trying to read a float";
             r)
    else
      Int
        (try ignore(int_of_string r); r with
            _ ->
              error loc
                (Printf.sprintf "2(%d:%d) <%s>\n%s" stream.line stream.column r
                    "Lexical error while trying to read an integer");
              r)
  in
  {token = n; loc = {loc with el = stream.line; ec = stream.column}}


let read_upper stream =
  let loc =
    {sl = stream.line; sc = stream.column; el = stream.line;
     ec = stream.column}
  in
  let string_of_char c = let s = " " in s.[0] <- c; s in
  let rec f res =
    try
      match stream.pop () with
        'A'..'Z' as c -> f (res ^ string_of_char c)
      | 'a'..'z' | '0'..'9' | '_' as c ->
          if res = "" then failwith "bad use of lexer (read_upper)";
          f (res ^ string_of_char c)
      | c -> stream.push c; res
    with
      End_of_file -> res
  in
  let res = f "" in
  {token = Upper res; loc = {loc with el = stream.line; ec = stream.column}}

let read_lower stream =
  let loc =
    {sl = stream.line; sc = stream.column; el = stream.line;
     ec = stream.column}
  in
  let string_of_char c = let s = " " in s.[0] <- c; s in
  let rec f res =
    try
      match stream.pop () with
        'a'..'z' | '_' as c -> f (res ^ string_of_char c)
      | 'A'..'Z' | '0'..'9' as c ->
          if res = "" then failwith "bad use of lexer (read_lower)";
          f (res ^ string_of_char c)
      | c -> stream.push c; res
    with
      End_of_file -> res
  in
  let res = f "" in
  try
    {token = List.assoc res keywords;
     loc = {loc with el = stream.line; ec = stream.column}}
  with
    Not_found ->
      try
        {token = List.assoc res keyops;
         loc = {loc with el = stream.line; ec = stream.column}}
      with
        Not_found ->
          {token = Lower res;
           loc = {loc with el = stream.line; ec = stream.column}}

let read_infix stream =
  let loc =
    {sl = stream.line; sc = stream.column; el = stream.line;
     ec = stream.column}
  in
  let string_of_char c = let s = " " in s.[0] <- c; s in
  let rec f res =
    try
      match stream.pop () with
        '!' | '?' | '~' as c ->
          if res = "" then failwith "bad use of lexer (read_infix)";
          f (res ^ string_of_char c)
      | '$' | '%' | '&' | '*' | '+' | '-' | '.' | '/' | ':' | '<' | '=' |
        '>' | '@' | '^' | '|' as c ->
          f (res ^ string_of_char c)
      | ']' | '}' as c ->
          if List.mem_assoc (res ^ string_of_char c) keyops then
            f_spe (res ^ string_of_char c)
          else begin stream.push c; res end
      | c -> stream.push c; res
    with
      End_of_file -> res
  and f_spe res =
    try
      match stream.pop () with
        '!' | '&' | '*' | '+' | '-' | '.' | ':' | '<' | '=' | '>' | '?' |
        '~' | '`' | '(' | ')' | '#' | '[' | ']' | '{' | '|' | '}' as c ->
          if res = "" || List.mem_assoc (res ^ string_of_char c) keyops then
            f (res ^ string_of_char c)
          else begin stream.push c; res end
      | c -> stream.push c; res
    with
      End_of_file -> res
  in
  let res = f "" in
  try
    {token = List.assoc res keyops;
     loc = {loc with el = stream.line; ec = stream.column}}
  with
    Not_found ->
      {token = Infix res;
       loc = {loc with el = stream.line; ec = stream.column}}

let read_prefix stream =
  let loc =
    {sl = stream.line; sc = stream.column; el = stream.line;
     ec = stream.column}
  in
  let string_of_char c = let s = " " in s.[0] <- c; s in
  let rec f res =
    try
      match stream.pop () with
        '!' | '?' | '~' as c ->
          if res <> "" then failwith "bad use of lexer (read_prefix)";
          f (res ^ string_of_char c)
      | '$' | '%' | '&' | '*' | '+' | '-' | '.' | '/' | ':' | '<' | '=' |
        '>' | '@' | '^' | '|' as c ->
          f (res ^ string_of_char c)
      | c -> stream.push c; res
    with
      End_of_file -> res
  in
  let res = f "" in
  try
    {token = List.assoc res keyops;
     loc = {loc with el = stream.line; ec = stream.column}}
  with
    Not_found ->
      {token = Prefix res;
       loc = {loc with el = stream.line; ec = stream.column}}


let read_char stream = 
  let loc =
    {sl = stream.line; sc = stream.column; el = stream.line;
     ec = stream.column}
  in
  let res =
  match stream.pop () with
    | '\'' ->
        begin match stream.pop () with
          | '\\' -> 
              begin match stream.pop () with
                | 'n' | 'r' | 'b' | 't' as c -> 
                    begin match stream.pop () with
                      | '\'' -> "'\\" ^ String.make 1 c ^ "'"
                      | c2 ->
                          error {loc with el = stream.line; ec = stream.column}
                            "Lexical error: Illegal backslash escape in character";
                          "'\\" ^ String.make 1 c ^ String.make 1 c2
                    end
                | '#' | '0' .. '2' as c ->
                    let c1 = stream.pop () in
                    let c2 = stream.pop () in
                      begin match stream.pop () with
                        | '\'' -> "'\\" ^ String.make 1 c ^ String.make 1 c1 ^ String.make 1 c2 ^ "'"
                        | c3 ->
                            error {loc with el = stream.line; ec = stream.column}
                              "Lexical error: Illegal backslash escape in character";
                            "'\\" ^ String.make 1 c
                            ^ String.make 1 c1 ^ String.make 1 c2  
                            ^ String.make 1 c3
                      end
                | '\'' -> ("'\\'" ^ String.make 1 (stream.pop ()))
                | '\\' -> ("'\\\\" ^ String.make 1 (stream.pop ()))
                | c ->
                    begin
                      error {loc with el = stream.line; ec = stream.column}
                        "Lexical error: Illegal backslash escape in character";
                      match stream.pop () with
                        | '\'' -> "'\\" ^ String.make 1 c ^ "'"
                        | x -> "'\\" ^ String.make 1 c ^ String.make 1 x
                    end
              end
          | c -> "'" ^ String.make 1 c ^ String.make 1 (stream.pop())
        end
    | _ -> assert false
  in
    {token = Char res;
     loc = {loc with el = stream.line; ec = stream.column}}

let read_string stream = 
  let loc =
    {sl = stream.line; sc = stream.column; el = stream.line;
     ec = stream.column}
  in
  let res =
  match stream.pop () with
    | '\"' ->
        let rec eat s =
          begin match stream.pop () with

            (* end of string *)
            | '\"' -> s ^ "\""

            (* backslashed item *)
            | '\\' ->
                begin match stream.pop () with
                  | 'n' | 'r' | 'b' | 't' as c -> 
                      eat (s ^ "\\" ^ String.make 1 c)
                  | '#' | '0' .. '2' as c ->
                    let c1 = stream.pop () in
                    let c2 = stream.pop () in
                      eat (s ^ "'\\" ^ String.make 1 c ^ String.make 1 c1 ^ String.make 1 c2 ^ "'")
                  | '\"' | '\'' | '\\' | '\n' | '\r' as c ->
                      eat (s ^ "\\" ^ String.make 1 c)
                  | c ->                      
                        error {loc with el = stream.line; ec = stream.column}
                          "Lexical error: Illegal backslash escape in string";
                        eat (s ^ String.make 1 c)
                end
            | c -> eat (s ^ String.make 1 c)
          end
        in eat "\""
    | _ -> assert false
  in {token = String res;
       loc = {loc with el = stream.line; ec = stream.column}}


let read_comment stream =
  let loc =
    {sl = stream.line; sc = stream.column; el = stream.line;
     ec = stream.column}
  in
  let string_of_char c = let s = " " in s.[0] <- c; s in
  let rec f res level =
    match stream.pop () with
      '(' ->
        begin match stream.pop () with
          '*' -> f (res ^ "(*") (level + 1)
        | c -> f (res ^ "(" ^ string_of_char c) level
        end
    | '*' ->
        begin match stream.pop () with
          ')' -> if level = 1 then res ^ "*)" else f (res ^ "*)") (level - 1)
        | '*' -> stream.push '*'; f (res ^ "*") level
        | c -> f (res ^ "*" ^ string_of_char c) level
        end
    | c -> f (res ^ string_of_char c) level
  in
  {token = Comment (f "" 0);
   loc = {loc with el = stream.line; ec = stream.column}}

let read_op stream =
  let loc =
    {sl = stream.line; sc = stream.column; el = stream.line;
     ec = stream.column}
  in
  let string_of_char c = let s = " " in s.[0] <- c; s in
  let rec f res =
    try
      match stream.pop () with
        '!' | '&' | '*' | '+' | '-' | '.' | ':' | '<' | '=' | '>' | '?' | '~'
          as c ->
          f (res ^ string_of_char c)
      | '[' | ']' | '{' | '|' | '}' as c ->
          if res = "" || List.mem_assoc (res ^ string_of_char c) keyops then
            f_spe (res ^ string_of_char c)
          else begin stream.push c; res end
      | '`' | '(' | ')' | '#' as c ->
          if res = "" then string_of_char c else begin stream.push c; res end
      | ',' -> if res = "" then "," else begin stream.push ','; res end
      | ';' ->
          if res = "" then
            match stream.pop () with
              ';' -> ";;"
            | c -> stream.push c; ";"
          else begin stream.push ';'; res end
      | c -> stream.push c; res
    with
      End_of_file -> res
  and f_spe res =
    try
      match stream.pop () with
        '!' | '&' | '*' | '+' | '-' | '.' | ':' | '<' | '=' | '>' | '?' |
        '~' | '`' | '(' | ')' | '#' | '[' | ']' | '{' | '|' | '}' as c ->
          if res = "" || List.mem_assoc (res ^ string_of_char c) keyops then
            f (res ^ string_of_char c)
          else begin stream.push c; res end
      | c -> stream.push c; res
    with
      End_of_file -> res
  in
  let res = f "" in
  try
    {token = List.assoc res keyops;
     loc = {loc with el = stream.line; ec = stream.column}}
  with
    Not_found ->
      {token = Operator res;
       loc = {loc with el = stream.line; ec = stream.column}}

let read stream =
  let rec f res =
    try
      match stream.pop () with
        '0'..'9' as c -> stream.push c; f (read_number stream :: res)
      | 'A'..'Z' as c -> stream.push c; f (read_upper stream :: res)
      | 'a'..'z' | '_' as c -> stream.push c; f (read_lower stream :: res)
      | ' ' | '\t' | '\n' | '\r' -> f res
      | '!' | '?' | '~' as c -> stream.push c; f (read_prefix stream :: res)
      | '=' | '<' | '>' | '@' | '^' | '|' | '&' | '+' | '-' | '*' | '/' |
        '$' | '%' as c ->
          stream.push c; f (read_infix stream :: res)
      | '(' ->
          begin match stream.pop () with
            '*' ->
              stream.push '*'; stream.push '('; f (read_comment stream :: res)
          | c -> stream.push c; stream.push '('; f (read_op stream :: res)
          end
      | '\'' as c -> stream.push c; f (read_char stream :: res)
      | '\"' as c -> stream.push c; f (read_string stream :: res)
      | '\\' ->
          error
            {sl = stream.line; sc = stream.column - 1; el = stream.line;
             ec = stream.column}
            "Lexical error: unexpected presence of a backslash";
          res
      | c -> stream.push c; f (read_op stream :: res)
    with
      End_of_file -> res
  in
  List.rev (f [])


let read_one stream =
  let rec f res =
    match res with
      [e] -> e
    | _ :: _ -> failwith "error : file lexer.ml, function read_one"
    | [] ->
        try
          match stream.pop () with
            '0'..'9' as c -> stream.push c; f (read_number stream :: res)
          | 'A'..'Z' as c -> stream.push c; f (read_upper stream :: res)
          | 'a'..'z' | '_' as c -> stream.push c; f (read_lower stream :: res)
          | ' ' | '\t' | '\n' | '\r' as c ->
              begin
  let loc =
    {sl = stream.line; sc = stream.column; el = stream.line;
     ec = stream.column}
  in
 f ({token = Space (String.make 1 c);loc = {loc with el = stream.line; ec = stream.column}} :: res)
              end
          | '!' | '?' | '~' as c ->
              stream.push c; f (read_prefix stream :: res)
          | '=' | '<' | '>' | '@' | '^' | '|' | '&' | '+' | '-' | '*' | '/' |
            '$' | '%' as c ->
              stream.push c; f (read_infix stream :: res)
          | '(' ->
              begin match stream.pop () with
                '*' ->
                  stream.push '*';
                  stream.push '(';
                  f (read_comment stream :: res)
              | c -> stream.push c; stream.push '('; f (read_op stream :: res)
              end
          | '\'' as c -> stream.push c; f (read_char stream :: res)
          | '\"' as c -> stream.push c; f (read_string stream :: res)
          | '\\' ->
              error
                {sl = stream.line; sc = stream.column - 1; el = stream.line;
                 ec = stream.column}
                "Lexical error: unexpected presence of a backslash";
              {token = Eof;
             loc =
               {el = stream.line; ec = stream.column; sl = stream.line;
                sc = stream.column}}
          | c -> stream.push c; f (read_op stream :: res)
        with
          End_of_file ->
            {token = Eof;
             loc =
               {el = stream.line; ec = stream.column; sl = stream.line;
                sc = stream.column}}
  in
  f []


let from_string : string -> string2_lexbuf =
  fun input ->
    {lex_start_p = {name = "dummy"; lin = 0; col = 0};
     lex_curr_p = {name = "dummy"; lin = 0; col = 0};
     lex_buf = create_buffer_from_string input}

let _ =
  List.map
    (fun {token = e} -> token_to_any (fun x -> x) e)
    (read ((from_string "let x = x").lex_buf))

