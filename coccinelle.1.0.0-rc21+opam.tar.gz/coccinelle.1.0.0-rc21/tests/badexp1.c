int main() {
  foo(a);
  a(y);
}
