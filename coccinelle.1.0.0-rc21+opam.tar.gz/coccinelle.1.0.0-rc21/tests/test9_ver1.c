void main(int foo) {

  f(1);
  f(1); // if uncoment then problems
  g(2);
  if(1) {
    h(3);
  } else {
    h(4);
  }

  // if uncomment then problems
  {
    i++;
  }
  
}

