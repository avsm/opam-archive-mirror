int main () {
  int a, b, c, d;
  int a, b, c, *d;
  int a, b, *c, d;
  int a, *b, c, d;
  int *a, b, c, d;
  int a, b, *c, *d;
  int a, *b, *c, d;
  int *a, *b, c, d;
  int *a, b, c, *d;
  int a, *b, c, *d;
  int *a, b, *c, d;
  int a, *b, c, *d;
  int *a, b, *c, d;
  int a, *b, *c, *d;
  int *a, *b, *c, d;
  int *a, *b, c, *d;
  int *a, b, *c, *d;
  int *a, b, c, *d;
  int *a, b, *c, *d;
  int a, *b, *c, *d;
  int *a, *b, c, *d;
}
