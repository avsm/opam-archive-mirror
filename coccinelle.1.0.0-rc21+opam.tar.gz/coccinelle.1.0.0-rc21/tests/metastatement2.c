void main(int i) {

  f();
  { replace(); replace(); }
  g();
}
