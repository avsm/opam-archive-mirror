int func() {
  int c;
  Packet p1,p2;
  int y;
  a = 3;
  return x+y;
}
