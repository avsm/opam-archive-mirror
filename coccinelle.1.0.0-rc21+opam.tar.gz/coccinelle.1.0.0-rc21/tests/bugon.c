static void b44_tx(struct b44 *bp)
{
		if (unlikely(skb == NULL))
			BUG();
}
