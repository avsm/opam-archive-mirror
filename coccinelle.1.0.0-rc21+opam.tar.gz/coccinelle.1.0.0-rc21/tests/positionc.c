int main () {
  if (foo(6,7)) x = ret; else x = ret;
  if (foo(6,7)) x = ret; else x = ret;
  if (foo(7,7)) x = ret; else x = ret;
  if (bar(6,7)) x = ret; else x = ret;
  if (bar(6,7)) x = ret; else x = ret;
  if (bar(7,7)) x = ret; else x = ret;
}

