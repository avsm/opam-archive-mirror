#define INT16 int
//typedef int INT16;

void main(void)
{
     INT16 a, b, c;
     c = a + b;
}

