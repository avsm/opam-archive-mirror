void main(int i) {

  g();
  if(1) 
    f(1,2);
  else 
    f(3,4);

  // return 1;
}
