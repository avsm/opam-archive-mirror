#include <linux/foo.h>
#include <asm/semaphore.h>
#include <linux/foo2.h>
#ifdef FOO
#include <linux/bar.h>
#endif FOO
