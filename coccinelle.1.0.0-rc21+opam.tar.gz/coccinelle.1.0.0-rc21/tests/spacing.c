typedef int *foo;

int f(int x) {
  one();
  if (x) {
    two();
  }
}
