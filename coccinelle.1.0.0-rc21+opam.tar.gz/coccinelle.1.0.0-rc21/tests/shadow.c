struct foo bar;

struct foo bar = { .a = 12 };

