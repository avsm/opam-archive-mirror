typedef union {
int foo;
} t_foo;
typedef struct {
int foo;
} t_foo;
