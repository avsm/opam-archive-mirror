void f(void)
{
switch (2)
   {
     int x;
     int y;
   case 2: i++;
           break;

   case 4: j++;
           break;

   }
}
