int foo() {
  struct foo x;
  return 0;
}

