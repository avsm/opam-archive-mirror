void main(int i) {
  
  if (!hostptr) {
    if (hostptr) {
      return -ESRCH;
    }
  }

}
