int main(int x) {
  for(x=1;x>1;x++) {
    xxx(2);
    xxx(1);
  }
}
