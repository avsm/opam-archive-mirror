typedef struct stlpcibrd {
	unsigned short		vendid;
	unsigned short		devid;
	int			brdtype;
} stlpcibrd_t;

int main () { sema_init(x); }
