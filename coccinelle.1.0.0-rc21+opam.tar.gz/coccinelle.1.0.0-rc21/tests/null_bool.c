int main () {
  if (x != NULL) return;
  if (a && x != NULL && b) return;
  if (x) return;
  if (a && x && b) return;
  x = x + 20;
}

