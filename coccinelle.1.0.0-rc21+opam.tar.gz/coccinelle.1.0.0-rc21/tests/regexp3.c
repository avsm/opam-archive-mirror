
int main(void) {

char *t0 = "FOO";
char *t1 = "BAR";
char *t2 = "FOOBAR";
char *t3 = "BARFOOBAR";
char *t4 = "BARFOO";
char *s0 = "%s";

}
