int main(int x) {
  f();
  h();
  g();
  h();
}

