static void foo(int x) { return; }
