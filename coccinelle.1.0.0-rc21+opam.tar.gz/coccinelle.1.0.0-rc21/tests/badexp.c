int main() {
  foo(a);
  b = a;
}
