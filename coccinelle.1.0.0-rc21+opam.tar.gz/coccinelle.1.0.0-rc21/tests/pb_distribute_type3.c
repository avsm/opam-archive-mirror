int foo() {
  int x;
  return 0;
}


int foo() {
  int *x;
  return 0;
}

int foo() {
  int x[45];
  return 0;
}
