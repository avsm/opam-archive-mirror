void info_func(int i) {
  foo();
  while (x) {
    1+hostno+xxx;
    2+hostno+xxx;
  }
}
