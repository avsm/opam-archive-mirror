int main() {
  foo(12);
}

int q() {
  xxx();
}
