struct SHT var = {
  .f1 = toto1,
  .f2 = toto2,
  .f3 = toto3,
};
