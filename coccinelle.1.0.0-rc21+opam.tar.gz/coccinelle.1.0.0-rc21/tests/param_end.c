int one (int x) { return; }

int two (int a, int x, int b) { return; }

int three (int x, int a) { return; }

int four (int a, int x) { return; }

int yone (int y) { return; }

int ytwo (int a, int y, int b) { return; }

int ythree (int y, int a) { return; }

int yfour (int a, int y) { return; }
