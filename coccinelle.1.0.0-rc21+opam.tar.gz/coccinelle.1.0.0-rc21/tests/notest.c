int main() {
  struct foo *x;
  x = FN();
  if (!x) return;
  return;
}
