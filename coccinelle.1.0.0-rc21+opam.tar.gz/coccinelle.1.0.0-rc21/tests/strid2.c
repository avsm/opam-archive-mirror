int main () {
  struct foo *a;
  enum foo1 *b;
  struct foo a1;
  enum foo1 b1;
  print(a);
  print(b);
  print(a1.x);
  print(b1);
}
