int main () { return first; }

int f () { return second; }
int f () { return second; }

int main () { return third; }

#define x 3
#define x 3
#define x 3
#define x 3

int main () { return fifth; }
