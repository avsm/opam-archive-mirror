static const int a;

static const int (*f)(const int);
