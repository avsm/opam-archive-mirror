#define CS_THIS_MODULE THIS_MODULE,
#define CS_OWNER owner:
void cs46xx_null(struct pci_dev *pcidev) { return PAGE_SIZE; }
