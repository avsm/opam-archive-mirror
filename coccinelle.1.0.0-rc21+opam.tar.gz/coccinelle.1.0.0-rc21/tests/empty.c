static int vlsi_hard_start_xmit(struct sk_buff *skb, struct net_device *ndev)
{
		pci_restore_state(pdev, idev->cfg_space);
		if (ring_first(idev->tx_ring) == NULL) {
		}
		else
			;

}
