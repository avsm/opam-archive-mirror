struct foo my_foo[] = {
.a = 1,
.u.b = 42,
};
