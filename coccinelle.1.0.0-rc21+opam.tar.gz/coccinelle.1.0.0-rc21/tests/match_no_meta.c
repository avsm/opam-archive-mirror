void main(int i)
{
  foo(1);
  bar(2);

  bar(3);
}
