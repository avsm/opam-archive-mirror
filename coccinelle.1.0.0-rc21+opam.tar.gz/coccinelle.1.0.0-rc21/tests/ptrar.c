int main () {
  struct foo *x;
  struct foo y[12];
  *y = 4;
  *x = 2;
  a = sizeof x;
  b = sizeof "foo";
}
