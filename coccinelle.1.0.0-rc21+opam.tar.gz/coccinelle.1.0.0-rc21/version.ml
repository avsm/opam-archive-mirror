let version_date = "Sun, 13 Apr 2014 22:41:13 +0200"
let configure_flags = "--enable-release --disable-python --disable-pcre-syntax"
