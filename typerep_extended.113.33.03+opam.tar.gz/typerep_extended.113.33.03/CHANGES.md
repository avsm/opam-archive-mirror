## 113.24.00

- Switched to ppx.

- Kill the nonrec rewrite done by typerep. It is no longer needed since
  4.02.2, we kept it only for compatibility with the camlp4 code.

## 112.17.00

- typerep_extended now use core_kernel

