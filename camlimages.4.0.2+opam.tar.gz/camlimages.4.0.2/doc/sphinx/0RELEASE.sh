make html
scp -r _build/html/* furuse@yquem.inria.fr:/net/yquem/infosystems/www/gallium/camlimages/
