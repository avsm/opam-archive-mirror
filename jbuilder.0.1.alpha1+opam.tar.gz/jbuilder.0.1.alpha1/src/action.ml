type t =
  { prog : Path.t
  ; args : string list
  ; dir  : Path.t
  ; env  : string array
  }
