let concurrency = ref 4
(*let ocaml_comp_flags = ref ["-g"]*)
let g = ref true
let debug_rules = ref false
let debug_run = ref true
let warnings = ref "-40"
let debug_dep_path = ref false
