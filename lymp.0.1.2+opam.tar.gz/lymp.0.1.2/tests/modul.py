# coding: utf-8
import bson

def rand_str():
	print("alright, inside python")
	return "salut les gars"

def get_tuple():
	return (1,2)

def print_tuple(arg):
	print(arg)

def first_of_tuple(arg):
	return arg[0]

def print_arg(arg):
	print(arg)

def ret_unicode():
	return u'saluté'