1.0.0 (2014-12-30):
* Initial public release.
