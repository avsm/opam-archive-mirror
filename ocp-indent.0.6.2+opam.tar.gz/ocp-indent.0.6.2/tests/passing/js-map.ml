let projection_files =
  Deferred.List.map x ~f:(fun p ->
    _)
  >>| String.split ~on:'\n'
