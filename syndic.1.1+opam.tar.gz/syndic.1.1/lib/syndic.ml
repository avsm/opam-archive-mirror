
module Rss1 = Syndic_rss1
module Rss2 = Syndic_rss2
module Atom = Syndic_atom

module XML = Syndic_xml
