
(* for now we just try to parse, so no AST *)

type info = Parse_info.info


