void main() {
  FOR_EACH (t, ugc.target_id_arr) {
  }
}

