struct x : struct y;
