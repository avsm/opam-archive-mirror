#define foo namespace {}

void main()
{
}
