
// see also constructed_object.cpp

void main() {

  foo1 x(foo2, foo3[i]);
  string& x("foo");

  foo2 x(*y);
  foo2 x(&y);

  return (x * y);

  if(!(x & y)) {
  }

}
