void main() 
{
  throw Foo();

}
