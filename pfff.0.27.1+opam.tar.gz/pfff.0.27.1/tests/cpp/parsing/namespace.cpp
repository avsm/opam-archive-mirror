
using namespace std;
using namespace a::b::std;

using foo_t;

namespace fs = boost::filesystem;

namespace x {

namespace fs = boost::filesystem;

}

namespace y {
#define MACRO1 2
}
