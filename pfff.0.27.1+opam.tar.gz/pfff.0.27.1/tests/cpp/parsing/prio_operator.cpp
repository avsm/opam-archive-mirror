void main() {
  return 1 == 1 && (x = 0);
}
