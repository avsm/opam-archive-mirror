namespace A {
}

namespace VM {
int foo() { }
}

namespace A {
}

namespace B {
  namespace VM {
    ...
  }
}
