class $X { 
}
