#define FOO 1

#define FOOBAR(a,b) a+b

int buf;

int foo(int a, int b) {
  return a+b;
}

struct x {
  int a;
  int b;
};

enum X {
  X_FOO1,
  X_FOO2,
};


int xopen() {
}
