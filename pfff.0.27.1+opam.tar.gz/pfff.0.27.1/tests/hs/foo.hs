module X

foo :: int -> int
foo 1 = 1
foo 2 = 2
