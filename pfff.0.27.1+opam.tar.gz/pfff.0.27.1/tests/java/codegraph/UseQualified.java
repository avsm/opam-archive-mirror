package X;

class UseQualified {
  public java.util.List<Object> x;
}