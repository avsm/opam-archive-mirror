package inter;

// we need to get the full inheritance tree before looking for Use
class AnotherExtendsExpr extends ExtendsExpr {
  void main() {
    int x = op;
  }
}