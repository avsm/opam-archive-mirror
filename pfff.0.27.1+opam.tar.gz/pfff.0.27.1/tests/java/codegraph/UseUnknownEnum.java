package X;
import package_with_constants.*;

class UseUnknownEnum {
  void main() {
    int x = A_CONSTANT1;
    int y = A_CONSTANT2;
    int z = A_CONSTANT3;
  }
}