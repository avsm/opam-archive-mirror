class MultiInit {
  static int x;
  static {
     x = 1;
  }

  static int y;
  static {
     y = 1;
  }

}