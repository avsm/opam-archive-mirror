package inter;

class ExtendsExtendsExpr extends ExtendsExpr {
  void main() {
    int x = op;
  }
}