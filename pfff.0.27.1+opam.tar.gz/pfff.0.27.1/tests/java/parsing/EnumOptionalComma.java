class X {

  public enum IndexItemCategory {
    SEARCH,
    APP,
    PEOPLE,
    GROUP,
  }
}

