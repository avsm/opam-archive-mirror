class Anon_class_closure {

  public static void main(String args[])
  {
    new Bar() { };

  }

}