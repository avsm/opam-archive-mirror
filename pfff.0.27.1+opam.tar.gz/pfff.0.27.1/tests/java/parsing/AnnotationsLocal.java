class X {

  void foo() {
    @SuppressWarnings("serial")
    List<Tuple<String, Long> > newRowsRaw;
  }

}

