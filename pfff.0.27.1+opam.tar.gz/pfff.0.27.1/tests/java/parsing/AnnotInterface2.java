public @interface Implementation {
  String value();

  //boolean i18nSafe() default true;
}
