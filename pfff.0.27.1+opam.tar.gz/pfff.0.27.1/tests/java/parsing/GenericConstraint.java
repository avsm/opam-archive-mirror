class TextViewHasTextMatcher<T extends TextView> extends TypeSafeMatcher<T> {
}

