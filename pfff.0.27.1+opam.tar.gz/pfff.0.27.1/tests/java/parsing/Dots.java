class Dots {

  protected void doInBackground(Void... unused) {
  }

}

