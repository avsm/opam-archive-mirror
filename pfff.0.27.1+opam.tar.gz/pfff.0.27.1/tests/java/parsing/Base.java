class Base {

  void foo(String args[])
  {
    System.out.println("Hello World from Base!");
  }

}