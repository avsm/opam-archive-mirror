class ExtendQualified extends com.org.X {
}