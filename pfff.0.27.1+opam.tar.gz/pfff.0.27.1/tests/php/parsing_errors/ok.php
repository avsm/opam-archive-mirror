<?php

// need at least one correct files in this directory otherwise
// build_db on this directory will fail hard
foo();
