<?php

$ret = 0;

//HipHop Notice:  Use of undefined constant ret - assumed 'ret' in /data/users/pad/github_new/pfff/tests/php/semantic/truthy_ugly.php on line 5
//yep, can forget dollar

if(ret) {
  echo "yep, can forget dollar\n";
}