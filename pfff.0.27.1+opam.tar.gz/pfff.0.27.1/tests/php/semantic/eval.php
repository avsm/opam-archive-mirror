<?php

$s = "echo 1+1;";
eval($s);
