<?php

class :x:foo {
  public function foo() {
    return self::BAR;
  }
}