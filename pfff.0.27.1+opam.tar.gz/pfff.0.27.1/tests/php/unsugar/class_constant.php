<?php

class A {
  function foo() {
    self::BAR;
  }
}