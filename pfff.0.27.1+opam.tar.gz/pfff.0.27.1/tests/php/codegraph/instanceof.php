<?php

$o = null;
//ERROR: undefined class
if($o instanceof UNKNOWN_CLASS) {
  
}