<?php

if(defined('DUPED_CONSTANT')) {
  define('DUPED_CONSTANT', 1);
} else {
  define('DUPED_CONSTANT', 2);
}
