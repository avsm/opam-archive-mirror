<?php

$o = ClassConstant::CST1;
$o = ClassConstant::class;
