<?php

function use_basic() {
  test_throw();
}
