<?php

class Dupe {
  private $fld;
}

//ERROR: duplicated class
class Dupe {
  private $fld;
}