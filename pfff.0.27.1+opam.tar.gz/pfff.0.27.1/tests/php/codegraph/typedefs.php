<?hh

class T1 { }

type T1Alias = T1;
//SKIP: type T1AliasAlias = T1Alias;

