<?php

function foo() {
}

class Bar {
}
