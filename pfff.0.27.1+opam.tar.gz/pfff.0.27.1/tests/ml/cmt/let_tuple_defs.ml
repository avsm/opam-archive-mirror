let (tuple_let1, tuple_let2) = 
  (fun x -> x), (fun y -> y)


let x = tuple_let1 1
