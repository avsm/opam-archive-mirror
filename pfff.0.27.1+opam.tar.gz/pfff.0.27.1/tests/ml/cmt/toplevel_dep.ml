
let _ =
  Foo.func 1 2

let () =
  let _ = Foo.func 2 3 in
  ()
