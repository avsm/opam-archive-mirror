
type foo = 
  Foo of Common.filename * Common.filepos

type foo2 = 
  Foo2 of (Common.filename * Common.filepos)
