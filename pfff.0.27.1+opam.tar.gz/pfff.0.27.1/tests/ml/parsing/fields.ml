let x = [
 { fld1 = 1;
   fld2 = 2;
 };
]

