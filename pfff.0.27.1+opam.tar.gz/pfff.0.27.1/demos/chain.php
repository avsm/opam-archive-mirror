<?php

function test_chain() {
  $o->foo()->bar()->foobar();
}