<?php

function foo($a, $b) {
  echo $a, $b;
}

foo("hello world", bar(2));
foo("hello world", "this is " . "a string");

