## 111.06.00

- Renamed `Typerep` libraries for more consistency with the rest of
  the framework.

    ```ocaml
    Typerep_kernel --> Typerep_lib
    Typerep_core   --> Typerep_extended
    Typereplib     --> Typerep_experimental
    ```

