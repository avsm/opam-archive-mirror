(* Dummy ML file to workaround https://github.com/ocsigen/lwt/issues/91 *)
