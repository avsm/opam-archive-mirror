This package provides preliminary support for building OCaml libraries
that use the [Cstubs][cstubs] module from the
[ocaml-ctypes][ocaml-ctypes] package to bind C libraries.

[![Travis build Status](https://travis-ci.org/yallop/ocaml-ctypes-build.svg?branch=master)](https://travis-ci.org/yallop/ocaml-ctypes-build)

[cstubs]: https://github.com/ocamllabs/ocaml-ctypes/blob/master/src/cstubs/cstubs.mli
[ocaml-ctypes]: https://github.com/ocamllabs/ocaml-ctypes/
