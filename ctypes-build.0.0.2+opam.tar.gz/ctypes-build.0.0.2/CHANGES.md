0.0.2 (2016-08-04):
* Remove dll library dependency rules.
  https://github.com/yallop/ocaml-ctypes-build/pull/5
* Remove flags involving /usr/local.
  https://github.com/yallop/ocaml-ctypes-build/pull/5

0.0.1 (2016-07-20):
* Initial release
