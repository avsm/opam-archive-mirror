(* For backward compatibility. *)
include Async_find
