open Exn

(* It is very stupid but camlp4 of 4.00.1 has a bug of
   converting `True to ` True and `False to ` False.
   We have to use `TRUE or `true instead.
*)

let iter_lines_exn fname f =
  let ic = open_in fname in
  protect () 
    ~f:(fun () ->
      let rec iter () = f (input_line ic); iter () in
      try iter () with Exit | End_of_file -> ())
    ~finally:(fun _ -> close_in ic)
;;

let iter_lines fname f =
  catch () ~f:(fun () -> iter_lines_exn fname f)
;;

let to_lines fname =
  let rev_lines = ref [] in
  match iter_lines fname (fun x -> rev_lines := x :: !rev_lines) with
  | `Error e -> `Error e
  | `Ok () -> `Ok (List.rev !rev_lines)
;;

let to_string fname =
  let buf = Buffer.create 0 in
  match iter_lines fname (Buffer.add_string buf) with
  | `Ok () -> `Ok (Buffer.contents buf)
  | `Error e -> `Error e

let open_out string f =
  let oc = open_out string in
  protect () ~f:(fun () -> f oc) ~finally:(fun _ -> close_out oc)
;;

let write_lines p lines = 
  open_out p (fun oc ->
    List.iter (fun l -> 
      output_string oc l; output_char oc '\n') lines)
