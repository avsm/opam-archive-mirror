var Bar = { x: 0 };
module.exports = Bar;
