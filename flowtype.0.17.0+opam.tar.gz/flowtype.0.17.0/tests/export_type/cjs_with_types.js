/* @flow */

export type talias4 = number;

module.exports = {}
