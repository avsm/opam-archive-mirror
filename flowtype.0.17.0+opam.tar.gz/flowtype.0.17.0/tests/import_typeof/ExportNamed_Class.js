/**
 * @flow
 */

class ClassFoo2 {
  returnsANumber(): number { return 42; }
}

export {ClassFoo2};
