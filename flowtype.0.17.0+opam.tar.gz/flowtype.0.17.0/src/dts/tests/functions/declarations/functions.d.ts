function f(num:number, str:string):C;
declare class C {
    x : number
}
