Blocking a 1.0 release:

* Document the signatures for ocamldoc
* Bounds checking elimination at attach-time (possibly interface-breaking)

Nice to have:

* Performance tests vs bitstring
