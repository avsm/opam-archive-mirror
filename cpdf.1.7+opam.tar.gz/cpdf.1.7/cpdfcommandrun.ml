let _ = Cpdfcommand.go ()

