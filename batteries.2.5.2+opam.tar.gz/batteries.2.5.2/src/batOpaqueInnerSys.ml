(* this file must be compiled with -opaque *)
let opaque_identity x = x
