var { ColorId } = require('./test');
var ColorIdToNumber = require('./test2');

(ColorIdToNumber[ColorId.BLUE]: 'ffffff'); // oops
