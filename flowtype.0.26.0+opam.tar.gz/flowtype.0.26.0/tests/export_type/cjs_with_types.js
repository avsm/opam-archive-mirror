/* @flow */

export type talias4 = number;
export interface IFoo { prop: number };

module.exports = {}
