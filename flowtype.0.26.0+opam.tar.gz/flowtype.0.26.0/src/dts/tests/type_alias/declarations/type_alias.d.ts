declare module M {
    type NumString = number | string
    export var x : NumString
}
