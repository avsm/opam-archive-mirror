# Generic diagnostic facility

The [generic diagnostic facility][1] can be specialised on each
[application message parametrisation][2] to produce a concrete message
facility such as the [Unixish diangostic facility][3].  The most
important product of this application are [message sinks][4].

A message sink works as a hub dispatching diagnostic messages to
output channels.  Several output channels can be attached to the same
sink and each output message will receive a given message according to
filtering rules based on the importance of message.  Applications can
hence implement a “red telephone” sending critical diagnostics to a
special line. A message sink will gather messages so long that it is
not connected to an output channel, this is controlled by *control
flags*.

The examples [wordcount][5] and [wordgen][6] show this message
facility in action. Each software component defined in these programs
define a `Message` module responsible for sending the messages to the
sink dedicated to the component.


## Formatting indications

As displayed by the following call found in [wordcount][5], messages
sent to a sink support formatting indications à la `printf`.

```ocaml
let cannot_open name reason =
  send sink Error "${FILENAME:s}: cannot open (${REASON:s})"
    [ "FILENAME", make String name;
      "REASON", make String reason;
    ]
```

Printf-like was reimplemented in terms of abstract output channels and
can be used with any output channels, including output channels whose
word is a Unicode character.


## Message sinks and internationalisation

Message sinks can (potentially) be used to easily internationalise an
application.  Let us consdier again the previous call

```ocaml
let cannot_open name reason =
  send sink Error "${FILENAME:s}: cannot open (${REASON:s})"
    [ "FILENAME", make String name;
      "REASON", make String reason;
    ]
```

It is treated as follows:

1. The string `${FILENAME:s}: cannot open (${REASON:s})` is processed to
   remove formatting indications, yielding
   `${FILENAME}: cannot open (${REASON})`.

2. The string obtained in step 1 is used a key in a message database,
   the lookup will return a short bytecode program which has two
   verbs, one to send words to an output channel and another to send
   formatted variables.

3. The bytecode program is processed, yielding actual output.

Now it is possible to write a non-internationalised Gasoline host by
using a database module actually *converting* the identifier to a
bytecode program.  If internationalisation becomes important, it is
possible to turn it on by just changing the message database module,
so that an actual lookup is performed.

This approach is superior to `printf`-based mechansims, because:

1. It allows an order change of the variables in the message, which is
   impossible with `printf`.

2. It is paramatrised by [core application types](CoreApplicationTypes)
   while `printf` requires the repeated use of custom printers.


## Organisation advice

It is bad style to scatter application diagnostics all around in a
program, because it makes it hard to automatically generate the list
of diagnostics sent by the application.  Snooping the message database
for lookups will only work as well as your coverage tests do.

Instead, it is better and not more difficult to define a `Message`
module for each software component, which is responsible for sending
diagnostic messages to the required sink.  With these precautions, it
is very to automatically determine an exhaustive list of diagnostic
messages used by the application and compare this list to the content
of an actual database.

This practice is illustrated by the example programs [wordcount][5]
and [wordgen][6].

  [1]: http://michipili.github.io/gasoline/reference/Generic_message.html
  [2]: http://michipili.github.io/gasoline/reference/Generic_message.P.html
  [3]: http://michipili.github.io/gasoline/reference/CMessage.html
  [4]: http://michipili.github.io/gasoline/reference/CMessage.Sink.html
  [5]: https://github.com/michipili/gasoline/blob/master/example/wordcount/wordcount.ml
  [6]: https://github.com/michipili/gasoline/blob/master/example/wordgen/wordgen.ml
