# OCaml bindings to the PLplot library

[PLplot][] is a library for creating scientific plots.

[PLplot]: http://plplot.sf.net/

# Installation

Install [PLplot][] then pin this repository:
```
opam pin add plplot -k git https://github.com/hcarty/ocaml-plplot.git
```
