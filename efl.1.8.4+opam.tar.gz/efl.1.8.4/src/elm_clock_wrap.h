#include "include.h"

inline Elm_Clock_Edit_Mode Elm_Clock_Edit_Mode_val_list(value v);

inline value copy_Elm_Clock_Edit_Mode(Elm_Clock_Edit_Mode m);

