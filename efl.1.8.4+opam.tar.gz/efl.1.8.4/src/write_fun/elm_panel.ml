open Common

let funs = [
  prop "orient" elm_panel_orient;
  prop "hidden" bool;
  simple_unit "toggle" [evas_object]
]

