open Common

let funs = [
  prop "enabled" bool;
  prop "smooth" bool;
  prop "alpha" bool;
  prop "auto" bool;
]

