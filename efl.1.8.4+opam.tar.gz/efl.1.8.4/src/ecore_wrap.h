#ifndef ECORE_H
#define ECORE_H

PREFIX void raise_not_X();
PREFIX void raise_not_Wayland();

PREFIX void ml_Ecore_Cb_1_free(void* data);
PREFIX void ml_Ecore_Cb_free(void* data);

#endif

