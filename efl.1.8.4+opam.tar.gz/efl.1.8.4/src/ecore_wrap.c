#include "include.h"

PREFIX void raise_not_X()
{
        static value* e = NULL;
        if(e == NULL) e = caml_named_value("Not_X exception");
        caml_raise_constant(*e);
}

PREFIX void raise_not_Wayland()
{
        static value* e = NULL;
        if(e == NULL) e = caml_named_value("Not_Wayland exception");
        caml_raise_constant(*e);
}

void* ml_Ecore_Cb(void* data)
{
        value* v_fun = (value*) data;
        caml_callback(*v_fun, Val_unit);
        return data;
}

void ml_Ecore_Cb_1_free(void* data)
{
        CAMLparam0();
        CAMLlocal1(v_fun);
        value* v_data = (value*) data;
        v_fun = Field(*v_data, 1);
        caml_callback(v_fun, Val_unit);
        ml_remove_value(v_data);
        CAMLreturn0;
}

void ml_Ecore_Cb_free(void* data)
{
        CAMLparam0();
        CAMLlocal1(v_fun);
        value* v_data = (value*) data;
        v_fun = *v_data;
        caml_callback(v_fun, Val_unit);
        ml_remove_value(v_data);
        CAMLreturn0;
}

Eina_Bool ml_Ecore_Task_Cb_free_on_last(void* data)
{
      
        value* v_fun = (value*) data;
        Eina_Bool b = Eina_Bool_val(caml_callback(*v_fun, Val_unit));
        if(!b) ml_remove_value(v_fun);
        return b;
}

PREFIX value ml_ecore_x_window_focus(value v_win)
{
#ifdef HAVE_ELEMENTARY_X
        ecore_x_window_focus(Int_val(v_win));
#else
        raise_not_X();
#endif
        return Val_unit;
}

PREFIX value ml_ecore_timer_add(value v_x, value v_fun)
{
        value* data = caml_stat_alloc(sizeof(value));
        *data = v_fun;
        caml_register_generational_global_root(data);
        Ecore_Timer* timer = ecore_timer_add(Double_val(v_x),
                ml_Ecore_Task_Cb_free_on_last, data);
        if(timer == NULL) {
                ml_remove_value(data);
                caml_failwith("ecore_timer_add");
        }
        return (value) v_fun;
}

PREFIX value ml_ecore_main_loop_thread_safe_call_sync(value v_fun)
{
        CAMLparam1(v_fun);
        Eina_Bool is_main_loop = eina_main_loop_is();
        if(!is_main_loop) caml_release_runtime_system();
        ecore_main_loop_thread_safe_call_sync(ml_Ecore_Cb, &v_fun);
        if(!is_main_loop) caml_acquire_runtime_system();
        CAMLreturn(Val_unit);
}


