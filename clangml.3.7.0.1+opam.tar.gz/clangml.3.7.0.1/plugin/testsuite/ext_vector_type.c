typedef __attribute__(( ext_vector_type(2) ))  int __int2;
