// g0018.cc
// gcc allows 'main' to be declared w/o a type!

main(int argc, char** argv)
{
  // whatever
  return argc - 1;
}
