void f() {
  int icnt;
  sizeof (int[icnt]);
  __alignof__ (int[icnt]);
}
