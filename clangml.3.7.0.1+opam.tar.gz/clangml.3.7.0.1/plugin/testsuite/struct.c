struct list
{
  struct list *next;
  int data;
};
