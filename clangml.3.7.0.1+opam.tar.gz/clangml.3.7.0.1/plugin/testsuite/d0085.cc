//  ./compat-db-3.3.11-4/cxx_app-9TN0.i.cpp_out:/home/ballAruns/tmpfiles/./compat-db-3.3.11-4/cxx_app-9TN0.i:561:38:
//  Parse error (state 275) at asm

// note that the 'asm' comes after the 'throw'

extern void *tmpfile (void) throw () __asm__ ("" "tmpfile64");
