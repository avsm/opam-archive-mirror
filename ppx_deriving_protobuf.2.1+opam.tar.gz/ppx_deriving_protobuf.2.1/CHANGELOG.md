Changelog
=========

2.1
---

  * Update for _ppx_deriving_ 2.0.

2.0
---

  * Update to accomodate syntactic changes in _ppx_deriving_ 1.0.

1.0.0
-----

  * First stable release and initial release as _ppx_deriving_protobuf_.
