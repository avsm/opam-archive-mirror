!!The Project

We are grateful to funding by the RCUK Horizon Digital Economy Research Hub grant, EP/G065802/1.

Amazon also gave us an [Amazon in Education](http://aws.amazon.com/education/) award to help test on EC2.

Verisign is [sponsoring](http://www.cl.cam.ac.uk/news/2011/03/anil-madhavapeddy-wins-verisign-grant/) work on the secure DNS library.

