include Lwt_pool
let use pool ~f = use pool f
