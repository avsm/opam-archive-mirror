let ocaml_version = "3.13.0"
let ocaml_name = "jocaml"
let ast_impl_magic_number = "Caml1999M013"
let ast_intf_magic_number = "Caml1999N012"
