let ocaml_version = "3.08.1"
let ocaml_name = "ocaml"
let ast_impl_magic_number = "Caml1999M010"
let ast_intf_magic_number = "Caml1999N009"
