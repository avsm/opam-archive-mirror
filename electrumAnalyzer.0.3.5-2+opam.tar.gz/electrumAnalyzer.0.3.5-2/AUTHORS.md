<!--- OASIS_START --->
<!--- DO NOT EDIT (digest: 37cca414da028b974b0f1840e23390e8) --->

Authors of electrumAnalyzer:

* David Chemouil
* Julien Brunel
* Denis Kuperberg

Current maintainers of electrumAnalyzer:

* david.chemouil+electrum@onera.fr
* julien.brunel+electrum@onera.fr

<!--- OASIS_STOP --->

Project initiators:

* Julien Brunel (Onera/DTIM, Toulouse)
* David Chemouil (Onera/DTIM, Toulouse)

Contributions to research about the Electrum Analyzer:

* Antoine Beugnard (Telecom Bretagne, Brest)
* Jean-Paul Bodeveix (IRIT, Toulouse)
* Julien Brunel (Onera/DTIM, Toulouse)
* David Chemouil (Onera/DTIM, Toulouse)
* Alcino Cunha (HasLab, Braga)
* Fabien Dagnat (Telecom Bretagne, Brest)
* Mamoun Filali (IRIT, Toulouse)
* Denis Kuperberg (IRIT & Onera/DTIM, Toulouse, funded by RTRA STAE project BRIEFCASE)
