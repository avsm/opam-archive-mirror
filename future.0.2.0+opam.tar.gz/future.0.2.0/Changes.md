# Future release notes

## future 0.2.0 2016-09-28
* Add more operations.
* Use solvuu-build for build system.
* Remove all uses of camlp4.

## future 0.1.0 2016-02-15
* Initial release.
