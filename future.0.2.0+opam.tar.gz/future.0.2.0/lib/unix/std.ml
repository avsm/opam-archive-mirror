module type FUTURE = S.S
module Future = Future
