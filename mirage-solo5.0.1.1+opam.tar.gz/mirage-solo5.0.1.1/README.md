Mirage OS platform bindings for Solo5.
