(* OASIS_START *)
(* DO NOT EDIT (digest: 6b14e9f8e3ce93d7b61df6632978b14b) *)
This is the README file for the ocamlify distribution.

include files in OCaml code

See the files INSTALL.txt for building and installation instructions. See the
file COPYING.txt for copying conditions. 


(* OASIS_STOP *)
