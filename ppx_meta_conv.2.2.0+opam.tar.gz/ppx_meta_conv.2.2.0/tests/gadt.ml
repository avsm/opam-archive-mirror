module M : sig
  type 'a fgen =
    | O : 'a f6 -> 'a fgen
  and 'a f6 = F of 'a f * string
  and 'a f = C : 'a f -> (char -> 'a) f
    [@@deriving conv{ocaml_of}]
end = struct
  type 'a fgen =
    | O : 'a f6 -> 'a fgen
  and 'a f6 = F of 'a f * string
  and 'a f = C : 'a f -> (char -> 'a) f
    [@@deriving conv{ocaml_of}]
end
