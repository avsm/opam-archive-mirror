# Changelog

#### 0.2.1 (30 August 2015)

- Fixes metadata in the `opam` file for submission.

### 0.2 (30 August 2015)

- Rather than just terminating when the `ABT` instruction is encountered, Nebula will now print the length-prefixed ASCII string pointed to by the first argument to the instruction.
