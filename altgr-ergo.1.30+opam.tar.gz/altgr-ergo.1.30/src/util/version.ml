(******************************************************************************)
(*     Alt-Ergo: The SMT Solver For Software Verification                     *)
(*     Copyright (C) 2013-2015 --- OCamlPro                                   *)
(*     This file is distributed under the terms of the CeCILL-C licence       *)
(******************************************************************************)

(* WARNING: a "cut" is performed on the following file in the Makefile.
   DO NOT CHANGE its format *)

let version="1.30"

let release_commit = "(not released)"

let release_date   = "(not released)"


let version="1.30"
let release_commit = "0447785ef027702c0cd50a62b86fb28dd54acc08"
let release_date = "Mon Nov 21 07:54:45 CET 2016"
