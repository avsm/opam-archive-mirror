[![Build Status](https://travis-ci.org/mirage/mirage-entropy.svg?branch=master)](https://travis-ci.org/mirage/mirage-entropy)

mirage-entropy
==============

Entropy source for MirageOS unikernels.

* WWW: <http://openmirage.org>
* E-mail: <mirageos-devel@lists.xenproject.org>
* Issues: <https://github.com/mirage/mirage/issues>
* IRC: `#mirage` on Freenode
