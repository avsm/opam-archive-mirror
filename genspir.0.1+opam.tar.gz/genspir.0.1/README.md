genspir
=======

OCaml implementation of the generalized spiral:
a function to generate almost uniformly points on a sphere.

bibliography
============

"Distributing many points on a sphere"
Saff, E.B. & Kuijlaars, A.B.J. (1997).
The Mathematical Intelligencer, 19, 5-11,
http://www.math.vanderbilt.edu/~esaff/texts/161.pdf

TODO
====

 - package for OPAM
