class D { }
class E { }
new E().x
