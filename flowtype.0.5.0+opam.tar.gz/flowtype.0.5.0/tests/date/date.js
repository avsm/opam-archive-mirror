var d = new Date(0);
var x:string = d.getTime();

var y:number = d;
