var x;

function foo(bar?) {
    x = bar;
}

function bar() {
    return x.duck;
}
