var o = require('./proto');

o.z = 0;
var x:string = o.x;
