declare var a: number;
var b: typeof a = "...";
var c: typeof a = "...";

type T = number;
var x:T = "...";

// what about recursive unions?
