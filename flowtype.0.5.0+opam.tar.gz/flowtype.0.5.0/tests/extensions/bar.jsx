module.exports = function (p: string) {}
