/* @flow */

var c = require('./b');
c.a();
c.foo();