var a = 0;

function foo(x) { }

foo("");
