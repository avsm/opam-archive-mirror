function bar(x:number) { }
function foo() {
    var x = null;
    if (x == null) return;
    bar(x);
}
