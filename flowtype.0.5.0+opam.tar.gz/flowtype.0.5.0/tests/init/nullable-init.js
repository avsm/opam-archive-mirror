var o: {x: ?number} = { x: null };
var a: Array<?number> = [null,null];
