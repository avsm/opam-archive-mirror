/* @flow */
class A {}
class B {}

module.exports = { A, B };
