/* @flow */

var f = require('./lib');

f("...");
