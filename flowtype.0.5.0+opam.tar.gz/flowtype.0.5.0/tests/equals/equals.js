var x = (1 == null);
var y = (1 == "");
