/*
@flow
*/

var x = 'Test';
var y = 5 / x;

var z: {
    type: number,
    y: string
} = {type: 1, y: 'hey'};
