#ifndef _LANGINFO_H
#define _LANGINFO_H

#include <nl_types.h>

char *nl_langinfo(nl_item);

#endif
