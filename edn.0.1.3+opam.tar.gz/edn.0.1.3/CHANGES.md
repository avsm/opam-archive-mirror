v0.1.3 2016-08-10
--------------------------

- support escaped quotes
- int parsing fix

v0.1.2 2016-06-29 
--------------------------

- oasis changed to _tags + topkg
- prefix added to internal moduled
- few bugfixed in reader
- comments support added
