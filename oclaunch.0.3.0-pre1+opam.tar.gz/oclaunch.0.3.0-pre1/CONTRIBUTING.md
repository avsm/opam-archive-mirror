# Contributions are most welcome, not only for the code !

See [the website](http://oclaunch.eu.org/contribute) for details.

By participating in this project you agree to abide by its
[rules](http://www.oclaunch.eu.org/rules).
