void f(){
  int x = 09;
}
