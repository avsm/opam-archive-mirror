void f (){
  long x = 0x80000000l;
}
