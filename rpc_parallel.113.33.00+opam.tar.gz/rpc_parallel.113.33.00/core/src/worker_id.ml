open Core.Std

include Uuid
