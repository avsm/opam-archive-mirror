v0.9.0 2015-06-17 Cambridge (UK)
--------------------------------

Support for Unicode 8.0.0's new line breaking and sentence boundary rules.


v0.8.0 2014-12-23 Cugy (VD)
---------------------------

First release.
