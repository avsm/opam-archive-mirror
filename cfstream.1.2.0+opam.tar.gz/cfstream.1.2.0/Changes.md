CFStream Release Notes

1.2.0 2015-04-25
----------------
* Add `map2` and `all` functions. 
* Add Result and Or_error modules.
* #4: skip now returns the stream in input instead of fresh one

1.1.2 2014-07-02
-------------------------
* #3: Fix bug in `drop`.
* Reduced dependency to core_kernel instead of core.

1.1.1 2014-03-02
-------------------------
* Fix doc build bug.

1.1.0 2014-03-02
-------------------------
* Provide concat_map.
* New About module.

1.0.0 2013-08-09
-------------------------
* First release.
