# POSIX semaphores

This library provides access to the POSIX semaphores.

The source code of time is available under the MIT license.

This library is originally written by [Markus Weissmann](http://www.mweissmann.de/)
