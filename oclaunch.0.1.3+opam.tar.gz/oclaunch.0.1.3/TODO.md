# Things to do

## Users idees
    **Feel free to add things here (and make a pull request).
    Or send an email to the author !**

    + @RomFouq: Add message on reset


## Short term

### Commands
 + Add command to modify configuration file
 + Allow to list all available commands

### Configuration value
 + Make displaying command before launching configurable
 + Allow to run infinitely or say when it is finish
 + Make tmp file emplacement configurable
 + Use two modes, one for easy launch and another more
   complete
    + alway runnig : be sure that there entry are always running
    + easy : one entry on each call
    + confirm : ask before launching each entry
    + proportionate : launch by percent.
 + Relaunch the terminal detached after (possibole ?)
 + Allow to tag entry and do things according to tags
 + Display text before and after, maybe in color (For example
   "================================================")

### Misc
 + Documentation ;-)
 + Reuse atdgen for tmp file
 + Use biniou in tmp file
