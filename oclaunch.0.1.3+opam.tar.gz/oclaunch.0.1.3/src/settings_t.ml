(* Auto-generated from "settings.atd" *)


type rc_file = { progs: string list; settings: string list }
