(* Auto-generated from "settings.atd" *)


type rc_file = Settings_t.rc_file = {
  progs: string list;
  settings: string list
}

let _1_tag = Bi_io.array_tag
let write_untagged__1 = (
  Ag_ob_run.write_untagged_list
    Bi_io.string_tag
    (
      Bi_io.write_untagged_string
    )
)
let write__1 ob x =
  Bi_io.write_tag ob Bi_io.array_tag;
  write_untagged__1 ob x
let string_of__1 ?(len = 1024) x =
  let ob = Bi_outbuf.create len in
  write__1 ob x;
  Bi_outbuf.contents ob
let get__1_reader = (
  Ag_ob_run.get_list_reader (
    Ag_ob_run.get_string_reader
  )
)
let read__1 = (
  Ag_ob_run.read_list (
    Ag_ob_run.get_string_reader
  )
)
let _1_of_string ?pos s =
  read__1 (Bi_inbuf.from_string ?pos s)
let rc_file_tag = Bi_io.record_tag
let write_untagged_rc_file : Bi_outbuf.t -> rc_file -> unit = (
  fun ob x ->
    Bi_vint.write_uvint ob 2;
    Bi_outbuf.add_char4 ob '\200' '\143' '\223' '\153';
    (
      write__1
    ) ob x.progs;
    Bi_outbuf.add_char4 ob '\139' '=' '|' '\227';
    (
      write__1
    ) ob x.settings;
)
let write_rc_file ob x =
  Bi_io.write_tag ob Bi_io.record_tag;
  write_untagged_rc_file ob x
let string_of_rc_file ?(len = 1024) x =
  let ob = Bi_outbuf.create len in
  write_rc_file ob x;
  Bi_outbuf.contents ob
let get_rc_file_reader = (
  fun tag ->
    if tag <> 21 then Ag_ob_run.read_error () else
      fun ib ->
        let field_progs = ref (Obj.magic 0.0) in
        let field_settings = ref (Obj.magic 0.0) in
        let bits0 = ref 0 in
        let len = Bi_vint.read_uvint ib in
        for i = 1 to len do
          match Bi_io.read_field_hashtag ib with
            | -930095207 ->
              field_progs := (
                (
                  read__1
                ) ib
              );
              bits0 := !bits0 lor 0x1;
            | 188579043 ->
              field_settings := (
                (
                  read__1
                ) ib
              );
              bits0 := !bits0 lor 0x2;
            | _ -> Bi_io.skip ib
        done;
        if !bits0 <> 0x3 then Ag_ob_run.missing_fields [| !bits0 |] [| "progs"; "settings" |];
        (
          {
            progs = !field_progs;
            settings = !field_settings;
          }
         : rc_file)
)
let read_rc_file = (
  fun ib ->
    if Bi_io.read_tag ib <> 21 then Ag_ob_run.read_error_at ib;
    let field_progs = ref (Obj.magic 0.0) in
    let field_settings = ref (Obj.magic 0.0) in
    let bits0 = ref 0 in
    let len = Bi_vint.read_uvint ib in
    for i = 1 to len do
      match Bi_io.read_field_hashtag ib with
        | -930095207 ->
          field_progs := (
            (
              read__1
            ) ib
          );
          bits0 := !bits0 lor 0x1;
        | 188579043 ->
          field_settings := (
            (
              read__1
            ) ib
          );
          bits0 := !bits0 lor 0x2;
        | _ -> Bi_io.skip ib
    done;
    if !bits0 <> 0x3 then Ag_ob_run.missing_fields [| !bits0 |] [| "progs"; "settings" |];
    (
      {
        progs = !field_progs;
        settings = !field_settings;
      }
     : rc_file)
)
let rc_file_of_string ?pos s =
  read_rc_file (Bi_inbuf.from_string ?pos s)
