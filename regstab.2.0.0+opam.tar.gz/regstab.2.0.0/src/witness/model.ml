(** Datatype and operations related to models. *)
open Softcore open Literal

(** Signature of the module. *)
module type S =
  sig
    (** Type of models. *)
    type t

    (** An empty model for a given constraint. *)
    val empty : cstr:Constraint.t -> t

    (** Add a literal to a model. *)
    val add_lit : t -> lit:Literal.t -> t

    (** Add literals to a model. *)
    val add_lits : t -> lits:Literalset.t -> t

    (** Modifies the constraint of a model so that it is its conjunction with another constraint. *)
    val and_constraint : cstr:Constraint.t -> t -> t

    (** "Shifts" a model: when a schema is shifted (i.e. [n+1] is substituted to [n]), the model also needs to be shifted in order to match the new schema. *)
    val shift : t -> t

    (** Output to string. *)
    (** Note: the output depends on the wanted encoding for strings, hence the functor. *)
    module Output : functor (S : String.S) -> sig 
      (** In addition to a model, this functions takes the following parameters:
        * - [exclude] allows to provide a list of propositional variables that won't be printed (useful if some variable are not really meaningful);
        * - [sch] is the schema which the model is supposed to be a model of; useful to give more information to the user:
        *   e.g. if the model fixes a value for the parameter, then we can display the corresponding instance;
        * - [param] and [var] allow to provide the names to provide to the parameter and variable
        *   (they must be provided since those are not stored internally);
        *   those are options because it might be that the model/schema actually does not contain the parameter or any bound variable.
        *)
      val to_string : ?exclude:Proposition.t list -> sch:Schema.t -> param:string option -> var:string option -> t -> S.t
    end
  end

(**/**)
module Exposed =
  struct
    type t = {
      shift : int; (* This is used only for the display of the model *)
      cstr : Constraint.t;
      lits : Literal.t list;
    }

    let empty ~cstr = { shift = 0; cstr = cstr; lits = [] }
    let add_lit m ~lit = { m with lits = lit :: m.lits }
    let add_lits m ~lits = { m with lits = Literalset.fold lits ~init:m.lits ~f:(fun lit ~acc -> lit :: acc) }
    let shift m = { shift = pred m.shift; cstr = Constraint.shift m.cstr; lits = List.map ~f:Literal.shift m.lits }
    let and_constraint ~cstr m = { m with cstr = Constraint.bounds_conjunction cstr m.cstr }

    module Output (S : String.S) =
      struct
        module H = Human.Output(S)
        let (^^) = S.(^)
        let (!) = S.of_string
        let concat_map x = S.concat_map ~sep:!", " x

        let to_string ?(exclude=[]) ~sch ~param ~var m =
          let literals = 
            let filter_excluded = List.filter ~f:(fun l -> not (List.mem (Literal.prop_of l) ~set:exclude)) in
            let simplify = List.map ~f:(Literal.simplify ~cstr:m.cstr) in
            let dedup = List.dedup ~eq:Literal.equal ~cmp:Literal.compare in
            let to_human = List.map ~f:(Literal.to_human ~var:param) in
            (to_human <|| dedup <|| simplify <|| filter_excluded) m.lits
          in
          let cstr = Constraint.to_human ~var:param (Constraint.shift ~by:m.shift m.cstr) in
          let excluded_variables = List.map exclude ~f:Proposition.to_human in
          let emptyset_sentence = 
            !(if m.lits = [] then " for any value of the parameter which is " ^ (if Constraint.is_lower m.cstr then "small" else "big") ^ " enough" else "") in
          (match Constraint.how_much_trivial m.cstr with
          |`VeryTrivial -> !"Found model" ^^ emptyset_sentence
          |`Trivial n   ->
              let cstr = H.cstr_to_string cstr in
              let instance = H.schema_to_string (Prop.to_human ~var:param (Schema.compute ~n:(n-m.shift) sch)) in
              !"for " ^^ cstr ^^ !", the corresponding instance is:\n\n" ^^ instance ^^ !"\n\nand the following is a model"
          |`NonTrivial  ->
              let cstr = H.cstr_to_string cstr in
              let instance = H.schema_to_string (Schema.to_human ~param ~var (Schema.algebraic_simplification sch ~cstr:m.cstr)) in
              !"for any " ^^ cstr ^^ !", the corresponding instance is:\n" ^^ instance ^^ !"\n\nand the following is a model" ^^ emptyset_sentence
          )
          ^^
          (match excluded_variables with
          |[]  -> S.empty
          |[x] -> !" (variable " ^^ H.prop_to_string x ^^ !" is excluded)"
          |xs  -> !" (variables " ^^ concat_map xs ~f:H.prop_to_string ^^ !" are excluded)")
          ^^ !":\n\n" ^^ concat_map literals ~f:H.lit_to_string
      end

  end

include (Exposed : S)
