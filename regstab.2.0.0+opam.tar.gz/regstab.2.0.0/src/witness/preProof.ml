(** Datatype and operations related to preproofs: proofs that are under construction. *)
open Softcore open Helpers

module P = Proof

(** Type of preproofs.
 * Very similar to {!Proof.t} except that children and loops are mutable in order to allow a progressive building of the proof.
 * In addition the type {!rule} allows a {!No_rule} value, which is convenient when building a proof but removed in a real proof object.
 **)
type t = node P.root
and node = {
  block : P.block;
  mutable possible_symbol : P.symbol option;
  mutable rule : rule option;
}
and rule = 
  |No_rule of node
  |Purity of Literal.t list * node
  |Top of node
  |And of P.active * P.active * node
  |Binary of P.binary * P.active * P.active * node * node
  |Unfold of ClosedArgument.t * node
  |Loop of P.symbol
  |Closed of ClosedArgument.t

(** Signature of the module *)
module type S =
  sig
    (** Conversion of a preproof to a proof. *)
    val to_proof : t -> Proof.t
  end

(**/**)
module Exposed =
  struct
    exception PreProof_is_not_well_formed of string

    module H = Human.Output(String.UTF8)
    let rec to_proof p = P.({ p with root = node_to_proof ~param:p.parameter ~var:p.bound_variable p.root })

    and node_to_proof ~param ~var n = 
      match n.rule with
      |None -> raise (PreProof_is_not_well_formed (String.UTF8.to_string (H.left_sequent_to_string (Proof.block_to_human ~param ~var n.block))))
      |Some r -> rule_to_proof ~param ~var ~bck:n.block ~sym:n.possible_symbol r

    and rule_to_proof ~param ~var ~bck ~sym = 
      let to_node r = bck, sym, r in
      let node_to_proof = node_to_proof ~param ~var in
      function
      |No_rule n -> node_to_proof n
      |Purity(lits,n) -> to_node (P.Purity(lits,node_to_proof n))
      |Top n -> to_node(P.Top (node_to_proof n))
      |And(a1,a2,n) -> to_node(P.And(a1,a2,node_to_proof n))
      |Binary(op,a1,a2,n1,n2) -> to_node(P.Binary(op,a1,a2,node_to_proof n1,node_to_proof n2))
      |Unfold(arg,n) -> to_node(P.Unfold(arg,node_to_proof n))
      |Loop s -> to_node(P.Loop s)
      |Closed arg -> to_node(P.Closed arg)
  end

include (Exposed : S)
