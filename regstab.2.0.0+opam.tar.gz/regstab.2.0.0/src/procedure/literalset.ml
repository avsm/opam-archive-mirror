open Softcore open Helpers

module type S =
  sig
    type t
    val empty : unit -> t
    val is_empty : t -> bool
    val fold : f:(Literal.t -> acc:'a -> 'a) -> t -> init:'a -> 'a
    val add : cstr:Constraint.t -> elt:Literal.t -> t -> t
    val mem : cstr:Constraint.t -> elt:Literal.t -> t -> bool
    val singleton : Literal.t -> cstr:Constraint.t -> t
    val equal : t -> t -> bool
    val half_map : f:(unit Indexes.Map.t -> 'a) -> t -> 'a Literal.HalfMap.t
    val simplify_wrt_constraint : cstr:Constraint.t -> t -> t Helpers.ClosedOrNot.t
    val shift : ?by:int -> t -> t
    val partition : f:(Literal.t -> bool) -> t -> t * t
    val subset : t -> t -> bool
    val to_list : t -> Literal.t list
  end

module Exposed =
  struct
    module I = Indexes.Map
    module HM = Literal.HalfMap
    module Half = HM.Key

    type t = (unit I.t) HM.t

    let empty () = HM.empty ()
    let direct_add ~elt s =
      let key = Half.of_lit elt in
      HM.add s ~key ~data:(I.add ~key:(Literal.idx_of elt) ~data:() (try HM.find ~key s with Not_found -> I.empty))

    let add ~cstr ~elt = direct_add ~elt:(Literal.simplify ~cstr elt)

    let direct_mem ~elt s =
      try I.mem (Literal.idx_of elt) (HM.find ~key:(Half.of_lit elt) s)
      with Not_found -> false

    let mem ~cstr ~elt = direct_mem ~elt:(Literal.simplify ~cstr elt)

    let singleton elt = add ~elt (empty ())

    let fold ~f = HM.fold ~f:(fun ~key ~data acc -> I.fold data ~init:acc ~f:(fun ~key:idx ~data:_ acc -> f (Half.to_literal key ~idx) ~acc))
    let half_map = HM.map

    let exists ~f = fold ~f:(fun elt ~acc -> acc || f elt) ~init:false
    let for_all ~f = fold ~f:(fun elt ~acc -> acc && f elt) ~init:true

    let to_list x = fold ~f:(fun elt ~acc -> elt::acc) ~init:[] x
    let is_empty x = to_list x = []

    let subset = HM.subset ~eq:(I.subset ~eq:(fun () () -> true))

    let iter ~f = HM.iter ~f:(fun ~key ~data -> I.iter data ~f:(fun ~key:idx ~data:_ -> f (Half.to_literal key ~idx)))

    let equal x y = HM.compare ~cmp:(I.compare ~cmp:(fun () () -> 0)) x y = 0
    let partition ~f =
      fold ~init:(empty (), empty ()) ~f:(fun elt ~acc:(acc1,acc2) -> if f elt then direct_add ~elt acc1, acc2 else acc1, direct_add ~elt acc2)

    exception Interruption of Literal.t
    let simplify_wrt_constraint ~cstr ls =
      let module CoN = ClosedOrNot in
      match Constraint.is_equality cstr with
      |`No -> CoN.Non_closed ls
      |`Yes _ -> 
          let ls = fold ~f:(fun elt ~acc -> add ~cstr ~elt acc) ~init:(empty ()) ls in
          try
            iter ls ~f:(fun lit -> if direct_mem ~elt:(Literal.opposite lit) ls then raise (Interruption lit));
            CoN.Non_closed ls
          with Interruption lit -> CoN.Closed (ClosedArgument.Opposite_literals(lit,cstr))

    let map_idxs ~f = HM.map ~f:(fun data -> I.fold data ~f:(fun ~key ~data:_ acc -> I.add ~key:(f key) ~data:() acc) ~init:I.empty)
    let shift ?by = map_idxs ~f:(Indexes.shift ?by)
  end

include (Exposed : S)
