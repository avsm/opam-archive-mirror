open Softcore open Constraint

module type S = 
  sig 
    val purified : bounds:Bounds.t -> lits:Literalset.t -> its:Iteration.Set.t -> cstr:Constraint.t -> Literalset.t * Literalset.t
      (* the result is a pair (set of pure literals, set of non-pure literals) *)
  end

module Exposed =
  struct
    (* A purity maps pairs ``sign of literal, proposition name of literal'' to sets of indexes.
     * The idea is that if we want to know whether P_e is pure or not,
     * we first get the set of indexes S corresponding to the pair (~,P) and then check if e is in S.
     * In such a case P_e is not pure else it is.
     *)
    (* Note: most of the time the purity computes the same kind of values e.g. most indexes are in the same interval, try to cache such results.
     * -> done once, but did not seem to improve results very much
     *)

    module HM = Literal.HalfMap
    module I = Indexes.Map
    module Half = HM.Key

    module IntervalsSet = MoreLabels.Set.Make(struct include Bounds let compare = total_compare end)

    (* The type of purity maps. *)
    type t = (unit I.t * IntervalsSet.t) HM.t

    let empty_set = I.empty, IntervalsSet.empty

    (* Add a literal to a purity map.
     * - if no bounds, just add a singleton with the index
     * - if there are bounds, say 1<=i<=n, then add the interval [2;n+1]
     *)
    let of_literal ?bounds ~acc lit =
      let idx = Literal.idx_of lit in
      let key = Half.of_lit lit in
      let (idxs,ints) = try HM.find ~key acc with Not_found -> empty_set in
      let new_data =
        match bounds with
        |None   -> I.add ~key:idx ~data:() idxs, ints
        |Some b when Indexes.contains_variable idx -> idxs, IntervalsSet.add (Bounds.shift ~by:(Indexes.get_shift idx) b) ints
        |Some _ -> I.add ~key:idx ~data:() idxs, ints
      in
      HM.add ~key ~data:new_data acc

    let of_literals x = Literalset.half_map ~f:(fun idxmap -> idxmap, IntervalsSet.empty) x

    module Pol = Connective.ExtendedPolarity

    let rec of_prop ~bounds ?(pol=Pol.Pos) ~acc p =
      match Prop.destruct p with
      |`Top | `Bot -> acc
      |`Op(con,s1,s2) ->
          let of_prop_wrt_polarity pol' = of_prop ~bounds ~pol:Pol.(match pol' with Both -> Both | Neg -> opposite pol | Pos -> pol) in
          let pol1,pol2 = Connective.polarity con in
          of_prop_wrt_polarity pol2 s2 ~acc:(of_prop_wrt_polarity pol1 s1 ~acc)
      |`Lit l -> 
          match pol with
          |Pol.Pos  -> of_literal l ~bounds ~acc
          |Pol.Neg  -> of_literal (Literal.opposite l) ~bounds ~acc
          |Pol.Both -> of_literal l ~bounds ~acc:(of_literal (Literal.opposite l) ~bounds ~acc)

    (* Note: One could cache this computation since iterations do not change all along the procedure.
     * -> tried once, actually had no impact on performance. *)
    let of_iteration ~bounds ~acc it = of_prop ~acc ~bounds (Iteration.body_of it)
    let of_iterations ~bounds ~acc = Iteration.Set.fold ~f:(fun it acc -> of_iteration it ~acc ~bounds) ~init:acc

    let is_pure ~cstr ~lit pur =
      let idx = Literal.idx_of lit in
      try
        let (idxs,ints) = HM.find ~key:(Half.opposite_of_lit lit) pur in
        I.for_all idxs ~f:(fun x -> Constraint.always_different ~hyp:cstr idx x)
        &&
        IntervalsSet.for_all ints ~f:(fun bounds -> Bounds.index_never_in ~hyp:cstr ~idx bounds)
      with Not_found -> true

    let purified ~bounds ~lits ~its ~cstr =
      let pur = of_iterations ~bounds ~acc:(of_literals lits) its in
      Literalset.partition lits ~f:(fun lit -> is_pure ~cstr ~lit pur)
  end

include (Exposed : S)
