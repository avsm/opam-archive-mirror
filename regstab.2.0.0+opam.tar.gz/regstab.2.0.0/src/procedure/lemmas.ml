(** Datatype and operations related to the lemma database used in the proof procedure.
 * Main dependency: {!Node}.
 *)
open Softcore open Helpers

(** A lemma is a standard set of atomic schemata. *)
module Lemma = AtomicSchemaSet.Std

(** A lemma table is a hash table of lemmas. *)
module Lemma_table =
  struct
    (** Standard hash table signature, where the key is a [Lemma]. *)
    include Hashtbl.Make(Lemma)

    (** List of keys. *)
    let to_list x = fold ~init:[] ~f:(fun ~key ~data:_ acc -> key :: acc) x

    (** Is the table empty? *)
    let is_empty m = length m = 0

    (** Output functorized by some {!Helpers.OUTPUT_INFO}. *)
    module Output (I : OUTPUT_INFO) =
      struct
        module S = I.S
        (**/**)
        module H = Human.Output(S)
        let param,bound_var,bounds = I.(parameter,bound_variable,bounds)
        (**/**)
        let to_string x = (S.concat_map ~sep:S.eol ~f:(H.left_sequent_to_string <|| Lemma.to_human ~param ~bound_var ~bounds) <|| to_list) x
      end
  end
(**/**)
module T = Lemma_table
(**/**)

(** Signatures. *)
module Sig =
  struct
    (** Standard signature.
     * There is only one database, thus the functions implicitly work with this database. 
     * Concretely, this entails that all functions dealing with the database do not take the database as a parameter
     * (as opposite to {!Lemma_table}).
     *)
    module type S =
      sig
        (** {6 Ancestors} *)

        (** [Node] module we rely on. *)
        module Node : Node.S

        (** The type of looping info we rely on. *)
        type looping_info = Node.looping_info

        (** {6 Main operations} *)

        (** Add a lemma with some {!looping_info} to the database. *)
        val add : Lemma.t -> info:looping_info -> unit

        (** Retrieve the {!looping_info} corresponding to a lemma from the database, if the lemma does exist in the database. *)
        val find : Lemma.t -> looping_info option

        (** Usual iteration function on the database. *)
        val iter : f:(Lemma.t -> info:looping_info -> unit) -> unit

        (** Output functorized by some {!Helpers.OUTPUT_INFO}. *)
        module Output : functor (O : OUTPUT_INFO) -> sig val to_string : unit -> O.S.t end
      end

    (** Additional values when the user wants statistics. *)
    module type WITH_STATS =
      sig
        module Stats : sig
          (** Number of times a loop was detected. *)
          val loops : unit -> int

          (** Number of lemmas added to the database. *)
          val lemmas : unit -> int

          (** Number of lemmas really used. *)
          val used_lemmas : unit -> int
        end
        (** (...) see {!S} *)
        include S
      end

    (** Additional values when the user wants to know which lemmas were used in the deduction. *)
    module type WITH_USED_LEMMAS = sig
      (** Number of lemmas really used. *)
      val used_lemmas : unit -> unit Lemma_table.t

      (** (...) see {!S} *)
      include S
    end

    (** {!WITH_STATS} + {!WITH_USED_LEMMAS} *)
    module type WITH_STATS_AND_USED_LEMMAS = sig
      (** Number of lemmas really used. *)
      val used_lemmas : unit -> unit Lemma_table.t

      include WITH_STATS
    end
  end

(**/**)
include Sig
(**/**)

(** Make a module of signature {!S} out of a node module (of signature {!Node.S}).
 * Use equality for looping.
 *)
module Make_std_equal (N : Node.S) : S with module Node = N =
  struct
    (** Inheriting types and modules from {!N}: *)

    module Node = N
    type looping_info = N.looping_info
    
    (** (...) see {!Lemmas.Sig.S} *)
    (**/**)
    let set : looping_info T.t = T.create 9973
    let add l ~info = T.add set ~key:l ~data:info
    let find l = try Some (T.find set l) with Not_found -> None
    let iter ~f = T.iter set ~f:(fun ~key ~data -> f key ~info:data)
    module Output(I : OUTPUT_INFO) = 
      struct
        module TO = T.Output(I)
        let to_string () = TO.to_string set 
      end
  end

(** Make a module of signature {!S} out of a node module (of signature {!Node.S}).
 * Use inclusion for looping.
 * Yields shorter proofs but longer execution time (inclusion is harder to detect than equality,
 * but some sets that do not loop with equality do loop with inclusion).
 *)
module Make_std_include (N : Node.S) : S with module Node = N =
  struct
    include Make_std_equal(N)
    exception Found of looping_info
    let find lemma = 
      try iter ~f:(fun l ~info -> if Lemma.subset l lemma then raise (Found info) else ()); None
      with Found info -> Some info
  end

(** Extend a module of signature {!S} with verbosity.
 * Since printing is involved, a module of signature {!OUTPUT_INFO} is also required. *)
module Extend_with_verbose (L : S) (I : OUTPUT_INFO) : S with module Node = L.Node =
  struct
    (** (...) see {!Lemmas.Sig.S} (types are unchanged w.r.t. {!R}). *)
    (**/**)
    include L
    module S = I.S
    module H = Human.Output(S)
    let to_string l = H.left_sequent_to_string (Lemma.to_human ~param:I.parameter ~bound_var:I.bound_variable ~bounds:I.bounds l)
    let (^) = S.(^)
    let add lemma ~info = with_effect (L.add lemma ~info) ~f:(fun _ -> S.print_double_endlines (S.of_string "Adding lemma " ^ to_string lemma))
    let find l =  with_effect (L.find l) ~f:(fun res -> 
      let loops_or_not = match res with None -> "does not loop" | Some _ -> "loops" in
      S.print_double_endlines (to_string l ^ S.space ^ S.of_string loops_or_not))
  end

(** Extend a module [L] of signature {!S} into a module of signature {!Sig.WITH_STATS}.
 * The {!Node} module of [L] must have signature {!Node.WITH_USED_INFO} and share the same [looping_info] as [L]. *)
module Extend_with_stats (L : S) (N : Node.WITH_USED_INFO with type looping_info = L.looping_info) : WITH_STATS with module Node = L.Node =
  struct
    (** (...) see {!Lemmas.Sig.WITH_STATS}. *)
    (**/**)
    include L
    let nb_loops, nb_lemmas, nb_used_lemmas = ref 0, ref 0, ref 0
    module Stats =
      struct
        let loops () = !nb_loops
        let lemmas () = !nb_lemmas
        let used_lemmas () = !nb_used_lemmas
      end
    let add lemma ~info = with_effect (L.add lemma ~info) ~f:(fun _ -> incr nb_lemmas)
    let find lemma =
      with_effect (L.find lemma) ~f:(Option.iter ~f:(fun info ->
          incr nb_loops;
          if not (N.Used_info.is_used info) then begin N.Used_info.mark_as_used info; incr nb_used_lemmas end))
  end

(** Extend a module [L] of signature {!S} into a module of signature {!Sig.WITH_USED_LEMMAS}.
 * The {!Node} module of [L] must have signature {!Node.WITH_USED_INFO} and share the same [looping_info] as [L]. *)
module Extend_with_used_lemmas (L : S) (N : Node.WITH_USED_INFO with type looping_info = L.looping_info) : WITH_USED_LEMMAS with module Node = L.Node =
  struct
    (** (...) see {!Lemmas.Sig.WITH_USED_LEMMAS}. *)
    (**/**)
    include L
    let find lemma = with_effect (L.find lemma) ~f:(Option.iter ~f:N.Used_info.mark_as_used)
    let used_lemmas () = with_effect (T.create 9973) ~f:(fun res -> iter ~f:(fun l ~info -> if N.Used_info.is_used info then T.add res ~key:l ~data:()))
  end

(** Extend a module [L] of signature {!S} into a module of signature {!Sig.WITH_STATS_AND_USED_LEMMAS}.
 * The {!Node} module of [L] must have signature {!Node.WITH_USED_INFO} and share the same [looping_info] as [L]. *)
module Extend_with_stats_and_used_lemmas (L : S) (N : Node.WITH_USED_INFO with type looping_info = L.looping_info) 
  : WITH_STATS_AND_USED_LEMMAS with module Node = L.Node =
    struct
      (** (...) see {!Lemmas.Sig.WITH_STATS_AND_USED_LEMMAS}. *)
      (**/**)
      module With_stats = Extend_with_stats(L)(N)
      (* Note: it is important that [Extend_with_used_lemmas] be applied after [Extend_with_stats], otherwise stats are badly counted *)
      include Extend_with_used_lemmas(With_stats)(N)
      module Stats = With_stats.Stats
    end
