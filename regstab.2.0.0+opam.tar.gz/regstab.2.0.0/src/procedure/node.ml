(** Datatype and operations related to the nodes of the built tableau.
 * In the most basic case, a node is just a set of schemas:
 * we do not store any link to its parent or child.
 * But when a proof is required then a node also contains those links.
 * Main dependency: {!RuleApplication} (because nodes are built due to the application of some rules).
 * *)
open Softcore open Helpers

(**/**)
module CoN = ClosedOrNot
(**/**)

(** Signatures. *)
module Sig =
  struct
    (** Standard signature. *)
    module type S =
      sig
        (** {6 Ancestors} *)

        (** [RuleApplication] module we rely on. *)
        module RuleApplication : RuleApplication.S

        (** The type of atomic schema sets we rely on. *)
        type atomic_schset = RuleApplication.atomic_schset

        (** The type of general schema sets we rely on. *)
        type schset = RuleApplication.schset

        (** {6 Datatype} *)

        (** The type of the nodes. *)
        type t

        (** The type of the data stored when a looping is detected
         * (more precisely, every lemma is mapped to this data in the lemma database).
         * In the most basic case, nothing is stored because we just want to know whether a lemma is or not in the database.
         * But in the cases where the user wants the proof or some information on the data used,
         * then we store more info like the symbol of the corresponding proof or the number of times the lemma was used.
         *)
        type looping_info

        (** {6 Type aliases} *)

        type and_result = RuleApplication.And.result
        type top_result = RuleApplication.Top.result
        type split_result = RuleApplication.Split.result
        type pur_result = RuleApplication.Pur.result
        type unfold_result = RuleApplication.Unfold.result
        type bot_result = RuleApplication.Bot.result

        (** {6 Constructors} *)

        val init : cstr:Constraint.t -> Schema.t -> t

        (** Builds a node out of a parent and a {!and_result}.
         * The result might be a contradiction, hence the wrapping with [ClosedOrNot.t].
         * In cases where the proof is computed, the parent's link is also updated.
         *)
        val of_and_result : parent:t -> and_result -> t ClosedOrNot.t

        (** Builds a node out of a parent and a {!top_result}. 
         * In cases where the proof is computed, the parent's link is also updated.
         *)
        val of_top_result : parent:t -> top_result -> t

        (** Builds a node out of a parent and a {!split_result}.
         * Any of both results might be a contradiction, hence the wrapping with [ClosedOrNot.t].
         * In cases where the proof is computed, the parent's link is also updated.
         *)
        val of_split_result : parent:t -> split_result -> t ClosedOrNot.t * t ClosedOrNot.t

        (** Builds a node out of a parent and a {!pur_result}.
         * In cases where the proof is computed, the parent's link is also updated.
         *)
        val of_pur_result : parent:t -> pur_result -> t

        (** Builds a node out of a parent and a {!unfold_result}.
         * There are three possibilities:
         * - the empty-iteration branch is non-closed; 
         * then it entails that it is necessarily satisfiable and we return the set of atomic schemas which allows to retrieve a model
         * ({!`Sat} case);
         * - both the empty-iteration branch and the non-empty-iteration branch are closed, then we just return {!`Closed};
         * - the empty-iteration branch is closed, and the non-empty-iteration branch is not closed, then we just return the node ({!`Neither} case);
         * In cases where the proof is computed, the parent's link is also updated.
         *)
        val of_unfold_result : parent:t -> unfold_result -> [ `Sat of atomic_schset | `Closed | `Neither of t ] 

        (** The result is just the empty list of nodes.
         * In cases where the proof is computed, the parent's link is also updated.
         *)
        val of_bot_result : parent:t -> bot_result -> t list

        (** The result is just the empty list of nodes.
         * In cases where the proof is computed, the parent's link is also updated.
         *)
        val of_looping_info : parent:t -> looping_info -> t list

        (** {6 Getters} *)

        (** Retrieves the set of schemas of a node, either an atomic or a general one. *)
        val get_schset : t -> (atomic_schset,schset) AtomicOrNot.t

        (** Retrieves the looping info of a node. *)
        val get_looping_info : t -> looping_info
      end

    (** Additional values when the user wants to know which lemmas are useful. *)
    module type USED_INFO =
      sig
        type looping_info

        (** Extract from some {!looping_info} data whether it is used or not. *)
        val is_used : looping_info -> bool

        (** Mark a {!looping_info} as used. *)
        val mark_as_used : looping_info -> unit
      end

    (** Standard signature + {!USED_INFO} *)
    module type WITH_USED_INFO = sig include S module Used_info : USED_INFO with type looping_info := looping_info end

    (** Additional values when the user wants to retrieve a proof. *)
    module type PROOF =
      sig
        type node

        (** Retrieves a {!PreProof.node} out of a node,
         * i.e. a node which is suitable for the representation of a proof, not a node as used in the provedure. *)
        val get_proof_node : node -> PreProof.node
      end

    (** Standard signature + {!PROOF} *)
    module type WITH_PROOF = sig include S module Proof : PROOF with type node := t end

    (** Standard signature + {!PROOF} + {!USED_INFO} *)
    module type WITH_PROOF_AND_USED_INFO =
      sig
        include S
        module Proof : PROOF with type node := t 
        module Used_info : USED_INFO with type looping_info := looping_info 
      end
  end

include Sig

(** Make a module of signature {!S} out of a rule application module (of signature {!RuleApplication.S}). *)
module Make_std (R : RuleApplication.S) : S with module RuleApplication = R =
  struct
    (** Inheriting types and modules from {!B}: *)

    module RuleApplication = R
    module S = R.SchemaSet

    type atomic_schset = S.atomic_schset
    type schset = S.t
    type and_result = R.And.result
    type top_result = R.Top.result
    type bot_result = R.Bot.result
    type split_result = R.Split.result
    type unfold_result = R.Unfold.result
    type pur_result = R.Pur.result

    (** (...) see {!Node.Sig.S} *)
    (**/**)
    module A = S.AtomicSchemaSet
    module AoN = AtomicOrNot
    type looping_info = unit
    type t = (A.t, S.t) AoN.t

    let init ~cstr sch = AoN.Non_atomic (S.of_schema ~cstr sch)
    let pending_if_non_closed = CoN.map ~f:(fun b -> AoN.Non_atomic b)
    let of_and_result ~parent:_ res = pending_if_non_closed (R.And.to_schset res)
    let of_top_result ~parent:_ res = AoN.Non_atomic (R.Top.to_schset res)
    let of_bot_result ~parent:_ res = []
    let of_split_result ~parent:_ res =
      let schs1,schs2 = R.Split.to_schsets res in
      pending_if_non_closed schs1, pending_if_non_closed schs2
    let of_pur_result ~parent:_ res =
      let aschs,_ = R.Pur.to_atomic_schset res in
      AoN.Atomic aschs
    let of_unfold_result ~parent:_ res =
      let aschs1,schs2 = R.Unfold.to_schsets res in
      match aschs1 with
      |SatOrClosed.Sat aschs1 -> `Sat aschs1
      |SatOrClosed.Closed arg ->
          match schs2 with ClosedOrNot.Closed arg -> `Closed | ClosedOrNot.Non_closed schs2 -> `Neither (AoN.Non_atomic schs2)
    let of_looping_info ~parent:_ _ = []
    
    let get_schset = ident
    let get_looping_info _ = ()
  end

(** Extend a module of signature {!S} into a module of signature {!Sig.WITH_PROOF}. *)
module Extend_with_proof (N : S) 
  (R : RuleApplication.WITH_PROOF 
    with module SchemaSet = N.RuleApplication.SchemaSet
    and type And.result = N.and_result
    and type Top.result = N.top_result
    and type Split.result = N.split_result
    and type Pur.result = N.pur_result
    and type Bot.result = N.bot_result
    and type Unfold.result = N.unfold_result
  )
  : WITH_PROOF with module RuleApplication = R =
  struct
    module RuleApplication = R

    type atomic_schset = N.atomic_schset
    type schset = N.schset
    type and_result = N.and_result
    type top_result = N.top_result
    type split_result = N.split_result
    type pur_result = N.pur_result
    type bot_result = N.bot_result
    type unfold_result = N.unfold_result

    (** (...) see {!WITH_PROOF} *)
    (**/**)

    module S = RuleApplication.SchemaSet
    module P = PreProof

    type looping_info = N.looping_info * Proof.symbol
    type 'a with_proof_node = 'a * P.node
    type t = N.t * P.node

    let fresh_symbol =
      let count = ref (-1) in
      fun () -> incr count; !count
    let init ~cstr sch = N.init ~cstr sch, P.({ block = S.to_proof_block (S.of_schema ~cstr sch); possible_symbol = Some (fresh_symbol ()); rule = None; })

    let lift f (n,_) = f n
    let get_schset = lift N.get_schset

    module Proof = struct let get_proof_node = snd end
    let set_rule ~rule n = P.(n.rule <- Some rule)
    let fake_proof_node = P.({ block = [], Constraint.top; possible_symbol = None; rule = None; })

    let of_bot_result ~parent:(parent,ppn) res =
      set_rule ~rule:(R.Bot.get_proof_rule res) ppn;
      List.map (N.of_bot_result ~parent res) ~f:(fun x -> x,fake_proof_node)

    let of_top_result ~parent:(parent,ppn) res =
      set_rule ~rule:(R.Top.get_proof_rule res) ppn;
      N.of_top_result ~parent res, R.Top.get_proof_node res

    let of_and_result ~parent:(parent,ppn) res =
      set_rule ~rule:(R.And.get_proof_rule res) ppn;
      CoN.map (N.of_and_result ~parent res) ~f:(fun super -> super, R.And.get_proof_node res)

    let of_split_result ~parent:(parent,ppn) res =
      set_rule ~rule:(R.Split.get_proof_rule res) ppn;
      let n1,n2 = N.of_split_result ~parent res in
      let m1,m2 = R.Split.get_proof_nodes res in
      let map_if_non_closed n m = CoN.map n ~f:(fun n -> (n,m)) in
      map_if_non_closed n1 m1, map_if_non_closed n2 m2 

    let of_pur_result ~parent:(parent,ppn) res =
      set_rule ~rule:(R.Pur.get_proof_rule res) ppn;
      N.of_pur_result ~parent res, R.Pur.get_proof_node res

    let of_unfold_result ~parent:(parent,ppn) res =
      match N.of_unfold_result ~parent res with
      |`Sat a -> `Sat a
      |`Closed ->
          IfNotSat.(match R.Unfold.get_proof_rule res with
          |Sat -> assert false
          |Not_sat rule -> set_rule ~rule ppn; `Closed)
      |`Neither n ->
          IfNotSat.(match R.Unfold.get_proof_rule res, R.Unfold.get_proof_node res with
          |(Sat,_ | _,Sat) -> assert false
          |Not_sat rule, Not_sat node ->
              match node with
              |ClosedOrNot.Closed _ -> assert false
              |ClosedOrNot.Non_closed node -> set_rule ~rule ppn; `Neither(n, node))

    let of_looping_info ~parent:(parent,ppn) (super_info,info) =
      set_rule ~rule:(P.Loop info) ppn;
      List.map (N.of_looping_info ~parent super_info) ~f:(fun x -> x,fake_proof_node)

    let get_looping_info (parent, pn) =
      let open P in
      N.get_looping_info parent,
      match pn.possible_symbol with
      |Some s -> s
      |None ->
        let s = fresh_symbol () in
        pn.possible_symbol <- Some s;
        s
  end

(** Extend a module of signature {!S} into a module of signature {!Sig.WITH_USED_INFO}. *)
module Extend_with_used_info (N : S) : WITH_USED_INFO with module RuleApplication = N.RuleApplication and type t = N.t =
  struct
    (** Inheriting types and modules from {!N}: *)

    module RuleApplication = N.RuleApplication
    type atomic_schset = N.atomic_schset
    type schset = N.schset
    type top_result = N.top_result
    type bot_result = N.bot_result
    type and_result = N.and_result
    type split_result = N.split_result
    type pur_result = N.pur_result
    type unfold_result = N.unfold_result
    type looping_info = { super: N.looping_info; mutable used: bool }

    (** (...) see {!WITH_USED_INFO} *)
    (**/**)
    module Used_info =
      struct
        let is_used { used; _ } = used
        let mark_as_used n = n.used <- true
      end
    let get_looping_info super_node = { super = N.get_looping_info super_node; used = false }
    let of_looping_info ~parent { super; _ } = N.of_looping_info ~parent super

    type t = N.t
    let init, get_schset, of_and_result, of_top_result, of_bot_result, of_split_result, of_pur_result, of_unfold_result =
      N.init, N.get_schset, N.of_and_result, N.of_top_result, N.of_bot_result, N.of_split_result, N.of_pur_result, N.of_unfold_result
  end

(** Extend a module of signature {!S} into a module of signature {!Sig.WITH_PROOF_AND_USED_INFO}. *)
module Extend_with_proof_and_used_info (N : S) 
  (R : RuleApplication.Sig.WITH_PROOF 
    with module SchemaSet = N.RuleApplication.SchemaSet
    and type And.result = N.and_result
    and type Top.result = N.top_result
    and type Split.result = N.split_result
    and type Pur.result = N.pur_result
    and type Bot.result = N.bot_result
    and type Unfold.result = N.unfold_result)
  : WITH_PROOF_AND_USED_INFO
  with module RuleApplication = N.RuleApplication =
  struct
    module With_proof = Extend_with_proof(N)(R)
    include Extend_with_used_info(With_proof)
    module Proof = With_proof.Proof
  end
