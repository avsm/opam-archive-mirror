(** Operations related to rule applications.
 * Depending on the desired functionality, different datatypes are returned.
 * This might be more than just a set of schemata:
 * e.g. a proof piece might also come with it (relevant if a proof is required as the end result).
 * Main dependencies: {!SchemaSet}, {!AtomicSchemaSet}.
 * *)
open Softcore open Helpers

(**/**)
module CoN = ClosedOrNot
(**/**)

(** Signatures. *)
module Sig =
  struct
    (** Alias for the [Flat.t] type. *)
    type f = Flat.t

    (** Datatype and operations related to the rule dealing with ⊤. *)
    module type TOP =
      sig
        (** Type of the value returned by the ⊤ rule (abstract). *)
        type result

        (** Type of the schema sets we rely on. *)
        type schset

        (** The rule itself: takes a set of schemas, apply the ⊤ rule on it 
         * (i.e. remove occurrences of ⊤), and return the resulting set of schemas. *)
        val rule : schs:schset -> result

        (** Extract a schema set out of the result. *)
        val to_schset : result -> schset
      end

    (** Datatype and operations related to the rule dealing with ⊥. *)
    module type BOT =
      sig
        (** Type of the value returned by the ⊥ rule (abstract). *)
        type result

        (** Type of the schema sets we rely on. *)
        type schset

        (** The rule itself: takes a set of schemas, apply the ⊥ rule on it.
         * Note that this is a "fake" rule since the rule just concludes that there is a contradiction.
         * This is useful mainly to store the argument of a contradiction when the user asks for a refutation.  *)
        val rule : schs:schset -> result
      end

    (** Datatype and operations related to the rule dealing with ∧. *)
    module type AND =
      sig
        (** Type of the value returned by the ∧ rule (abstract). *)
        type result

        (** Type of the schema sets we rely on. *)
        type schset

        (** The rule itself: takes a set of schemas, plus the two operands of the active formula
         * (thus the decomposition should be achieved by the caller, {i not the callee});
         * apply the ∧ rule on it (i.e. append the two operands of the active formula to the set of schemas).
         *)
        val rule : schs:schset -> f -> f -> result

        (** Extract a schema set out of the result. 
         * Note that the result might yield a contradiction, hence the wrapping with [ClosedOrNot.t].
         *)
        val to_schset : result -> schset ClosedOrNot.t
      end

    (** Datatype and operations related to any rule that yields a splitting of the branches. *)
    module type SPLIT =
      sig
        (** Type of the value returned by a splitting rule (abstract). *)
        type result

        (** Type of the schema sets we rely on. *)
        type schset

        (** The rule for ∨.
         * Takes a set of schemas, plus the two operands of the active formula and apply the rule on it
         * (i.e. generate one branch with each operand). *)
        val disj  : schs:schset -> f -> f -> result

        (** The rule for ⊕.
         * Takes a set of schemas, plus the two operands of the active formula apply the rule on it. *)
        val xor   : schs:schset -> f -> f -> result

        (** The rule for ⇒.
         * Takes a set of schemas, plus the two operands of the active formula apply the rule on it. *)
        val imply : schs:schset -> f -> f -> result

        (** The rule for ⇔.
         * Takes a set of schemas, plus the two operands of the active formula and apply the rule on it. *)
        val equiv : schs:schset -> f -> f -> result

        (** Extract two schema sets out of the result.
         * Either branch might yield a contradiction, hence the wrapping with [ClosedOrNot.t]. *)
        val to_schsets : result -> schset ClosedOrNot.t * schset ClosedOrNot.t
      end

    (** Datatype and operations related to the unfold rule. *)
    module type UNFOLD =
      sig
        (** Type of the value returned by the unfolding rule (abstract). *)
        type result

        (** Type of the schema sets we rely on. *)
        type schset

        (** Type of the atomic schema sets we rely on. *)
        type atomic_schset

        (** The rule itself.
         * Takes a set of schemata, plus two constraints corresponding respectively
         * to the case where iterations are empty, and to the case where iterations are non-empty.
         * *)
        val rule : empty_cstr:Constraint.t -> non_empty_cstr:Constraint.t -> schs:atomic_schset -> result

        (** Extract two schema sets out of the result.
         * The first set (corresponding to the case where there is no more iterations, due to emptiness) contains only atomic schemas.
         * This branch might yield an immediate contradiction due to opposite literals.
         * If it does not then it is necessarily satisfiable, hence the wrapping with [SatOrClosed.t].
         * The second set is a general set of schemata. 
         * This branch might also yield an immediate contradiction due to contradictory constraints, hence the wrapping with [ClosedOrNot.t]. *)
        val to_schsets : result -> atomic_schset SatOrClosed.t * schset ClosedOrNot.t
      end

    (** Datatype and operations related to the pur literal rule. *)
    module type PUR =
      sig
        (** Type of the value returned by the unfolding rule (abstract). *)
        type result

        (** Type of the atomic schema sets we rely on. *)
        type atomic_schset

        (** The rule itself.
         * Takes a set of schemata, plus some bounds (required to compute the pure literals).
         * Note that the bounds should be the same for all iterations in [schs] due to the properties of regular schemas and of the employed strategy. *)
        val rule : schs:atomic_schset -> bounds:Bounds.t -> result

        (** Extract the resulting set of atomic schemas, plus the set of removed literals. *)
        val to_atomic_schset : result -> atomic_schset * Literalset.t
      end

    (** Gathering of all rules signatures. *)
    module type S =
      sig
        (** {6 Ancestors} *)

        (** [SchemaSet] module we rely on. *)
        module SchemaSet : SchemaSet.S

        (** The type of atomic schema sets we rely on. *)
        type atomic_schset = SchemaSet.atomic_schset

        (** The type of general schema sets we rely on. *)
        type schset = SchemaSet.t

        (** {6 Gathering of the modules corresponding to each rule} *)

        module Bot : BOT with type schset := schset
        module Top : TOP with type schset := schset
        module Pur : PUR with type atomic_schset := atomic_schset
        module And : AND with type schset := schset
        module Split : SPLIT with type schset := schset
        module Unfold : UNFOLD with type schset := schset and type atomic_schset := atomic_schset
      end

    (** Alias for {!PreProof.rule}. *)
    type r = PreProof.rule

    (** Alias for {!PreProof.node}. *)
    type n = PreProof.node

    (** Specialized signature in the case where a refutation (proof) is required.
     * Each module shall provide additional values to allow the extraction of a proof from their result.
     * Some additional wrapping is needed in the case of the unfold rule. *)
    module type WITH_PROOF =
      sig
        (** [SchemaSet] module we rely on. *)
        module SchemaSet : SchemaSet.S

        (** The type of atomic schema sets we rely on. *)
        type atomic_schset = SchemaSet.atomic_schset

        (** The type of general schema sets we rely on. *)
        type schset = SchemaSet.t

        (** Same as {!BOT}, plus [get_proof_rule].
         * [get_proof_rule] allows to retrieve the rule that has been applied on the node. *)
        module Bot : sig include BOT with type schset := schset val get_proof_rule : result -> r end

        (** Same as {!TOP}, plus [get_proof_rule] and [get_proof_node].
         * [get_proof_rule] allows to retrieve the rule that has been applied to the node,
         * and [get_proof_node] allows to retrieve the resulting new node. *)
        module Top : sig include TOP with type schset := schset val get_proof_rule : result -> r val get_proof_node : result -> n end

        (** Same as {!AND}, plus [get_proof_rule] and [get_proof_node].
         * [get_proof_rule] allows to retrieve the rule that has been applied to the node,
         * and [get_proof_node] allows to retrieve the resulting new node. *)
        module And : sig include AND with type schset := schset val get_proof_rule : result -> r val get_proof_node : result -> n end

        (** Same as {!SPLIT}, plus [get_proof_rule] and [get_proof_nodes].
         * [get_proof_rule] allows to retrieve the rule that has been applied to the node,
         * and [get_proof_node] allows to retrieve the {b two} resulting new nodes. *)
        module Split : sig include SPLIT with type schset := schset val get_proof_rule : result -> r val get_proof_nodes : result -> n * n end

        (** Same as {!PUR}, plus [get_proof_rule] and [get_proof_node].
         * [get_proof_rule] allows to retrieve the rule that has been applied to the node,
         * and [get_proof_node] allows to retrieve the resulting new node. *)
        module Pur : sig include PUR with type atomic_schset := atomic_schset val get_proof_rule : result -> r val get_proof_node : result -> n end

        (** Same as {!UNFOLD}, plus [get_proof_rule] and [get_proof_node].
         * [get_proof_rule] allows to retrieve the rule that has been applied to the node;
         * of course this makes sense only if the branch did not prove to be satisfiable, thus the result is wrapped in [IfNotSat.t].
         * [get_proof_node] allows to retrieve the new node resulting from the branch where iterations are non empty
         * (the other branch is necessarilly closed or satisfiable:
         * in the first case, the proof is completely built so we don't need to retrieve the node,
         * in the latter case, there is just no proof so it is not relevant)
         * The result is wrapped in [IfNotSat.t] for the same reason as [get_proof_rule]
         * and in [ClosedOrNot.t] in case the branche is immediatly closed due to an unsatisfiable constraint. *)
        module Unfold : sig include UNFOLD with type schset := schset and type atomic_schset := atomic_schset
          val get_proof_rule : result -> r IfNotSat.t val get_proof_node : result -> n ClosedOrNot.t IfNotSat.t end
      end

    (** Additional values when the user wants statistics. *)
    module type STATS = 
      sig
        (** Number of times the conjunction rule has been applied *)
        val conj : unit -> int

        (** Number of times the disjunction rule has been applied *)
        val disj : unit -> int

        (** Number of times the exclusive-or rule has been applied *)
        val xor : unit -> int

        (** Number of times the equivalence rule has been applied *)
        val equ : unit -> int 

        (** Number of times the implication rule has been applied *)
        val imp : unit -> int 

        (** Number of times the unfolding rule has been applied *)
        val unfolds : unit -> int
      end

    (** Expanding {!S} with {!STATS} *)
    module type WITH_STATS = sig include S module Stats : STATS end

    (** Expanding {!S} with {!STATS} and proof information*)
    module type WITH_PROOF_AND_STATS = sig include WITH_PROOF module Stats : STATS end
  end
include Sig

(** Make a module of signature {!S} out of a schema set module (of signature {!SchemaSet.S}). *)
module Make_std (B : SchemaSet.S) : S with module SchemaSet = B =
  struct
    (** Inheriting types and modules from {!B}: *)

    module SchemaSet = B
    module A = B.AtomicSchemaSet
    type schset = B.t
    type atomic_schset = A.t

    (** (...) see {!S} *)
    (**/**)
    let (+>) sks = B.add_skeletons_semantic ~sks
    module Pur =
      struct
        type result = A.t * Literalset.t
        let rule ~schs ~bounds = A.purified ~bounds schs
        let to_atomic_schset = ident
      end
    module Bot =
      struct
        type result = unit
        let rule ~schs:_ = ()
      end
    module Top =
      struct
        type result = B.t
        let rule ~schs = schs
        let to_schset = ident
      end
    module And =
      struct
        type result = B.t ClosedOrNot.t
        let rule ~schs s1 s2 = [s1;s2] +> schs
        let to_schset = ident
      end
    module Split =
      struct
        type result = B.t ClosedOrNot.t * B.t ClosedOrNot.t
        let disj ~schs s1 s2 = [s1] +> schs, [s2] +> schs
        let (~~) = Flat.opposite
        let equiv ~schs s1 s2 = [s1;s2] +> schs, [~~s1;~~s2] +> schs
        let xor ~schs s1 s2 = [s1;~~s2] +> schs, [~~s1;s2] +> schs
        let imply ~schs s1 s2 = disj ~schs (~~s1) s2
        let to_schsets = ident
      end
    module Unfold =
      struct
        type result = A.t SatOrClosed.t * B.t ClosedOrNot.t
        let rule ~empty_cstr ~non_empty_cstr ~schs =
          CoN.(match A.and_constraint ~cstr:empty_cstr schs with 
            |Closed arg -> SatOrClosed.Closed arg
            |Non_closed _ when A.contains_iterated_disjunction schs -> SatOrClosed.Closed (ClosedArgument.Empty_disjunction empty_cstr)
            |Non_closed b -> SatOrClosed.Sat (A.empty_iterations b)
          ),
          CoN.map (A.and_constraint ~cstr:non_empty_cstr schs) ~f:(fun b -> let atomic, nas = A.unfold b in B.of_atomic ~nas atomic)
        let to_schsets = ident
      end
  end

(** Extend a module of signature {!S} into a module of signature {!Sig.WITH_PROOF}. *)
module Extend_with_proof (R : S) : WITH_PROOF with module SchemaSet = R.SchemaSet =
  struct
    (** Inheriting types and modules from {!R}: *)

    module SchemaSet = R.SchemaSet
    type schset = R.schset
    type atomic_schset = R.atomic_schset

    (** (...) see {!WITH_PROOF} *)
    (**/**)
    module B = SchemaSet
    module H = Human.Rule
    module P = PreProof
    module CoN = ClosedOrNot


    let default_node schs = P.({ block = B.to_proof_block schs; possible_symbol = None; rule = None; })
    let (+>) sks = B.add_skeletons_syntactic ~sks

    module Bot =
      struct
        type result = R.Bot.result * P.rule
        let rule ~schs = R.Bot.rule ~schs, P.Closed ClosedArgument.False_formula
        let get_proof_rule (_,r) = r
      end
    module Top =
      struct
        type result = R.Top.result * P.rule * P.node
        let rule ~schs = 
          let node = default_node schs in
          R.Top.rule ~schs, P.Top node, node
        let to_schset (x,_,_) = R.Top.to_schset x
        let get_proof_rule (_,r,_) = r
        let get_proof_node (_,_,n) = n
      end
    module And =
      struct
        type result = R.And.result * P.rule * P.node
        let rule ~schs s1 s2 =
          let res = R.And.rule ~schs s1 s2 in
          let node =
            match R.And.to_schset res with
            |CoN.Non_closed schs' -> default_node schs'
            |CoN.Closed arg -> P.({ block = B.to_proof_block ([s1;s1] +> schs); possible_symbol = None; rule = Some (Closed arg); })
          in
          res, P.And(s1,s2,node), node
        let to_schset (x,_,_) = R.And.to_schset x
        let get_proof_rule (_,r,_) = r
        let get_proof_node (_,_,n) = n
      end
    module Split =
      struct
        type result = R.Split.result * P.rule * P.node * P.node
        let node_of_possibly_closed_node ~schs schs' = P.({
          block = B.to_proof_block schs;
          possible_symbol = None;
          rule = match schs' with CoN.Closed arg -> Some (Closed arg) | CoN.Non_closed schs' -> None; 
        })
        let common ~rule ~f ~schs1_f ~schs2_f =
          fun ~schs s1 s2 ->
          let res = f ~schs s1 s2 in
          let schs1,schs2 = R.Split.to_schsets res in
          let node1 = node_of_possibly_closed_node ~schs:(schs1_f ~schs s1 s2) schs1 in
          let node2 = node_of_possibly_closed_node ~schs:(schs2_f ~schs s1 s2) schs2 in
          res, P.(Binary(rule, s1, s2, node1, node2)), node1, node2

        module P = Proof
        let (~~) = Flat.opposite
        let disj = common ~rule:P.Or ~f:R.Split.disj ~schs1_f:(fun ~schs s1 _ -> [s1] +> schs) ~schs2_f:(fun ~schs _ s2 -> [s2] +> schs)
        let equiv = common ~rule:P.Equiv ~f:R.Split.equiv ~schs1_f:(fun ~schs s1 s2 -> [s1;s2] +> schs) ~schs2_f:(fun ~schs s1 s2 -> [~~s1;~~s2] +> schs)
        let xor = common ~rule:P.Xor ~f:R.Split.xor ~schs1_f:(fun ~schs s1 s2 -> [s1;~~s2] +> schs) ~schs2_f:(fun ~schs s1 s2 -> [~~s1;s2] +> schs)
        let imply = common ~rule:P.Imply ~f:R.Split.imply ~schs1_f:(fun ~schs s1 _ -> [~~s1] +> schs) ~schs2_f:(fun ~schs _ s2 -> [s2] +> schs)
        let to_schsets (x,_,_,_) = R.Split.to_schsets x
        let get_proof_rule (_,r,_,_) = r
        let get_proof_nodes (_,_,n1,n2) = n1,n2
      end
    module Pur =
      struct
        type result = R.Pur.result * P.rule * P.node
        let rule ~schs ~bounds =
          let res = R.Pur.rule ~schs ~bounds in
          let schs',purs = R.Pur.to_atomic_schset res in
          match Literalset.to_list purs with
          |[] -> let node = default_node (B.of_atomic schs) in res, P.No_rule(node), node
          |purs -> let node = default_node (B.of_atomic schs') in res, P.Purity(purs, node), node
        let to_atomic_schset (x,_,_) = R.Pur.to_atomic_schset x
        let get_proof_rule (_,r,_) = r
        let get_proof_node (_,_,n) = n
      end
    module Unfold =
      struct
        type result = R.Unfold.result * (P.rule * P.node ClosedOrNot.t) IfNotSat.t
        let rule ~empty_cstr ~non_empty_cstr ~schs =
          let res = R.Unfold.rule ~empty_cstr ~non_empty_cstr ~schs in
          let aschs1,schs2 = R.Unfold.to_schsets res in
          res,
          CoN.(match aschs1 with
          |SatOrClosed.Sat _ -> IfNotSat.Sat
          |SatOrClosed.Closed arg1 -> IfNotSat.Not_sat(
            match schs2 with
            |Non_closed schs2 -> let node = default_node schs2 in P.Unfold(arg1, node), Non_closed node
            |Closed arg2 as closed ->
                let atomic,nas = B.AtomicSchemaSet.unfold schs in
                P.(Unfold(arg1, { block = B.to_proof_block (B.of_atomic ~nas atomic); possible_symbol = None; rule = Some(Closed arg2); })), closed
            )
          )
        let to_schsets (x,_) = R.Unfold.to_schsets x
        let get_proof_rule (_,x) = IfNotSat.map ~f:fst x
        let get_proof_node (_,x) = IfNotSat.map ~f:snd x
      end
  end

(** Extend a module of signature {!S} into a module of signature {!Sig.WITH_STATS}. *)
module Extend_with_stats (R : S) : WITH_STATS with module SchemaSet = R.SchemaSet =
  struct
    (** Inheriting types and modules from {!R}: *)

    module SchemaSet = R.SchemaSet
    type atomic_schset = R.atomic_schset
    type schset = R.schset

    (** (...) see {!WITH_STATS} *)
    (**/**)
    let nb_conj, nb_disj, nb_xor, nb_equ, nb_imp, nb_unf = ref 0, ref 0, ref 0, ref 0, ref 0, ref 0
    module Stats = struct
      let conj () = !nb_conj
      let disj () = !nb_disj
      let xor () = !nb_xor
      let equ () = !nb_equ
      let imp () = !nb_imp
      let unfolds () = !nb_unf
    end
    module And =
      struct
        include R.And
        let rule ~schs s1 s2 = with_effect (rule ~schs s1 s2) ~f:(fun _ -> incr nb_conj)
      end
    module Split =
      struct
        include R.Split
        let common ~f ~stat ~schs s1 s2 = with_effect (f ~schs s1 s2) ~f:(fun _ -> incr stat)
        let disj = common ~f:disj ~stat:nb_disj
        let equiv = common ~f:equiv ~stat:nb_equ
        let xor = common ~f:xor ~stat:nb_xor
        let imply = common ~f:imply ~stat:nb_imp
      end
    module Unfold =
      struct
        include R.Unfold
        let rule ~empty_cstr ~non_empty_cstr ~schs = with_effect (R.Unfold.rule ~empty_cstr ~non_empty_cstr ~schs) ~f:(fun _ -> incr nb_unf)
      end
    (* There's room for more stats if needed *)
    module Pur = R.Pur
    module Bot = R.Bot
    module Top = R.Top
  end

(** Extend a module of signature {!S} with verbosity.
 * Since printing is involved, a module of signature {!OUTPUT_INFO} is also required. *)
module Extend_with_verbose (R : S) (I : OUTPUT_INFO) : S with module SchemaSet = R.SchemaSet =
  struct
    (** (...) see {!S} (types are unchanged w.r.t. {!R}) *)
    (**/**)
    module S = I.S
    module SchemaSet = R.SchemaSet
    module B = SchemaSet
    module A = B.AtomicSchemaSet
    module H = Human.Output(S)
    module CArgO = ClosedArgument.Output(I)

    let param, bound_var, bounds = I.(parameter,bound_variable,bounds)
    let (!) = S.of_string
    let (^) = S.(^)
    let verbose = S.print_double_endlines
    let verbose' x = verbose (!"  " ^ S.to_ ^ S.space ^ x)
    let schset_to_string = H.left_sequent_to_string <|| B.to_human ~param ~bound_var ~bounds
    let atomic_schset_to_string = H.left_sequent_to_string <|| A.to_human ~param ~bound_var ~bounds
    let flat_to_string = H.schema_to_string <|| Flat.to_human ~param ~var:bound_var ~bounds

    type schset = B.t
    type atomic_schset = A.t

    let (+>) sks = B.add_skeletons_semantic ~sks
    module Pur =
      struct
        include R.Pur
        let lits_to_string = S.concat_map ~f:(H.lit_to_string <|| Literal.to_human ~var:param) <|| Literalset.to_list
        let rule ~schs ~bounds =
          verbose (!"Removing pure literals of " ^ atomic_schset_to_string schs);
          with_effect (R.Pur.rule ~schs ~bounds) ~f:(fun res ->
            let purified,purs = R.Pur.to_atomic_schset res in
            if Literalset.is_empty purs 
            then verbose' !"no pure literal found, schema set unchanged"
            else begin
              verbose' (!"the following literals are pure: " ^ lits_to_string purs);
              verbose' (!"resulting schema set lock: " ^ atomic_schset_to_string purified)
            end
          )
      end
    module Bot =
      struct
        include R.Bot
        let rule ~schs = with_effect (R.Bot.rule ~schs) ~f:(fun _ -> verbose !"Applying Bot rule")
      end
    module Top =
      struct
        include R.Top
        let rule ~schs = with_effect (R.Top.rule ~schs) ~f:(fun _ -> verbose !"Applying Top rule")
      end
    module And =
      struct
        include R.And
        let rule ~schs s1 s2 = with_effect (R.And.rule ~schs s1 s2) ~f:(fun res -> 
          verbose (!"Applying And rule on " ^ flat_to_string s1 ^ S.space ^ S.wedge ^ S.space ^ flat_to_string s2);
          match R.And.to_schset res with
          |CoN.Closed arg -> verbose' (!"closed because of " ^ CArgO.to_string arg)
          |CoN.Non_closed schs -> verbose' (schset_to_string schs)
          )
      end
    module Split =
      struct
        include R.Split
        module C = Connective.Output(S)
        let common ~f ~name ~op ~schs s1 s2 =
          with_effect (f ~schs s1 s2) ~f:(fun res ->
            verbose (!"Applying " ^ !name ^ !" rule on " ^ flat_to_string s1 ^ S.space ^ op ^ S.space ^ flat_to_string s2);
            let schs1,schs2 = to_schsets res in
            let common schs ~branch =
              verbose' (!branch ^ !" branch " ^
                match schs with
                |CoN.Closed arg -> !"closed because of " ^ CArgO.to_string arg
                |CoN.Non_closed schs -> !"yields " ^ schset_to_string schs)
            in
            common schs1 ~branch:"First";
            common schs2 ~branch:"Second")
        let disj = common ~f:R.Split.disj ~name:"Or" ~op:S.vee
        let equiv = common ~f:R.Split.equiv ~name:"Equiv" ~op:S.equiv
        let xor = common ~f:R.Split.xor ~name:"Xor" ~op:S.oplus
        let imply = common ~f:R.Split.imply ~name:"Imply" ~op:S.imply
      end
    module Unfold =
      struct
        include R.Unfold
        let rule ~empty_cstr ~non_empty_cstr ~schs =
          verbose (!"Unfolding " ^ atomic_schset_to_string schs);
          with_effect (R.Unfold.rule ~empty_cstr ~non_empty_cstr ~schs) ~f:(fun res ->
            let left,right = R.Unfold.to_schsets res in
            begin
              let verbose'' x = verbose' (!"Branch where iterations are empty " ^ x) in
              match left with
              |SatOrClosed.Sat schs -> verbose'' (!"is satisfiable! (schema set = " ^ atomic_schset_to_string schs ^ !")")
              |SatOrClosed.Closed arg ->
                  verbose'' (!"is closed due to " ^ CArgO.to_string arg);
                  let verbose'' x = verbose' (!"Branch where iterations are not empty " ^ x) in
                  match right with
                  |ClosedOrNot.Closed arg -> verbose'' (!"closed due to " ^ CArgO.to_string arg)
                  |ClosedOrNot.Non_closed schs -> verbose'' (!"results in: " ^ schset_to_string schs)
            end
          )
      end
  end

(** Extend a module of signature {!S} into a module of signature {!WITH_PROOF_AND_STATS} *)
module Extend_with_proof_and_stats (R : S) : WITH_PROOF_AND_STATS with module SchemaSet = R.SchemaSet =
  struct
    module With_stats = Extend_with_stats(R)
    include Extend_with_proof(With_stats)
    module Stats = With_stats.Stats
  end
