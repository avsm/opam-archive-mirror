(** Datatype and operations related to sets of schemas. *) 
open Softcore open Helpers

(**/**)
module CoN = ClosedOrNot
module CArg = ClosedArgument
(**/**)

(** Signature *)
module type S =
  sig
    (** Type of schema sets. *)
    type t

    (** {6 Ancestors} *)

    (** Set of atomic schemas which we rely on. *)
    module AtomicSchemaSet : AtomicSchemaSet.S

    (** Type of atomic sets we rely on. *)
    type atomic_schset = AtomicSchemaSet.t

    (** {6 Constructors} *)

    val of_schema : cstr:Constraint.t -> Schema.t -> t

    (** [nas] (for ``{b n}on {b a}tomic schema{b s}'') allows to provide non atomic
     * schemas in addition to the atomic ones already present in the [atomic_schset]. *)
    val of_atomic : ?nas:Flat.non_atomic list -> atomic_schset -> t

    (** {6 Comparisons} *)

    val equal : t -> t -> bool

    (** {6 Getters} *)

    val contains_iteration : t -> bool

    (** Picks any non atomic schema.
     * Returns [None] if the set is empty, otherwise returns an option carrying
     * both the non atomic schema, and the set containing the remaining schemas. *)
    val pick_non_atomic : t -> (Flat.non_atomic * t) option

    (** ``Forget'' the non atomic schemas of the set. *)
    val to_atomic : t -> atomic_schset

    (** {6 Setters} *)

    (** Adds some skeletons to a set. *)
    val add_skeletons_syntactic : sks:Flat.t list -> t -> t

    (** Same as {!add_skeletons_syntactic}, but also check whether one of the
     * skeletons is a literal that generates a contradiction with the literals already in the set.
     * Returns [Helpers.Non_closed(schset)] if there is no contradiction (where [schset] is the new set),
     * and [Helpers.(Closed(Opposite_literals(...)))] if there is a contradiction.
     *)
    val add_skeletons_semantic : sks:Flat.t list -> t -> t ClosedOrNot.t

    (** {6 Useful operations} *) 

    (** Conversion to proof blocks. *)
    val to_proof_block : t -> Proof.block

    (** {6 Conversion to human sequents} *)

    val to_human : param:string option -> bound_var:string option -> bounds:Bounds.t option -> t -> Human.left_sequent
  end

(** Make a module of signature {!S} out of an atomic schema set module (of signature {!AtomicSchemaSet.S}).
 **)
module Make (A : AtomicSchemaSet.S) : S with module AtomicSchemaSet = A =
  struct
    (** Inheriting types and modules from {!A}: *)

    module AtomicSchemaSet = A
    type atomic_schset = A.t

    (** ... see {!S} *)
    (**/**)
    type t = A.t * Flat.non_atomic list
    let contains_iteration (x,_) = A.contains_iteration x
    let equal (x1,nas1) (x2,nas2) = A.equal x1 x2 && List.equal ~eq:Flat.equal (Flat.of_non_atomics nas1) (Flat.of_non_atomics nas2)
    let to_human ~param ~bound_var ~bounds (x,nas) =
      let schs,cstr = A.to_human ~param ~bound_var ~bounds x in
      List.fold_left nas ~init:schs ~f:(fun acc na -> Flat.to_human ~var:bound_var ~param ~bounds (Flat.of_non_atomic na) :: acc), cstr
    let to_atomic (x,_) = x
    let of_atomic ?(nas=[]) x = (x,nas)
    let add_skeleton_semantic ~sk (b,nas) =
      match Flat.destruct sk with
      |`Bot -> CoN.Closed CArg.False_formula
      |`Lit lit -> CoN.map (A.add_literal_semantic ~lit b) ~f:(fun x -> x, nas)
      |`It it -> CoN.Non_closed (A.add_iteration ~it b, nas)
      |(`Top | `Op _) as na -> CoN.Non_closed (b,na::nas)
    let add_skeletons_semantic ~sks bck = List.fold_left sks ~init:(CoN.Non_closed bck) ~f:(fun acc sk -> 
      match acc with
      |CoN.Non_closed acc -> add_skeleton_semantic ~sk acc
      |CoN.Closed _ as x -> x)
      (* PERF might be faster by throwing an exception in the [Closed] case.
       * However, the input list has at most 2 elts so it should not have a huge impact. *)
    let add_skeleton_syntactic ~sk (b,nas) =
      match Flat.destruct sk with
      |`Lit lit -> A.add_literal_syntactic ~lit b, nas
      |`It it -> A.add_iteration ~it b, nas
      |(`Top | `Op _ | `Bot) as na -> b, na::nas
    let add_skeletons_syntactic ~sks bck = List.fold_left sks ~init:bck ~f:(fun acc sk -> add_skeleton_syntactic ~sk acc)
    let of_schema ~cstr sch = add_skeleton_syntactic ~sk:(Schema.skeleton_of sch) (A.empty ~cstr, [])
    let pick_non_atomic (b,nas) = match nas with [] -> None | na::nas' -> Some(na,(b,nas'))
    let to_proof_block (b,nas) =
      let sks,cstr = A.to_proof_block b in
      Flat.of_non_atomics nas @ sks, cstr
  end
