(** Datatype and operations related to sets of atomic schemas (``atomic sets'').
 * Here, "atomic" means either a literal or an iteration.
 **)
open Softcore open Helpers

(**/**)
module CoN = ClosedOrNot
module CArg = ClosedArgument
(**/**)

(** Partial signature.
 * As we will see there exist two versions of atomic sets: a standard one ({!Std}), and one in which all sets also carry a model.
 * However it is required that both can be translated in the standard one at some point
 * (function {!to_std}, used in {!ExpandNode}) - of course this translation is trivial in the former case.
 * However {!Std} is not defined yet, thus we cannot fully define the signature for now.
 * This will be completed once {!Std} is defined.
 **)
module type Soid =
  sig
    (** Type of atomic sets. *)
    type t

    (** {6 Comparisons} *)

    val equal : t -> t -> bool
    val subset : t -> t -> bool

    (** {6 Constructors} *)

    val empty : cstr:Constraint.t -> t

    (** {6 Getters} *)

    val cstr_of : t -> Constraint.t
    val lits_of : t -> Literalset.t
    val contains_iterated_disjunction : t -> bool
    val contains_iteration : t -> bool
    val mem_literal : lit:Literal.t -> t -> bool

    (** {6 Setters} *)

    (** Adds an iteration to a set. *)
    val add_iteration : it:Iteration.t -> t -> t

    (** Adds a literal to a set. *)
    val add_literal_syntactic : lit:Literal.t -> t -> t

    (** Same as {!add_literal_syntactic}, but also check whether the added literal
     * generates a contradiction with the literals already in the set.
     * Returns [Helpers.Non_closed(bck)] if there is no contradiction (where [bck] is the new set),
     * and [Helpers.(Closed(Opposite_literals(...)))] if there is a contradiction.
     *)
    val add_literal_semantic : lit:Literal.t -> t -> t ClosedOrNot.t

    (** {6 Useful operations} *) 

    (** Type of standard atomic sets (to be substituted with [Std.t]). *)
    type std

    val to_std : t -> std

    (** Remove pure literals from a set.
     * @return both the "purified" set and the set of removed literals.
     *)
    val purified : bounds:Bounds.t -> t -> t * Literalset.t

    (** Remove the iterations from a set. *)
    val empty_iterations : t -> t

    (** ``AND'' the constraint of the set with a new constraint.
     * Simplify the set if the resulting constraint yields some simplifications.
     * The result is wrapped in [Helpers.ClosedOrNot.t] because the resulting constraint can be unsatisfiable.
     * Returns [Helpers.Non_closed(bck)] if there is no contradiction (where [bck] is the new set),
     * and [Helpers.(Closed.Unsatisfiable_constraint(...))] if there is a contradiction.
     *)
    val and_constraint : cstr:Constraint.t -> t -> t ClosedOrNot.t

    (** Unfold all iterations in a set, and shift the literals indices accordingly. *)
    val unfold : t -> t * Flat.non_atomic list

    (** Conversion to proof blocks. *)
    val to_proof_block : t -> Proof.block

    (** {6 Conversion to human sequents} *)

    exception Missing_parameter
    exception Missing_variable
    val to_human : t -> param:string option -> bound_var:string option -> bounds:Bounds.t option -> Human.left_sequent

  end

(** Standard atomic sets.
 * See {!Soid}: the only differences are that [std] is instantiated into [t] and that a [hash] function is provided.
 **)
module Std :
  sig
    type t

    include Soid with type t := t and type std := t

    val hash : t -> int
  end
  =
  struct
    module IS = Iteration.Set

    type t = Literalset.t * IS.t * Constraint.t

    (** A hash function is required for standard sets because they will be used in the lemma database. *)
    let hash (x:t) = Hashtbl.hash x

    (** [to_std] is actually the identity function here. *)
    let to_std : t -> t = ident

    (** (... - the rest is just like {!Soid}) *)
    (**/**)
    let empty ~cstr = Literalset.empty (), IS.empty, cstr
    let cstr_of (_,_,cstr) = cstr
    let lits_of (lits,_,_) = lits

    let contains_iterated_disjunction (_,its,_) = IS.exists its ~f:Iteration.is_disjunction
    let contains_iteration (_,its,_) = its <> IS.empty

    let purified ~bounds (lits,its,cstr) = 
      let purs, non_purs = Purity.purified ~lits ~its ~cstr ~bounds in
      (non_purs, its, cstr), purs

    let mem_literal ~lit (lits,_,cstr) = Literalset.mem ~cstr ~elt:lit lits

    let add_literal_syntactic ~lit (lits,its,cstr) = Literalset.add ~cstr ~elt:lit lits, its, cstr

    let add_literal_semantic ~lit ((lits,its,cstr) as a) = 
      if mem_literal ~lit:(Literal.opposite lit) a
      then CoN.Closed(CArg.Opposite_literals(lit,cstr))
      else CoN.Non_closed(add_literal_syntactic ~lit a)

    let add_iteration ~it (lits,its,cstr) = (lits, IS.add it its, cstr)

    exception Missing_parameter
    exception Missing_variable
    let to_human (lits,its,cstr) ~param ~bound_var ~bounds =
      let human_lits = List.rev_map (Literalset.to_list lits) ~f:(fun lit -> Human.Lit(Literal.to_human ~var:param lit)) in
      let it_to_human it =
        let param = Option.raise_if_none ~exc:Missing_parameter param in
        let var = Option.raise_if_none ~exc:Missing_variable bound_var in
        Human.It(Iteration.to_human ~param ~var ~bounds:(Bounds.of_option bounds) it) in
      let human_lits_its = List.fold_left (IS.elements its) ~f:(fun acc it -> it_to_human it :: acc) ~init:human_lits in
      human_lits_its, Constraint.to_human ~var:param cstr

    let and_constraint ~cstr (lits,its,cstr') = 
      let cstr'' = Constraint.bounds_conjunction cstr cstr' in
      if Constraint.is_false cstr'' then CoN.(Closed (CArg.Unsatisfiable_constraint(cstr,cstr'))) else 
        let simplified = Literalset.simplify_wrt_constraint ~cstr:cstr'' lits in
        CoN.map simplified ~f:(fun lits' -> (lits',its,cstr''))

    let empty_iterations (lits,_,cstr) = (lits,IS.empty,cstr)

    let unfold (lits,its,cstr) = 
      let unfolded_its = IS.fold its ~init:[] ~f:(fun it acc -> 
        let op,body,it = Iteration.unfold it in
        let unfolded_it = (if Connective.Big.is_disjunction op then Flat.disj else Flat.conj) (Flat.of_prop body) (Flat.it it) in
        unfolded_it :: acc)
      in
      (Literalset.shift lits,IS.empty,Constraint.shift cstr), unfolded_its

    let equal (lits1,its1,c1) (lits2,its2,c2) = Constraint.equal c1 c2 && Literalset.equal lits1 lits2 && IS.equal its1 its2

    let subset (lits1,its1,c1) (lits2,its2,c2) = Literalset.subset lits1 lits2 && IS.subset its1 its2 && Constraint.entails c2 c1

    let to_proof_block (lits,its,cstr) = 
      let lits' = List.rev_map (Literalset.to_list lits) ~f:Flat.lit in
      let lits_its = List.fold_left (IS.elements its) ~f:(fun acc it -> Flat.it it :: acc) ~init:lits' in
      lits_its, cstr
  end

(** Signatures. *)
module Sig =
  struct
    (** Same as {!Soid} except that [std] is defined as [Std.t]. *)
    module type S = Soid with type std := Std.t

    (** The module that carries models provides the following values. *)
    module type MODEL = sig
      (** Type of the atomic set that carries a model. *)
      type atomic

      (** Retrieve the model carried by the [atomic] set. *)
      val retrieve : atomic -> Model.t
    end

    (** {!S} + {!MODEL} *)
    module type WITH_MODEL = sig include S module Model : MODEL with type atomic := t end 
  end
include Sig

(** The version that carries models in addition to the usual contents of a schema set is obtained through a functor.
 * Indeed extending the standard module is the best way to share many operations that are similar.
 *
 * The resulting module has signature {!Sig.WITH_MODEL}.
 *)
module Extend_with_model (A : S) : WITH_MODEL =
  struct
    (**/**)
    type t = A.t * Model.t
    exception Missing_parameter
    exception Missing_variable
    let empty ~cstr = A.empty ~cstr, Model.empty ~cstr
    let map f (x,m) = (f x, m)
    let fold f (x,m) = f x
    let to_std = fold A.to_std
    let cstr_of = fold A.cstr_of
    let lits_of = fold A.lits_of
    let to_proof_block = fold A.to_proof_block
    let contains_iterated_disjunction = fold A.contains_iterated_disjunction
    let contains_iteration = fold A.contains_iteration
    let add_iteration ~it = map (A.add_iteration ~it)
    let mem_literal ~lit = fold (A.mem_literal ~lit)
    let add_literal_syntactic ~lit (x,m) =
      A.add_literal_syntactic ~lit x, Model.add_lits m ~lits:(Literalset.singleton ~cstr:(A.cstr_of x) lit)
    let add_literal_semantic ~lit (x,m) =
      CoN.map (A.add_literal_semantic ~lit x) ~f:(fun a -> a, Model.add_lits m ~lits:(Literalset.singleton ~cstr:(A.cstr_of x) lit))
    let purified ~bounds (x,m) =
      let res, purs = A.purified ~bounds x in
      (res, m), purs
    let to_human = fold A.to_human
    let and_constraint ~cstr (x,m) = CoN.map (A.and_constraint ~cstr x) ~f:(fun x -> x, Model.and_constraint ~cstr m)
    let empty_iterations = map A.empty_iterations
    let unfold (x,m) =
      let x',nas = A.unfold x in
      (x', Model.shift m), nas
    let equal (x1,_) (x2,_) = A.equal x1 x2 (* We don't care about models for equality *)
    let subset (x1,_) (x2,_) = A.subset x1 x2
    module Model = struct let retrieve (_,m) = m end
  end
