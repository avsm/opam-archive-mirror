(** Datatypes intended to be an intermediate between the user and the internal datatypes.
 * For instance, the internal representation of variables does not contain the name of the variable because it is useless for the procedure.
 * Its "human" counterpart ({!int_var}), on the other hand, is indeed a string.
 *
 * The human representation is used as an intermediate between the user and the internal data representation,
 * both for input (parsing) or for output (printing to [stdout] or to file).
 * This is a convenient way to gather much information that should be otherwise vehicled through the arguments of many functions.
 *)
open Softcore

(** Human version of {!Schema.S.t}. *)
type schema = Top | Bot | Op of connective * schema * schema | Lit of literal | It of iteration

(** Human version of {!Connective.S.t}. *)
and connective = And | Or | Xor | Equiv | Imply

(** Human version of {!Literal.S.t}. *)
and literal = polarity * prop_var * indexes

(** Human version of {!Proposition.S.t}. *)
and prop_var = string

(** Human version of {!Polarity.S.t}. *)
and polarity = Pos | Neg

(** Human version of {!Indexes.S.t}. *)
and indexes = Int of int | Sum of int_var * int

(** Human version of {!Iteration.S.t}. *)
and iteration = big_connective * int_var * lower_bound * upper_bound * schema

(** Human version of {!Connective.S.Big.t}. *)
and big_connective = Big_and | Big_or

(** Integer variable (no internal datatype counterpart). *)
and int_var = string

(** Iteration lower bound (no internal datatype counterpart). *)
and lower_bound = int

(** Iteration upper bound (no exact internal datatype counterpart, but close to {!Indexes.S.t}). *)
and upper_bound = int_var * int

(** Human version of {!Constraint.S.t}. *)
type cstr =
  |True
  |False
  |Atom of int_var * inequality * int
  |Between of int * int_var * int

(** Human version of {!Inequality.S.t}. *)
and inequality = Le | Lt | Eq | Gt | Ge

(** Human version of {!Proof.rule} and {!Proof.binary} (covers a bit of both). *)
module Rule =
  struct
    type unary = And | Purity | Top
    type binary = Or | Equiv | Imply | Xor | Unfold
  end

(** Human version of {!Proof.t}. *)
type proof = (symbol * partial_proof) list

(** Human version of {!Proof.symbol}. *)
and symbol = int

(** Human version of {!Proof.node}. *)
and partial_proof = left_sequent * rule

(** Human version of {!Proof.rule}. *)
and rule =
  |Axiom
  |Link of symbol
  |Unary of unary_rule_type * child
  |Binary of binary_rule_type * child * child

(** Human version of {!Proof.rule} and {!Proof.binary} (covers a bit of both). *)
and unary_rule_type = Rule.unary

(** Human version of {!Proof.rule} and {!Proof.binary} (covers a bit of both). *)
and binary_rule_type = Rule.binary

(** Human version of {!Proof.node} ({!child} is just an abbreviation for {!partial_proof} to make the type {!rule} clearer. *)
and child = partial_proof

(** Human version of {!Proof.block} *)
and left_sequent = schema list * cstr

(** Signature for the operations related to the above types. *)
module type S = 
  sig
    (** Most operations, except for the {!Output} module, are useful for parsing. *)

    (** Exception raised if a schema contains more than one free variable (forbidden by the conditions on regular schemata).
     * The two strings are the two different variables that were encountered.
     *)
    exception More_than_one_free_variable of string * string

    (** Exception raised if a schema contains two iterations with different lower bounds (forbidden by the conditions on regular schemata).
     * The two integers are the two different lower bounds.
     *)
    exception Different_lower_bounds of int * int

    (** Exception raised if a schema contains two iterations with different upper bounds (forbidden by the conditions on regular schemata).
     * The two [string * int] are the two different upper bounds.
     *)
    exception Different_upper_bounds of (string * int) * (string * int)

    (** Returns the (only) free variable that appears in a schema.
     * Since there might be none (for a pure propositional formula), the result type is an option.
     * @raise More_than_one_free_variable if more that one free variable were encountered.
     *)
    val free_variable_of : schema -> int_var option

    (** Returns the first bound variable that appears in a schema.
     * Since there might be none (if there is no iteration), the result type is an option.
     *)
    val first_bound_variable_of : schema -> int_var option

    (** Returns the bounds that are common to all iterations in a schema (they should be common by the conditions on regular schemata).
     * @raise Different_lower_bounds if different lower bounds were encountered.
     * @raise Different_upper_bounds if different upper bounds were encountered.
     *)
    val bounds_of : schema -> (lower_bound * upper_bound) option

    (** Complementary schema: since the procedure only works with n.n.f. schemata, negated schemata are turned into n.n.f. ones.
     * This is obtained by applying De Morgan rules recursively.
     *)
    val complementary : schema -> schema

    (** Negation of a literal. *)
    val complementary_lit : literal -> literal

    (** Opposite polarity (similar to {!Polarity.S.opposite}). *)
    val complementary_pol : polarity -> polarity

    (** Output to string and XML. *)
    (** Note: the output depends on the wanted encoding for strings, hence the functor. *)
    module Output : functor (S : String.S) ->
      sig
        val schema_to_string : schema -> S.t
        val prop_to_string : prop_var -> S.t
        val lit_to_string : literal -> S.t
        val it_to_string : iteration -> S.t
        val cstr_to_string : cstr -> S.t
        val left_sequent_to_string : left_sequent -> S.t
        val schema_to_xml : schema -> XML(S).t
        val proof_to_xml : proof -> XML(S).t
      end
  end

(**/**)
module Contents =
  struct
    exception More_than_one_free_variable of string * string

    let rec free_variable_of = function
      |Top | Bot -> None
      |Lit l -> variable_of_lit l
      |It it -> Some (free_variable_of_it it)
      |Op(_,s1,s2) ->
          match free_variable_of s1, free_variable_of s2 with
          |None,x | x,None -> x
          |Some v1 as x, Some v2 when v1 = v2 -> x
          |Some v1, Some v2 -> raise (More_than_one_free_variable(v1,v2))

    (** Free variable of an iteration, i.e. the variable that appears in the upper bound. *)
    and free_variable_of_it (_,_,_,u,_) = variable_of_upper_bound u

    (** Variable in the upper bound of an iteration. *)
    and variable_of_upper_bound = Tuple2.get1

    (** Variable in the index of a literal. *)
    and variable_of_lit (_,_,t) = variable_of_indexes t

    (** Variable in an index. *)
    and variable_of_indexes = function Int _ -> None | Sum(v,_) -> Some v

    let rec first_bound_variable_of = function
      |Top | Bot | Lit _ -> None
      |It(_,i,_,_,_) -> Some i
      |Op(_,s1,s2) ->
          match first_bound_variable_of s1 with
          |Some _ as x -> x
          |None -> first_bound_variable_of s2

    exception Different_lower_bounds of int * int
    exception Different_upper_bounds of (string * int) * (string * int)

    let rec bounds_of = function
      |Top | Bot | Lit _ -> None
      |It(_,_,l,u,_) -> Some(l,u)
      |Op(_,s1,s2) ->
          match bounds_of s1, bounds_of s2 with
          |None,x | x,None -> x
          |Some(l1,_), Some(l2,_) when l1 <> l2 -> raise (Different_lower_bounds(l1,l2))
          |Some(_,(v1,n1)), Some(_,(v2,n2)) when n1 <> n2 -> raise (Different_upper_bounds((v1,n1),(v2,n2)))
          |Some _ as x, Some _ -> x

    let rec complementary = function
      |Top -> Bot
      |Bot -> Top
      |Lit l -> Lit(complementary_lit l)
      |It(op,v,l,u,s) -> It(complementary_big_op op,v,l,u,complementary s)
      |Op(op,s1,s2) -> 
          let op', s1', s2' =
            match op with
            |Or -> And, complementary s1, complementary s2
            |And -> Or, complementary s1, complementary s2
            |Xor -> Equiv, s1, s2
            |Equiv -> Xor, s1, s2
            |Imply -> And, s1, complementary s2
          in
          Op(op',s1',s2')
    and complementary_lit (pol,p,t) = complementary_pol pol, p, t
    and complementary_pol = function Neg -> Pos | Pos -> Neg
    and complementary_big_op = function Big_and -> Big_or | Big_or -> Big_and

    module Output (S : String.S) =
      struct
        open S
        let (!) = S.of_string
        let rec schema_to_string s = schema_to_string' ~parent:ident s
        and schema_to_string' ~parent =
          let connective_case op s1 s2 = 
            schema_to_string' ~parent:S.parenthesize s1 ^ S.space ^ connective_to_string op ^ S.space ^ schema_to_string' ~parent:S.parenthesize s2 
          in
          (function
          |Top -> S.top
          |Bot -> S.bot
          |Lit l -> lit_to_string l
          |It it -> it_to_string it
          |Op(And,s1,s2) -> connective_case And s1 s2
          |Op(op,s1,s2) -> parent (connective_case op s1 s2))
        and connective_to_string = function And -> S.wedge | Or -> S.vee | Xor -> S.oplus | Equiv -> S.equiv | Imply -> S.imply
        and lit_to_string (pol,p,t) = polarity_to_string pol ^ prop_to_string p ^ !"_" ^ indexes_to_string t
        and prop_to_string = (!)
        and polarity_to_string = function Pos -> S.empty | Neg -> S.neg
        and indexes_to_string = function Int n -> S.of_int n | Sum(v,n) -> S.of_expr v n
        and it_to_string (con,v,l,u,b) =
          big_connective_to_string con ^ !v ^ !"=" ^ lower_to_string l ^ S.dots ^ upper_to_string u ^ !" [" ^ schema_to_string b ^ !"]"
        and lower_to_string = S.of_int
        and upper_to_string (v,n) = S.of_expr v n
        and big_connective_to_string = function Big_and -> S.big_wedge | Big_or -> S.big_vee

        let rec left_sequent_to_string (schs,cstr) =
          let cstr_string = cstr_to_string cstr in
          let cstr_strings = if S.is_empty cstr_string then [] else [ cstr_string ] in
          let strings = List.map schs ~f:schema_to_string @ cstr_strings in
          S.concat strings ^ S.space ^ S.vdash
        and cstr_to_string = function
          |True -> S.empty
          |False -> S.bot
          |Atom(v,ineq,n) -> !v ^ ineq_to_string ineq ^ S.of_int n
          |Between(n1,v,n2) -> S.of_int n1 ^ S.leq ^ !v ^ S.leq ^ S.of_int n2
        and ineq_to_string = function Le -> S.leq | Lt -> S.lt | Eq -> S.eq | Gt -> S.gt | Ge -> S.geq

        module X = XML(S)
        let (!) = X.(!)
        let (!!) = X.(!!)
        let (!^) = S.of_string

        let rec schema_to_xml x = !"schema" [ skeleton_to_xml x ]
        and skeleton_to_xml = function
          |Top -> !"true" []
          |Bot -> !"false" []
          |Lit l -> lit_to_xml l
          |It it -> it_to_xml it
          |Op(op,s1,s2) -> !(connective_to_xml op) [ skeleton_to_xml s1; skeleton_to_xml s2 ]

        and lit_to_xml (pol,p,t) = 
          let tag = match pol with Pos -> "pos_atom" | Neg -> "neg_atom" in
          !tag [ prop_to_xml p; indexes_to_xml t ]
        and prop_to_xml x = !!"prop_var" (prop_to_string x)
        and indexes_to_xml idx = !"index" [ match idx with Int n -> num_to_xml n | Sum(var,n) -> sum_to_xml ~var n ]
        and sum_to_xml ~var n = !"plus" [ var_to_xml var; num_to_xml n ]
        and num_to_xml n = !!"num" (S.of_int n)
        and var_to_xml v = !!"var" !^v
        and it_to_xml (con,v,l,u,b) = !(big_connective_to_xml con) [ var_to_xml v; lower_to_xml l; upper_to_xml u; skeleton_to_xml b; ]
        and lower_to_xml x = !!"from" (S.of_int x)
        and upper_to_xml (var,n) = !"to" [ sum_to_xml ~var n ]
        and connective_to_xml = function And -> "and" | Or -> "or" | Xor -> "xor" | Equiv -> "equiv" | Imply -> "imply"
        and big_connective_to_xml = function Big_and -> "itand" | Big_or -> "itor"

        let (!~) = S.of_string
        let rec proof_to_xml ps = !"prooftrees" (List.map ps ~f:(fun (symbol,p) -> partial_proof_to_xml ~symbol p))
        and partial_proof_to_xml ~symbol:s (seq,rule) =
          X.node ~tag:!~"proof" ~attrs:([ !~"symbol", symbol_to_xml s; !~"calculus", !~"RegSTAB" ]) [ rule_to_xml ~sequent:seq rule ]
        and rule_to_xml ~sequent rule =
          let rule_node ~typ nodes = X.node ~tag:!~"rule" ~attrs:[ !~"type", !~typ ] (left_sequent_to_xml sequent :: nodes) in
          match rule with
          |Axiom -> rule_node ~typ:"ax" [ ]
          |Link symbol -> rule_node ~typ:"lnk" [ X.node ~tag:!~"prooflink" ~attrs:[ !~"symbol", symbol_to_xml symbol ] [ ] ]
          |Unary(t,(sequent,rule)) -> rule_node ~typ:(unary_rule_type_to_xml t) [ rule_to_xml ~sequent rule ]
          |Binary(t,(s1,r1),(s2,r2)) -> rule_node ~typ:(binary_rule_type_to_xml t) [ rule_to_xml ~sequent:s1 r1; rule_to_xml ~sequent:s2 r2; ]
        and unary_rule_type_to_xml = Rule.(function And -> "and" | Purity -> "pur" | Top -> "top")
        and binary_rule_type_to_xml = Rule.(function Or -> "or" | Equiv -> "equ" | Imply -> "imp" | Unfold -> "unf" | Xor -> "xor")
        and left_sequent_to_xml (schs,cstr) =
          (* TEMPORARY *)
          (*!"left_sequent" [ !"schemalist" (List.map schs ~f:schema_to_xml @ match cstr with True -> [] | _ -> [ cstr_to_xml cstr ]) ]*)
          !!"conclusion" (left_sequent_to_string (schs,cstr))
        and cstr_to_xml = function
          |True -> assert false
          |False -> !!"false" S.empty
          |Atom(v,ineq,n) -> !(ineq_to_xml ineq) [ var_to_xml v; num_to_xml n ]
          |Between(n1,v,n2) -> !"between" [ num_to_xml n1; var_to_xml v; num_to_xml n2 ]
        and symbol_to_xml n = S.(phi ^ of_int n)
        and ineq_to_xml = function Le -> "leq" | Lt -> "lt" | Eq -> "eq" | Gt -> "gt" | Ge -> "geq"
        and num_to_xml n = !!"num" (S.of_int n)
      end
    let default_bounds ~param = 1, param
  end

include (Contents:S)
