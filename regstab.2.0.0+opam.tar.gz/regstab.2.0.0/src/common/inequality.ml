(** Datatype and operations dealing with inequality operators. *)
open Softcore

(** Signature of the module. *)
module type S =
  sig
    (** Type of inequality operators. Three possible values: Lower or Equal, Greater Than, or Equal *)
    type t = Le | Gt | Eq

    (** {6 Comparisons} *)

    val equal : t -> t -> bool

    (** {6 Useful functions} *)

    (** Le -> Gt, Gt -> Le, Eq -> Eq.
     * Useful to reverse an inequality.
     *)
    val reverse_sgn : t -> t

    (** Le, Gt -> pred, Eq -> ident.
     * Useful to reverse an inequality.
     *)
    val reverse_int : t -> (int -> int)

    (** Turns an operator into the corresponding Ocaml function. *)
    val to_fun : t -> (int -> int -> bool)

    (** {6 Conversions from/to human constraints} *)

    val to_human : t -> Human.inequality

    (** @raise Lt_not_translatable or Ge_not_translatable in case the inequality is [Human.Lt] or [Human.Ge] *)
    val of_human : Human.inequality -> t

    exception Lt_not_translatable
    exception Ge_not_translatable
  end

(**/**)
module Exposed =
  struct
    type t = Le | Gt | Eq
    let to_human = function Le -> Human.Le | Gt -> Human.Gt | Eq -> Human.Eq
    exception Lt_not_translatable
    exception Ge_not_translatable
    let of_human =
      function Human.Le -> Le | Human.Gt -> Gt | Human.Eq -> Eq | Human.Lt -> raise Lt_not_translatable | Human.Ge -> raise Ge_not_translatable
    let reverse_sgn    = function Le -> Gt | Gt -> Le | Eq -> Eq
    let reverse_int    = function (Le | Gt) -> pred | Eq -> ident
    let to_fun ineq (x:int) (y:int) = match ineq with Le -> x <= y | Gt -> x > y | Eq -> x = y 
    let equal ineq1 ineq2 =
      match ineq1,ineq2 with
      |Le,Le | Gt,Gt | Eq,Eq -> true
      |_ -> false
  end

include (Exposed : S)
