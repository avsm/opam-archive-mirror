(** Substitute to the Ocaml standard library.
 *
 * This file was originally a substitute to the Jane Street Core library
 * (<http://ocaml.janestreet.com/?q=node/13>) used in earlier versions of RegSTAB.
 * A few pieces of code were even copy-pasted from Core.
 * Now, however this file does not have much to do with Core anymore.
 *
 * We don't document every function and module in this file since they are all short and/or self explanatory and/or frequent in ocaml programs.
 *)

(** Identity *)
external ident : 'a -> 'a = "%identity"

(** Composition *)
let (<||) f g = fun x -> f (g x)

(** Applies (impure) function [f] to res, and return res. *)
let with_effect res ~f = f res; res

module String = ExtString

module Tuple2 =
  struct
    type ('a,'b) t = 'a * 'b
    let get1 (x,_) = x
    let get2 (_,y) = y
    let equal ~eq1 ~eq2 (x1,x2) (y1,y2) = eq1 x1 y1 && eq2 x2 y2
    let compare ~cmp1 ~cmp2 (x1,x2) (y1,y2) = 
      let res1 = cmp1 x1 y1 in
      if res1 <> 0 then res1 else cmp2 x2 y2
  end

module Tuple3 =
  struct
    type ('a,'b,'c) t = 'a * 'b * 'c
    let get1 (x,_,_) = x
    let get2 (_,y,_) = y
    let get3 (_,_,z) = z
    let equal ~eq1 ~eq2 ~eq3 (x1,x2,x3) (y1,y2,y3) = eq1 x1 y1 && eq2 x2 y2 && eq3 x3 y3
    let compare ~cmp1 ~cmp2 ~cmp3 (x1,x2,x3) (y1,y2,y3) = 
      let res1 = cmp1 x1 y1 in
      if res1 <> 0 then res1 else 
        let res2 = cmp2 x2 y2 in
        if res2 <> 0 then res2 else cmp3 x3 y3
  end

module Array = StdLabels.Array

module List =
  struct
    module L = StdLabels.List
    include L
    let of_pair (x,y) = [x;y]
    let fold t ~init ~f = fold_left t ~f ~init
    let map l ~f = L.rev (L.rev_map ~f l)
    let dedup ?(cmp = compare) ?(eq = (=)) l =
      let sorted = L.sort ~cmp l in
      let rec loop l acc = match l with
        |[]           -> acc
        |hd::[]       -> loop [] (hd::acc)
        |hd1::hd2::tl -> if eq hd1 hd2 then loop (hd2::tl) acc else loop (hd2::tl) (hd1::acc)
      in
      loop sorted []
    let range ?(stride=1) low high =
      if stride <= 0 then invalid_arg "Softcore.List.range: stride must be positive";
      let rec loop low high accum = if low >= high then accum else loop (low + stride) high (low::accum) in
      L.rev (loop low high [])
    let reduce l ~f = match l with
      |[]       -> raise (Invalid_argument "List.reduce")
      |init::l' -> L.fold_left ~init ~f l'
    let append l1 l2 = L.rev_append (L.rev l1) l2
    let rev_filter_map l ~f =
      let rec loop l acc = match l with
        |[]     -> acc
        |hd::tl -> loop tl (match f hd with Some x -> x::acc | None -> acc)
      in
      loop l []
    let filter_map l ~f = List.rev (rev_filter_map l ~f)
    let fold_right l ~f ~init = fold_left ~f:(fun a b -> f b a) ~init (List.rev l)
    let to_string ~to_string ?delim:(delim1,delim2=("[","]")) ?(sep=" ; ") xs = 
      let rec list_to_string' = function
        |[] -> ""
        |[x] -> to_string x
        |x::xs -> (to_string x) ^ sep ^ (list_to_string' xs)
      in
      delim1 ^ (list_to_string' xs) ^ delim2
    let equal ~eq xs ys = try List.for_all2 eq xs ys with _ -> false
    let opt_map ~f = fold ~f:(fun acc x -> match f x with None -> acc | Some y -> y::acc) ~init:[]
  end

module Option =
  struct
    let value ~default = function None -> default | Some x -> x
    let raise_if_none ~exc = function None -> raise exc | Some x -> x
    let is_some = function Some _ -> true  | _ -> false
    let is_none = function Some _ -> false | _ -> true
    let map ~f t = match t with None -> None | Some x -> Some (f x)
    let map_value ~default ~f = function None -> default | Some x -> f x
    let equal ~eq t1 t2 =
      match t1,t2 with
      |None,None -> true
      |Some _,None |None,Some _ -> false
      |Some x1,Some x2 -> eq x1 x2
    let total_compare ~cmp t1 t2 =
      match t1,t2 with
      |None,None -> 0
      |None,Some _ -> -1
      |Some _,None -> 1
      |Some x1,Some x2 -> cmp x1 x2
    let to_bool = function None -> false | Some _ -> true
    let iter ~f = function None -> () | Some x -> f x
    let to_list = function None -> [] | Some x -> [ x ]
  end

module Exn =
  struct
    type t = exn
    exception Finally of t * t
    let protectx ~f x ~(finally : 'a -> unit) =
      let res =
        try f x
        with exn ->
          (try finally x with final_exn -> raise (Finally (exn, final_exn)));
          raise exn
      in
      finally x;
      res
  end

let read_wrap ?(binary = false) ~f fname =
  let ic =
    if binary then
      open_in_bin fname
    else
      open_in fname
  in
  Exn.protectx ic ~f ~finally:close_in

module Map =
  struct
    type ('key,'a) t = Empty | Node of ('key,'a) t * 'key * 'a * ('key,'a) t * int

    let height = function Empty -> 0 | Node(_,_,_,_,h) -> h

    let create l x d r =
      let hl = height l and hr = height r in
      Node(l, x, d, r, (if hl >= hr then hl + 1 else hr + 1))

    let singleton key data = create Empty key data Empty

    let bal l x d r =
      let hl = match l with Empty -> 0 | Node(_,_,_,_,h) -> h in
      let hr = match r with Empty -> 0 | Node(_,_,_,_,h) -> h in
      if hl > hr + 2 then begin
        match l with
        |Empty               -> invalid_arg "Map.bal"
        |Node(ll,lv,ld,lr,_) -> 
            if height ll >= height lr then create ll lv ld (create lr x d r)
            else begin match lr with
              |Empty                   -> invalid_arg "Map.bal"
              |Node(lrl,lrv,lrd,lrr,_) -> create (create ll lv ld lrl) lrv lrd (create lrr x d r)
            end
      end else if hr > hl + 2 then begin
        match r with
        |Empty -> invalid_arg "Map.bal"
        |Node(rl, rv, rd, rr, _) ->
            if height rr >= height rl then create (create l x d rl) rv rd rr
            else begin match rl with
              |Empty                       -> invalid_arg "Map.bal"
              |Node(rll, rlv, rld, rlr, _) -> create (create l x d rll) rlv rld (create rlr rv rd rr)
            end
      end else Node(l, x, d, r, (if hl >= hr then hl + 1 else hr + 1))

    let empty = Empty

    let is_empty = function Empty -> true | _ -> false

    let rec add ~key:x ~data = function
      |Empty           -> Node(Empty, x, data, Empty, 1)
      |Node(l,v,d,r,h) -> 
          let c = Pervasives.compare x v in
          if c = 0 then Node(l, x, data, r, h)
          else if c < 0 then bal (add ~key:x ~data l) v d r
          else bal l v d (add ~key:x ~data r)

    let rec find t x =
      match t with
      |Empty           -> None
      |Node(l,v,d,r,_) -> 
          let c = Pervasives.compare x v in
          if c = 0 then Some d
          else find (if c < 0 then l else r) x

    let rec find_exn t x = match find t x with None -> raise Not_found | Some data -> data

    let find_with_default ~default t x =
      match find t x with
      |None -> default
      |Some x -> x

    let rec mem t x =
      match t with
      |Empty           -> false
      |Node(l,v,_,r,_) -> 
          let c = Pervasives.compare x v in
          c = 0 || mem (if c < 0 then l else r) x

    let rec min_elt = function
      |Empty                -> None
      |Node (Empty,k,d,_,_) -> Some (k, d)
      |Node (l,_,_,_,_)     -> min_elt l

    let rec min_elt_exn t = match min_elt t with None -> raise Not_found | Some v -> v

    let rec cardinal = function Empty -> 0 | Node (l, _, _, r, _) -> cardinal l + cardinal r + 1

    let rec rev_fold ~f t ~init:accu = match t with
      |Empty               -> accu
      |Node(l, v, d, r, _) -> rev_fold ~f l ~init:(f ~key:v ~data:d (rev_fold ~f r ~init:accu))

    let keys t = rev_fold ~f:(fun ~key ~data:_ list -> key::list) t ~init:[]

    let rec min_binding = function
        Empty -> raise Not_found
      | Node(Empty, x, d, _, _) -> x, d
      | Node(l, _, _, _, _) -> min_binding l

    let rec remove_min_binding t =
      match t with
        Empty -> invalid_arg "Map.remove_min_elt"
      | Node(Empty, _, _, r, _) -> r
      | Node(l, x, d, r, _) -> bal (remove_min_binding l) x d r

    let merge t1 t2 =
      match (t1, t2) with
        (Empty, t) -> t
      | (t, Empty) -> t
      | (_, _) ->
          let (x, d) = min_binding t2 in
          bal t1 x d (remove_min_binding t2)

    let rec remove t x =
      match t with
      | Empty ->
          Empty
      | Node(l, v, d, r, _) ->
          let c = Pervasives.compare x v in
          if c = 0 then
            merge l r
          else if c < 0 then
            bal (remove l x) v d r
          else
            bal l v d (remove r x)

    let merge ~f t1 t2 =
      let all_keys = List.dedup (List.append (keys t1) (keys t2)) in
      List.fold_left ~init:empty all_keys
        ~f:(fun t key ->
              match f ~key (find t1 key) (find t2 key) with
              |None      -> t
              |Some data -> add ~key ~data t)
  end

module Set =
  struct
    type 'a t = ('a,unit) Map.t
    let empty = Map.empty
    let add t x = Map.add t ~key:x ~data:()
    let min_elt_exn t = let (x,_) = Map.min_elt_exn t in x
    let min_elt t = try Some (min_elt_exn t) with Not_found -> None
    let choose = min_elt
    let choose_exn = min_elt_exn
    let elements = Map.keys
    let cardinal = Map.cardinal
    let union t1 t2 = Map.merge t1 t2 ~f:(fun ~key data1 data2 -> match data1,data2 with Some(),_ | _,Some() -> Some () | _ -> None)
    let singleton x = Map.singleton x ()
  end

module Hashtbl =
  struct
    module H = MoreLabels.Hashtbl
    include H
    let find_exn t key = H.find t key
    let find t key = try let res = H.find t key in Some res with Not_found -> None
  end

(** A module to represent and output XML files. *)
module XML (S : String.S) : 
  sig
    type t 
    type attr = S.t * S.t
    type tag = S.t
    val leaf : S.t -> t
    val node : tag:S.t -> ?attrs:(S.t * S.t) list -> t list -> t
    val output : human:bool -> ch:out_channel -> doctype:S.t -> t -> unit
    (* helpers *)
    val (!) : string -> t list -> t
    val (!!) : string -> S.t -> t
  end
  =
  struct
    open S
    type attr = S.t * S.t
    type tag = S.t
    type t = Literal of S.t | Node of tag * attr list * t list
    let (!) = S.of_string
    let leaf s = Literal s
    let node ~tag ?(attrs=[]) kids = Node(tag,attrs,kids)

    let to_xmlm = function
      |Literal s -> `Data (S.to_string s)
      |Node(tag,attrs,kids) -> `El((("",S.to_string tag), List.map attrs ~f:(fun (attr,value) -> ("",S.to_string attr),S.to_string value)), kids)

    let output ~human ~ch ~doctype x =
      let dtd = !"<!DOCTYPE " ^ doctype ^ !" SYSTEM \"" ^ doctype ^ !".dtd\">" in
      if human
      then Xmlm.output_doc_tree to_xmlm (Xmlm.make_output ~indent:(Some 1) (`Channel ch)) (Some (S.to_string dtd), x)
      else Xmlm.output_doc_tree to_xmlm (Xmlm.make_output (`Channel ch)) (Some (S.to_string dtd), x)

    let (!) tag = node ~tag:(S.of_string tag) ~attrs:[]
    let (!!) tag v = node ~tag:(S.of_string tag) [ leaf v ]
  end

(** Original modules from the Standard Library *)
module Caml =
  struct
    module Map = Map
    module Set = Set
    module MoreLabels = MoreLabels
    module StdLabels = StdLabels
  end

