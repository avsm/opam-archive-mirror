(** A substitute for the standard {!String} module.
 * Provides both an ASCII and a UTF8 implementation, both having the same signatures but (on purpose) incompatible types.
 * If useful, a module LaTeX could easily be added.
 *)

(**/**)
external ident : 'a -> 'a = "%identity"
(**/**)

(** A signature containing several special characters.
 * This will be integrated in the main signature {!S}.
 * Since this signature has both an {!ASCII} and a {!UTF8} implementation,
 * this allows to use some characters without caring about the actual character in use.
 *)
module type CHAR =
  sig
    (** The names should be self-explanatory. Most of them come from their LaTeX counterparts. *)

    type t
    val wedge : t
    val vee : t
    val oplus : t
    val big_wedge : t
    val big_vee : t
    val equiv : t
    val imply : t
    val dots : t
    val top : t
    val bot : t
    val leq : t
    val geq : t
    val eq : t
    val neq : t
    val lt : t
    val gt : t
    val empty : t
    val space : t
    val eol : t
    val neg : t
    val vdash : t
    val to_ : t
    val phi : t
  end

(** Main signature. *)
module type S =
  sig 
    (** Type of string. *)
    type t

    (** {6 Constructors} *)

    (** From a standard string. *)
    val of_string : string -> t

    (** From an integer. *)
    val of_int : int -> t

    (** From a string [v] and an integer [k], generates the string "v+k" if [k]>0, "v" if [k]=0, and "v-k" if [k]<0 *)
    val of_expr : string -> int -> t

    (** Concatenation of strings, with an optional separator. *)
    val concat : ?sep:t -> t list -> t

    (** Concatenation with mapping (just a convenient helper function). *)
    val concat_map : ?sep:t -> f:('a -> t) -> 'a list -> t

    (** Concatenation of two strings. *)
    val (^) : t -> t -> t

    (** Take a string and surround it with parentheses. *)
    val parenthesize : t -> t

    (** Put every character in lower case. *)
    val lowercase : t -> t

    (** {6 Selectors} *)

    (** Conversion to standard string. *)
    val to_string : t -> string

    (** Is a string equal to the empty string. *)
    val is_empty : t -> bool

    (** Length of a string. *)
    val length : t -> int

    (** For a string [s], returns \[[s1;s2;...;sk]\] s.t. [s] = [s1 ^ on ^ s2 ^ on ^ ... ^ on ^ sk]
     * (approximately, since [on] is actually of type [char]).
     *)
    val split : t -> on:char -> t list

    (** {6 Output.} *)

    (** Print a string and start a new line. *)
    val print_endline : t -> unit

    (** Print a string, insert a blank line, and start a new line. *)
    val print_double_endlines : t -> unit

    (** Output to a given channel. *)
    val output : ch:out_channel -> t -> unit

    (** Special characters (named module). *)
    module Char : CHAR with type t := t

    (** Special characters (included module). *)
    include CHAR with type t := t

    (** Some functions providing the equivalent functionality as the standard [Str] module. *)
    module Str :
      sig
        val regexp : t -> Str.regexp
        val global_replace : Str.regexp -> t -> t -> t
      end
  end

(**/**)
module Common =
  struct
    include StringLabels
    let is_empty s = s = ""
    let output ~ch = Pervasives.output_string ch
    let concat ?(sep=", ") = concat ~sep
    let concat_map ?sep ~f xs = concat ?sep (ListLabels.map ~f xs)
    let (^) = (^)
    let of_string = ident
    let to_string = ident
    let of_int = string_of_int
    let length = length
    let of_expr v = function
      |0 -> v
      |n when n<0 -> Printf.sprintf "%s-%d" v (abs n)
      |n  -> Printf.sprintf "%s+%d" v n
    let parenthesize x = "(" ^ x ^ ")"
    let print_endline = print_endline
    let print_double_endlines s = print_endline (s ^ "\n")
    let split str ~on =
      let len = length str in
      let rec loop acc last_pos pos =
        if pos = -1 then
          sub str ~pos:0 ~len:last_pos :: acc
        else
          if str.[pos] = on then
            let pos1 = pos + 1 in
            let sub_str = sub str ~pos:pos1 ~len:(last_pos - pos1) in
            loop (sub_str :: acc) pos (pos - 1)
          else loop acc last_pos (pos - 1)
      in
      loop [] len (len - 1)

    module Str =
      struct
        let regexp = Str.regexp
        let global_replace = Str.global_replace
      end
  end

module Common_Char =
  struct
    let big_vee = "\\/"
    let big_wedge = "/\\"
    let space = " "
    let eol = "\n"
    let lt = "<"
    let gt = ">"
    let eq = "="
    let empty = ""
  end
(**/**)

(** Implementation of {!S} for ASCII strings. *)
module ASCII : S with type t = string =
  struct
    (** See {!S}. *)
    (**/**)
    include Common
    module Char =
      struct
        include Common_Char
        let wedge = "/\\"
        let neg = "~"
        let vee = "\\/"
        let oplus = "(+)"
        let imply = "->"
        let equiv = "<->"
        let dots = ".."
        let top = "True"
        let bot = "False"
        let leq = "<="
        let geq = ">="
        let neq = "<>"
        let vdash = "|-"
        let to_ = "->"
        let phi = "Phi"
      end
    include Char
  end

(** Implementation of {!S} for UTF8 strings. *)
module UTF8 : S =
  struct
    (** See {!S}. *)
    (**/**)
    include Common
    module Char =
      struct
        include Common_Char
        let neg = "¬"
        let wedge = "∧"
        let vee = "∨"
        let oplus = "⊕"
        let imply = "⇒"
        let equiv = "⇔"
        let dots = "…"
        let top = "⊤"
        let bot = "⊥"
        let leq = "≤"
        let geq = "≥"
        let neq = "≠"
        let vdash = "⊢"
        let to_ = "→"
        let phi = "φ"
      end
    include Char
  end
