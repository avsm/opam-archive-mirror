(** Datatype and operations dealing with (a simple restriction of) linear arithmetic constraints. *)
open Softcore

module I = Inequality

(** Signature of the module. *)
module type S =
  sig
    (** Type of constraints.
     * Constraints can have the following forms: true, false, n1 <= x <= n2, x ∙ n where ∙ ∈ \{≤,<,=,>,≥\}
     * (x denotes a variable, n, n1, n2 are integers).
     * *)
    type t

    (** {6 Comparisons} *)

    val equal : t -> t -> bool

    (** {6 Constructors} *)

    (** The always-true constraint. *)
    val top : t

    (** The always-false constraint. *)
    val bot : t

    (** An atomic constraint: inequality between two index expressions *)
    val constraint_atom : Indexes.t -> Inequality.t -> Indexes.t -> t

    (** Conjunction of two bounds. *)
    val bounds_conjunction : t -> t -> t

    (** An inequality between two index expressions intended to be the lower and upper bound of an iteration. *)
    val bounds_constraint  : lower:int -> upper_shift:int -> Inequality.t -> t

    (** {6 Destructors} *)
    
    val is_true : t -> bool
    val is_false : t -> bool

    (** True if the constraint is of the form "x=n", in which case returns x. *)
    val is_equality : t -> [ `Yes of int | `No ]

    (** True if the constraint is of the form "x<=n". *)
    val is_lower : t -> bool

    (** Is the constraint acceptable as a user-input constraint?
     * If the schema which is input by the user contains iterations
     * then the corresponding bounds shall be provided to the function via the [with_bounds] argument.
     * - If there are no bounds:
     *   * Accepted: true, false, x=n, x>=n
     *   * Rejected: x<=n, n1<=x<=n2
     * - If there are bounds (a,n+b):  
     *   * Accepted: true, false, x=n, x>=m where m >= a-b-2
     *   * Rejected: x<=n, n1<=x<=n2, x>=m where m < a-b-2
     *)
    val is_acceptable_as_input : with_bounds: (int * Indexes.t) option -> t -> bool

    (** Is a constraint always true or always false? *)
    val is_trivial : t -> bool

    (** How trivial is a constraint?
     * - [`VeryTrivial] means always true or false
     * - [`Trivial n] means the constraint has the form x=n
     * - [`NonTrivial] means everything else
     *)
    val how_much_trivial : t -> [ `VeryTrivial | `Trivial of int | `NonTrivial ]

    (** {6 Entailment relations} *)

    (** Is an index expression always greater than another under the hypothesis [hyp]?
     * For instance:
     * - x+1 is always greater than x
     * - x is always greater than 0 under the hypothesis x>1
     *)
    val always_greater_than : ?hyp:t -> Indexes.t -> Indexes.t -> bool

    (** Is an index expression always lower than another under the hypothesis [hyp]?
     * For instance:
     * - x is always lower than x+1
     * - x is always lower than 1 under the hypothesis x<0
     *)
    val always_lower_than : ?hyp:t -> Indexes.t -> Indexes.t -> bool

    (** Is an index expression always greater or equal to another under the hypothesis [hyp]?
     * For instance:
     * - x+1 is always greater or equal to x
     * - x is always greater or equal to x
     * - x is always greater or equal to 0 under the hypothesis x>1
     *)
    val always_greater_or_equal : ?hyp:t -> Indexes.t -> Indexes.t -> bool

    (** Is an index expression always different than another under the hypothesis [hyp]?
     * For instance:
     * - x is always different from x+1
     * - 0 is always different 1
     * - x is always different from 2 under the hypothesis x<1
     *)
    val always_different : ?hyp:t -> Indexes.t -> Indexes.t -> bool

    (** Does a given constraint entails another one?
     * For instance:
     * - x>1 entails x>0
     * - 1<2 entails 1<3
     *)
    val entails : t -> t -> bool

    (** {6 Useful functions} *)

    (** Turns x∙n into x+by∙n (actually into x∙n-by) and n1<=x<=n2 into n1<=x+by<=n2.
     * [by] defaults to 1.
     *)
    val shift : ?by:int -> t -> t

    (** {6 Conversions from/to human constraints} *)

    val to_human : var:string option -> t -> Human.cstr
    val of_human : Human.cstr -> t

    (** {6 Output to XML} *)
    (** Note: the output depends on the wanted encoding for strings, hence the functor. *)
    module Output : functor (S : String.S) -> sig val to_xml : t -> XML(S).t end
  end

(**/**)
module Exposed =
  struct
    type t =
      |True
      |False
      |Atom of Inequality.t * int (* intended as "variable (inequality) int", but the variable is not stored *)
      |Between of int * int (* intended as "variable is between int1 and int2" *)

    let to_human ~var = 
      let get_var var = Option.raise_if_none var ~exc:(Invalid_argument "to_human") in
      function
      |True -> Human.True
      |False -> Human.False
      |Atom(Inequality.Gt,n) -> Human.(Atom(get_var var, Ge, n+1)) (* More readable *)
      |Atom(ineq,n) -> Human.Atom(get_var var, Inequality.to_human ineq, n)
      |Between(n1,n2) -> Human.Between(n1, get_var var, n2)

    let of_human = function
      |Human.True -> True
      |Human.False -> False
      |Human.Between(n1,_,n2) -> Between(n1,n2)
      |Human.Atom(_,ineq,n) -> 
          try Atom(Inequality.of_human ineq,n)
          with 
          |Inequality.Lt_not_translatable -> Atom(Inequality.of_human Human.Le,n-1)
          |Inequality.Ge_not_translatable -> Atom(Inequality.of_human Human.Gt,n-1)

    let equal c1 c2 =
      match c1,c2 with
      |True,True                     -> true
      |False,False                   -> true
      |Atom(ineq1,n1),Atom(ineq2,n2) -> n1 = n2 && Inequality.equal ineq1 ineq2
      |Between(n1,p1),Between(n2,p2) -> n1 = n2 && p1 = p2
      |_                                                 -> false

    (* Exceptions *)
    exception Non_normalized_constraint

    (* Selectors *)
    let of_bool = function true -> True | false -> False
    let is_true c = match c with True -> true | _ -> false
    let is_false c = match c with False -> true | _ -> false
    let is_trivial c = match c with False | True -> true | _ -> false

    let normalized = function
      |Between(n1,n2) when n2 <= n1 -> raise Non_normalized_constraint
      |_ as c -> c

    let shift ?(by=1) = function
      |True -> True
      |False -> False
      |Atom(ineq,n) -> Atom(ineq,n-by)
      |Between(n1,n2) -> Between(n1-by,n2-by)

    let is_equality c = match normalized c with Atom(I.Eq,n) -> `Yes n | _ -> `No

    let is_lower = function Atom(I.Le,_) -> true | _ -> false
    let how_much_trivial = function
      |True |False -> `VeryTrivial
      |_ as x ->
          match is_equality x with
          |`Yes n -> `Trivial n
          |_ -> `NonTrivial

    (* Constructors *)
    let top = True
    let bot = False

    (* Two possibilities to create a constraint, see developper doc.
     * Roughly: only one of two bounds can contain a variable.
     * If regular_bounds is true then we don't authorize each term to have a variable.
     *)
    let constraint_atom_internal ~regular_bounds t1 ineq t2 =
      match Indexes.contains_variable t1,Indexes.contains_variable t2 with
      |true,true -> of_bool (I.to_fun ineq (Indexes.get_shift t1) (Indexes.get_shift t2))
      |true,false -> Atom(ineq, (Indexes.get_shift t2)-(Indexes.get_shift t1))
      |false,true -> Atom(I.reverse_sgn ineq, I.reverse_int ineq ((Indexes.get_shift t1)-(Indexes.get_shift t2)))
      |false,false -> of_bool (I.to_fun ineq (Indexes.get_shift t1) (Indexes.get_shift t2))

    let constraint_atom = constraint_atom_internal ~regular_bounds:false
    let bounds_constraint ~lower ~upper_shift ineq =
      constraint_atom_internal ~regular_bounds:true (Indexes.of_int lower) ineq (Indexes.create ~var:true upper_shift)

    (* Combines two constraints.
     * As previously said we don't support general conjunction of constraints.
     * So constraints can be combined only if one is trivial or if both deal with the same variable in some "convenient" way.
     *)
    let bounds_conjunction c1 c2 =
      let open I in
      match normalized c1, normalized c2 with
      |True,c |c,True -> c
      |False,_ |_,False -> False
      |Atom(Eq,n),Atom(ineq,n') when not (to_fun ineq n n') -> False
      |Atom(ineq,n'),Atom(Eq,n) when not (to_fun ineq n n') -> False
      |Atom(Eq,n),Atom(ineq,n') | Atom(ineq,n'),Atom(Eq,n) -> Atom(Eq,n)
      |Atom(Le,n),Atom(Le,n') -> Atom(Le,min n n')
      |Atom(Gt,n),Atom(Gt,n') -> Atom(Gt,max n n')
      |Atom(Le,n),Atom(Gt,n') when n<=n' -> False
      |Atom(Gt,n),Atom(Le,n') when n>=n' -> False
      |Atom(Le,n),Atom(Gt,n') when n=n'+1 -> Atom(Eq,n)
      |Atom(Gt,n),Atom(Le,n') when n'=n+1 -> Atom(Eq,n')
      |Atom(Gt,n),Atom(Le,n') -> Between(n+1,n')
      |Atom(Le,n),Atom(Gt,n') -> Between(n'+1,n)
      |Between(n1,n2),Atom(Le,n') -> Between(n1,min n2 n')
      |Between(n1,n2),Atom(Gt,n') -> Between(max n1 (n'+1),n2)
      |Atom(Le,n'),Between(n1,n2) -> Between(n1,min n2 n')
      |Atom(Gt,n'),Between(n1,n2) -> Between(max n1 (n'+1),n2)
      |Between(n1,n2),Atom(Eq,n') when n1 <= n' && n' <= n2 -> c2
      |Atom(Eq,n'),Between(n1,n2) when n1 <= n' && n' <= n2 -> c2
      |Atom(Eq,n'),Between(n1,n2) -> False
      |Between(n1,n2),Atom(Eq,n') -> False
      |Between(n1,n2),Between(m1,m2) when n2 < m1-1 && m2 < n1-1 -> False
      |Between(n1,n2),Between(m1,m2) -> Between(min n1 m1, max n2 m2)

    (* Consequence relation between those constraints. *)
    let entails hyp con =
      let open I in
      match normalized hyp, normalized con with
      |False,_ | _,True -> true
      |True,_ | _,False -> false
      |Atom(Eq,n),Atom(ineq,n')  -> to_fun ineq n n'
      |Atom(Le,n),Atom(Le,n')
      |Between(_,n),Atom(Le,n')  -> n <= n'
      |Atom(Gt,n),Atom(Gt,n')    -> n >= n'
      |Between(n,_),Atom(Gt,n')  -> n-1 >= n'
      |Atom(Eq,n),Between(n1,n2) -> n1 <= n && n <= n2
      |_ -> false

    let is_acceptable_as_input ~with_bounds = function
      |Atom(I.Eq,_) | True | False -> true
      |Atom(I.Le,_) | Between(_,_) -> false
      |Atom(I.Gt,n) ->
          match with_bounds with
          |None      -> true
          |Some(l,u) -> n >= l-(Indexes.get_shift u)-2

    (* Some predefined relations. Assume both terms contain the same variables. *)
    let always_greater_than     ?(hyp=True) t1 t2 = entails hyp (constraint_atom t1 I.Gt t2)
    let always_lower_than ?(hyp=True) t1 t2 = always_greater_than ~hyp t2 t1
    let always_greater_or_equal ?(hyp=True) t1 t2 = entails hyp (constraint_atom t2 I.Le t1)

    let always_different ?(hyp=True) t1 t2 =
      match constraint_atom t1 I.Eq t2 with
      |True -> false
      |False -> true
      |Atom(I.Eq,n) -> 
          (match normalized hyp with
          |True -> false
          |False -> true
          |Atom(I.Le,n') -> n'< n
          |Atom(I.Gt,n') -> n'>=n
          |Atom(I.Eq,n') -> n'<>n
          |Between(n1,n2) -> n < n1 || n >= n2)
      |_ -> failwith "Constraint.always_different: unexpected behaviour; please report."

    module Output (S : String.S) =
      struct
        module X = XML(S)
        let (!~) = S.of_string
        open X
        let to_xml = function
          |True -> X.leaf !~"top"
          |False -> X.leaf !~"bot"
          |Atom(I.Le,n) -> !!"leq" (S.of_int n)
          |Atom(I.Eq,n) -> !!"eq" (S.of_int n)
          |Atom(I.Gt,n) -> !!"geq" (S.of_int (n+1))
          |Between(n1,n2) -> !"between" [ !!"geq" (S.of_int n1); !!"leq" (S.of_int n2) ]
      end
  end

include (Exposed : S)
