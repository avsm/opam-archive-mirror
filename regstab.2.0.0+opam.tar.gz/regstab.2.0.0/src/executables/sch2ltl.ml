(** Translation of schemata to LTL.
 * Implementation of an algorithm described in the article
 * {i Linear Temporal Logic and Propositional Schemata, Back and Forth},
 * V. Aravantinos, R. Caferra, N. Peltier,
 * {i TIME 2011}
*)
open Schema open Softcore

(**/**)
type non_sequential_arg = Positive | Bounds | Integer_inside_iteration
type ('content,'arg) result = Result of 'content | No_result of 'arg

let are_integer_positive s =
  let rec aux' x =
    match Prop.destruct x with
    |`Lit l -> Indexes.get_shift (Literal.idx_of l) >= 0
    |`Op(_,s1,s2) -> aux' s1 && aux' s2
    |`Top | `Bot -> true
  in
  let rec aux s =
    match Flat.destruct s with
    |`It it -> aux' (Iteration.body_of it)
    |`Lit l -> Indexes.get_shift (Literal.idx_of l) >= 0
    |`Op(_,s1,s2) -> aux s1 && aux s2
    |`Top | `Bot -> true
  in
  aux (skeleton_of s)

let are_bounds_ok s =
  match bounds_of s with
    |None -> true 
    |Some b -> Bounds.lower_of b = 0 && Bounds.upper_shift_of b = -1

let no_int_inside_it s =
  let rec contains_variable x =
    match Prop.destruct x with
    |`Lit l -> Indexes.contains_variable (Literal.idx_of l) 
    |`Op(_,s1,s2) -> contains_variable s1 && contains_variable s2
    |`Top | `Bot -> true
  in
  let rec in_regular s =
    match Flat.destruct s with
    |`Lit _ |`Top | `Bot -> true
    |`Op(_,s1,s2) -> in_regular s1 && in_regular s2
    |`It it -> contains_variable (Iteration.body_of it)
  in
  in_regular (skeleton_of s)

let is_sequential s =
  if not (are_bounds_ok s) then No_result Bounds
  else if not (are_integer_positive s) then No_result Positive
  else if not (no_int_inside_it s) then No_result Integer_inside_iteration
  else Result ()

(* LTL syntax *)
let top = "True"
let bot = "False"
let insert op x y = "(" ^ x ^ " " ^ op ^ " " ^ y ^ ")"
let disj = insert "|"
let conj = insert "&"
let (&&) = conj
let imply = insert "=>"
let (=>) = imply
let equiv = insert "<=>"
let (<=>) = equiv
let until = insert "U"
let (-~>) = until

let prepend op x = op ^ " (" ^ x ^")"
let neg = prepend "~"
let (~~) = neg
let always = prepend "G"
let (!!) = always
let sometime = prepend "F"
let next = prepend "X"
let xor x y = equiv (neg x) y

(* Axioms for schemata in LTL *)
let lt_n = "ltn"
let eq_n = "eqn"
let axiom_lt_n = lt_n -~> !!(~~lt_n)
let axiom_eq_n = !!((lt_n && next ~~lt_n) <=> next eq_n) && (~~lt_n <=> eq_n)
let axioms = axiom_lt_n && axiom_eq_n

let rec nexts ~k prop =
  if k<0 then raise (Invalid_argument "nexts") else
  if k=0 then prop else next (nexts ~k:(k-1) prop)

let seq_to_ltl s =
  let module S = String.ASCII in
  let module H = Human.Output(S) in
  let prop = S.lowercase <|| H.prop_to_string <|| Proposition.to_human in
  let literal l = (if Polarity.is_pos (Literal.polarity_of l) then ident else neg) (prop (Literal.prop_of l)) in
  let connective con =
    match Connective.destruct con with
    | `And -> conj | `Or -> disj | `Xor -> xor | `Imply -> imply | `Equiv -> equiv
  in
  let nexts l = nexts ~k:(Indexes.get_shift (Literal.idx_of l)) (literal l) in
  let rec flat x =
    match Prop.destruct x with
    |`Top -> top
    |`Bot -> bot
    |`Lit l -> nexts l
    |`Op(op,s1,s2) -> (connective op) (flat s1) (flat s2)
  in
  let iteration it = 
    if Iteration.is_disjunction it 
    then sometime (lt_n && flat (Iteration.body_of it))
    else !!(lt_n => flat (Iteration.body_of it))
  in
  let rec regular s =
    match Flat.destruct s with
    |`Top -> top
    |`Bot -> bot
    |`Lit l when not (Indexes.contains_variable (Literal.idx_of l)) -> nexts l
    |`Lit l -> !!(eq_n => nexts l)
    |`Op(op,s1,s2) -> (connective op) (regular s1) (regular s2)
    |`It it -> iteration it
  in
  axioms && regular (skeleton_of s)

let to_ltl s =
  match is_sequential s with
  |Result ()            -> Result (seq_to_ltl s)
  |(No_result arg) as x -> x

(* The main function, called with the input channel and options *)
let main ch =
  if ch = stdin then print_endline "Taking input from stdin.";
  let lexbuf  = Lexing.from_channel ch in
  (try
    let (_,(sch,_,_,_)) = Parser.main Lexer.token lexbuf in
    match to_ltl sch with
    |Result f -> print_endline f
    |No_result arg -> (fun x -> failwith ("The input schema is not sequential: " ^ x ^ "."))
        (match arg with
        |Positive                 -> "it contains negative indices"
        |Bounds                   -> "the bounds of iterations differ from 0..n-1"
        |Integer_inside_iteration -> "an iteration contains a proposition with an integer index (the bound variable must appear in such a proposition)")
  with Failure s -> print_endline s);
  print_newline ();
  flush stdout

(* Handling of command-line options, calls main *)
let _ =
  let file = ref None in
  let options = Arg.align [] in
  let usage = "sch2ltl [file]  - computes the SAT-equivalent LTL formula of a sequential schema\n" in
  let call_main s = 
    match !file with
    |None   -> file := Some s
    |Some _ -> failwith "Too many arguments."
  in
  Arg.parse options call_main usage;
  match !file with None -> main stdin | Some f -> read_wrap ~f:main f

