(** Datatype and operations related to literals. *)
open Softcore

(** Signature of the module *)
module type S =
  sig
    (** Type of literals *)
    type t

    (** {6 Comparisons } *)

    val compare : t -> t -> int
    val equal   : t -> t -> bool

    (** {6 Destructors} *)

    val prop_of : t -> Proposition.t
    val idx_of  : t -> Indexes.t
    val polarity_of  : t -> Polarity.t

    (** {6 Useful operations} *)

    (** Computes the propositional formula corresponing to a given value of the parameter *)
    val compute : t -> n:int -> t

    (** Substitute the variable, if any, by a term *)
    val substitute_variable : t -> by:Indexes.t -> t

    (** Try to simplify a literal if the constraint allows it *)
    val simplify : cstr:Constraint.t -> t -> t

    (** Shifts the index by a certain amount *)
    val shift : ?by:int -> t -> t

    (** Computes the negation of a literal. *)
    val opposite : t -> t

    (** {6 Conversions from/to human iterations} *)

    val of_human : Human.literal -> t
    val to_human : var:string option -> t -> Human.literal

    (** {6 Output to XML} *)
    (** Note: the output depends on the wanted encoding for strings, hence the functor. *)
    module Output : functor (S : String.S) -> sig val to_xml : t -> XML(S).t end

    (** {6 "HalfMap", ie. map from pairs (polarity,proposition) (ie. we don't care about the index)} *)

    (** Artificial synonymous type for [t]. *)
    type lit = t

    module HalfMap :
      sig
        (** Keys for [HalfMap]s (a polarity and a proposition). *)
        module Key :
          sig
            (** Type of keys. *)
            type t

            (** Constructor. *)
            val of_lit : lit -> t

            (** Constructor. *)
            val opposite_of_lit : lit -> t

            (** Destructor. *)
            val to_literal : t -> idx:Indexes.t -> lit
          end

        (** Type of keys. *)
        type key = Key.t

        (** Type of half maps. *)
        type 'a t
        
        (** {6 Usual map functions} *)

        val empty : unit -> 'a t
        val add : key:key -> data:'a -> 'a t -> 'a t
        val find : key:key -> 'a t -> 'a
        val iter : f:(key:key -> data:'a -> unit) -> 'a t -> unit
        val map : f:('a -> 'b) -> 'a t -> 'b t
        val fold : f:(key:key -> data:'a -> 'b -> 'b) -> 'a t -> init:'b -> 'b
        val compare : cmp:('a -> 'a -> int) -> 'a t -> 'a t -> int
        val subset : eq:('a -> 'a -> bool) -> 'a t -> 'a t -> bool
      end
  end

(**/**)
module Exposed =
  struct
    type t = Polarity.t * Proposition.t * Indexes.t

    let to_human ~var (pol,p,t) = Polarity.to_human pol, Proposition.to_human p, Indexes.to_human ~var t
    let of_human (pol,p,e) = Polarity.of_human pol, Proposition.of_human p, Indexes.of_human e

    (* Selectors *)
    let polarity_of = Tuple3.get1
    let prop_of     = Tuple3.get2
    let idx_of      = Tuple3.get3
    let atom_of (_,p,i) = (p,i)

    (* Computes the opposite of a literal *)
    let opposite (pol,prop,idx) = (Polarity.opposite pol,prop,idx)

    (* Substitution of indexes *)
    let substitute_variable (sgn,p,t') ~by:t = (sgn,p,Indexes.substitute_variable t' ~by:t)
    let compute (sgn,p,t) ~n = (sgn,p,Indexes.create ~var:false (Indexes.compute t n))

    (* Comparisons *)
    let compare = Tuple3.compare ~cmp1:Polarity.compare ~cmp2:Proposition.compare ~cmp3:Indexes.total_compare
    let equal   = Tuple3.equal ~eq1:Polarity.equal ~eq2:Proposition.equal ~eq3:Indexes.equal

    let simplify ~cstr l = match Constraint.is_equality cstr with `Yes n -> compute ~n l | `No -> l

    let shift ?by (s,p,t) = (s,p,Indexes.shift ?by t)

    module Output (S : String.S) =
      struct
        module X = XML(S)
        module Pol = Polarity.Output(S)
        module P = Proposition.Output(S)
        module I = Indexes.Output(S)
        let to_xml (pol,p,t) = X.node ~tag:(Pol.to_xml pol) [ P.to_xml p; I.to_xml t; ]
      end

    type lit = t

    module Key =
      struct
        type t = Polarity.t * Proposition.t
        let compare = Tuple2.compare ~cmp1:Polarity.compare ~cmp2:Proposition.compare
        let of_lit lit = polarity_of lit, prop_of lit
        let opposite_of_lit lit = Polarity.opposite (polarity_of lit), prop_of lit
        let hash (x:t) = Hashtbl.hash x
        let equal = Tuple2.equal ~eq1:Polarity.equal ~eq2:Proposition.equal
        let to_literal (pol,p) ~idx = (pol,p,idx)
      end

    module HalfMap =
      struct
        module Key = Key

        module P = Polarity
        type key = Key.t
        module PM = Proposition.Map
        type 'a t = 'a PM.t * 'a PM.t
        let empty () = (PM.empty (), PM.empty ())
        let add ~key:(s,key) ~data (pos,neg) = if P.is_pos s then PM.add ~key ~data pos,neg else pos, PM.add ~key ~data neg
        let find ~key:(s,key) (pos,neg) =
          match (if P.is_pos s then PM.find ~key pos else PM.find ~key neg) with
          |None -> raise Not_found
          |Some x -> x
        let compare ~cmp (pos1,neg1) (pos2,neg2) =
          let pos_cmp = PM.compare ~cmp pos1 pos2 in
          if pos_cmp <> 0 then pos_cmp else PM.compare ~cmp neg1 neg2
        let iter ~f (pos,neg) = PM.iteri ~f:(fun ~key -> f ~key:(P.pos,key)) pos; PM.iteri ~f:(fun ~key -> f ~key:(P.neg,key)) neg
        let map ~f (pos,neg) = (PM.map ~f pos, PM.map ~f neg)
        let fold ~f (pos,neg) ~init =
          PM.fold ~f:(fun ~key -> f ~key:(P.pos,key)) pos ~init:(PM.fold neg ~f:(fun ~key -> f ~key:(P.neg,key)) ~init)
        let subset ~eq (pos1,neg1) (pos2,neg2) = PM.subset ~eq pos1 pos2 && PM.subset ~eq neg1 neg2
      end
  end

include (Exposed : S)
