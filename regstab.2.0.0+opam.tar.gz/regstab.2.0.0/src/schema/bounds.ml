(** Datatype and operations related to the bounds of iterations. *)
open Softcore

(** Signature of the module *)
module type S =
  sig
    (** Type of bounds *)
    type t

    (** {6 Comparisons} *)

    val equal : t -> t -> bool
    val total_compare : t -> t -> int

    (** {6 Getters} *)

    val upper_of : t -> Indexes.t

    (** The upper bound has the form [n+k] where [n] is the parameter; [upper_shift_of] returns [k] *)
    val upper_shift_of : t -> int
    val lower_of : t -> int

    (** {6 Constructors} *)

    (** @raise Missing_bounds if the content is [None] *)
    val of_option : t option -> t
    exception Missing_bounds

    (** Default value for bounds: 1..n *)
    val default : t

    (** {6 Useful operations} *)

    (** Shift the lower and upper bounds by a given amount *)
    val shift : by:int -> t -> t

    (** @return [true] if the index [idx] is never between the input bounds, with the assumption that [hyp] holds. *)
    val index_never_in : hyp:Constraint.t -> idx:Indexes.t -> t -> bool

    (** {6 Conversions from/to human bounds} *)

    val of_human : Human.lower_bound -> Human.upper_bound -> t
    val to_human : var:string -> t -> Human.lower_bound * Human.upper_bound

    (** {6 Output to XML} *)
    (** Note: the output depends on the wanted encoding for strings, hence the functor. *)
    module Output : functor (S : String.S) -> sig val to_xml : t -> XML(S).attr list end
  end

(**/**)
module Exposed =
  struct
    (* the first int is the lower bound, the second one is the shift of the upper bounds *)
    type t = int * int

    exception Missing_bounds

    let of_human l (_,u) = l, u
    let to_human ~var (l,u) = l, (var, u)

    let upper_of (_,u) = Indexes.create ~var:true u
    let upper_shift_of (_,u) = u
    let lower_of (l,_) = l

    let equal ((l1,u1) : t) ((l2,u2) : t) = l1 = l2 && u1 = u2
    let total_compare ((l1,u1) : t) ((l2,u2) : t) =
      let int_cmp = compare l1 l2 in
      if int_cmp <> 0 then int_cmp else compare u1 u2

    let of_option = Option.raise_if_none ~exc:Missing_bounds

    let default = 1,0

    let shift ~by (l,u) = (l+by,u+by)

    let index_never_in ~hyp ~idx (l,u) =
      Constraint.always_greater_than ~hyp (Indexes.of_int l) idx || Constraint.always_greater_than ~hyp idx (Indexes.create ~var:true u)

    module Output (S : String.S) =
      struct
        let (!) = S.of_string
        let to_xml (l,u) = [ !"lower_bound", S.of_int l; !"upper_bound_shift", S.of_int u ]
      end
  end

include (Exposed : S)
