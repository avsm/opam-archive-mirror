(** Datatype and operations related to connectives. *)
open Softcore

(** Signature of the module *)
module type S =
  sig
    (** Type of connectives *)
    type t 

    (** {6 Comparisons} *)

    val compare : t -> t -> int
    val equal : t -> t -> bool

    (** {6 Constructors} *)

    val conj : t
    val disj : t
    val xor : t
    val imply : t
    val equiv : t

    (** {6 Destructors} *)
    
    val is_conj : t -> bool
    val is_disj : t -> bool
    val destruct : t -> [ `And | `Or | `Xor | `Equiv | `Imply ]

    (** {6 Polarity operations} *)
    
    module ExtendedPolarity :
      sig
        type t = Pos | Neg | Both
        val opposite : t -> t
      end
    val polarity : t -> ExtendedPolarity.t * ExtendedPolarity.t

    (** {6 Formula operations guided by connectives} *)

    (** Turns exclusive or, implication, and equivalence into the equivalent combination of negations, conjunctions and disjunctions.
     * Note that the result cannot be given as a single connective, so instead we output a function returning the good formula out of two other formulas.
     * To do this, we need as input a function computing the opposite of a formula and one computing a function from a connective.
     *)
    val canonized : t -> opposite_formula:('formula -> 'formula) -> op:(t -> 'formula -> 'formula -> 'formula) -> ('formula -> 'formula -> 'formula)

    (** Computes the opposite of a connective (conjuction -> disjunction, exclusive or -> equivalence).
     * Returns the head connective and the functions to apply to each operand in order to get the formula opposite.
     *)
    val opposite : t -> opposite_formula:('formula -> 'formula) -> t * ('formula -> 'formula) * ('formula -> 'formula)

    (** For a connective [op] and a left operand [left], simplifies the expression [left op].
     * The result is the function to apply to the *right* operand.
     *
     * E.g. a formula "⊤ ∧ φ" can be simplified into "φ".
     * Here, with our notations, [op] is ∧ and [left] is ⊤.
     * Then [neutral_simplification op ~left] will return the identity function, because, we just want to leave the right operand unchanged.
     * In other cases we might return the opposite of the right operand, or the constants ⊤ or ⊥.
     * In yet some other cases, no simplification can be achieved, in which case [None] is returned.
     *
     * Note that we need also a parameter [opposite_neutral] allowing to compute the opposite of neutral.
     *)
    val neutral_simplification : t -> left:[> `Top | `Bot ] -> opposite_neutral:(([> `Bot | `Top ] as 'neutral) -> 'neutral) -> ('neutral -> 'neutral) option

    (** {6 Conversions from/to human connectives} *)

    val to_human : t -> Human.connective
    val of_human : Human.connective -> t

    (** {6 Output to XML} *)

    (** Note: the output depends on the wanted encoding for strings, hence the functor. *)
    module Output : functor (S : String.S) -> sig
      (** Used when the connective occurs inside an iteration. *)
      val to_xml_inner : t -> XML(S).tag 

      (** Used when the connective occurs outside an iteration. *)
      val to_xml_outer : t -> XML(S).tag 
    end

    (** {6 "Big" version of connectives, i.e. for iterations} *)

    module Big :
      sig
        (** Type of big connectives. *)
        type t

        (** {6 Constructors} *)

        val conj : t
        val disj : t

        (** {6 Selectors} *)

        val is_disjunction : t -> bool

        (** {6 Useful operations} *)

        (** Computes the opposite of a connective (conjuction -> disjunction, exclusive or -> equivalence). *)
        val opposite : t -> t

        (** Returns the neutral element of the connective. *)
        val neutral : t -> [> `Top | `Bot ]

        (** {6 Conversions from/to human connectives} *)

        val to_human : t -> Human.big_connective
        val of_human : Human.big_connective -> t

        (** {6 Output to XML} *)
        (** Note: the output depends on the wanted encoding for strings, hence the functor. *)
        module Output : functor (S : String.S) -> sig val to_xml : t -> XML(S).tag end
      end

    (** {6 Conversion from big connective} *)

    val of_big : Big.t -> t
  end

(**/**)
module Exposed =
  struct
    type t = [ `And | `Or | `Xor | `Equiv | `Imply ]

    let compare op1 op2 =
      match op1,op2 with
      |`And,`And | `Or,`Or | `Xor,`Xor | `Equiv,`Equiv | `Imply,`Imply -> 0
      |`And,_   -> -1
      |_,`And   -> 1
      |`Or,_    -> -1
      |_,`Or    -> 1
      |`Xor,_   -> -1
      |_,`Xor   -> 1
      |`Equiv,_ -> -1
      |_,`Equiv -> 1

    let equal op1 op2 =
      match op1,op2 with
      |`And,`And | `Or,`Or | `Xor,`Xor | `Equiv,`Equiv | `Imply,`Imply -> true
      |_ -> false

    module H = Human
    let to_human = function `And -> H.And | `Or -> H.Or | `Xor -> H.Xor | `Equiv -> H.Equiv | `Imply -> H.Imply
    let of_human = function H.And -> `And | H.Or -> `Or | H.Xor -> `Xor | H.Equiv -> `Equiv | H.Imply -> `Imply

    let conj = `And
    let disj = `Or
    let xor = `Xor
    let imply = `Imply
    let equiv = `Equiv
    let is_conj = function `And -> true | _ -> false
    let is_disj = function `Or -> true | _ -> false
    let destruct = ident

    let neutral_simplification op ~left ~opposite_neutral =
      match op,left with
      |`And,`Top    -> Some ident
      |`And,`Bot    -> Some (fun _ -> `Bot)
      |`Or, `Top    -> Some (fun _ -> `Top)
      |`Or, `Bot    -> Some ident
      |`Xor, `Top   -> Some opposite_neutral
      |`Xor, `Bot   -> Some opposite_neutral
      |`Equiv, `Top -> Some ident
      |`Equiv, `Bot -> Some opposite_neutral
      |`Imply, `Top -> Some ident
      |`Imply, `Bot -> Some (fun _ -> `Bot)
      |_,_          -> None

    module ExtendedPolarity =
      struct
        type t = Pos | Neg | Both
        let opposite = function Pos -> Neg | Both -> Both | Neg -> Pos
      end
    let polarity = ExtendedPolarity.(function
      |`Or | `And -> Pos,Pos
      |`Equiv | `Xor -> Both,Both
      |`Imply -> Neg,Pos)

    let opposite op ~opposite_formula =
        match op with
        |`Or -> `And, opposite_formula, opposite_formula
        |`And -> `Or, opposite_formula, opposite_formula
        |`Xor -> `Equiv, ident, ident
        |`Equiv -> `Xor, ident, ident
        |`Imply -> `And, ident, opposite_formula

    let canonized con ~opposite_formula ~op f1 f2 =
      match con with
      |`Xor   -> op `And (op `Or (opposite_formula f1) (opposite_formula f2)) (op `Or f1 f2)
      |`Equiv -> op `And (op `Or (opposite_formula f1) f2) (op `Or f1 (opposite_formula f2))
      |`Imply -> op `Or (opposite_formula f1) f2
      |_      -> op con f1 f2

    module Output(S : String.S) =
      struct
        let (^) = S.(^)
        let to_xml_outer = S.of_string <|| function `Or -> "or" | `And -> "and" | `Xor -> "xor" | `Equiv -> "equ" | `Imply -> "imp"
        let to_xml_inner op = S.of_string "in_" ^ to_xml_outer op
      end

    module Big =
      struct
        type t = [ `And | `Or ]
        let to_human = function `And -> H.Big_and | `Or -> H.Big_or
        let of_human = function H.Big_and -> `And | H.Big_or -> `Or
        let opposite = function `And -> `Or | `Or -> `And
        let conj = conj
        let disj = disj
        let is_disjunction = function `Or -> true | `And -> false
        let neutral = function `And -> `Top | `Or -> `Bot

        module Output(S : String.S) =
          struct
            module X = XML(S)
            open X
            let to_xml = S.of_string <|| function `Or -> "it_or" | `And -> "it_and"
          end
      end
    let of_big (x : Big.t) = (x :> t)
  end

include (Exposed : S)
