(** Datatype and operations related to flat skeletons.
 * Namely:
 * - a skeleton is almost a schema except that the iterations do not carry any information about their bounds
 * (with regular schemata, all bounds are the same so there is no need to store them in every single iteration)
 * - and a skeleton is flat if iterations are not nested, this is statically enforced using the type system.
 *)
open Softcore

(** Signature of the module *)
module type S =
  sig
    (** Type of flat skeletons *)
    type t

    (** {6 Comparisons} *)

    val equal : t -> t -> bool
    val total_compare : t -> t -> int

    (** {6 Constructors} *)

    val of_prop : Prop.t -> t
    val lit  : Literal.t -> t
    val it : Iteration.t -> t

    (** {6 Destructor} *)

    val destruct : t -> [ `Top | `Bot | `Op of Connective.t * t * t | `Lit of Literal.t | `It of Iteration.t ]

    (** {6 Useful operations} *)

    (** Tries to simplify a skeleton accoring to a given constraint.
     * The bounds are optional because the skeleton might contain no iteration. *)
    val algebraic_simplification : ?bounds:Bounds.t -> cstr:Constraint.t -> t -> t

    (** Computes the propositional formula corresponing to a given value of the parameter *)
    val compute : ?bounds:Bounds.t -> n:int -> t -> Prop.t

    (** Shifts the index by a certain amount *)
    val shift : ?by:int -> t -> t

    (** Computes the negation of a skeleton. *)
    val opposite : t -> t

    (** {6 Type and operations for non atomic skeletons} *)

    (** Type of non atomic skeletons, i.e. skeletons that are not literals
     * (note that the usual definition of an atom should also exclude ⊤ and ⊥, which we do not do here)
     *)
    type non_atomic = t OpenProp.non_atomic

    (** Constructor. *)
    val conj : t -> t -> non_atomic

    (** Constructor. *)
    val disj : t -> t -> non_atomic

    (** Cast from [non_atomic] to [t] *)
    val of_non_atomic : non_atomic -> t

    (** Cast from [non_atomic list] to [t list] *)
    val of_non_atomics : non_atomic list -> t list

    (** {6 Conversions from/to human schemas} *)

    (** The parameter and variable are options because the skeleton might very well contain no iteration and/or literals involving only integers
     * (note that such schemata are obviously trivial since they are just propositional formulas)
     * However, when the skeleton does contain iterations then a variable and a parameter must be provided.
     * Similarly, if the skeleton contains literals involving non-integer expressions then a parameter must be provided.
     * @raise Missing_parameter if the parameter is needed but not provided.
     * @raise Missing_variable if the variable is needed but not provided.
     *)
    val to_human : param:string option -> var:string option -> bounds:Bounds.t option -> t -> Human.schema

    exception Missing_parameter
    exception Missing_variable

    (** @raise More_than_one_parameter if the input contains more than one parameter (which is not allowed for regular schemata) *)
    val of_human : Human.schema -> t

    exception More_than_one_parameter of string * string

    (** {6 Output to XML} *)
    (** Note: the output depends on the wanted encoding for strings, hence the functor. *)
    module Output (S : String.S) : sig val to_xml : t -> XML(S).t end
  end

(**/**)
module Exposed =
  struct
    module O = OpenProp
    type t = [ t OpenProp.t | `It of Iteration.t ]

    let destruct = ident
    let of_prop x = (Prop.rec_destruct x :> t)

    let conj s1 s2 = `Op(Connective.conj,s1,s2)
    let disj s1 s2 = `Op(Connective.disj,s1,s2)
    let lit l = `Lit l

    exception Missing_parameter
    exception Missing_variable

    let rec to_human ~param ~var ~bounds = function
      |#O.t as x -> O.to_human (to_human ~param ~var ~bounds) ~var:param x
      |`It it ->
          match bounds with
          |None -> raise Bounds.Missing_bounds
          |Some b ->
              let param = Option.raise_if_none ~exc:Missing_parameter param in
              let var = Option.raise_if_none ~exc:Missing_variable var in
              Human.It (Iteration.to_human ~param ~var it ~bounds:b)

    exception More_than_one_parameter of string * string
    let of_human x = 
      (try ignore (Human.free_variable_of x) with Human.More_than_one_free_variable(v1,v2) -> raise (More_than_one_parameter(v1,v2)));
      let rec of_human x = O.of_human of_human ~iteration_case:(fun it -> `It (Iteration.of_human it)) x in
      of_human x

    let rec equal s1 s2 =
      match s1,s2 with
      |(#O.t as x1), (#O.t as x2) -> O.equal equal x1 x2
      |`It it1,`It it2 -> Iteration.equal it1 it2
      |_,_ -> false

    let rec total_compare s1 s2 =
      match s1,s2 with
      |(#O.t as x1), (#O.t as x2) -> O.total_compare total_compare x1 x2
      |`It it1,`It it2 -> Iteration.total_compare it1 it2
      |`It _, _ -> -1
      |_, `It _ -> 1

    let rec opposite = function
      |#O.t as x -> O.opposite opposite x
      |`It it -> `It(Iteration.opposite it)

    let rec algebraic_simplification ?bounds ~cstr = function
      |#O.t as x -> O.algebraic_simplification (algebraic_simplification ?bounds ~cstr) opposite x
      |`It it -> (Iteration.algebraic_simplification ~cstr ~bounds:(Bounds.of_option bounds) it :> t)

    let rec compute ?bounds ~n = function
      |#O.t as x -> Prop.construct (O.compute (compute ?bounds) ~n x)
      |`It it -> Iteration.compute ~bounds:(Bounds.of_option bounds) ~n it

    let it it = `It it

    let rec shift ?by = function
      |#O.t as x -> O.shift shift ?by x
      |`It _ as x -> x

    type non_atomic = t OpenProp.non_atomic
    let of_non_atomic (x : non_atomic) = (x :> t)
    let of_non_atomics (x : non_atomic list) = (x :> t list)

    module Output (S : String.S) =
      struct
        module X = XML(S)
        module L = Literal.Output(S)
        module C = Connective.Output(S)
        module I = Iteration.Output(S)
        let (!~) = S.of_string
        let rec to_xml = function
          |`Top -> X.leaf (S.of_string "true")
          |`Bot -> X.leaf (S.of_string "false")
          |`Lit l -> L.to_xml l
          |`Op(op,s1,s2) -> X.node ~tag:(C.to_xml_outer op) [ to_xml s1; to_xml s2; ]
          |`It it -> I.to_xml it
      end
  end

include (Exposed : S)
