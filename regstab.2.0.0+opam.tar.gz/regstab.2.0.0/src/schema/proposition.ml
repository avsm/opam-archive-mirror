(** Datatype and operations related to propositional variables. *)
open Softcore

(** Signature of the module *)
module type S =
  sig
    (** Type of propositional variables. *)
    type t

    (** {6 Comparisons } *)

    val compare : t -> t -> int
    val equal : t -> t -> bool

    (** {6 Conversions from/to human propositional variables} *)

    val of_human : Human.prop_var -> t
    val to_human : t -> Human.prop_var

    (** {6 Output to XML} *)
    (** Note: the output depends on the wanted encoding for strings, hence the functor. *)
    module Output : functor (S : String.S) -> sig val to_xml : t -> XML(S).t end

    (** {6 Map of propositions} *)

    module Map :
      sig
        type key = t
        type 'a t

        (** {6 Usual operations for map} *)

        val empty : unit -> 'a t
        val add : key:key -> data:'a -> 'a t -> 'a t
        val find : key:key -> 'a t -> 'a option
        val compare : cmp:('a -> 'a -> int) -> 'a t -> 'a t -> int
        val iteri : f:(key:key -> data:'a -> unit) -> 'a t -> unit
        val map : f:('a -> 'b) -> 'a t -> 'b t
        val fold : f:(key:key -> data:'a -> 'b -> 'b) -> init:'b -> 'a t -> 'b
        val subset : eq:('a -> 'a -> bool) -> 'a t -> 'a t -> bool
      end
  end

(**/**)
module Exposed =
  struct
    type t = int

    let var_to_string = Hashtbl.create 9973
    let string_to_var = Hashtbl.create 9973
    let nb_vars = ref 0

    let of_human s = 
      match Hashtbl.find string_to_var s with
      |None ->
          let new_var = !nb_vars in
          (incr nb_vars;
          Hashtbl.add var_to_string ~key:new_var ~data:s; 
          Hashtbl.add string_to_var ~key:s ~data:new_var; 
          new_var)
      |Some v -> v
    let to_human v = Hashtbl.find_exn var_to_string v

    let compare (v1:t) (v2:t) = compare v1 v2
    let equal (v1:t) (v2:t) = v1 = v2

    module Output (S : String.S) =
      struct
        module X = XML(S)
        open X
        let to_xml p = !!"prop_var" (S.of_string (to_human p))
      end

    module Map =
      struct
        type key = t
        module A =
          struct
            type 'a t = 'a array
            include Array
            let create ~size = Array.create size
            let set ~key ~data a =
              let res = Array.copy a in
              res.(key) <- data;
              res
            let get ~key a = try a.(key) with Invalid_argument _ -> None
            let fold a ~f ~init =
              let res = ref init in
              iteri a ~f:(fun key data -> res := f ~key ~data !res);
              !res
            let compare ~cmp a1 a2 =
              let len1, len2 = length a1, length a2 in
              let len_cmp = Pervasives.compare len1 len2 in
              if len_cmp <> 0 then len_cmp
              else
                let rec loop i =
                  if i = len1 then 0 else
                    let elt_cmp = cmp a1.(i) a2.(i) in
                    if elt_cmp <> 0 then elt_cmp else loop (i+1)
                in
                loop 0
          end
        type 'a t = 'a option A.t
        let empty () = A.create ~size:!nb_vars None
        let add ~key ~data = A.set ~key ~data:(Some data)
        let find ~key a = try A.get ~key a with Invalid_argument _ -> None
        let iteri ~f = A.iteri ~f:(fun key -> Option.iter ~f:(fun data -> f ~key ~data))
        let map ~f = A.map ~f:(Option.map ~f)
        let fold ~f ~init = A.fold ~init ~f:(fun ~key ~data acc -> match data with None -> acc | Some data -> f ~key ~data acc)
        let compare ~cmp x y = A.compare ~cmp:(fun x y -> Option.total_compare ~cmp x y) x y
        exception Counter_example
        let for_all ~f x =
          try iteri x ~f:(fun ~key ~data -> if f ~key ~data then () else raise Counter_example); true
          with Counter_example -> false
        let subset ~eq a1 a2 = for_all a1 ~f:(fun ~key ~data -> 
          let data2 = try A.get ~key a2 with Invalid_argument _ -> None in
          match data2 with Some data2 when data2 = data -> true |None | Some _ -> false)
      end
  end

include (Exposed : S)
