H5L_type_t H5L_type_val(value);
value Val_h5l_type(H5L_type_t);
