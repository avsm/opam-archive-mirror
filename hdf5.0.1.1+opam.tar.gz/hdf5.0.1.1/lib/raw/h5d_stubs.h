#include <stdbool.h>
H5D_layout_t H5D_layout_val(value);
value Val_h5d_layout(H5D_layout_t);
