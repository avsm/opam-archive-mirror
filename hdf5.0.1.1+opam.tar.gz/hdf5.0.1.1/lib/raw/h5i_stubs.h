void fail();
void raise_if_fail(hid_t);
