type t = {
  name  : string;
  type_ : Type.t;
}

let create name type_ = { name; type_ }
