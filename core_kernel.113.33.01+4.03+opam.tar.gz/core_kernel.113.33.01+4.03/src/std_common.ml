(* Modules that are overridden by Core.Std *)
module Bigbuffer         = Bigbuffer
module Bigstring         = Bigstring
module Bigstring_marshal = Bigstring_marshal
module Caml              = Caml
module Time_ns           = Time_ns
