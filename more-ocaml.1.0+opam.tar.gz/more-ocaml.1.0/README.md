more-ocaml
==========

Support code for the book "More OCaml".

It is released under the LGPL with special linking exception (see LGPL.txt). The file "OCamlmakefile" is due to Markus Mottl, and is under the same licence.

Instructions for using this library are in the chapter "Our Working Environment" in the book.

