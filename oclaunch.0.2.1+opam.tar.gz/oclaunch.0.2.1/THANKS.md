# Thanks to

## Alexander James Wright and Dario Moriconi, from the noun project
for the icon on which the logo is based.   
Thanks also to [ocaml.org](http://www.ocaml.org) for the camel.

The result is licensed under CC-BY.

