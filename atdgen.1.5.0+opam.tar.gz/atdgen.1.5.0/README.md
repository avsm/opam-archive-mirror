Atdgen uses type definitions in the ATD syntax and generates
efficient [JSON](http://json.org) serializers, deserializers and
validators for OCaml.

Documentation
-------------

The manual is being reformatted using the Markdown syntax and Pandoc.
The semi-readable source is on Github, and it is the most complete and
accurate reference for atdgen:
https://github.com/mjambon/atdgen-doc

The home page for atdgen is http://mjambon.com/atdgen. It contains
links to an old tutorial which also needs some reformatting, and links
to a few other useful pages that give some context about the project.

Stable releases are available from opam.


How to contribute
-----------------

See https://github.com/mjambon/documents/blob/master/how-to-contribute.md
