(* Locale routines for ocaml
   Copyright (C) 2002 Shawn Wagner <raevnos@pennmush.org>

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.
	 
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
	 
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*)

type category = [ `LC_ALL | `LC_COLLATE | `LC_CTYPE | `LC_MESSAGES | `LC_MONETARY | `LC_NUMERIC | `LC_TIME ]
external set : ?name:string -> category -> string option = "stew_set_locale"

type numeric_lconv = {
  decimal_point: string;
  thousands_sep: string;
  grouping: string;
}

type sign_pos = [ `SurroundBoth | `SignPrecedesBoth | `SignSucceedsBoth | `SignPrecedesCS | `SignSucceedsCS | `UnknownOrder ]

type monetary_lconv = {
  int_curr_symbol: string;
  currency_symbol: string;
  decimal_point: string;
  thousands_sep: string;
  grouping: string;
  positive_sign: string;
  negative_sign: string;
  int_frac_digits: int;
  frac_digits: int;
  p_cs_precedes: bool;
  p_sep_by_space: bool;
  n_cs_precedes: bool;
  n_sep_by_space: bool;
  p_sign_posn: sign_pos;
  n_sign_posn: sign_pos;
}

let set_from_env = set ~name:""

let get locale = Option.default (set locale) ""

external numeric_info: unit -> numeric_lconv = "stew_localeconv_n"
external monetary_info: unit -> monetary_lconv = "stew_localeconv_m" 

