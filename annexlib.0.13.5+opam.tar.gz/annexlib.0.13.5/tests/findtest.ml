
let matcher = Find.make (`Or [ `Name "*.ml"; `Name "*.mli"; `And [ `Size (`LargerThan (`Kilobytes 20)); `Perms 01] ]) in
  print_endline "Files matching the criteria:";
  List.iter (fun f -> print_endline f) (Find.find matcher ".")

