let test_char c =
  print_char c;
  print_string " is ";
  if CharExtras.is_alpha c then begin
    print_endline "alphabetic";
    let uc = CharExtras.to_upper c
    and lc = CharExtras.to_lower c in
      print_char uc;
      print_string " is uppercase and ";
      print_char lc;
      print_endline " is lower case."
  end else print_endline "NOT alphabetic"
    
let test_locale l =  
  let _ =
    print_string "Old character type was ";
    print_endline (CharExtras.get_chartype ());
    match CharExtras.set_chartype l with
      | Some newc -> 
          print_string "New character type is ";
          print_endline newc
      | None -> print_endline "None found." in
    test_char 'X';
    test_char '9';
    test_char '�';
    test_char '\n'

let _ = 
  test_locale "C";
  test_locale "en_US";
  print_string "Old LC_TIME locale was ";
  print_endline (Locale.get `LC_TIME);
  begin match Locale.set ~name:"es" `LC_TIME with
    | Some locale -> print_string "New LC_TIME locale is "; print_endline locale
    | None -> print_endline "Setting LC_TIME locale to es failed."
  end;
  let t = Time.time () in
    print_string "The time is: ";
    print_string (StrExtras.chomp (Time.time_string t));
    print_endline " and this should be on the same line.";
    print_string (Time.format_time "And also %A, %B %d.\n" t)
    
