let package_name = "ppx_fields_conv"

let sections =
  [ ("lib",
    [ ("built_lib_ppx_fields_conv", None)
    ],
    [ ("META", None)
    ])
  ]
