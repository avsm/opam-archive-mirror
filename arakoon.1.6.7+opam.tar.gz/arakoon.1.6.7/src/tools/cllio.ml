external int64_to_buffer : string -> int -> int64 -> unit =
    "Caml_int64_to_buffer"
