# Defaults for arakoon initscript
# sourced by /etc/init.d/arakoon
# installed at /etc/default/arakoon by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
