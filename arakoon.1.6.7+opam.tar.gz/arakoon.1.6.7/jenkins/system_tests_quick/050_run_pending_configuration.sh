#!/bin/bash -xue

/opt/qbase3/qshell -c "
q.qp._runPendingReconfigeFiles()
"
