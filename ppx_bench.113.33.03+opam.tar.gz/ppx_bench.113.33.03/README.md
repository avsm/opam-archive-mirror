Syntax extension for writing in-line benchmarks in ocaml code.

For documentation & examples, see: 
    example/pa_bench_sample.ml
