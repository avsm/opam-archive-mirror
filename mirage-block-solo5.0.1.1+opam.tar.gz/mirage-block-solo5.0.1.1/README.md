Mirage BLOCK implementation for Solo5
