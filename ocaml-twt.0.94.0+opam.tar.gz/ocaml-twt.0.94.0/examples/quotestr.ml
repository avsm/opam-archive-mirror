String.length {|\"|}         (* returns 2 *)

String.length {foo|The quick
  brown fox jumps over the lazy dog. |}
    {foo| {bar| let }])([{ |bar}" |foo}

String.length {foo|\"|foo}   (* returns 2 *)

String.length ({foo|\"|foo} ^ {|"|foo}|})

Printf.printf "hello world\n"

