open Core.Std let _ = _squelch_unused_module_warning_

let f s = s^s^s

let message = f "plugin_003 is a stammer "
