(**
   This config is different, it is a library config file.
   Grass uses such jobs file to overwrite e.g. some builtins
*)
let f x = x^" using some config_util utility functions"
