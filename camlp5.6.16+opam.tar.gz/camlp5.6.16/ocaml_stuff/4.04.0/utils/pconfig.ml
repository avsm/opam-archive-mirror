let ocaml_version = "4.04.0"
let ocaml_name = "ocaml"
let ast_impl_magic_number = "Caml1999M019"
let ast_intf_magic_number = "Caml1999N018"
