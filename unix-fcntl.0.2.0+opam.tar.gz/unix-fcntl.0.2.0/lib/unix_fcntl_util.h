int unix_fcntl_o_shlock();
int unix_fcntl_o_exlock();
int unix_fcntl_o_evtonly();
int unix_fcntl_o_symlink();
int unix_fcntl_o_search();
int unix_fcntl_o_exec();
int unix_fcntl_o_tty_init();
