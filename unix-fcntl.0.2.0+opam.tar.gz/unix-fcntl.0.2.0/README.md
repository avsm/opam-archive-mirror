ocaml-unix-fcntl
================

[ocaml-unix-fcntl](https://github.com/dsheets/ocaml-unix-fcntl) provides
host-dependent fcntl.h access.
