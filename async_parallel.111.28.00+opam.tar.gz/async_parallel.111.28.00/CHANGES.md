## 111.25.00

- improve error handling

## 109.41.00

Rename library from Parallel to Async_parallel

