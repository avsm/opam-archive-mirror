#!bin/sh

# Apparently can do this in oasis as well using the mandir variable
cp brozip.1 $(opam config var man)/man1
