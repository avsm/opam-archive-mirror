open Convenience
open Big_int

(* A smarter function to compute the value in a product of n parts.
 *
 ******************************************************************************
 * Great function, unfortunately, it relies on prime factor decomposition,
 * which is of course very slow for large numbers. 
 * This method is therefore unusable in practice for large indexes.
 ******************************************************************************
 * 
 * We proceed by iteration. At each iteration, we pop a prime factor
 * from the starting index (roughly by division), and push this factor
 * into one part (roughly by muliplication).
 *
 * Terminology: these numbers that are built by successive
 * multiplication or deconstructed by successive divisions
 * are called "factorized" or "defactorized" (respectively).
 *
 * The current state includes the current defactorized space size
 * and the current defactorized index (that is an index in the remaining space).
 *
 * For each part, we maintain:
 *   - the current factorized index in this part, 
 *   - its current defactorized size,
 *   - a decomposition of the current defactorized size in prime factors 
 *     (they are kept in descending order)
 *
 * Invariant (I): current defactorized space size == product of defactorized part sizes.
 *
 *
 *****  Algorithm  *****
 *
 * We repeat the following steps until the defactorized space size equals 1.
 *
 * - Take the first part with defactorized size > 1 
 *   (that is, take its greatest prime factor). Such a part exists by virtue of (I).
 *   We write pf for this prime factor. 
 *   By (I), we know that this pf divides the space size.
 *
 * - Compute the pf-coordinate of deconstructed index in the deconstructed space, that is:
 *     let subspace_size = space_size / pf
 *     let pf_coordinate = index / subspace_size
 *
 * - Use this coordinate as a coordinate for the current part
 *   => remove pf from the list of prime factors (and divide the defactorized part size accordingly)
 *   => the factorized part index becomes += pf_coordinate * subpart size
 *
 * When finished, current defactorized space size = 1, current defactorized index = 0,
 * all parts have a defactorized size = 1.
 *)

type part_status = {
    f_index : big_int ;
    df_size : big_int ;
    decomp  : big_int list ; (* Prime factors of df_size, kept in descending order. *)
  }

(* Returns the descending list of prime factors of n. *)
let rec get_primes_aux add2 acu n div =
  if n <== bigone then acu
  else
    begin
      let (ndiv, nmod) = quomod n div in
      if sign nmod = 0 then
	(* This is a prime factor ! Check it again to take account for multiplicity. *)
	get_primes_aux add2 (div :: acu) ndiv div
      else
	get_primes_aux false acu n (if add2 then 2 +++ div else succ div)
    end

let get_primes n =
  if (is_bigone n) then []
  else get_primes_aux false [] n (boi 2)


let test_primes () =
  for i = 1 to 500 do
    let pr = get_primes (boi i) in
    Printf.printf "Primes %d = %s\n%!" i (sep sob ", " pr)
  done ;
  ()

(* Initialize a part status given its initial cardinal. *)
let init_status card = 
  Printf.printf "Getting primes for %s...%!" (sob card) ;
  let status =
    { f_index = bigzero ;
      df_size = card ;
      decomp  = get_primes card }
  in 
  Printf.printf "done\n%!" ;
  status

(* Iterate until the space size is one. 
 * rev indicates if the last argument (statuses) is ordered or reversed with respect to the original part list. 
 * acu contains the statuses already treated, in the opposite order (not rev). 
 * changed indicates if at least one status has changed since we started this list of statuses. 
 * Returns the reversed list of statuses. *)
let rec iterate_prime_product ~rev ~changed space_size index acu statuses =
  
  match statuses with
  | [] ->
      if is_bigone space_size then
	begin
	  (* Finished *)
	  assert (0 = big_compare index bigzero) ;

	  (* Always return the reversed list. 
	   * Remember that acu is ordered according to (not rev). *)
	  if rev then List.rev acu else acu
	end

      else
	begin
	  (* If nothing has changed since we started the list, we are looping indefinitely. 
	   * This cannot happen. *)
	  assert changed ;
	  iterate_prime_product ~rev:(not rev) ~changed:false space_size index [] acu
	end

  | part_status :: others ->
      begin
	(* Is there a prime factor available? *)
	match part_status.decomp with
	| [] ->
	    (* Nope, this part is completely done. *)
	    assert (is_bigone part_status.df_size) ;
	    
	    (* To the next one *)
	    iterate_prime_product ~rev ~changed space_size index (part_status :: acu) others
	    
	| pf :: factors ->
	    (* A prime factor! (evil laugh) Ha ha ha! *)

	    let (subspace_size, zz) = quomod space_size pf in
	    assert (sign zz = 0) ;

	    let (pf_coordinate, new_index) = quomod index subspace_size in

	    let (new_dfsize, zz) = quomod part_status.df_size pf in
	    assert (sign zz = 0) ;
	    
	    let new_status =
	      { f_index = part_status.f_index ++ pf_coordinate ** new_dfsize ;
		df_size = new_dfsize ;
		decomp  = factors }
	    in
	    
	    (* To the next one *)
	    iterate_prime_product ~rev ~changed:true subspace_size new_index (new_status :: acu) others	    
      end


(* Returns a vector corresponding to indexes in the respective parts. *)
let compute_product_aux get_cardinal parts =
  
  (* Statuses of all parts. *)
  let rev_statuses = List.rev_map (fun p -> init_status (get_cardinal p)) parts in
 
  let space_size = myfold parts bigone (fun acu p -> acu ** get_cardinal p) in
 
  fun index ->
    (* Initial space status = space_size, index. *)
    let rev_statuses = iterate_prime_product ~rev:true ~changed:false space_size index [] rev_statuses in
    
    let indexes = myrevmap rev_statuses 
	begin fun status ->
	  assert (status.decomp = []) ;
	  assert (is_bigone status.df_size) ;
	  status.f_index
	end
    in 

    indexes
