open Convenience

(* A smarter function to compute the value in an union of n parts.
 * 
 * The standard function above splits the interval [0..max_index] in n sequential subintervals,
 * where each subinterval corresponds to a unique part. That is, parts are just concatenated.
 * 
 * In this function, parts are interleaved.
 * 
 * The interval [0..max_index] is split in n sequential subintervals, where each subinterval
 * contains the interleaved values of all 'active' parts.
 * In the very first subinterval, all parts are active.
 * This first subinterval ends when the smallest part is fully enumerated. This parts becomes inactive.
 * More generally, a subinterval ends when one of its parts is fully enumerated.
 * The following subinterval contains only remaining active parts.
 *
 * All this can be easily described with a drawing. *)

(* interval_nb = subinterval number in which this index lies. *)
let rec find_in_layout interval_nb index = function
  | [] -> assert false (* Index was too big. *)
  | (start_i, consumed_i) :: others ->
      if start_i <== index then
	(* Not in this subinterval *)
	find_in_layout (interval_nb + 1) index others
 
      else
	(* It is here *)
	(interval_nb, start_i, consumed_i)

let compute_union_aux get_cardinal partlist =
  
  let getc = get_cardinal in

  (* Sort the parts according to their cardinal. *)
  let partlist = List.sort (fun p1 p2 -> big_compare (getc p1) (getc p2)) partlist in
  (* Now the parts are in ascending order. *)

  let n = List.length partlist in

  (* Compute the layout, that is, a list of indexes
   * where each index is the beginning of the next subinterval. *)
  let (last_index, consumed, active_parts, layout) = 
    myfold partlist (bigzero, bigzero, n, [])
      
      (* current_index is the absolute index in the full interval.
       * consumed = how many elements already consumed in all active parts. 
       * active_parts = how many remaining active parts. *)
      begin fun (current_index, consumed, active_parts, acu) part ->
	(* This part is necessarily the smallest of active parts. *)

	(* How many elements remain to be enumerated in the smallest part. *)
	let remaining = (getc part) -- consumed in

	let next_index = current_index ++ active_parts **. remaining
	and newconsumed = consumed ++ remaining
	in
	(next_index, newconsumed, active_parts - 1, (next_index, newconsumed) :: acu)
      end
  in

  (* There should be no remaining active parts. *)
  assert (active_parts = 0) ;

  (* consumed should be equal to the cardinal of the biggest part. *)
  assert (0 = big_compare consumed (getc (List.nth partlist (n-1)))) ;

  (* The last index should be equal to the sum of cardinals. *)
  assert (0 = big_compare last_index (myfold partlist bigzero (fun acu p -> acu ++ (getc p)))) ;

  (* By construction, the layout was reversed. *)
  let layout = List.rev layout in
  (* It is now in increasing order. *)

  (* Layout = [(index_1, consumed_1) ; (index_2, consumed_2) ; ... (index_n, consumed_n)]
   *    where 
   *      index_1 is the beginning of the second subinterval
   *      consumed_1 is the number of elements of all parts which are already enumerated in the first subinterval.

   *      index_2 is the beginning of the third subinterval
   *      consumed_2 is the number of elements of active parts (>=2) which are enumerated in the first & second subinterval.
   *      ...
   *      index_n is equal to the sum of cardinals.
   *)


  (* Lookup function. *)
  fun index ->

    let (interval_nb, start, consumed) = find_in_layout 0 index layout in
    
    let remaining = index -- start in
    
    (* Number of active parts in this subinterval. *)
    let nb_active = n - interval_nb in
    assert (nb_active > 0) ;

    (* In which active part should it be, at which relative index. *)
    let (relative_index, activepart) = quomod remaining (boi nb_active) in

    let absolute_index = consumed ++ relative_index in

    (* Now, convert the active part number to a real part number *)
    let realpart = (iob activepart) + interval_nb in

    (* Finally, get the expected part *)
    let part = List.nth partlist realpart in
    
    (part, absolute_index)
