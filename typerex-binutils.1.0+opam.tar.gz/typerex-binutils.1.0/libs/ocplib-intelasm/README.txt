ocplib-intelasm
===============

A very simple assembler for a subset of Intel x86/amd64 instructions.
The implemented instruction set corresponds to what is emitted by the
OCaml compiler.

Also, a backend for the OCaml native compiler to directly generate
object files (currently, only for Windows) without an external
assembler.
