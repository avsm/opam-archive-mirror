ocplib-elf
==========

A library to read and write elf object files.

Both 32 bits and 64 bits are supported.
Read is implemented, write is not implemented yet.
Only LittleEndian architectures are currently supported.
