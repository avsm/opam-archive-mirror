Simple library to read and write tar files.

This library is part of Citrix'
[xen-api-libs](https://raw.github.com/xen-org/xen-api-libs), I've only
made it self-consistent and a bit more generic.

This is pure OCaml code, no C bindings.