## 111.17.00

- Upgraded library to use inotify 2.0

