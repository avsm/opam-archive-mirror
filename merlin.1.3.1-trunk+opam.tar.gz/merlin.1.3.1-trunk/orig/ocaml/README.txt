Merlin uses code from Ocaml, see [http://caml.inria.fr/](The Caml language: Home).
Files derived from the original Ocaml compiler source includes:
- the parsing, typing and utils subdirectories
- chunk_parser.mly, outline_parser.mly, lexer.mll, lexer.mli
- main_args.ml, main_args.mli

There you can find the original distribution:
  http://caml.inria.fr/pub/distrib/ocaml-4.00/ocaml-4.00.1.tar.gz
Trunk version from:
  https://github.com/ocaml/ocaml

The Ocaml compiler is distributed under the QPL licence and is copyright INRIA.
See LICENSE in the current directory.
