let package_name = "email_message"

let sections =
  [ ("lib",
    [ ("built_lib_email_message", None)
    ],
    [ ("META", None)
    ])
  ]
