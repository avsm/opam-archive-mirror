1.1.0 (2015-01-24):
* Add `Dockerfile_opam` and `Dockerfile_opam_cmdliner` modules with
  specific rules for managing OPAM installations with Dockerfiles.

1.0.0 (2014-12-30):
* Initial public release.
