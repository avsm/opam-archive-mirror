let package_name = "fieldslib"

let sections =
  [ ("lib",
    [ ("built_lib_fieldslib", None)
    ],
    [ ("META", None)
    ])
  ]
