typedef int x[];
