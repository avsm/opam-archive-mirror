void f(void) {

  id keys;
  id thatKey;

  for (id thisKey in keys) {
    thatKey = thisKey;
  };
}
