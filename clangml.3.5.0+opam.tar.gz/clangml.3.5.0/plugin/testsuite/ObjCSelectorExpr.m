void f() {
  SEL s = @selector(retain);
}
