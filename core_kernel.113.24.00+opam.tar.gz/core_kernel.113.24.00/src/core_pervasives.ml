include Pervasives
external raise : exn -> 'a = "%reraise"

