[![Build Status](https://travis-ci.org/agarwal/oloop.svg?branch=master)](https://travis-ci.org/agarwal/oloop)

Oloop
=====

Oloop is a library that lets you interact with toploops.
