Oloop Release Notes

oloop 0.1.2 2015-Jul-01
-----------------------
* preload Lazy module in toplevels
* add noinit option


oloop 0.1.1 2015-Jun-30
-----------------------
* remove noinit option


oloop 0.1.0 2015-Jun-30
-----------------------
* First release.
