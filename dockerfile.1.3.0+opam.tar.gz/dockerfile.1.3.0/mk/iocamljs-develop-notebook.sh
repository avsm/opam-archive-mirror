#!/bin/sh -ex

NAME=dockerfile

iocaml -js ${NAME} notebooks/
