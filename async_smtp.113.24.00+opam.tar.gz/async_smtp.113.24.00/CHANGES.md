## 113.24.00

- Switched to PPX.

- Follow Core & Async evolution.

## 113.00.00

- Improve the async_smtp client interface so that it is suitable as a
  replacement for Core_extended.Std.Sendmail.

## 112.17.00

Moved from janestreet-alpha

