
module Serialize = Serialize
module MsgpackConfig = MsgpackConfig
module Pack = Pack
module MsgpackCore = MsgpackCore

type t = Serialize.t
