#ifndef OCSFML_RAW_DATA_TYPE_HPP_INCLUDED
#define OCSFML_RAW_DATA_TYPE_HPP_INCLUDED

#include <camlpp/big_array.hpp>

typedef camlpp::big_array<void, 1> RawDataType;

#endif
