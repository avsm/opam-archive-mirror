#ifndef OCSFML_CLOCK_HPP_INCLUDED
#define OCSFML_CLOCK_HPP_INCLUDED


#include "Time.hpp"


#endif
