#include "Drawable.hpp"

#include <camlpp/custom_ops.hpp>

#define CAMLPP__CLASS_NAME() sf_Drawable
camlpp__register_preregistered_custom_operations( CAMLPP__DEFAULT_FINALIZE(), CAMLPP__NO_COMPARE(), CAMLPP__NO_HASH() )
camlpp__register_preregistered_custom_class()
{}
#undef CAMLPP__CLASS_NAME

