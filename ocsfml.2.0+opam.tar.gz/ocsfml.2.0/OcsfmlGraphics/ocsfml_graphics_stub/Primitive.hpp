#ifndef OCSFML_PRIMITIVE_HPP_INCLUDED
#define OCSFML_PRIMITIVE_HPP_INCLUDED

#include <camlpp/custom_conversion.hpp>

#include <SFML/Graphics/PrimitiveType.hpp>

custom_enum_affectation( sf::PrimitiveType ) ;
custom_enum_conversion ( sf::PrimitiveType ) ;

#endif
