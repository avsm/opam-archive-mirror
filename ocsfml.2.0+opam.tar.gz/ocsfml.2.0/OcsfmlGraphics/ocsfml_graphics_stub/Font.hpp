#ifndef OCSFML_GONT_HPP_INCLUDED
#define OCSFML_GONT_HPP_INCLUDED

#include <camlpp/custom_class.hpp>

#include <SFML/Graphics/Font.hpp>

typedef sf::Font sf_Font;
camlpp__preregister_custom_class( sf_Font )

#endif
