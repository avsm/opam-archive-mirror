## [v0.1.1]

*2015-12-03*

- Compile with `-safe-string` (issue #1)
- Add a bytecode-only target (PR #2)

## v0.1.0

*2015-08-28*

- Initial release

[v0.1.1]: https://github.com/cryptosense/enumerators/compare/v0.1.0...v0.1.1
