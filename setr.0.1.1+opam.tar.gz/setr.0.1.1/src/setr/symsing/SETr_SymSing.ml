module Interface = SETr_SymSing_Interface
module Lin = SETr_SymSing_Lin
module Logic = SETr_SymSing_Logic
module Sing = SETr_SymSing_Sing
