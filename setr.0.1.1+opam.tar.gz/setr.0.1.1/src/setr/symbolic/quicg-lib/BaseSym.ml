
type t = int

let zero = 0

let succ a = a + 1

let add a b = a + b

let sub a b = a - b

let fmt ff v = Format.pp_print_int ff v

let compare a b = compare a b

let of_int i = i

let to_int i = i
