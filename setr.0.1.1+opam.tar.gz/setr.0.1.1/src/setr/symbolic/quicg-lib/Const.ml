type const =
  | NumConst of int
