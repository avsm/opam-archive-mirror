#!/bin/bash -xue

./arakoon.native --version > arakoonqpackage.version.txt
