(* OASIS_START *)
(* DO NOT EDIT (digest: d83c97a78d85428fc1f65fdfe8b3603c) *)

orakuda - ORakuda, Perlish string literals in OCaml
===================================================

See the file [INSTALL.txt](INSTALL.txt) for building and installation
instructions.

Copyright and license
---------------------

orakuda is distributed under the terms of the GNU Lesser General Public
License version 2.0 with OCaml linking exception.

(* OASIS_STOP *)
