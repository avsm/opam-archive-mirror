module Regexp = Regexp
include Regexp.Infix

(* for pa_hash *)
module Hashtbl = Hashtbl

module Cformat = Cformat
