let version = "1.8.3"
let date = "Wed Apr 17 20:29:52 CEST 2013"
