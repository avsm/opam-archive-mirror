## 111.08.00

- Improved the propagation of SSL errors to the caller.

## 111.06.00

Initial release

