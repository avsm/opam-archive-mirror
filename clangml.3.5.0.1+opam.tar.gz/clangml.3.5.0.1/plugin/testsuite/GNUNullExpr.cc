int null_size = sizeof(__null);
