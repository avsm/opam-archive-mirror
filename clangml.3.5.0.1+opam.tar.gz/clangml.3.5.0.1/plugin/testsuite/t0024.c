// t0024.c
// use of 'std' as an identifier

enum { std };

int foo()
{
  return std;
}
