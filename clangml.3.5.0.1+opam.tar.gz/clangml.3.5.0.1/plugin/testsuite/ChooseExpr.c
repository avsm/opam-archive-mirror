int f() {
  return __builtin_choose_expr(0, 10, 20);
}
