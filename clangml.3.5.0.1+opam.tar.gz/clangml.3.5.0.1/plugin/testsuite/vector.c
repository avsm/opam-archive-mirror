typedef int v4si __attribute__ ((__vector_size__ (16)));
