(* empty stub, to call ocp-watch-gencalls on it to generate the file *)
