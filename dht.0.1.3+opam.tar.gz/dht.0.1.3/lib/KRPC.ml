(* Copyright (C) 2001-2014 ygrek, mldonkey

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA. *)

let debug ?exn fmt = Log.lprintlf ?exn ("KRPC: " ^^ fmt)

let (>>=) = Lwt.(>>=)

open Printf

let alpha = 3
    
type msg =
  | Query of string * (string * Bcode.t) list
  | Response of (string * Bcode.t) list
  | Error of int64 * string

let string_of_msg = function
  | Query (name, args) ->
    sprintf "query %s(%s)" name (String.concat "," (List.map fst args))
  | Response d ->
    sprintf "response (%s)" (String.concat "," (List.map fst d))
  | Error (n, s) ->
    sprintf "error (%Ld,%S)" n s

let encode t msg =
  let d = match msg with
    | Query (name, args) ->
      ["y", Bcode.String "q"; "q", Bcode.String name; "a", Bcode.Dict args]
    | Response dict ->
      ["y", Bcode.String "r"; "r", Bcode.Dict dict]
    | Error (code, s) ->
      ["y", Bcode.String "e"; "e", Bcode.List [Bcode.Int code; Bcode.String s]]
  in
  let d = ("t", Bcode.String t) :: d in
  Bcode.encode (Bcode.Dict d)

let decode s =
  let bc = Bcode.decode s in
  let t = Bcode.to_string (Bcode.find "t" bc) in
  let y = Bcode.to_string (Bcode.find "y" bc) in
  let msg = match y with
    | "q" ->
      let q = Bcode.to_string (Bcode.find "q" bc) in
      let a = Bcode.to_dict (Bcode.find "a" bc) in
      Query (q, a)
    | "r" ->
      let r = Bcode.to_dict (Bcode.find "r" bc) in
      Response r
    | "e" ->
      begin match Bcode.to_list (Bcode.find "e" bc) with
      | Bcode.Int n :: Bcode.String s :: _ -> Error (n, s)
      | _ -> failwith "KRPC.decode: bad fields for 'e' entry"
      end
    | _ ->
      failwith (Printf.sprintf "KRPC.decode: unknown message type y %S" y)
  in
  (t, msg)

module Assoc2 : sig
  type ('a, 'b, 'c) t
  val create : unit -> ('a, 'b, 'c) t
  val add : ('a, 'b, 'c) t -> 'a -> 'b -> 'c -> unit
  val find : ('a, 'b, 'c) t -> 'a -> 'b -> 'c option
  val remove : ('a, 'b, 'c) t -> 'a -> 'b -> unit
  val clear : ('a, 'b, 'c) t -> unit
  val iter : ('a -> 'b -> 'c -> unit) -> ('a, 'b, 'c) t -> unit
end = struct
  type ('a, 'b, 'c) t = ('a, ('b, 'c) Hashtbl.t) Hashtbl.t
  let create () = Hashtbl.create 3
  let add h a b c =
    let hh = try Hashtbl.find h a with Not_found -> Hashtbl.create 3 in
    Hashtbl.add hh b c;
    Hashtbl.replace h a hh
  let find h a b =
    try Some (Hashtbl.find (Hashtbl.find h a) b) with Not_found -> None
  let remove h a b =
    try Hashtbl.remove (Hashtbl.find h a) b with Not_found -> ()
  let clear h =
    Hashtbl.clear h
  let iter f h =
    Hashtbl.iter (fun a h -> Hashtbl.iter (fun b c -> f a b c) h) h
end

type answer_func = Addr.t -> string -> (string * Bcode.t) list -> msg

type rpc =
  | Error
  | Timeout
  | Response of Addr.t * (string * Bcode.t) list

type t = {
  sock : UDP.socket;
  answer : answer_func;
  pending : (Addr.t, string, rpc Lwt.u * float) Assoc2.t
}

let create answer port =
  { sock = UDP.create_socket ~port (); answer; pending = Assoc2.create () }

let read_one_packet krpc =
  UDP.recv krpc.sock >>= fun (s, addr) ->
  let (t, msg) = decode s in
  match msg with
  | Error (code, msg) ->
    begin match Assoc2.find krpc.pending addr t with
    | None -> 
      debug "no t:%S for %s" t (Addr.to_string addr)
    | Some (w, _) ->
      Assoc2.remove krpc.pending addr t;
      Lwt.wakeup w Error
    end;
    Lwt.return ()
  | Query (name, args) ->
    let ret = krpc.answer addr name args in
    UDP.send krpc.sock (encode t ret) addr
  | Response args ->
    begin match Assoc2.find krpc.pending addr t with
    | None ->
      debug "no t:%S for %s" t (Addr.to_string addr);
      Lwt.return ()
    | Some (w, _) ->
      Assoc2.remove krpc.pending addr t;
      Lwt.wakeup w (Response (addr, args));
      Lwt.return ()
    end

let rec read_loop krpc =
  read_one_packet krpc >>= fun () -> read_loop krpc

let fresh_txn =
  let last = ref 0 in
  fun () ->
    let id = string_of_int !last in
    incr last;
    id

let timeout_check_delay = 5.0

let rec timeout_pulse krpc =
  let now = Unix.time () in
  let bad = ref [] in
  Assoc2.iter
    (fun addr t (w, at_most) -> if at_most < now then bad := (addr, t, w) :: !bad)
    krpc.pending;
  List.iter
    (fun (addr, t, w) -> Assoc2.remove krpc.pending addr t; Lwt.wakeup w Timeout)
    !bad;
  Lwt_unix.sleep timeout_check_delay >>= fun () -> timeout_pulse krpc

let start krpc =
  Lwt.async (fun () -> read_loop krpc);
  Lwt.async (fun () -> timeout_pulse krpc)

let timeout_delay = 20.0

let send_msg krpc msg addr =
  let t = fresh_txn () in (* FIXME only outstanding queries need be unique *)
  let wait, w = Lwt.wait () in
  Assoc2.add krpc.pending addr t (w, Unix.time () +. timeout_delay);
  let s = encode t msg in
  debug "send msg to %s : %S" (Addr.to_string addr) s;
  UDP.send krpc.sock s addr >>= fun () -> wait
