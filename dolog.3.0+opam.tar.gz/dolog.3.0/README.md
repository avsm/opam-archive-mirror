dolog
=====

Minimalistic lazy logger in OCaml

Dolog was initially created for console applications, has
optional coloring of log levels and optional
user-defined prefix of log messages (called "sections").

WARNING: dolog uses local time to timestamp messages, _NOT_ GMT.

lib_test/example.ml and lib_test/test.ml are working examples.
