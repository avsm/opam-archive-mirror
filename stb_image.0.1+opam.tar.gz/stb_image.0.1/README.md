Stb\_image is an OCaml binding to stb\_image from Sean Barrett, [Nothings](http://nothings.org/):

  stb\_image.h: public domain C image loading library

The OCaml binding is released under CC-0 license.  It has no dependency beside
working OCaml and C compilers (stb\_image is self-contained).

```shell
$ make
$ make install
```
