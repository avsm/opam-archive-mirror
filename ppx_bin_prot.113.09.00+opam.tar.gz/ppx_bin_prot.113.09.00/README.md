Generation of binary serialization and deserialization functions from type definitions.

For documentation & examples, see: 
    ../../lib/bin_prot/README.md
    
