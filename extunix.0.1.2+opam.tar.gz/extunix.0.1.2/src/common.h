
#define UNUSED(x) (void)(x)

#define Val_none Val_int(0)
#define Some_val(v) Field(v,0)

int extunix_open_flags(value);
