Version 0.8.2 (2016-05-02):
---------------------------
  - Support ctypes-0.6

Version 0.8.1 (2016-05-02):
---------------------------
  - Replaced Oasis as a build system with OCamlbuild. Made sure code
    works with 4.03.0.

Version 0.8.0 (2016-01-25):
---------------------------
  - Expose all of the probability distribution functions that are
    present in the Cephes library.

Version 0.1.2 (2015-10-23):
---------------------------
  - carm <carmelo.piccione@gmail.com> added power and a merlin file
  
Version 0.1.1 (2015-08-07):
---------------------------
  - Ocephes first released to opam
