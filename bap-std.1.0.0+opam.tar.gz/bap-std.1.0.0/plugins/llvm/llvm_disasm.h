#ifdef __cplusplus
extern "C" {
#endif

    int disasm_llvm_init();

#ifdef __cplusplus
}
#endif
