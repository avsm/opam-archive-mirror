#!/bin/bash -eu

ocamlbuild p1.cma p1.cmxa