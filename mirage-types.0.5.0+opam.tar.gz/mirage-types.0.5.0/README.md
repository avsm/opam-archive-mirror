This library contains interfaces to build applications that are compatible with
the Mirage operating system.  It defines only interfaces, and no concrete
modules.

See <http://openmirage.org> for more information.
