(* OASIS_START *)
(* DO NOT EDIT (digest: 231cdfdf88f861d4d2e2071496a9d3be) *)
This is the README file for the integration1d distribution.

Integration of functions of one variable.

Collection of integration routines inspired by QUADPACK. Pure OCaml code.

See the files INSTALL.txt for building and installation instructions. 

Home page: http://forge.ocamlcore.org/projects/integration1d/


(* OASIS_STOP *)
