if (x) { doThat() // Some comment
 }