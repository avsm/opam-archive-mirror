if (x) { // Some comment
doThat(); }