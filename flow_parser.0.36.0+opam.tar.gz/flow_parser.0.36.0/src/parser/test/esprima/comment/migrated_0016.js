// line comment
42