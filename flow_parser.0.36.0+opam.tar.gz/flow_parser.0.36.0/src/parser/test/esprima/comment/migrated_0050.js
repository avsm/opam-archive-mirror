/**
 * @type {number}
 */
var a = 5,
    /**
     * @type {number}
     */
    b = 6;
