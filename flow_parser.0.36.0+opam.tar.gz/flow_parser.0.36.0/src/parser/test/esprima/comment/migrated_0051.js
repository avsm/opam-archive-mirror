(/* comment */{
    /* comment 2 */
    p1: null
})
