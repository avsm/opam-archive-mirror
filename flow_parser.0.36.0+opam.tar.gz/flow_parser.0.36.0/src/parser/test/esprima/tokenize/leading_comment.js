/* hello world */  /42/
