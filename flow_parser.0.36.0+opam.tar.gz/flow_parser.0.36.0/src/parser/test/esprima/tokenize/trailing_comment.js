/42/ /* answer */
