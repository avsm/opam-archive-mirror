var x = /[\u0063-b]/u;
