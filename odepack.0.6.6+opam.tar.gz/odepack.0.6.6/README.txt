(* OASIS_START *)
(* DO NOT EDIT (digest: 5bf82926d4f53cc3e730ba335791797e) *)

odepack - Binding to ODEPACK.
=============================

This is a collection of solvers for the initial value problem for ordinary
differential equation systems.

See the file [INSTALL.txt](INSTALL.txt) for building and installation
instructions.

[Home page](http://forge.ocamlcore.org/projects/odepack/)

Copyright and license
---------------------

odepack is distributed under the terms of the GNU Lesser General Public
License version 3.0 with OCaml linking exception.

(* OASIS_STOP *)
