# PPXX: a small extension library for PPX

PPXX contains several utility functions to make PPX preprocessors easier.

There are already several PPX related helper modules:

* Ast_helper of OCaml compier-libs.common
* Ast_convenience of ppx_tools

They are still not enough for my use, so I built ppxx.

