(* To break the circular dependency *)

type t with sexp, bin_io, compare
