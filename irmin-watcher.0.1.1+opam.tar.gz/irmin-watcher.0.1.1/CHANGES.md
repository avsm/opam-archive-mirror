### 0.1.1

- Fix link issue with the inotify backend

### 0.1.0

- Initial release