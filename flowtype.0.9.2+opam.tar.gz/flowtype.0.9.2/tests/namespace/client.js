var ns = require('./namespace')

var bar: string = ns.foo
