/**
 * @providesModule ES6_Default_NamedFunction2
 * @flow
 */

export default function foo():number { return 42; }
