/**
 * @providesModule ES6_Default_NamedFunction1
 * @flow
 */

export default function foo():number { return 42; }
