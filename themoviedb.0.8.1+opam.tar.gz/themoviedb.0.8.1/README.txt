(* OASIS_START *)
(* DO NOT EDIT (digest: 5e16679b37670e3c9398dde2e19c1e2a) *)
This is the README file for the theMovieDb distribution.

API for TheMovieDb.org website

See the files INSTALL.txt for building and installation instructions. 


(* OASIS_STOP *)
