#ifndef _ASM_SIGCONTEXT_H
#define _ASM_SIGCONTEXT_H

#include <sys/cdefs.h>

__BEGIN_DECLS

struct _fpstate {
};

struct sigcontext {
};

__END_DECLS

#endif
