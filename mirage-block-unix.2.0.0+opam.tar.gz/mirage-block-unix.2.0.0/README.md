mirage-block-unix
=================

Unix implementation of the Mirage `BLOCK_DEVICE` interface.

This interface exposes raw. unbuffered I/O (via `O_DIRECT`) to files
and block devices.

E-mail: <mirageos-devel@lists.xenproject.org>
