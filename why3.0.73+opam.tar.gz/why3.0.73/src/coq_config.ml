let realized_theories = [
  ["int"; "Abs"];
  ["int"; "ComputerDivision"];
  ["int"; "EuclideanDivision"];
  ["int"; "Int"];
  ["int"; "MinMax"];
  ["real"; "Abs"];
  ["real"; "FromInt"];
  ["real"; "MinMax"];
  ["real"; "Real"];
  ["real"; "Square"];
  ["floating_point"; "Rounding"];
  ["floating_point"; "Single"];
  ["floating_point"; "Double"];
]
