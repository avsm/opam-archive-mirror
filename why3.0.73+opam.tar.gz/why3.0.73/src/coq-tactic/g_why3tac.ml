(**************************************************************************)
(*                                                                        *)
(*  Copyright (C) 2010-2012                                               *)
(*    François Bobot                                                      *)
(*    Jean-Christophe Filliâtre                                           *)
(*    Claude Marché                                                       *)
(*    Guillaume Melquiond                                                 *)
(*    Andrei Paskevich                                                    *)
(*                                                                        *)
(*  This software is free software; you can redistribute it and/or        *)
(*  modify it under the terms of the GNU Library General Public           *)
(*  License version 2.1, with the special exception on linking            *)
(*  described in file LICENSE.                                            *)
(*                                                                        *)
(*  This software is distributed in the hope that it will be useful,      *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                  *)
(*                                                                        *)
(**************************************************************************)

(*i camlp4deps: "parsing/grammar.cma" i*)

open Why3tac

open Pcoq
open Extrawit
(* *)
let _ =
  try
    let _ =
      Tacinterp.add_tactic "Why3"
        (function
           [s] when Genarg.genarg_tag s = Genarg.StringArgType && true ->
             let s = Genarg.out_gen Genarg.wit_string s in why3tac s
         | [s; n]
           when
             Genarg.genarg_tag s = Genarg.StringArgType &&
             Genarg.genarg_tag n = Genarg.IntArgType && true ->
             let s = Genarg.out_gen Genarg.wit_string s in
             let n = Genarg.out_gen Genarg.wit_int n in why3tac ~timelimit:n s
         | _ -> failwith "Tactic extension: cannot occur")
    in
    List.iter
      (fun (s, l) ->
         Tacinterp.add_primitive_tactic s
           (Tacexpr.TacAtom
              (Util.dummy_loc,
               Tacexpr.TacExtend (Util.dummy_loc, "Why3", l))))
      []
  with e -> Pp.pp (Cerrors.explain_exn e)
let _ =
  Egrammar.extend_tactic_grammar "Why3"
    [[Egrammar.GramTerminal "why3";
      Egrammar.GramNonTerminal
        (Util.dummy_loc, Genarg.StringArgType,
         Extend.Aentry ("prim", "string"), Some (Names.id_of_string "s"))];
     [Egrammar.GramTerminal "why3";
      Egrammar.GramNonTerminal
        (Util.dummy_loc, Genarg.StringArgType,
         Extend.Aentry ("prim", "string"), Some (Names.id_of_string "s"));
      Egrammar.GramTerminal "timelimit";
      Egrammar.GramNonTerminal
        (Util.dummy_loc, Genarg.IntArgType, Extend.Aentry ("prim", "integer"),
         Some (Names.id_of_string "n"))]]
let _ =
  List.iter Pptactic.declare_extra_tactic_pprule
    ["Why3", [Genarg.StringArgType], (0, [Some "why3"; None]);
     "Why3", [Genarg.StringArgType; Genarg.IntArgType],
     (0, [Some "why3"; None; Some "timelimit"; None])]
