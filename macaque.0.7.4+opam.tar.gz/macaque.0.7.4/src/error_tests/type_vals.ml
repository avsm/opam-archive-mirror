open Sql
let _ = <:value< 1 >> = <:value< 1. >>
