let package_name = "ppx_conv_func"

let sections =
  [ ("lib",
    [ ("built_lib_ppx_conv_func", None)
    ],
    [ ("META", None)
    ])
  ]
