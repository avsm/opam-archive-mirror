(** Re-exports middleware *)
let static = Static.m
let debug = Debug.m
