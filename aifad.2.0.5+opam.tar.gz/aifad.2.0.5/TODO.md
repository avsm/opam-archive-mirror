TODO
====

  * better stopping-criterion (theoretical maximum entropy vs. measured one)
  * better most-freq-model
  * reduced error pruning
  * abstraction of model construction
  * error messages (type specifications)
  * CPS for null-splits
