let () = Ocamlbuild_plugin.Options.use_ocamlfind := true
