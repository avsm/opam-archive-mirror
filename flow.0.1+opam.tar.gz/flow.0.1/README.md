flow
====

Exceptionless “systems” library on top of Core and Lwt (and one day Async?)


Build:
======

Just run:
```
omake && omake install
```
(you can control the destination with the standard 'OCAMLFIND_DESTDIR'
variable).