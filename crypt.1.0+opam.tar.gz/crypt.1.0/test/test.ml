open Crypt

let _ = print_endline (crypt Sys.argv.(1) Sys.argv.(2));
