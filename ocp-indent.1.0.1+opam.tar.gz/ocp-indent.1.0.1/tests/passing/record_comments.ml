type t = {
  a : int ;
  (** blablabla *)
  b : int ;
  (** blublublu *)

  c : int ;
  (** ccc *)
}

let _ =
  [ A ;
    (* A *)
    B ;
    (* B *)
  ]
