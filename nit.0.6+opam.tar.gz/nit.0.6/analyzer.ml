(*
 *  This file is part of Nit (Nullability Inference Tool)
 *  Copyright (c)2008,2009 CNRS
 *  Laurent Hubert <first.last@irisa.fr>
 *  Copyright 2013 INRIA Pierre Vittet <pierre.vittet@inria.fr>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *)

(** This is a generic analyzer that need to be specialized with an
    analysis.  It contains an iteration algorithm on the source code
    for the constraint generation and a fix-point iteration algorithm
    for the constraint solving problem. *)
open Javalib_pack
open Sawja_pack
open JBasics
open Javalib
open JProgram

module type ANALYSIS = sig

  module State:Safe.State.S
  module Constraints:Safe.Constraints.S

(*   type abInfo *)
    (** [init p pps st] Initialize entrypoints [pps] in [st] .*)
  val init : JBir.t program -> JBirPP.t list -> State.t -> State.t

  val abstract_init_method_instr :
    Options.analysis_options ->
    JBir.t program ->
    State.t -> JBir.t node -> method_signature -> 
    Constraints.cst list -> Constraints.cst list

  val abstract_method :
    Options.analysis_options ->
    JBir.t program ->
    State.t -> JBir.t node -> method_signature -> 
    ClassMethodSet.t -> Constraints.cst list 
    -> (ClassMethodSet.t*Constraints.cst list)

  val abstract_instruction :
    Options.analysis_options -> 
    JBir.t program ->
    State.t -> JBirPP.t -> JBir.instr -> JBirPP.t list -> 
    Constraints.cst list -> Constraints.cst list

  val abstract_instruction_ex :
    Options.analysis_options -> 
    JBir.t program ->
    State.t -> JBirPP.t -> JBir.instr -> JBirPP.t list -> 
    Constraints.cst list -> Constraints.cst list
    
end

module Make (Analysis:ANALYSIS) : sig
  open Analysis

  val collect_constraints :
    JBir.t program ->
    Options.analysis_options ->
    ClassMethodSet.t -> 
    State.t -> Constraints.cst list

  val solve_constraints :
    ?optimize_join:bool ->
    Constraints.cst list ->
    Constraints.State.t -> Constraints.State.Var.t list -> Constraints.State.t
end = struct
  open Analysis
  module ASolver = Safe.Solver.Make(Constraints)

  module HashPP = Hashtbl.Make(JBirPP)

  (** @raise NoCode if an abstract or native method without annotations
      is encountered (as it cannot be analyzed). *)
  let collect_constraints
      (prog:JBir.t program)
      (opt:Options.analysis_options)
      (excluded:ClassMethodSet.t)
      (abst:State.t)
      : Constraints.cst list =
    Debug.print_debug 2 "collecting instruction constraints...\n";
    let f =
      (fun pp normal_succ exceptional_succ csts ->
         if not (ClassMethodMap.mem 
		   ((JBirPP.get_meth pp).cm_class_method_signature) 
		   prog.parsed_methods)
         then csts
         else
           begin
             let opcode = JBirPP.get_opcode pp in
             let csts = 
	       abstract_instruction 
		 opt prog abst pp opcode normal_succ csts
	     in
             let csts = 
	       abstract_instruction_ex 
		 opt prog abst pp opcode exceptional_succ csts
	     in
               csts
           end
      )
    in
    let csts = 
      ClassMethodMap.fold
        (fun cms (c,_) csts ->
	   if not (ClassMethodSet.mem cms excluded)
	   then
               let (_,ms) = cms_split cms in
	       let pp = JBirPP.get_first_pp_wp c ms in
		 ControlFlowGraph.intra_fold 
		   prog f pp csts
	   else csts
	)
        prog.parsed_methods
        []	
    in
      Debug.print_debug 5 ((string_of_int (List.length csts))^" constraints on instructions collected.\n");
      Debug.print_time 5;
      Debug.print_debug 4 "collecting constraints on methods (nit)...\n";
      let (_,csts) = 
	let cms_set = ClassMethodSet.empty in
	ClassMethodMap.fold
          (fun cms (c,_) (cms_set,csts)->
	     if not (ClassMethodSet.mem cms excluded)
	     then
               let (_,ms) = cms_split cms in
	       let csts = 
		 abstract_init_method_instr opt prog abst c ms csts
	       in
		 abstract_method opt prog abst c ms cms_set csts
	     else 
	       (cms_set,csts)
	  )
          prog.parsed_methods
          (cms_set,csts)
      in
	csts

  let solve_constraints ?(optimize_join=false) =
    ASolver.solve_constraints ~optimize_join ()
end

module Null = Make(NullAAnalysis)
