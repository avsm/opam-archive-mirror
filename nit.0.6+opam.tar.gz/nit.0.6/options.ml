(*
 *  This file is part of Nit (Nullability Inference Tool)
 *  Copyright (c)2008,2009 CNRS
 *  Laurent Hubert <first.last@irisa.fr>
 *  Copyright 2013 INRIA Pierre Vittet <first.last@inria.fr>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *)

(** This modules contains options that are used to tune the analyses.
    The main program may set those options depending on the command
    line arguments and the analyses read those options when needed. *)


open Sawja_pack

type analysis_options = {
  field_annotations : bool;
  method_annotations : bool;
  safe_exception : bool;
  safe_native : bool;
  safe_static : bool;
  safe_array : bool;
  aggressive_native : bool;
  aggressive_array : bool;
  aggressive_static : bool;
  aggressive_field : bool;
  aggressive_parameter : bool;
  aggressive_return : bool; 
  heap_input: ParserType.parsed_heap option;
}

(* if set to true, then analyses try to reduce their memory
   consumption, even if it will consume more time. *)
let spare_memory = ref true
