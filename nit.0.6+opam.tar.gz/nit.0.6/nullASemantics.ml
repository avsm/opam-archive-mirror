(*
 *  This file is part of Nit (Nullability Inference Tool)
 *  Copyright (c)2008,2009 CNRS
 *  Laurent Hubert <first.last@irisa.fr>
 *  Copyright 2013 INRIA Pierre Vittet <first.last@inria.fr>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *)
open Javalib_pack
open JBasics
open Javalib
open Sawja_pack
open JProgram
open JControlFlow
open NullADomains
open JBir


let rho_with_ref_fields (node:'a node) (ref_fields_of_node:FieldSet.t) = 
  match node with
    | Interface _ ->
	(function _ -> AbThis.top ref_fields_of_node)
    | Class cc -> fun v ->
	if AbVal.isInit v then
	  AbThis.bot
	else match AbVal.rawLevel v with
	  | Some c' when extends_class c' cc -> 
	      AbThis.bot
	  | _ -> AbThis.top ref_fields_of_node

let rho (node:'a node) = 
  fun v -> rho_with_ref_fields node (get_all_ref_fields node) v
    
let meth_var c ms = `Method ((),get_name c,ms)

let get_method_domain mvar abSt = AbState.get_method abSt mvar

let tvar_index tv = index (snd tv)

let equal_this cn v_idx =
   match cn.cm_implementation with
    | Native -> (not cn.cm_static) && (0 = v_idx)
     | Java rep -> 
        (not cn.cm_static) && ((tvar_index (List.hd (params (Lazy.force rep)))) = v_idx)

let expr_equal_this cn expr =
  match expr with 
    | Var (_,v) ->
        equal_this cn (index v)
    | _ -> false

let init_clinit_method_instr csts pp_var = 
  let cstslocal =
    {
      AbConstraints.dependencies = [];
      AbConstraints.target = pp_var;
      AbConstraints.transferFun =
        (fun _ ->
	   `PPDomain (AbPP.bot_except_locals AbLocals.init))}
  in
    cstslocal::csts

(*[do_minus_null l idx]: set variable at [idx] as "not null" (NonNull or Raw)*)
let do_minus_null l v_idx =
  AbLocals.set l v_idx (AbVal.minus_null (AbLocals.get l v_idx))

let set_if_var l expr nval = 
  match expr with
    | Var (_,v) -> AbLocals.set l (index v) nval
    | _ -> l

let slval (v:AbVal.t) (equal_this:bool) (c:JBir.t class_node) (t:AbThis.t) =
  if equal_this && AbThis.isAllDef (get_all_ref_fields (Class c)) t
    && (match super_class (Class c) with
          | None -> true
          | Some super -> AbVal.equal v (AbVal.raw (super)))
  then AbVal.raw c
  else v

let lval (lv:int) (pp:JBirPP.t) (t:AbThis.t) (l:AbLocals.t) =
  let eq_this =
    equal_this (JBirPP.get_meth pp) lv in 
    match (JBirPP.get_class pp) with
      | Class c -> slval (AbLocals.get l lv) eq_this c t
      | Interface _ -> (AbLocals.get l lv)

let ioc2c = function
  | Class c -> c
  | Interface _ -> raise IncompatibleClassChangeError

(*Compute the dependancies of an expression.*)
let expr_dep expr prog = 
  let field_dep cn fs = 
    let fcl = resolve_field fs (resolve_class prog cn)
    in
      List.map
        (fun fc ->`Field ((),get_name fc,fs))
        fcl
  in
  let rec expr_dep' expr = 
    match expr with
      | Const _ 
      | Var _  -> []
      | Unop (_,expr) -> expr_dep' expr
      | Binop (_,e1,e2) -> (expr_dep' e1) @ (expr_dep' e2)
      | Field (exprv, cn, fs) ->
          (field_dep cn fs) @ (expr_dep' exprv)
      | StaticField (cn, fs) ->
          (field_dep cn fs)
  in expr_dep' expr

  (*Check if a condition contain an instanceOf operation.*)
let cond_with_instanceOf expr1 expr2 =
  match expr1, expr2 with
    | Unop (InstanceOf _,Var (_,v)), Const (`Int i) -> Some (v,i) 
    | Const (`Int i), Unop (InstanceOf _,Var (_,v)) -> Some (v,i)
    | _ -> None


(*Get the abstract value given to an expression [expr].*)
let expr_val expr pp abSt prog opt =
  let pp_var = pp_var_from_PP pp in
  let get_pp_domain ppvar abSt = AbState.get_PP abSt ppvar in
  let rec expr_val' expr =
    match expr with
      | Const `ANull -> AbVal.NullableInit
      | Const _ -> AbVal.NonNull
      | Var (_,v) -> 
          let dpp = get_pp_domain pp_var abSt in
          let t,l = (AbPP.get_this dpp,AbPP.get_locals dpp) in
            lval (index v) pp t l
      | Unop (Neg _,_)  
      | Unop (ArrayLength,_)  
      | Unop (InstanceOf _,_) 
      | Unop (Conv _,_) -> AbVal.NonNull
      | Unop (Cast _, expr) -> expr_val' expr
      | Binop (ArrayLoad (TBasic _ ), _,_) -> AbVal.nonnull
      | Binop (ArrayLoad (TObject _ ), _,_) ->
          if opt.Options.safe_array then AbVal.top
          else if opt.Options.aggressive_array then AbVal.nonnull
          else AbVal.init
      | Binop (Add _,_,_ )
      | Binop (Sub _,_,_ )
      | Binop (Mult _,_,_)
      | Binop (Rem _,_,_) 
      | Binop (Div _,_,_) 
      | Binop (CMP _,_,_)
      | Binop (IShl ,_,_)| Binop (IShr ,_,_)| Binop (IAnd ,_,_)| Binop (IOr ,_,_)
      | Binop (IXor ,_,_)| Binop (IUshr,_,_) | Binop (LShl ,_,_)| Binop (LShr ,_,_)
      | Binop (LAnd ,_,_)| Binop (LOr ,_,_)| Binop (LXor ,_,_)| Binop (LUshr,_,_)
        -> AbVal.NonNull
      | Field (exprv, cn, fs) ->
          let dpp = 
            get_pp_domain pp_var abSt in
          let t = AbPP.get_this dpp in
            (match fs_type fs with 
               | TBasic _ -> AbVal.bot
               | TObject _ ->
                   let fcl = resolve_field fs (resolve_class prog cn) in
                     List.fold_left
                       (fun curVal fc ->
                          if (not opt.Options.field_annotations )
                          then AbVal.top
                          else if opt.Options.aggressive_field 
                          then AbVal.bot 
                          else 
                            (let eq_this = expr_equal_this
                                             (JBirPP.get_meth pp) exprv in 
                             let objVal = expr_val' exprv in
                             let f_var = 
                               `Field ((),get_name fc,fs) in
                             let ab_f = 
                               AbState.get_field abSt f_var in
                             let ab_f =
                               if (AbVal.isInit objVal) 
                                 || (eq_this  && 
                                     (AbThis.isDef fs t))
                                 || (match AbVal.rawLevel objVal
                                     with 
                                       | Some c -> extends (Class c) fc
                                       | _ -> false)
                               then ab_f
                               else AbVal.join AbVal.null ab_f
                             in 
                               AbVal.join curVal ab_f
                            )
                       )
                       AbVal.bot
                       fcl
            )
      | StaticField (cn, fs) ->
          (match fs_type fs with
             | TBasic _ -> AbVal.bot
             | TObject _ ->
                 let cl = resolve_field fs (resolve_class prog cn) in
                 let default = 
                   if (opt.Options.aggressive_static || 
                       Option.is_some opt.Options.heap_input)
                   then AbVal.nonnull
                   else AbVal.null
                 in
                   List.fold_left
                     (fun curVal c ->
                        let f_var = `Field ((), get_name c, fs) in
                        let f_val = AbState.get_field abSt f_var in
                          AbVal.join curVal f_val
                     )
                     default 
                     cl
          )
  in expr_val' expr

(*This type allows to be more precise when we need to keep the information that
  a value is 'null and only null'.*)
type nullOrVal =
  | NullV
  | AbstrVal of AbVal.t 

(*Convert to a standard abstract val.*)
let nullOrVal2Val nv =
  match nv with
    | NullV -> AbVal.top
    | AbstrVal v -> v 

(*Get abstract vall of an expression (using the raffined nullOrVal type).*)
let expr_null_or_vall expr pp abSt prog opt =
  match expr with
    | Const `ANull -> NullV
    | _ -> AbstrVal (expr_val expr pp abSt prog opt) 

let abstract_init_method_instr opt (c:JBir.t JProgram.node) (msi:method_signature) csts =
  let cn = get_name c in
  let pp_var = `PP ((),cn,msi,0) in
  let m_var = `Method ((),cn,msi) in
  let normal_csts _ = 
    let cstlocals =
      {
        AbConstraints.dependencies = [m_var];
        AbConstraints.target = pp_var;
        AbConstraints.transferFun =
          (fun abSt ->
             `PPDomain
               (if not opt.Options.aggressive_parameter 
                then
                  AbPP.bot_except_locals
                    (AbMethodSig.init_locals c msi (get_method_domain m_var abSt))
                else AbPP.bot))
      }
    and cstthis =
      {
        AbConstraints.dependencies= [m_var];
        AbConstraints.target = pp_var;
        AbConstraints.transferFun =
          (fun abSt ->
             `PPDomain (
               AbPP.bot_except_this
                 (AbMethodSig.get_this (get_method_domain m_var abSt)))
          )
      }
    in cstlocals::cstthis::csts
  in
    if is_static_method (get_method c msi) && ms_equal msi clinit_signature
    then 
      (match opt.Options.heap_input with
         | Some heap ->
             if (not (ClassMap.mem (JProgram.get_name c) heap.ParserType.hp_class))
             then init_clinit_method_instr csts pp_var
             else normal_csts ()
         | None -> init_clinit_method_instr csts pp_var)
    else normal_csts ()


let abstract_method opt (c_in: JBir.t JProgram.node) (msi:method_signature) (cms_done:ClassMethodSet.t) csts =
  (* \forall m', m, overrides(m,m') => M(m')[args] < M(m)[args] *)
  (* \forall m', m, overrides(m,m') => \top_{class(m)} < M(m)[this] *)
  (* \forall m', m, overrides(m,m') => \top_{class(m')} < M(m')[post] *)
  (* c_overrides_or_implements c returns all methods that c overrides
     or implements transitivly, it returns only the first occurence in
     each hierarchy branch*)
  let c_overrides_or_implements c' = 
    let rec interfaces_of_abstract ac = 
      (* looking for method in interfaces of abstract class*)
      let ac_inter = 
	List.map
	  (fun i -> Interface i)
	  (resolve_interface_method' msi ac)
      in
	match super_class ac with
	    None -> ac_inter
	  | Some ac' -> 
	      (*if super_class of abstract class is also abstract,
		then method could be present in super_class interfaces
		...*)
	      if ac'.c_info.c_abstract
	      then (interfaces_of_abstract (Class ac'))@ac_inter
	      else ac_inter
    in
    let interface_list = 
      List.map
        (fun i -> Interface i)
        (resolve_interface_method' msi c')
    in
      match c' with
	| Interface _
	| Class {c_super = None;_}
          -> interface_list
	| Class {c_super = Some c'';_} ->
	    try
	      (Class (resolve_method' msi c''))::interface_list
	    with _ -> 
	      (*If super class is an abstract class, then it
		could not implements the method but its interfaces
		could...*)
	      if c''.c_info.c_abstract
	      then (interfaces_of_abstract (Class c''))@interface_list
	      else interface_list
  in
    (* [create_constraints] first create the constraints between
       (cl,msi) and the first methods in each hierarchy branch
       overriden or implemented by (cl,msi), then it creates
       constraints between the overriden or implemented methods and
       those they overrides or implements themselves, and so on until
       the higher msi methods in the hierarchy are found. [cms_done]
       is used not to generate 2 times the same constraints between 2
       executions of abstract_methods*)
  let rec create_constraints cl cms_d lcsts =
    let cms = (make_cms (get_name cl) msi) in
    let (cms_d,new_csts,over_or_impl_list) = 
      if ClassMethodSet.mem cms cms_d
      then (cms_d,lcsts,[])
      else 
	let m_var = `Method ((),get_name cl,msi) in
	let over_or_impl_list = c_overrides_or_implements cl in
	let new_csts = 	
	  match over_or_impl_list with 
	      [] -> lcsts
	    | _ -> 
		let concrete_not_static = 
		  match get_method cl msi with
		    | ConcreteMethod m 
			when not m.cm_static -> true
		    | _ -> false
		in
		let all_ref_fields = get_all_ref_fields cl in
		let rho_cl = rho_with_ref_fields cl all_ref_fields in
		  List.fold_left
		    (fun l c' ->
		       let m_var' = meth_var c' msi in
		       let all_ref_fields' = get_all_ref_fields c' in
		       let cst_argsthispost =
			 {AbConstraints.dependencies = [m_var; m_var'];
			  AbConstraints.target = m_var;
			  AbConstraints.transferFun =
			     (fun abSt ->
				let abM' = get_method_domain m_var' abSt in
				  `MethodDomain (
				    if AbMethodSig.isBot abM'
				    then 
				      AbMethodSig.bot
				    else
				      let args = 
					AbMethodSig.get_args abM' in
				      let abM = 
					get_method_domain m_var abSt in
				      let abM = 
					AbMethodSig.join_args abM args 
				      in
					if concrete_not_static
					then
					  let this = 
					    rho_cl (AbLocals.get args 0) 
					  in
					    if AbThis.isAllDef
					      all_ref_fields
					      this
					    then abM
					    else 
					      AbMethodSig.join_this 
						abM this
					else abM
				  )
			     )
			 }
		       and cst_post =
			 {AbConstraints.dependencies = [m_var];
			  AbConstraints.target = m_var';
			  AbConstraints.transferFun =
			     (fun abSt ->
				let bot' = AbMethodSig.bot in
				let abM = get_method_domain m_var abSt in
				  `MethodDomain(
				    if AbMethodSig.isBot abM
				    then bot'
				    else AbMethodSig.join_post bot' 
				      (AbThis.top 
					 all_ref_fields')))
			 }
		       in cst_argsthispost::cst_post::l
		    )
		    lcsts
		    over_or_impl_list
	in (ClassMethodSet.add cms cms_d,new_csts,over_or_impl_list)
    in
      (* Apply create constraints on overriden or implemented methods
	 ...*)
      List.fold_left
	(fun (cms_d,ncsts) c' -> 
	   create_constraints c' cms_d ncsts
	)
	(cms_d,new_csts)
	over_or_impl_list
  in
  let is_virtual msi =
    if ((String.compare (ms_name msi) "<init>") = 0 || ms_equal clinit_signature msi)
    then false
    else
      try
        match get_method c_in msi with
          | AbstractMethod _ -> false
          | ConcreteMethod cm -> not (cm.cm_static
                                      || cm.cm_access = `Private)
      with _ -> false
  in
    if not opt.Options.method_annotations then
      let m_var = meth_var c_in msi in
      let toTop =
        {AbConstraints.dependencies = [];
         AbConstraints.target = m_var;
         AbConstraints.transferFun =
	    (fun _abSt ->
	       `MethodDomain
		 (AbMethodSig.join_return
		    (AbMethodSig.init (c_in,msi)) AbVal.top))}
      in
        (cms_done,toTop::csts)
    else
      if is_virtual msi
      then create_constraints c_in cms_done csts
      else (cms_done,csts)
          
let abstract_instruction opt prog pp opcode succs csts =
  let pp_var = pp_var_from_PP pp in
  let get_pp_domain ppvar abSt = AbState.get_PP abSt ppvar in
  let make_csts ?(cstsl=csts) ?(other_dep=[]) transferFun_list =
    List.fold_right
      (fun transferFun lcsts -> 
	 List.fold_right
	   (fun target lcsts -> 
	      let pp_targ = pp_var_from_PP target in
		{AbConstraints.dependencies = pp_var::other_dep;
		 AbConstraints.target = pp_targ;
		 AbConstraints.transferFun = transferFun}::lcsts)
	   succs
	   lcsts)
      transferFun_list
      cstsl
  in

  (*Check if we are in deadCode. *)
  let is_dead abSt  =
    let l = AbPP.get_locals (get_pp_domain pp_var abSt) in
    AbLocals.isBot l 
  in

  let if_alive_local abSt f = 
    match is_dead abSt with
      | true -> AbLocals.bot
      | false -> f
  in
  let if_alive_this abSt f = 
    match is_dead abSt with
      | true -> AbThis.bot
      | false -> f
  in
  let if_alive_val abSt f = 
    match is_dead abSt with
      | true -> AbVal.bot
      | false -> f
  in
  let if_alive_meth abSt f = 
    match is_dead abSt with
      | true -> AbMethodSig.bot
      | false -> f
  in

  let is_transient ioc fsi =
    match get_field ioc fsi with
      | ClassField {cf_transient = transient;_} -> transient
      | InterfaceField _ -> false
  and propagate_this ?(f=fun a -> a) =
          (fun abSt -> 
             `PPDomain (AbPP.bot_except_this 
                          (if_alive_this abSt 
                             (f (AbPP.get_this (get_pp_domain pp_var abSt))))))
  in
  let default_prop_locals = 
    fun (a:AbState.t) ->  AbPP.get_locals (get_pp_domain pp_var a)
  in
  let propagate_locals ?(f= default_prop_locals)
      = (fun abSt -> 
           `PPDomain (AbPP.bot_except_locals (if_alive_local abSt (f abSt))))
  in
  (*Function dedicated to the different invoke instructions.*)
  let handle_invoke_and_new typ ret obj cl ms args call_new =
    let (is_special,is_static) = 
      match typ with
        | `Special -> (true,false)
        | `Static -> (false,true)
        | _ -> (false,false)
    in
    let eq_this_obj = 
      match obj with
        | None -> false
        | Some expr -> expr_equal_this (JBirPP.get_meth pp) expr
    in
      (try
         let node = (JBirPP.get_class pp) in
         let cc = ioc2c node in
         let is_init_meth = ms_name ms = "<init>" in
         let abVal_return =
           (match (ms_rtype ms), ret with
              | Some (JBasics.TObject _), Some _ret -> 
                  Some (fun abSt m_var ->
                          if_alive_val abSt 
                            ((if opt.Options.aggressive_return then
                                AbVal.bot
                              else 
                                if not opt.Options.method_annotations 
                                then
                                  AbVal.top
                                else 
                                  let ab_m = 
                                    AbState.get_method abSt m_var 
                                  in
                                    AbMethodSig.get_return ab_m
                             )))
              | Some _, Some _ -> Some (fun _abSt _m_var -> AbVal.bot)
              | _ -> None
           )
         in

         let cstlocals c' lcsts =
           let m_var = `Method ((),get_name c',ms) in
           let default _ =
             (fun abSt -> 
                `PPDomain 
                  (AbPP.bot_except_locals
                     (
                       if_alive_local abSt 
                         (let l = AbPP.get_locals (get_pp_domain pp_var abSt) in
                            match (abVal_return), ret with
                              | Some fret, Some ret_var ->
                                  AbLocals.set l (index ret_var) (fret abSt m_var)
                              | _ -> l)
                     )))
           in
            let default_static _ =
              (fun abSt -> 
                 `PPDomain 
                   (AbPP.bot_except_locals
                      (
                        if_alive_local abSt 
                          (let l = AbPP.get_locals (get_pp_domain pp_var abSt) in
                             match (abVal_return), ret with
                               | Some fret, Some ret_var ->
                                   AbLocals.set l (index ret_var) (fret abSt m_var)
                               | _ -> l)
                      )))
            in                 

             (match c' with
                | Class _ when is_static -> 
                    make_csts ~cstsl:lcsts ~other_dep:[m_var] [default_static ()]
                | Interface _ -> make_csts ~cstsl:lcsts [default ()]
                | Class c when (ms_name ms <> "<init>" 
                                && not (c_equal c cc)) -> 
                    make_csts ~cstsl:lcsts ~other_dep:[m_var] [default ()]
                | Class c ->
                    let c_equal_c_cc = c_equal c cc in
                    let all_ref_fields_c' = get_all_ref_fields c' in
                      make_csts ~cstsl:lcsts ~other_dep:[m_var]
                        [(fun abSt ->
                            `PPDomain (
                              let ab_post _ = 
                                let ab_m = 
                                  AbState.get_method abSt m_var in
                                  AbMethodSig.get_post ab_m
                              in
                              let p = get_pp_domain pp_var abSt in  
                              let l' = AbPP.get_locals p in
                              let l = 
                                (match (call_new, obj) with
                                   | true, Some (Var (_,v)) 
                                     ->
                                       (*If we are in allocating a new, we
                                        can explictly state that it is not
                                        null.*)
                                       AbLocals. set l' (index v) 
                                  AbVal.nonnull
                                  | _ -> l'
                                )
                              in
                              (*add return variable*)
                              let l = 
                                match (abVal_return), ret with
                                  | Some fret, Some ret_var ->
                                      AbLocals.set l (index ret_var) 
                                        (fret abSt m_var)
                                  | _ -> l
                              in 
                              let t = AbPP.get_this p in
                                AbPP.bot_except_locals
                                  (if_alive_local abSt
                                     (

                                       (if (is_init_meth ||
                                            (c_equal_c_cc
                                             &&
                                             (match super_class c' with
                                                | None -> 
                                                    AbVal.less_than 
                                                      (AbLocals.get l 0) 
                                                      AbVal.rawtop
                                                | Some c'' -> 
                                                    AbVal.less_than 
                                                      (AbLocals.get l 0) 
                                                      (AbVal.raw c''))
                                             && 
                                             AbThis.isAllDef
                                               all_ref_fields_c' 
                                               (AbThis.meet (ab_post ()) t)))
                                        && eq_this_obj
                                        then
                                          let ab_this =
                                            let l0 = AbLocals.get l 0 in
                                              try AbVal.meet l0 (AbVal.raw c)
                                              with AbVal.NoMeet -> l0
                                          in AbLocals.set l 0 ab_this
                                          else l)))))]
             )

          and cstmethod_args c lcsts =
            let m_var = `Method ((),get_name c,ms) in
            let deps = 
              List.fold_left 
                (fun odep arg -> (expr_dep arg prog)@odep)
                [pp_var; m_var]
                args
            in
            let deps =
              match obj with 
                | None -> deps 
                | Some obj -> (expr_dep obj prog)@deps
            in
              { 
                AbConstraints.dependencies = deps;
                AbConstraints.target = m_var;
                AbConstraints.transferFun =
                  (fun abSt ->
                     `MethodDomain
                       (let ab_m = AbState.get_method abSt m_var in
                          if_alive_meth abSt
                            (
                              let new_args =
                                if is_static
                                then
                                  (let pos = ref (-1) in
                                     List.fold_left 
                                       (fun nl arg ->
                                          pos := !pos +1; 
                                          AbLocals.set nl !pos 
                                            (expr_val arg pp abSt prog opt)
                                       ) AbLocals.init args )
                                else
                                  (
                                    let ab_l0 =
                                      if (is_special
                                          && (not eq_this_obj)
                                          && is_init_meth)
                                      then 
                                        AbVal.rawtop
                                      else
                                        (match obj with
                                           | None -> assert false
                                           | Some obj -> 
                                               AbVal.minus_null
                                                 (expr_val obj pp abSt prog 
                                                    opt))
                                    in 
                                    let pos = ref 0 in
                                      List.fold_left 
                                        (fun nl arg ->
                                           pos:= !pos+1; 
                                           AbLocals.set nl !pos 
                                             (expr_val arg pp abSt prog 
                                                opt)
                                        ) 
                                        (AbLocals.set AbLocals.init 0 ab_l0) 
                                        args 
                                  )
                              in
                                AbMethodSig.join_args ab_m new_args)))
              }
                  ::lcsts
          and cstmethod_this c lcsts =
            let m_var = `Method ((),get_name c,ms) in
              if is_static
              then lcsts
              else
                (
                  let deps = 
                    match obj with 
                      | None -> [pp_var; m_var]
                      | Some obj -> (expr_dep obj prog)@([pp_var; m_var])
                  in
                  {AbConstraints.dependencies = deps;
                  AbConstraints.target = m_var;
                  AbConstraints.transferFun =
                    (fun abSt ->
                         `MethodDomain(
                         if_alive_meth abSt 
                           (
                             let p = get_pp_domain pp_var abSt in
                             let ab_m = 
                               AbState.get_method abSt m_var in  
                               match c with
                                 | Class c when c_equal c cc 
                                   && eq_this_obj  ->
                                     let t = AbPP.get_this p in
                                       AbMethodSig.join_this ab_m t
                                 | _ ->
                                     let l = AbPP.get_locals p in
                                       if AbLocals.isBot l 
                                       then AbMethodSig.bot
                                       else
                                         let ab_obj = 
                                           if is_special
                                           && not eq_this_obj
                                           && is_init_meth
                                           then 
                                             AbVal.rawtop
                                           else 
                                             (match obj with
                                                | None -> assert false
                                                | Some expr -> expr_val expr pp
                                                                 abSt prog opt
                                             )
                                         in
                                           AbMethodSig.join_this 
                                             ab_m (rho c ab_obj))))}::lcsts)

 	      and cstthis c lcsts = 
		match c with
		  | Interface _ -> make_csts ~cstsl:lcsts [propagate_this]
		  | Class c' ->
		      if is_static then 
			make_csts ~cstsl:lcsts [propagate_this]
		      else
			let m_var = `Method ((),get_name c,ms) in
                        let c_equal_cc_c' = c_equal c' cc in
                          make_csts ~cstsl:lcsts ~other_dep:[m_var]
                            [(fun abSt ->
                                `PPDomain(
                                  let p = get_pp_domain pp_var abSt in
                                  let t = AbPP.get_this p in
                                    AbPP.bot_except_this
                                      (if_alive_this abSt
                                         (if eq_this_obj
                                          && c_equal_cc_c'
                                          then 
                                            let ab_m = 
                                              AbState.get_method abSt m_var in
                                              AbThis.meet t
                                                (AbMethodSig.get_post ab_m)
                                              else t))
                                ))]
       in List.fold_left
            (fun lcsts c ->
               cstmethod_args c (cstthis c (cstlocals c (cstmethod_this c lcsts))))
            csts
            cl
      with IncompatibleClassChangeError  -> csts
         | NoClassDefFoundError -> csts
            )
       in

  let handle_invoke typ ret obj ms args =
    let cl =
      match JBirPP.static_lookup prog pp with
        | None -> []
        | Some cl -> cl
    in
    handle_invoke_and_new typ ret obj cl ms args false
  in
    
  let handle_new var cn ms args = 
    let cl = [JProgram.get_node prog cn;] in
     handle_invoke_and_new `Special None (Some (Var (TObject (TClass cn),var))) 
       cl ms args true
  in
    (*end of handle_invoke*)
    (*Start looking at opcodes*)
    match opcode with
      | Return opt_retv -> 
	  let c = JBirPP.get_class pp
          and ms = let m = JBirPP.get_meth pp in m.cm_signature
	  in
	  let m_var = `Method ((),get_name c,ms) in
	  let cstpost lcsts = {
	    AbConstraints.dependencies = [pp_var; m_var];
	    AbConstraints.target = m_var;
	    AbConstraints.transferFun =
              (fun abSt ->
                 `MethodDomain(
                   if_alive_meth abSt
                     (let p = get_pp_domain pp_var abSt in
                      let t = AbPP.get_this p in  
                        AbMethodSig.join_post 
                          (AbState.get_method abSt m_var) t)))
	  }::lcsts
	  and cstreturn lcsts = 
            (match opt_retv  with 
               | None -> lcsts
               | Some ret_expr ->
                   let deps = (expr_dep ret_expr prog) @ [pp_var; m_var] in
                     { AbConstraints.dependencies = deps;
                       AbConstraints.target = m_var;
                       AbConstraints.transferFun =
                         (fun abSt ->
                            `MethodDomain(
                              if_alive_meth abSt
                                (let vexpr = expr_val ret_expr pp abSt prog 
                                               opt
                                 in
                                   AbMethodSig.join_return
                                     (AbState.get_method abSt m_var) vexpr)))}
                     ::lcsts
            )
	  in
	    if ms_name ms = "<init>"
	    then (*We initialize every not initialized fields to null (for object).*)
              (
                FieldMap.fold
                  (fun fs f lcsts ->
                     match fs_type fs with
                       | JBasics.TBasic _ -> lcsts
                       | JBasics.TObject _ ->
                           (match f with
                             | InterfaceField _
                             | ClassField {cf_static=true;_} -> lcsts
                             | _ ->
                                 let f_var = `Field ((),get_name c,fs) in
                                   {
                                     AbConstraints.dependencies = 
                                       [f_var;pp_var];
                                     AbConstraints.target = f_var;
                                     AbConstraints.transferFun =
                                       (fun abSt ->
                                          `FieldDomain(
                                            if_alive_val abSt 
                                              (let p = 
                                                 get_pp_domain pp_var abSt in
                                               let t = AbPP.get_this p in
                                                 if AbThis.isDef fs t
                                                 then AbVal.nonnull
                                                 else 
                                                   AbVal.join 
                                                     AbVal.null 
                                                     (AbState.get_field 
                                                        abSt f_var))))
                                   }::lcsts))
                  (get_fields c)
                  (cstpost (cstreturn csts)))
	    else (cstpost (cstreturn csts))
      | Check (CheckNullPointer expr) ->
          (match expr with
             | Unop (Cast _, Var (_,v))
             | Var (_,v) ->
                 let idx = index v in
                 let p_locals = 
                   propagate_locals
                     ~f:(fun abSt -> 
                           if_alive_local abSt
                             (let l = AbPP.get_locals (get_pp_domain pp_var abSt) 
                              in
                                (do_minus_null l idx)))
                 in
                   make_csts [propagate_this; p_locals]
             | Field (_,cn,fs) 
             | StaticField (cn,fs) ->
                 (match fs_type fs with
                    | TObject _ ->
                        let cl = resolve_field fs (resolve_class prog cn)
                        in
                        let cstsfield= 
                          (match cl with
                             | [c] -> 
                                 let f_var = `Field ((),get_name c,fs) in
                                   {
                                     AbConstraints.dependencies = [pp_var];
                                     AbConstraints.target = f_var;
                                     AbConstraints.transferFun =
                                       (fun abSt ->
                                          `FieldDomain (
                                            if_alive_val abSt
                                              ((AbVal.minus_null 
                                                  (AbState.get_field abSt 
                                                     f_var)))
                                          )
                                       )}::csts
                             | _ -> csts
                          )
                        in 
                          make_csts ~cstsl:cstsfield
                            [propagate_this; propagate_locals]
                    | _ -> make_csts [propagate_this; propagate_locals])
             | Const (`Class _ ) -> 
                 make_csts [propagate_this; propagate_locals]
             | _ -> 
                 make_csts [propagate_this; propagate_locals]
                 )
      | MonitorEnter _ 
      | MonitorExit _
      | MayInit _ 
      | Check _ 
      | Formula _ 
      | Goto _
      | Nop -> make_csts [propagate_this; propagate_locals]
      | AffectVar (v,e) ->
          let deps = expr_dep e prog in
          let p_locals = 
            propagate_locals 
              ~f:(fun abSt -> 
                    if_alive_local abSt
                      (let l = AbPP.get_locals (get_pp_domain pp_var abSt) in
                         AbLocals.set l (index v) 
                           (expr_val e pp abSt prog opt))
              )
          in
            make_csts ~other_dep:deps [propagate_this; p_locals]
      | AffectArray (_ar_expr, _idx_var, _af_var) -> 
          make_csts [propagate_this; propagate_locals]
        (*f_var.<cn.fs> = af_var*)
      | AffectField (lhs_expr, cn,fs, rhs_expr) ->
          (match fs_type fs with
             | TBasic _ -> 
                           make_csts [propagate_this; propagate_locals]
             | TObject _ ->
                 (try
                    let cl =
                      List.map ioc2c 
                        (resolve_field fs (resolve_class prog cn))
                    in
                    let node = (JBirPP.get_class pp) in
                    let tf_this c = 
                      let eq_this = expr_equal_this (JBirPP.get_meth pp) lhs_expr in
                        if eq_this && (c_equal (ioc2c node) c)
                        then
                          propagate_this ~f:(fun t -> AbThis.setDef fs t)
                        else 
                          propagate_this ~f:(fun l -> l)
                    in
                    let cstsfield =
                      List.fold_right
                        (fun c lcsts ->
                           let is_transient_c_fs =
                             is_transient (Class c) fs
                           in
                           let deps = (expr_dep rhs_expr prog) @ [pp_var] in
                             {
                               AbConstraints.dependencies = deps;
                               AbConstraints.target =
                                 `Field ((), get_name (Class c), fs);
                               AbConstraints.transferFun =
                                 (fun abSt ->
                                    let p = get_pp_domain pp_var abSt in
                                    let l = AbPP.get_locals p in
                                      `FieldDomain (
                                        if_alive_val abSt 
                                          (if not opt.Options.field_annotations 
                                           then AbVal.top
                                           else if AbLocals.isBot l
                                           then AbVal.bot
                                           else 
                                             let abval = expr_val rhs_expr pp abSt
                                                           prog opt
                                             in 
                                               if is_transient_c_fs
                                               then AbVal.join AbVal.null abval
                                               else abval
                                          ))
                                 )}::lcsts)
                        cl
                        csts
                    in
                      make_csts ~cstsl:cstsfield
                        (List.fold_right
                           (fun c tfs ->
                              (tf_this c)::tfs
                           )
                           cl
                           [propagate_locals;]
                        )
                  with IncompatibleClassChangeError | IllegalAccessError
                  | NoSuchFieldError -> 
                      csts
                 )
          )
      | AffectStaticField (cn, fs, af_expr) ->
          (match fs_type fs with
             | TBasic _ ->
                 make_csts [propagate_this; propagate_locals]
             | TObject _ ->
                 let cl = 
                   resolve_field fs (resolve_class prog cn) 
                 in
                 let cstsfield =
                   List.fold_right
                     (fun c lcsts -> 
                        let is_transient_c_fs = is_transient c fs in
                        let deps = (expr_dep af_expr prog) @ [pp_var] in
                          {AbConstraints.dependencies = deps;
                           AbConstraints.target = 
                             `Field ((),get_name c,fs);
                           AbConstraints.transferFun =
                             (fun abSt ->
                                  `FieldDomain (
                                    if_alive_val abSt
                                      (let abval = expr_val af_expr pp abSt prog
                                                     opt in
                                         if is_transient_c_fs
                                         then AbVal.join AbVal.null abval
                                         else abval)))
                          }::lcsts)
                     cl
                     csts
                 in
                   make_csts ~cstsl:cstsfield
                     [propagate_locals;propagate_this;]
          )
      | Ifd ((cmp, e1,e2),pc) ->
          (match type_of_expr e1, type_of_expr e2 with
            | TBasic _, TBasic _ -> 
                (*We want to rafine compararaison with an instanceof*)
                (match cond_with_instanceOf e1 e2 with
                   | Some (var,boolean) -> 
                      let default_local_prop target = 
                        {
                          AbConstraints.dependencies = [pp_var];
                          AbConstraints.target = target;
                          AbConstraints.transferFun =
                            (fun abSt ->
                               let p = get_pp_domain pp_var abSt in
                                 `PPDomain(
                                   (AbPP.bot_except_locals
                                      (if_alive_local abSt
                                         (AbPP.get_locals p))
                                   )))} in
                      let rafined_local_prop target = 
                        {
                          AbConstraints.dependencies = [pp_var];
                          AbConstraints.target = target;
                          AbConstraints.transferFun =
                            (fun abSt ->
                               let p = get_pp_domain pp_var abSt in
                                 `PPDomain(
                                   (AbPP.bot_except_locals
                                      (if_alive_local abSt
                                         (let l = AbPP.get_locals p in
                                            do_minus_null l (index var)
                                         )))
                                 ))} in
                      let (ppEq,ppNeq) = 
                        if cmp = `Eq then
                          (JBirPP.goto_absolute pp pc,JBirPP.next_instruction pp)
                        else
                          (JBirPP.next_instruction pp,JBirPP.goto_absolute pp pc)
                      in
                      let (ppvEq,ppvNeq) = 
                        (pp_var_from_PP ppEq, pp_var_from_PP ppNeq) in
                      let rafinment = 
                        if (Int32.compare boolean Int32.zero) = 0
                        then (*precision can be improved if condition is false.
                              In this case InstanceOf returns 1 and then var
                              cannot be null.
                              *)
                          [rafined_local_prop ppvNeq; default_local_prop ppvEq]
                        else (*precision can be improved if condition is true.*)
                          [rafined_local_prop ppvEq; default_local_prop ppvNeq]
                      in
                        make_csts ~cstsl:(rafinment@csts) [propagate_this;]
                  | None ->
                      make_csts [propagate_this; propagate_locals])
            | TObject _, TObject _ ->
                let (ppEq,ppNeq) = 
                  if cmp = `Eq then
                    (JBirPP.goto_absolute pp pc,JBirPP.next_instruction pp)
                  else
                    (JBirPP.next_instruction pp,JBirPP.goto_absolute pp pc)
                in
                let (ppvEq,ppvNeq) = 
                  (pp_var_from_PP ppEq, pp_var_from_PP ppNeq) 
                in  
                let cstlocals1 = 
                  let deps = (expr_dep e1 prog) @ (expr_dep e2 prog) @ [pp_var]
                  in
                    {
                      AbConstraints.dependencies = deps;
                      AbConstraints.target = ppvEq;
                      AbConstraints.transferFun =
                        (fun abSt ->
                           let p = get_pp_domain pp_var abSt in
                           let l = AbPP.get_locals p in
                             `PPDomain(
                               (AbPP.bot_except_locals
                                  (if_alive_local abSt
                                     (try
                                       let l = AbPP.get_locals p in
                                       let l0 = expr_null_or_vall 
                                                  e1 pp abSt prog opt
                                       and l1 = expr_null_or_vall 
                                                  e2 pp abSt prog opt
                                       in 
                                         match l0, l1 with
                                           | NullV , AbstrVal v0 
                                           | AbstrVal v0 , NullV when 
                                               AbVal.is_nonnull v0 
                                             -> AbLocals.bot
                                           | NullV, NullV -> l 
                                           | _ ->
                                               let l0 = nullOrVal2Val l0 in 
                                               let l1 = nullOrVal2Val l1 in 
                                               let x =
                                                 AbVal.meet l0 l1
                                               in
                                               let l' = set_if_var l e1 x in
                                                 set_if_var l' e2 x 
                                     with AbVal.NoMeet ->
                                       prerr_endline "NoMeet in IfCmp AEq";
                                       l)))
                        ))
                    }
                and cstlocals2 = 
                  let deps = (expr_dep e1 prog) @ (expr_dep e2 prog) @ [pp_var]
                  in
                  {AbConstraints.dependencies = deps;
                   AbConstraints.target = ppvNeq;
                   AbConstraints.transferFun = 
                     (fun abSt -> 
                        let p = get_pp_domain pp_var abSt in
                        let l0 = expr_null_or_vall 
                                   e1 pp abSt prog opt
                        and l1 = expr_null_or_vall 
                                   e2 pp abSt prog opt
                        in 
                        let l = AbPP.get_locals p in
                          `PPDomain(
                            AbPP.bot_except_locals
                              (if_alive_local abSt
                                 ((match l0, l1 with
                                     | NullV , AbstrVal v0 
                                                 when not (AbVal.is_nonnull v0) 
                                       ->
                                         (match e2 with
                                            | Var (_,v2) -> 
                                                do_minus_null l (index v2)
                                            | _ -> l)
                                     | AbstrVal v0 , NullV when 
                                         not (AbVal.is_nonnull v0)
                                       -> (match e1 with
                                             | Var (_,v) -> do_minus_null l 
                                                              (index v)
                                             | _ -> l)
                                     | NullV, NullV -> AbLocals.bot
                                     | _ -> l
                                  ))))
                     )
                  }
                in
                  make_csts ~cstsl:(cstlocals1::cstlocals2::csts)
                    [propagate_this]
             | _ -> assert false
          )
      | Throw _v -> csts
      | NewArray (v, _, _) ->
          let idx = index v in
          let p_locals = 
            propagate_locals 
              ~f:(fun abSt -> 
                    if_alive_local abSt
                      (let l = AbPP.get_locals (get_pp_domain pp_var abSt) in
                         AbLocals.set l idx AbVal.nonnull))
          in make_csts [propagate_this; p_locals]
      | New (v,cn,argts,args) ->
          let idx = index v in
          let p_locals = 
            propagate_locals 
              ~f:(fun abSt -> 
                    if_alive_local abSt
                    (let l = AbPP.get_locals (get_pp_domain pp_var abSt) in
                      AbLocals.set l idx AbVal.nonnull))
          in
          let ms = make_ms "<init>" argts None in
          let csts = handle_new v cn ms args in
            make_csts ~cstsl:csts [propagate_this; p_locals] 


        (*v=cn.ms(args)*)
      | InvokeStatic (ret,_cn,ms,args) ->
          handle_invoke `Static ret None ms args 
      | InvokeVirtual (ret,obj,_kind,ms,args) ->
          handle_invoke `Virtual ret (Some obj) ms args 
      | InvokeNonVirtual (ret,obj,_cn,ms,args) ->
          handle_invoke `Special ret (Some obj) ms args 

let abstract_instruction opt prog pp opcode succs csts=
  abstract_instruction opt prog pp opcode succs csts

let abstract_instruction_ex opt pp succs csts  =
  let pp_var = pp_var_from_PP pp in
  let get_pp_domain ppvar abSt = AbState.get_PP abSt ppvar in
  let is_dead abSt  =
    let l = AbPP.get_locals (get_pp_domain pp_var abSt) in
    AbLocals.isBot l 
  in

  let if_alive_local abSt f = 
    match is_dead abSt with
      | true -> AbLocals.bot
      | _ -> f
  in
  let if_alive_this abSt f = 
    match is_dead abSt with
      | true -> AbThis.bot
      | _ -> f
  in
  let propagate_this  =
    (fun abSt -> 
       `PPDomain (AbPP.bot_except_this 
                    (if_alive_this abSt 
                       (AbPP.get_this (AbState.get_PP abSt pp_var)))))
  and propagate_locals ?(f=fun a -> a) = 
      (fun abSt -> 
         `PPDomain (AbPP.bot_except_locals 
                      (if_alive_local abSt 
                         (f (AbPP.get_locals (AbState.get_PP abSt pp_var))))))
  in
  let exn = 
    if opt.Options.safe_exception then AbVal.rawtop else AbVal.nonnull
  in
    List.fold_right 
      (fun target lcsts ->
         let exc_var = 
           let exc_h = 
             List.find
               (fun e -> if (e.JBir.e_handler= (JBirPP.get_pc target)) 
                then true 
                else false) 
               (JBir.exc_tbl (JBirPP.get_ir target))
           in exc_h.JBir.e_catch_var 
         in
         let pp_targ = pp_var_from_PP target in
           {AbConstraints.dependencies = pp_var::[];
            AbConstraints.target = pp_targ;
            AbConstraints.transferFun = propagate_locals
                                          ~f:(fun l -> if AbLocals.isBot l 
                                              then AbLocals.bot
                                              else AbLocals.set l (index exc_var) exn)
           }::
           {
             AbConstraints.dependencies = pp_var::[];
             AbConstraints.target = pp_targ;
             AbConstraints.transferFun = propagate_this;
           }::lcsts
      )
      succs
      csts

