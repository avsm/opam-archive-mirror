(*
 *  This file is part of Nit (Nullability Inference Tool)
 *  Copyright (c)2008,2009 CNRS
 *  Laurent Hubert <first.last@irisa.fr>
 *  Copyright 2013 INRIA Pierre Vittet <pierre.vittet@inria.fr>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *)

open Javalib_pack
open JBasics
open Javalib
open Sawja_pack
open JProgram



(* open JControlFlow *)

(* this is not an efficient implementation but it is simple, and it does not
   consume much memory. *)
type cfg =
  | Intra of JBir.t program
  | Modular of JBir.t program
  | Full of JBir.t program


let build_modular_cfg p = Modular p
let build_full_cfg p = Full p
let build_intra_cfg p = Intra p


let intra_fold _prog f pp init =
  let result = ref init in
  let pp_done = Hashtbl.create 100 in
  let todo = ref [pp] in
    while !todo <> [] do
      let pp = List.hd !todo in
      let normal_succ = JBirPP.normal_successors pp
      and exceptional_succ = JBirPP.exceptional_successors pp in
	todo := List.tl !todo;
	result := f pp normal_succ exceptional_succ !result;
	Hashtbl.add pp_done pp ();
	List.iter
	  (fun pp ->
	    if not ((List.mem pp !todo) || (Hashtbl.mem pp_done pp))
	    then todo := pp::!todo)
	  exceptional_succ;
	List.iter
	  (fun pp ->
	    if not ((Hashtbl.mem pp_done pp) || (List.mem pp !todo))
	    then todo := pp::!todo)
	  normal_succ;
    done;
    !result

module HashPP = Hashtbl.Make(JBirPP)

module PPSet = Set.Make (JBirPP)
let inter_fold
    ?(interpp_done = HashPP.create 10000)
    (prog:JBir.t program)
    (excluded:ClassMethodSet.t)
    f
    entrypoints
    (init:'b) : 'b =
  let result = ref init in
  let intrapp_done = HashPP.create 1000 in
  let inter_todo = ref PPSet.empty in
  let intra_todo = ref (List.fold_right PPSet.add entrypoints PPSet.empty) in
  let debug = ref 1 in
    while not (PPSet.is_empty !intra_todo) do
      let pp = PPSet.choose !intra_todo in
      let normal_succ = JBirPP.normal_successors pp
      and exceptional_succ = JBirPP.exceptional_successors pp
      and inter_succ =
        let ppl = 
	  JBirPP.static_pp_lookup prog pp
        in
	  List.filter
	    (fun pp ->
	       let cms = (JBirPP.get_meth pp).cm_class_method_signature in
		 not (ClassMethodSet.mem cms excluded))
	    ppl
      in
        result := f pp normal_succ inter_succ exceptional_succ !result;
        intra_todo := PPSet.remove pp !intra_todo;
        HashPP.add intrapp_done pp ();
        begin
	  let add_intra_todo succ =
	    List.iter
	      (fun pp ->
		 if not (HashPP.mem intrapp_done pp)
		 then intra_todo := PPSet.add pp !intra_todo)
	      succ
	  in
	    add_intra_todo exceptional_succ;
	    add_intra_todo normal_succ;
        end;
        List.iter
	  (fun pp ->
	     if not (HashPP.mem interpp_done pp)
	     then inter_todo := PPSet.add pp !inter_todo)
	  inter_succ;
        if PPSet.is_empty !intra_todo && not (PPSet.is_empty !inter_todo)
        then
	  begin
	    let pp = PPSet.choose !inter_todo in
	      intra_todo := PPSet.singleton pp;
	      inter_todo := PPSet.remove pp !inter_todo;
	      HashPP.add interpp_done pp ();
	      HashPP.clear intrapp_done;
	  end;
	
        if !debug mod 50000 = 0 
        then (
	  debug := 0;
	  Debug.print_time 4;
	  let sizes =
	    Printf.sprintf "intra_todo = %d\ninter_todo = %d\nintrapp_done = %d\ninterpp_done = %d\n"
	      (PPSet.cardinal !intra_todo) (PPSet.cardinal !inter_todo)
	      (HashPP.length intrapp_done) (HashPP.length interpp_done)
	  in 
	    Debug.print_debug 4 sizes
        );
        incr debug
    done;
    !result

