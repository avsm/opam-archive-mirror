(*
 *  This file is part of Nit (Nullability Inference Tool)
 *  Copyright (c)2008,2009 CNRS
 *  Laurent Hubert <first.last@irisa.fr>
 *  Copyright 2013 INRIA Pierre Vittet <first.last@inria.fr>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *)



open Javalib_pack
open Javalib
open JBasics
open NullADomains
open Sawja_pack
open JControlFlow
open JProgram

(** Compute statistics on the result of the null-ability analysis. *)

type stats = {
  read_fields : ClassFieldSet.t; (** Set of fields of reference type that are actually read. *)
  (* TODO : should we add written fields ? this would probably (artifitially) improve the results... *)
  called_methods : ClassMethodSet.t; (** Set of methods that are actually called. *)
  fields : int; (** number of fields (total).*)
  raw_fields : int; (** number of fields declared as Raw.*)
  mbn_fields : int; (** number of fields declared as maybe null.*)
  nn_fields : int; (** number of fields declared as NonNull.*)
  invokes : int; (** total number of invokes*)
  nn_invokes : int; (** virtual invoke on value NonNull *)
  raw_invokes : int; (** virtual invoke on value Raw *)
  mbn_invokes : int; (** virtual invoke on maybe null values (Nullable or NullableInit) *)
  invokes_nn : int; (** invoke of method which return a NonNull reference *)
  invokes_raw : int; (** invoke of method which return a Raw reference *)
  invokes_mbn : int; (** invoke of a method which return a may be null reference *)
  cargs : int; (** total number of reference arguments *)
  nn_cargs : int; (** number of non null reference arguments *)
  raw_cargs : int; (** number of raw reference arguments *)
  mbn_cargs : int; (** number of maybe null reference arguments *)
  args : int; (** total number of reference formal parameters *)
  nn_args : int; (** number of non null reference formal parameters *)
  raw_args : int; (** number of raw reference formal parameters *)
  mbn_args : int; (** number of maybe null reference formal parameters *)
  ret_nn : int; (** declared NonNull return type *)
  ret_raw : int; (** declared Raw return type *)
  ret_mbn : int; (** declared maybe-null return type *)
  getfields : int;  (** number of getfields *)
  nn_getfield : int;  (** number of getfields on non null references *)
  raw_getfield : int;  (** number of getfields on raw references *)
  mbn_getfield : int;  (** number of getfields on Nullable(Init) references *)
  getfield_mbn : int;  (** number of getfields yielding Nullable(Init) references *)
  getfield_raw : int;  (** number of getfields yielding Raw references *)
  getfield_nn : int;  (** number of getfields yielding NonNull references *)
  putfields : int; (** number of putfields *)
  nn_putfield : int; (** number of putfields {b on} non null references *)
  raw_putfield : int; (** number of putfields {b on} Raw references *)
  mbn_putfield : int; (** number of putfields {b on} Nullable(Init) references *)
  putfield_mbn : int; (** number of putfields {b of} Nullable(Init) references *)
  putfield_raw : int; (** number of putfields {b of} Raw references *)
  putfield_nn : int; (** number of putfields {b of} NonNull references *)
  mbn_aaload : int; (** number of array load on Nullable(Init) references *)
  nn_aaload : int; (** number of array load on non-null references *)
  raw_aaload : int; (** number of array load on raw references *)
  mbn_aastore :int; (** number of array store on Nullable(Init) references *)
  nn_aastore :int; (** number of array store on non-null references *)
  raw_aastore :int; (** number of array store on raw references *)
  mbn_aalength :int; (** number of array length on Nullable(Init) references *)
  nn_aalength :int; (** number of array length on non-null references *)
  raw_aalength :int; (** number of array length on raw references *)
  mbn_check :int; (** number of NonNull check on Nullable(Init) references *)
  nn_check :int; (** number of NonNull check length on non-null references *)
  raw_check :int; (** number of NonNull check length on raw references *)

}

let empty_stats = {
  read_fields = ClassFieldSet.empty;
  called_methods = ClassMethodSet.empty;
  fields = 0;
  raw_fields = 0;
  mbn_fields = 0;
  nn_fields = 0;
  invokes = 0;
  nn_invokes = 0;
  mbn_invokes = 0;
  raw_invokes = 0;
  invokes_nn = 0;
  invokes_raw = 0;
  invokes_mbn = 0;
  cargs = 0;
  nn_cargs = 0;
  raw_cargs = 0;
  mbn_cargs = 0;
  args = 0;
  nn_args = 0;
  raw_args = 0;
  mbn_args = 0;
  ret_nn = 0;
  ret_raw = 0;
  ret_mbn = 0;
  getfields = 0;
  mbn_getfield = 0;
  nn_getfield = 0;
  raw_getfield = 0;
  getfield_mbn = 0;
  getfield_raw = 0;
  getfield_nn = 0;
  putfields = 0;
  nn_putfield = 0;
  raw_putfield = 0;
  mbn_putfield = 0;
  putfield_mbn = 0;
  putfield_raw = 0;
  putfield_nn = 0;
  mbn_aaload = 0;
  nn_aaload = 0;
  raw_aaload = 0;
  mbn_aastore = 0;
  nn_aastore = 0;
  raw_aastore = 0;
  mbn_aalength = 0;
  nn_aalength = 0;
  raw_aalength = 0;
  mbn_check = 0;
  nn_check = 0;
  raw_check = 0;
}

let fold_args  prog pp abSt (cargs,nn_cargs,raw_cargs,mbn_cargs) (vtypes, args)
      opt = 
  let expr_val e = NullASemantics.expr_val e pp abSt prog opt in
    List.fold_left2
      (fun (cargs,nn_cargs,raw_cargs,mbn_cargs) cur_arg vtype ->
         match vtype with
           | TBasic _ -> (cargs,nn_cargs,raw_cargs,mbn_cargs)
           | TObject _ ->
               let arg_val = expr_val cur_arg in
                 if AbVal.less_than AbVal.null arg_val
                 then 
                   (succ cargs,nn_cargs,raw_cargs,succ mbn_cargs)
                 else 
                   (if not (AbVal.isBot arg_val)
                    then (succ cargs, nn_cargs, succ raw_cargs, mbn_cargs)
                    else (succ cargs, succ nn_cargs,raw_cargs, mbn_cargs))
      )
      (cargs,nn_cargs,raw_cargs,mbn_cargs)
      args vtypes

let fold_ab_args (args, nn_args ,raw_args, mbn_args) (vtypes, ab_args) =
    List.fold_left2
      (fun (args,nn_args,raw_args,mbn_args) arg_val vtype ->
         match vtype with
           | TBasic _ -> (args,nn_args,raw_args,mbn_args)
           | TObject _ -> 
               if AbVal.less_than AbVal.null arg_val
               then (succ args,nn_args, raw_args,succ mbn_args)
               else 
                 (if not (AbVal.isBot arg_val)
                  then (succ args,nn_args, succ raw_args, mbn_args)
                  else (succ args,succ nn_args,raw_args, mbn_args))

      )
      (args,nn_args,raw_args,mbn_args)
      ab_args vtypes

let stat_expr expr pp abSt stats prog opt = 
  let expr_val e = NullASemantics.expr_val e pp abSt prog opt in
  let rec stat_expr' expr stats = 
    let open JBir in
    match expr with 
      | Const _  
      | Var _ -> stats
      | Unop (ArrayLength, expr_ar) ->
          let abVal = expr_val expr_ar in
            {stats with
                 mbn_aalength =
                   if AbVal.less_than AbVal.null abVal
                   then 
                     succ stats.mbn_aalength
                   else stats.mbn_aalength;
                 nn_aalength = 
                   if AbVal.isBot abVal
                   then succ stats.nn_aalength
                   else stats.nn_aalength;
                 raw_aalength = 
                   if not (AbVal.less_than AbVal.null abVal) &&
                      not (AbVal.isBot abVal)
                   then succ stats.raw_aalength
                   else stats.raw_aalength;

            }
      | Binop (ArrayLoad _, e1, e2) ->
          let abVal = expr_val e1 in
          let nstats = 
            {stats with
                 mbn_aaload =
                   if AbVal.less_than AbVal.null abVal
                   then 
                     succ stats.mbn_aaload
                   else stats.mbn_aaload;
                 nn_aaload = 
                   if AbVal.isBot abVal
                   then succ stats.nn_aaload
                   else stats.nn_aaload;
                 raw_aaload = 
                   if not (AbVal.less_than AbVal.null abVal) &&
                      not (AbVal.isBot abVal)
                   then succ stats.raw_aaload
                   else stats.raw_aaload;

            } in
            stat_expr' e2 (stat_expr' e1 nstats)
      | Binop (_, e1, e2) ->
          stat_expr' e1 (stat_expr' e2 stats)
      | Field (exprv, cn, fs) ->
          let cfs = make_cfs cn fs in
          let field_val  = expr_val expr in
          let obj_val = expr_val exprv 
          in (*Check the field itself*)
          let stats = 
            match fs_type fs with
              | JBasics.TObject _ ->
                  {stats with
                       read_fields =
                         ClassFieldSet.add cfs stats.read_fields;
                       getfield_mbn =
                         if AbVal.less_than AbVal.null field_val
                         then succ stats.getfield_mbn
                         else stats.getfield_mbn;
                       getfield_raw = 
                         if not (AbVal.isInit field_val)
                         && not (AbVal.less_than AbVal.null field_val)
                         then succ stats.getfield_raw 
                         else stats.getfield_raw;
                       getfield_nn = 
                         if AbVal.isBot field_val
                         then succ stats.getfield_nn
                         else stats.getfield_nn;}
              | _ -> stats
          in
          let stats = 
            {stats with
                 getfields = succ stats.getfields;
                 mbn_getfield = 
                   if AbVal.less_than AbVal.null obj_val
                   then succ stats.mbn_getfield
                   else stats.mbn_getfield;
                 nn_getfield = 
                   if (AbVal.isBot obj_val)
                   then succ stats.nn_getfield
                   else stats.nn_getfield;
                 raw_getfield =
                   if not (AbVal.isBot obj_val)
                   && not (AbVal.less_than AbVal.null obj_val)
                   then succ stats.raw_getfield
                   else stats.raw_getfield;
            }
          in stat_expr' exprv stats
      | Unop (_,e) -> stat_expr' e stats
      | _ -> stats
  in
    stat_expr' expr stats



let stat_invoke pp abSt typ ret ms obj args prog stats opt =
  let stat_expr e stats = stat_expr e pp abSt stats prog opt in
  let expr_val e = NullASemantics.expr_val e pp abSt prog opt in
  let cl =
    match JBirPP.static_lookup prog pp with
      | None -> []
      | Some cl -> cl
  in
  let l' = 
    AbPP.get_locals
      (AbState.get_PP abSt 
         (pp_var_from_PP (JBirPP.next_instruction pp))) 
  in
  let (mbni,rawi,nni) =
    (match typ with
       | `Static -> (stats.mbn_invokes,stats.raw_invokes,stats.nn_invokes)
       | _ ->
           let obj_val = (expr_val (Option.get obj)) in
             if AbVal.less_than AbVal.null obj_val
             then
               (succ stats.mbn_invokes, 
                stats.raw_invokes, stats.nn_invokes)
             else (if not (AbVal.isBot obj_val)
             then stats.mbn_invokes, succ stats.raw_invokes, stats.nn_invokes
             else stats.mbn_invokes, stats.raw_invokes, succ stats.nn_invokes)
    ) in
  let (cargs,nn_cargs,raw_cargs,mbn_cargs) =  
    fold_args prog pp abSt (stats.cargs,stats.nn_cargs,stats.raw_cargs,stats.mbn_cargs)
      (ms_args ms, args) opt
  in
  let (ret_mbn,ret_raw,ret_nn) =
    match ms_rtype ms with
      | Some (JBasics.TObject _) ->
          let ret_val' = AbLocals.get l' (JBir.index (Option.get ret)) in  
          if AbVal.less_than AbVal.null ret_val'
          then (succ stats.invokes_mbn, stats.invokes_raw, stats.invokes_nn)
          else if not (AbVal.isBot ret_val')
          then (stats.invokes_mbn, succ stats.invokes_raw, stats.invokes_nn)
          else (stats.invokes_mbn, stats.invokes_raw, succ stats.invokes_nn)
      | _ -> (stats.invokes_mbn, stats.invokes_raw, stats.invokes_nn)
  in
  let stats = 
    {stats with
         called_methods = 
           List.fold_left
             (fun s c -> ClassMethodSet.add 
                           (make_cms (get_name c) ms) s)
             stats.called_methods cl;
         invokes = succ stats.invokes;
         mbn_invokes = mbni;
         raw_invokes = rawi;
         nn_invokes = nni;
         cargs = cargs;
         mbn_cargs = mbn_cargs;
         nn_cargs = nn_cargs;
         raw_cargs = raw_cargs;
         invokes_mbn = ret_mbn;
         invokes_raw = ret_raw;
         invokes_nn = ret_nn;
    }
  in 
  (*check stats for the argument expressions*)
  let stats = List.fold_left (fun stats arg -> stat_expr arg stats) stats args 
  in match obj with
    | None -> stats
    | Some obj -> stat_expr obj stats


let stat_instruction abSt prog pp stats opt = 
  let open JBir in
  let p = (AbState.get_PP abSt (pp_var_from_PP pp)) in
  let l = AbPP.get_locals p in
  let stat_expr e stats = stat_expr e pp abSt stats prog opt in
  let expr_val e = NullASemantics.expr_val e pp abSt prog opt in
    if AbLocals.isBot l then (function _ -> stats)
    else
      function
        | AffectVar (_, expr) ->
            stat_expr expr stats
        | AffectArray (e1, e2, e3) ->
            let abVal = expr_val e1 in
            let stats =
              {stats with 
                   mbn_aastore =
                     if AbVal.less_than AbVal.null abVal
                     then succ stats.mbn_aastore
                     else stats.mbn_aastore;
                   nn_aastore =
                     if AbVal.isBot abVal
                     then succ stats.nn_aastore
                     else stats.nn_aastore;
                 raw_aastore= 
                   if not (AbVal.less_than AbVal.null abVal) &&
                      not (AbVal.isBot abVal)
                   then succ stats.raw_aastore
                   else stats.raw_aastore;
              }
            in
            let stats = stat_expr e1 stats in
            let stats = stat_expr e2 stats in
            stat_expr e3 stats
            (*...*)
        | AffectField (e, _, fs, e') ->
            (*handle rhs (e')*)
            let abval = expr_val e' in
            let stats =
              match fs_type fs with
                | JBasics.TObject _ ->
                    {stats with 
                         putfield_mbn = 
                           if (AbVal.less_than AbVal.null abval)
                           then succ stats.putfield_mbn
                           else stats.putfield_mbn;
                         putfield_raw =
                           if not (AbVal.isInit abval)
                           && not (AbVal.less_than AbVal.null abval)
                           then succ stats.putfield_raw
                           else  stats.putfield_raw;
                         putfield_nn = 
                           if AbVal.isBot abval
                           then succ stats.putfield_nn
                           else stats.putfield_nn
                    }
                | _ -> stats
            in
              (*handle lfs (e)*)
              let abval = expr_val e in
              let stats =
                {stats with
                     putfields = succ stats.putfields;
                     mbn_putfield =
                       if AbVal.less_than AbVal.null abval
                       then 
                         succ stats.mbn_putfield
                       else 
                         stats.mbn_putfield;
                     nn_putfield =
                       if (AbVal.isBot abval)
                       then succ stats.nn_putfield
                       else stats.nn_putfield;
                     raw_putfield = 
                       if not (AbVal.less_than AbVal.null abval)
                       && not (AbVal.isBot abval)
                       then succ stats.raw_putfield
                       else stats.raw_putfield;
                }
              in stat_expr e (stat_expr e' stats)
        | InvokeStatic (ret, _, ms, args) -> 
            stat_invoke pp abSt `Static ret ms None args prog stats opt
        | InvokeVirtual (ret, obj, _ , ms, args) ->
            stat_invoke pp abSt `Virtual ret ms (Some obj) args prog stats opt
        | InvokeNonVirtual (ret, obj, _, ms, args) ->
            stat_invoke pp abSt `NonVirtual ret ms (Some obj) args prog stats opt
        | New (var, cn, args_type, args) -> 
            let ms = make_ms "<init>" args_type None in
            stat_invoke pp abSt `NonVirtual None ms 
              (Some (Var (TObject (TClass cn),var))) args prog stats opt
        | NewArray (_,_, exprlist) ->
            List.fold_left 
              (fun stats expr -> stat_expr expr stats) stats exprlist 
        | Return optexpr ->
            (match optexpr with
              | None -> stats
              | Some e -> stat_expr e stats)
        | AffectStaticField (_,_,expr) ->
            stat_expr expr stats
        | Ifd ((_ , e1 , e2) , _) ->
            stat_expr e1 (stat_expr e2 stats)
        | MonitorEnter e
        | MonitorExit e
        | Throw e -> stat_expr e stats
        | Check (CheckNullPointer e) -> 
            let abval = expr_val e in
              {stats with
                   mbn_check = 
                     if AbVal.less_than AbVal.null abval
                     then succ stats.mbn_check
                     else stats.mbn_check;
                   nn_check = 
                     if (AbVal.isBot abval)
                     then succ stats.nn_check
                     else stats.nn_check;
                   raw_check =
                     if not (AbVal.less_than AbVal.null abval)
                     && not (AbVal.isBot abval)
                     then succ stats.raw_check 
                     else stats.raw_check;
              }
        | _ -> stats

let get_stats : ?remove_packages:string list list -> 
  JBir.t program ->
  ClassMethodSet.t -> 
  AbState.t -> Options.analysis_options -> stats =
  fun ?(remove_packages=[]) prog native abSt opt ->
    Debug.print_debug 2 "browsing the code...\n";
    let fpp = (fun pp _ _ stats ->
                 let rec notPrefix = fun l2 l1 -> match l1,l2 with
                   | e1::l1,e2::l2 when e1=e2 -> notPrefix l2 l1
                   | [],_ -> false
                   | _,_ -> true
                 in
                   if List.for_all 
		     (notPrefix (cn_package (get_name (JBirPP.get_class pp)))) 
		     remove_packages
                   then stat_instruction abSt prog pp stats opt (JBirPP.get_opcode pp) 
                   else stats)
    in
    let stats = 
      ClassMethodMap.fold
        (fun cms (c,_) stats ->
	   if not (ClassMethodSet.mem cms native)
	   then
             let (_,ms) = cms_split cms in
	     let pp = JBirPP.get_first_pp_wp c ms in
	       ControlFlowGraph.intra_fold 
		 prog fpp pp stats
	   else stats
	)
        prog.parsed_methods
	empty_stats
    in
    let stats =
      ClassFieldSet.fold
        (fun cfs stats ->
           let v = AbState.get_field abSt (field_var_from_cfs cfs) in
             if AbVal.isBot v then
               {stats with nn_fields = succ stats.nn_fields}
             else if AbVal.less_than AbVal.null v then
               {stats with mbn_fields = succ stats.mbn_fields}
             else
               {stats with raw_fields = succ stats.raw_fields}
        )
        stats.read_fields
        {stats with fields = ClassFieldSet.cardinal stats.read_fields}
    in
    let stats =
      ClassMethodSet.fold
        (fun cms stats ->
	   let (cni,msi) = cms_split cms in
           let ioc = (resolve_class prog cni) in
           let is_static =
             match get_method ioc msi with
               | AbstractMethod _ -> false
               | ConcreteMethod m -> m.cm_static
           and abm = 
	     AbState.get_method abSt (`Method ((),cni,msi))
           in
           let ab_args = AbMethodSig.get_args abm in
           let (absList, vtypes) = let len = List.length (ms_args msi) in
             match is_static with 
               | true -> (AbLocals.to_list ab_args len), ms_args msi
               | _ -> List.tl (AbLocals.to_list ab_args (len+1)), ms_args msi
           in
           let (args,nn_args,raw_args,mbn_args) =
             fold_ab_args 
               (stats.args,stats.nn_args,stats.raw_args,stats.mbn_args)
               (vtypes,absList) 
           and (ret_mbn,ret_raw,ret_nn) =
             match ms_rtype msi with
               | Some (JBasics.TObject _) ->
                   if AbVal.less_than AbVal.null 
		     (AbMethodSig.get_return abm)
                   then (succ stats.ret_mbn,stats.ret_raw,stats.ret_nn)
                   else if not (AbVal.isBot (AbMethodSig.get_return abm))
                   then (stats.ret_mbn,succ stats.ret_raw,stats.ret_nn)
                   else (stats.ret_mbn,stats.ret_raw,succ stats.ret_nn)
               | _ -> (stats.ret_mbn,stats.ret_raw,stats.ret_nn)
           in
             {stats with
                args = args;
                nn_args = nn_args;
                raw_args = raw_args;
                mbn_args = mbn_args;
                ret_mbn = ret_mbn;
                ret_raw = ret_raw;
                ret_nn = ret_nn;
             }
        )
        stats.called_methods
        stats
    in stats

let print_stats out name version stats =
  (* mem_usage in kB, in Bytes it would overflow. *)
  let mem_usage = ((Gc.quick_stat ()).Gc.top_heap_words/1024) * (Sys.word_size/8) in
  let time = 
    let times = Unix.times () in
      int_of_float ((times.Unix.tms_utime +. times.Unix.tms_stime) *. 1000.)
  in
  let res : (string*string) list =
    [("Name",name);
     ("Total Fields",string_of_int stats.fields);
     ("NN fields",string_of_int stats.nn_fields);
     ("RAW Fields",string_of_int stats.raw_fields);
     ("MBN fields",string_of_int stats.mbn_fields);
     ("total invokes",string_of_int stats.invokes);
     ("NN invokes",string_of_int stats.nn_invokes);
     ("Raw invokes",string_of_int stats.raw_invokes);
     ("MBN invokes",string_of_int stats.mbn_invokes);
     ("invokes NN",string_of_int stats.invokes_nn);
     ("invokes Raw",string_of_int stats.invokes_raw);
     ("invokes MBN",string_of_int stats.invokes_mbn);
     ("total arguments",string_of_int stats.cargs);
     ("NN arguments",string_of_int stats.nn_cargs);
     ("Raw arguments",string_of_int stats.raw_cargs);
     ("MBN arguments",string_of_int stats.mbn_cargs);
     ("total getfields",string_of_int stats.getfields);
     ("getfields on NN",string_of_int stats.nn_getfield);
     ("getfields on Raw",string_of_int stats.raw_getfield);
     ("getfields on MBN",string_of_int stats.mbn_getfield);
     ("getfields of NN",string_of_int stats.getfield_nn);
     ("getfields of RAW",string_of_int stats.getfield_raw);
     ("getfields of MBN",string_of_int stats.getfield_mbn);
     ("total putfields",string_of_int stats.putfields);
     ("putfields on NN",string_of_int stats.nn_putfield);
     ("putfields on RAW",string_of_int stats.raw_putfield);
     ("putfields on MBN",string_of_int stats.mbn_putfield);
     ("putfields of NN",string_of_int stats.putfield_nn);
     ("putfields of RAW",string_of_int stats.putfield_raw);
     ("putfields of MBN",string_of_int stats.putfield_mbn);
     ("total parameters",string_of_int stats.args);
     ("NN parameters",string_of_int stats.nn_args);
     ("Raw parameters",string_of_int stats.raw_args);
     ("MBN parameters",string_of_int stats.mbn_args);
     ("total return",string_of_int (stats.ret_nn+stats.ret_mbn+stats.ret_raw));
     ("NN return",string_of_int stats.ret_nn);
     ("Raw return",string_of_int stats.ret_raw);
     ("MBN return",string_of_int stats.ret_mbn);
     ("NN ArrayLoad",string_of_int stats.nn_aaload);
     ("Raw ArrayLoad",string_of_int stats.raw_aaload);
     ("MBN ArrayLoad",string_of_int stats.mbn_aaload);
     ("NN ArrayStore",string_of_int stats.nn_aastore);
     ("Raw ArrayStore",string_of_int stats.raw_aastore);
     ("MBN ArrayStore",string_of_int stats.mbn_aastore);
     ("NN ArrayLength",string_of_int stats.nn_aalength);
     ("Raw ArrayLength",string_of_int stats.raw_aalength);
     ("MBN ArrayLength",string_of_int stats.mbn_aalength);
     ("NN on Check",string_of_int stats.nn_check);
     ("Raw on Check",string_of_int stats.raw_check);
     ("MBN on Check",string_of_int stats.mbn_check);
     ("Mem usage (MB)",string_of_int (mem_usage/1024));
     ("Time (ms)",string_of_int time);
     ("Version",version)]
  in
    output_string out "# ";
    List.iter
      (fun (s,_) -> output_string out (s^"; "))
      res;
    output_char out '\n';
    List.iter
      (fun (_,s) -> output_string out (s^"; "))
      res;
    output_char out '\n';

