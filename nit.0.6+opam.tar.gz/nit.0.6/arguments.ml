(*
 *  This file is part of Nit (Nullability Inference Tool)
 *  Copyright (c)2008,2009 CNRS
 *  Laurent Hubert <first.last@irisa.fr>
 *  Copyright 2013 INRIA Pierre Vittet <pierre.vittet@inria.fr>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *)

open Javalib_pack
open JBasics
open Options

let sawja_plugin = IFDEF SPLUG THEN true ELSE false ENDIF

(** Either CRA or RTA. Select the analysis used to load the program
    (RTA is much more precise than CRA but is also very sensitive
    to native methods and may therefore produce incomplete
    programs) (the type system then add co-variant and
    contra-variant constraints on types so it does not change the
    analysis). *)
type class_analysis = RTA | CRA

(** Contains all options that can be modified by the command line. *)
type arg_options = {
  mutable class_path : string;
  (** Contains the directories and .jar files separated by columns ':'
      into which the .class files should be looked for.*)
  mutable debug : int;
  (** Level of debugging. 0 = none, 4=currently the highest. *)
  mutable compact : bool;
  (** If [true], analyses should try to reduce their memory
      consumption. *)
  mutable main : (class_method_signature) list;
  (** Main classes to use. cf --main option. *)
  mutable html_output : string option;
  (** If different from [None], it contains the name of the directory
      to which the result should be stored (in HTML). *)
  mutable xml_output : string option;
  (** If different from [None], it contains the name of the file to
      which the result should be stored (in XML). *)
  mutable no_output : bool;
  (** If [true], then Nit can be launched without printing any result (useful
      for timing the analysis). *)
  mutable anno_file_output : string option;
  (** If different from [None], it contains the name of the file to
      which the result should be stored (format suitable for use with
      the Annotation File Utilities
      (http://types.cs.washington.edu/annotation-file-utilities/)). *)
  mutable scc_output : string option;
  (** If different from [None], it contains the name of the file to
      which the Strongly Connected Components including '<clinit>'
      methods of the call graph is stored (in Dot). cf --clinit-scc-output option.*)
  mutable scc_max_size : int;
  (** cf --clinit-scc-size *)
  mutable cycle_output : string option;
  (** If different from [None], it contains the name of the file to
      which the cycles including '<clinit>' methods of the call graph
      is stored (in Dot). cf --clinit-scc-output option.*)
  mutable cycle_max_size : int;
  (** cf --clinit-cycle-size *)
  mutable remove_packages : string list list;
  (** list of packages to exclude from the text, xml, anno_file and html
      output and from the statistics (cf. --stats). *)
  mutable stats_output : bool;
  (** If [true], it outputs on the standard output some stats (in CSV)
      on the null-ability analysis. cf --stats option.*)
  mutable warning_output : bool;
  (** If [true], it outputs a warning on the standard output for each
      unsafe dereference.*)
  mutable class_analysis : class_analysis;
  (** Either CRA or RTA. Select the analysis used to load the program
      (RTA is much more precise than CRA but is also very sensitive to
      native methods and may therefore produce incomplete programs)
      (the type system then add co-variant and contra-variant
      constraints on types so it does not change the analysis). *)
  mutable analysis_options : analysis_options;
  (** Contains options to tune (most often in unsafe ways) the
      analysis.*)
  mutable noDefEntryPoints : bool; (*If true, do not add any default entrypoint + do not init any clinit.*)
}
