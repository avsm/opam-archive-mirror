(*
 *  This file is part of Nit (Nullability Inference Tool)
 *  Copyright (c)2008,2009 CNRS
 *  Laurent Hubert <first.last@irisa.fr>
 *  Copyright 2013 INRIA Pierre Vittet <first.last@inria.fr>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *)


(* sample output with Ernst's format *)
(* package nullability: *)
(* annotation @NonNull: *)
(* annotation @Nullable: *)

(* package java.lang : *)
(* class Object: *)
(* field f : @NonNull //pb : un champs n'est pas définit par un nom *)
(* field g: @Nullable *)
(* method toString()Ljava/lang/String; : *)
(* receiver @NonNull *)
(* parameter 0: @Nullable *)
(* parameter 1: @NonNull *)
(* local 0 # 0 + 45 : @NonNull  (local num # start # length) *)

open NullADomains

open Javalib_pack
open JBasics
open Javalib
open Sawja_pack
open JProgram
open Format
open JBir


module PP = JBirPP (* shortcut *)

let get_local_expr_info expr =
  print_expr expr, type_of_expr expr

(* basic printing functions *)
type bpf = {
  pp_field: 
    fmt:formatter ->
    fs:field_signature -> 
    abval:NullADomains.AbVal.t ->
    unit;
  pp_class:
    fmt:formatter ->
    class_name:class_name ->
    pp_fields:(formatter -> unit) ->
    pp_methods:(formatter -> unit) ->
    pp_warnings:(formatter -> unit) ->
    unit;
  pp_method:
    fmt:formatter ->
    program:JBir.t program ->
    ioc:JBir.t node ->
    meth:JBir.t jmethod ->
    ams:NullADomains.AbMethodSig.t ->
    unit;
  pp_concat_methods:
    fmt:formatter ->
    pf:(formatter -> (method_signature * JBir.t jmethod) -> unit) ->
    data:(method_signature * JBir.t jmethod) list -> unit;
  pp_concat_fields:
    fmt:formatter ->
    pf:(formatter -> field_signature -> unit) ->
    data:field_signature list -> unit;
}

let replace_all ~str ~sub ~by =
  let continue = ref true
  and s = ref str
  and i = ref 0 in
    while !continue do
      let (c,str) = ExtString.String.replace ~str:!s ~sub ~by in
	s := str;
	continue := c;
	incr i
    done;
    (!i,!s)

let pp_concat f pp_open pp_close pp_sep = function
  | [] -> ()
  | a::[] -> pp_open (); f a;pp_close ();
  | a::l ->
      pp_open ();
      f a;
      List.iter (fun a -> pp_sep ();f a) l;
      pp_close ()

let pp_warn_opcode ?(first=ref false) abSt pp fmt prog opt : JBir.instr -> unit =
  let pp_var = pp_var_from_PP pp in
  let l = AbPP.get_locals (AbState.get_PP abSt pp_var)
  and ms2shortstring ms =
    let (_,printable_name) =
      replace_all
        ~str:(snd (replace_all ~str:(ms_name ms) ~sub:"<" ~by:"^"))
        ~sub:">" ~by:"$"
    in
      printable_name ^":("
      ^ (String.concat ""
	   (List.map JDumpBasics.type2shortstring (ms_args ms)))
      ^ ")" ^ JDumpBasics.rettype2shortstring (ms_rtype ms)
  and array2string t = 
    (JDumpBasics.value_signature t^"[]")
  and info expr typ action =
    try
      let (expr_name,_type)= get_local_expr_info expr
      in "Null pointer access: the expression "^expr_name^" may be null."
    with _ ->
      "Null pointer access: the reference of type "
      ^ typ ^ " on which " ^ action ^ " may be null."
  in
  let get_source_line_number pp =
    let default ms pc = ms2shortstring ms ^ ":" ^ string_of_int pc
    and meth = PP.get_meth pp
    in match meth.cm_implementation with
      | Native -> default meth.cm_signature (PP.get_pc pp)
      | Java code ->
          let pc = PP.get_pc pp
          and code = Lazy.force code
          in match JBir.get_source_line_number pc code with
            | Some i -> string_of_int i
            | None -> default meth.cm_signature pc
  in
    if AbLocals.isBot l then ignore
    else function
      | Check (CheckNullPointer expr) ->
          let abVal = NullASemantics.expr_val expr pp abSt prog opt in
          if AbVal.less_than AbVal.null abVal
          then
            let typ = 
              match type_of_expr expr with
                | TObject (TArray (ar_typ )) ->ar_typ
                | TObject _ as typ -> typ
                | _ -> assert false
              in
              let line = get_source_line_number pp
              and message = info expr (array2string typ) "trying to use variable"
              and signature = JDumpBasics.value_signature typ
              in
                if !first
                then first := false
                else pp_print_cut fmt ();
                pp_open_hvbox fmt 2;
                pp_print_string fmt ("<warning line=\"" ^ line ^"\">");
                pp_print_cut fmt ();
                pp_print_string fmt
                  ("<vastore info=\""^message
                   ^"\" signature=\""^signature^"\"/>");
                pp_close_box fmt ();
                pp_print_cut fmt ();
                pp_print_string fmt "</warning>"

      | AffectVar (_v, Binop (ArrayLoad _, e2, _e3)) ->
          let abVal = NullASemantics.expr_val e2 pp abSt prog opt in
            if AbVal.less_than AbVal.null abVal
            then
              let typ = 
                match type_of_expr e2 with
                  | TObject (TArray (ar_typ )) ->ar_typ
                  | TObject _ as typ -> typ
                  | typ -> Printf.printf "type: %s" (array2string typ); assert false
              in
              let line = get_source_line_number pp
              and message = info e2 (array2string typ) "a cell is read"
              and signature = JDumpBasics.value_signature typ
              in
                if !first
                then first := false
                else pp_print_cut fmt ();
                pp_open_hvbox fmt 2;
                pp_print_string fmt ("<warning line=\"" ^ line ^"\">");
                pp_print_cut fmt ();
                pp_print_string fmt
                  ("<vaload info=\""^message
                   ^"\" signature=\""^signature^"\"/>");
                pp_close_box fmt ();
                pp_print_cut fmt ();
                pp_print_string fmt "</warning>"
        (*v1[v2]=v3*)
      | AffectArray (e1, _v2, _v3) ->
          let abVal = NullASemantics.expr_val e1 pp abSt prog opt in
            if AbVal.less_than AbVal.null abVal
            then
              let typ = 
                match type_of_expr e1 with
                  | TObject (TArray (ar_typ )) ->ar_typ
                  | TObject _ as typ -> typ
                  | _ -> assert false
              in
              let line = get_source_line_number pp
              and message = info e1 (array2string typ) "a cell is written"
              and signature = JDumpBasics.value_signature typ
              in
                if !first
                then first := false
                else pp_print_cut fmt ();
                pp_open_hvbox fmt 2;
                pp_print_string fmt ("<warning line=\"" ^ line ^"\">");
                pp_print_cut fmt ();
                pp_print_string fmt
                  ("<vastore info=\""^message
                   ^"\" signature=\""^signature^"\"/>");
                pp_close_box fmt ();
                pp_print_cut fmt ();
                pp_print_string fmt "</warning>"
      | AffectVar  (_v, Unop (ArrayLength , e1)) ->
          let abVal = NullASemantics.expr_val e1 pp abSt prog opt in
            if AbVal.less_than AbVal.null abVal
            then
              let line = get_source_line_number pp
              and message = 
                info e1 "array" "the length is retrieved."
              in
                if !first
                then first := false
                else pp_print_cut fmt ();
                pp_open_hvbox fmt 2;
                pp_print_string fmt ("<warning line=\"" ^ line ^"\">");
                pp_print_cut fmt ();
                pp_print_string fmt
                  ("<arraylength info=\""^message^"\"/>");
                pp_close_box fmt ();
                pp_print_cut fmt ();
                pp_print_string fmt "</warning>"

      | AffectVar (_v, Field (e, cn, fs)) ->
          let abVal = NullASemantics.expr_val e pp abSt prog opt in
            if AbVal.less_than AbVal.null abVal
            then
              let line = get_source_line_number pp
              and message =
                info e
                  (cn_name cn)
                  ("the field "^fs_name fs^" is read")
              and signature = fs_name fs^":"
		^JDumpBasics.type2shortstring (fs_type fs)
              in
                if !first
                then first := false
                else pp_print_cut fmt ();
                pp_open_hvbox fmt 2;
                pp_print_string fmt ("<warning line=\"" ^ line ^"\">");
                pp_print_cut fmt ();
                pp_print_string fmt
                  ("<getfield info=\""^message
                   ^"\" signature=\""^signature^"\"/>");
                pp_close_box fmt ();
                pp_print_cut fmt ();
                pp_print_string fmt "</warning>"

      | AffectField (e, cn, fs, _v2) ->
          let abVal = NullASemantics.expr_val e pp abSt prog opt
          in if AbVal.less_than AbVal.null abVal
          then(
            let line = get_source_line_number pp
            and message = 
              info e
                (cn_name cn)
                ("the field "^fs_name fs^" is written")
            and signature = fs_name fs^":"^JDumpBasics.type2shortstring (fs_type fs)
            in
              if !first
              then first := false
              else pp_print_cut fmt ();
              pp_open_hvbox fmt 2;
              pp_print_string fmt ("<warning line=\"" ^ line ^"\">");
              pp_print_cut fmt ();
              pp_print_string fmt
                ("<putfield info=\""^message
                 ^"\" signature=\""^signature^"\"/>");
              pp_close_box fmt ();
              pp_print_cut fmt ();
              pp_print_string fmt "</warning>")
      | InvokeVirtual (_, obj,kind,ms,_) -> 
          let abVal = NullASemantics.expr_val obj pp abSt prog opt in 
            if AbVal.less_than AbVal.null abVal
            then
              (
              let line = get_source_line_number pp
              and message =
                let (_,ms_name) =
                  replace_all
                    ~str:(snd (replace_all ~str:(ms_name ms) ~sub:"<" ~by:"^"))
                    ~sub:">" ~by:"$"
                in
                  match kind with
                    | VirtualCall t ->
                        info obj
                          (JDumpBasics.object_value_signature t)
                          ("the method "^ms_name^" is called")
                    | InterfaceCall cn  ->
                        info
                          obj
                          (cn_name cn)
                          ("the method "^ms_name^" is called")
              and signature = ms2shortstring ms
              in
                if !first
                then first := false
                else pp_print_cut fmt ();
                pp_open_hvbox fmt 2;
                pp_print_string fmt ("<warning line=\"" ^ line ^"\">");
                pp_print_cut fmt ();
                pp_print_string fmt
                  ("<invoke info=\""^message
                   ^"\" signature=\""^signature^"\"/>");
                pp_close_box fmt ();
                pp_print_cut fmt ();
                pp_print_string fmt "</warning>"
              )
      | InvokeNonVirtual (_,obj, cn,ms,_) ->
          let abVal = NullASemantics.expr_val obj pp abSt prog opt in 
            if AbVal.less_than AbVal.null abVal
            then
              (
              let line = get_source_line_number pp
              and message =
                let (_,ms_name) =
                  replace_all
                    ~str:(snd (replace_all ~str:(ms_name ms) ~sub:"<" ~by:"^"))
                    ~sub:">" ~by:"$"
                in
                  info obj (cn_name cn) ("the method "^ms_name^" is called")
              and signature = ms2shortstring ms
              in
                if !first
                then first := false
                else pp_print_cut fmt ();
                pp_open_hvbox fmt 2;
                pp_print_string fmt ("<warning line=\"" ^ line ^"\">");
                pp_print_cut fmt ();
                pp_print_string fmt
                  ("<invoke info=\""^message
                   ^"\" signature=\""^signature^"\"/>");
                pp_close_box fmt ();
                pp_print_cut fmt ();
                pp_print_string fmt "</warning>"
              )
      | _ -> ()


let pp_warnings prog ioc abSt fmt mmsl opt =
  List.iter
    (function
       | _ms, AbstractMethod _am -> ()
       | _ms, ConcreteMethod {cm_implementation = Native;_} -> ()
       | _ms, ConcreteMethod ({cm_implementation = Java code;_} as cm) ->
           let c = Lazy.force code
           and first = ref true
           in
             Array.iteri
               (fun pc opcode ->
                  let pp = PP.get_pp ioc cm pc
                  in pp_warn_opcode ~first abSt pp fmt prog opt opcode)
               (JBir.code c))
    mmsl


let pp_method_signature fmt ms =
  let (_,printable_name) =
    replace_all
      ~str:(snd (replace_all ~str:(ms_name ms) ~sub:"<" ~by:"^"))
      ~sub:">" ~by:"$"
  in
    pp_print_string fmt (printable_name ^":(");
    pp_concat
      (fun t -> pp_print_string fmt (JDumpBasics.type2shortstring t))
      ignore ignore ignore (ms_args ms);
    pp_print_string fmt (")"^JDumpBasics.rettype2shortstring (ms_rtype ms))

let pp_field_signature fmt fs =
  pp_print_string fmt ((fs_name fs) ^ ":" ^ JDumpBasics.type2shortstring (fs_type fs))

let pp_abVal fmt (v:NullADomains.AbVal.t) =
  if AbVal.isBot v then
    pp_print_string fmt "<NonNull />"
  else if AbVal.isInit v then
    pp_print_string fmt "<NullableInit />"
  else if AbVal.less_than v AbVal.rawtop then
    begin
      match AbVal.rawLevel v with
	| Some c ->
	    pp_print_string fmt ("<Raw class=\"" 
				 ^cn_name (get_name (Class c)) ^ "\" />")
	| None ->
	    pp_print_string fmt "<Raw />"
    end
  else
    begin
      assert (AbVal.equal v AbVal.top);
      pp_print_string fmt "<Nullable />"
    end

let pp_abThis ioc fmt (v:AbThis.t) : unit =
  let fl = get_all_ref_fields ioc in
    if AbThis.isAllDef fl v then
      pp_print_string fmt "<AllDef />"
    else if AbThis.isTop v then
      pp_print_string fmt "<Top />"
    else
      pp_concat
	(fun fsi ->
	   if AbThis.isDef fsi v then
	     (pp_print_string fmt "<Def field=\"";
	      pp_field_signature fmt fsi;
	      pp_print_string fmt "\" />";)
	)
	(fun () -> pp_open_hvbox fmt 0)
	(pp_close_box fmt)
	(pp_print_cut fmt)
	(FieldSet.elements fl)




let xml_bpf =
  let concat =
    (fun ~fmt ~pf ~data ->
       pp_concat
         (pf fmt)
         (fun () -> pp_open_vbox fmt 0)
         (pp_close_box fmt)
         (pp_print_cut fmt)
         data
    )
  in 
    
    {
      pp_class =
        (fun ~fmt ~class_name ~pp_fields ~pp_methods ~pp_warnings ->
           fprintf fmt "@[<hv><class name=\"%s\">@;<0 2>@[<hv>%t@,%t@,%t@]@,</class>@]"
             (cn_name class_name)
             pp_fields
             pp_methods
             pp_warnings
        );
      pp_field = 
        (fun ~fmt ~fs ~abval ->
           fprintf fmt "@[<hv><field descriptor=\"%s:%s\">@;<0 2>@[<hv>%a@]@,</field>@]"
	     (fs_name fs) (JDumpBasics.type2shortstring (fs_type fs))
             pp_abVal abval);
      pp_method =
        (fun ~fmt ~program ~ioc ~meth ~ams ->
           ignore(program);
	   let ms = get_method_signature meth in
	   let all_args args value = 
	       if is_static_method meth
	       then 
		 List.map (fun _ -> value) args
	       else 
		 value::(List.map (fun _ -> value) args)
           in
             let nb_args = 
               if is_static_method meth 
               then List.length (ms_args ms) 
               else (List.length (ms_args ms)) +1
             
             in
           let args =
             let to_list args =
               AbLocals.to_list args nb_args 
             in
             let args = AbMethodSig.get_args ams
             in
               if AbLocals.isBot args
               then 
		 all_args (ms_args ms) AbVal.bot
               else to_list args 
           and ret_val = AbMethodSig.get_return ams
           in
             fprintf fmt "@[<hv><method descriptor=\"%a\">@;<0 2>@[<hv>" pp_method_signature ms;
             pp_open_hvbox fmt 0;
             pp_print_string fmt "<arguments>";
             begin
               pp_concat
	         (pp_abVal fmt)
	         (fun () -> fprintf fmt "@;<0 2>@[<hv>")
	         (pp_close_box fmt)
	         (pp_print_cut fmt)
	         args
             end;
             fprintf fmt "</arguments>@]@,";
             if (ms_rtype ms) <> None then
               begin
	         pp_print_string fmt "<return>";
	         pp_abVal fmt ret_val;
	         pp_print_string fmt "</return>";
	         pp_print_cut fmt ();
               end;
             if not (is_static_method meth) then
               begin
	         fprintf fmt "@[<hv><this>@;<0 2>@[<hv>%a@]@,</this>@]@,"
	           (pp_abThis ioc) (AbMethodSig.get_this ams);
	         fprintf fmt "@[<hv><post>@;<0 2>@[<hv>%a@]@,</post>@]"
	           (pp_abThis ioc) (AbMethodSig.get_post ams)
               end;
             fprintf fmt "@]@,</method>@]"
        );
      pp_concat_methods = concat;
      pp_concat_fields = concat;
    }

let anno_file_abval v =
  if AbVal.less_than AbVal.null v
  then "@Nullable"
  else "@NonNull"

let anno_file_bpf = {
  pp_class =
    (fun ~fmt ~class_name ~pp_fields ~pp_methods ~pp_warnings ->
       if false then pp_warnings Format.err_formatter;
       let (package_string,class_name) =
         let (cn,pn) = cn_simple_name class_name, cn_package class_name in
           ("package " ^String.concat "." (List.rev pn) ^":\n", cn)
       in
         pp_print_string fmt package_string;
         pp_print_string fmt ("class "^class_name^":\n");
         pp_fields fmt;
         pp_methods fmt);
  pp_field =
    (fun ~fmt ~fs ~abval ->
       pp_print_string fmt ("  field "^(fs_name fs) ^":" ^ anno_file_abval abval^"\n"));
  pp_method =
    (fun ~fmt ~program ~ioc ~meth ~ams ->
       ignore (program,ioc);
       let ms = get_method_signature meth in
       let all_args args value = 
	   if is_static_method meth
	   then 
	     List.map (fun _ -> value) args
	   else 
	     value::(List.map (fun _ -> value) args)
       in	 
       let nb_args = 
         if is_static_method meth 
         then List.length (ms_args ms) 
         else (List.length (ms_args ms)) +1

       in
       let args =
         let to_list args =
           AbLocals.to_list args nb_args 
         in
         let args = AbMethodSig.get_args ams
         in
           if AbLocals.isBot args
           then all_args (ms_args ms) AbVal.bot
           else to_list args 
       and ret_val = AbMethodSig.get_return ams
       in
         pp_print_string fmt
           ("  method "^(ms_name ms)
            ^"(" ^ (String.concat "" (List.map JDumpBasics.type2shortstring (ms_args ms)))
            ^ ")" ^ JDumpBasics.rettype2shortstring (ms_rtype ms)
            ^ " : ");
         if (ms_rtype ms) = None then
           pp_print_string fmt "\n"
         else
           pp_print_string fmt (anno_file_abval ret_val ^"\n");
         let args =
           if is_static_method meth
           then args
           else
             let (receiver,args) =
               match args with
                 | hd::tl -> (hd,tl)
                 | [] -> (AbVal.bot,[])
             in
               pp_print_string fmt ("    receiver: " ^ anno_file_abval receiver ^"\n");
               args
         in
           ExtList.List.iteri
             (fun i abval ->
                pp_print_string fmt ("    parameter "^string_of_int i ^":" 
                                     ^ anno_file_abval abval^"\n"))
             args;
    );
  pp_concat_methods = (fun ~fmt ~pf ~data -> List.iter (pf fmt) data);
  pp_concat_fields = (fun ~fmt ~pf ~data -> List.iter (pf fmt) data);
}




let pp_methods bpf program ioc abSt fmt mmsl =
  bpf.pp_concat_methods
    ~fmt
    ~pf:(fun fmt (ms,meth) ->
           let ams = AbState.get_method abSt (`Method ((),get_name ioc,ms))
           in bpf.pp_method ~fmt ~program ~ioc ~meth ~ams)
    ~data:mmsl


let pp_fields bpf _program ioc abSt fmt fsl =
  let abFd fs = AbState.get_field abSt (`Field((),get_name ioc,fs)) in
  bpf.pp_concat_fields
    ~fmt
    ~pf:(fun fmt fs -> bpf.pp_field ~fmt ~fs ~abval:(abFd fs))
    ~data:fsl


let pp_ioc bpf program abSt fmt ioc opt =
  let fsl =
    let fsl =
      FieldMap.key_elements
        (get_fields ioc)
    in
      List.filter
        (fun fs -> 
	   match fs_type fs with
           | (JBasics.TObject _) -> true
           | (JBasics.TBasic _) -> false)
        fsl
  and mmsl = 
    MethodMap.fold (fun ms m l -> (ms,m)::l) (get_methods ioc) []
  in
    bpf.pp_class ~fmt
      ~class_name:(JProgram.get_name ioc)
      ~pp_fields:(fun fmt -> pp_fields bpf program ioc abSt fmt fsl)
      ~pp_methods:(fun fmt -> pp_methods bpf program ioc abSt fmt mmsl)
      ~pp_warnings:(fun fmt -> pp_warnings program ioc abSt fmt mmsl opt)


let pprint_xml_program ?(doPrint=fun _ -> true) abSt fmt prog opt =
  pp_open_vbox fmt 0;
  pp_print_string fmt "<nit>";
  pp_print_break fmt 0 2;
  pp_open_vbox fmt 0;
  JProgram.iter
    (fun ioc ->
       if doPrint ioc
       then (pp_ioc xml_bpf prog abSt fmt ioc opt ; pp_print_cut fmt ()))
    prog;
  pp_close_box fmt ();
  pp_force_newline fmt ();
  pp_print_string fmt "</nit>";
  pp_close_box fmt ()

let pprint_anno_file_program ?(doPrint=fun _ -> true) abSt fmt prog opt =
  pp_print_string fmt "package:\nannotation @NonNull:\nannotation @Nullable:\n\n";
  JProgram.iter
    (fun ioc ->
       if doPrint ioc
       then
         (pp_ioc anno_file_bpf prog abSt fmt ioc opt;
          pp_print_cut fmt ()))
    prog;
  pp_force_newline fmt ()
  
