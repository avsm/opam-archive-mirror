(*
 *  This file is part of Nit (Nullability Inference Tool)
 *  Copyright (c)2008,2009 CNRS
 *  Laurent Hubert <first.last@irisa.fr>
 *  Copyright 2013 INRIA Pierre Vittet <pierre.vittet@inria.fr>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *)

open Javalib_pack
open JBasics
open Javalib
open Sawja_pack
open JProgram
open Format
open Safe

let get_all_ref_fields (i:'a node) =
  FieldMap.fold
    (fun fs _ fset -> 
       match fs_type fs with 
	   TObject _ ->  FieldSet.add fs fset
	 | _ -> fset
    )
    (get_fields i)
    FieldSet.empty
  


let tvar_index tv = JBir.index (snd tv)


 let a3Bir_get_this c ms = 
   match get_method c ms with
     | AbstractMethod _ -> assert false
     | ConcreteMethod cm ->
         (match cm.cm_implementation, cm.cm_static with
            | _, true -> assert false
            | Native,_ -> 0
            | Java rep, false -> 
                tvar_index (List.hd (JBir.params (Lazy.force rep))))


     



module AbVal : sig
  exception NoMeet
    (** raised if [meet v1 v2] is undefined (case meet (Raw c1) (Raw c2)
	where c1 and c2 are not on the same branch of the hierarchy tree.)*)
  type t =
    | NonNull
    | Nullable
    | NullableInit
    | Raw of JBir.t class_node option
  type analysisID = unit
  type analysisDomain = t

  val bot : t
  val top : t
  val raw : JBir.t class_node -> t
  val rawtop : t
  val rawLevel : t -> JBir.t class_node option
  val nonnull : t
  val init : t 
    (** represents all initialized values. *)
  val isBot : analysisDomain -> bool
  val isInit : t -> bool
    (** return true if the value is definitely initialized. Note that
	[isInit init] may return [false] if the domain cannot
	represent all and only all initialized concrete values by an
	abstract value. *)
  val join : ?modifies:bool Pervasives.ref -> t -> t -> t
  val join_ad: ?do_join:bool -> ?modifies:bool Pervasives.ref ->
       t -> analysisDomain -> t
  val meet : t -> t -> t
  val null : t
    (** \alpha(null) *)
  val minus_null : t -> t
    (** [minus_null v] return \alpha(\gamma(v) - \{null\}) with \alpha
	the abstraction function and \gamma the concretization
	function.  It cannot return Nullable. *)
  val equal : t -> t -> bool
  val less_than : t -> t -> bool
  val get_analysis : analysisID -> t -> analysisDomain
  (*[is_nonnull return true if [t] is strictely not null (Raw or NonNull).*)
  val is_nonnull : t -> bool
  val t2string : t -> string
  val pprint : Format.formatter -> t -> unit
end = struct

  exception NoMeet
  type t =
    | NonNull
    | Nullable
    | NullableInit
    | Raw of JBir.t class_node option

  type analysisID = unit
  type analysisDomain = t	

  let bot = NonNull
  let top = Nullable

  let raw c = Raw (Some c)
  let rawtop = Raw None
  let nonnull = NonNull
  let init = NullableInit

  let rawLevel = function
    | Raw c -> c
    | _ -> None

  let null = NullableInit

  let isInit = function
    | NonNull | NullableInit -> true
    | _ -> false

  let isBot = function NonNull -> true | _ -> false


  let minus_null = function
    | Nullable -> Raw None
    | NullableInit -> NonNull
    | o -> o

  let join ?(modifies=ref false) v1 v2 = 
    if v1 ==v2 then v1 
    else match v1,v2 with
      | Nullable,_ 
      | Raw None, Raw _ 
      | Raw _, NonNull 
      | NullableInit, NonNull
      | NullableInit,NullableInit 
      | NonNull,NonNull -> v1

      | _,Nullable
      | Raw _, Raw None 
      | NonNull, Raw _ 
      | NonNull, NullableInit -> modifies:=true; v2

      | Raw _, NullableInit 
      | NullableInit, Raw _ -> modifies:=true; Nullable

      | Raw (Some c1), Raw (Some c2) 
	  -> 
	  if c_equal c1 c2
	  then v1
	  else
	    (modifies:=true;
	     Raw (Some (first_common_super_class c1 c2)))

  let meet v1 v2 = if v1 == v2 then v1
    else match v1,v2 with
      | NonNull,_ 
      | Raw _, Nullable
      | Raw _, Raw None 
      | NullableInit, Nullable
      | NullableInit, NullableInit 
      | Nullable, Nullable -> v1

      | _,NonNull 
      | Nullable, Raw _
      | Raw None, Raw (Some _)
      | Nullable, NullableInit -> v2

      | NullableInit,Raw _
      | Raw _, NullableInit -> NonNull

      | Raw (Some c1), Raw (Some c2) ->
	  if extends_class c1 c2
	  then v1
	  else if extends_class c2 c1
	  then v2
	  else raise NoMeet

  let equal v1 v2 = match v1,v2 with
      | NonNull, NonNull
      | Nullable, Nullable
      | NullableInit,NullableInit
      | Raw None, Raw None
	  -> true
      | Raw (Some c1), Raw (Some c2) -> c_equal c1 c2
      | _, _ -> false

  let join_ad ?(do_join=true) ?(modifies=ref false) v1 v2 =
    if do_join
    then join ~modifies v1 v2
    else if equal v1 v2
    then v1
    else (modifies := true;v2)

  let t2string = function
      | NonNull -> "NonNull"
      | Nullable -> "Nullable"
      | NullableInit -> "NullableInit"
      | Raw None -> "RawTop"
      | Raw (Some cn) -> Printf.sprintf "Raw(%s)" (cn_name (get_name (Class cn)))

  let get_analysis () v = v    

  let is_nonnull v = 
    match v with
      | NonNull | Raw _ -> true
      | _ -> false



  let less_than v1 v2 = equal (join v1 v2) v2

  let pprint fmt v =
    pp_print_string fmt (t2string v)

end


module AbThis : sig
  type t =
      | Bot
      | Top
      | Locals of FieldSet.t
  type analysisID
  type analysisDomain = t
  val bot : t
  val top : FieldSet.t -> t
  val init : t
  val setDef : field_signature -> t -> t
  val isDef : field_signature -> t -> bool
  val isAllDef : FieldSet.t -> t -> bool
  val join : ?modifies:bool ref -> t -> t -> t
  val meet : t -> t -> t
  val isBot : analysisDomain -> bool
  val isTop : t -> bool
  val equal : t -> t -> bool
  val pprint : Format.formatter -> t -> unit
  val get_analysis : analysisID -> t -> analysisDomain
end = struct

  type t =
      | Bot
      | Top
      | Locals of FieldSet.t

  type analysisID = unit
  type analysisDomain = t	
  

  let setDef f = function
    | Bot -> Bot
    | Top -> Locals (FieldSet.singleton f)
    | Locals s as v-> 
	let fs'= FieldSet.add f s in
	  if fs' == s 
	  then v
	  else
	    Locals fs'

  let isDef f = function
    | Bot -> true
    | Top -> false
    | Locals s -> FieldSet.mem f s


  let join ?(modifies=ref false) s1 s2 = 
    if s1 == s2 
    then s1 
    else 
      match s1,s2 with
	| Top,_
        | Locals _, Bot 
	| Bot,Bot -> s1
	| _,Top
        | Bot, Locals _ -> modifies:=true; s2
        | Locals fs1,Locals fs2 -> 
            let fs' = FieldSet.inter fs1 fs2 in
              if FieldSet.equal fs1 fs'
              then s1
              else (modifies:=true;Locals fs')

  let meet s1 s2 =
    if s1 == s2 
    then s1
    else
      match s1,s2 with
	| Locals _, Top
        | Bot, _
	| Top, Top -> s1 
	| Top, Locals _ 
        | _, Bot -> s2
	    
        | Locals fs1,Locals fs2 -> 
            let fs' = FieldSet.union fs1 fs2 in
              if FieldSet.equal fs1 fs'
              then s1
              else Locals fs'

  let isTop = function
    | Top -> true
    | Locals s -> FieldSet.is_empty s
    | Bot -> false

  
  let bot = Bot

  let isBot = (==) Bot

  let isAllDef (all:FieldSet.t) = function
    | Bot -> true
    | Top -> FieldSet.is_empty all
    | Locals _ as t -> not (FieldSet.exists (fun e -> not (isDef e t)) all)

  let top fl = if FieldSet.is_empty fl then Bot else Top
  let init = Top

  let equal s1 s2 =
    if s1==s2 then true
    else match s1,s2 with
      | Locals s1, Locals s2 -> FieldSet.equal s1 s2
      | _,_ -> false

  let pprint fmt s =
    let pp_field_signature fmt fs =
      pp_print_string fmt (JPrint.field_signature fs)
    in
      pp_print_string fmt "def fields = [";
      pp_open_box fmt 0;
      begin
        try
	  match s with
	    | Top -> pp_print_string fmt "Top"
	    | Bot -> pp_print_string fmt "Bot"
	    | Locals s ->
		FieldSet.iter
		    (fun v ->
		       pp_field_signature fmt v;
		       pp_print_string fmt ",";
		       pp_print_space fmt ();
		    )
		    s;
        with Not_found -> ()
      end;
      pp_close_box fmt ();
      pp_print_string fmt "]"

  let get_analysis () v = v    

end


module AbLocals = struct
  include Domain.Local(AbVal) 
  let get d i = get_var i d
  let set d i v = 
    match isBot d with
      | true -> d
      | false -> set_var i v d

  let to_list l nb_locals = 
    let var = ref 0 in
    let lst = ref [] in
      while !var <> nb_locals do
        lst := (get l !var)::!lst;
        var:= !var+1
      done;
      (List.rev !lst)
 



     
  let pprint' p cn ms fmt l=
    let print_string = Format.pp_print_string fmt in 
    let node = (JProgram.get_node p cn) 
    in 
      if isBot l 
      then print_string "Bot"
      else
	let vars = 
	  match (JProgram.get_method node ms) with
	      ConcreteMethod cm -> 
		(match cm.cm_implementation with
		    Native -> assert false
		  | Java laz -> 
		      JBir.vars (Lazy.force laz))
	    | AbstractMethod _ -> assert false
	in
          if (Array.length vars)= 0
          then print_string "[||]"
          else
	      
            let print_loc (i,loc) =
              print_string ((JBir.var_name_g i)^":");
              AbVal.pprint fmt loc
            in
              print_string "[|";
                Array.iter
                  (fun var -> print_string ";";print_loc (var,get l (JBir.index var)))
                  vars;
              print_string "|]"
end




module AbMethodSig = struct

  type t = {args: AbLocals.t ; return: AbVal.t; this: AbThis.t; post:AbThis.t}
      
  type analysisID = unit
  type analysisDomain = t	

  let is_static c ms = 
    match get_method c ms with
      | AbstractMethod _ -> false
      | ConcreteMethod m -> m.cm_static

  let equal v1 v2 : bool =
    AbLocals.equal v1.args v2.args
    && AbVal.equal v1.return v2.return
    && AbThis.equal v1.this v2.this
    && AbThis.equal v1.post v2.post
      
  let bot = 
    let thisbot = AbThis.bot 
    in
      {
       args = AbLocals.bot;
       return = AbVal.bot;
       this = thisbot;
       post = thisbot}

  let isBot t = equal t bot

  let init (c,ms) : t =
    let thistop = AbThis.top (get_all_ref_fields c)
    and thisbot = AbThis.bot
    in
    let is_static = 
      is_static c ms
    in
    let (argsinit, cpt_args) =
      if is_static 
      then AbLocals.init, 0
      else (*add this as first argument*)
        (AbLocals.set_var (a3Bir_get_this c ms) AbVal.top AbLocals.init, 1)
    in
    let (argsinit,_) =
      List.fold_left
	(fun (l,cpt) _arg ->
               (AbLocals.set_var cpt AbVal.top l, cpt+1)
        )
	(argsinit, cpt_args)
	(ms_args ms)
    in	  
      {
       args = argsinit;
       return = AbVal.bot;
       this = thistop;
       post =
	  if is_static 
	  then thistop
	  else thisbot;
      }


  let get_post v = v.post
  let get_args v = v.args
  let get_this v = v.this
  let get_return v = v.return

  let join_post v p =
    {v with post = AbThis.join v.post p}
      
  let join_this v t =
    {v with this = AbThis.join v.this t}
      
  let join_args v a =
    {v with args = AbLocals.join v.args a}
      
  let join_return v r =
    {v with return = AbVal.join v.return r}

  let join ?(modifies=ref false) 
      ({args=a1;return=r1;this=t1;post=p1} as v1) 
      ({args=a2;return=r2;this=t2;post=p2} as v2)  =
    if v1 == v2 
    then v1
    else
      let (ma,mr,mt,mp) = (ref false, ref false, ref false, ref false) in
      let j = 
	{

         args = AbLocals.join ~modifies:ma a1 a2;
	 return = AbVal.join ~modifies:mr r1 r2;
	 this = AbThis.join ~modifies:mt t1 t2;
	 post = AbThis.join ~modifies:mp p1 p2}
      in
	if !ma or !mr or !mt or !mp
	then (modifies:=true; j)
	else v1


  let join_ad ?(do_join=true) ?(modifies=ref false) v1 v2 =
    if do_join
    then join ~modifies v1 v2
    else if equal v1 v2
    then v1
    else (modifies := true;v2)
	 
  let init_locals node ms abm =
    match abm.args with
      | s when AbLocals.isBot s -> AbLocals.bot
      | s ->
          let (_, params) = 
            match (JProgram.get_method node ms) with
              | ConcreteMethod cm ->
                  (match cm.cm_implementation with
                     | Native -> assert false
                     | Java laz ->
                         let bir = (Lazy.force laz) in
                           (JBir.vars bir, JBir.params bir))
              | _ -> assert false
          in
          let pos = ref (-1) in
            List.fold_left
              (fun state (_,curvar) ->
                 pos:=!pos+1;
                 AbLocals.set state (JBir.index curvar) (AbLocals.get s !pos)
              )
              AbLocals.init
              params




  let pprint_static static fmt t =
    pp_open_hvbox fmt 0;
    pp_print_string fmt "args:";
    AbLocals.pprint fmt t.args;
    pp_print_space fmt ();
    pp_print_string fmt "return:";
    AbVal.pprint fmt t.return;
    if not static then
      (pp_print_space fmt ();
        pp_print_string fmt "this:{";
        pp_open_box fmt 0;
        AbThis.pprint fmt t.this;
        pp_close_box fmt ();
        pp_print_string fmt "}";
        pp_print_space fmt ();
        pp_print_string fmt "post:{";
        pp_open_box fmt 0;
        AbThis.pprint fmt t.post;
        pp_close_box fmt ();
        pp_print_string fmt "}";);
    pp_close_box fmt ()


    let pprint fmt t =
      pp_open_hvbox fmt 0;
      pp_print_string fmt "args:";
      AbLocals.pprint fmt t.args;
      pp_print_space fmt ();
      pp_print_string fmt "return:";
      AbVal.pprint fmt t.return;
      pp_print_space fmt ();
      pp_print_string fmt "?this:{";
      pp_open_box fmt 0;
      AbThis.pprint fmt t.this;
      pp_close_box fmt ();
      pp_print_string fmt "}";
      pp_print_space fmt ();
      pp_print_string fmt "?post:{";
      pp_open_box fmt 0;
      AbThis.pprint fmt t.post;
      pp_close_box fmt ();
      pp_print_string fmt "}";
      pp_close_box fmt ()

    let get_analysis () v = v    

end


module AbPP = struct
  

  type t = AbThis.t * AbLocals.t 

  type analysisID = unit

  type analysisDomain = t
  
  let bot = (AbThis.bot,AbLocals.bot)

  let isBot ((t,l):t) =
    AbThis.isBot t && AbLocals.isBot l 

  let get_this =
    function (t,_l) -> t

  let get_locals =
    function (_t,l) -> l

  let bot_except_this this = 
    (this,AbLocals.bot)

  let bot_except_locals locals = 
    (AbThis.bot,locals)

  let join ?(modifies=ref false) ((t1,l1) as v1) ((t2,l2) as v2)  =
    if v1 == v2 
    then v1
    else
      let (mt,ml) = (ref false, ref false) in
      let j = 
	(AbThis.join ~modifies:mt t1 t2, AbLocals.join ~modifies:ml l1 l2)
      in
	if !mt or !ml 
	then (modifies:=true; j)
	else v1

  let equal (t1,l1) (t2,l2) =
    (AbThis.equal t1 t2
     && AbLocals.equal l1 l2)

  let join_ad ?(do_join=true) ?(modifies=ref false) v1 v2=
    if do_join
    then join ~modifies v1 v2
    else if equal v1 v2
    then v1
    else (modifies := true;v2)

  let pprint fmt (abT,abL) = 
    pp_print_string fmt "{";
    pp_open_tag fmt "nullness";
    pp_open_hvbox fmt 0;
    pp_print_string fmt "this:";
    AbThis.pprint fmt abT;
    pp_print_string fmt ",";
    pp_print_space fmt ();
    pp_print_string fmt "locals:";
    AbLocals.pprint fmt abL;
    pp_print_string fmt ",";
    pp_print_space fmt ()

  let pprint' p cn ms fmt (abT,abL) = 
    pp_print_string fmt "{";
    pp_open_tag fmt "nullness";
    pp_open_hvbox fmt 0;
    pp_print_string fmt "this:";
    AbThis.pprint fmt abT;
    pp_print_string fmt ",";
    pp_print_space fmt ();
    pp_print_string fmt "locals:";
    AbLocals.pprint' p cn ms fmt abL;
    pp_print_string fmt ",";
    pp_print_space fmt ()

  let get_analysis () v = v    

end

module AbValR = (AbVal:Safe.Domain.S
                   with type t = AbVal.t
                   and type analysisDomain = AbVal.t
                   and type analysisID = AbVal.analysisID)
module AbPPR = (AbPP:Safe.Domain.S
                   with type t = AbPP.t
                   and type analysisDomain = AbPP.t
                   and type analysisID = AbPP.analysisID)
module AbMethodSigR = (AbMethodSig:Safe.Domain.S
                   with type t = AbMethodSig.t
                   and type analysisDomain = AbMethodSig.t
                   and type analysisID = AbMethodSig.analysisID)

module ED = Domain.Empty 
module Var = Var.Make(Var.EmptyContext)
module AbState = State.Make(Var)(ED)(ED)(AbValR)(AbMethodSigR)(AbPPR)
module AbConstraints = Constraints.Make(AbState)

let pp_var_from_PP pp = 
  let (cn,ms) = 
    cms_split ((JBirPP.get_meth pp).cm_class_method_signature)
  in
  let pc = JBirPP.get_pc pp in
    `PP ((),cn,ms,pc)

let method_var_from_PP pp = 
  let (cn,ms) = 
    cms_split ((JBirPP.get_meth pp).cm_class_method_signature)
  in
    `Method ((),cn,ms)

let field_var_from_cfs cfs =
  let (cn,fs) = cfs_split cfs in
    `Field ((),cn,fs)

let get_hinfo program (abSt:AbState.t) info : JPrintHtml.info =
    {info with
       JPrintHtml.p_field =
        (fun cni fsi ->
           let my_info =
	     let v = 
	       let f_var = `Field ((),cni,fsi) in
		 AbState.get_field abSt f_var
	     in
               "@"^AbVal.t2string v
           in my_info::(info.JPrintHtml.p_field cni fsi)
	);

       JPrintHtml.p_method =
        (fun cni msi ->
           let my_info =
               let static =
                 try
                   let c = JProgram.get_node program cni
                   in is_static_method (JProgram.get_method c msi)
                 with _ -> false
               and v = 
		 let m_var = `Method ((),cni,msi) in
		 AbState.get_method abSt m_var
	       in
	         AbMethodSig.pprint_static static Format.str_formatter v;
                 "{"^Format.flush_str_formatter () ^"}"
           in my_info::(info.JPrintHtml.p_method cni msi)
	);

       JPrintHtml.p_pp =
        (fun cni msi i ->
           let my_info =
	     let pp_var = `PP((),cni,msi,i) in
	     let ab = AbState.get_PP abSt pp_var
	     in
	       AbPP.pprint' program cni msi Format.str_formatter ab;
               Format.flush_str_formatter ()
           in my_info::(info.JPrintHtml.p_pp cni msi i)
	);
    }
