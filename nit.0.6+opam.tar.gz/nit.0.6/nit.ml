(*
 *  This file is part of Nit (Nullability Inference Tool)
 *  Copyright (c)2008,2009 CNRS
 *  Copyright (c)2010 INRIA
 *  Laurent Hubert <first.last@irisa.fr>
 *  Vincent Monfort <first.last@irisa.fr>
 *  Copyright 2013 INRIA Pierre Vittet <pierre.vittet@inria.fr>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *)
(*let _ = Printexc.record_backtrace true*)
let version = "Nit 0.6"
(** This is the main module of the program.*)

open Javalib_pack
open Sawja_pack
open JBasics
open Javalib
open JProgram
open Options
open Arguments

let _print_info = Debug.print_debug 2



let _ = Printexc.record_backtrace true 

module NullAnalysis = NullAAnalysis


(** [NullAnalyzer] is the module that will be used for the
    null-ability analysis. *)
module NullAnalyzer = Analyzer.Make(NullAnalysis)

let usage = ArgE.wrap_line 0 80 80
  (Printf.sprintf "%s\n (C)2009 Laurent Hubert(CNRS)\n (C)2010 Vincent Monfort(INRIA)\n (C)2013 Pierre Vittet(INRIA)\n\n\
                  Usage: %s [options ... ] --main <string>\n\
                  Nit infers nullness properties for the reference variables of a Java program and can therefore be used to infer null-ability annotations for fields, local variables, method parameters and return values.\n\
                  It takes options but no argument and analyze the program starting from the given main method (with --main option).  At least one output option must be given.\n\n\
                  Options:" version Sys.argv.(0))
   
(** Default options. *)
let empty_args = {
  class_path = (
    try Sys.getenv "CLASSPATH"
    with Not_found -> "");
  debug = 0;
  compact = true;
  main = [];
  html_output = None;
  xml_output = None;
  no_output = false;
  anno_file_output = None;
  scc_output = None;
  scc_max_size = 100;
  cycle_output = None;
  cycle_max_size = 10;
  remove_packages = [];(* [["java"];["sun"]]; *)
  stats_output = false;
  warning_output = false;
  class_analysis = RTA;
  noDefEntryPoints = false;
  analysis_options = {
    field_annotations = true;
    method_annotations = true;
    safe_exception = true;
    safe_native = true;
    safe_static = false;
    safe_array = true;
    aggressive_native = false;
    aggressive_array = false;
    aggressive_static = false;
    aggressive_field = false;
    aggressive_parameter = false;
    aggressive_return = false;
    heap_input = None;
  }
}



(** Used in conjunction with the OCaml [Arg] module to parse the
    command line.

    The list is splitted in two: one part for the "high" priority
    options (short help message displayed when no option is given) and
    a second part for all other "low" priority options that are
    displayed only with the -help or --help options
*)
let spec_args_high args = [
  ("--classpath",
   ArgE.FileBin (fun s -> args.class_path <- s),
   "<string> It takes a list of directories and .jar files concatenated with ':' (or ';' under Windows) where needed classes (including boot strap classes) will be looked for. It should therefore contain the path of your runtime (or bootclasspath in Java). If no --classpath option is given, then the environment variable CLASSPATH is used.");

  ("--main",
   ArgE.String
     (fun s ->
        let re_cn_no_ms = Str.regexp "^[^~]*$" in
        let re_cn_with_ms = Str.regexp "^[^~]*~.*$" in
        let (cn, ms) =
          let open ExtString.String in
            if (Str.string_match re_cn_no_ms s 0)
            then make_cn s, main_signature
            else
              if (Str.string_match re_cn_with_ms s 0)
              then 
                (let (cn_str, ms_str) = split s "~" in
                 let (ms_name, ms_descr_str) = (split ms_str "(") in
                 let (ms_args,ms_ret) = JParseSignature.parse_method_descriptor ("("^ms_descr_str) 
                 in
                   (make_cn cn_str, make_ms ms_name ms_args ms_ret))
              else raise (Arg.Bad ("Error: The class name given to --main must be in the form foo.Bar~Truc or foo.Bar~Truc([Ljava/lang/String;)V ("^s^" given).\n"))

        in
          args.main <- (make_cms cn ms)::args.main),
   "<string> Set the main method of the program.  It takes as argument a class name (such as foo.Bar) optionnaly followed by a method signature in the JVM (internal) syntax (such as '.m(IIL)V').  If no method signature is given, the default is '.main([Ljava/lang/String;)V', which correspond to the void main(String[]) method.  This option must be specified at least once and can be specified more than once.");
  ("--heap-input", 
   ArgE.String
     (fun s -> args.analysis_options <- {args.analysis_options with heap_input = Some (HeapParser.get_init_heap s)}),
   "<file> Try to use <file> as an heap dump file and init the nit initial state with the information from this file.");
  ("--html-output",
   ArgE.String
     (fun s ->
        let rec mkdir d =
          let parent = Filename.dirname d in
            if not (Sys.file_exists parent)
            then mkdir parent;
            if not (Sys.file_exists d)
            then Unix.mkdir d 0o777
        in
          if not (Sys.file_exists s)
          then mkdir s
          else if not (Sys.is_directory s)
          then raise (Arg.Bad "The HTML output directory must be a directory or must not already exist.");
          args.html_output <- Some s),
   "<directory> Outputs the result as HTML code in the given directory (including annotated opcodes).");

  ("--xml-output",
   ArgE.String (fun s -> args.xml_output <- Some s),
   "<f.xml> Outputs the result as XML in the given file (excluding opcodes, i.e. only method and field annotations).");

  ("--anno-file-output",
   ArgE.String (fun s -> args.anno_file_output <- Some s),
   "<f.jaif> Outputs the result (only method and field annotations and only Nullable/NonNull, ie no raw annotations) in the given file in a format suitable for use with the Annotation File Utilities (http://types.cs.washington.edu/annotation-file-utilities/).");
  ("--warnings",
   ArgE.Unit (fun () -> args.warning_output <- true),
   " Output warning for each unsafe dereference on the standard output (stdout).");

  ("--no-output",
   ArgE.Unit (fun () -> args.no_output <- true),
   " For debugging: it does the analysis but do not require to output a result.");

  ("--version",
   ArgE.Unit (fun _ ->
                Printf.printf "%s\n\
 Copyright (C) 2009 CNRS - Laurent Hubert (first.last@irisa.fr)\n\
 Copyright (C) 2010 INRIA - Vincent Monfort (first.last@irisa.fr)\n\
 Copyright (C) 2013 INRIA - Pierre Vittet (first.last@irisa.fr) \n\
Nit comes with ABSOLUTELY NO WARRANTY.\n\
You may redistribute copies of Nit\n\
under the terms of the GNU General Public License.\n\
For more information about these matters, see the file named LICENCE." version;
                exit(0)
             ),
   " Prints version information and exit.");
  ("--no-others-entryPoints",
   ArgE.Unit (fun () -> 
                args.noDefEntryPoints <- true),
   " Dont add any implicit entrypoints.");
]

let spec_args_help = [
  ("-help", ArgE.Unit (function () -> assert false), " Display all available options.");
  ("--help", ArgE.Unit (function () -> assert false), " Display all available options.");
]

let spec_args_low args = [
  ("--debug",
   ArgE.Unit (fun _ -> args.debug <- 5),
   " Prints every debugging information.");

  ("--verbose",
   ArgE.Unit (fun _ -> args.debug <- 1),
   " Prints some debugging information.");

  ("-v",
   ArgE.Unit (fun _ -> args.debug <- 1),
   " Prints some debugging information.");

  ("--stats",
   ArgE.Unit (fun () -> args.stats_output <- true),
   " Output statistics in CSV format on the standard output (stdout).");

  ("--remove-package",
   ArgE.String (fun s -> 
                  args.remove_packages <-
                    ((List.map
			(fun s -> ExtString.String.nsplit s ".")
			(ExtString.String.nsplit s ","))
                     @ args.remove_packages)),
   "<string> It takes a comma separated list of package names (e.g. \"java,sun\" or \"java.lang\") and removes all classes in these packages from the output.  This option can be specified multiple times.  Note: these packages are still analyzed, the option just removes the information concerning these packages from the output.");

  ("--class-analysis",
   ArgE.Symbol (["RTA"; "CRA"],
                (function
                   | "RTA" -> args.class_analysis <- RTA
                   | "CRA" -> args.class_analysis <- CRA
                   | _ -> assert false
                ), true),
   " Either RTA or CRA (RTA is the default option). It selects the analysis used to load the program (RTA is much more precise than CRA but is also very sensitive to native methods and may therefore produce incomplete programs) (the type system then add co-variant and contra-variant constraints on types so it does not change the analysis)."
  );

  ("--no-compact",
   ArgE.Unit (fun _ -> args.compact <- false),
   " Avoid compacting the result of intermediate analyses (It can sometimes save time but always costs memory).");

    ("--no-field-annotation",
   ArgE.Unit (fun () -> 
		args.analysis_options <- {args.analysis_options with field_annotations = false}),
   " Deactivate field annotations. It reduces the precision of the analysis without significantly improving time and memory consumption.");

  ("--no-method-annotation",
   ArgE.Unit (fun () -> 
		args.analysis_options <- {args.analysis_options with method_annotations = false}),
   " Deactivate method annotations. It reduces the precision of the analysis without significantly improving time and memory consumption.");

  ("--unsafe-exception",
   ArgE.Unit (fun () -> 
		args.analysis_options <- {args.analysis_options with safe_exception = false}),
   " Annotate caught exception object as if they were always initialized (NonNull) objects. It improves the results but it is incorrect (as it is possible to throw the current object this in a constructor).");

  ("--unsafe-native",
   ArgE.Unit (fun () -> 
		args.analysis_options <- {args.analysis_options with safe_native = false}),
   " Annotate native methods as if they were always returning initialized objects (NullableInit). It improves the results but it is incorrect.");

  ("--unsafe-static",
   ArgE.Unit (fun () -> 
		args.analysis_options <- {args.analysis_options with safe_static = false}),
   " Annotate static fields as if no class initializer could initialize a static field to not-fully initialized value, i.e to a Raw value. It improves the results but it is incorrect.");

  ("--unsafe-array",
   ArgE.Unit (fun () -> 
		args.analysis_options <- {args.analysis_options with safe_array = false}),
   " Annotate arrays as if none of their cells were ever assigned a Raw value. It improves the results but it is incorrect.");

  ("--aggressive-native",
   ArgE.Unit (fun () -> 
		args.analysis_options <- {args.analysis_options with safe_native = false; aggressive_native = true}),
   " Annotate native methods as if their return value were always NonNull. It improves the results but it is incorrect.");

  ("--aggressive-array",
   ArgE.Unit (fun () -> 
		args.analysis_options <- {args.analysis_options with safe_array = false; aggressive_array = true}),
   " Annotate arrays as if all their cell were cells always NonNull.  It improves the results but it is incorrect.");

  ("--aggressive-static",
   ArgE.Unit (fun () -> 
		args.analysis_options <- {args.analysis_options with safe_static = false; aggressive_static = true}),
   " Annotate static fields as if they were always initialized by their class initializer with a NonNull value. It improves the results but it is incorrect.");

  ("--aggressive-field",
   ArgE.Unit (fun () -> 
		args.analysis_options <- {args.analysis_options with aggressive_field = true}),
   " Annotate instance fields as if they were always NonNull.  It improves the results but it is incorrect.");

  ("--aggressive-parameter",
   ArgE.Unit (fun () ->
		args.analysis_options <- {args.analysis_options with aggressive_parameter = true}),
   " Annotate method parameters as if they were always NonNull.  It improves the results but it is incorrect.");

  ("--aggressive-return",
   ArgE.Unit (fun () -> 
		args.analysis_options <- {args.analysis_options with aggressive_return = true}),
   " Annotate return value of methods as if they were always NonNull. It improves the results but it is incorrect.");

  ]

let spec_list_sawja args = 
  ([("--classpath","Class path",
     ArgPlugin.ClassPath (fun s -> args.class_path <- s),
     "<string> It takes a list of directories and .jar files concatenated with ':' (or ';' under Windows) where needed classes (including boot strap classes) will be looked for. It should therefore contain the path of your runtime (or bootclasspath in Java). If no --classpath option is given, then the environment variable CLASSPATH is used.");

    ("--main","Main class",
     ArgPlugin.ClassFile
       (fun s ->
        let valid_class_name =
          Str.regexp "^\\([a-zA-Z_$][a-zA-Z_$0-9]*\\.\\)*\\([a-zA-Z_][a-zA-Z_0-9]*\\$\\)*[a-zA-Z_][a-zA-Z_0-9]*$"
        in
        let (cn,ms) =
          try
            let split_cn = String.rindex s '.'
            and split_method_name = String.index s '('in
            let cn = make_cn (String.sub s 0 split_cn)
            and ms_descriptor =
              JParseSignature.parse_method_descriptor
                (String.sub s split_method_name (String.length s - split_method_name))
            in 
	    let ms =
              let ms_name=
		String.sub s (split_cn+1) (split_method_name - split_cn - 1)
	      and ms_parameters = fst ms_descriptor 
	      and ms_return_type = snd ms_descriptor
	      in make_ms ms_name ms_parameters ms_return_type
	    in (cn,ms)
          with
            | Not_found ->
                if not (Str.string_match valid_class_name s 0)
                then raise (Arg.Bad ("Error: The class name given to --main must be in the form foo.Bar~Truc or foo.Bar~Truc([Ljava/lang/String;)V ("^s^" given).\n"));
                (make_cn s,main_signature)
            | _ ->
                raise (Arg.Bad ("Error: The class name given to --main must be in the form foo.Bar~Truc or foo.Bar~Truc.main([Ljava/lang/String;)V ("^s^" given).\n"))
        in
          args.main <- (make_cms cn ms)::args.main),
     "<string> Set the main method of the program.  It takes as argument a class name (such as foo.Bar) optionnaly followed by a method signature in the JVM (internal) syntax (such as '~m(IIL)V').  If no method signature is given, the default is '~main([Ljava/lang/String;)V', which correspond to the void main(String[]) method.");
     ("--heap-input", "Use a <file> as initial heap dump (see heap inspector).",
      ArgPlugin.String
        ((fun s -> args.analysis_options <- {args.analysis_options with heap_input = Some (HeapParser.get_init_heap s)}),None),
      "<file> Try to use <file> as an heap dump file and init the nit initial state with the information from this file.");


    ("--unsafe-exception","assert Non-raw on caught exceptions",
     ArgPlugin.Boolean ((fun b -> 
			   args.analysis_options <- {args.analysis_options with safe_exception = b}),
			Some false),
     " Annotate caught exception object as if they were always initialized (NonNull) objects. It improves the results but it is incorrect (as it is possible to throw the current object this in a constructor).");

    ("--unsafe-native","assert Non-raw on native method return",
     ArgPlugin.Boolean ((fun b -> 
			   args.analysis_options <- {args.analysis_options with safe_native = not b}),Some false),
     " Annotate native methods as if they were always returning initialized objects (NullableInit). It improves the results but it is incorrect.");

    ("--unsafe-static","assert Non-raw on static fields",
     ArgPlugin.Boolean ((fun b -> 
			   args.analysis_options <- {args.analysis_options with safe_static = not b}),Some false),
     " Annotate static fields as if no class initializer could initialize a static field to not-fully initialized value, i.e to a Raw value. It improves the results but it is incorrect.");

    ("--unsafe-array","assert Non-raw on arrays cells",
     ArgPlugin.Boolean ((fun b -> 
			   args.analysis_options <- {args.analysis_options with safe_array = not b}),Some false),
     " Annotate arrays as if none of their cells were ever assigned a Raw value. It improves the results but it is incorrect.");

    ("--aggressive-native","assert Non-null on native method return",
     ArgPlugin.Boolean ((fun b -> 
			   args.analysis_options 
			   <- {args.analysis_options with safe_native = not b; aggressive_native = b})
			  ,Some false),
     " Annotate native methods as if their return value were always NonNull. It improves the results but it is incorrect.");

    ("--aggressive-array","assert Non-null on arrays cells",
     ArgPlugin.Boolean ((fun b -> 
			   args.analysis_options 
			   <- {args.analysis_options with safe_array = not b; aggressive_array = b})
			  ,Some false),
     " Annotate arrays as if all their cell were cells always NonNull.  It improves the results but it is incorrect.");

    ("--aggressive-static","assert Non-null on static fields",
     ArgPlugin.Boolean ((fun b -> 
			   args.analysis_options 
			   <- {args.analysis_options with safe_static = not b; aggressive_static = b})
			  ,Some false),
     " Annotate static fields as if they were always initialized by their class initializer with a NonNull value. It improves the results but it is incorrect.");

    ("--aggressive-field","assert Non-null on object fields",
     ArgPlugin.Boolean ((fun b -> 
			   args.analysis_options <- {args.analysis_options with aggressive_field = b}),Some false),
     " Annotate instance fields as if they were always NonNull.  It improves the results but it is incorrect.");

    ("--aggressive-parameter","assert Non-null on parameters",
     ArgPlugin.Boolean ((fun b ->
			   args.analysis_options 
			   <- {args.analysis_options with aggressive_parameter = b})
			  ,Some false),
     " Annotate method parameters as if they were always NonNull.  It improves the results but it is incorrect.");

    ("--aggressive-return","assert Non-null on return value",
     ArgPlugin.Boolean ((fun b -> 
			   args.analysis_options 
			   <- {args.analysis_options with aggressive_return = b})
			  ,Some false),
     " Annotate return value of methods as if they were always NonNull. It improves the results but it is incorrect.");
   ],
   ArgPlugin.PluginOutput ("--xml-output",(fun s -> args.xml_output <- Some s)))


let _ =
  (* GC settings *)
  let current_options = Gc.get () in
  let new_options = {
    current_options with
      Gc.minor_heap_size = 1024*1024;        (* default is 32k *)
      Gc.major_heap_increment = 4096*1024;   (* default is 124k *)
      Gc.space_overhead = 120;               (* default is 80 *)
      Gc.max_overhead = 1000;                (* default is 500 *)
  }
  in
    Gc.set new_options

let _ = Debug.print_debug 2 "GC configured"

let main () =
  (* parsing arguments... *)
  let args = empty_args in
  let entrypoints =
    let spec_args_low = spec_args_low args
    and spec_args_high = spec_args_high args
    in
    let speclist = spec_args_high @ spec_args_low
    and speclist_short = spec_args_high @ spec_args_help
    in

    Debug.print_debug 2  "arguments parsed" ;
    if Arguments.sawja_plugin 
      then
	begin 
	  let (speclist,out) = spec_list_sawja args in
	    ArgPlugin.parse ("NIT", "The Nullability Inference Tool")
	      speclist out usage
	end
      else
	ArgE.parse ~as_cgi:false ~do_wrap:(Some 80) speclist ignore usage;
      Debug.debug := args.debug;
      Options.spare_memory := args.compact;
      if args.xml_output = None &&
	args.anno_file_output = None &&
	args.html_output = None &&
	args.scc_output = None &&
	args.cycle_output = None &&
        not args.no_output &&
	not args.stats_output &&
	not args.warning_output
      then
	begin
	  ArgE.usage speclist_short usage;
	  exit 1
	end;
      if List.length args.main > 0
      then args.main
      else
        begin
	  prerr_endline (Sys.argv.(0)^ " : --main \"option\" is mandatory");
	  ArgE.usage speclist_short usage;
	  exit 1
        end
  in
    Debug.print_time 1;
    Debug.print_mem 1;
    Debug.print_debug 1 "Nullability Inference Tool launched.\n";
    
    let version = 
      version ^" run with arguments : "
      ^ String.concat " " (Array.to_list Sys.argv)
    in
      Debug.print_debug 1 (version ^"\n");

      (* building the program *)
      Debug.print_debug 2 "building program...\n";
      let program =
        JBasics.set_permissive true;
        try
          Debug.print_debug 2 ("classpath = \""^args.class_path^"\"...\n");
          match args.class_analysis with
            | RTA ->
                begin
                  Debug.print_debug 2 "parsing as RTA...";
                  match entrypoints with
                    | pp0::others ->
                       if args.noDefEntryPoints 
                       then 
                         fst 
                           (JRTA.parse_program
                              ~instantiated:[]
                              ~other_entrypoints:[]
                              args.class_path
                              pp0)
                       else 
                         fst 
                           (JRTA.parse_program
                              ~other_entrypoints:(others@JRTA.default_entrypoints)
                              args.class_path
                              pp0)
                    | _ -> assert false
                        (* we have already checked that the length
                           args.main is greater that 1 *)
                end
            | CRA ->
                Debug.print_debug 2 "parsing as CRA...\n";
                let full_entrypoints = 
                  if args.noDefEntryPoints 
                  then entrypoints
                  else entrypoints@JRTA.default_entrypoints
                in
		let prog = 
                  try
                    JCRA.parse_program
                      args.class_path
                      (List.map (fun cms -> fst (cms_split cms)) entrypoints)
                  with JCRA.Class_not_found s->
                    Printf.printf "CRA could not parse program: class %s is missing!\n"
                      (cn_name s);
                    exit 1
		in
		let prog = 
		  {prog with 
		     parsed_methods = 
		      ReachableMethods.compute_reachable_methods 
			prog (full_entrypoints)}
		in 
            
		  prog
        with
	    exn ->
	      prerr_endline (Printexc.to_string exn^"\n");
	      exit 1
      in
      Debug.print_debug 2 "done\n";
        (*transform to JBir program*)
      Debug.print_debug 2 "transforming to jbir...\n";

      let program = 
        JProgram.map_program2
          (fun _ -> JBir.transform ~bcv: false ~ch_link: false ~formula: false ~formula_cmd:[])
          (Some (fun code pp -> (JBir.pc_ir2bc code).(pp)))
          program
      in 


	(*let _ =
	  let cg = (JProgram.get_callgraph program) in
	  let nodes = 
	  List.fold_left
	  (fun cms ((cn,ms,_),(cnt,mst)) -> 
	  ClassMethodSet.add 
	  (make_cms cn ms)
	  (ClassMethodSet.add
	  (make_cms cnt mst)
	  cms)
	  )
	  ClassMethodSet.empty
	  cg
	  in
	  print_endline ("Nb classes: "^string_of_int (List.length (ClassMap.elements program.classes)));
	  print_endline ("Nb parsed methods: "^string_of_int (List.length (ClassMethodMap.elements program.parsed_methods)));
	  print_endline ("Nb arcs: "^string_of_int (List.length cg));
	  print_endline ("Nb nodes: "^string_of_int (ClassMethodSet.cardinal nodes))
	  in*)
        Debug.print_time 2;
	Debug.print_mem 2;
        Debug.print_debug 1 "program built\n";
        Debug.print_prog_stat 1 program;
        Debug.print_debug 1 "programme built";
        Debug.print_debug 1 "initialising analysis...";



        let entrypoints =
          List.map
            (fun cms ->
	       let (cn,ms) = cms_split cms in
		 try
                   let c = JProgram.get_node program cn
                   in JBirPP.get_first_pp_wp c ms
		 with _ ->
                   let meth =
                     JPrint.method_signature ms
                   in failwith 
			("Error: entry point " ^meth^
			   " not found in "^cn_name cn^".")
            )
            entrypoints
        in
	let nb_pp = 
	  ClassMethodMap.fold
	    (fun _ (_,cm) nb -> 
	       match cm.cm_implementation with
		   Native -> nb
		 | Java laz -> 
		     try 
		       Array.length (JBir.code (Lazy.force laz)) + nb
		     with _ -> nb
	    )
	    program.parsed_methods
	    0
        in
          Debug.print_debug 2 "Initializing abstact state.\n";
	let ab_init = 
	  let nb_fields = 
	    ClassMap.fold 
	      (fun _ no nb -> 
		 (FieldMap.fold
		    (fun _ _ nb2 -> nb2+1)
		    (get_fields no)
		    0)+nb)
	      program.classes
	      0
	  and nb_meth = 
	    ClassMethodMap.fold
	      (fun _ _ nb -> nb +1)
	      program.parsed_methods
	      0
	  in
	    NullAnalysis.State.bot (0,0,nb_fields,nb_meth,nb_pp)
	in
          Debug.print_debug 2 "initial program point(s) found\n";
          (* stats on the program *)
          begin
	    if !Debug.debug < 3 then () 
	    else
	      let clinit_methods =
	        JProgram.fold
	          (fun l ioc ->
		     if JProgram.defines_method ioc clinit_signature 
		     then
		       (Debug.print_debug 4 
			  (cn_name (JProgram.get_name ioc) ^" ");
		        (JProgram.get_method ioc clinit_signature)::l)
		     else l)
	          []
	          program
	      in
	        Debug.print_debug 3 
		  (string_of_int (List.length clinit_methods)
		   ^" <clinit> methods found.\n")
          end;
          let (native,mannot) =
	    NullAnalysis.get_native_N_main_annot 
	      args.analysis_options
	      ab_init
	      entrypoints
	      program
          in
            Debug.print_debug 1 "annotations for native methods generated\n";


            Debug.print_debug 1 "done";
	    let abStNull =
	      if !Options.spare_memory then Gc.compact ();
	      (* collecting constraints... *)
	      Debug.print_debug 1 "collecting constraints...\n";
	      let abStNull = 
		NullAnalysis.init 
		  program 
		  entrypoints 
		  mannot 
	      in
                (*add initial heap*)
              let abStNull =
                match args.analysis_options.heap_input with
                  | Some initHeap ->
                        NullAnalysis.init_with_heap
                          abStNull
                          initHeap
                  | _ -> abStNull
              in

	      let constraints =
(*
		let info = 
		  NullAnalysis.get_abInfo ni_info io_info
	        in
*)
                
	          NullAnalyzer.collect_constraints
	            program 
		    args.analysis_options 
		    native 
		    abStNull 
	      in
	        Debug.print_time 2;
		Debug.print_mem 2;
	        Debug.print_debug 1
	          (string_of_int (List.length constraints)
		   ^ " constraints found for the nullability inference analysis\n");
         (* solving constraints... *)
         Debug.print_debug 1 "done";
         Debug.print_debug 1 "solving constraints...";
         NullAnalyzer.solve_constraints 
                  ~optimize_join:true
		  constraints 
		  abStNull 
		  (List.fold_right
		     (fun pp e_p-> 
			let (cn,ms) = 
			  get_name (JBirPP.get_class pp),
			  (JBirPP.get_meth pp).cm_signature
			in
			  `Method((),cn,ms)::
			    `PP((),cn,ms,JBirPP.get_pc pp)::e_p		  
		     )
		     entrypoints
		     [])
            in
              Debug.print_debug 1 "done";
              Debug.print_time 2;
              Debug.print_mem 2;
              Debug.print_debug 1 "fixpoint for the nullability inference analysis found\n";
              if !Options.spare_memory then Gc.major ();
              Debug.print_debug 1 "Displaying result..."; 
              NullAnalysis.display 
                version	args program entrypoints native abStNull args.analysis_options;
              Debug.print_debug 1 "done";
	      Debug.print_time 2;
	      Debug.print_mem 2;
	      Debug.print_debug 1 "display of results finished\n"
		
(* Some form of late exception handling for the user interface *)
let _ =
  try 
    main ();
    Debug.print_time 1;
    Debug.print_mem 1;
    Debug.print_debug 1 "end of execution\n"
  with
    | JBasics.No_class_found s ->
	prerr_endline ("The class " ^s^ " could not be loaded. This may be because your class path (see option --classpath) does not contain your runtime classes (eg. rt.jar).")
    | exn -> print_endline (Printexc.to_string exn);
	Printexc.print_backtrace stdout
