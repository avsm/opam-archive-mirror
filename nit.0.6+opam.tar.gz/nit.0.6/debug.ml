(*
 *  This file is part of Nit (Nullability Inference Tool)
 *  Copyright (c)2008,2009 CNRS
 *  Laurent Hubert <first.last@irisa.fr>
 *  Copyright 2013 INRIA Pierre Vittet <pierre.vittet@inria.fr>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *)

let debug = ref 0

let print_debug level msg =
  if level <= !debug then (prerr_string msg; flush stderr)

open Unix
open Pervasives
open Printf
open Javalib_pack
open JBasics
open Javalib
open Sawja_pack
open JProgram

let prevtime = ref None

let print_mem level =
  if level <= !debug
  then Gc.print_stat stderr

let print_time level =
  if level <= !debug
  then
    let tod = localtime (gettimeofday ()) in
    let tods = 
      sprintf "%02d/%02d/%02d %02d:%02d:%02d"
	tod.tm_mday tod.tm_mon (tod.tm_year mod 100) tod.tm_hour tod.tm_min tod.tm_sec
    in
    let cputimes = times () in
    let cputimess =  match !prevtime with
      | None ->
	  sprintf "  user:   %.3fs\n  system: %.3fs" cputimes.tms_utime cputimes.tms_stime
      | Some prevtime ->
	  let diff_utime = cputimes.tms_utime -. prevtime.tms_utime
	  and diff_ctime = cputimes.tms_stime -. prevtime.tms_stime
	  in
	    sprintf "  user:   %.3fs (+%.3fs)\n  system: %.3fs (+%.3fs)"
	      cputimes.tms_utime diff_utime cputimes.tms_stime diff_ctime
    in
      prevtime := Some cputimes;
      prerr_string (sprintf "at %s :\n%s\n" tods cputimess);
      flush stderr

let print_prog_stat level prog =
  let nb_abstract = ref 0
  and nb_interface = ref 0
  and nb_class = ref 0
  and nb_method = ref 0
  and nb_field = ref 0
  in
    if level <= !debug
    then
      begin
	JProgram.iter
	  (function
	    | Class cn -> 
		if cn.c_info.c_abstract=true
		then incr nb_abstract
		else incr nb_class
	    | Interface _ -> incr nb_interface)
	  prog;
	let cs = 
	  sprintf "program statistics:\n  %d classes (of which %d are abstract)\n  %d interfaces"
	    (!nb_class + !nb_abstract) !nb_abstract !nb_interface
	and mfs =
	  if (succ level) <= !debug
	  then
	    begin
	      JProgram.iter
		(fun c ->
		  nb_method := !nb_method 
		  + List.length (MethodMap.key_elements (get_methods c));
		  nb_field := !nb_field 
		  + List.length (FieldMap.key_elements (get_fields c)))
		prog;
	      sprintf "\n  %d methods\n  %d fields" !nb_method !nb_field
	    end
	  else ""
	and is =
	  if level+2 <= !debug
	  then
	    begin
	      let nb_i =
		JProgram.fold
		  (fun nb_i c ->
		    MethodMap.fold
		      (fun _ms jm nb_i ->
			match jm with
			  | ConcreteMethod {cm_implementation = Java c;_} ->
			      nb_i + (Array.length (JBir.code (Lazy.force c)))
			  | _ -> nb_i
		      )
		      (get_methods c)
		      nb_i
		      
		      
		  )
		  0
		  prog
	      in
		sprintf "\n  %d instructions" nb_i
	    end
	  else ""
	in
	  prerr_string (sprintf "%s%s%s\n" cs mfs is);
	  flush stderr
      end
