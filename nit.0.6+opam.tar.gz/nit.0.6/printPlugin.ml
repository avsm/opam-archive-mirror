(*
 *  This file is part of Nit (Nullability Inference Tool)
 *  Copyright (c)2008,2009 CNRS
 *  Copyright (c)2010 INRIA
 *  Laurent Hubert <first.last@irisa.fr>
 *  Vincent Monfort <first.last@irisa.fr>
 *  Copyright 2013 INRIA Pierre Vittet <first.last@inria.fr>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *)
open NullADomains

open Javalib_pack
open JBasics
open Javalib
open Sawja_pack
open JProgram
open JPrintPlugin
open JBir

module PP = JBirPP (* shortcut *)

let get_local_expr_info expr =
  print_expr expr, type_of_expr expr

type pre_post = Pre | Post

type otype = Receiv | Par | Ret | Field

let replace_all ~str ~sub ~by =
  let continue = ref true
  and s = ref str
  and i = ref 0 in
    while !continue do
      let (c,str) = ExtString.String.replace ~str:!s ~sub ~by in
	s := str;
	continue := c;
	incr i
    done;
    (!i,!s)

let pp_abVal otype (v:NullADomains.AbVal.t) =
  let what = 
    match otype with
	Receiv -> " the receiver "
      | Par -> " the parameter "
      | Ret -> " the returned object "
      | Field -> " the field "
  in
    if AbVal.isBot v then
      "NonNull:"^what^"is never null."
    else if AbVal.isInit v then
      "NullableInit:"^what^"may be null."
    else if AbVal.less_than v AbVal.rawtop then
      begin
	(match AbVal.rawLevel v with
	   | Some c ->
	       "@Raw(" 
	       ^cn_name (get_name (Class c)) ^ "):"
	   | None ->
	       "@Raw:")^
	  what^"may have not finished its constructor."
      end
    else
      begin
	assert (AbVal.equal v AbVal.top);
	"Nullable:"^what^"may be null."
      end

let pp_abThis pre_post node (v:AbThis.t) l  =
  let fl = get_all_ref_fields node in
    if AbThis.isAllDef fl v then
      match pre_post with
	  Pre -> This("Pre(AllDef): At the beginning of this method, all reference fields defined in this class are initialized.")::l
	| Post -> This("Post(AllDef): At the end of this method, all reference fields defined in this class are initialized.")::l
    else if AbThis.isTop v then
      match pre_post with
	  Pre -> This("Pre(AllUnDef): At the beginning of this method, there may be no reference fields defined in this class that is initialized.")::l
	| Post -> This("Post(AllUnDef): At the end of this method, there may be no reference fields defined in this class that is initialized.")::l
    else
      let msg = 
	FieldSet.fold
	  (fun fsi s ->
	     if AbThis.isDef fsi v 
	     then
	       s^"'"^(fs_name fsi)^"'; "
	     else
	       s
	  )
	  fl
	  ((match pre_post with 
		Pre -> "Pre(Def): At the beginning of this method, " 
	      | Post -> "Post(Def): At the end of this method, ")
	   ^"the following reference fields defined in this class are initialized:<br/>")
      in
	(This (msg))::l

let pp_abVal_warn (v:NullADomains.AbVal.t) =
  if AbVal.isBot v then
    None
  else if AbVal.isInit v then
    None
  else if AbVal.less_than v AbVal.rawtop then
    begin
      match AbVal.rawLevel v with
	| Some c ->
	    Some ("Raw(" 
		  ^cn_name (get_name (Class c)) ^ ")")
	| None ->
	    Some "Raw"
    end
  else
    begin
      assert (AbVal.equal v AbVal.top);
      None
    end

let print_plugin_info prog abSt output opt = 
  let p_field cn fs map = 
    let abFd = AbState.get_field abSt (`Field((),cn,fs)) in
    let (ci,fi,mpi) = 
      try ClassMap.find cn map with
	  Not_found -> ([],FieldMap.empty,MethodMap.empty)
    in
    let fi = FieldMap.add fs [pp_abVal Field abFd] fi in
      ClassMap.add cn (ci,fi,mpi) map
  in
  let p_method cn ms map =
    let abMd = AbState.get_method  abSt (`Method ((),cn,ms)) in
    let node = get_node prog cn in
    let meth = get_method node ms  in
    let all_args args value = 
      if is_static_method meth
      then 
	(None,List.map (fun _ -> value) args)
      else 
	(Some value, (List.map (fun _ -> value) args))
    in
    let this, args =
      let args = AbMethodSig.get_args abMd in
      let basic_args = ms_args ms in
        if AbLocals.isBot args
        then 
          all_args basic_args AbVal.bot
        else 
          if is_static_method meth
          then (None,AbLocals.to_list args (List.length basic_args))
          else (
            let args_without_this = 
              match (AbLocals.to_list args ((List.length basic_args)+1)) with
                | [] -> []
                | _::hd -> hd 
            in
              (Some (AbLocals.get args 0), args_without_this)
          )
    and ret_val = AbMethodSig.get_return abMd in
    let ret_l = 
      match ms_rtype ms with 
          Some vt when (match vt with 
                            TObject _ -> true 
                          | _ -> false) 
          -> (JPrintPlugin.Return (pp_abVal Ret ret_val))::[] 
        | _ -> []
    in
    let args_l = 
      let cpt = ref (List.length args) in
        List.fold_right
          (fun v res -> 
             cpt:=!cpt-1;
             JPrintPlugin.Argument(!cpt,pp_abVal Par v)::res
          )
          args
          ret_l
    in
    let this_l = 
      let args_l = 
	match this with
	    None -> args_l
	  | Some v -> 
	      (JPrintPlugin.This (pp_abVal Receiv v ))::args_l
      in 
	if not (is_static_method meth) then
	  pp_abThis Pre node (AbMethodSig.get_this abMd)
	    (pp_abThis Post node (AbMethodSig.get_post abMd) args_l)
	else args_l
    in
    let (ci,fi,mi) = 
      try ClassMap.find cn map with
	  Not_found -> ([],FieldMap.empty,MethodMap.empty)
    in
    let mi = MethodMap.add ms (this_l,Ptmap.empty) mi in
      ClassMap.add cn (ci,fi,mi) map	 
  in
  let p_infos = 
    ClassMap.fold
      (fun _cn node map -> 
	 let nmap = 
	   MethodMap.fold
	     (fun _ms cm map -> 
		let cn, ms = cms_split cm.cm_class_method_signature in
		  p_method cn ms map
	     )
	     (get_concrete_methods node)
	     map
	 in
	FieldMap.fold
	  (fun _fs af map -> 
	     let cn, fs = cfs_split (get_class_field_signature af) in
	       p_field cn fs map	       
	  )
	  (get_fields node)
	  nmap
      )
      prog.classes 
      ClassMap.empty
  in
  let pp_warn_opcode abSt pp op =
    let pp_var = pp_var_from_PP pp in
    let l = AbPP.get_locals (AbState.get_PP abSt pp_var)
  and array2string t = 
    (JDumpBasics.value_signature t^"[]")
    and info expr typ action =
      try
        let (expr_name,_type)= get_local_expr_info expr
        in "Null pointer access: the expression "^expr_name^" may be null."
      with _ ->
        "Null pointer access: the reference of type "
        ^ typ ^ " on which " ^ action ^ " may be null."
    in
    let rec pp_warn_expr expr cur_msg = 
      let merge_msg new_msg current = 
        match new_msg with
          | None -> current
          | Some w -> w::current
      in
      (*first match, check warning*)
      let new_msg = 
        match expr with
          | Binop (ArrayLoad (TBasic _ ), _e1,_e2) -> None
          | Binop (ArrayLoad (TObject _ ), e1,_e2) ->
              let abVal = NullASemantics.expr_val e1 pp abSt prog opt in

                if AbVal.less_than AbVal.null abVal
                then (
                  let typ = 
                    match type_of_expr e1 with
                      | TObject (TArray (ar_typ )) ->ar_typ
                      | TObject _ as typ -> typ
                      | _ -> assert false
                  in
                  let message = 
                    info e1 (array2string typ) "a cell is read" in
                    Some (message, Some expr))
                else None
          | Unop (ArrayLength, e1) -> 
              let abVal = NullASemantics.expr_val e1 pp abSt prog opt in
                if AbVal.less_than AbVal.null abVal
                then
                  (let message = 
                     info e1 "array" "the length is retrieved." in
                     Some (message, Some expr))
                else
                  None
          | JBir.Field (e1, cn, fs) ->
              let abVal = NullASemantics.expr_val e1 pp abSt prog opt in
                if AbVal.less_than AbVal.null abVal
                then
                  let message =
                    info e1
                      (cn_name cn)
                      ("the field "^fs_name fs^" is read")
                  in
                    Some (message,Some e1)
                else
                  None
          | _ -> None
      in
      (*second match, propagate to sub-expr*)
      let cur_msg = merge_msg new_msg cur_msg in
        match expr with 
          | JBir.Field (e1, _,_) 
          | Unop (_, e1) -> (pp_warn_expr e1 cur_msg)
          | Binop (_, e1, e2) ->
              pp_warn_expr e2 (pp_warn_expr e1 cur_msg)
          | _ -> cur_msg
    in
      if AbLocals.isBot l then None
      else 
        (*first match, specificaly check inner expression*)
        let cur_expr_warn = 
          match op with
            | AffectVar (_, e1)
            | AffectStaticField (_,_,e1) 
            | Throw e1
            | Return (Some e1)
            | MonitorEnter e1
            | MonitorExit e1 -> pp_warn_expr e1 []

            | AffectField (e1, _,_, e2)
            | Ifd ((_,e1,e2),_) -> pp_warn_expr e2 (pp_warn_expr e1 [])

            | AffectArray (e1, e2, e3) -> 
                pp_warn_expr e3 (pp_warn_expr e2 (pp_warn_expr e1 []))

            | New (_,_,_, e_list)
            | NewArray (_,_, e_list)
            | InvokeStatic (_,_,_,e_list) ->
                List.fold_left
                  (fun cur_res expr ->
                     pp_warn_expr expr cur_res
                  )
                  []
                  e_list

            | InvokeVirtual (_,e, _,_,e_list)
            | InvokeNonVirtual (_,e,_,_,e_list) ->
                List.fold_left
                  (fun cur_res expr ->
                     pp_warn_expr expr cur_res
                  )
                  (pp_warn_expr e [])
                  e_list

            | _ -> []
        in
        let cur_instr_warn = 
          (*second match, check on instructions*)
          match op with
            | AffectArray (e1,_e2,_e3) ->
                let abVal = NullASemantics.expr_val e1 pp abSt prog opt in
                  if AbVal.less_than AbVal.null abVal 
                  then 
                    (
                      let typ = 
                        match type_of_expr e1 with
                          | TObject (TArray (ar_typ )) ->ar_typ
                          | TObject _ as typ -> typ
                          | _ -> assert false
                      in
                      let message = 
                        info e1 (array2string typ) "a cell is written" in
                        Some (message, None))
                  else None
            | AffectField (_e1, cn, fs, e2) ->
                let abVal = NullASemantics.expr_val e2 pp abSt prog opt in
                  if AbVal.less_than AbVal.null abVal
                  then
                    (let message = 
                      info
                        e2
                        (cn_name cn)
                        ("the field "^fs_name fs^" is written")
                    in
                      Some (message,None))
                  else
                    None
            | InvokeVirtual (_ret, e1, c_kind, ms, _args) ->
                let abVal_obj = NullASemantics.expr_val e1 pp abSt prog opt in
                if AbVal.less_than AbVal.null abVal_obj
                then
                 (let message =
		    let (_,ms_name) =
		      replace_all
			~str:(snd (replace_all ~str:(ms_name ms) ~sub:"<" ~by:"^"))
			~sub:">" ~by:"$"
		    in
                      match c_kind with
                        | VirtualCall t ->
                            info
                              e1
                              (JDumpBasics.object_value_signature t)
                              ("the method "^ms_name^" is called")
                        | InterfaceCall cn ->
                            info
                              e1
                              (cn_name cn)
                              ("the method "^ms_name^" is called")
                  in
                    Some (message,None)
                 )
                else None
            | InvokeNonVirtual (_ret, e1, cn, ms, _args) ->
                let abVal_obj = NullASemantics.expr_val e1 pp abSt prog opt in
                  if AbVal.less_than AbVal.null abVal_obj
                  then
                    (let message =
                       let (_,ms_name) =
                         replace_all
                           ~str:(snd (replace_all ~str:(ms_name ms) ~sub:"<" ~by:"^"))
                           ~sub:">" ~by:"$"
                       in
                         info
                           e1
                           (cn_name cn)
                           ("the method "^ms_name^" is called")
                     in
                       Some (message,None)
                    )
                  else None
	  | _ -> None
        in 
          match cur_instr_warn, cur_expr_warn with
            | None, [] -> None
            | None, _ -> Some (cur_expr_warn)
            | Some w,_ -> Some (w::cur_expr_warn)
  in
  let method_warns abSt cm =
    let cn,ms = cms_split cm.cm_class_method_signature in
    let meth_var = `Method ((),cn,ms) in
      if (ms_name ms) = "<init>"
      then 
	[]
      else
	let ams = AbState.get_method abSt meth_var in
	let meth = ConcreteMethod cm in
	let all_args args value = 
	  if is_static_method meth
	  then 
	    (None,List.map (fun _ -> value) args)
	  else 
	    (Some value, (List.map (fun _ -> value) args))
	in
	let this, args =
	  let args = AbMethodSig.get_args ams
	  in
            if AbLocals.isBot args
            then 
              all_args (ms_args ms) AbVal.bot
            else
              let basic_args = ms_args ms in
              if is_static_method meth
              then (None,AbLocals.to_list args (List.length basic_args))
              else 
                ( let args_without_this = 
                    match (AbLocals.to_list args ((List.length basic_args)+1)) with
                      | [] -> []
                      | _::hd -> hd
                  in (Some (AbLocals.get args 0), args_without_this))
        and ret_val = AbMethodSig.get_return ams in
        let ret_l = 
          match pp_abVal_warn ret_val with 
              None -> []
            | Some _msg -> (JPrintPlugin.Return ("The returned reference may point to objects which have not finished their contructor."))::[] 
	in
	let args_l = 
	  let cpt = ref (List.length args) in
	    List.fold_right
	      (fun v res -> 
		 cpt:=!cpt-1;
		 match pp_abVal_warn v with
		     None -> res
		   | Some _msg -> 
		       JPrintPlugin.Argument(!cpt,"The parameter may point to objects which have not finished their contructor.")::res
	      )
	      args
	      ret_l
	in
	let this_l = 
	  match this with
	      None -> args_l
	    | Some v -> 
		begin match pp_abVal_warn v with 
		    None -> args_l
		  | Some _msg -> (JPrintPlugin.This ("The receiver may point to objects which have not finished their contructor."))::args_l
		end
	in
	  this_l
  in
  let field_warns abSt cn fs = 
    let field = AbState.get_field abSt (`Field ((),cn,fs)) in
      match pp_abVal_warn field with
	  None -> []
	| Some _msg -> 
	    ("The field "^(fs_name fs)^" may point to objects which have not finished their contructor.")::[]
  in
  let p_warnings = 
    ClassMap.map
      (fun node -> 
	 let meth_warnings = 
	   MethodMap.fold
	     (fun ms cm mm -> 
		match cm.cm_implementation with
		    Native -> mm
		  | Java laz -> 
		      let code = Lazy.force laz in
		      let cpt = ref (-1) in
		      let ptmap = 
			Array.fold_left
			  (fun pt opcode ->
			     incr cpt;
			     let pp = PP.get_pp node cm !cpt
			     in 
			       match pp_warn_opcode abSt pp opcode with
				   None -> pt
				 | Some w -> Ptmap.add !cpt w pt
			  )
			  Ptmap.empty
			  (JBir.code code)
		      in
		      let mwarns = method_warns abSt cm in
			if (Ptmap.is_empty ptmap && (List.length mwarns = 0))
			then mm
			else MethodMap.add ms (mwarns,ptmap) mm
	     )
	     (get_concrete_methods node)
	     MethodMap.empty
	 in
	 let fields_warnings = 
	   FieldMap.fold
	     (fun fs _af fm -> 
		match field_warns abSt (get_name node) fs with
		    [] -> fm
		  | l -> FieldMap.add fs l fm
	     )
	     (get_fields node)
	     FieldMap.empty
	 in
	   ([],fields_warnings,meth_warnings)
      )
      prog.classes 
  in
  let to_print = 
    {
      p_infos = p_infos;
      p_warnings = p_warnings
    }
  in
    JBir.PluginPrinter.print_program to_print prog output
