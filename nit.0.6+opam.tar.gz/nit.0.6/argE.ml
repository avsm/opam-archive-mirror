(*
 *  This file is part of the ArgE library (Extention to the Ocaml Arg module)
 *  Copyright (c)2009 CNRS  - Laurent Hubert
 *  Copyright (c)2009 INRIA - Méven Car
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program.  If not, see 
 * <http://www.gnu.org/licenses/>.
 *)


(** ArgE, which stands for Arg Extended, is a wrapper to the module
    Arg.

    It adds to Arg an option “--formatDesc” which forces the program
    to output its available options in a formated string (similar to
    -help but with some more information and in a way which is easier
    to parse).  The module is also able to parse such a string and to
    return instead a list of ArgE.espec.  The type ArgE.espec describe
    the type of the expected argument.
*)

(** Base type of ArgE.  A such constructor describe the type of an
    option's argument. *)
type espec = EUnit | EBool | EString | EInt | EFloat | ESymbol of string list * bool | EFileText | EFileBin

(** Similar to Arg.spec but with some more constructors and
    information. *)
type spec = 
  | Unit of (unit -> unit)     (** Call the function with unit argument *)
  | Bool of (bool -> unit)     (** Call the function with a bool argument *)
  | Set of bool ref            (** Set the reference to true *)
  | Clear of bool ref          (** Set the reference to false *)
  | String of (string -> unit) (** Call the function with a string argument *)
  | Set_string of string ref   (** Set the reference to the string argument *)
  | Int of (int -> unit)       (** Call the function with an int argument *)
  | Set_int of int ref         (** Set the reference to the int argument *)
  | Float of (float -> unit)   (** Call the function with a float argument *)
  | Set_float of float ref     (** Set the reference to the float argument *)
  | Tuple of spec list         (** Take several arguments according to the
                                  spec list *)
  | Symbol of string list * (string -> unit) * bool
                               (** Take one of the symbols as argument and
                                  call the function with the symbol. *)
                               (** the bool option is used to express whether 
                                the argument is mandatory or not *)
  | Rest of (string -> unit)   (** Stop interpreting keywords and call the
                                  function with each remaining argument *)
  | FileText of (string -> unit) (** Call the function with a string argument
                                    The argument is supposed to be a text file *)
  | FileBin of (string -> unit) (** Call the function with a string argument
                                   The argument is supposed to be a binary file *)

(** Encode an ArgE.spec into a string. *)
let parse_spec (spec:spec) =
  match spec with
    | Symbol (s, _, true) -> 
        "Symbol(" ^ (String.concat "," s) ^")mandatory"
    | Symbol (s, _, false) -> 
        "Symbol(" ^ (String.concat "," s) ^")"
    | Clear _
    | Set _
    | Unit _ -> "Unit"
    | Set_string _
    | String _ -> "String"
    | Bool _ -> "Bool"
    | Set_int _
    | Int _ -> "Int"
    | Set_float _
    | Float _ -> "Float"
    | FileText _ -> "FileText"
    | FileBin _ -> "FileBin"
        (* Not supported by ArgE *)
    | Tuple _
    | Rest _ -> failwith "Tuple and Rest are not supported yet by ArgE"

(** An exception raised in case the argument did not match the format expected
*)
exception Arg_ERROR of string

(*
    Converts a string to an ArgE.spec
*)
let unmarshal_spec spec =
    let symbol_regex = Str.regexp "Symbol(\\(.*\\))\\(\\(mandatory\\)?\\)" in
    match spec with
       | "Unit" -> EUnit
       | "String" -> EString
       | "Bool" -> EBool
       | "Int" -> EInt
       | "Float" -> EFloat
       | "FileText" -> EFileText
       | "FileBin" -> EFileBin
       | s when Str.string_match symbol_regex s 0 -> 
            (ESymbol 
                ((Str.split (Str.regexp ",") (Str.matched_group 1 s)),
                (if (Str.matched_group 2 s) = "" then false else true))
            )
       | _ -> raise (Arg_ERROR "Unknown type of parameter")

(* 
    Transforms a string option to a string 
    None is transformed in an empt string
*)
let val_option_string str_opt =
    match str_opt with
        | None -> ""
        | Some str -> str

let rec transcode_ArgE_to_Arg spec = 
  match spec with
    | Unit t -> Arg.Unit t
    | Bool t -> Arg.Bool t
    | Set t -> Arg.Set t
    | Clear t -> Arg.Clear t
    | String t -> Arg.String t
    | Set_string t -> Arg.Set_string t
    | Int t -> Arg.Int t
    | Set_int t -> Arg.Set_int t
    | Float t -> Arg.Float t
    | Set_float t -> Arg.Set_float t
    | Tuple t -> Arg.Tuple (List.map (transcode_ArgE_to_Arg) t)
    | Symbol (l , t, _) -> Arg.Symbol (l, t)
    | Rest t -> Arg.Rest t
    | FileText t
    | FileBin t -> Arg.String t

let transcode_spec_list = 
  List.map
    (fun (opt, spec, desc) -> (opt, transcode_ArgE_to_Arg spec, desc))

let remove_indentation : string -> string =
  let pattern = Str.regexp "[\n\r]+ *"
  in Str.global_replace pattern " "


let rec wrap_line ?(first=true) indent first_window window string =
  let new_line = "\n"^(String.make indent ' ') in
  let window' = if first then first_window else window - indent in
    if String.length string <= window'
    then string
    else
      let split ?(remove=true) string cut_point =
        let snd_start = if remove then succ cut_point else cut_point
        in
	(String.sub string 0 cut_point,
         String.sub string snd_start (String.length string - snd_start))
      in
      let (s1,s2) =
	try split string (String.rindex_from string window' '\n')
	with Not_found ->
	  try split string (String.rindex_from string window' ' ')
	  with Not_found -> split ~remove:false string window'
      in
        s1^new_line^(wrap_line indent ~first:false first_window window s2)

let wrap window indent speclist =
    List.map (fun (a,b,c) -> (a,b,wrap_line indent (window - (String.length a)) window c)) speclist

let align window speclist =
  let first_word_size s =
    try String.index s ' '
    with Not_found -> String.length s
  in
  let alignment_one (opt,_,doc) = (String.length opt) + (first_word_size doc)
  in
  let alignment =
    4 + (List.fold_left
           (fun m spec -> max m (alignment_one spec))
           0
           speclist)
  in
  let align = function
  | (opt,(Arg.Symbol _ as spec),doc) ->
      let alignment = alignment - 2
      in
        (opt,spec,
         "\n" ^ String.make alignment ' '
         ^ wrap_line alignment (window - alignment) window (ExtString.String.strip doc))
  | (opt,f,doc) ->
      let new_doc =
        try
          let first_word_size = String.index doc ' '
          in
            (String.sub doc 0 first_word_size)
            ^ String.make (alignment - (String.length opt) - first_word_size - 3) ' '
            ^ (wrap_line (alignment - 2) (window - alignment) window
                 (String.sub doc (first_word_size + 1) (String.length doc - first_word_size - 1)))
        with Not_found -> doc
      in
        (opt,f,new_doc)
  in
    List.map align speclist

(** Wrapper of the Arg.parse function that adds an option to the
    available options: --formatDesc

    This option is used to express the other options as string in the format :
    option; ArgE.spec; default ; description
*)
let parse ?(as_cgi=false) ?(do_wrap=Some 80) (spec:(string * spec * string) list) f usage_msg =
  let new_spec =
    if as_cgi then
      transcode_spec_list spec @
        [(
           "--formatDesc", 
           Arg.Unit
             (fun () ->
                raise
                  (Arg.Help
                     (List.fold_left
                        (fun s (opt,spec,desc) ->
                           s ^ opt ^ ";"
                           ^ (parse_spec spec) ^ ";"
                           ^ (remove_indentation desc) ^ "\n") "" spec
                     ))
             ),
           " print options in a format which is easy to parse"
         )]
    else transcode_spec_list spec
  in
  let new_spec = match do_wrap with
    | None -> new_spec
    | Some window -> align window new_spec
  in
    Arg.parse new_spec f usage_msg

(*
    Converts a channel to a stream of string composed of the lines of the channel
*)
let line_stream_of_channel channel =
  Stream.from
    (fun _ ->
       try Some (input_line channel) with End_of_file -> None)

(*
    Function that parse a string of format 'option;ArgE.spec;default;description'
    back to (string * string * string * string)
*)
let parse_line line =
    let reg = Str.regexp "^\\([^\n;]+\\);\\([^\n;]+\\);\\(.+\\)$" in
    match (Str.string_match reg line 0) with
    | true ->
        let opt = (Str.matched_group 1 line) in
        let spec = (Str.matched_group 2 line) in
        let desc = (Str.matched_group 3 line) in
        (opt, spec, desc)
    | false ->
	assert false

(*
    Converts a stream to a list
*)
let list_of_stream stream =
  let result = ref [] in
  Stream.iter (fun value -> result := value :: !result) stream;
  List.rev !result

(*
    Wrapper for Arg.usage and Arg.align method
*)
let usage spec_list usage =
  Arg.usage (align 80 (transcode_spec_list spec_list)) usage


(*
    From a given in_channel returns a (string * Arge.spec * string) list
*)
let open_arg_channel_in channel =
  try
    let lines = list_of_stream (line_stream_of_channel channel) in
      close_in channel;
      List.map
        (fun line -> match (parse_line line) with 
           | opt, spec , desc  -> 
               (opt, (unmarshal_spec spec) ,desc)
        )
	lines;
  with e ->
    close_in channel;
    raise e

