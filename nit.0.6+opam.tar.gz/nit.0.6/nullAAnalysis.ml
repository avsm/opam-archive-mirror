(*
 *  This file is part of Nit (Nullability Inference Tool)
 *  Copyright (c)2008,2009 CNRS
 *  Laurent Hubert <first.last@irisa.fr>
 *  Copyright 2013 INRIA Pierre Vittet <pierre.vittet@inria.fr>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *)

(** This module is used as an interface to null-ability analysis.
    Only this module of the analysis should be used outside the
    null-ability analysis. *)
open Javalib_pack
open JBasics
open Javalib
open Sawja_pack
open JProgram
open Options
open Arguments 

(* type abInfo = NullASemantics.abInfo *)

module Var = NullADomains.Var
module State = NullADomains.AbState
module Constraints = NullADomains.AbConstraints

let init_static_field_to_top prog nullst =
  let nullable = (`FieldDomain (NullADomains.AbVal.top)) in
    JProgram.iter
      (fun node ->
         let cn = (get_name node) in
           JProgram.f_iter
             (fun any_f -> 
                match any_f with
                  | InterfaceField f ->
                      let fs = f.if_signature in
                        State.join nullst (`Field ((), cn, fs)) nullable
                  | ClassField f ->
                      match (f.cf_static) with
                        | true -> 
                            let fs = f.cf_signature in
                              State.join nullst (`Field ((), cn, fs)) nullable
                        | _ -> ()
             )
             node
      )
      prog



let init program entrypoints abSt =
  init_static_field_to_top program abSt;
  List.iter 
    (fun pp0 -> 
       let c = JBirPP.get_class pp0
       and msi = (JBirPP.get_meth pp0).cm_signature
       in
       let m_var = `Method((),get_name c,msi) in
       let ab_m = State.get_method abSt m_var in
         if NullADomains.AbMethodSig.isBot ab_m then
           State.join
             abSt
             m_var
             (`MethodDomain(NullADomains.AbMethodSig.init (c,msi)))
         else ()
    )
    entrypoints;
  abSt

let init_with_heap nullst parsed_heap = 
  let open ParserType in
  let hp_class = parsed_heap.hp_class in
    ClassMap.iter
      (fun cn cl_el -> 
         (*static fields*)
         FieldMap.iter
           (fun fs _value ->
              let f_var = `Field ((), cn, fs) in
                State.join ~do_join:false
                  nullst 
                  f_var
                  (`FieldDomain(NullADomains.AbVal.nonnull))
           )
           cl_el.cl_static_fields;
         (*instance fields:
          1) we get an abstraction for each field (considering every instance)
          2) we put this abstraction in the state
          *)
         (*
          1) 

          If a field is appearing in each instance of the given class, then
          it is non_null else it is nullable.
          In order to check this, we count the number of instance for each
          class and we check that the field appear the same amount of time.
          *)
         let (inst_count, appearingFields) = 
           Ptmap.fold
             (fun _inst_id fmap (nb_inst, appearingFields)  ->
                let appearingFields = 
                  FieldMap.fold
                    (fun fs _value appearingFields -> 
                       let cur_count = 
                         try (FieldMap.find fs appearingFields)
                         with Not_found -> 0 
                       in
                         FieldMap.add fs (cur_count +1) appearingFields
                    )
                    fmap
                    appearingFields
                in
                  (nb_inst + 1, appearingFields)
             )
             cl_el.cl_instances
             (0, FieldMap.empty)
         in
        (* 
         2) For each field present in every instance, I put it as non null.
        *)
         FieldMap.iter
           (fun fs fs_count -> 
              if (fs_count = inst_count)
              then
                (let f_var = `Field ((), cn, fs) in
                   State.join 
                     nullst
                     f_var
                     (`FieldDomain(NullADomains.AbVal.nonnull))
                )
           ) 
           appearingFields
      )
      hp_class;
    nullst





let abstract_method opt _prog _st ioc ms cms_done csts = NullASemantics.abstract_method opt ioc ms cms_done csts
let abstract_init_method_instr opt _prog _st ioc ms csts = NullASemantics.abstract_init_method_instr opt ioc ms csts
let abstract_instruction opt prog _st pp opcode succs csts = NullASemantics.abstract_instruction opt prog pp opcode succs csts
let abstract_instruction_ex opt _prog _st pp _opcode succs csts = NullASemantics.abstract_instruction_ex opt pp succs csts

let get_hinfo = NullADomains.get_hinfo

let get_main_annot mannot pp =
  let c = JBirPP.get_class pp
  and ms = (JBirPP.get_meth pp).cm_signature
  in
    (if ms = main_signature
     then
       NullADomains.AbState.join 
         mannot 
         (`Method((),get_name c,ms))
         (`MethodDomain(
            (NullADomains.AbMethodSig.join_args
               NullADomains.AbMethodSig.bot
               (NullADomains.AbLocals.set
                  (NullADomains.AbLocals.init) 0
                  NullADomains.AbVal.nonnull
               ))))
     else
       NullADomains.AbState.join 
         mannot 
         (`Method((),get_name c,ms))
         (`MethodDomain(
            (NullADomains.AbMethodSig.init (c,ms)))));
    mannot

    
let native_methodsig opt  =
  `MethodDomain(
    NullADomains.AbMethodSig.join_return
      NullADomains.AbMethodSig.bot
      (if opt.aggressive_native then
         NullADomains.AbVal.nonnull (* very optimistic *)
       else if not opt.safe_native then
         NullADomains.AbVal.init (* probably close to reality*)
       else NullADomains.AbVal.top) (* (very) conservative *))

let get_native_N_main_annot opt abSt entrypoints program =
  let mannot = 
    List.fold_left get_main_annot abSt entrypoints
  in
  let get_native_methods_class = function
    | Class _ as c->
	MethodMap.fold
	  (fun ms m l ->
	     match m with
	       | ConcreteMethod {cm_implementation=Native;_} -> 
		   (c,ms)::l
	       | _ -> l)
	  (get_methods c)
	  []
    | _ -> []
  in
    JProgram.fold
      (fun (native,mannot) c ->
	 List.fold_left
           (fun (native,mannot) (c,msi) ->
	      let cn = get_name c in
	      let _mannot = 
		State.join 
		  mannot 
		  (`Method((),cn,msi))
		  (native_methodsig opt)
	      in
		(ClassMethodSet.add (make_cms cn msi) native,
		 mannot))
	   (native,mannot)
           (get_native_methods_class c)
      )
      (ClassMethodSet.empty,mannot)
      program

let display version args program entrypoints native abStNull opt = 
  (* displaying the results *)
  begin
    let doPrint ioc = 
      let rec notPrefix = fun l2 l1 -> match l1,l2 with
	| e1::l1,e2::l2 when e1=e2 -> notPrefix l2 l1
	| [],_ -> false
	| _,_ -> true
      in
	List.for_all 
	  (notPrefix (cn_package (get_name ioc)))
	  args.remove_packages
    in
    let print
        (printing_function:?doPrint:
	   (JBir.t JProgram.node -> bool) ->
	  NullADomains.AbState.t -> Format.formatter -> 
	  JBir.t JProgram.program -> Options.analysis_options -> unit)
        file :unit =
      let oc = open_out_bin file in
        try
	  let fmt = Format.formatter_of_out_channel oc
	  in
	    printing_function 
	      ~doPrint abStNull fmt program opt;
	    Format.pp_print_flush fmt ();
	    close_out oc
        with e -> (close_out oc; raise e)
    in
      (match args.xml_output with
         | None -> ()
         | Some xmlfile -> 
             if Arguments.sawja_plugin
             then
               PrintPlugin.print_plugin_info program abStNull xmlfile opt
             else
               print Print.pprint_xml_program xmlfile);
      (match args.anno_file_output with
	 | None -> ()
	 | Some anno_file -> 
	     print Print.pprint_anno_file_program anno_file);
  end;

  begin match args.html_output with
    | Some directory ->
        let printHTML_info =
          get_hinfo
	    program abStNull JPrintHtml.void_info
        in
	  JBir.print_program ~info:printHTML_info program directory
    | None -> ()
  end;

   
  if args.warning_output || args.stats_output then
    let stats =
      Statistics.get_stats
	~remove_packages:args.remove_packages
	program native abStNull opt
    in 
      if args.stats_output then
	Statistics.print_stats stdout
	  (JDumpBasics.class_name (JProgram.get_name (JBirPP.get_class (List.hd entrypoints))))
	  version
	  stats;
      Debug.print_time 1;
      Debug.print_mem 3;
      Debug.print_debug 1 "results printed (program finished)\n"
