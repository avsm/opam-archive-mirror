0.1.1 (2014-10-30)
* stricter decoding of ints in BER/DER tags and OIDs
* performance improvements

0.1.0 (2014-07-08):
* initial (beta) release
