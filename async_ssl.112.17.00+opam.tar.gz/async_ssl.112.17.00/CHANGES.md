## 112.17.00

- moved ffi_bindings and ffi_stubgen in separate libraries

## 111.21.00

- Upgraded to use new ctypes and its new stub generation methods.

## 111.08.00

- Improved the propagation of SSL errors to the caller.

## 111.06.00

Initial release

