To get an overview of Async, read the Dummy's guide to Async in the
docs repo.
