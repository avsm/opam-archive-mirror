(* OASIS_START *)
(* DO NOT EDIT (digest: 61a3895b52e0b1ff373766728982d2c4) *)
This is the README file for the mesh distribution.

Triangular mesh generation and manipulation.

This is an interface to various mesh generators, in particular triangle.  It
also provides functions to optimize the numbering of mesh points and to
export meshes and piecewise linear functions defined on them to TikZ, Scilab,
Matlab, and Mathematica formats.

See the files INSTALL.txt for building and installation instructions. 

Home page: http://forge.ocamlcore.org/projects/mesh/


(* OASIS_STOP *)
