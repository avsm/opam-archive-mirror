let package_name = "ppx_csv_conv"

let sections =
  [ ("lib",
    [ ("built_lib_ppx_csv_conv", None)
    ],
    [ ("META", None)
    ])
  ]
