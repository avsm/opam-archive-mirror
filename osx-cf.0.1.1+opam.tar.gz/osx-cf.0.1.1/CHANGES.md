0.1.1 (2016-08-08):
* Update for ctypes >= 0.6.0

0.1.0 (2016-05-31):
* Initial public release
