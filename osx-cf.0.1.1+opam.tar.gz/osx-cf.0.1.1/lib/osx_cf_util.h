void osx_cf_run_loop_run();

SInt32 osx_cf_run_loop_run_in_mode
(CFStringRef mode, CFTimeInterval seconds, Boolean returnAfterSourceHandled);
