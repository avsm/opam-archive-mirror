## OCaml bindings to OS X CoreFoundation

These bindings use [ctypes](https://github.com/ocamllabs/ocaml-ctypes)
for type-safe stub generation.

### Dependent Packages

 - [ocaml-osx-fsevents](https://github.com/dsheets/ocaml-osx-fsevents)