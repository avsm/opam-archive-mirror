open Core.Std
open Result.Monad_infix

module Error_code = struct
  type t = Raw.krb5_error_code

  let sexp_of_t = Int32.sexp_of_t
  let t_of_sexp = Int32.t_of_sexp

  let is_failure = Raw.is_krb_failure
end


module Context : sig
  type 'a t =
    { raw_context : Raw.krb5_context
    ; mutex       : Mutex.t
    ; data        : 'a
    }

  (** [raw t ~f] extracts the error message from the context **)
  val raw  : _ t -> f:(Raw.krb5_context -> ('a, Error_code.t) Result.t) -> 'a Or_error.t

  val init : 'a -> 'a t Or_error.t
  val data : 'a t -> 'a
  val error_msg : _ t -> Error_code.t -> string

  val add_finalizer : _ t -> 'a -> f:(Raw.krb5_context -> 'a -> unit) -> unit

end = struct
  type 'a t =
    { raw_context : Raw.krb5_context
    ; mutex       : Mutex.t
    ; data        : 'a
    }

  let data { data; _ } = data

  let raw' t ~f = Mutex.critical_section t.mutex ~f:(fun () -> f t.raw_context)

  let raw t ~f = raw' t ~f:(fun context -> Result.map_error (f context) ~f:(fun errno ->
    Error.create (Raw.krb5_get_error_message context errno) errno Error_code.sexp_of_t))

  let init data =
    Result.map_error (Raw.krb5_init_context ()) ~f:(fun errno ->
      Error.create "Krb5 error" errno Error_code.sexp_of_t)
    >>| fun raw_context ->
    let res = { raw_context; mutex = Mutex.create (); data } in
    Gc.Expert.add_finalizer_exn res (fun c -> raw' c ~f:Raw.krb5_free_context);
    res

  let error_msg t code = raw' t ~f:(fun c -> Raw.krb5_get_error_message c code)

  let add_finalizer context t ~f:finalize =
    Gc.Expert.add_finalizer_exn t (fun t -> raw' context ~f:(fun context -> finalize context t))
end

module Keytab = struct
  type t = Raw.krb5_keytab

  let resolve context ~path =
    Context.raw context ~f:(fun c -> Raw.krb5_kt_resolve c path)
end

module Principal = struct
  type t = Raw.krb5_principal

  module Of_sname_type = struct
    type t =
      | NT_SRV_HST
      | NT_UNKNOWN
  end

  let of_sname context ~service ~hostname stype =
    let stype =
      match stype with
      | Of_sname_type.NT_SRV_HST -> Raw.KRB5_NT_SRV_HST
      | Of_sname_type.NT_UNKNOWN -> Raw.KRB5_NT_UNKNOWN
    in
    Context.raw context ~f:(fun c -> Raw.krb5_sname_to_principal c ~hostname ~service stype)
    >>| fun principal ->
    Context.add_finalizer context principal ~f:Raw.krb5_free_principal;
    principal

  let of_string context name =
    Context.raw context ~f:(fun c -> Raw.krb5_parse_name c name)
    >>| fun principal ->
    Context.add_finalizer context principal ~f:Raw.krb5_free_principal;
    principal

  let to_string context t =
    Context.raw context ~f:(fun c -> Raw.krb5_unparse_name c t)

  let check_password context t ~password =
    Context.raw context ~f:(fun c ->
      Raw.krb5_get_init_creds_password c t password
      >>| fun krb5_creds ->
      Raw.krb5_free_cred_contents c krb5_creds)
end

module Cred_cache = struct
  type t = Raw.krb5_ccache

  let default context =
    Context.raw context ~f:Raw.krb5_cc_default
end


module Peer_context = struct
  type 'a t =
    { context : 'a Context.t
    ; raw_auth : Raw.krb5_auth_context
    }

  let context { context; raw_auth=_ } = context
end

module Service_context = struct
  type 'a t =
    { peer_context : 'a Peer_context.t
    ; client_name : string
    }

  let peer_context t = t.peer_context
  let client_name t = t.client_name

  let init context principal keytab ~in_data
      ~local_addr ~local_port ~remote_addr ~remote_port =
    Context.raw context ~f:(fun c ->
      Raw.krb5_auth_con_init c
      >>= fun auth_context ->
      Context.add_finalizer context auth_context ~f:Raw.krb5_auth_con_free;
      Raw.krb5_rd_req c auth_context ~in_data principal keytab
      >>= fun client_name ->
      Raw.krb5_auth_con_setflags c auth_context [Raw.KRB5_AUTH_CONTEXT_DO_SEQUENCE]
      >>= fun () ->
      Raw.krb5_auth_con_setaddrs
        c
        auth_context
        local_addr
        ~port:local_port
        ~replay_id:None
        ~is_local:true
      >>= fun () ->
      Raw.krb5_auth_con_setaddrs
        c
        auth_context
        remote_addr
        ~port:remote_port
        ~replay_id:None
        ~is_local:false
      >>| fun () ->
      { peer_context =
          { Peer_context.context;
            raw_auth = auth_context;
          }
      ; client_name
      })

end

module Client_context = struct
  type 'a t = 'a Peer_context.t

  type request = Bigstring.t

  module Flag = struct
    type t =
    | AP_OPTS_USE_SESSION_KEY
    | AP_OPTS_MUTUAL_REQUIRED
  end

  let peer_context = Fn.id

  let init ?in_data ?replay_id context ccache flags
      ~service ~hostname ~local_addr ~local_port ~remote_addr ~remote_port =
    let flags = List.map flags ~f:(function
      | Flag.AP_OPTS_USE_SESSION_KEY -> Raw.AP_OPTS_USE_SESSION_KEY
      | Flag.AP_OPTS_MUTUAL_REQUIRED -> Raw.AP_OPTS_MUTUAL_REQUIRED)
    in
    Context.raw context ~f:(fun c ->
      Raw.krb5_auth_con_init c
      >>= fun auth_context ->
      Context.add_finalizer context auth_context ~f:Raw.krb5_auth_con_free;
      Raw.krb5_mk_req c auth_context flags ~service ~hostname ~in_data ccache
      >>= fun request ->
      Raw.krb5_auth_con_setflags c auth_context [Raw.KRB5_AUTH_CONTEXT_DO_SEQUENCE]
      >>= fun () ->
      Raw.krb5_auth_con_setaddrs
        c
        auth_context
        local_addr
        ~port:local_port
        ~replay_id
        ~is_local:true
      >>= fun () ->
      Raw.krb5_auth_con_setaddrs
        c
        auth_context
        remote_addr
        ~port:remote_port
        ~replay_id
        ~is_local:false
      >>| fun () -> ({ Peer_context.context ; raw_auth = auth_context}, request))

end

let mk_priv client_context in_data =
  Context.raw client_context.Peer_context.context ~f:(fun c ->
    Raw.krb5_mk_priv c client_context.Peer_context.raw_auth in_data)
let rd_priv client_context in_data =
  Context.raw client_context.Peer_context.context ~f:(fun c ->
    Raw.krb5_rd_priv c client_context.Peer_context.raw_auth in_data)

let mk_safe client_context in_data =
  Context.raw client_context.Peer_context.context ~f:(fun c ->
    Raw.krb5_mk_safe c client_context.Peer_context.raw_auth in_data)
let rd_safe client_context in_data =
  Context.raw client_context.Peer_context.context ~f:(fun c ->
    Raw.krb5_rd_safe c client_context.Peer_context.raw_auth in_data)
