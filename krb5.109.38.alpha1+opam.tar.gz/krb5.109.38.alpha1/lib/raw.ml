open Core.Std

(* krb5 type definitions *)

type krb5_context;;
type krb5_data;;
type krb5_ccache;;
type krb5_principal;;
type krb5_error;;
type krb5_ap_rep_enc_part;;
type krb5_auth_context;;
type krb5_int32 = int32;;  (* this might be bad *)
type krb5_error_code = krb5_int32;;
type krb5_creds;;
type krb5_ticket;;
type krb5_keytab;;

type krb5_mk_req_flag =
  | AP_OPTS_USE_SESSION_KEY
  | AP_OPTS_MUTUAL_REQUIRED

type sname_to_principal_type =
  | KRB5_NT_SRV_HST
  | KRB5_NT_UNKNOWN

type krb5_auth_context_flag =
  | KRB5_AUTH_CONTEXT_DO_TIME
  | KRB5_AUTH_CONTEXT_RET_TIME
  | KRB5_AUTH_CONTEXT_DO_SEQUENCE
  | KRB5_AUTH_CONTEXT_RET_SEQUENCE


(* Random utility functions *)

external is_ap_rep_enc_part :
  krb5_ap_rep_enc_part
  -> bool
  = "is_ap_rep_enc_part";;

external buffer_to_hs :
  string
  -> int
  = "buffer_to_hs";;

external hs_to_buffer :
  int
  -> string
  = "hs_to_buffer";;

external is_krb_success :
  krb5_error_code
  -> bool
  = "is_krb_success";;

external is_krb_failure :
  krb5_error_code
  -> bool
  = "is_krb_failure";;

external is_auth_context :
  krb5_auth_context
  -> bool
  = "is_auth_context";;

external is_error :
  krb5_error
  -> bool
  = "is_error";;

external k5u_get_error_text :
  krb5_error
  -> string
  = "my_k5u_get_error_text";;

external k5u_ticket_client :
  krb5_ticket
  -> krb5_principal
  = "my_k5u_ticket_client" ;;

(* Kerberos 5 API interface sort of *)

external krb5_init_context : unit -> (krb5_context, krb5_error_code) Result.t
  = "my_krb5_init_context";;

external krb5_sname_to_principal :
  krb5_context
  -> hostname:string
  -> service:string
  -> sname_to_principal_type
  -> (krb5_principal, krb5_error_code) Result.t
  = "my_krb5_sname_to_principal";;

external krb5_cc_default :
  krb5_context -> (krb5_ccache, krb5_error_code) Result.t
  = "my_krb5_cc_default";;
external krb5_cc_get_principal :
  krb5_context
  -> krb5_ccache
  -> (krb5_principal, krb5_error_code) Result.t
  = "my_krb5_cc_get_principal";;
external krb5_sendauth : krb5_context -> Caml.Unix.file_descr -> string ->
  krb5_principal -> krb5_principal -> string -> krb5_ccache ->
    krb5_error_code * krb5_auth_context * krb5_error * krb5_ap_rep_enc_part =
      "my_krb5_sendauth_bytecode" "my_krb5_sendauth_native";;
external krb5_recvauth : krb5_context -> Caml.Unix.file_descr -> string ->
  krb5_principal -> krb5_keytab -> krb5_error_code * krb5_auth_context *
  krb5_ticket = "my_krb5_recvauth";;
external krb5_cc_close : krb5_context -> krb5_ccache -> krb5_error_code
  = "my_krb5_cc_close";;
external krb5_auth_con_init :
  krb5_context
  -> (krb5_auth_context, krb5_error_code) Result.t
  = "my_krb5_auth_con_init";;
external krb5_auth_con_free : krb5_context -> krb5_auth_context -> unit
  = "my_krb5_auth_con_free";;
external krb5_free_ap_rep_enc_part :
  krb5_context
  -> krb5_ap_rep_enc_part
  -> unit
  = "my_krb5_free_ap_rep_enc_part";;

external krb5_free_context : krb5_context -> unit = "my_krb5_free_context";;

external krb5_parse_name :
  krb5_context
  -> string
  -> (krb5_principal, krb5_error_code) Result.t
  = "my_krb5_parse_name";;

external krb5_unparse_name :
  krb5_context -> krb5_principal
  -> (string, krb5_error_code) Result.t = "my_krb5_unparse_name";;
external krb5_free_error :
  krb5_context
  -> krb5_error
  -> unit = "my_krb5_free_error";;
external krb5_free_ticket : krb5_context -> krb5_ticket -> unit
= "my_krb5_free_ticket";;
external krb5_kt_resolve :
  krb5_context
  -> string
  -> (krb5_keytab, krb5_error_code) Result.t
  = "my_krb5_kt_resolve";;
external krb5_kt_close : krb5_context -> krb5_keytab -> krb5_error_code
  = "my_krb5_kt_close";;
external krb5_free_principal : krb5_context -> krb5_principal -> unit
  = "my_krb5_free_principal";;

(* new jkilburg stuff *)

external krb5_get_init_creds_password :
  krb5_context -> krb5_principal -> string ->
    (krb5_creds, krb5_error_code) Result.t
    = "krb5_get_init_creds_password_stub"

external krb5_free_cred_contents :
  krb5_context -> krb5_creds -> unit = "my_krb5_free_cred_contents";;

(* stuff vharvey thinks he needs *)

type client_name = string
type out_buffer = bigstring
type out_buffer_result =
  (out_buffer, krb5_error_code) Result.t

external krb5_get_error_message : krb5_context -> krb5_error_code -> string
= "krb5_get_error_message_stub";;

external krb5_mk_req :
  krb5_context
  -> krb5_auth_context
  -> krb5_mk_req_flag list
  -> service:string
  -> hostname:string
  -> in_data:(Bigsubstring.t option)
  -> krb5_ccache
  -> out_buffer_result
  = "krb5_mk_req_bytecode_stub" "krb5_mk_req_native_stub";;

external krb5_rd_req :
  krb5_context
  -> krb5_auth_context
  -> in_data:Bigsubstring.t
  -> krb5_principal
  -> krb5_keytab
  -> (client_name, krb5_error_code) Result.t
  = "krb5_rd_req_stub";;

external krb5_auth_con_getflags :
  krb5_context
  -> krb5_auth_context
  -> (krb5_auth_context_flag, krb5_error_code) Result.t
  = "krb5_auth_con_getflags_stub"

external krb5_auth_con_setflags :
  krb5_context
  -> krb5_auth_context
  -> krb5_auth_context_flag list
  -> (unit, krb5_error_code) Result.t
  = "krb5_auth_con_setflags_stub"

external krb5_auth_con_setaddrs :
  krb5_context
  -> krb5_auth_context
  -> Unix.Inet_addr.t
  -> port:int
  -> replay_id:(string option)
  -> is_local:bool
  -> (unit, krb5_error_code) Result.t
  = "krb5_auth_con_setaddrs_bytecode_stub"
  "krb5_auth_con_setaddrs_native_stub";;

external krb5_mk_priv :
  krb5_context
  -> krb5_auth_context
  -> Bigsubstring.t
  -> out_buffer_result = "krb5_mk_priv_stub";;

external krb5_rd_priv :
  krb5_context
  -> krb5_auth_context
  -> Bigsubstring.t
  -> out_buffer_result = "krb5_rd_priv_stub";;

external krb5_mk_safe :
  krb5_context
  -> krb5_auth_context
  -> Bigsubstring.t
  -> out_buffer_result = "krb5_mk_safe_stub";;

external krb5_rd_safe :
  krb5_context
  -> krb5_auth_context
  -> Bigsubstring.t
  -> out_buffer_result = "krb5_rd_safe_stub";;
