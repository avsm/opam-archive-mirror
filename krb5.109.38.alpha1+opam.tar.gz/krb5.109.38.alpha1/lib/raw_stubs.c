#include <stdio.h>
#include <string.h>
#include <krb5/krb5.h>

/* ntohs needs this the man page claims on Linux */
#include <arpa/inet.h>

#include <caml/mlvalues.h>
#include <caml/memory.h>
#include <caml/alloc.h>
#include <caml/custom.h>
#include <caml/bigarray.h>
#include <caml/fail.h>
#include <caml/threads.h>

#include "socketaddr.h"

/*
 * No fancy type handling for now.
 */
static struct custom_operations krb_default_ops = {
  "com.greenjeans.caml.krb",
  custom_finalize_default,
  custom_compare_default,
  custom_hash_default,
  custom_serialize_default,
  custom_deserialize_default,
  custom_compare_default
};

/*
 * Hopefully most of the dirty work of creating wrappers is handled here.
 * field val contains the krb5_ type val.
 * field id  contains a string to use for type checking and debugging.
 */
#define create_wrap(name)						\
  CAMLprim value create_ ## name() {					\
    CAMLparam0();							\
    CAMLlocal1(x);							\
    x = caml_alloc_custom(&krb_default_ops, \
        sizeof(struct wrap_ ## name), 0, 1); \
    memset(((struct wrap_ ## name *)Data_custom_val(x)),		\
	   0, sizeof(struct wrap_ ## name));				\
    ((struct wrap_ ## name *)Data_custom_val(x))->id = #name;		\
    CAMLreturn(x);							\
  }

#define make_wrap(name)							\
  struct wrap_ ## name {						\
    name val;								\
    char *id;								\
  };									\
  create_wrap(name)

#define make_ptr_wrap(name) \
  struct wrap_ ## name {    \
    name *val;		    \
    char *id;		    \
  };			    \
  create_wrap(name)

#define prn_debug(s) { printf ("DEBUG: %s\n", s); fflush(stdout); }

/*
 * Random things
 */
#define Val_ec(x) caml_copy_int32((x))

/*
 *
 * Access stuff in the wrappers
 *
 */
#define get_custom(name, v) ((struct wrap_ ## name *)Data_custom_val(v))
#define get_val(name, v) (get_custom(name, v)->val)
#define get_id(name, v) (get_custom(name, v)->id)
#define prn_id(name, v) printf("PRN_ID: %s, %s\n", #name, get_id(name, v));
#define set_val(name, v, new_val) (get_custom(name, (v)))->val = (new_val)

/*
 * Create Kerberos type wrappers.  We end up with structs and
 * functions called create_krb5_<the-type>(void).  Semi-colons here
 * makes strict compiler falgs unhappy.
 */
make_wrap(krb5_context)
make_wrap(krb5_principal)
make_wrap(krb5_ccache)
make_wrap(krb5_auth_context)
make_wrap(krb5_keytab)
make_wrap(krb5_creds)
make_ptr_wrap(krb5_error)
make_ptr_wrap(krb5_ap_rep_enc_part)
make_ptr_wrap(krb5_enctype)
make_ptr_wrap(krb5_ticket)

/*
 * Utility type wrappers.  No extra semi-colons...
 */
typedef char *string_storage;
make_wrap(string_storage)

/*
 *
 * Utility functions
 *
 */
CAMLprim value
my_k5u_get_error_text(value error) {
  CAMLparam1(error);
  krb5_error *err;
  char *s;

  err = get_val(krb5_error, error);
  if (err != NULL && err->text.data != NULL) {
    s = (char *)malloc(err->text.length + 1);
    strncpy(s, err->text.data, err->text.length);
    s[err->text.length] = 0;
    CAMLreturn(caml_copy_string(s));
    free(s);
  }
  CAMLreturn(caml_copy_string(""));
}

CAMLprim value
is_error(value error) {
  CAMLparam1(error);
  CAMLlocal1(rv);
  krb5_error *err;

  err = get_val(krb5_error, error);
  if (err != NULL && err->text.data != NULL) rv = Val_true;
  else rv = Val_false;
  CAMLreturn(rv);
}

CAMLprim value
is_auth_context(value auth_context) {
  CAMLparam1(auth_context);
  if (get_val(krb5_auth_context, auth_context) != 0) CAMLreturn(Val_true);
  CAMLreturn(Val_false);
}

CAMLprim value
is_krb_success(value ec) {
  CAMLparam1(ec);
  CAMLlocal1(rv);
  if (Int32_val(ec) == 0) rv = Val_true;
  else rv = Val_false;
  CAMLreturn(rv);
}

CAMLprim value
is_krb_failure(value ec) {
  CAMLparam1(ec);
  CAMLlocal1(rv);
  if (Int32_val(ec) == 0) rv = Val_false;
  else rv = Val_true;
  CAMLreturn(rv);
}

CAMLprim value
is_ap_rep_enc_part(value enc_part) {
  CAMLparam1(enc_part);
  if (get_val(krb5_ap_rep_enc_part, enc_part) != NULL) {
    CAMLreturn(Val_true);
  }
  CAMLreturn(Val_false);
}

/*
 * Weird utility function.  Take first two bytes from a buffer,
 * assume it is a network order 2 byte integer and then convert it to
 * host ordering.  Return an int.
 */
CAMLprim value
buffer_to_hs(value buffer) {
  CAMLparam1(buffer);
  short hs, ns;
  memmove(&ns, &Byte(buffer, 0), 2);
  hs = ntohs(ns);
  CAMLreturn(Val_int(hs));
}

CAMLprim value
hs_to_buffer(value o_hs) {
  CAMLparam1(o_hs);
  short ns;
  char *buffer;
  CAMLlocal1(o_buffer);
  ns = htons((short)Int_val(o_hs));
  o_buffer = caml_alloc_string(2);
  buffer = String_val(o_buffer);
  memmove(buffer, &ns, 2);
  CAMLreturn(o_buffer);
}

CAMLprim value
buffer_to_ns(value buffer) {
  CAMLparam1(buffer);
  short hs, ns;
  memmove(&hs, &Byte(buffer, 0), 2);
  ns = htons(hs);
  CAMLreturn(Val_int(hs));
}

CAMLprim value
get_string_from_storage(value sstore) {
  CAMLparam1(sstore);
  CAMLreturn(caml_copy_string(get_val(string_storage, sstore)));
}

/* Outputs a ('a, krb5_error_code) Core.Std.Result.t */
static CAMLprim value wrap_result(
    value v_data, krb5_error_code const error)
{
  CAMLparam1(v_data);
  CAMLlocal2(result, res_val);

  if(error == 0)
  {
    result = caml_alloc(1, 0);
    res_val = v_data;
  }
  else
  {
    result = caml_alloc(1, 1);
    res_val = Val_ec(error);
  }

  Store_field(result, 0, res_val);
  CAMLreturn(result);
}

/*
 *
 * Kerberos-ish primitives
 *
 */
CAMLprim value
my_krb5_init_context(void) {
  CAMLparam0();
  krb5_error_code retval;
  krb5_context context = NULL;
  CAMLlocal1(o_context);

  caml_release_runtime_system();
  retval = krb5_init_context(&context);
  caml_acquire_runtime_system();

  o_context = create_krb5_context();
  set_val(krb5_context, o_context, context);

  CAMLreturn(wrap_result(o_context, retval));
}

#define STR_BUFFER_SIZE 1028

static void str_cpy(char dest[STR_BUFFER_SIZE], value v_str)
{
  strncpy(dest, String_val(v_str), STR_BUFFER_SIZE);
  if(dest[STR_BUFFER_SIZE - 1] != '\0')
    caml_invalid_argument("string input too large, > 256 bytes");
}

CAMLprim value
my_krb5_sname_to_principal(value v_context, value v_hostname,
			   value v_sname, value v_type) {
  CAMLparam4(v_context, v_hostname, v_sname, v_type);
  CAMLlocal1(o_princ);

  krb5_int32 type = 0;
  krb5_error_code retval;
  krb5_principal princ = NULL;
  krb5_context context = get_val(krb5_context, v_context);
  char hostname[STR_BUFFER_SIZE];
  char service[STR_BUFFER_SIZE];

  str_cpy(hostname, v_hostname);
  str_cpy(service, v_sname);

  switch(Int_val(v_type))
  {
    case 0: type = KRB5_NT_SRV_HST; break;
    case 1: type = KRB5_NT_UNKNOWN; break;
    default: caml_invalid_argument(
                 "krb5_sname_to_principal: invalid sname_to_principal_type");
  }

  caml_release_runtime_system();
  retval = krb5_sname_to_principal(context,
				   hostname, service,
				   type, &princ);
  caml_acquire_runtime_system();

  o_princ = create_krb5_principal();
  set_val(krb5_principal, o_princ, princ);

  CAMLreturn(wrap_result(o_princ, retval));
}

CAMLprim value
my_krb5_cc_close(value v_context, value v_ccache) {
  CAMLparam2(v_context, v_ccache);
  krb5_error_code retval;

  krb5_context context = get_val(krb5_context, v_context);
  krb5_ccache ccache = get_val(krb5_ccache, v_ccache);

  caml_release_runtime_system();
  retval = krb5_cc_close(context, ccache);
  caml_acquire_runtime_system();

  CAMLreturn(Val_ec(retval));
}

CAMLprim value
my_krb5_cc_default(value v_context) {
  CAMLparam1(v_context);
  krb5_error_code retval;
  krb5_ccache ccache = NULL;
  CAMLlocal1(o_ccache);

  krb5_context context = get_val(krb5_context, v_context);

  caml_release_runtime_system();
  retval = krb5_cc_default(context, &ccache);
  caml_acquire_runtime_system();

  o_ccache = create_krb5_ccache();
  set_val(krb5_ccache, o_ccache, ccache);

  CAMLreturn(wrap_result(o_ccache, retval));
}

CAMLprim value
my_krb5_cc_initialize(value v_context, value v_ccache, value v_principal)
{
  CAMLparam3(v_context, v_ccache, v_principal);
  krb5_error_code retval;

  krb5_context context = get_val(krb5_context, v_context);
  krb5_ccache ccache = get_val(krb5_ccache, v_ccache);
  krb5_principal principal = get_val(krb5_principal, v_principal);

  caml_release_runtime_system();
  retval = krb5_cc_initialize(context, ccache, principal);
  caml_acquire_runtime_system();

  CAMLreturn(wrap_result(Val_unit, retval));
}

CAMLprim value
my_krb5_cc_get_principal(value v_context, value v_ccache) {
  CAMLparam2(v_context, v_ccache);
  krb5_error_code retval;
  krb5_principal princ = NULL;
  CAMLlocal1(o_princ);

  krb5_context context = get_val(krb5_context, v_context);
  krb5_ccache ccache = get_val(krb5_ccache, v_ccache);

  caml_release_runtime_system();
  retval = krb5_cc_get_principal(context, ccache, &princ);
  caml_acquire_runtime_system();

  o_princ = create_krb5_principal();
  set_val(krb5_principal, o_princ, princ);

  CAMLreturn(wrap_result(o_princ, retval));
}

/*
 *
 * This is not yet complete.  It fudges some of the arguments.
 *
 */
CAMLprim value
my_krb5_sendauth_native(value context,
			value sock, value appl_version,
			value client, value server,
			value appl_data,
			value ccache) {
  CAMLparam4(context, sock, appl_version, client);
  CAMLxparam3(server, appl_data, ccache);
  krb5_error_code retval;
  krb5_data cksum_data;
  krb5_auth_context auth_context = NULL;
  krb5_error *error = NULL;
  krb5_ap_rep_enc_part *rep_result = NULL;
  int localsock = Int_val(sock);
  CAMLlocal4(tuple, o_auth_context, o_error, o_rep_result);

  /*
  prn_id(krb5_context, context);
  prn_id(krb5_principal, client);
  prn_id(krb5_principal, server);
  prn_id(krb5_ccache, ccache);
  prn_id(krb5_error, error);
  prn_id(krb5_ap_rep_enc_part, rep_result);
  */

  cksum_data.data = String_val(appl_data);
  cksum_data.length = strlen(cksum_data.data);

  retval = krb5_sendauth(get_val(krb5_context, context),
       &auth_context,
			 (krb5_pointer)&localsock,
			 String_val(appl_version),
			 get_val(krb5_principal, client),
			 get_val(krb5_principal, server),
			 AP_OPTS_MUTUAL_REQUIRED, &cksum_data,
			 0,
			 get_val(krb5_ccache, ccache),
       &error,
       &rep_result,
			 NULL);

  o_auth_context = create_krb5_auth_context();
  o_error = create_krb5_error();
  o_rep_result = create_krb5_ap_rep_enc_part();

  set_val(krb5_auth_context, o_auth_context, auth_context);
  set_val(krb5_error, o_error, error);
  set_val(krb5_ap_rep_enc_part, o_rep_result, rep_result);

  tuple = caml_alloc_tuple(4);
  Store_field(tuple, 0, Val_ec(retval));
  Store_field(tuple, 1, o_auth_context);
  Store_field(tuple, 2, o_error);
  Store_field(tuple, 3, o_rep_result);

  CAMLreturn(tuple);
}

CAMLprim value
my_krb5_sendauth_bytecode(value *argv, int argn) {
  /* this check is mostly to make the compiler stop complaining
   * about argn not being used.
   */
  if (argn != 7) {
    fprintf (stderr, "Invalid number of arguments\n");
    exit(1);
  }
  return my_krb5_sendauth_native(argv[0], argv[1], argv[2], argv[3],
				 argv[4], argv[5], argv[6]);
}

CAMLprim value
my_krb5_recvauth(value o_context,
                 value o_sock,
                 value o_appl_version,
                 value o_server,
                 value o_keytab) {
  CAMLparam5(o_context, o_sock, o_appl_version, o_server, o_keytab);
  krb5_error_code retval;
  krb5_ticket *ticket = NULL;
  krb5_auth_context auth_context = NULL;
  int localsock = Int_val(o_sock);
  CAMLlocal1(o_ticket);
  CAMLlocal1(o_auth_context);
  CAMLlocal1(o_tuple);

  retval = krb5_recvauth(get_val(krb5_context, o_context),
                         &auth_context,
			 (krb5_pointer)&localsock,
			 String_val(o_appl_version),
			 get_val(krb5_principal, o_server),
                         (krb5_int32)0,
                         get_val(krb5_keytab, o_keytab),
                         &ticket);

  o_auth_context = create_krb5_auth_context();
  set_val(krb5_auth_context, o_auth_context, auth_context);

  o_ticket = create_krb5_ticket();
  set_val(krb5_ticket, o_ticket, ticket);

  o_tuple = caml_alloc_tuple(3);
  Store_field(o_tuple, 0, Val_ec(retval));
  Store_field(o_tuple, 1, o_auth_context);
  Store_field(o_tuple, 2, o_ticket);

  CAMLreturn(o_tuple);
}

CAMLprim value
my_krb5_free_ap_rep_enc_part(value context, value enc_part) {
  CAMLparam2(context, enc_part);

  krb5_free_ap_rep_enc_part(get_val(krb5_context, context),
			    get_val(krb5_ap_rep_enc_part, enc_part));
  CAMLreturn(Val_unit);
}

CAMLprim value
my_krb5_free_context(value context) {
  CAMLparam1(context);
  krb5_free_context(get_val(krb5_context, context));
  CAMLreturn(Val_unit);
}

CAMLprim value
my_krb5_auth_con_init(value v_context) {
  CAMLparam1(v_context);
  krb5_error_code retval;
  krb5_auth_context auth_context = NULL;
  CAMLlocal1(o_auth_context);

  krb5_context context = get_val(krb5_context, v_context);

  caml_release_runtime_system();
  retval = krb5_auth_con_init(context, &auth_context);
  caml_acquire_runtime_system();

  o_auth_context = create_krb5_auth_context();
  set_val(krb5_auth_context, o_auth_context, auth_context);

  CAMLreturn(wrap_result(o_auth_context, retval));
}

CAMLprim value
my_krb5_auth_con_free(value context, value auth_context) {
  CAMLparam2(context, auth_context);
  krb5_error_code retval;

  retval = krb5_auth_con_free(get_val(krb5_context, context),
			      get_val(krb5_auth_context, auth_context));

  CAMLreturn(Val_ec(retval));
}

CAMLprim value
my_krb5_free_cred_contents(value context, value creds) {
  CAMLparam2(context, creds);
  krb5_creds temp_creds = get_val(krb5_creds, creds);

  krb5_free_cred_contents(get_val(krb5_context, context),
                           &temp_creds);

  CAMLreturn(Val_unit);
}

CAMLprim value
my_krb5_parse_name(value context, value name) {
  CAMLparam2(context, name);
  krb5_error_code retval;
  krb5_principal princ = NULL;
  CAMLlocal1(o_princ);

  retval = krb5_parse_name(get_val(krb5_context, context),
			   String_val(name), &princ);

  if(retval)
    CAMLreturn(wrap_result(Val_unit, retval));
  else
  {
    o_princ = create_krb5_principal();
    set_val(krb5_principal, o_princ, princ);
    CAMLreturn(wrap_result(o_princ, retval));
  }
}

CAMLprim value
my_krb5_unparse_name(value context, value principal) {
  CAMLparam2(context, principal);
  krb5_error_code retval;
  char *string = NULL;
  CAMLlocal1(s);

  retval = krb5_unparse_name(get_val(krb5_context, context),
			     get_val(krb5_principal, principal),
			     &string);

  if(retval)
    CAMLreturn(wrap_result(Val_unit, retval));
  else
  {
    s = caml_copy_string(string);
    free(string);
    CAMLreturn(wrap_result(s, retval));
  }
}

CAMLprim value
my_krb5_copy_principal(value context, value inprinc) {
  CAMLparam2(context, inprinc);
  krb5_error_code retval;
  krb5_principal outprinc = NULL;
  CAMLlocal1(tuple);
  CAMLlocal1(o_outprinc);

  retval = krb5_copy_principal(get_val(krb5_context, context),
			       get_val(krb5_principal, inprinc),
             &outprinc);

  o_outprinc = create_krb5_principal();
  set_val(krb5_principal, o_outprinc, outprinc);

  tuple = caml_alloc_tuple(2);
  Store_field(tuple, 0, Val_ec(retval));
  Store_field(tuple, 1, o_outprinc);

  CAMLreturn(tuple);
}

CAMLprim value
my_krb5_free_ticket(value context, value ticket) {
  CAMLparam2(context, ticket);

  krb5_free_ticket(get_val(krb5_context, context),
          get_val(krb5_ticket, ticket));

  CAMLreturn(Val_unit);
}

CAMLprim value
my_krb5_free_error(value context, value error) {
  CAMLparam2(context, error);

  krb5_free_error(get_val(krb5_context, context),
		  get_val(krb5_error, error));

  CAMLreturn(Val_unit);
}

CAMLprim value
my_krb5_kt_resolve(value v_context, value v_keytab_name) {
  CAMLparam2(v_context, v_keytab_name);
  krb5_error_code retval;
  krb5_keytab keytab = NULL;
  CAMLlocal1(o_keytab);

  krb5_context context = get_val(krb5_context, v_context);

  char keytab_name[STR_BUFFER_SIZE];
  str_cpy(keytab_name, v_keytab_name);

  caml_release_runtime_system();
  retval = krb5_kt_resolve(context, keytab_name, &keytab);
  caml_acquire_runtime_system();

  o_keytab = create_krb5_keytab();
  set_val(krb5_keytab, o_keytab, keytab);

  CAMLreturn(wrap_result(o_keytab, retval));
}


CAMLprim value
my_k5u_ticket_client(value o_ticket) {
  CAMLparam1(o_ticket);
  krb5_ticket *ticket = get_val(krb5_ticket, o_ticket);
  CAMLlocal1(o_princ);

  o_princ = create_krb5_principal();
  set_val(krb5_principal, o_princ, ticket->enc_part2->client);

  CAMLreturn(o_princ);
}

CAMLprim value
my_krb5_kt_close(value o_context, value o_keytab) {
  CAMLparam2(o_context, o_keytab);
  krb5_error_code retval;

  retval = krb5_kt_close(get_val(krb5_context, o_context),
      get_val(krb5_keytab, o_keytab));

  CAMLreturn(Val_ec(retval));
}

CAMLprim value
my_krb5_free_principal(value o_context, value o_server) {
  CAMLparam2(o_context, o_server);

  krb5_free_principal(get_val(krb5_context, o_context),
      get_val(krb5_principal, o_server));

  CAMLreturn(Val_unit);
}

/* stuff vharvey thinks he needs */


/* Outputs a (bigsubstring, krb5_error_code) Core.Std.Result.t */
static CAMLprim value handle_outbuffer(
    krb5_data *data, krb5_error_code const error)
{
  CAMLparam0();
  CAMLlocal2(result, res_val);

  if(error == 0)
  {
    long length = data->length;
    result = caml_alloc(1, 0);
    res_val = caml_ba_alloc(
        CAML_BA_UINT8 | CAML_BA_C_LAYOUT | CAML_BA_MANAGED,
        1, data->data, &length);
  }
  else
  {
    result = caml_alloc(1, 1);
    res_val = Val_ec(error);
  }

  Store_field(result, 0, res_val);
  CAMLreturn(result);
}

static krb5_data data_of_bigsubstring(value v_bigsubstring)
{
  krb5_data ret;

  value v_input_data = Field(v_bigsubstring, 0);
  int in_pos = Int_val(Field(v_bigsubstring, 1));
  int in_len = Int_val(Field(v_bigsubstring, 2));

  ret.data = (char*)Caml_ba_data_val(v_input_data) + in_pos;
  ret.length = in_len;
  ret.magic = 0;

  return ret;
}

CAMLprim value
krb5_mk_req_native_stub(value v_context, value v_auth_context,
    value v_req_flags, value v_servicename, value v_hostname,
    value v_input, value v_ccache)
{
  CAMLparam5(v_context, v_auth_context, v_req_flags, v_servicename,
      v_hostname);
  CAMLxparam2(v_input, v_ccache);
  CAMLlocal1(out_bigstring);

  krb5_error_code err;
  krb5_context context = get_val(krb5_context, v_context);
  krb5_data inputbuf, outbuf, *inputbuf_ptr = NULL;
  krb5_flags flags = 0;
  krb5_auth_context auth_context = get_val(krb5_auth_context, v_auth_context);
  krb5_ccache ccache = get_val(krb5_ccache, v_ccache);
  char hostname[STR_BUFFER_SIZE];
  char service[STR_BUFFER_SIZE];
  str_cpy(hostname, v_hostname);
  str_cpy(service, v_servicename);

  if(Is_block(v_input))
  {
    value v_tuple = Field(v_input, 0);
    inputbuf = data_of_bigsubstring(v_tuple);
    inputbuf_ptr = &inputbuf;
  }

	while(v_req_flags != Val_int(0))
	{
		switch(Int_val(Field(v_req_flags, 0)))
    {
      case 0: flags |= AP_OPTS_USE_SESSION_KEY; break;
      case 1: flags |= AP_OPTS_MUTUAL_REQUIRED; break;
      default: caml_invalid_argument(
                   "krb5_mk_req_native_stub: invalid krb5_mk_req_flag");
    }

	  v_req_flags = Field(v_req_flags, 1);
	}

  /* because Bigstrings/Bigarray's/Bigsubstrings are allocated with malloc,
   * I don't have to worry about them being moved by the OCaml garbage
   * collector when I release the runtime system */
  caml_release_runtime_system();
  err = krb5_mk_req(
        context,
        &auth_context,
        flags,
        service,
        hostname,
        inputbuf_ptr,
        ccache,
        &outbuf);
  caml_acquire_runtime_system();

  CAMLreturn(handle_outbuffer(&outbuf, err));
}

CAMLprim value
krb5_mk_req_bytecode_stub(value *a, int const argn)
{
  (void)argn;
  return krb5_mk_req_native_stub(
    a[0], a[1], a[2], a[3], a[4], a[5], a[7]);
}

CAMLprim value
krb5_rd_req_stub(value v_context, value v_auth_context,
    value v_input, value v_principal, value v_keytab)
{
  CAMLparam5(v_context, v_auth_context, v_input, v_principal, v_keytab);
  CAMLlocal1(retv);

  krb5_context context = get_val(krb5_context, v_context);
  krb5_auth_context auth_context = get_val(krb5_auth_context, v_auth_context);
  krb5_principal principal = get_val(krb5_principal, v_principal);
  krb5_keytab keytab = get_val(krb5_keytab, v_keytab);

  krb5_error_code err;
  krb5_data inputbuf = data_of_bigsubstring(v_input);
  krb5_ticket *ticket = NULL;
  char *client_name = NULL;
  retv = Val_unit;

  caml_release_runtime_system();
  err = krb5_rd_req(
      context,
      &auth_context,
      &inputbuf,
      principal,
      keytab,
      NULL,
      &ticket);
  caml_acquire_runtime_system();

  if(!err)
  {
    err = krb5_unparse_name(context, ticket->enc_part2->client, &client_name);
    if(!err)
    {
      retv = caml_copy_string(client_name);
      free(client_name);
    }
    krb5_free_ticket(context, ticket);
  }

  CAMLreturn(wrap_result(retv, err));
}

static void add_to_list(value *v_list, value *v_iter, value v)
{
  CAMLparam1(v);
  CAMLlocal1(v_new);

  if(*v_iter == Val_int(0))
  {
    *v_iter = caml_alloc(2, 0);
    *v_list = *v_iter;
  }
  else
  {
    v_new = caml_alloc(2, 0);
    Store_field(*v_iter, 1, v_new);
    v_iter = &v_new;
  }

  Store_field(*v_iter, 0, v);
  Store_field(*v_iter, 1, Val_int(0));

  CAMLreturn0;
}

CAMLprim value
krb5_auth_con_getflags_stub(value v_context, value v_auth_context)
{
  CAMLparam2(v_context, v_auth_context);
  CAMLlocal2(v_res, v_iter);

  krb5_int32 flags;
  krb5_context context = get_val(krb5_context, v_context);
  krb5_auth_context auth_context = get_val(krb5_auth_context, v_auth_context);

  krb5_error_code err = krb5_auth_con_getflags(context, auth_context, &flags);

  if(err)
    CAMLreturn(wrap_result(v_res, err));

  if(flags & KRB5_AUTH_CONTEXT_DO_TIME)
    add_to_list(&v_res, &v_iter, Val_int(0));
  if(flags & KRB5_AUTH_CONTEXT_RET_TIME)
    add_to_list(&v_res, &v_iter, Val_int(1));
  if(flags & KRB5_AUTH_CONTEXT_DO_SEQUENCE)
    add_to_list(&v_res, &v_iter, Val_int(2));
  if(flags & KRB5_AUTH_CONTEXT_RET_SEQUENCE)
    add_to_list(&v_res, &v_iter, Val_int(3));

  CAMLreturn(wrap_result(v_res, err));
}

CAMLprim value
krb5_auth_con_setflags_stub(value v_context, value v_auth_context,
    value v_flags)
{
  CAMLparam3(v_context, v_auth_context, v_flags);

  krb5_int32 flags = 0;
  krb5_context context = get_val(krb5_context, v_context);
  krb5_auth_context auth_context = get_val(krb5_auth_context, v_auth_context);

  krb5_error_code err;

	while(v_flags != Val_int(0))
	{
		switch(Int_val(Field(v_flags, 0)))
    {
      case 0: flags |= KRB5_AUTH_CONTEXT_DO_TIME; break;
      case 1: flags |= KRB5_AUTH_CONTEXT_RET_TIME; break;
      case 2: flags |= KRB5_AUTH_CONTEXT_DO_SEQUENCE; break;
      case 3: flags |= KRB5_AUTH_CONTEXT_RET_SEQUENCE; break;
      default: caml_invalid_argument(
                   "krb5_mk_con_setflags_stub: invalid krb5_auth_context_flag");
    }

	  v_flags = Field(v_flags, 1);
	}

  err = krb5_auth_con_setflags(context, auth_context, flags);

  CAMLreturn(wrap_result(Val_unit, err));
}

CAMLprim value
krb5_auth_con_setaddrs_native_stub(value v_context, value v_auth_context,
    value v_inet, value v_port, value v_replay_name, value v_is_local)
{
  CAMLparam5(v_context, v_auth_context, v_inet, v_replay_name, v_is_local);
  CAMLxparam1(v_port);
  krb5_context context = get_val(krb5_context, v_context);
  krb5_auth_context auth_context = get_val(krb5_auth_context, v_auth_context);

  int local = Bool_val(v_is_local);

  struct in_addr *ml_addr = &GET_INET_ADDR(v_inet);

  krb5_address addr;
  krb5_error_code err;
  krb5_address *other_addr = NULL;

  /* unsigned short is the type of sockaddr_in.sin_port */
  unsigned short port = htons(Int_val(v_port));

  krb5_auth_con_getaddrs(
      context, auth_context,
      (local ? NULL : &other_addr),
      (local ? &other_addr : NULL));

  addr.addrtype = ADDRTYPE_INET;
  addr.length = sizeof(struct in_addr);
  addr.contents = (krb5_octet*)ml_addr;

  err = krb5_auth_con_setaddrs(
        context, auth_context,
        (local ? &addr : other_addr),
        (local ? other_addr : &addr));

  if(err)
    CAMLreturn(wrap_result(Val_unit, err));

  addr.addrtype = ADDRTYPE_IPPORT;
  addr.length = sizeof(port);
  addr.contents = (krb5_octet*)&port;

  err = krb5_auth_con_setaddrs(
        context, auth_context,
        (local ? &addr : other_addr),
        (local ? other_addr : &addr));

  if(err)
    CAMLreturn(wrap_result(Val_unit, err));

  if(Is_block(v_replay_name))
  {
    value v_replay_name_str = Field(v_replay_name, 0);
    krb5_rcache rcache;
    krb5_data rcache_name_packet;
    char rcache_name[STR_BUFFER_SIZE];
    str_cpy(rcache_name, v_replay_name_str);
    rcache_name_packet.length = strlen(rcache_name) + 1;
    rcache_name_packet.data = rcache_name;

    caml_release_runtime_system();

    err = krb5_get_server_rcache(context, &rcache_name_packet, &rcache);
    if(err)
    {
      caml_acquire_runtime_system();
      CAMLreturn(wrap_result(Val_unit, err));
    }
    err = krb5_auth_con_setrcache(context, auth_context, rcache);

    caml_acquire_runtime_system();
  }

  CAMLreturn(wrap_result(Val_unit, err));
}

CAMLprim value
krb5_auth_con_setaddrs_bytecode_stub(value *a, int const argn)
{
  (void)argn;
  return krb5_auth_con_setaddrs_native_stub(
    a[0], a[1], a[2], a[3], a[4], a[5]);
}

typedef krb5_error_code
(*priv_msg_func)(
    krb5_context,
    krb5_auth_context,
    krb5_data const*,
    krb5_data*,
    krb5_replay_data*);

static CAMLprim value
krb5_msg_func(value v_context, value v_auth_context, value v_in,
    priv_msg_func msg_func)
{
  CAMLparam3(v_context, v_auth_context, v_in);

  krb5_context context = get_val(krb5_context, v_context);
  krb5_auth_context auth_context = get_val(krb5_auth_context, v_auth_context);
  krb5_error_code err;
  krb5_data inputbuf, outbuf;

  inputbuf = data_of_bigsubstring(v_in);

  caml_release_runtime_system();
  err = msg_func(
      context,
      auth_context,
      &inputbuf,
      &outbuf, NULL);
  caml_acquire_runtime_system();

  CAMLreturn(handle_outbuffer(&outbuf, err));
}

CAMLprim value
krb5_mk_priv_stub(value v_context, value v_auth_context, value v_in)
{ return krb5_msg_func(v_context, v_auth_context, v_in, krb5_mk_priv); }

CAMLprim value
krb5_rd_priv_stub(value v_context, value v_auth_context, value v_in)
{ return krb5_msg_func(v_context, v_auth_context, v_in, krb5_rd_priv); }

CAMLprim value
krb5_mk_safe_stub(value v_context, value v_auth_context, value v_in)
{ return krb5_msg_func(v_context, v_auth_context, v_in, krb5_mk_safe); }

CAMLprim value
krb5_rd_safe_stub(value v_context, value v_auth_context, value v_in)
{ return krb5_msg_func(v_context, v_auth_context, v_in, krb5_rd_safe); }

CAMLprim value
krb5_get_error_message_stub(value v_context, value v_error_code)
{
  CAMLparam2(v_context, v_error_code);

  CAMLreturn(caml_copy_string(
        krb5_get_error_message(
          get_val(krb5_context, v_context),
          Int32_val(v_error_code))));
}

/* more kilburg stuff */

CAMLprim value
krb5_get_init_creds_password_stub(value o_context,
                                  value o_client, value o_password) {
  CAMLparam3(o_context, o_client, o_password);
  krb5_context context = get_val(krb5_context, o_context);
  krb5_error_code err;
  krb5_creds creds;
  krb5_get_init_creds_opt *opt;
  krb5_principal client = get_val(krb5_principal, o_client);
  char password[STR_BUFFER_SIZE];
  CAMLlocal1(o_creds);

  str_cpy(password, o_password);

  caml_release_runtime_system();

  /* make these options and more args available to ocaml */
  krb5_get_init_creds_opt_alloc (context, &opt);
  krb5_get_init_creds_opt_set_tkt_life (opt, 300);
  krb5_get_init_creds_opt_set_forwardable (opt, FALSE);
  krb5_get_init_creds_opt_set_proxiable (opt, FALSE);
  err = krb5_get_init_creds_password(context,
                                     &creds,
                                     client,
                                     password,
                                     NULL,
                                     NULL,
                                     0,
                                     NULL,
                                     opt);
  krb5_get_init_creds_opt_free(context, opt);

  caml_acquire_runtime_system();

  o_creds = create_krb5_creds();
  set_val(krb5_creds, o_creds, creds);

  CAMLreturn(wrap_result(o_creds, err));
}
