open Core.Std
open Async.Std

let (>>=?) = Deferred.Or_error.(>>=)

let inet_of_fd ~f fd =
  let open Result.Monad_infix in
  Or_error.try_with (fun () -> Fd.file_descr_exn fd)
  >>= fun file_desc ->
  let sockaddr = f file_desc in
  (match sockaddr with
  | Core.Std.Unix.ADDR_UNIX _ -> Or_error.error_string "Not an inet socket"
  | Core.Std.Unix.ADDR_INET (inet, port) -> Ok (`Inet (inet, port)))

let local_inet_of_fd = inet_of_fd ~f:Core.Std.Unix.getsockname
let remote_inet_of_fd = inet_of_fd ~f:Core.Std.Unix.getpeername

module Error_code = Safe.Error_code

module Context = struct
  type async_data = In_thread.Helper_thread.t
  type 'a t = ('a * async_data) Safe.Context.t

  let data   t = fst (Safe.Context.data t)
  let thread t = snd (Safe.Context.data t)

  let run t ~f = In_thread.run ~thread:(thread t) (fun () -> f t)

  let init data =
    Deferred.return (In_thread.Helper_thread.create ~name:"Krb5_context" ())
    >>=? fun thread ->
    In_thread.run ~thread (fun () -> Safe.Context.init (data, thread))

  let error_msg = Safe.Context.error_msg
end

module Cred_cache = struct
  include Safe.Cred_cache

  let default context = Context.run context ~f:Safe.Cred_cache.default
end

module Keytab = struct
  include Safe.Keytab

  let resolve context ~path =
    Context.run context ~f:(Safe.Keytab.resolve ~path)
end

module Principal = struct
  type t = Safe.Principal.t

  module Of_sname_type = Safe.Principal.Of_sname_type

  let of_sname context ~service ~hostname of_sname_type =
    Context.run context ~f:(fun c ->
      Safe.Principal.of_sname c ~service ~hostname of_sname_type)

  let of_string context name =
    Context.run context ~f:(fun c ->
      Safe.Principal.of_string c name)

  let to_string context t =
    Context.run context ~f:(fun c ->
      Safe.Principal.to_string c t)

  let check_password context t ~password =
    Context.run context ~f:(fun c ->
      Safe.Principal.check_password c t ~password)
end

module Peer_context = struct
  type 'a t = ('a * Context.async_data) Safe.Peer_context.t

  let context = Safe.Peer_context.context
end

module Service_context = struct
  type 'a t = ('a * Context.async_data) Safe.Service_context.t

  let peer_context = Safe.Service_context.peer_context

  let client_name  = Safe.Service_context.client_name

  let init context principal keytab ~in_data
      ~local_inet:(`Inet (local_addr, local_port))
      ~remote_inet:(`Inet (remote_addr, remote_port)) =
    Context.run context ~f:(fun c ->
      Safe.Service_context.init
        c
        principal
        keytab
        ~in_data
        ~local_addr
        ~local_port
        ~remote_addr
        ~remote_port)
end

module Client_context = struct
  type 'a t = ('a * Context.async_data) Safe.Client_context.t
  type request = Bigstring.t

  module Flag = Safe.Client_context.Flag

  let peer_context = Safe.Client_context.peer_context

  let init ?in_data ?replay_id context ccache flags ~service ~hostname
      ~local_inet:(`Inet (local_addr, local_port))
      ~remote_inet:(`Inet (remote_addr, remote_port)) =
    Context.run context ~f:(fun c ->
      (Safe.Client_context.init
         ?in_data
         ?replay_id
         c
         ccache
         flags
         ~service
         ~hostname
         ~local_addr
         ~local_port
         ~remote_addr
         ~remote_port))
end

let mk_priv = Safe.mk_priv
let rd_priv = Safe.rd_priv

let mk_safe = Safe.mk_safe
let rd_safe = Safe.rd_safe
