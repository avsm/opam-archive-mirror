
# 20 "data_parser.dyp"
        

  open Abstract_syntax
(*  open Syntactic_data_structures*)
  open Dyp

  module Env = Utils.StringSet
    

  type token=Acg_token.Token.t
  open Acg_token.Token
(*  type token=t*) 

  module Make (E:Environment.Environment_sig) =
  struct  


    type local_data =
      | Signature of E.Signature1.t
      | Abs_and_obj of (E.Signature1.t * E.Signature1.t)
      | Env of E.t


let _ = () (* dummy line to improve OCaml error location *)
# 28                 "data_parser_temp.ml"
let _ =
  if "20120619" <> Dyp.version
  then (Printf.fprintf stderr
    "version mismatch, dypgen version 20120619 and dyplib version %s\n" Dyp.version;
  exit 2)

module Dyp_symbols =
struct
  let get_token_name t = match t with
    | ARROW _ -> 0
    | BINDER _ -> 1
    | COLON _ -> 2
    | COLON_EQUAL _ -> 3
    | COMMA _ -> 4
    | COMPOSE _ -> 5
    | DOT _ -> 6
    | END_OF_DEC _ -> 7
    | EOI -> 8
    | EQUAL _ -> 9
    | IDENT _ -> 10
    | INFIX _ -> 11
    | LAMBDA _ -> 12
    | LAMBDA0 _ -> 13
    | LEX_OPEN _ -> 14
    | LIN_ARROW _ -> 15
    | LPAREN _ -> 16
    | PREFIX _ -> 17
    | RPAREN _ -> 18
    | SEMICOLON _ -> 19
    | SIG_OPEN _ -> 20
    | SYMBOL _ -> 21
    | TYPE _ -> 22
  let str_token t = match t with
    | ARROW _ -> "ARROW"
    | BINDER _ -> "BINDER"
    | COLON _ -> "COLON"
    | COLON_EQUAL _ -> "COLON_EQUAL"
    | COMMA _ -> "COMMA"
    | COMPOSE _ -> "COMPOSE"
    | DOT _ -> "DOT"
    | END_OF_DEC _ -> "END_OF_DEC"
    | EOI -> "EOI"
    | EQUAL _ -> "EQUAL"
    | IDENT _ -> "IDENT"
    | INFIX _ -> "INFIX"
    | LAMBDA _ -> "LAMBDA"
    | LAMBDA0 _ -> "LAMBDA0"
    | LEX_OPEN _ -> "LEX_OPEN"
    | LIN_ARROW _ -> "LIN_ARROW"
    | LPAREN _ -> "LPAREN"
    | PREFIX _ -> "PREFIX"
    | RPAREN _ -> "RPAREN"
    | SEMICOLON _ -> "SEMICOLON"
    | SIG_OPEN _ -> "SIG_OPEN"
    | SYMBOL _ -> "SYMBOL"
    | TYPE _ -> "TYPE"
  let ter_string_list = [
      ("ARROW",0);
      ("BINDER",1);
      ("COLON",2);
      ("COLON_EQUAL",3);
      ("COMMA",4);
      ("COMPOSE",5);
      ("DOT",6);
      ("END_OF_DEC",7);
      ("EOI",8);
      ("EQUAL",9);
      ("IDENT",10);
      ("INFIX",11);
      ("LAMBDA",12);
      ("LAMBDA0",13);
      ("LEX_OPEN",14);
      ("LIN_ARROW",15);
      ("LPAREN",16);
      ("PREFIX",17);
      ("RPAREN",18);
      ("SEMICOLON",19);
      ("SIG_OPEN",20);
      ("SYMBOL",21);
      ("TYPE",22);]
end

type ('dypgen__Inh_dypgen__early_action_0, 'dypgen__Inh_dypgen__early_action_1, 'dypgen__Inh_dypgen__early_action_2, 'dypgen__Inh_dypgen__early_action_3, 'dypgen__Inh_dypgen__early_action_4, 'dypgen__Inh_dypgen__early_action_5, 'dypgen__Inh_dypgen__early_action_6, 'dypgen__Inh_dypgen__early_action_7, 'dypgen__Inh_dypgen__early_action_8, 'dypgen__Obj_application, 'dypgen__Obj_arrow, 'dypgen__Obj_atomic_term, 'dypgen__Obj_atomic_type, 'dypgen__Obj_comma_ids, 'dypgen__Obj_comma_ids_or_sym, 'dypgen__Obj_composition_argument, 'dypgen__Obj_data, 'dypgen__Obj_dypgen__early_action_0, 'dypgen__Obj_dypgen__early_action_1, 'dypgen__Obj_dypgen__early_action_2, 'dypgen__Obj_dypgen__early_action_3, 'dypgen__Obj_dypgen__early_action_4, 'dypgen__Obj_dypgen__early_action_5, 'dypgen__Obj_dypgen__early_action_6, 'dypgen__Obj_dypgen__early_action_7, 'dypgen__Obj_dypgen__early_action_8, 'dypgen__Obj_dypgen__epsilon, 'dypgen__Obj_heterogenous_term_and_type, 'dypgen__Obj_idents, 'dypgen__Obj_lex_entries, 'dypgen__Obj_lex_entry, 'dypgen__Obj_lex_opening, 'dypgen__Obj_lexicon, 'dypgen__Obj_lexicon_composition, 'dypgen__Obj_sig_entries, 'dypgen__Obj_sig_entry, 'dypgen__Obj_sig_ident, 'dypgen__Obj_signature, 'dypgen__Obj_term, 'dypgen__Obj_term_alone, 'dypgen__Obj_term_dec_start, 'dypgen__Obj_term_declaration, 'dypgen__Obj_term_def_start, 'dypgen__Obj_term_definition, 'dypgen__Obj_type_declaration, 'dypgen__Obj_type_definition, 'dypgen__Obj_type_expression) obj =
  | Inh_dypgen__early_action_0 of 'dypgen__Inh_dypgen__early_action_0
  | Inh_dypgen__early_action_1 of 'dypgen__Inh_dypgen__early_action_1
  | Inh_dypgen__early_action_2 of 'dypgen__Inh_dypgen__early_action_2
  | Inh_dypgen__early_action_3 of 'dypgen__Inh_dypgen__early_action_3
  | Inh_dypgen__early_action_4 of 'dypgen__Inh_dypgen__early_action_4
  | Inh_dypgen__early_action_5 of 'dypgen__Inh_dypgen__early_action_5
  | Inh_dypgen__early_action_6 of 'dypgen__Inh_dypgen__early_action_6
  | Inh_dypgen__early_action_7 of 'dypgen__Inh_dypgen__early_action_7
  | Inh_dypgen__early_action_8 of 'dypgen__Inh_dypgen__early_action_8
  | Lexeme_matched of string
  | Obj_ARROW of (Abstract_syntax.location)
  | Obj_BINDER of (Abstract_syntax.location)
  | Obj_COLON of (Abstract_syntax.location)
  | Obj_COLON_EQUAL of (Abstract_syntax.location)
  | Obj_COMMA of (Abstract_syntax.location)
  | Obj_COMPOSE of (Abstract_syntax.location)
  | Obj_DOT of (Abstract_syntax.location)
  | Obj_END_OF_DEC of (Abstract_syntax.location)
  | Obj_EOI
  | Obj_EQUAL of (Abstract_syntax.location)
  | Obj_IDENT of ((string*Abstract_syntax.location))
  | Obj_INFIX of (Abstract_syntax.location)
  | Obj_LAMBDA of (Abstract_syntax.location)
  | Obj_LAMBDA0 of (Abstract_syntax.location)
  | Obj_LEX_OPEN of (Abstract_syntax.location)
  | Obj_LIN_ARROW of (Abstract_syntax.location)
  | Obj_LPAREN of (Abstract_syntax.location)
  | Obj_PREFIX of (Abstract_syntax.location)
  | Obj_RPAREN of (Abstract_syntax.location)
  | Obj_SEMICOLON of (Abstract_syntax.location)
  | Obj_SIG_OPEN of (Abstract_syntax.location)
  | Obj_SYMBOL of ((string*Abstract_syntax.location))
  | Obj_TYPE of (Abstract_syntax.location)
  | Obj_application of 'dypgen__Obj_application
  | Obj_arrow of 'dypgen__Obj_arrow
  | Obj_atomic_term of 'dypgen__Obj_atomic_term
  | Obj_atomic_type of 'dypgen__Obj_atomic_type
  | Obj_comma_ids of 'dypgen__Obj_comma_ids
  | Obj_comma_ids_or_sym of 'dypgen__Obj_comma_ids_or_sym
  | Obj_composition_argument of 'dypgen__Obj_composition_argument
  | Obj_data of 'dypgen__Obj_data
  | Obj_dypgen__early_action_0 of 'dypgen__Obj_dypgen__early_action_0
  | Obj_dypgen__early_action_1 of 'dypgen__Obj_dypgen__early_action_1
  | Obj_dypgen__early_action_2 of 'dypgen__Obj_dypgen__early_action_2
  | Obj_dypgen__early_action_3 of 'dypgen__Obj_dypgen__early_action_3
  | Obj_dypgen__early_action_4 of 'dypgen__Obj_dypgen__early_action_4
  | Obj_dypgen__early_action_5 of 'dypgen__Obj_dypgen__early_action_5
  | Obj_dypgen__early_action_6 of 'dypgen__Obj_dypgen__early_action_6
  | Obj_dypgen__early_action_7 of 'dypgen__Obj_dypgen__early_action_7
  | Obj_dypgen__early_action_8 of 'dypgen__Obj_dypgen__early_action_8
  | Obj_dypgen__epsilon of 'dypgen__Obj_dypgen__epsilon
  | Obj_heterogenous_term_and_type of 'dypgen__Obj_heterogenous_term_and_type
  | Obj_idents of 'dypgen__Obj_idents
  | Obj_lex_entries of 'dypgen__Obj_lex_entries
  | Obj_lex_entry of 'dypgen__Obj_lex_entry
  | Obj_lex_opening of 'dypgen__Obj_lex_opening
  | Obj_lexicon of 'dypgen__Obj_lexicon
  | Obj_lexicon_composition of 'dypgen__Obj_lexicon_composition
  | Obj_sig_entries of 'dypgen__Obj_sig_entries
  | Obj_sig_entry of 'dypgen__Obj_sig_entry
  | Obj_sig_ident of 'dypgen__Obj_sig_ident
  | Obj_signature of 'dypgen__Obj_signature
  | Obj_term of 'dypgen__Obj_term
  | Obj_term_alone of 'dypgen__Obj_term_alone
  | Obj_term_dec_start of 'dypgen__Obj_term_dec_start
  | Obj_term_declaration of 'dypgen__Obj_term_declaration
  | Obj_term_def_start of 'dypgen__Obj_term_def_start
  | Obj_term_definition of 'dypgen__Obj_term_definition
  | Obj_type_declaration of 'dypgen__Obj_type_declaration
  | Obj_type_definition of 'dypgen__Obj_type_definition
  | Obj_type_expression of 'dypgen__Obj_type_expression

module Dyp_symbols_array =
struct
  let token_name_array =
  [|"ARROW";
    "BINDER";
    "COLON";
    "COLON_EQUAL";
    "COMMA";
    "COMPOSE";
    "DOT";
    "END_OF_DEC";
    "EOI";
    "EQUAL";
    "IDENT";
    "INFIX";
    "LAMBDA";
    "LAMBDA0";
    "LEX_OPEN";
    "LIN_ARROW";
    "LPAREN";
    "PREFIX";
    "RPAREN";
    "SEMICOLON";
    "SIG_OPEN";
    "SYMBOL";
    "TYPE"|]
  let nt_cons_list =
  [
    ("0_1",49);
    ("application",32);
    ("arrow",33);
    ("atomic_term",34);
    ("atomic_type",35);
    ("comma_ids",36);
    ("comma_ids_or_sym",37);
    ("composition_argument",38);
    ("data",39);
    ("dypgen__early_action_0",40);
    ("dypgen__early_action_1",41);
    ("dypgen__early_action_2",42);
    ("dypgen__early_action_3",43);
    ("dypgen__early_action_4",44);
    ("dypgen__early_action_5",45);
    ("dypgen__early_action_6",46);
    ("dypgen__early_action_7",47);
    ("dypgen__early_action_8",48);
    ("heterogenous_term_and_type",50);
    ("idents",51);
    ("lex_entries",52);
    ("lex_entry",53);
    ("lex_opening",54);
    ("lexicon",55);
    ("lexicon_composition",56);
    ("sig_entries",57);
    ("sig_entry",58);
    ("sig_ident",59);
    ("signature",60);
    ("term",61);
    ("term_alone",62);
    ("term_dec_start",63);
    ("term_declaration",64);
    ("term_def_start",65);
    ("term_definition",66);
    ("type_declaration",67);
    ("type_definition",68);
    ("type_expression",69)]
  let str_cons o = match o with
    | Inh_dypgen__early_action_0 _ -> "Inh_dypgen__early_action_0"
    | Inh_dypgen__early_action_1 _ -> "Inh_dypgen__early_action_1"
    | Inh_dypgen__early_action_2 _ -> "Inh_dypgen__early_action_2"
    | Inh_dypgen__early_action_3 _ -> "Inh_dypgen__early_action_3"
    | Inh_dypgen__early_action_4 _ -> "Inh_dypgen__early_action_4"
    | Inh_dypgen__early_action_5 _ -> "Inh_dypgen__early_action_5"
    | Inh_dypgen__early_action_6 _ -> "Inh_dypgen__early_action_6"
    | Inh_dypgen__early_action_7 _ -> "Inh_dypgen__early_action_7"
    | Inh_dypgen__early_action_8 _ -> "Inh_dypgen__early_action_8"
    | Lexeme_matched _ -> "Lexeme_matched"
    | Obj_ARROW _ -> "Obj_ARROW"
    | Obj_BINDER _ -> "Obj_BINDER"
    | Obj_COLON _ -> "Obj_COLON"
    | Obj_COLON_EQUAL _ -> "Obj_COLON_EQUAL"
    | Obj_COMMA _ -> "Obj_COMMA"
    | Obj_COMPOSE _ -> "Obj_COMPOSE"
    | Obj_DOT _ -> "Obj_DOT"
    | Obj_END_OF_DEC _ -> "Obj_END_OF_DEC"
    | Obj_EQUAL _ -> "Obj_EQUAL"
    | Obj_IDENT _ -> "Obj_IDENT"
    | Obj_INFIX _ -> "Obj_INFIX"
    | Obj_LAMBDA _ -> "Obj_LAMBDA"
    | Obj_LAMBDA0 _ -> "Obj_LAMBDA0"
    | Obj_LEX_OPEN _ -> "Obj_LEX_OPEN"
    | Obj_LIN_ARROW _ -> "Obj_LIN_ARROW"
    | Obj_LPAREN _ -> "Obj_LPAREN"
    | Obj_PREFIX _ -> "Obj_PREFIX"
    | Obj_RPAREN _ -> "Obj_RPAREN"
    | Obj_SEMICOLON _ -> "Obj_SEMICOLON"
    | Obj_SIG_OPEN _ -> "Obj_SIG_OPEN"
    | Obj_SYMBOL _ -> "Obj_SYMBOL"
    | Obj_TYPE _ -> "Obj_TYPE"
    | Obj_application _ -> "Obj_application"
    | Obj_arrow _ -> "Obj_arrow"
    | Obj_atomic_term _ -> "Obj_atomic_term"
    | Obj_atomic_type _ -> "Obj_atomic_type"
    | Obj_comma_ids _ -> "Obj_comma_ids"
    | Obj_comma_ids_or_sym _ -> "Obj_comma_ids_or_sym"
    | Obj_composition_argument _ -> "Obj_composition_argument"
    | Obj_data _ -> "Obj_data"
    | Obj_dypgen__early_action_0 _ -> "Obj_dypgen__early_action_0"
    | Obj_dypgen__early_action_1 _ -> "Obj_dypgen__early_action_1"
    | Obj_dypgen__early_action_2 _ -> "Obj_dypgen__early_action_2"
    | Obj_dypgen__early_action_3 _ -> "Obj_dypgen__early_action_3"
    | Obj_dypgen__early_action_4 _ -> "Obj_dypgen__early_action_4"
    | Obj_dypgen__early_action_5 _ -> "Obj_dypgen__early_action_5"
    | Obj_dypgen__early_action_6 _ -> "Obj_dypgen__early_action_6"
    | Obj_dypgen__early_action_7 _ -> "Obj_dypgen__early_action_7"
    | Obj_dypgen__early_action_8 _ -> "Obj_dypgen__early_action_8"
    | Obj_dypgen__epsilon _ -> "Obj_dypgen__epsilon"
    | Obj_heterogenous_term_and_type _ -> "Obj_heterogenous_term_and_type"
    | Obj_idents _ -> "Obj_idents"
    | Obj_lex_entries _ -> "Obj_lex_entries"
    | Obj_lex_entry _ -> "Obj_lex_entry"
    | Obj_lex_opening _ -> "Obj_lex_opening"
    | Obj_lexicon _ -> "Obj_lexicon"
    | Obj_lexicon_composition _ -> "Obj_lexicon_composition"
    | Obj_sig_entries _ -> "Obj_sig_entries"
    | Obj_sig_entry _ -> "Obj_sig_entry"
    | Obj_sig_ident _ -> "Obj_sig_ident"
    | Obj_signature _ -> "Obj_signature"
    | Obj_term _ -> "Obj_term"
    | Obj_term_alone _ -> "Obj_term_alone"
    | Obj_term_dec_start _ -> "Obj_term_dec_start"
    | Obj_term_declaration _ -> "Obj_term_declaration"
    | Obj_term_def_start _ -> "Obj_term_def_start"
    | Obj_term_definition _ -> "Obj_term_definition"
    | Obj_type_declaration _ -> "Obj_type_declaration"
    | Obj_type_definition _ -> "Obj_type_definition"
    | Obj_type_expression _ -> "Obj_type_expression"
    | _ -> failwith "str_cons, unexpected constructor"
  let cons_array = [|
    "Inh_dypgen__early_action_0";
    "Inh_dypgen__early_action_1";
    "Inh_dypgen__early_action_2";
    "Inh_dypgen__early_action_3";
    "Inh_dypgen__early_action_4";
    "Inh_dypgen__early_action_5";
    "Inh_dypgen__early_action_6";
    "Inh_dypgen__early_action_7";
    "Inh_dypgen__early_action_8";
    "Lexeme_matched";
    "Obj_ARROW";
    "Obj_BINDER";
    "Obj_COLON";
    "Obj_COLON_EQUAL";
    "Obj_COMMA";
    "Obj_COMPOSE";
    "Obj_DOT";
    "Obj_END_OF_DEC";
    "Obj_EQUAL";
    "Obj_IDENT";
    "Obj_INFIX";
    "Obj_LAMBDA";
    "Obj_LAMBDA0";
    "Obj_LEX_OPEN";
    "Obj_LIN_ARROW";
    "Obj_LPAREN";
    "Obj_PREFIX";
    "Obj_RPAREN";
    "Obj_SEMICOLON";
    "Obj_SIG_OPEN";
    "Obj_SYMBOL";
    "Obj_TYPE";
    "Obj_application";
    "Obj_arrow";
    "Obj_atomic_term";
    "Obj_atomic_type";
    "Obj_comma_ids";
    "Obj_comma_ids_or_sym";
    "Obj_composition_argument";
    "Obj_data";
    "Obj_dypgen__early_action_0";
    "Obj_dypgen__early_action_1";
    "Obj_dypgen__early_action_2";
    "Obj_dypgen__early_action_3";
    "Obj_dypgen__early_action_4";
    "Obj_dypgen__early_action_5";
    "Obj_dypgen__early_action_6";
    "Obj_dypgen__early_action_7";
    "Obj_dypgen__early_action_8";
    "Obj_dypgen__epsilon";
    "Obj_heterogenous_term_and_type";
    "Obj_idents";
    "Obj_lex_entries";
    "Obj_lex_entry";
    "Obj_lex_opening";
    "Obj_lexicon";
    "Obj_lexicon_composition";
    "Obj_sig_entries";
    "Obj_sig_entry";
    "Obj_sig_ident";
    "Obj_signature";
    "Obj_term";
    "Obj_term_alone";
    "Obj_term_dec_start";
    "Obj_term_declaration";
    "Obj_term_def_start";
    "Obj_term_definition";
    "Obj_type_declaration";
    "Obj_type_definition";
    "Obj_type_expression";
    "";
  |]
  let entry_points = [
    "type_expression";
    "term";
    "heterogenous_term_and_type";
    "term_alone";
    "lex_entry";
    "sig_entry";
    "data";]
end

let dypgen_lexbuf_position lexbuf =
  (lexbuf.Lexing.lex_start_p,lexbuf.Lexing.lex_curr_p)

module Dyp_aux_functions =
struct
  let get_token_value t = match t with
    | ARROW x -> Obj_ARROW x
    | BINDER x -> Obj_BINDER x
    | COLON x -> Obj_COLON x
    | COLON_EQUAL x -> Obj_COLON_EQUAL x
    | COMMA x -> Obj_COMMA x
    | COMPOSE x -> Obj_COMPOSE x
    | DOT x -> Obj_DOT x
    | END_OF_DEC x -> Obj_END_OF_DEC x
    | EOI -> Obj_EOI
    | EQUAL x -> Obj_EQUAL x
    | IDENT x -> Obj_IDENT x
    | INFIX x -> Obj_INFIX x
    | LAMBDA x -> Obj_LAMBDA x
    | LAMBDA0 x -> Obj_LAMBDA0 x
    | LEX_OPEN x -> Obj_LEX_OPEN x
    | LIN_ARROW x -> Obj_LIN_ARROW x
    | LPAREN x -> Obj_LPAREN x
    | PREFIX x -> Obj_PREFIX x
    | RPAREN x -> Obj_RPAREN x
    | SEMICOLON x -> Obj_SEMICOLON x
    | SIG_OPEN x -> Obj_SIG_OPEN x
    | SYMBOL x -> Obj_SYMBOL x
    | TYPE x -> Obj_TYPE x
  let cons_table = Dyp.Tools.hashtbl_of_array Dyp_symbols_array.cons_array
end

module Dyp_priority_data =
struct
  let relations = [
    ["atom_type";"arrow_type";];
    ["atom";"app";"sym_app";"binder";];
  ]
end

let global_data = ()
let local_data = ()
let global_data_equal = (==)
let local_data_equal = (==)

let dyp_merge_Inh_dypgen__early_action_0 = Dyp.Tools.keep_zero
let dyp_merge_Inh_dypgen__early_action_1 = Dyp.Tools.keep_zero
let dyp_merge_Inh_dypgen__early_action_2 = Dyp.Tools.keep_zero
let dyp_merge_Inh_dypgen__early_action_3 = Dyp.Tools.keep_zero
let dyp_merge_Inh_dypgen__early_action_4 = Dyp.Tools.keep_zero
let dyp_merge_Inh_dypgen__early_action_5 = Dyp.Tools.keep_zero
let dyp_merge_Inh_dypgen__early_action_6 = Dyp.Tools.keep_zero
let dyp_merge_Inh_dypgen__early_action_7 = Dyp.Tools.keep_zero
let dyp_merge_Inh_dypgen__early_action_8 = Dyp.Tools.keep_zero
let dyp_merge_Lexeme_matched = Dyp.Tools.keep_zero
let dyp_merge_Obj_ARROW = Dyp.Tools.keep_zero
let dyp_merge_Obj_BINDER = Dyp.Tools.keep_zero
let dyp_merge_Obj_COLON = Dyp.Tools.keep_zero
let dyp_merge_Obj_COLON_EQUAL = Dyp.Tools.keep_zero
let dyp_merge_Obj_COMMA = Dyp.Tools.keep_zero
let dyp_merge_Obj_COMPOSE = Dyp.Tools.keep_zero
let dyp_merge_Obj_DOT = Dyp.Tools.keep_zero
let dyp_merge_Obj_END_OF_DEC = Dyp.Tools.keep_zero
let dyp_merge_Obj_EQUAL = Dyp.Tools.keep_zero
let dyp_merge_Obj_IDENT = Dyp.Tools.keep_zero
let dyp_merge_Obj_INFIX = Dyp.Tools.keep_zero
let dyp_merge_Obj_LAMBDA = Dyp.Tools.keep_zero
let dyp_merge_Obj_LAMBDA0 = Dyp.Tools.keep_zero
let dyp_merge_Obj_LEX_OPEN = Dyp.Tools.keep_zero
let dyp_merge_Obj_LIN_ARROW = Dyp.Tools.keep_zero
let dyp_merge_Obj_LPAREN = Dyp.Tools.keep_zero
let dyp_merge_Obj_PREFIX = Dyp.Tools.keep_zero
let dyp_merge_Obj_RPAREN = Dyp.Tools.keep_zero
let dyp_merge_Obj_SEMICOLON = Dyp.Tools.keep_zero
let dyp_merge_Obj_SIG_OPEN = Dyp.Tools.keep_zero
let dyp_merge_Obj_SYMBOL = Dyp.Tools.keep_zero
let dyp_merge_Obj_TYPE = Dyp.Tools.keep_zero
let dyp_merge_Obj_application = Dyp.Tools.keep_zero
let dyp_merge_Obj_arrow = Dyp.Tools.keep_zero
let dyp_merge_Obj_atomic_term = Dyp.Tools.keep_zero
let dyp_merge_Obj_atomic_type = Dyp.Tools.keep_zero
let dyp_merge_Obj_comma_ids = Dyp.Tools.keep_zero
let dyp_merge_Obj_comma_ids_or_sym = Dyp.Tools.keep_zero
let dyp_merge_Obj_composition_argument = Dyp.Tools.keep_zero
let dyp_merge_Obj_data = Dyp.Tools.keep_zero
let dyp_merge_Obj_dypgen__early_action_0 = Dyp.Tools.keep_zero
let dyp_merge_Obj_dypgen__early_action_1 = Dyp.Tools.keep_zero
let dyp_merge_Obj_dypgen__early_action_2 = Dyp.Tools.keep_zero
let dyp_merge_Obj_dypgen__early_action_3 = Dyp.Tools.keep_zero
let dyp_merge_Obj_dypgen__early_action_4 = Dyp.Tools.keep_zero
let dyp_merge_Obj_dypgen__early_action_5 = Dyp.Tools.keep_zero
let dyp_merge_Obj_dypgen__early_action_6 = Dyp.Tools.keep_zero
let dyp_merge_Obj_dypgen__early_action_7 = Dyp.Tools.keep_zero
let dyp_merge_Obj_dypgen__early_action_8 = Dyp.Tools.keep_zero
let dyp_merge_Obj_dypgen__epsilon = Dyp.Tools.keep_zero
let dyp_merge_Obj_heterogenous_term_and_type = Dyp.Tools.keep_zero
let dyp_merge_Obj_idents = Dyp.Tools.keep_zero
let dyp_merge_Obj_lex_entries = Dyp.Tools.keep_zero
let dyp_merge_Obj_lex_entry = Dyp.Tools.keep_zero
let dyp_merge_Obj_lex_opening = Dyp.Tools.keep_zero
let dyp_merge_Obj_lexicon = Dyp.Tools.keep_zero
let dyp_merge_Obj_lexicon_composition = Dyp.Tools.keep_zero
let dyp_merge_Obj_sig_entries = Dyp.Tools.keep_zero
let dyp_merge_Obj_sig_entry = Dyp.Tools.keep_zero
let dyp_merge_Obj_sig_ident = Dyp.Tools.keep_zero
let dyp_merge_Obj_signature = Dyp.Tools.keep_zero
let dyp_merge_Obj_term = Dyp.Tools.keep_zero
let dyp_merge_Obj_term_alone = Dyp.Tools.keep_zero
let dyp_merge_Obj_term_dec_start = Dyp.Tools.keep_zero
let dyp_merge_Obj_term_declaration = Dyp.Tools.keep_zero
let dyp_merge_Obj_term_def_start = Dyp.Tools.keep_zero
let dyp_merge_Obj_term_definition = Dyp.Tools.keep_zero
let dyp_merge_Obj_type_declaration = Dyp.Tools.keep_zero
let dyp_merge_Obj_type_definition = Dyp.Tools.keep_zero
let dyp_merge_Obj_type_expression = Dyp.Tools.keep_zero
let dyp_merge = Dyp.keep_one
let dypgen_match_length = `shortest
let dypgen_choose_token = `first
let dypgen_keep_data = `both
let dypgen_use_rule_order = false
let dypgen_use_all_actions = false

# 44 "data_parser.dyp"

(*  open Dyp*)
  open Entry

  exception No_sig

  let cpt = ref 0

  let incr () = cpt := (!cpt)+1

  let cpt_to_string () = Printf.sprintf "%d" !cpt

  type type_or_cst =
    | Nothing
    | Type
    | Cst
    | Both

  let type_or_cst_to_string = function
    | Nothing -> "Nothing"
    | Type -> "Type"
    | Cst -> "Cst"
    | Both -> "Both"

  exception Is_type
  exception Is_cst

  let emit_parse_error e loc = raise (Error.Error (Error.Parse_error (e,loc)))

  let local_data = None

  let global_data = false

(*  type abstraction =
    | Linear
    | Non_linear  *)

      
  let new_loc (s,_) (_,e) = (s,e)

  let get_term_location = function
    | Abstract_syntax.Var (_,l) -> l
    | Abstract_syntax.Const (_,l) -> l
    | Abstract_syntax.Abs (_,_,_,l) -> l
    | Abstract_syntax.LAbs (_,_,_,l) -> l
    | Abstract_syntax.App (_,_,l) -> l


  let abs x l1 t = function
    | Abstract_syntax.Linear -> Abstract_syntax.LAbs (x,l1,t,new_loc l1 (get_term_location t))
    | Abstract_syntax.Non_linear -> Abstract_syntax.Abs (x,l1,t,new_loc l1 (get_term_location t))

  let rec multiple_abs e ws k_a ids t k =
    match ids with
      | [] -> k (t e ws)
      | [a,l_a] ->
	  let new_t,new_ws = t (Env.add a e) ws in
	    k (abs a l_a new_t k_a,new_ws)
      | (a,l_a)::((_,l_b)::_ as tl) -> 
	  let new_env = Env.add a e in
	    multiple_abs new_env ws k_a tl t (fun r -> k (abs a l_a (fst r) k_a,(snd r)))

  let reset_location l = function
    | Abstract_syntax.LAbs(x,l1,t,l2),ws -> Abstract_syntax.LAbs(x,l1,t,new_loc l l2),ws
    | Abstract_syntax.Abs(x,l1,t,l2),ws -> Abstract_syntax.Abs(x,l1,t,new_loc l l2),ws
    | _ -> failwith "Bug"

  let bind c x l t lin = Abstract_syntax.App (c,abs x l t lin,new_loc l (get_term_location t))

  let rec multiple_bind e ws binder lin ids t k =
    match ids with
      | [] -> k (t e ws)
      | [a,l_a] ->
	  let new_t,new_ws = t (Env.add a e) ws in
	    k (bind binder a l_a new_t lin,new_ws)
      | (a,l_a)::((_,l_b)::_ as tl) ->
	  let new_env = Env.add a e in
	    multiple_bind new_env ws binder lin tl t (fun r -> k (bind binder a l_a (fst r) lin,(snd r)))

  let reset_binder_location l1 = function
    | Abstract_syntax.App(u,v,l2),ws -> Abstract_syntax.App(u,v,new_loc l1 l2),ws
    | _ -> failwith "Bug"


  let get_sig_value = function
    | None -> raise No_sig
    | Some (Signature s) -> s
    | Some (Abs_and_obj (_,o)) -> o
    | Some (Env _) -> failwith "Bug: looking for a signature while env is the current local data"

  let get_abs_and_obj_sig_value = function
    | None -> raise No_sig
    | Some (Signature _) -> failwith "Bug: looking for an abs_obj while signature is the current local data"
    | Some (Abs_and_obj (a,o)) -> a,o
    | Some (Env _) -> failwith "Bug: looking for an abs_obj while env is the current local data"


  let get_env_value = function
    | None -> E.empty
    | Some (Env e) -> e
    | Some (Abs_and_obj _) -> failwith "Bug: looking for an env while abs_obj is the current local data"
    | Some (Signature _) -> failwith "Bug: looking for an env while signature is the current local data"


  let raise_expect v (p1,p2) =
    let s = Entry.valuation_to_string v in
      raise (Error.Error (Error.Lexer_error (Error.Expect s,(p1,p2))))

	

let _ = () (* dummy line to improve OCaml error location *)
# 639                "data_parser_temp.ml"
let __dypgen_ra_list, __dypgen_main_lexer, __dypgen_aux_lexer =
[
(("data",[Dyp.Ter "EOI"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [ _1] -> Obj_data 
# 206 "data_parser.dyp"
(
      (get_env_value dyp.last_local_data):'dypgen__Obj_data)
# 648                "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("data",[Dyp.Non_ter ("0_1",Dyp.No_priority );Dyp.Non_ter ("signature",Dyp.No_priority );Dyp.Non_ter ("dypgen__early_action_8",Dyp.No_priority );Dyp.Non_ter ("data",Dyp.No_priority )],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_signature ( (
# 208 "data_parser.dyp"
           (s:'dypgen__Obj_signature)
# 657                "data_parser_temp.ml"
 as _1));Obj_dypgen__early_action_8 ( (
(_:'dypgen__Obj_dypgen__early_action_8)
# 660                "data_parser_temp.ml"
 as _2));Obj_data ( (
# 208 "data_parser.dyp"
                                                                                                                                              (d:'dypgen__Obj_data)
# 664                "data_parser_temp.ml"
 as _3))] -> Obj_data 
# 207 "data_parser.dyp"
(
                                                                                                                                                  (d):'dypgen__Obj_data)
# 669                "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[3,
(fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_inh_val (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_signature ( (
# 208 "data_parser.dyp"
           (s:'dypgen__Obj_signature)
# 676                "data_parser_temp.ml"
 as _1))] -> Inh_dypgen__early_action_8 
(
((_1)):'dypgen__Inh_dypgen__early_action_8)
# 680                "data_parser_temp.ml"
 | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl)])
;
(("dypgen__early_action_8",[],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Inh_dypgen__early_action_8( (
# 208 "data_parser.dyp"
           (s:'dypgen__Obj_signature)
# 688                "data_parser_temp.ml"
 as _1))] ->  let res = 
# 207 "data_parser.dyp"
(
                  (s,[Local_data (Some (Env (E.insert ~override:dyp.global_data (E.Signature s) (get_env_value dyp.last_local_data))))]):'dypgen__Obj_dypgen__early_action_8 * ('t,'obj,'gd,'ld,'l) Dyp.dyp_action list)
# 693                "data_parser_temp.ml"
  in Obj_dypgen__early_action_8(fst res), snd res
 | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("data",[Dyp.Non_ter ("0_1",Dyp.No_priority );Dyp.Non_ter ("lexicon",Dyp.No_priority );Dyp.Non_ter ("dypgen__early_action_7",Dyp.No_priority );Dyp.Non_ter ("data",Dyp.No_priority )],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_lexicon ( (
# 209 "data_parser.dyp"
         (l:'dypgen__Obj_lexicon)
# 703                "data_parser_temp.ml"
 as _1));Obj_dypgen__early_action_7 ( (
(_:'dypgen__Obj_dypgen__early_action_7)
# 706                "data_parser_temp.ml"
 as _2));Obj_data ( (
# 209 "data_parser.dyp"
                                                                                                                                                                        (d:'dypgen__Obj_data)
# 710                "data_parser_temp.ml"
 as _3))] -> Obj_data 
# 208 "data_parser.dyp"
(
                                                                                                                                                                            (d):'dypgen__Obj_data)
# 715                "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[3,
(fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_inh_val (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_lexicon ( (
# 209 "data_parser.dyp"
         (l:'dypgen__Obj_lexicon)
# 722                "data_parser_temp.ml"
 as _1))] -> Inh_dypgen__early_action_7 
(
((_1)):'dypgen__Inh_dypgen__early_action_7)
# 726                "data_parser_temp.ml"
 | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl)])
;
(("dypgen__early_action_7",[],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Inh_dypgen__early_action_7( (
# 209 "data_parser.dyp"
         (l:'dypgen__Obj_lexicon)
# 734                "data_parser_temp.ml"
 as _1))] ->  let res = 
# 208 "data_parser.dyp"
(
                (let () = E.Lexicon.check l in l,[Local_data (Some (Env (E.insert ~override:dyp.global_data (E.Lexicon l) (get_env_value dyp.last_local_data))))]):'dypgen__Obj_dypgen__early_action_7 * ('t,'obj,'gd,'ld,'l) Dyp.dyp_action list)
# 739                "data_parser_temp.ml"
  in Obj_dypgen__early_action_7(fst res), snd res
 | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("signature",[Dyp.Ter "SIG_OPEN";Dyp.Non_ter ("sig_ident",Dyp.No_priority );Dyp.Ter "EQUAL";Dyp.Non_ter ("sig_entries",Dyp.No_priority )],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_SIG_OPEN  (
(_:(Abstract_syntax.location))
# 748                "data_parser_temp.ml"
 as _1);Obj_sig_ident ( (
(_:'dypgen__Obj_sig_ident)
# 751                "data_parser_temp.ml"
 as _2));Obj_EQUAL  (
(_:(Abstract_syntax.location))
# 754                "data_parser_temp.ml"
 as _3);Obj_sig_entries ( (
(_:'dypgen__Obj_sig_entries)
# 757                "data_parser_temp.ml"
 as _4))] -> Obj_signature 
# 211 "data_parser.dyp"
(
                                       (_4):'dypgen__Obj_signature)
# 762                "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("signature",[Dyp.Ter "SIG_OPEN";Dyp.Non_ter ("sig_ident",Dyp.No_priority );Dyp.Ter "EQUAL";Dyp.Non_ter ("sig_entries",Dyp.No_priority )],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_SIG_OPEN  (
(_:(Abstract_syntax.location))
# 770                "data_parser_temp.ml"
 as _1);Obj_sig_ident ( (
(_:'dypgen__Obj_sig_ident)
# 773                "data_parser_temp.ml"
 as _2));Obj_EQUAL  (
(_:(Abstract_syntax.location))
# 776                "data_parser_temp.ml"
 as _3);Obj_sig_entries ( (
(_:'dypgen__Obj_sig_entries)
# 779                "data_parser_temp.ml"
 as _4))] -> Obj_signature 
# 212 "data_parser.dyp"
(
                                       (_4):'dypgen__Obj_signature)
# 784                "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("sig_ident",[Dyp.Ter "IDENT"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_IDENT  (
# 216 "data_parser.dyp"
       (n:((string*Abstract_syntax.location)))
# 793                "data_parser_temp.ml"
 as _1)] ->  let res = 
# 215 "data_parser.dyp"
(
           (n,[Local_data (Some (Signature (E.Signature1.empty n)))]):'dypgen__Obj_sig_ident * ('t,'obj,'gd,'ld,'l) Dyp.dyp_action list)
# 798                "data_parser_temp.ml"
  in Obj_sig_ident(fst res), snd res
 | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("lexicon",[Dyp.Ter "LEX_OPEN";Dyp.Non_ter ("lex_opening",Dyp.No_priority );Dyp.Ter "EQUAL";Dyp.Non_ter ("lex_entries",Dyp.No_priority )],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_LEX_OPEN  (
(_:(Abstract_syntax.location))
# 807                "data_parser_temp.ml"
 as _1);Obj_lex_opening ( (
# 219 "data_parser.dyp"
                      (l:'dypgen__Obj_lex_opening)
# 811                "data_parser_temp.ml"
 as _2));Obj_EQUAL  (
(_:(Abstract_syntax.location))
# 814                "data_parser_temp.ml"
 as _3);Obj_lex_entries ( (
# 219 "data_parser.dyp"
                                           (e:'dypgen__Obj_lex_entries)
# 818                "data_parser_temp.ml"
 as _4))] -> Obj_lexicon 
# 218 "data_parser.dyp"
(
                                               (e l):'dypgen__Obj_lexicon)
# 823                "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("lexicon",[Dyp.Ter "LEX_OPEN";Dyp.Non_ter ("lex_opening",Dyp.No_priority );Dyp.Ter "EQUAL";Dyp.Non_ter ("lex_entries",Dyp.No_priority )],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_LEX_OPEN  (
(_:(Abstract_syntax.location))
# 831                "data_parser_temp.ml"
 as _1);Obj_lex_opening ( (
# 220 "data_parser.dyp"
                      (l:'dypgen__Obj_lex_opening)
# 835                "data_parser_temp.ml"
 as _2));Obj_EQUAL  (
(_:(Abstract_syntax.location))
# 838                "data_parser_temp.ml"
 as _3);Obj_lex_entries ( (
# 220 "data_parser.dyp"
                                           (e:'dypgen__Obj_lex_entries)
# 842                "data_parser_temp.ml"
 as _4))] -> Obj_lexicon 
# 219 "data_parser.dyp"
(
                                               (e l):'dypgen__Obj_lexicon)
# 847                "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("lexicon",[Dyp.Ter "LEX_OPEN";Dyp.Ter "IDENT";Dyp.Ter "EQUAL";Dyp.Non_ter ("lexicon_composition",Dyp.No_priority )],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_LEX_OPEN  (
(_:(Abstract_syntax.location))
# 855                "data_parser_temp.ml"
 as _1);Obj_IDENT  (
# 221 "data_parser.dyp"
                (name:((string*Abstract_syntax.location)))
# 859                "data_parser_temp.ml"
 as _2);Obj_EQUAL  (
(_:(Abstract_syntax.location))
# 862                "data_parser_temp.ml"
 as _3);Obj_lexicon_composition ( (
# 221 "data_parser.dyp"
                                                (c:'dypgen__Obj_lexicon_composition)
# 866                "data_parser_temp.ml"
 as _4))] -> Obj_lexicon 
# 220 "data_parser.dyp"
(
                                                    (c name):'dypgen__Obj_lexicon)
# 871                "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("lexicon_composition",[Dyp.Ter "IDENT";Dyp.Ter "COMPOSE";Dyp.Non_ter ("composition_argument",Dyp.No_priority )],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_IDENT  (
# 224 "data_parser.dyp"
       (name1,loc:((string*Abstract_syntax.location)))
# 880                "data_parser_temp.ml"
 as _1);Obj_COMPOSE  (
(_:(Abstract_syntax.location))
# 883                "data_parser_temp.ml"
 as _2);Obj_composition_argument ( (
# 224 "data_parser.dyp"
                                               (l:'dypgen__Obj_composition_argument)
# 887                "data_parser_temp.ml"
 as _3))] -> Obj_lexicon_composition 
# 223 "data_parser.dyp"
(
                                                   (
  fun name ->
    try
      let env=get_env_value dyp.last_local_data in
      let l1 = E.get_lexicon name1 env in
      E.Lexicon.compose l1 (l ("__NO__NAME__",(Lexing.dummy_pos,Lexing.dummy_pos))) ( name)
    with
    | E.Lexicon_not_found _ -> 
      emit_parse_error (Error.No_such_signature name1) loc):'dypgen__Obj_lexicon_composition)
# 900                "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("lexicon_composition",[Dyp.Ter "LPAREN";Dyp.Non_ter ("lexicon_composition",Dyp.No_priority );Dyp.Ter "RPAREN"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_LPAREN  (
(_:(Abstract_syntax.location))
# 908                "data_parser_temp.ml"
 as _1);Obj_lexicon_composition ( (
# 233 "data_parser.dyp"
                            (c:'dypgen__Obj_lexicon_composition)
# 912                "data_parser_temp.ml"
 as _2));Obj_RPAREN  (
(_:(Abstract_syntax.location))
# 915                "data_parser_temp.ml"
 as _3)] -> Obj_lexicon_composition 
# 232 "data_parser.dyp"
(
                                       (c):'dypgen__Obj_lexicon_composition)
# 920                "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("composition_argument",[Dyp.Ter "IDENT"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_IDENT  (
# 236 "data_parser.dyp"
       (name,loc:((string*Abstract_syntax.location)))
# 929                "data_parser_temp.ml"
 as _1)] -> Obj_composition_argument 
# 235 "data_parser.dyp"
(
                  (fun res_name-> 
  try
    E.get_lexicon name (get_env_value dyp.last_local_data)
  with
  | E.Lexicon_not_found _ -> 
    emit_parse_error (Error.No_such_signature name) loc):'dypgen__Obj_composition_argument)
# 939                "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("composition_argument",[Dyp.Non_ter ("lexicon_composition",Dyp.No_priority )],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_lexicon_composition ( (
# 242 "data_parser.dyp"
                     (c:'dypgen__Obj_lexicon_composition)
# 948                "data_parser_temp.ml"
 as _1))] -> Obj_composition_argument 
# 241 "data_parser.dyp"
(
                         (c):'dypgen__Obj_composition_argument)
# 953                "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("lex_opening",[Dyp.Ter "IDENT";Dyp.Ter "LPAREN";Dyp.Ter "IDENT";Dyp.Ter "RPAREN";Dyp.Ter "COLON";Dyp.Ter "IDENT"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_IDENT  (
# 246 "data_parser.dyp"
       (name:((string*Abstract_syntax.location)))
# 962                "data_parser_temp.ml"
 as _1);Obj_LPAREN  (
(_:(Abstract_syntax.location))
# 965                "data_parser_temp.ml"
 as _2);Obj_IDENT  (
# 246 "data_parser.dyp"
                          (abs_name,abs_loc:((string*Abstract_syntax.location)))
# 969                "data_parser_temp.ml"
 as _3);Obj_RPAREN  (
(_:(Abstract_syntax.location))
# 972                "data_parser_temp.ml"
 as _4);Obj_COLON  (
(_:(Abstract_syntax.location))
# 975                "data_parser_temp.ml"
 as _5);Obj_IDENT  (
# 246 "data_parser.dyp"
                                                               (obj_name,obj_loc:((string*Abstract_syntax.location)))
# 979                "data_parser_temp.ml"
 as _6)] ->  let res = 
# 245 "data_parser.dyp"
(
                                                                                  (
    let env = get_env_value dyp.last_local_data in
    let abs = 
      try
	E.get_signature abs_name env
      with
	| E.Signature_not_found _ -> emit_parse_error (Error.No_such_signature abs_name) abs_loc in
    let obj = 
      try
	E.get_signature obj_name env
      with
	| E.Signature_not_found _ -> emit_parse_error (Error.No_such_signature obj_name) obj_loc in
    let lex = E.Lexicon.empty name ~abs:abs ~obj:obj in
      lex,[Local_data (Some (Abs_and_obj (abs,obj)))]):'dypgen__Obj_lex_opening * ('t,'obj,'gd,'ld,'l) Dyp.dyp_action list)
# 997                "data_parser_temp.ml"
  in Obj_lex_opening(fst res), snd res
 | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("sig_entries",[Dyp.Ter "END_OF_DEC"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_END_OF_DEC  (
(_:(Abstract_syntax.location))
# 1006               "data_parser_temp.ml"
 as _1)] -> Obj_sig_entries 
# 261 "data_parser.dyp"
(
             (get_sig_value dyp.local_data):'dypgen__Obj_sig_entries)
# 1011               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("sig_entries",[Dyp.Non_ter ("sig_entry",Dyp.No_priority );Dyp.Ter "END_OF_DEC"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_sig_entry ( (
(_:'dypgen__Obj_sig_entry)
# 1019               "data_parser_temp.ml"
 as _1));Obj_END_OF_DEC  (
(_:(Abstract_syntax.location))
# 1022               "data_parser_temp.ml"
 as _2)] -> Obj_sig_entries 
# 262 "data_parser.dyp"
(
                       (_1 (get_sig_value dyp.local_data)):'dypgen__Obj_sig_entries)
# 1027               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("sig_entries",[Dyp.Non_ter ("0_1",Dyp.No_priority );Dyp.Non_ter ("sig_entry",Dyp.No_priority );Dyp.Ter "SEMICOLON";Dyp.Non_ter ("dypgen__early_action_6",Dyp.No_priority );Dyp.Non_ter ("sig_entries",Dyp.No_priority )],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_sig_entry ( (
(_:'dypgen__Obj_sig_entry)
# 1035               "data_parser_temp.ml"
 as _1));Obj_SEMICOLON  (
(_:(Abstract_syntax.location))
# 1038               "data_parser_temp.ml"
 as _2);Obj_dypgen__early_action_6 ( (
(_:'dypgen__Obj_dypgen__early_action_6)
# 1041               "data_parser_temp.ml"
 as _3));Obj_sig_entries ( (
(_:'dypgen__Obj_sig_entries)
# 1044               "data_parser_temp.ml"
 as _4))] ->  let res = 
# 266 "data_parser.dyp"
(
                  (_4,[Local_data (Some (Signature _4))]):'dypgen__Obj_sig_entries * ('t,'obj,'gd,'ld,'l) Dyp.dyp_action list)
# 1049               "data_parser_temp.ml"
  in Obj_sig_entries(fst res), snd res
 | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[4,
(fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_inh_val (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_sig_entry ( (
(_:'dypgen__Obj_sig_entry)
# 1056               "data_parser_temp.ml"
 as _1));Obj_SEMICOLON  (
(_:(Abstract_syntax.location))
# 1059               "data_parser_temp.ml"
 as _2)] -> Inh_dypgen__early_action_6 
(
((_1, _2)):'dypgen__Inh_dypgen__early_action_6)
# 1063               "data_parser_temp.ml"
 | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl)])
;
(("dypgen__early_action_6",[],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Inh_dypgen__early_action_6( (
(_:'dypgen__Obj_sig_entry)
# 1070               "data_parser_temp.ml"
 as _1),
 (
(_:'dypgen__Obj_SEMICOLON)
# 1074               "data_parser_temp.ml"
 as _2))] ->  let res = 
# 264 "data_parser.dyp"
(
                   (let new_sg = _1 (get_sig_value dyp.local_data) in
		       (new_sg,[Local_data (Some (Signature new_sg))])):'dypgen__Obj_dypgen__early_action_6 * ('t,'obj,'gd,'ld,'l) Dyp.dyp_action list)
# 1080               "data_parser_temp.ml"
  in Obj_dypgen__early_action_6(fst res), snd res
 | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("sig_entry",[Dyp.Non_ter ("type_declaration",Dyp.No_priority )],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_type_declaration ( (
(_:'dypgen__Obj_type_declaration)
# 1089               "data_parser_temp.ml"
 as _1))] -> Obj_sig_entry 
# 269 "data_parser.dyp"
(
                   (_1):'dypgen__Obj_sig_entry)
# 1094               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("sig_entry",[Dyp.Non_ter ("type_definition",Dyp.No_priority )],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_type_definition ( (
(_:'dypgen__Obj_type_definition)
# 1102               "data_parser_temp.ml"
 as _1))] -> Obj_sig_entry 
# 270 "data_parser.dyp"
(
                  (_1):'dypgen__Obj_sig_entry)
# 1107               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("sig_entry",[Dyp.Non_ter ("term_declaration",Dyp.No_priority )],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_term_declaration ( (
(_:'dypgen__Obj_term_declaration)
# 1115               "data_parser_temp.ml"
 as _1))] -> Obj_sig_entry 
# 271 "data_parser.dyp"
(
                   (_1):'dypgen__Obj_sig_entry)
# 1120               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("sig_entry",[Dyp.Non_ter ("term_definition",Dyp.No_priority )],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_term_definition ( (
(_:'dypgen__Obj_term_definition)
# 1128               "data_parser_temp.ml"
 as _1))] -> Obj_sig_entry 
# 272 "data_parser.dyp"
(
                  (_1):'dypgen__Obj_sig_entry)
# 1133               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("type_declaration",[Dyp.Non_ter ("comma_ids",Dyp.No_priority );Dyp.Ter "COLON";Dyp.Ter "TYPE"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_comma_ids ( (
(_:'dypgen__Obj_comma_ids)
# 1141               "data_parser_temp.ml"
 as _1));Obj_COLON  (
(_:(Abstract_syntax.location))
# 1144               "data_parser_temp.ml"
 as _2);Obj_TYPE  (
(_:(Abstract_syntax.location))
# 1147               "data_parser_temp.ml"
 as _3)] -> Obj_type_declaration 
# 279 "data_parser.dyp"
(
                       (
    fun s ->
      let new_sig =
	List.fold_left
	  (fun acc id ->
	     try
	       E.Signature1.add_entry (Abstract_syntax.Type_decl (fst id,snd id,(Abstract_syntax.K []))) acc
	     with
	       | E.Signature1.Duplicate_type_definition -> 
		   let pos1,pos2= snd id in
		     emit_parse_error (Error.Duplicated_type (fst id)) (pos1,pos2))
	  s
	  _1 in
	new_sig):'dypgen__Obj_type_declaration)
# 1165               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("comma_ids",[Dyp.Ter "IDENT"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_IDENT  (
# 296 "data_parser.dyp"
       (id:((string*Abstract_syntax.location)))
# 1174               "data_parser_temp.ml"
 as _1)] -> Obj_comma_ids 
# 295 "data_parser.dyp"
(
            ([id]):'dypgen__Obj_comma_ids)
# 1179               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("comma_ids",[Dyp.Ter "IDENT";Dyp.Ter "COMMA";Dyp.Non_ter ("comma_ids",Dyp.No_priority )],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_IDENT  (
# 297 "data_parser.dyp"
       (id:((string*Abstract_syntax.location)))
# 1188               "data_parser_temp.ml"
 as _1);Obj_COMMA  (
(_:(Abstract_syntax.location))
# 1191               "data_parser_temp.ml"
 as _2);Obj_comma_ids ( (
# 297 "data_parser.dyp"
                           (id_list:'dypgen__Obj_comma_ids)
# 1195               "data_parser_temp.ml"
 as _3))] -> Obj_comma_ids 
# 296 "data_parser.dyp"
(
                                     (id::id_list):'dypgen__Obj_comma_ids)
# 1200               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("type_definition",[Dyp.Ter "IDENT";Dyp.Ter "EQUAL";Dyp.Non_ter ("type_expression",Dyp.No_priority );Dyp.Ter "COLON";Dyp.Ter "TYPE"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_IDENT  (
(_:((string*Abstract_syntax.location)))
# 1208               "data_parser_temp.ml"
 as _1);Obj_EQUAL  (
(_:(Abstract_syntax.location))
# 1211               "data_parser_temp.ml"
 as _2);Obj_type_expression ( (
(_:'dypgen__Obj_type_expression)
# 1214               "data_parser_temp.ml"
 as _3));Obj_COLON  (
(_:(Abstract_syntax.location))
# 1217               "data_parser_temp.ml"
 as _4);Obj_TYPE  (
(_:(Abstract_syntax.location))
# 1220               "data_parser_temp.ml"
 as _5)] -> Obj_type_definition 
# 299 "data_parser.dyp"
(
                                         (
    fun s ->
      let new_sig =
	try
	  E.Signature1.add_entry (Abstract_syntax.Type_def (fst _1,snd _1,fst (_3 s),Abstract_syntax.K [])) s
	with
	  | E.Signature1.Duplicate_type_definition -> 
	      let pos1,pos2= snd _1 in
		emit_parse_error (Error.Duplicated_type (fst _1)) (pos1,pos2) in 
	new_sig):'dypgen__Obj_type_definition)
# 1234               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("type_definition",[Dyp.Ter "IDENT";Dyp.Ter "EQUAL";Dyp.Non_ter ("type_expression",Dyp.No_priority );Dyp.Ter "COLON";Dyp.Non_ter ("type_expression",Dyp.No_priority )],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_IDENT  (
(_:((string*Abstract_syntax.location)))
# 1242               "data_parser_temp.ml"
 as _1);Obj_EQUAL  (
(_:(Abstract_syntax.location))
# 1245               "data_parser_temp.ml"
 as _2);Obj_type_expression ( (
(_:'dypgen__Obj_type_expression)
# 1248               "data_parser_temp.ml"
 as _3));Obj_COLON  (
(_:(Abstract_syntax.location))
# 1251               "data_parser_temp.ml"
 as _4);Obj_type_expression ( (
(_:'dypgen__Obj_type_expression)
# 1254               "data_parser_temp.ml"
 as _5))] -> Obj_type_definition 
# 309 "data_parser.dyp"
(
                                                    (let s = get_sig_value dyp.last_local_data in
						       try
							 let _ = _3 s in
							   raise_expect Entry.Type_kwd (snd (_5 s))
						       with
							 | Error.Error (Error.Parse_error ((Error.Unknown_type _),_)) -> raise Dyp.Giveup):'dypgen__Obj_type_definition)
# 1264               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("type_definition",[Dyp.Ter "IDENT";Dyp.Ter "EQUAL";Dyp.Non_ter ("type_expression",Dyp.No_priority );Dyp.Ter "COLON";Dyp.Non_ter ("term",Dyp.No_priority )],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_IDENT  (
(_:((string*Abstract_syntax.location)))
# 1272               "data_parser_temp.ml"
 as _1);Obj_EQUAL  (
(_:(Abstract_syntax.location))
# 1275               "data_parser_temp.ml"
 as _2);Obj_type_expression ( (
(_:'dypgen__Obj_type_expression)
# 1278               "data_parser_temp.ml"
 as _3));Obj_COLON  (
(_:(Abstract_syntax.location))
# 1281               "data_parser_temp.ml"
 as _4);Obj_term ( (
(_:'dypgen__Obj_term)
# 1284               "data_parser_temp.ml"
 as _5))] -> Obj_type_definition 
# 315 "data_parser.dyp"
(
                                         (let s = get_sig_value dyp.last_local_data in
					    try
					      let _ = _3 s in
					      let l = get_term_location (fst (_5 Env.empty [])) in
						raise_expect Entry.Type_kwd l
					    with
					      | Error.Error (Error.Parse_error ((Error.Unknown_type _),_)) -> raise Dyp.Giveup
					      | Error.Error (Error.Parse_error ((Error.Unknown_constant _),(p1,p2))) -> raise_expect Entry.Type_kwd (p1,p2)):'dypgen__Obj_type_definition)
# 1296               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("type_expression",[Dyp.Non_ter ("atomic_type",Dyp.No_priority )],"atom_type",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_atomic_type ( (
(_:'dypgen__Obj_atomic_type)
# 1304               "data_parser_temp.ml"
 as _1))] -> Obj_type_expression 
# 325 "data_parser.dyp"
(
              (_1):'dypgen__Obj_type_expression)
# 1309               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("type_expression",[Dyp.Non_ter ("atomic_type",Dyp.Lesseq_priority "atom_type");Dyp.Non_ter ("arrow",Dyp.No_priority );Dyp.Non_ter ("type_expression",Dyp.Lesseq_priority "arrow_type")],"arrow_type",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_atomic_type ( (
(_:'dypgen__Obj_atomic_type)
# 1317               "data_parser_temp.ml"
 as _1));Obj_arrow ( (
# 327 "data_parser.dyp"
                                  (a:'dypgen__Obj_arrow)
# 1321               "data_parser_temp.ml"
 as _2));Obj_type_expression ( (
(_:'dypgen__Obj_type_expression)
# 1324               "data_parser_temp.ml"
 as _3))] -> Obj_type_expression 
# 326 "data_parser.dyp"
(
                                                                      (fun sg ->
									  let ty1,loc1 = _1 sg in
									  let ty2,loc2 = _3 sg in
									  let new_loc = new_loc loc1 loc2 in (a (ty1,ty2,new_loc)),new_loc):'dypgen__Obj_type_expression)
# 1332               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("arrow",[Dyp.Ter "LIN_ARROW"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_LIN_ARROW  (
(_:(Abstract_syntax.location))
# 1340               "data_parser_temp.ml"
 as _1)] -> Obj_arrow 
# 332 "data_parser.dyp"
(
            (fun (ty1,ty2,l) ->Abstract_syntax.Linear_arrow (ty1,ty2,l)):'dypgen__Obj_arrow)
# 1345               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("arrow",[Dyp.Ter "ARROW"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_ARROW  (
(_:(Abstract_syntax.location))
# 1353               "data_parser_temp.ml"
 as _1)] -> Obj_arrow 
# 333 "data_parser.dyp"
(
        (fun (ty1,ty2,l) ->Abstract_syntax.Arrow (ty1,ty2,l)):'dypgen__Obj_arrow)
# 1358               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("atomic_type",[Dyp.Ter "IDENT"],"atom_type",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_IDENT  (
(_:((string*Abstract_syntax.location)))
# 1366               "data_parser_temp.ml"
 as _1)] -> Obj_atomic_type 
# 336 "data_parser.dyp"
(
        (fun sg ->
	   let id,((pos1,pos2) as l) = _1 in
	     match E.Signature1.is_type id sg with
	       | true -> Abstract_syntax.Type_atom (id,l,[]),l
	       | false -> emit_parse_error (Error.Unknown_type id) (pos1,pos2)):'dypgen__Obj_atomic_type)
# 1375               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("atomic_type",[Dyp.Ter "LPAREN";Dyp.Non_ter ("type_expression",Dyp.No_priority );Dyp.Ter "RPAREN"],"atom_type",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_LPAREN  (
(_:(Abstract_syntax.location))
# 1383               "data_parser_temp.ml"
 as _1);Obj_type_expression ( (
(_:'dypgen__Obj_type_expression)
# 1386               "data_parser_temp.ml"
 as _2));Obj_RPAREN  (
(_:(Abstract_syntax.location))
# 1389               "data_parser_temp.ml"
 as _3)] -> Obj_atomic_type 
# 341 "data_parser.dyp"
(
                                (fun sg -> fst (_2 sg),new_loc _1 _3):'dypgen__Obj_atomic_type)
# 1394               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("term_declaration",[Dyp.Non_ter ("term_dec_start",Dyp.No_priority );Dyp.Ter "COLON";Dyp.Non_ter ("type_expression",Dyp.No_priority )],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_term_dec_start ( (
(_:'dypgen__Obj_term_dec_start)
# 1402               "data_parser_temp.ml"
 as _1));Obj_COLON  (
(_:(Abstract_syntax.location))
# 1405               "data_parser_temp.ml"
 as _2);Obj_type_expression ( (
(_:'dypgen__Obj_type_expression)
# 1408               "data_parser_temp.ml"
 as _3))] -> Obj_term_declaration 
# 344 "data_parser.dyp"
(
                                        (
    fun s ->
      let new_sig =
	List.fold_left
	  (fun acc (id,kind,loc) -> 
	     try
	       let ty = fst (_3 s) in
	       E.Signature1.add_entry (Abstract_syntax.Term_decl (id,kind,loc,ty)) acc
	     with
	       | E.Signature1.Duplicate_term_definition -> 
		   let pos1,pos2= loc in
		     emit_parse_error (Error.Duplicated_term id) (pos1,pos2))
	  s
	  _1 in
	new_sig):'dypgen__Obj_term_declaration)
# 1427               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("term_dec_start",[Dyp.Non_ter ("comma_ids",Dyp.No_priority )],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_comma_ids ( (
(_:'dypgen__Obj_comma_ids)
# 1435               "data_parser_temp.ml"
 as _1))] -> Obj_term_dec_start 
# 361 "data_parser.dyp"
(
            (List.map (fun (id,loc) -> (id,Abstract_syntax.Default,loc)) _1):'dypgen__Obj_term_dec_start)
# 1440               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("term_dec_start",[Dyp.Ter "PREFIX";Dyp.Ter "SYMBOL"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_PREFIX  (
(_:(Abstract_syntax.location))
# 1448               "data_parser_temp.ml"
 as _1);Obj_SYMBOL  (
# 363 "data_parser.dyp"
               (sym,l:((string*Abstract_syntax.location)))
# 1452               "data_parser_temp.ml"
 as _2)] -> Obj_term_dec_start 
# 362 "data_parser.dyp"
(
                       ([sym,Abstract_syntax.Prefix,l]):'dypgen__Obj_term_dec_start)
# 1457               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("term_dec_start",[Dyp.Ter "INFIX";Dyp.Ter "SYMBOL"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_INFIX  (
(_:(Abstract_syntax.location))
# 1465               "data_parser_temp.ml"
 as _1);Obj_SYMBOL  (
# 364 "data_parser.dyp"
              (sym,l:((string*Abstract_syntax.location)))
# 1469               "data_parser_temp.ml"
 as _2)] -> Obj_term_dec_start 
# 363 "data_parser.dyp"
(
                      ([sym,Abstract_syntax.Infix,l]):'dypgen__Obj_term_dec_start)
# 1474               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("term_dec_start",[Dyp.Ter "BINDER";Dyp.Ter "IDENT"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_BINDER  (
(_:(Abstract_syntax.location))
# 1482               "data_parser_temp.ml"
 as _1);Obj_IDENT  (
(_:((string*Abstract_syntax.location)))
# 1485               "data_parser_temp.ml"
 as _2)] -> Obj_term_dec_start 
# 364 "data_parser.dyp"
(
               ([fst _2,Abstract_syntax.Binder,snd _2]):'dypgen__Obj_term_dec_start)
# 1490               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("term_def_start",[Dyp.Ter "IDENT"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_IDENT  (
(_:((string*Abstract_syntax.location)))
# 1498               "data_parser_temp.ml"
 as _1)] -> Obj_term_def_start 
# 367 "data_parser.dyp"
(
        (fst _1,Abstract_syntax.Default,snd _1):'dypgen__Obj_term_def_start)
# 1503               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("term_def_start",[Dyp.Ter "PREFIX";Dyp.Ter "SYMBOL"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_PREFIX  (
(_:(Abstract_syntax.location))
# 1511               "data_parser_temp.ml"
 as _1);Obj_SYMBOL  (
# 369 "data_parser.dyp"
               (sym,l:((string*Abstract_syntax.location)))
# 1515               "data_parser_temp.ml"
 as _2)] -> Obj_term_def_start 
# 368 "data_parser.dyp"
(
                       ((sym,Abstract_syntax.Prefix,l)):'dypgen__Obj_term_def_start)
# 1520               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("term_def_start",[Dyp.Ter "INFIX";Dyp.Ter "SYMBOL"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_INFIX  (
(_:(Abstract_syntax.location))
# 1528               "data_parser_temp.ml"
 as _1);Obj_SYMBOL  (
# 370 "data_parser.dyp"
              (sym,l:((string*Abstract_syntax.location)))
# 1532               "data_parser_temp.ml"
 as _2)] -> Obj_term_def_start 
# 369 "data_parser.dyp"
(
                      ((sym,Abstract_syntax.Infix,l)):'dypgen__Obj_term_def_start)
# 1537               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("term_def_start",[Dyp.Ter "BINDER";Dyp.Ter "IDENT"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_BINDER  (
(_:(Abstract_syntax.location))
# 1545               "data_parser_temp.ml"
 as _1);Obj_IDENT  (
(_:((string*Abstract_syntax.location)))
# 1548               "data_parser_temp.ml"
 as _2)] -> Obj_term_def_start 
# 370 "data_parser.dyp"
(
               (fst _2,Abstract_syntax.Binder,snd _2):'dypgen__Obj_term_def_start)
# 1553               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("term_definition",[Dyp.Non_ter ("term_def_start",Dyp.No_priority );Dyp.Ter "EQUAL";Dyp.Non_ter ("term",Dyp.No_priority );Dyp.Ter "COLON";Dyp.Non_ter ("type_expression",Dyp.No_priority )],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_term_def_start ( (
(_:'dypgen__Obj_term_def_start)
# 1561               "data_parser_temp.ml"
 as _1));Obj_EQUAL  (
(_:(Abstract_syntax.location))
# 1564               "data_parser_temp.ml"
 as _2);Obj_term ( (
(_:'dypgen__Obj_term)
# 1567               "data_parser_temp.ml"
 as _3));Obj_COLON  (
(_:(Abstract_syntax.location))
# 1570               "data_parser_temp.ml"
 as _4);Obj_type_expression ( (
(_:'dypgen__Obj_type_expression)
# 1573               "data_parser_temp.ml"
 as _5))] -> Obj_term_definition 
# 374 "data_parser.dyp"
(
                                                  (fun s ->
						     let id,k,l = _1 in
						     let new_sig =
						       try
							 let term_value,ws = _3 Env.empty [] in
							 let new_sig2 = E.Signature1.add_entry (Abstract_syntax.Term_def (id,k,l,term_value,fst (_5 s))) s  in 
							   (match ws with
							      | [] -> new_sig2
							      | lst -> E.Signature1.add_warnings ws new_sig2) with
							     | E.Signature1.Duplicate_term_definition ->
								 emit_parse_error (Error.Duplicated_term id) (fst l,snd l) in
						       new_sig):'dypgen__Obj_term_definition)
# 1589               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("term_alone",[Dyp.Non_ter ("term",Dyp.No_priority );Dyp.Ter "COLON";Dyp.Non_ter ("type_expression",Dyp.No_priority );Dyp.Ter "EOI"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_term ( (
# 389 "data_parser.dyp"
      (t:'dypgen__Obj_term)
# 1598               "data_parser_temp.ml"
 as _1));Obj_COLON  (
(_:(Abstract_syntax.location))
# 1601               "data_parser_temp.ml"
 as _2);Obj_type_expression ( (
# 389 "data_parser.dyp"
                               (ty:'dypgen__Obj_type_expression)
# 1605               "data_parser_temp.ml"
 as _3)); _4] -> Obj_term_alone 
# 388 "data_parser.dyp"
(
                                        (let sg = (get_sig_value dyp.last_local_data) in
					   E.Signature1.convert_term (fst (t Env.empty [])) (fst (ty sg)) sg (*(E.Signature1.empty ("fake signature",(Lexing.dummy_pos,Lexing.dummy_pos)))*)):'dypgen__Obj_term_alone)
# 1611               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("heterogenous_term_and_type",[Dyp.Non_ter ("0_1",Dyp.No_priority );Dyp.Non_ter ("term",Dyp.No_priority );Dyp.Non_ter ("dypgen__early_action_5",Dyp.No_priority );Dyp.Ter "COLON";Dyp.Non_ter ("type_expression",Dyp.No_priority );Dyp.Ter "EOI"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_term ( (
# 394 "data_parser.dyp"
      (t:'dypgen__Obj_term)
# 1620               "data_parser_temp.ml"
 as _1));Obj_dypgen__early_action_5 ( (
(_:'dypgen__Obj_dypgen__early_action_5)
# 1623               "data_parser_temp.ml"
 as _2));Obj_COLON  (
(_:(Abstract_syntax.location))
# 1626               "data_parser_temp.ml"
 as _3);Obj_type_expression ( (
# 394 "data_parser.dyp"
                                                                                                                                              (ty:'dypgen__Obj_type_expression)
# 1630               "data_parser_temp.ml"
 as _4)); _5] -> Obj_heterogenous_term_and_type 
# 393 "data_parser.dyp"
(
                                                                                                                                                       (
  let abs_sig=get_sig_value dyp.last_local_data in
  (fst (t Env.empty [])),(fst (ty abs_sig))):'dypgen__Obj_heterogenous_term_and_type)
# 1637               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[3,
(fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_inh_val (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_term ( (
# 394 "data_parser.dyp"
      (t:'dypgen__Obj_term)
# 1644               "data_parser_temp.ml"
 as _1))] -> Inh_dypgen__early_action_5 
(
((_1)):'dypgen__Inh_dypgen__early_action_5)
# 1648               "data_parser_temp.ml"
 | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl)])
;
(("dypgen__early_action_5",[],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Inh_dypgen__early_action_5( (
# 394 "data_parser.dyp"
      (t:'dypgen__Obj_term)
# 1656               "data_parser_temp.ml"
 as _1))] ->  let res = 
# 393 "data_parser.dyp"
(
             (t,let abs_sig,_=get_abs_and_obj_sig_value dyp.last_local_data in [Local_data (Some (Signature abs_sig))]):'dypgen__Obj_dypgen__early_action_5 * ('t,'obj,'gd,'ld,'l) Dyp.dyp_action list)
# 1661               "data_parser_temp.ml"
  in Obj_dypgen__early_action_5(fst res), snd res
 | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("term",[Dyp.Ter "LAMBDA0";Dyp.Non_ter ("idents",Dyp.No_priority );Dyp.Ter "DOT";Dyp.Non_ter ("term",Dyp.No_priority )],"binder",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_LAMBDA0  (
(_:(Abstract_syntax.location))
# 1670               "data_parser_temp.ml"
 as _1);Obj_idents ( (
(_:'dypgen__Obj_idents)
# 1673               "data_parser_temp.ml"
 as _2));Obj_DOT  (
(_:(Abstract_syntax.location))
# 1676               "data_parser_temp.ml"
 as _3);Obj_term ( (
(_:'dypgen__Obj_term)
# 1679               "data_parser_temp.ml"
 as _4))] -> Obj_term 
# 399 "data_parser.dyp"
(
                           (
    let sg = get_sig_value dyp.last_local_data in
      fun env ws -> reset_location _1 (multiple_abs env ws Abstract_syntax.Linear _2 _4 (fun x -> x))):'dypgen__Obj_term)
# 1686               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("term",[Dyp.Ter "LAMBDA";Dyp.Non_ter ("idents",Dyp.No_priority );Dyp.Ter "DOT";Dyp.Non_ter ("term",Dyp.No_priority )],"binder",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_LAMBDA  (
(_:(Abstract_syntax.location))
# 1694               "data_parser_temp.ml"
 as _1);Obj_idents ( (
(_:'dypgen__Obj_idents)
# 1697               "data_parser_temp.ml"
 as _2));Obj_DOT  (
(_:(Abstract_syntax.location))
# 1700               "data_parser_temp.ml"
 as _3);Obj_term ( (
(_:'dypgen__Obj_term)
# 1703               "data_parser_temp.ml"
 as _4))] -> Obj_term 
# 402 "data_parser.dyp"
(
                          (
    let sg = get_sig_value dyp.last_local_data in
      fun env ws -> reset_location _1 (multiple_abs env ws Abstract_syntax.Non_linear _2 _4 (fun x -> x))):'dypgen__Obj_term)
# 1710               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("term",[Dyp.Non_ter ("0_1",Dyp.No_priority );Dyp.Ter "IDENT";Dyp.Non_ter ("idents",Dyp.No_priority );Dyp.Ter "DOT";Dyp.Non_ter ("dypgen__early_action_4",Dyp.No_priority );Dyp.Non_ter ("term",Dyp.No_priority )],"binder",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_IDENT  (
# 406 "data_parser.dyp"
       (b:((string*Abstract_syntax.location)))
# 1719               "data_parser_temp.ml"
 as _1);Obj_idents ( (
# 406 "data_parser.dyp"
                  (ids:'dypgen__Obj_idents)
# 1723               "data_parser_temp.ml"
 as _2));Obj_DOT  (
(_:(Abstract_syntax.location))
# 1726               "data_parser_temp.ml"
 as _3);Obj_dypgen__early_action_4 ( (
# 413 "data_parser.dyp"
                                                                        (lin:'dypgen__Obj_dypgen__early_action_4)
# 1730               "data_parser_temp.ml"
 as _4));Obj_term ( (
# 414 "data_parser.dyp"
          (t:'dypgen__Obj_term)
# 1734               "data_parser_temp.ml"
 as _5))] -> Obj_term 
# 413 "data_parser.dyp"
(
              (
	let binder,((p1,p2) as l) = b in
	  fun env ws -> reset_binder_location l (multiple_bind env ws (Abstract_syntax.Const(binder,l)) lin ids t (fun x -> x))):'dypgen__Obj_term)
# 1741               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[5,
(fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_inh_val (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_IDENT  (
# 406 "data_parser.dyp"
       (b:((string*Abstract_syntax.location)))
# 1748               "data_parser_temp.ml"
 as _1);Obj_idents ( (
# 406 "data_parser.dyp"
                  (ids:'dypgen__Obj_idents)
# 1752               "data_parser_temp.ml"
 as _2));Obj_DOT  (
(_:(Abstract_syntax.location))
# 1755               "data_parser_temp.ml"
 as _3)] -> Inh_dypgen__early_action_4 
(
((_1, _2, _3)):'dypgen__Inh_dypgen__early_action_4)
# 1759               "data_parser_temp.ml"
 | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl)])
;
(("dypgen__early_action_4",[],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Inh_dypgen__early_action_4( (
# 406 "data_parser.dyp"
       (b:'dypgen__Obj_IDENT)
# 1767               "data_parser_temp.ml"
 as _1),
 (
# 406 "data_parser.dyp"
                  (ids:'dypgen__Obj_idents)
# 1772               "data_parser_temp.ml"
 as _2),
 (
(_:'dypgen__Obj_DOT)
# 1776               "data_parser_temp.ml"
 as _3))] -> Obj_dypgen__early_action_4 
# 405 "data_parser.dyp"
(
                               (let sg = get_sig_value dyp.last_local_data in
				let binder,((p1,p2) as l) = b in
				  match E.Signature1.is_constant binder sg with
				    | true,Some Abstract_syntax.Binder -> (
					match E.Signature1.get_binder_argument_functional_type binder sg with
					  | None -> failwith "Binder of non functional type"
					  | Some k -> k)
				    | _ -> emit_parse_error (Error.Binder_expected binder) (p1,p2) ):'dypgen__Obj_dypgen__early_action_4)
# 1788               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("term",[Dyp.Non_ter ("application",Dyp.Lesseq_priority "app")],"app",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_application ( (
(_:'dypgen__Obj_application)
# 1796               "data_parser_temp.ml"
 as _1))] -> Obj_term 
# 416 "data_parser.dyp"
(
                     (_1):'dypgen__Obj_term)
# 1801               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("term",[Dyp.Non_ter ("0_1",Dyp.No_priority );Dyp.Non_ter ("atomic_term",Dyp.Lesseq_priority "atom");Dyp.Ter "SYMBOL";Dyp.Non_ter ("dypgen__early_action_3",Dyp.No_priority );Dyp.Non_ter ("term",Dyp.Lesseq_priority "app")],"app",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_atomic_term ( (
# 418 "data_parser.dyp"
                     (arg1:'dypgen__Obj_atomic_term)
# 1810               "data_parser_temp.ml"
 as _1));Obj_SYMBOL  (
# 418 "data_parser.dyp"
                                  (sym:((string*Abstract_syntax.location)))
# 1814               "data_parser_temp.ml"
 as _2);Obj_dypgen__early_action_3 ( (
(_:'dypgen__Obj_dypgen__early_action_3)
# 1817               "data_parser_temp.ml"
 as _3));Obj_term ( (
# 424 "data_parser.dyp"
                 (arg2:'dypgen__Obj_term)
# 1821               "data_parser_temp.ml"
 as _4))] -> Obj_term 
# 423 "data_parser.dyp"
(
                        (let id,((pos1,pos2) as l) = sym in
			   (fun env ws->
			      let u1,ws1 = arg1 env ws in
			      let u2,ws2 = arg2 env ws1 in
				(Abstract_syntax.App (Abstract_syntax.App(Abstract_syntax.Const(id,l),u1,new_loc (get_term_location u1) l),u2,new_loc (get_term_location u1) (get_term_location u2))),ws2)):'dypgen__Obj_term)
# 1830               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[4,
(fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_inh_val (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_atomic_term ( (
# 418 "data_parser.dyp"
                     (arg1:'dypgen__Obj_atomic_term)
# 1837               "data_parser_temp.ml"
 as _1));Obj_SYMBOL  (
# 418 "data_parser.dyp"
                                  (sym:((string*Abstract_syntax.location)))
# 1841               "data_parser_temp.ml"
 as _2)] -> Inh_dypgen__early_action_3 
(
((_1, _2)):'dypgen__Inh_dypgen__early_action_3)
# 1845               "data_parser_temp.ml"
 | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl)])
;
(("dypgen__early_action_3",[],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Inh_dypgen__early_action_3( (
# 418 "data_parser.dyp"
                     (arg1:'dypgen__Obj_atomic_term)
# 1853               "data_parser_temp.ml"
 as _1),
 (
# 418 "data_parser.dyp"
                                  (sym:'dypgen__Obj_SYMBOL)
# 1858               "data_parser_temp.ml"
 as _2))] -> Obj_dypgen__early_action_3 
# 417 "data_parser.dyp"
(
                                           (let id,((pos1,pos2) as l) = sym in
					    let sg = get_sig_value dyp.last_local_data in
					      match E.Signature1.is_constant id sg with
						| true,Some (Abstract_syntax.Infix) -> Error.unset_infix ()
						| true,_ -> raise Dyp.Giveup
						| _ -> emit_parse_error (Error.Unknown_constant id) (pos1,pos2)):'dypgen__Obj_dypgen__early_action_3)
# 1868               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("atomic_term",[Dyp.Ter "IDENT"],"atom",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_IDENT  (
(_:((string*Abstract_syntax.location)))
# 1876               "data_parser_temp.ml"
 as _1)] -> Obj_atomic_term 
# 430 "data_parser.dyp"
(
        (let id,l=_1 in
	 let s = get_sig_value dyp.last_local_data in 
	 let is_constant,_ = E.Signature1.is_constant id s in
	   fun env ws -> 
	     match Env.mem id env,is_constant with
	       | true,false -> Abstract_syntax.Var (id,l),ws
	       | true,true -> Abstract_syntax.Var (id,l),(Error.Variable_or_constant (id,fst l,snd l))::ws
	       | false,true -> Abstract_syntax.Const (id,l),ws
	       | false,false ->emit_parse_error (Error.Unknown_constant id) (fst l,snd l)):'dypgen__Obj_atomic_term)
# 1889               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("atomic_term",[Dyp.Ter "LPAREN";Dyp.Non_ter ("term",Dyp.No_priority );Dyp.Ter "RPAREN"],"atom",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_LPAREN  (
(_:(Abstract_syntax.location))
# 1897               "data_parser_temp.ml"
 as _1);Obj_term ( (
(_:'dypgen__Obj_term)
# 1900               "data_parser_temp.ml"
 as _2));Obj_RPAREN  (
(_:(Abstract_syntax.location))
# 1903               "data_parser_temp.ml"
 as _3)] -> Obj_atomic_term 
# 439 "data_parser.dyp"
(
                     (_2):'dypgen__Obj_atomic_term)
# 1908               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("atomic_term",[Dyp.Non_ter ("0_1",Dyp.No_priority );Dyp.Ter "SYMBOL";Dyp.Non_ter ("dypgen__early_action_2",Dyp.No_priority );Dyp.Non_ter ("term",Dyp.No_priority )],"atom",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_SYMBOL  (
# 441 "data_parser.dyp"
        (sym:((string*Abstract_syntax.location)))
# 1917               "data_parser_temp.ml"
 as _1);Obj_dypgen__early_action_2 ( (
(_:'dypgen__Obj_dypgen__early_action_2)
# 1920               "data_parser_temp.ml"
 as _2));Obj_term ( (
# 448 "data_parser.dyp"
          (t:'dypgen__Obj_term)
# 1924               "data_parser_temp.ml"
 as _3))] -> Obj_atomic_term 
# 447 "data_parser.dyp"
(
              (let id,((pos1,pos2) as l) = sym in
		 (fun env ws ->
		    let u2,ws2 = t env ws in
		      (Abstract_syntax.App(Abstract_syntax.Const(id,l),u2,new_loc l (get_term_location u2))),ws2)):'dypgen__Obj_atomic_term)
# 1932               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[3,
(fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_inh_val (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_SYMBOL  (
# 441 "data_parser.dyp"
        (sym:((string*Abstract_syntax.location)))
# 1939               "data_parser_temp.ml"
 as _1)] -> Inh_dypgen__early_action_2 
(
((_1)):'dypgen__Inh_dypgen__early_action_2)
# 1943               "data_parser_temp.ml"
 | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl)])
;
(("dypgen__early_action_2",[],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Inh_dypgen__early_action_2( (
# 441 "data_parser.dyp"
        (sym:'dypgen__Obj_SYMBOL)
# 1951               "data_parser_temp.ml"
 as _1))] -> Obj_dypgen__early_action_2 
# 440 "data_parser.dyp"
(
                 (let sg = get_sig_value dyp.last_local_data in
	     let id,((pos1,pos2) as l) = sym in
	       match E.Signature1.is_constant id sg with
		 | true,Some (Abstract_syntax.Prefix) -> ()
		 | true,_ -> let () = Error.set_infix sym in
		     raise Dyp.Giveup
		 | _ -> emit_parse_error (Error.Unknown_constant id) (pos1,pos2)):'dypgen__Obj_dypgen__early_action_2)
# 1962               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("application",[Dyp.Non_ter ("atomic_term",Dyp.Lesseq_priority "atom")],"app",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_atomic_term ( (
(_:'dypgen__Obj_atomic_term)
# 1970               "data_parser_temp.ml"
 as _1))] -> Obj_application 
# 453 "data_parser.dyp"
(
                      (_1):'dypgen__Obj_application)
# 1975               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("application",[Dyp.Non_ter ("application",Dyp.Lesseq_priority "app");Dyp.Non_ter ("atomic_term",Dyp.Lesseq_priority "atom")],"app",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_application ( (
(_:'dypgen__Obj_application)
# 1983               "data_parser_temp.ml"
 as _1));Obj_atomic_term ( (
(_:'dypgen__Obj_atomic_term)
# 1986               "data_parser_temp.ml"
 as _2))] -> Obj_application 
# 454 "data_parser.dyp"
(
                                         (fun e ws ->
					    let u1,ws1 = _1 e ws in
					    let u2,ws2 = _2 e ws1 in
					      (Abstract_syntax.App(u1,u2,new_loc (get_term_location u1) (get_term_location u2))),ws2):'dypgen__Obj_application)
# 1994               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("idents",[],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [] -> Obj_idents 
# 460 "data_parser.dyp"
(
  ([]):'dypgen__Obj_idents)
# 2004               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("idents",[Dyp.Ter "IDENT";Dyp.Non_ter ("idents",Dyp.No_priority )],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_IDENT  (
(_:((string*Abstract_syntax.location)))
# 2012               "data_parser_temp.ml"
 as _1);Obj_idents ( (
(_:'dypgen__Obj_idents)
# 2015               "data_parser_temp.ml"
 as _2))] -> Obj_idents 
# 461 "data_parser.dyp"
(
               (_1::_2):'dypgen__Obj_idents)
# 2020               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("lex_entries",[Dyp.Ter "END_OF_DEC"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_END_OF_DEC  (
(_:(Abstract_syntax.location))
# 2028               "data_parser_temp.ml"
 as _1)] -> Obj_lex_entries 
# 464 "data_parser.dyp"
(
             (fun lex -> lex):'dypgen__Obj_lex_entries)
# 2033               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("lex_entries",[Dyp.Non_ter ("lex_entry",Dyp.No_priority );Dyp.Ter "END_OF_DEC"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_lex_entry ( (
# 466 "data_parser.dyp"
           (e:'dypgen__Obj_lex_entry)
# 2042               "data_parser_temp.ml"
 as _1));Obj_END_OF_DEC  (
(_:(Abstract_syntax.location))
# 2045               "data_parser_temp.ml"
 as _2)] -> Obj_lex_entries 
# 465 "data_parser.dyp"
(
                          (fun lex -> e lex):'dypgen__Obj_lex_entries)
# 2050               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("lex_entries",[Dyp.Non_ter ("lex_entry",Dyp.No_priority );Dyp.Ter "SEMICOLON";Dyp.Non_ter ("lex_entries",Dyp.No_priority )],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_lex_entry ( (
# 467 "data_parser.dyp"
           (e:'dypgen__Obj_lex_entry)
# 2059               "data_parser_temp.ml"
 as _1));Obj_SEMICOLON  (
(_:(Abstract_syntax.location))
# 2062               "data_parser_temp.ml"
 as _2);Obj_lex_entries ( (
# 467 "data_parser.dyp"
                                    (es:'dypgen__Obj_lex_entries)
# 2066               "data_parser_temp.ml"
 as _3))] -> Obj_lex_entries 
# 466 "data_parser.dyp"
(
                                         (fun lex -> es (e lex)):'dypgen__Obj_lex_entries)
# 2071               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("lex_entry",[Dyp.Non_ter ("0_1",Dyp.No_priority );Dyp.Non_ter ("comma_ids_or_sym",Dyp.No_priority );Dyp.Ter "COLON_EQUAL";Dyp.Non_ter ("dypgen__early_action_1",Dyp.No_priority );Dyp.Non_ter ("term",Dyp.No_priority )],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_comma_ids_or_sym ( (
# 471 "data_parser.dyp"
                  (ids:'dypgen__Obj_comma_ids_or_sym)
# 2080               "data_parser_temp.ml"
 as _1));Obj_COLON_EQUAL  (
(_:(Abstract_syntax.location))
# 2083               "data_parser_temp.ml"
 as _2);Obj_dypgen__early_action_1 ( (
# 487 "data_parser.dyp"
           (kind:'dypgen__Obj_dypgen__early_action_1)
# 2087               "data_parser_temp.ml"
 as _3));Obj_term ( (
# 488 "data_parser.dyp"
       (t:'dypgen__Obj_term)
# 2091               "data_parser_temp.ml"
 as _4))] -> Obj_lex_entry 
# 487 "data_parser.dyp"
(
            (
	    try
	      fun lex ->
		let term = fst (t Env.empty []) in
		List.fold_left
		  (fun acc (id,loc) -> E.Lexicon.insert (Abstract_syntax.Constant (id,loc,term)) acc)
		  lex
		  ids
	    with
	    | Error.Error (Error.Parse_error (Error.Unknown_constant _,_)) when kind = Both ->  raise Dyp.Giveup 
	    | exc -> raise exc ):'dypgen__Obj_lex_entry)
# 2106               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[4,
(fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_inh_val (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_comma_ids_or_sym ( (
# 471 "data_parser.dyp"
                  (ids:'dypgen__Obj_comma_ids_or_sym)
# 2113               "data_parser_temp.ml"
 as _1));Obj_COLON_EQUAL  (
(_:(Abstract_syntax.location))
# 2116               "data_parser_temp.ml"
 as _2)] -> Inh_dypgen__early_action_1 
(
((_1, _2)):'dypgen__Inh_dypgen__early_action_1)
# 2120               "data_parser_temp.ml"
 | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl)])
;
(("dypgen__early_action_1",[],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Inh_dypgen__early_action_1( (
# 471 "data_parser.dyp"
                  (ids:'dypgen__Obj_comma_ids_or_sym)
# 2128               "data_parser_temp.ml"
 as _1),
 (
(_:'dypgen__Obj_COLON_EQUAL)
# 2132               "data_parser_temp.ml"
 as _2))] -> Obj_dypgen__early_action_1 
# 470 "data_parser.dyp"
(
                                       (
    let () = incr () in
    let abs,obj = get_abs_and_obj_sig_value dyp.last_local_data in    
    let kind =
      List.fold_left
	(fun k (id,loc) ->
	   match k,fst (E.Signature1.is_constant id abs),E.Signature1.is_type id abs with
	     | (Nothing|Cst|Both),true,false -> Cst
	     | (Nothing|Both),true,true -> Both
	     | Cst,true,_ -> Cst
	     | (Nothing|Both),false,true -> raise Dyp.Giveup 
	     | (Nothing|Both),false,false -> emit_parse_error (Error.Unknown_constant id) loc
	     | Cst,false,_ -> emit_parse_error (Error.Unknown_constant id) loc
	     | Type,_,_ -> failwith "Bug: should not occur")
	Nothing
	ids in
      kind):'dypgen__Obj_dypgen__early_action_1)
# 2153               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("lex_entry",[Dyp.Non_ter ("0_1",Dyp.No_priority );Dyp.Non_ter ("comma_ids",Dyp.No_priority );Dyp.Ter "COLON_EQUAL";Dyp.Non_ter ("dypgen__early_action_0",Dyp.No_priority );Dyp.Non_ter ("type_expression",Dyp.No_priority )],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_comma_ids ( (
# 499 "data_parser.dyp"
           (ids:'dypgen__Obj_comma_ids)
# 2162               "data_parser_temp.ml"
 as _1));Obj_COLON_EQUAL  (
(_:(Abstract_syntax.location))
# 2165               "data_parser_temp.ml"
 as _2);Obj_dypgen__early_action_0 ( (
(_:'dypgen__Obj_dypgen__early_action_0)
# 2168               "data_parser_temp.ml"
 as _3));Obj_type_expression ( (
# 524 "data_parser.dyp"
                      (ty:'dypgen__Obj_type_expression)
# 2172               "data_parser_temp.ml"
 as _4))] -> Obj_lex_entry 
# 523 "data_parser.dyp"
(
                            (
		  fun lex ->
		    let _,obj = get_abs_and_obj_sig_value dyp.last_local_data in    
		    let actual_type = fst (ty obj) in
		      List.fold_left
			(fun acc (id,loc) -> E.Lexicon.insert (Abstract_syntax.Type (id,loc,actual_type)) acc)
			lex
			ids):'dypgen__Obj_lex_entry)
# 2184               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[4,
(fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_inh_val (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_comma_ids ( (
# 499 "data_parser.dyp"
           (ids:'dypgen__Obj_comma_ids)
# 2191               "data_parser_temp.ml"
 as _1));Obj_COLON_EQUAL  (
(_:(Abstract_syntax.location))
# 2194               "data_parser_temp.ml"
 as _2)] -> Inh_dypgen__early_action_0 
(
((_1, _2)):'dypgen__Inh_dypgen__early_action_0)
# 2198               "data_parser_temp.ml"
 | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl)])
;
(("dypgen__early_action_0",[],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Inh_dypgen__early_action_0( (
# 499 "data_parser.dyp"
           (ids:'dypgen__Obj_comma_ids)
# 2206               "data_parser_temp.ml"
 as _1),
 (
(_:'dypgen__Obj_COLON_EQUAL)
# 2210               "data_parser_temp.ml"
 as _2))] -> Obj_dypgen__early_action_0 
# 498 "data_parser.dyp"
(
                                (
  let abs,obj = get_abs_and_obj_sig_value dyp.last_local_data in    
  let kind =
    List.fold_left
      (fun k (id,loc) ->
	match k,fst (E.Signature1.is_constant id abs),E.Signature1.is_type id abs with
	| (Nothing|Type|Both),false,true -> Type
	| (Nothing|Both),true,true -> Both
	| Type,_,true -> Type
	| (Nothing|Both),true,false -> raise Dyp.Giveup 
	| (Nothing|Both),false,false -> emit_parse_error (Error.Unknown_type id) loc
	| Type,_,false -> emit_parse_error (Error.Unknown_type id) loc
	| Cst,_,_ -> failwith "Bug: should not occur"
(*	   match k,E.Signature1.is_type id abs with
	     | (None|Some Type),true -> Some Type
	     | None,false ->
		 if fst (E.Signature1.is_constant id abs)
		 then
		   raise Dyp.Giveup 
		 else
		   emit_parse_error (Error.Unknown_type id) loc
	     | Some Type,false -> emit_parse_error (Error.Unknown_type id) loc
	     | Some Cst,_ -> failwith "Bug: should not occur"*) )
	Nothing
	ids in ()):'dypgen__Obj_dypgen__early_action_0)
# 2239               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("comma_ids_or_sym",[Dyp.Ter "IDENT"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_IDENT  (
# 534 "data_parser.dyp"
       (id:((string*Abstract_syntax.location)))
# 2248               "data_parser_temp.ml"
 as _1)] -> Obj_comma_ids_or_sym 
# 533 "data_parser.dyp"
(
            ([id]):'dypgen__Obj_comma_ids_or_sym)
# 2253               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("comma_ids_or_sym",[Dyp.Ter "SYMBOL"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_SYMBOL  (
# 535 "data_parser.dyp"
        (id:((string*Abstract_syntax.location)))
# 2262               "data_parser_temp.ml"
 as _1)] -> Obj_comma_ids_or_sym 
# 534 "data_parser.dyp"
(
             ([id]):'dypgen__Obj_comma_ids_or_sym)
# 2267               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("comma_ids_or_sym",[Dyp.Ter "IDENT";Dyp.Ter "COMMA";Dyp.Non_ter ("comma_ids",Dyp.No_priority )],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_IDENT  (
# 536 "data_parser.dyp"
       (id:((string*Abstract_syntax.location)))
# 2276               "data_parser_temp.ml"
 as _1);Obj_COMMA  (
(_:(Abstract_syntax.location))
# 2279               "data_parser_temp.ml"
 as _2);Obj_comma_ids ( (
# 536 "data_parser.dyp"
                           (id_list:'dypgen__Obj_comma_ids)
# 2283               "data_parser_temp.ml"
 as _3))] -> Obj_comma_ids_or_sym 
# 535 "data_parser.dyp"
(
                                     (id::id_list):'dypgen__Obj_comma_ids_or_sym)
# 2288               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("comma_ids_or_sym",[Dyp.Ter "SYMBOL";Dyp.Ter "COMMA";Dyp.Non_ter ("comma_ids",Dyp.No_priority )],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_SYMBOL  (
# 537 "data_parser.dyp"
        (id:((string*Abstract_syntax.location)))
# 2297               "data_parser_temp.ml"
 as _1);Obj_COMMA  (
(_:(Abstract_syntax.location))
# 2300               "data_parser_temp.ml"
 as _2);Obj_comma_ids ( (
# 537 "data_parser.dyp"
                            (id_list:'dypgen__Obj_comma_ids)
# 2304               "data_parser_temp.ml"
 as _3))] -> Obj_comma_ids_or_sym 
# 536 "data_parser.dyp"
(
                                      (id::id_list):'dypgen__Obj_comma_ids_or_sym)
# 2309               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("0_1",[],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [] -> Obj_dypgen__epsilon 
(
():'dypgen__Obj_dypgen__epsilon)
# 2318               "data_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])],

(["dummy_entry",Dyp.RE_Eof_char],
[0,(fun _ -> Lexeme_matched "")]),

[]

let __dypgen_regexp_decl = []

let dyp_merge_Inh_dypgen__early_action_0 l =
  match dyp_merge_Inh_dypgen__early_action_0 l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Inh_dypgen__early_action_1 l =
  match dyp_merge_Inh_dypgen__early_action_1 l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Inh_dypgen__early_action_2 l =
  match dyp_merge_Inh_dypgen__early_action_2 l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Inh_dypgen__early_action_3 l =
  match dyp_merge_Inh_dypgen__early_action_3 l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Inh_dypgen__early_action_4 l =
  match dyp_merge_Inh_dypgen__early_action_4 l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Inh_dypgen__early_action_5 l =
  match dyp_merge_Inh_dypgen__early_action_5 l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Inh_dypgen__early_action_6 l =
  match dyp_merge_Inh_dypgen__early_action_6 l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Inh_dypgen__early_action_7 l =
  match dyp_merge_Inh_dypgen__early_action_7 l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Inh_dypgen__early_action_8 l =
  match dyp_merge_Inh_dypgen__early_action_8 l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Lexeme_matched l =
  match dyp_merge_Lexeme_matched l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_ARROW l =
  match dyp_merge_Obj_ARROW l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_BINDER l =
  match dyp_merge_Obj_BINDER l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_COLON l =
  match dyp_merge_Obj_COLON l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_COLON_EQUAL l =
  match dyp_merge_Obj_COLON_EQUAL l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_COMMA l =
  match dyp_merge_Obj_COMMA l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_COMPOSE l =
  match dyp_merge_Obj_COMPOSE l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_DOT l =
  match dyp_merge_Obj_DOT l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_END_OF_DEC l =
  match dyp_merge_Obj_END_OF_DEC l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_EQUAL l =
  match dyp_merge_Obj_EQUAL l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_IDENT l =
  match dyp_merge_Obj_IDENT l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_INFIX l =
  match dyp_merge_Obj_INFIX l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_LAMBDA l =
  match dyp_merge_Obj_LAMBDA l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_LAMBDA0 l =
  match dyp_merge_Obj_LAMBDA0 l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_LEX_OPEN l =
  match dyp_merge_Obj_LEX_OPEN l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_LIN_ARROW l =
  match dyp_merge_Obj_LIN_ARROW l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_LPAREN l =
  match dyp_merge_Obj_LPAREN l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_PREFIX l =
  match dyp_merge_Obj_PREFIX l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_RPAREN l =
  match dyp_merge_Obj_RPAREN l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_SEMICOLON l =
  match dyp_merge_Obj_SEMICOLON l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_SIG_OPEN l =
  match dyp_merge_Obj_SIG_OPEN l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_SYMBOL l =
  match dyp_merge_Obj_SYMBOL l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_TYPE l =
  match dyp_merge_Obj_TYPE l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_application l =
  match dyp_merge_Obj_application l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_arrow l =
  match dyp_merge_Obj_arrow l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_atomic_term l =
  match dyp_merge_Obj_atomic_term l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_atomic_type l =
  match dyp_merge_Obj_atomic_type l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_comma_ids l =
  match dyp_merge_Obj_comma_ids l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_comma_ids_or_sym l =
  match dyp_merge_Obj_comma_ids_or_sym l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_composition_argument l =
  match dyp_merge_Obj_composition_argument l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_data l =
  match dyp_merge_Obj_data l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_dypgen__early_action_0 l =
  match dyp_merge_Obj_dypgen__early_action_0 l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_dypgen__early_action_1 l =
  match dyp_merge_Obj_dypgen__early_action_1 l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_dypgen__early_action_2 l =
  match dyp_merge_Obj_dypgen__early_action_2 l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_dypgen__early_action_3 l =
  match dyp_merge_Obj_dypgen__early_action_3 l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_dypgen__early_action_4 l =
  match dyp_merge_Obj_dypgen__early_action_4 l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_dypgen__early_action_5 l =
  match dyp_merge_Obj_dypgen__early_action_5 l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_dypgen__early_action_6 l =
  match dyp_merge_Obj_dypgen__early_action_6 l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_dypgen__early_action_7 l =
  match dyp_merge_Obj_dypgen__early_action_7 l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_dypgen__early_action_8 l =
  match dyp_merge_Obj_dypgen__early_action_8 l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_dypgen__epsilon l =
  match dyp_merge_Obj_dypgen__epsilon l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_heterogenous_term_and_type l =
  match dyp_merge_Obj_heterogenous_term_and_type l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_idents l =
  match dyp_merge_Obj_idents l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_lex_entries l =
  match dyp_merge_Obj_lex_entries l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_lex_entry l =
  match dyp_merge_Obj_lex_entry l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_lex_opening l =
  match dyp_merge_Obj_lex_opening l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_lexicon l =
  match dyp_merge_Obj_lexicon l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_lexicon_composition l =
  match dyp_merge_Obj_lexicon_composition l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_sig_entries l =
  match dyp_merge_Obj_sig_entries l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_sig_entry l =
  match dyp_merge_Obj_sig_entry l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_sig_ident l =
  match dyp_merge_Obj_sig_ident l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_signature l =
  match dyp_merge_Obj_signature l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_term l =
  match dyp_merge_Obj_term l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_term_alone l =
  match dyp_merge_Obj_term_alone l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_term_dec_start l =
  match dyp_merge_Obj_term_dec_start l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_term_declaration l =
  match dyp_merge_Obj_term_declaration l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_term_def_start l =
  match dyp_merge_Obj_term_def_start l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_term_definition l =
  match dyp_merge_Obj_term_definition l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_type_declaration l =
  match dyp_merge_Obj_type_declaration l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_type_definition l =
  match dyp_merge_Obj_type_definition l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_type_expression l =
  match dyp_merge_Obj_type_expression l with
    | ([],_,_) -> dyp_merge l
    | res -> res

let __dypgen_merge_list = [(fun l -> (
  let f1 (o,gd,ld) = match o with Inh_dypgen__early_action_0 ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Inh_dypgen__early_action_0"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Inh_dypgen__early_action_0 l in
  let f2 o = Inh_dypgen__early_action_0 o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Inh_dypgen__early_action_1 ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Inh_dypgen__early_action_1"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Inh_dypgen__early_action_1 l in
  let f2 o = Inh_dypgen__early_action_1 o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Inh_dypgen__early_action_2 ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Inh_dypgen__early_action_2"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Inh_dypgen__early_action_2 l in
  let f2 o = Inh_dypgen__early_action_2 o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Inh_dypgen__early_action_3 ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Inh_dypgen__early_action_3"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Inh_dypgen__early_action_3 l in
  let f2 o = Inh_dypgen__early_action_3 o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Inh_dypgen__early_action_4 ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Inh_dypgen__early_action_4"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Inh_dypgen__early_action_4 l in
  let f2 o = Inh_dypgen__early_action_4 o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Inh_dypgen__early_action_5 ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Inh_dypgen__early_action_5"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Inh_dypgen__early_action_5 l in
  let f2 o = Inh_dypgen__early_action_5 o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Inh_dypgen__early_action_6 ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Inh_dypgen__early_action_6"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Inh_dypgen__early_action_6 l in
  let f2 o = Inh_dypgen__early_action_6 o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Inh_dypgen__early_action_7 ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Inh_dypgen__early_action_7"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Inh_dypgen__early_action_7 l in
  let f2 o = Inh_dypgen__early_action_7 o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Inh_dypgen__early_action_8 ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Inh_dypgen__early_action_8"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Inh_dypgen__early_action_8 l in
  let f2 o = Inh_dypgen__early_action_8 o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Lexeme_matched ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Lexeme_matched"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Lexeme_matched l in
  let f2 o = Lexeme_matched o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_ARROW ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_ARROW"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_ARROW l in
  let f2 o = Obj_ARROW o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_BINDER ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_BINDER"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_BINDER l in
  let f2 o = Obj_BINDER o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_COLON ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_COLON"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_COLON l in
  let f2 o = Obj_COLON o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_COLON_EQUAL ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_COLON_EQUAL"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_COLON_EQUAL l in
  let f2 o = Obj_COLON_EQUAL o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_COMMA ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_COMMA"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_COMMA l in
  let f2 o = Obj_COMMA o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_COMPOSE ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_COMPOSE"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_COMPOSE l in
  let f2 o = Obj_COMPOSE o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_DOT ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_DOT"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_DOT l in
  let f2 o = Obj_DOT o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_END_OF_DEC ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_END_OF_DEC"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_END_OF_DEC l in
  let f2 o = Obj_END_OF_DEC o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_EQUAL ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_EQUAL"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_EQUAL l in
  let f2 o = Obj_EQUAL o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_IDENT ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_IDENT"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_IDENT l in
  let f2 o = Obj_IDENT o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_INFIX ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_INFIX"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_INFIX l in
  let f2 o = Obj_INFIX o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_LAMBDA ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_LAMBDA"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_LAMBDA l in
  let f2 o = Obj_LAMBDA o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_LAMBDA0 ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_LAMBDA0"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_LAMBDA0 l in
  let f2 o = Obj_LAMBDA0 o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_LEX_OPEN ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_LEX_OPEN"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_LEX_OPEN l in
  let f2 o = Obj_LEX_OPEN o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_LIN_ARROW ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_LIN_ARROW"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_LIN_ARROW l in
  let f2 o = Obj_LIN_ARROW o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_LPAREN ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_LPAREN"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_LPAREN l in
  let f2 o = Obj_LPAREN o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_PREFIX ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_PREFIX"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_PREFIX l in
  let f2 o = Obj_PREFIX o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_RPAREN ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_RPAREN"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_RPAREN l in
  let f2 o = Obj_RPAREN o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_SEMICOLON ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_SEMICOLON"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_SEMICOLON l in
  let f2 o = Obj_SEMICOLON o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_SIG_OPEN ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_SIG_OPEN"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_SIG_OPEN l in
  let f2 o = Obj_SIG_OPEN o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_SYMBOL ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_SYMBOL"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_SYMBOL l in
  let f2 o = Obj_SYMBOL o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_TYPE ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_TYPE"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_TYPE l in
  let f2 o = Obj_TYPE o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_application ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_application"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_application l in
  let f2 o = Obj_application o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_arrow ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_arrow"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_arrow l in
  let f2 o = Obj_arrow o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_atomic_term ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_atomic_term"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_atomic_term l in
  let f2 o = Obj_atomic_term o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_atomic_type ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_atomic_type"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_atomic_type l in
  let f2 o = Obj_atomic_type o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_comma_ids ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_comma_ids"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_comma_ids l in
  let f2 o = Obj_comma_ids o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_comma_ids_or_sym ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_comma_ids_or_sym"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_comma_ids_or_sym l in
  let f2 o = Obj_comma_ids_or_sym o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_composition_argument ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_composition_argument"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_composition_argument l in
  let f2 o = Obj_composition_argument o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_data ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_data"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_data l in
  let f2 o = Obj_data o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_dypgen__early_action_0 ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_dypgen__early_action_0"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_dypgen__early_action_0 l in
  let f2 o = Obj_dypgen__early_action_0 o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_dypgen__early_action_1 ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_dypgen__early_action_1"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_dypgen__early_action_1 l in
  let f2 o = Obj_dypgen__early_action_1 o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_dypgen__early_action_2 ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_dypgen__early_action_2"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_dypgen__early_action_2 l in
  let f2 o = Obj_dypgen__early_action_2 o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_dypgen__early_action_3 ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_dypgen__early_action_3"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_dypgen__early_action_3 l in
  let f2 o = Obj_dypgen__early_action_3 o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_dypgen__early_action_4 ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_dypgen__early_action_4"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_dypgen__early_action_4 l in
  let f2 o = Obj_dypgen__early_action_4 o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_dypgen__early_action_5 ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_dypgen__early_action_5"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_dypgen__early_action_5 l in
  let f2 o = Obj_dypgen__early_action_5 o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_dypgen__early_action_6 ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_dypgen__early_action_6"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_dypgen__early_action_6 l in
  let f2 o = Obj_dypgen__early_action_6 o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_dypgen__early_action_7 ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_dypgen__early_action_7"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_dypgen__early_action_7 l in
  let f2 o = Obj_dypgen__early_action_7 o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_dypgen__early_action_8 ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_dypgen__early_action_8"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_dypgen__early_action_8 l in
  let f2 o = Obj_dypgen__early_action_8 o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_dypgen__epsilon ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_dypgen__epsilon"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_dypgen__epsilon l in
  let f2 o = Obj_dypgen__epsilon o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_heterogenous_term_and_type ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_heterogenous_term_and_type"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_heterogenous_term_and_type l in
  let f2 o = Obj_heterogenous_term_and_type o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_idents ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_idents"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_idents l in
  let f2 o = Obj_idents o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_lex_entries ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_lex_entries"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_lex_entries l in
  let f2 o = Obj_lex_entries o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_lex_entry ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_lex_entry"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_lex_entry l in
  let f2 o = Obj_lex_entry o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_lex_opening ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_lex_opening"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_lex_opening l in
  let f2 o = Obj_lex_opening o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_lexicon ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_lexicon"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_lexicon l in
  let f2 o = Obj_lexicon o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_lexicon_composition ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_lexicon_composition"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_lexicon_composition l in
  let f2 o = Obj_lexicon_composition o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_sig_entries ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_sig_entries"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_sig_entries l in
  let f2 o = Obj_sig_entries o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_sig_entry ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_sig_entry"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_sig_entry l in
  let f2 o = Obj_sig_entry o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_sig_ident ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_sig_ident"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_sig_ident l in
  let f2 o = Obj_sig_ident o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_signature ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_signature"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_signature l in
  let f2 o = Obj_signature o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_term ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_term"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_term l in
  let f2 o = Obj_term o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_term_alone ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_term_alone"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_term_alone l in
  let f2 o = Obj_term_alone o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_term_dec_start ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_term_dec_start"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_term_dec_start l in
  let f2 o = Obj_term_dec_start o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_term_declaration ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_term_declaration"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_term_declaration l in
  let f2 o = Obj_term_declaration o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_term_def_start ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_term_def_start"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_term_def_start l in
  let f2 o = Obj_term_def_start o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_term_definition ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_term_definition"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_term_definition l in
  let f2 o = Obj_term_definition o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_type_declaration ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_type_declaration"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_type_declaration l in
  let f2 o = Obj_type_declaration o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_type_definition ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_type_definition"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_type_definition l in
  let f2 o = Obj_type_definition o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_type_expression ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_type_expression"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_type_expression l in
  let f2 o = Obj_type_expression o in
  (List.map f2 ol, gd, ld)))]



let __dypgen_test_cons () =  [|
  (fun x -> match x with Inh_dypgen__early_action_0 _ -> true | _ -> false);
  (fun x -> match x with Inh_dypgen__early_action_1 _ -> true | _ -> false);
  (fun x -> match x with Inh_dypgen__early_action_2 _ -> true | _ -> false);
  (fun x -> match x with Inh_dypgen__early_action_3 _ -> true | _ -> false);
  (fun x -> match x with Inh_dypgen__early_action_4 _ -> true | _ -> false);
  (fun x -> match x with Inh_dypgen__early_action_5 _ -> true | _ -> false);
  (fun x -> match x with Inh_dypgen__early_action_6 _ -> true | _ -> false);
  (fun x -> match x with Inh_dypgen__early_action_7 _ -> true | _ -> false);
  (fun x -> match x with Inh_dypgen__early_action_8 _ -> true | _ -> false);
  (fun x -> match x with Lexeme_matched _ -> true | _ -> false);
  (fun x -> match x with Obj_ARROW _ -> true | _ -> false);
  (fun x -> match x with Obj_BINDER _ -> true | _ -> false);
  (fun x -> match x with Obj_COLON _ -> true | _ -> false);
  (fun x -> match x with Obj_COLON_EQUAL _ -> true | _ -> false);
  (fun x -> match x with Obj_COMMA _ -> true | _ -> false);
  (fun x -> match x with Obj_COMPOSE _ -> true | _ -> false);
  (fun x -> match x with Obj_DOT _ -> true | _ -> false);
  (fun x -> match x with Obj_END_OF_DEC _ -> true | _ -> false);
  (fun x -> match x with Obj_EQUAL _ -> true | _ -> false);
  (fun x -> match x with Obj_IDENT _ -> true | _ -> false);
  (fun x -> match x with Obj_INFIX _ -> true | _ -> false);
  (fun x -> match x with Obj_LAMBDA _ -> true | _ -> false);
  (fun x -> match x with Obj_LAMBDA0 _ -> true | _ -> false);
  (fun x -> match x with Obj_LEX_OPEN _ -> true | _ -> false);
  (fun x -> match x with Obj_LIN_ARROW _ -> true | _ -> false);
  (fun x -> match x with Obj_LPAREN _ -> true | _ -> false);
  (fun x -> match x with Obj_PREFIX _ -> true | _ -> false);
  (fun x -> match x with Obj_RPAREN _ -> true | _ -> false);
  (fun x -> match x with Obj_SEMICOLON _ -> true | _ -> false);
  (fun x -> match x with Obj_SIG_OPEN _ -> true | _ -> false);
  (fun x -> match x with Obj_SYMBOL _ -> true | _ -> false);
  (fun x -> match x with Obj_TYPE _ -> true | _ -> false);
  (fun x -> match x with Obj_application _ -> true | _ -> false);
  (fun x -> match x with Obj_arrow _ -> true | _ -> false);
  (fun x -> match x with Obj_atomic_term _ -> true | _ -> false);
  (fun x -> match x with Obj_atomic_type _ -> true | _ -> false);
  (fun x -> match x with Obj_comma_ids _ -> true | _ -> false);
  (fun x -> match x with Obj_comma_ids_or_sym _ -> true | _ -> false);
  (fun x -> match x with Obj_composition_argument _ -> true | _ -> false);
  (fun x -> match x with Obj_data _ -> true | _ -> false);
  (fun x -> match x with Obj_dypgen__early_action_0 _ -> true | _ -> false);
  (fun x -> match x with Obj_dypgen__early_action_1 _ -> true | _ -> false);
  (fun x -> match x with Obj_dypgen__early_action_2 _ -> true | _ -> false);
  (fun x -> match x with Obj_dypgen__early_action_3 _ -> true | _ -> false);
  (fun x -> match x with Obj_dypgen__early_action_4 _ -> true | _ -> false);
  (fun x -> match x with Obj_dypgen__early_action_5 _ -> true | _ -> false);
  (fun x -> match x with Obj_dypgen__early_action_6 _ -> true | _ -> false);
  (fun x -> match x with Obj_dypgen__early_action_7 _ -> true | _ -> false);
  (fun x -> match x with Obj_dypgen__early_action_8 _ -> true | _ -> false);
  (fun x -> match x with Obj_dypgen__epsilon _ -> true | _ -> false);
  (fun x -> match x with Obj_heterogenous_term_and_type _ -> true | _ -> false);
  (fun x -> match x with Obj_idents _ -> true | _ -> false);
  (fun x -> match x with Obj_lex_entries _ -> true | _ -> false);
  (fun x -> match x with Obj_lex_entry _ -> true | _ -> false);
  (fun x -> match x with Obj_lex_opening _ -> true | _ -> false);
  (fun x -> match x with Obj_lexicon _ -> true | _ -> false);
  (fun x -> match x with Obj_lexicon_composition _ -> true | _ -> false);
  (fun x -> match x with Obj_sig_entries _ -> true | _ -> false);
  (fun x -> match x with Obj_sig_entry _ -> true | _ -> false);
  (fun x -> match x with Obj_sig_ident _ -> true | _ -> false);
  (fun x -> match x with Obj_signature _ -> true | _ -> false);
  (fun x -> match x with Obj_term _ -> true | _ -> false);
  (fun x -> match x with Obj_term_alone _ -> true | _ -> false);
  (fun x -> match x with Obj_term_dec_start _ -> true | _ -> false);
  (fun x -> match x with Obj_term_declaration _ -> true | _ -> false);
  (fun x -> match x with Obj_term_def_start _ -> true | _ -> false);
  (fun x -> match x with Obj_term_definition _ -> true | _ -> false);
  (fun x -> match x with Obj_type_declaration _ -> true | _ -> false);
  (fun x -> match x with Obj_type_definition _ -> true | _ -> false);
  (fun x -> match x with Obj_type_expression _ -> true | _ -> false)|]

let __dypgen_dummy_marker_2 = ()
let pp () = Dyp.make_parser
  __dypgen_ra_list Dyp_priority_data.relations global_data local_data
  (Dyp.Tools.make_nt_cons_map Dyp_symbols_array.nt_cons_list)
  Dyp_symbols_array.entry_points
  
  false 23 true
  
  Dyp_aux_functions.get_token_value
  Dyp_symbols.get_token_name Dyp_symbols.str_token
  global_data_equal local_data_equal (__dypgen_test_cons ())
  Dyp_symbols_array.str_cons
  Dyp_symbols_array.cons_array Dyp_aux_functions.cons_table
  (Dyp.Tools.array_of_list __dypgen_merge_list)
  dypgen_lexbuf_position __dypgen_regexp_decl __dypgen_main_lexer
  __dypgen_aux_lexer Dyp_symbols.ter_string_list
  (fun lexbuf -> Lexeme_matched (Dyp.lexeme lexbuf))
  false


let __dypgen_dummy_marker_5 = ()

let __dypgen_dummy_marker_3 = ()

let type_expression ?(global_data=global_data) ?(local_data=local_data) f lexbuf =
  let pf = Dyp.parse (pp ()) "type_expression" ~global_data:global_data
    ~local_data:local_data ~match_len:dypgen_match_length
    ~keep_data:dypgen_keep_data
    ~use_rule_order:dypgen_use_rule_order
    ~use_all_actions:dypgen_use_all_actions
    ~lexpos:dypgen_lexbuf_position f lexbuf in
  let aux1 (o,p) = match o with
    | Obj_type_expression r -> (r,p)
    | _ -> failwith "Wrong type for entry result" in
  List.map aux1 pf

let term ?(global_data=global_data) ?(local_data=local_data) f lexbuf =
  let pf = Dyp.parse (pp ()) "term" ~global_data:global_data
    ~local_data:local_data ~match_len:dypgen_match_length
    ~keep_data:dypgen_keep_data
    ~use_rule_order:dypgen_use_rule_order
    ~use_all_actions:dypgen_use_all_actions
    ~lexpos:dypgen_lexbuf_position f lexbuf in
  let aux1 (o,p) = match o with
    | Obj_term r -> (r,p)
    | _ -> failwith "Wrong type for entry result" in
  List.map aux1 pf

let heterogenous_term_and_type ?(global_data=global_data) ?(local_data=local_data) f lexbuf =
  let pf = Dyp.parse (pp ()) "heterogenous_term_and_type" ~global_data:global_data
    ~local_data:local_data ~match_len:dypgen_match_length
    ~keep_data:dypgen_keep_data
    ~use_rule_order:dypgen_use_rule_order
    ~use_all_actions:dypgen_use_all_actions
    ~lexpos:dypgen_lexbuf_position f lexbuf in
  let aux1 (o,p) = match o with
    | Obj_heterogenous_term_and_type r -> (r,p)
    | _ -> failwith "Wrong type for entry result" in
  List.map aux1 pf

let term_alone ?(global_data=global_data) ?(local_data=local_data) f lexbuf =
  let pf = Dyp.parse (pp ()) "term_alone" ~global_data:global_data
    ~local_data:local_data ~match_len:dypgen_match_length
    ~keep_data:dypgen_keep_data
    ~use_rule_order:dypgen_use_rule_order
    ~use_all_actions:dypgen_use_all_actions
    ~lexpos:dypgen_lexbuf_position f lexbuf in
  let aux1 (o,p) = match o with
    | Obj_term_alone r -> (r,p)
    | _ -> failwith "Wrong type for entry result" in
  List.map aux1 pf

let lex_entry ?(global_data=global_data) ?(local_data=local_data) f lexbuf =
  let pf = Dyp.parse (pp ()) "lex_entry" ~global_data:global_data
    ~local_data:local_data ~match_len:dypgen_match_length
    ~keep_data:dypgen_keep_data
    ~use_rule_order:dypgen_use_rule_order
    ~use_all_actions:dypgen_use_all_actions
    ~lexpos:dypgen_lexbuf_position f lexbuf in
  let aux1 (o,p) = match o with
    | Obj_lex_entry r -> (r,p)
    | _ -> failwith "Wrong type for entry result" in
  List.map aux1 pf

let sig_entry ?(global_data=global_data) ?(local_data=local_data) f lexbuf =
  let pf = Dyp.parse (pp ()) "sig_entry" ~global_data:global_data
    ~local_data:local_data ~match_len:dypgen_match_length
    ~keep_data:dypgen_keep_data
    ~use_rule_order:dypgen_use_rule_order
    ~use_all_actions:dypgen_use_all_actions
    ~lexpos:dypgen_lexbuf_position f lexbuf in
  let aux1 (o,p) = match o with
    | Obj_sig_entry r -> (r,p)
    | _ -> failwith "Wrong type for entry result" in
  List.map aux1 pf

let data ?(global_data=global_data) ?(local_data=local_data) f lexbuf =
  let pf = Dyp.parse (pp ()) "data" ~global_data:global_data
    ~local_data:local_data ~match_len:dypgen_match_length
    ~keep_data:dypgen_keep_data
    ~use_rule_order:dypgen_use_rule_order
    ~use_all_actions:dypgen_use_all_actions
    ~lexpos:dypgen_lexbuf_position f lexbuf in
  let aux1 (o,p) = match o with
    | Obj_data r -> (r,p)
    | _ -> failwith "Wrong type for entry result" in
  List.map aux1 pf


let __dypgen_dummy_marker_4 = ()


# 541 "data_parser.dyp"


  let parse_data ?(override=false) ?(output=false) filename includes env =
    try
      let in_ch =
	let fullname = Utils.find_file filename includes  in
	  open_in fullname in
      let lexbuf = Lexing.from_channel in_ch in
      let actual_env = if env=E.empty then None else Some (Env env) in
      let () = Printf.printf "Parsing \"%s\"...\n%!" filename in
      let () = Data_lexer.set_to_data () in
      let e = 
	try (fst (List.hd (data ~global_data:override ~local_data:actual_env Data_lexer.lexer lexbuf))) with
	  |  Dyp.Syntax_error -> raise (Error.dyp_error lexbuf filename) in
      let () = Printf.printf "Done.\n%!" in
      let () = match output with
	| false -> ()
	| true ->
	    E.iter 
	      (function 
		 | E.Signature sg -> 
		     let () = Printf.printf "%s\n%!" (E.Signature1.to_string sg) in
		       Printf.printf "%s\n%!" (Error.warnings_to_string filename (E.Signature1.get_warnings sg))
		 | E.Lexicon lex ->
		     Printf.printf "%s\n%!" (E.Lexicon.to_string lex))
	      e in
	Some e
    with
      | Utils.No_file(f,msg) -> let e =  Error.System_error (Printf.sprintf "No such file \"%s\" in %s" f msg) in 
	let () = Printf.fprintf stderr "Error: %s\n%!" (Error.error_msg e filename) in None
      | Sys_error s -> let e = Error.System_error s in
	let () = Printf.fprintf stderr "Error: %s\n%!" (Error.error_msg e filename) in None
      | Error.Error e -> 
	  let () = Printf.fprintf stderr "Error: %s\n%!" (Error.error_msg e filename) in
	  None
	      
let parse_term ?(offset="") ?(output=false) t sg = 
  let lexbuf = Lexing.from_string t in
  try 
    let () = Data_lexer.set_to_term () in
    let abs_term,abs_type = 
      try fst (List.hd(term_alone ~global_data:false ~local_data:(Some (Signature sg)) Data_lexer.lexer lexbuf)) with
      | Dyp.Syntax_error -> raise (Error.dyp_error lexbuf "stdin") in
    let () = match output with
      | true -> let () = Printf.printf "%s : %s\n%!" (E.Signature1.term_to_string abs_term sg) (E.Signature1.type_to_string abs_type sg) in
		Printf.printf "%s : %s \n%!" (E.Signature1.term_to_string (E.Signature1.unfold abs_term sg) sg) (E.Signature1.type_to_string abs_type sg) 
      | false -> () in
    Some (abs_term,abs_type)
  with
  | Error.Error er -> 
    let s,e = Error.get_loc_error er in
    let s',e' = s.Lexing.pos_cnum - s.Lexing.pos_bol,e.Lexing.pos_cnum - e.Lexing.pos_bol in
    let () = Printf.fprintf 
      stderr
      "%s\n%s%s%s\nError: %s\n%!"
      t
      offset
      (String.make s' ' ') 
      (String.make (e'-s') '^')
      (Error.error_msg er "stdin") in
    None
  | End_of_file -> None



let parse_heterogenous_term ?(offset="") ?(output=false) t lex = 
  let lexbuf = Lexing.from_string t in
  let abs,obj=E.Lexicon.get_sig lex in
  try 
    let () = Data_lexer.set_to_term () in
    let obj_term,abs_type = 
      try fst (List.hd(heterogenous_term_and_type ~global_data:false ~local_data:(Some (Abs_and_obj (abs,obj))) Data_lexer.lexer lexbuf)) with
      | Dyp.Syntax_error -> raise (Error.dyp_error lexbuf "stdin") in
    let abs_type=E.Signature1.convert_type abs_type abs in
    let obj_type=E.Lexicon.interpret_type abs_type lex in
    let obj_term=E.Signature1.typecheck obj_term obj_type obj in
    let () = match output with
      | true -> let () = Printf.printf "%s : %s (as image of %s)\n%!" (E.Signature1.term_to_string obj_term obj) (E.Signature1.type_to_string obj_type obj) (E.Signature1.type_to_string abs_type abs) in
		Printf.printf "%s : %s (as image of %s)\n%!" (E.Signature1.term_to_string (E.Signature1.unfold obj_term obj) obj) (E.Signature1.type_to_string obj_type obj) (E.Signature1.type_to_string abs_type abs)
      | false -> () in
    Some (obj_term,abs_type)
  with
  | Error.Error er -> 
    let s,e = Error.get_loc_error er in
    let s',e' = s.Lexing.pos_cnum - s.Lexing.pos_bol,e.Lexing.pos_cnum - e.Lexing.pos_bol in
    let () = Printf.fprintf 
      stderr
      "%s\n%s%s%s\nError: %s\n%!"
      t
      offset
      (String.make s' ' ') 
      (String.make (e'-s') '^')
      (Error.error_msg er "stdin") in
    None
  | End_of_file -> None




    
    
	    
  let parse_sig_entry ?(offset="") t sg = 
    let lexbuf = Lexing.from_string t in
      try 
	let () = Data_lexer.set_to_sig_entry () in
	  try Some ((fst (List.hd(sig_entry ~global_data:false ~local_data:(Some (Signature sg)) Data_lexer.lexer lexbuf))) sg) with
	    | Dyp.Syntax_error -> raise (Error.dyp_error lexbuf "stdin")
      with
	| Error.Error er -> 
	    let s,e = Error.get_loc_error er in
	    let s',e' = s.Lexing.pos_cnum - s.Lexing.pos_bol,e.Lexing.pos_cnum - e.Lexing.pos_bol in
	    let () = Printf.fprintf 
	      stderr
	      "%s\n%s%s%s\nError: %s\n%!"
	      t
	      offset
	      (String.make s' ' ') 
	      (String.make (e'-s') '^')
	      (Error.error_msg er "stdin") in
	      None
	| End_of_file -> None


  let parse_lex_entry ?(offset="") t lex = 
    let lexbuf = Lexing.from_string t in
      try 
	let () = Data_lexer.set_to_lex_entry () in
	  try Some ((fst (List.hd(lex_entry ~global_data:false ~local_data:(Some (Abs_and_obj (E.Lexicon.get_sig lex))) Data_lexer.lexer lexbuf))) lex) with
	    | Dyp.Syntax_error -> raise (Error.dyp_error lexbuf "stdin")
      with
	| Error.Error er -> 
	    let s,e = Error.get_loc_error er in
	    let s',e' = s.Lexing.pos_cnum - s.Lexing.pos_bol,e.Lexing.pos_cnum - e.Lexing.pos_bol in
	    let () = Printf.fprintf 
	      stderr
	      "%s\n%s%s%s\nError: %s\n%!"
	      t
	      offset
	      (String.make s' ' ') 
	      (String.make (e'-s') '^')
	      (Error.error_msg er "stdin") in
	      None
	| End_of_file -> None

    


end
let _ = () (* dummy line to improve OCaml error location *)
# 3508               "data_parser_temp.ml"
