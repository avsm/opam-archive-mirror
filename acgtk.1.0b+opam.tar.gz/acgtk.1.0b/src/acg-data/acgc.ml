(**************************************************************************)
(*                                                                        *)
(*                 ACG development toolkit                                *)
(*                                                                        *)
(*                  Copyright 2008 INRIA                                  *)
(*                                                                        *)
(*  More information on "http://acg.gforge.inria.fr/"                     *)
(*  License: CeCILL, see the LICENSE file or "http://www.cecill.info"     *)
(*  Authors: see the AUTHORS file                                         *)
(*                                                                        *)
(*                                                                        *)
(*                                                                        *)
(*                                                                        *)
(*  $Rev:: 491                          $:  Revision of last commit       *)
(*  $Author:: pogodall                  $:  Author of last commit         *)
(*  $Date:: 2014-02-09 08:41:31 +0100 (#$:  Date of last commit           *)
(*                                                                        *)
(**************************************************************************)

module Sg = Signature.Sylvains_signature
(*module Lex = Syntactic_data_structures.Abstract_lex*)
module Lex = Acg_lexicon.Sylvain_lexicon

module Test = Interactive.Make(Lex)


Test.main ()
