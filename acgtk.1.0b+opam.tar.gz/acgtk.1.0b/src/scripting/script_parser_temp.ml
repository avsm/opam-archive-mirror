
# 20 "script_parser.dyp"
      
  open Script_lexer
  let id = fun x -> x
    
  let pr s = Printf.printf "%s\n%!" s
    
  module Make (E:Environment.Environment_sig) =
  struct  
    module F = Functions.Make(E)
      
  
let _ = () (* dummy line to improve OCaml error location *)
# 16                 "script_parser_temp.ml"
let _ =
  if "20120619" <> Dyp.version
  then (Printf.fprintf stderr
    "version mismatch, dypgen version 20120619 and dyplib version %s\n" Dyp.version;
  exit 2)

module Dyp_symbols =
struct
  let get_token_name t = match t with
    | ADD _ -> 0
    | ANALYSE _ -> 1
    | AS -> 2
    | CHECK _ -> 3
    | COMPOSE -> 4
    | CREATE_HELP -> 5
    | CREATE_LEX -> 6
    | CREATE_SIG -> 7
    | DONT -> 8
    | EOII -> 9
    | HELP -> 10
    | IDB _ -> 11
    | IDENTT _ -> 12
    | LIST -> 13
    | LOAD_DATA _ -> 14
    | LOAD_HELP -> 15
    | LOAD_OBJECT _ -> 16
    | LOAD_SCRIPT _ -> 17
    | PARSE _ -> 18
    | PRINT _ -> 19
    | QUERY _ -> 20
    | REALIZE _ -> 21
    | SAVE _ -> 22
    | SELECT -> 23
    | SEMICOLONN _ -> 24
    | TRACE -> 25
    | UNSELECT -> 26
    | WAIT -> 27
  let str_token t = match t with
    | ADD _ -> "ADD"
    | ANALYSE _ -> "ANALYSE"
    | AS -> "AS"
    | CHECK _ -> "CHECK"
    | COMPOSE -> "COMPOSE"
    | CREATE_HELP -> "CREATE_HELP"
    | CREATE_LEX -> "CREATE_LEX"
    | CREATE_SIG -> "CREATE_SIG"
    | DONT -> "DONT"
    | EOII -> "EOII"
    | HELP -> "HELP"
    | IDB _ -> "IDB"
    | IDENTT _ -> "IDENTT"
    | LIST -> "LIST"
    | LOAD_DATA _ -> "LOAD_DATA"
    | LOAD_HELP -> "LOAD_HELP"
    | LOAD_OBJECT _ -> "LOAD_OBJECT"
    | LOAD_SCRIPT _ -> "LOAD_SCRIPT"
    | PARSE _ -> "PARSE"
    | PRINT _ -> "PRINT"
    | QUERY _ -> "QUERY"
    | REALIZE _ -> "REALIZE"
    | SAVE _ -> "SAVE"
    | SELECT -> "SELECT"
    | SEMICOLONN _ -> "SEMICOLONN"
    | TRACE -> "TRACE"
    | UNSELECT -> "UNSELECT"
    | WAIT -> "WAIT"
  let ter_string_list = [
      ("ADD",0);
      ("ANALYSE",1);
      ("AS",2);
      ("CHECK",3);
      ("COMPOSE",4);
      ("CREATE_HELP",5);
      ("CREATE_LEX",6);
      ("CREATE_SIG",7);
      ("DONT",8);
      ("EOII",9);
      ("HELP",10);
      ("IDB",11);
      ("IDENTT",12);
      ("LIST",13);
      ("LOAD_DATA",14);
      ("LOAD_HELP",15);
      ("LOAD_OBJECT",16);
      ("LOAD_SCRIPT",17);
      ("PARSE",18);
      ("PRINT",19);
      ("QUERY",20);
      ("REALIZE",21);
      ("SAVE",22);
      ("SELECT",23);
      ("SEMICOLONN",24);
      ("TRACE",25);
      ("UNSELECT",26);
      ("WAIT",27);]
end

type ('dypgen__Inh_dypgen__early_action_0, 'dypgen__Obj_all_commands, 'dypgen__Obj_command, 'dypgen__Obj_dypgen__early_action_0, 'dypgen__Obj_dypgen__epsilon, 'dypgen__Obj_optional_ident, 'dypgen__Obj_optional_idents) obj =
  | Inh_dypgen__early_action_0 of 'dypgen__Inh_dypgen__early_action_0
  | Lexeme_matched of string
  | Obj_ADD of ((string*Abstract_syntax.Abstract_syntax.location*string))
  | Obj_ANALYSE of ((string*Abstract_syntax.Abstract_syntax.location*string))
  | Obj_AS
  | Obj_CHECK of ((string*Abstract_syntax.Abstract_syntax.location*string))
  | Obj_COMPOSE
  | Obj_CREATE_HELP
  | Obj_CREATE_LEX
  | Obj_CREATE_SIG
  | Obj_DONT
  | Obj_EOII
  | Obj_HELP
  | Obj_IDB of (Abstract_syntax.Abstract_syntax.location)
  | Obj_IDENTT of ((string*Abstract_syntax.Abstract_syntax.location))
  | Obj_LIST
  | Obj_LOAD_DATA of ((string*Abstract_syntax.Abstract_syntax.location*string))
  | Obj_LOAD_HELP
  | Obj_LOAD_OBJECT of ((string*Abstract_syntax.Abstract_syntax.location*string))
  | Obj_LOAD_SCRIPT of ((string*Abstract_syntax.Abstract_syntax.location*string))
  | Obj_PARSE of ((string*Abstract_syntax.Abstract_syntax.location*string))
  | Obj_PRINT of (Abstract_syntax.Abstract_syntax.location)
  | Obj_QUERY of ((string*Abstract_syntax.Abstract_syntax.location*string))
  | Obj_REALIZE of ((string*Abstract_syntax.Abstract_syntax.location*string))
  | Obj_SAVE of ((string*Abstract_syntax.Abstract_syntax.location*string))
  | Obj_SELECT
  | Obj_SEMICOLONN of (string)
  | Obj_TRACE
  | Obj_UNSELECT
  | Obj_WAIT
  | Obj_all_commands of 'dypgen__Obj_all_commands
  | Obj_command of 'dypgen__Obj_command
  | Obj_dypgen__early_action_0 of 'dypgen__Obj_dypgen__early_action_0
  | Obj_dypgen__epsilon of 'dypgen__Obj_dypgen__epsilon
  | Obj_optional_ident of 'dypgen__Obj_optional_ident
  | Obj_optional_idents of 'dypgen__Obj_optional_idents
  | Obj_zzcommands of ((E.t))

module Dyp_symbols_array =
struct
  let token_name_array =
  [|"ADD";
    "ANALYSE";
    "AS";
    "CHECK";
    "COMPOSE";
    "CREATE_HELP";
    "CREATE_LEX";
    "CREATE_SIG";
    "DONT";
    "EOII";
    "HELP";
    "IDB";
    "IDENTT";
    "LIST";
    "LOAD_DATA";
    "LOAD_HELP";
    "LOAD_OBJECT";
    "LOAD_SCRIPT";
    "PARSE";
    "PRINT";
    "QUERY";
    "REALIZE";
    "SAVE";
    "SELECT";
    "SEMICOLONN";
    "TRACE";
    "UNSELECT";
    "WAIT"|]
  let nt_cons_list =
  [
    ("0_1",19);
    ("all_commands",16);
    ("command",17);
    ("dypgen__early_action_0",18);
    ("optional_ident",20);
    ("optional_idents",21);
    ("zzcommands",22)]
  let str_cons o = match o with
    | Inh_dypgen__early_action_0 _ -> "Inh_dypgen__early_action_0"
    | Lexeme_matched _ -> "Lexeme_matched"
    | Obj_ADD _ -> "Obj_ADD"
    | Obj_ANALYSE _ -> "Obj_ANALYSE"
    | Obj_CHECK _ -> "Obj_CHECK"
    | Obj_IDB _ -> "Obj_IDB"
    | Obj_IDENTT _ -> "Obj_IDENTT"
    | Obj_LOAD_DATA _ -> "Obj_LOAD_DATA"
    | Obj_LOAD_OBJECT _ -> "Obj_LOAD_OBJECT"
    | Obj_LOAD_SCRIPT _ -> "Obj_LOAD_SCRIPT"
    | Obj_PARSE _ -> "Obj_PARSE"
    | Obj_PRINT _ -> "Obj_PRINT"
    | Obj_QUERY _ -> "Obj_QUERY"
    | Obj_REALIZE _ -> "Obj_REALIZE"
    | Obj_SAVE _ -> "Obj_SAVE"
    | Obj_SEMICOLONN _ -> "Obj_SEMICOLONN"
    | Obj_all_commands _ -> "Obj_all_commands"
    | Obj_command _ -> "Obj_command"
    | Obj_dypgen__early_action_0 _ -> "Obj_dypgen__early_action_0"
    | Obj_dypgen__epsilon _ -> "Obj_dypgen__epsilon"
    | Obj_optional_ident _ -> "Obj_optional_ident"
    | Obj_optional_idents _ -> "Obj_optional_idents"
    | Obj_zzcommands _ -> "Obj_zzcommands"
    | _ -> failwith "str_cons, unexpected constructor"
  let cons_array = [|
    "Inh_dypgen__early_action_0";
    "Lexeme_matched";
    "Obj_ADD";
    "Obj_ANALYSE";
    "Obj_CHECK";
    "Obj_IDB";
    "Obj_IDENTT";
    "Obj_LOAD_DATA";
    "Obj_LOAD_OBJECT";
    "Obj_LOAD_SCRIPT";
    "Obj_PARSE";
    "Obj_PRINT";
    "Obj_QUERY";
    "Obj_REALIZE";
    "Obj_SAVE";
    "Obj_SEMICOLONN";
    "Obj_all_commands";
    "Obj_command";
    "Obj_dypgen__early_action_0";
    "Obj_dypgen__epsilon";
    "Obj_optional_ident";
    "Obj_optional_idents";
    "Obj_zzcommands";
    "";
    "";
    "";
    "";
    "";
    "";
    "";
    "";
    "";
    "";
    "";
    "";
    "";
    "";
  |]
  let entry_points = [
    "zzcommands";]
end

let dypgen_lexbuf_position lexbuf =
  (lexbuf.Lexing.lex_start_p,lexbuf.Lexing.lex_curr_p)

module Dyp_aux_functions =
struct
  let get_token_value t = match t with
    | ADD x -> Obj_ADD x
    | ANALYSE x -> Obj_ANALYSE x
    | AS -> Obj_AS
    | CHECK x -> Obj_CHECK x
    | COMPOSE -> Obj_COMPOSE
    | CREATE_HELP -> Obj_CREATE_HELP
    | CREATE_LEX -> Obj_CREATE_LEX
    | CREATE_SIG -> Obj_CREATE_SIG
    | DONT -> Obj_DONT
    | EOII -> Obj_EOII
    | HELP -> Obj_HELP
    | IDB x -> Obj_IDB x
    | IDENTT x -> Obj_IDENTT x
    | LIST -> Obj_LIST
    | LOAD_DATA x -> Obj_LOAD_DATA x
    | LOAD_HELP -> Obj_LOAD_HELP
    | LOAD_OBJECT x -> Obj_LOAD_OBJECT x
    | LOAD_SCRIPT x -> Obj_LOAD_SCRIPT x
    | PARSE x -> Obj_PARSE x
    | PRINT x -> Obj_PRINT x
    | QUERY x -> Obj_QUERY x
    | REALIZE x -> Obj_REALIZE x
    | SAVE x -> Obj_SAVE x
    | SELECT -> Obj_SELECT
    | SEMICOLONN x -> Obj_SEMICOLONN x
    | TRACE -> Obj_TRACE
    | UNSELECT -> Obj_UNSELECT
    | WAIT -> Obj_WAIT
  let cons_table = Dyp.Tools.hashtbl_of_array Dyp_symbols_array.cons_array
end

module Dyp_priority_data =
struct
  let relations = [
  ]
end

let global_data = ()
let local_data = ()
let global_data_equal = (==)
let local_data_equal = (==)

let dyp_merge_Inh_dypgen__early_action_0 = Dyp.Tools.keep_zero
let dyp_merge_Lexeme_matched = Dyp.Tools.keep_zero
let dyp_merge_Obj_ADD = Dyp.Tools.keep_zero
let dyp_merge_Obj_ANALYSE = Dyp.Tools.keep_zero
let dyp_merge_Obj_CHECK = Dyp.Tools.keep_zero
let dyp_merge_Obj_IDB = Dyp.Tools.keep_zero
let dyp_merge_Obj_IDENTT = Dyp.Tools.keep_zero
let dyp_merge_Obj_LOAD_DATA = Dyp.Tools.keep_zero
let dyp_merge_Obj_LOAD_OBJECT = Dyp.Tools.keep_zero
let dyp_merge_Obj_LOAD_SCRIPT = Dyp.Tools.keep_zero
let dyp_merge_Obj_PARSE = Dyp.Tools.keep_zero
let dyp_merge_Obj_PRINT = Dyp.Tools.keep_zero
let dyp_merge_Obj_QUERY = Dyp.Tools.keep_zero
let dyp_merge_Obj_REALIZE = Dyp.Tools.keep_zero
let dyp_merge_Obj_SAVE = Dyp.Tools.keep_zero
let dyp_merge_Obj_SEMICOLONN = Dyp.Tools.keep_zero
let dyp_merge_Obj_all_commands = Dyp.Tools.keep_zero
let dyp_merge_Obj_command = Dyp.Tools.keep_zero
let dyp_merge_Obj_dypgen__early_action_0 = Dyp.Tools.keep_zero
let dyp_merge_Obj_dypgen__epsilon = Dyp.Tools.keep_zero
let dyp_merge_Obj_optional_ident = Dyp.Tools.keep_zero
let dyp_merge_Obj_optional_idents = Dyp.Tools.keep_zero
let dyp_merge_Obj_zzcommands = Dyp.Tools.keep_zero
let dyp_merge = Dyp.keep_one
let dypgen_match_length = `shortest
let dypgen_choose_token = `first
let dypgen_keep_data = `both
let dypgen_use_rule_order = false
let dypgen_use_all_actions = false

# 32 "script_parser.dyp"
  
    open Dyp
    let local_data = (E.empty,fun _ -> failwith "Bug: Not yet defined")
      (* for global_data, the first projection describe whether when
	 executing a script, the interpreter should wait between two
	 commands. The second projection is used to specify whether to
	 echo the current command. The third projection correspond to
	 the include dirs. *)
    let global_data = false,true,[""]

    let echo ((_:bool),b,(_:string list)) s = if b then Printf.printf "%s\n%!" s else ()
    let wait  (b,(_:bool),(_:string list)) f = 
      if b then ignore (f () )
  
let _ = () (* dummy line to improve OCaml error location *)
# 355                "script_parser_temp.ml"
let __dypgen_ra_list, __dypgen_main_lexer, __dypgen_aux_lexer =
[
(("zzcommands",[Dyp.Ter "EOII"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [ _1] ->  let res = 
# 84 "script_parser.dyp"
(
       (let e,f = dyp.last_local_data in
	   (e,[Local_data (e,f)])):((E.t)) * ('t,'obj,'gd,'ld,'l) Dyp.dyp_action list)
# 365                "script_parser_temp.ml"
  in Obj_zzcommands(fst res), snd res
 | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("zzcommands",[Dyp.Non_ter ("0_1",Dyp.No_priority );Dyp.Non_ter ("command",Dyp.No_priority );Dyp.Non_ter ("dypgen__early_action_0",Dyp.No_priority );Dyp.Non_ter ("zzcommands",Dyp.No_priority )],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_command ( (
# 87 "script_parser.dyp"
         (c:'dypgen__Obj_command)
# 375                "script_parser_temp.ml"
 as _1));Obj_dypgen__early_action_0 ( (
(_:'dypgen__Obj_dypgen__early_action_0)
# 378                "script_parser_temp.ml"
 as _2));Obj_zzcommands ( (
(_:'dypgen__Obj_zzcommands)
# 381                "script_parser_temp.ml"
 as _3))] ->  let res = 
# 103 "script_parser.dyp"
(
                 (let e,f = (dyp.last_local_data) in e,[Local_data (e,f)]):((E.t)) * ('t,'obj,'gd,'ld,'l) Dyp.dyp_action list)
# 386                "script_parser_temp.ml"
  in Obj_zzcommands(fst res), snd res
 | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[3,
(fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_inh_val (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_command ( (
# 87 "script_parser.dyp"
         (c:'dypgen__Obj_command)
# 394                "script_parser_temp.ml"
 as _1))] -> Inh_dypgen__early_action_0 
(
((_1)):'dypgen__Inh_dypgen__early_action_0)
# 398                "script_parser_temp.ml"
 | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl)])
;
(("dypgen__early_action_0",[],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Inh_dypgen__early_action_0( (
# 87 "script_parser.dyp"
         (c:'dypgen__Obj_command)
# 406                "script_parser_temp.ml"
 as _1))] ->  let res = 
# 86 "script_parser.dyp"
(
                (let e,f = (dyp.last_local_data) in
		  let e' = 
		    try
		      c e
		    with
		      | F.Not_yet_implemented s-> raise (Scripting_errors.Error (Scripting_errors.Not_yet_implemented s,(Lexing.dummy_pos,Lexing.dummy_pos)))
		      | Scripting_errors.Error (er,loc_er) ->
			  let () = Printf.fprintf stderr "Error: %s\n%!" (Scripting_errors.error_msg er loc_er) in
			  let _ = Script_lexer.reset_echo () in
			    e
		  in
		    try
		      let () = wait dyp.global_data read_line in
			(e',[Local_data (e',f)])
		    with
		      | Sys.Break 
		      | End_of_file -> raise F.Stop ):'dypgen__Obj_dypgen__early_action_0 * ('t,'obj,'gd,'ld,'l) Dyp.dyp_action list)
# 427                "script_parser_temp.ml"
  in Obj_dypgen__early_action_0(fst res), snd res
 | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("command",[Dyp.Ter "WAIT";Dyp.Ter "SEMICOLONN"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [ _1;Obj_SEMICOLONN  (
# 108 "script_parser.dyp"
                 (l:(string))
# 437                "script_parser_temp.ml"
 as _2)] ->  let res = 
# 107 "script_parser.dyp"
(
                     (let g_d1,g_d2,g_d3 = dyp.global_data in
			 (fun e -> let () = echo dyp.global_data l in let () = F.wait () in e),[Global_data (true,g_d2,g_d3)]):'dypgen__Obj_command * ('t,'obj,'gd,'ld,'l) Dyp.dyp_action list)
# 443                "script_parser_temp.ml"
  in Obj_command(fst res), snd res
 | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("command",[Dyp.Ter "DONT";Dyp.Ter "WAIT";Dyp.Ter "SEMICOLONN"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [ _1; _2;Obj_SEMICOLONN  (
# 110 "script_parser.dyp"
                      (l:(string))
# 453                "script_parser_temp.ml"
 as _3)] ->  let res = 
# 109 "script_parser.dyp"
(
                          (let g_d1,g_d2,g_d3 = dyp.global_data in
			      (fun e ->  let () = echo dyp.global_data l in let () = F.dont_wait () in e),[Global_data (false,g_d2,g_d3)]):'dypgen__Obj_command * ('t,'obj,'gd,'ld,'l) Dyp.dyp_action list)
# 459                "script_parser_temp.ml"
  in Obj_command(fst res), snd res
 | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("command",[Dyp.Ter "LOAD_DATA"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_LOAD_DATA  (
# 112 "script_parser.dyp"
           (s,loc,l:((string*Abstract_syntax.Abstract_syntax.location*string)))
# 469                "script_parser_temp.ml"
 as _1)] -> Obj_command 
# 111 "script_parser.dyp"
(
                      (fun e ->  let () = echo dyp.global_data l in
			 let _,_,incl = dyp.global_data in
			   F.load F.Data  s  incl e):'dypgen__Obj_command)
# 476                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("command",[Dyp.Ter "LOAD_OBJECT"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_LOAD_OBJECT  (
# 115 "script_parser.dyp"
             (s,loc,l:((string*Abstract_syntax.Abstract_syntax.location*string)))
# 485                "script_parser_temp.ml"
 as _1)] -> Obj_command 
# 114 "script_parser.dyp"
(
                        (fun e ->  let () = echo dyp.global_data l in
			 let _,_,incl = dyp.global_data in
			   F.load F.Object s incl e):'dypgen__Obj_command)
# 492                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("command",[Dyp.Ter "LOAD_SCRIPT"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_LOAD_SCRIPT  (
# 118 "script_parser.dyp"
             (s,loc,l:((string*Abstract_syntax.Abstract_syntax.location*string)))
# 501                "script_parser_temp.ml"
 as _1)] -> Obj_command 
# 117 "script_parser.dyp"
(
                        (fun e ->  let () = echo dyp.global_data l in
			   let _,_,includes = dyp.global_data in
			   let new_env = F.load (F.Script (snd dyp.last_local_data)) s includes e in
			     new_env):'dypgen__Obj_command)
# 509                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("command",[Dyp.Ter "LIST";Dyp.Ter "SEMICOLONN"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [ _1;Obj_SEMICOLONN  (
# 122 "script_parser.dyp"
                 (l:(string))
# 518                "script_parser_temp.ml"
 as _2)] -> Obj_command 
# 121 "script_parser.dyp"
(
                     (fun e ->  let () = echo dyp.global_data l in let () = F.list e in e):'dypgen__Obj_command)
# 523                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("command",[Dyp.Ter "SELECT";Dyp.Ter "IDENTT";Dyp.Ter "SEMICOLONN"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [ _1;Obj_IDENTT  (
# 123 "script_parser.dyp"
               (name,loc:((string*Abstract_syntax.Abstract_syntax.location)))
# 532                "script_parser_temp.ml"
 as _2);Obj_SEMICOLONN  (
# 123 "script_parser.dyp"
                                     (l:(string))
# 536                "script_parser_temp.ml"
 as _3)] -> Obj_command 
# 122 "script_parser.dyp"
(
                                         (fun e ->  let () = echo dyp.global_data l in F.select name loc e):'dypgen__Obj_command)
# 541                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("command",[Dyp.Ter "UNSELECT";Dyp.Ter "SEMICOLONN"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [ _1;Obj_SEMICOLONN  (
# 124 "script_parser.dyp"
                     (l:(string))
# 550                "script_parser_temp.ml"
 as _2)] -> Obj_command 
# 123 "script_parser.dyp"
(
                         ( let () = echo dyp.global_data l in F.unselect):'dypgen__Obj_command)
# 555                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("command",[Dyp.Ter "TRACE";Dyp.Ter "SEMICOLONN"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [ _1;Obj_SEMICOLONN  (
# 125 "script_parser.dyp"
                  (l:(string))
# 564                "script_parser_temp.ml"
 as _2)] -> Obj_command 
# 124 "script_parser.dyp"
(
                      ( let () = echo dyp.global_data l in fun e -> let () = F.trace () in e):'dypgen__Obj_command)
# 569                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("command",[Dyp.Ter "DONT";Dyp.Ter "TRACE";Dyp.Ter "SEMICOLONN"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [ _1; _2;Obj_SEMICOLONN  (
# 126 "script_parser.dyp"
                       (l:(string))
# 578                "script_parser_temp.ml"
 as _3)] -> Obj_command 
# 125 "script_parser.dyp"
(
                           ( let () = echo dyp.global_data l in fun e -> let () = F.dont_trace () in e):'dypgen__Obj_command)
# 583                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("command",[Dyp.Non_ter ("optional_ident",Dyp.No_priority );Dyp.Ter "PRINT";Dyp.Ter "SEMICOLONN"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_optional_ident ( (
# 127 "script_parser.dyp"
                (name:'dypgen__Obj_optional_ident)
# 592                "script_parser_temp.ml"
 as _1));Obj_PRINT  (
# 127 "script_parser.dyp"
                            (p:(Abstract_syntax.Abstract_syntax.location))
# 596                "script_parser_temp.ml"
 as _2);Obj_SEMICOLONN  (
# 127 "script_parser.dyp"
                                          (l:(string))
# 600                "script_parser_temp.ml"
 as _3)] -> Obj_command 
# 126 "script_parser.dyp"
(
                                              (
  let () = echo dyp.global_data l in fun e -> 
    let loc = 
      match name with
      | None -> p
      | Some (_,l) -> l in
    match name with
    | None -> let () = F.print e loc in e
    | Some (n,l) -> let () = F.print ~name:n e loc in e):'dypgen__Obj_command)
# 613                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("command",[Dyp.Non_ter ("optional_idents",Dyp.No_priority );Dyp.Ter "ANALYSE"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_optional_idents ( (
# 136 "script_parser.dyp"
                 (names:'dypgen__Obj_optional_idents)
# 622                "script_parser_temp.ml"
 as _1));Obj_ANALYSE  (
# 136 "script_parser.dyp"
                                (t,l,line:((string*Abstract_syntax.Abstract_syntax.location*string)))
# 626                "script_parser_temp.ml"
 as _2)] -> Obj_command 
# 135 "script_parser.dyp"
(
                                             ( let () = echo dyp.global_data line in fun e -> 
					     match names with
					       | [] -> let () = F.analyse e t l in e
					       | _ -> let () = F.analyse  ~names e t l in e):'dypgen__Obj_command)
# 634                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("command",[Dyp.Non_ter ("optional_idents",Dyp.No_priority );Dyp.Ter "CHECK"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_optional_idents ( (
# 140 "script_parser.dyp"
                 (names:'dypgen__Obj_optional_idents)
# 643                "script_parser_temp.ml"
 as _1));Obj_CHECK  (
# 140 "script_parser.dyp"
                              (t,l,line:((string*Abstract_syntax.Abstract_syntax.location*string)))
# 647                "script_parser_temp.ml"
 as _2)] -> Obj_command 
# 139 "script_parser.dyp"
(
                                           ( 
  let () = echo dyp.global_data line in fun e -> 
    match names with
    | [] -> let () = F.check e t l in e
    | _ -> let () = F.check  ~names e t l in e):'dypgen__Obj_command)
# 656                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("command",[Dyp.Non_ter ("optional_idents",Dyp.No_priority );Dyp.Ter "REALIZE"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_optional_idents ( (
# 145 "script_parser.dyp"
                 (names:'dypgen__Obj_optional_idents)
# 665                "script_parser_temp.ml"
 as _1));Obj_REALIZE  (
# 145 "script_parser.dyp"
                                (t,l,line:((string*Abstract_syntax.Abstract_syntax.location*string)))
# 669                "script_parser_temp.ml"
 as _2)] -> Obj_command 
# 144 "script_parser.dyp"
(
                                             ( 
  let () = echo dyp.global_data line in fun e -> 
    match names with
    | [] -> let () = F.realize e t l in e
    | _ -> let () = F.realize  ~names e t l in e):'dypgen__Obj_command)
# 678                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("command",[Dyp.Non_ter ("optional_ident",Dyp.No_priority );Dyp.Ter "PARSE"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_optional_ident ( (
# 150 "script_parser.dyp"
                (name:'dypgen__Obj_optional_ident)
# 687                "script_parser_temp.ml"
 as _1));Obj_PARSE  (
# 150 "script_parser.dyp"
                            (t,l,line:((string*Abstract_syntax.Abstract_syntax.location*string)))
# 691                "script_parser_temp.ml"
 as _2)] -> Obj_command 
# 149 "script_parser.dyp"
(
                                         (
  let () = echo dyp.global_data line in fun e -> 
    match name with
    | None ->  let () = F.parse  e t l in e
    | Some (n,lex_loc) ->  let () = F.parse ~name:n e t lex_loc in e):'dypgen__Obj_command)
# 700                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("command",[Dyp.Non_ter ("optional_ident",Dyp.No_priority );Dyp.Ter "QUERY"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_optional_ident ( (
# 155 "script_parser.dyp"
                (name:'dypgen__Obj_optional_ident)
# 709                "script_parser_temp.ml"
 as _1));Obj_QUERY  (
# 155 "script_parser.dyp"
                            (t,l,line:((string*Abstract_syntax.Abstract_syntax.location*string)))
# 713                "script_parser_temp.ml"
 as _2)] -> Obj_command 
# 154 "script_parser.dyp"
(
                                         (
  let () = echo dyp.global_data line in fun e -> 
    match name with
    | None ->  let () = F.query  e t l in e
    | Some (n,lex_loc) ->  let () = F.query ~name:n e t lex_loc in e):'dypgen__Obj_command)
# 722                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("command",[Dyp.Non_ter ("optional_ident",Dyp.No_priority );Dyp.Ter "IDB";Dyp.Ter "SEMICOLONN"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_optional_ident ( (
# 160 "script_parser.dyp"
                (name:'dypgen__Obj_optional_ident)
# 731                "script_parser_temp.ml"
 as _1));Obj_IDB  (
# 160 "script_parser.dyp"
                          (p:(Abstract_syntax.Abstract_syntax.location))
# 735                "script_parser_temp.ml"
 as _2);Obj_SEMICOLONN  (
# 160 "script_parser.dyp"
                                        (l:(string))
# 739                "script_parser_temp.ml"
 as _3)] -> Obj_command 
# 159 "script_parser.dyp"
(
                                            (
  let () = echo dyp.global_data l in fun e -> 
    let loc = 
      match name with
      | None -> p
      | Some (_,l) -> l in
    match name with
    | None -> let () = F.idb e loc in e
    | Some (n,l) -> let () = F.idb ~name:n e loc in e):'dypgen__Obj_command)
# 752                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("command",[Dyp.Non_ter ("optional_idents",Dyp.No_priority );Dyp.Ter "ADD"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_optional_idents ( (
# 169 "script_parser.dyp"
                 (names:'dypgen__Obj_optional_idents)
# 761                "script_parser_temp.ml"
 as _1));Obj_ADD  (
# 169 "script_parser.dyp"
                            (t,l,line:((string*Abstract_syntax.Abstract_syntax.location*string)))
# 765                "script_parser_temp.ml"
 as _2)] -> Obj_command 
# 168 "script_parser.dyp"
(
                                         ( let () = echo dyp.global_data line in fun e -> 
					     match names with
					       | [] -> F.add e t l
					       | _ -> F.add  ~names e t l):'dypgen__Obj_command)
# 773                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("command",[Dyp.Ter "COMPOSE";Dyp.Ter "IDENTT";Dyp.Ter "IDENTT";Dyp.Ter "AS";Dyp.Ter "IDENTT";Dyp.Ter "SEMICOLONN"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [ _1;Obj_IDENTT  (
# 173 "script_parser.dyp"
                (n1:((string*Abstract_syntax.Abstract_syntax.location)))
# 782                "script_parser_temp.ml"
 as _2);Obj_IDENTT  (
# 173 "script_parser.dyp"
                            (n2:((string*Abstract_syntax.Abstract_syntax.location)))
# 786                "script_parser_temp.ml"
 as _3); _4;Obj_IDENTT  (
# 173 "script_parser.dyp"
                                          (n3:((string*Abstract_syntax.Abstract_syntax.location)))
# 790                "script_parser_temp.ml"
 as _5);Obj_SEMICOLONN  (
# 173 "script_parser.dyp"
                                                         (l:(string))
# 794                "script_parser_temp.ml"
 as _6)] -> Obj_command 
# 172 "script_parser.dyp"
(
                                                             ( let () = echo dyp.global_data l in fun e -> F.compose n1 n2 n3 e):'dypgen__Obj_command)
# 799                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("command",[Dyp.Ter "HELP";Dyp.Ter "SEMICOLONN"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [ _1;Obj_SEMICOLONN  (
# 174 "script_parser.dyp"
                 (l:(string))
# 808                "script_parser_temp.ml"
 as _2)] -> Obj_command 
# 173 "script_parser.dyp"
(
                     (let () = echo dyp.global_data l in fun e -> let () = F.help (F.Help None) in e):'dypgen__Obj_command)
# 813                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("command",[Dyp.Non_ter ("all_commands",Dyp.No_priority );Dyp.Ter "HELP";Dyp.Ter "SEMICOLONN"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_all_commands ( (
# 175 "script_parser.dyp"
              (c:'dypgen__Obj_all_commands)
# 822                "script_parser_temp.ml"
 as _1)); _2;Obj_SEMICOLONN  (
# 175 "script_parser.dyp"
                                 (l:(string))
# 826                "script_parser_temp.ml"
 as _3)] -> Obj_command 
# 174 "script_parser.dyp"
(
                                     (let () = echo dyp.global_data l in fun e -> let () = F.help (F.Help (Some c)) in e):'dypgen__Obj_command)
# 831                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("command",[Dyp.Ter "LOAD_HELP";Dyp.Ter "SEMICOLONN"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [ _1;Obj_SEMICOLONN  (
# 176 "script_parser.dyp"
                      (l:(string))
# 840                "script_parser_temp.ml"
 as _2)] -> Obj_command 
# 175 "script_parser.dyp"
(
                          (let () = echo dyp.global_data l in fun e -> let () = F.help (F.Help (Some F.Load)) in e):'dypgen__Obj_command)
# 845                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("command",[Dyp.Ter "CREATE_SIG";Dyp.Ter "IDENTT";Dyp.Ter "SEMICOLONN"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [ _1;Obj_IDENTT  (
# 177 "script_parser.dyp"
                   (n:((string*Abstract_syntax.Abstract_syntax.location)))
# 854                "script_parser_temp.ml"
 as _2);Obj_SEMICOLONN  (
# 177 "script_parser.dyp"
                                 (l:(string))
# 858                "script_parser_temp.ml"
 as _3)] -> Obj_command 
# 176 "script_parser.dyp"
(
                                     (let () = echo dyp.global_data l in fun e -> F.create_sig n e):'dypgen__Obj_command)
# 863                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("command",[Dyp.Ter "CREATE_LEX";Dyp.Ter "IDENTT";Dyp.Ter "IDENTT";Dyp.Ter "IDENTT";Dyp.Ter "SEMICOLONN"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [ _1;Obj_IDENTT  (
# 178 "script_parser.dyp"
                   (n:((string*Abstract_syntax.Abstract_syntax.location)))
# 872                "script_parser_temp.ml"
 as _2);Obj_IDENTT  (
# 178 "script_parser.dyp"
                             (n1:((string*Abstract_syntax.Abstract_syntax.location)))
# 876                "script_parser_temp.ml"
 as _3);Obj_IDENTT  (
# 178 "script_parser.dyp"
                                        (n2:((string*Abstract_syntax.Abstract_syntax.location)))
# 880                "script_parser_temp.ml"
 as _4);Obj_SEMICOLONN  (
# 178 "script_parser.dyp"
                                                        (l:(string))
# 884                "script_parser_temp.ml"
 as _5)] -> Obj_command 
# 177 "script_parser.dyp"
(
                                                            (let () = echo dyp.global_data l in fun e -> F.create_lex ~abs:n1 ~obj:n2 n e):'dypgen__Obj_command)
# 889                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("command",[Dyp.Non_ter ("optional_idents",Dyp.No_priority );Dyp.Ter "SAVE"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_optional_idents ( (
# 179 "script_parser.dyp"
                 (names:'dypgen__Obj_optional_idents)
# 898                "script_parser_temp.ml"
 as _1));Obj_SAVE  (
# 179 "script_parser.dyp"
                             (filename,l,line:((string*Abstract_syntax.Abstract_syntax.location*string)))
# 902                "script_parser_temp.ml"
 as _2)] -> Obj_command 
# 178 "script_parser.dyp"
(
                                                 ( let () = echo dyp.global_data line in fun e -> 
						match names with
						  | [] -> let () = F.save filename e l in e
						  | _ -> let () = F.save ~names filename e l in e):'dypgen__Obj_command)
# 910                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("all_commands",[Dyp.Ter "WAIT"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [ _1] -> Obj_all_commands 
# 184 "script_parser.dyp"
(
       (F.Wait):'dypgen__Obj_all_commands)
# 920                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("all_commands",[Dyp.Ter "DONT";Dyp.Ter "WAIT"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [ _1; _2] -> Obj_all_commands 
# 185 "script_parser.dyp"
(
            (F.Dont_wait):'dypgen__Obj_all_commands)
# 930                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("all_commands",[Dyp.Ter "LIST"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [ _1] -> Obj_all_commands 
# 186 "script_parser.dyp"
(
       (F.List):'dypgen__Obj_all_commands)
# 940                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("all_commands",[Dyp.Ter "SELECT"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [ _1] -> Obj_all_commands 
# 187 "script_parser.dyp"
(
         (F.Select):'dypgen__Obj_all_commands)
# 950                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("all_commands",[Dyp.Ter "UNSELECT"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [ _1] -> Obj_all_commands 
# 188 "script_parser.dyp"
(
           (F.Unselect):'dypgen__Obj_all_commands)
# 960                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("all_commands",[Dyp.Ter "TRACE"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [ _1] -> Obj_all_commands 
# 189 "script_parser.dyp"
(
        (F.Trace):'dypgen__Obj_all_commands)
# 970                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("all_commands",[Dyp.Ter "DONT";Dyp.Ter "TRACE"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [ _1; _2] -> Obj_all_commands 
# 190 "script_parser.dyp"
(
             (F.Dont_trace):'dypgen__Obj_all_commands)
# 980                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("all_commands",[Dyp.Ter "PRINT"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_PRINT  (
(_:(Abstract_syntax.Abstract_syntax.location))
# 988                "script_parser_temp.ml"
 as _1)] -> Obj_all_commands 
# 191 "script_parser.dyp"
(
        (F.Print):'dypgen__Obj_all_commands)
# 993                "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("all_commands",[Dyp.Ter "ANALYSE"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_ANALYSE  (
(_:((string*Abstract_syntax.Abstract_syntax.location*string)))
# 1001               "script_parser_temp.ml"
 as _1)] -> Obj_all_commands 
# 192 "script_parser.dyp"
(
          (F.Analyse):'dypgen__Obj_all_commands)
# 1006               "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("all_commands",[Dyp.Ter "ADD"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_ADD  (
(_:((string*Abstract_syntax.Abstract_syntax.location*string)))
# 1014               "script_parser_temp.ml"
 as _1)] -> Obj_all_commands 
# 193 "script_parser.dyp"
(
      (F.Add):'dypgen__Obj_all_commands)
# 1019               "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("all_commands",[Dyp.Ter "COMPOSE"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [ _1] -> Obj_all_commands 
# 194 "script_parser.dyp"
(
          (F.Compose):'dypgen__Obj_all_commands)
# 1029               "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("all_commands",[Dyp.Ter "HELP"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [ _1] -> Obj_all_commands 
# 195 "script_parser.dyp"
(
       (F.Help None):'dypgen__Obj_all_commands)
# 1039               "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("optional_ident",[],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [] -> Obj_optional_ident 
# 199 "script_parser.dyp"
(
  (None):'dypgen__Obj_optional_ident)
# 1049               "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("optional_ident",[Dyp.Ter "IDENTT"],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_IDENTT  (
# 201 "script_parser.dyp"
        (id:((string*Abstract_syntax.Abstract_syntax.location)))
# 1058               "script_parser_temp.ml"
 as _1)] -> Obj_optional_ident 
# 200 "script_parser.dyp"
(
             (Some id):'dypgen__Obj_optional_ident)
# 1063               "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("optional_idents",[],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [] -> Obj_optional_idents 
# 204 "script_parser.dyp"
(
  ([]):'dypgen__Obj_optional_idents)
# 1073               "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("optional_idents",[Dyp.Ter "IDENTT";Dyp.Non_ter ("optional_idents",Dyp.No_priority )],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [Obj_IDENTT  (
# 206 "script_parser.dyp"
        (id:((string*Abstract_syntax.Abstract_syntax.location)))
# 1082               "script_parser_temp.ml"
 as _1);Obj_optional_idents ( (
# 206 "script_parser.dyp"
                            (ids:'dypgen__Obj_optional_idents)
# 1086               "script_parser_temp.ml"
 as _2))] -> Obj_optional_idents 
# 205 "script_parser.dyp"
(
                                  (id::ids):'dypgen__Obj_optional_idents)
# 1091               "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])
;
(("0_1",[],"default_priority",[]),
Dyp.Dypgen_action (fun __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl ->
(Dyp.Tools.transform_action (fun dyp __dypgen_av_list -> (match (__dypgen_av_list) with [] -> Obj_dypgen__epsilon 
(
():'dypgen__Obj_dypgen__epsilon)
# 1100               "script_parser_temp.ml"
,[] | _ -> raise Dyp.Giveup))) __dypgen_ol __dypgen_pos __dypgen_posl __dypgen_gd __dypgen_ld __dypgen_lld __dypgen_di __dypgen_p __dypgen_nl),
[])],

(["dummy_entry",Dyp.RE_Eof_char],
[0,(fun _ -> Lexeme_matched "")]),

[]

let __dypgen_regexp_decl = []

let dyp_merge_Inh_dypgen__early_action_0 l =
  match dyp_merge_Inh_dypgen__early_action_0 l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Lexeme_matched l =
  match dyp_merge_Lexeme_matched l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_ADD l =
  match dyp_merge_Obj_ADD l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_ANALYSE l =
  match dyp_merge_Obj_ANALYSE l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_CHECK l =
  match dyp_merge_Obj_CHECK l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_IDB l =
  match dyp_merge_Obj_IDB l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_IDENTT l =
  match dyp_merge_Obj_IDENTT l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_LOAD_DATA l =
  match dyp_merge_Obj_LOAD_DATA l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_LOAD_OBJECT l =
  match dyp_merge_Obj_LOAD_OBJECT l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_LOAD_SCRIPT l =
  match dyp_merge_Obj_LOAD_SCRIPT l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_PARSE l =
  match dyp_merge_Obj_PARSE l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_PRINT l =
  match dyp_merge_Obj_PRINT l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_QUERY l =
  match dyp_merge_Obj_QUERY l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_REALIZE l =
  match dyp_merge_Obj_REALIZE l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_SAVE l =
  match dyp_merge_Obj_SAVE l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_SEMICOLONN l =
  match dyp_merge_Obj_SEMICOLONN l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_all_commands l =
  match dyp_merge_Obj_all_commands l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_command l =
  match dyp_merge_Obj_command l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_dypgen__early_action_0 l =
  match dyp_merge_Obj_dypgen__early_action_0 l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_dypgen__epsilon l =
  match dyp_merge_Obj_dypgen__epsilon l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_optional_ident l =
  match dyp_merge_Obj_optional_ident l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_optional_idents l =
  match dyp_merge_Obj_optional_idents l with
    | ([],_,_) -> dyp_merge l
    | res -> res
let dyp_merge_Obj_zzcommands l =
  match dyp_merge_Obj_zzcommands l with
    | ([],_,_) -> dyp_merge l
    | res -> res

let __dypgen_merge_list = [(fun l -> (
  let f1 (o,gd,ld) = match o with Inh_dypgen__early_action_0 ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Inh_dypgen__early_action_0"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Inh_dypgen__early_action_0 l in
  let f2 o = Inh_dypgen__early_action_0 o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Lexeme_matched ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Lexeme_matched"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Lexeme_matched l in
  let f2 o = Lexeme_matched o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_ADD ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_ADD"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_ADD l in
  let f2 o = Obj_ADD o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_ANALYSE ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_ANALYSE"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_ANALYSE l in
  let f2 o = Obj_ANALYSE o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_CHECK ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_CHECK"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_CHECK l in
  let f2 o = Obj_CHECK o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_IDB ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_IDB"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_IDB l in
  let f2 o = Obj_IDB o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_IDENTT ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_IDENTT"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_IDENTT l in
  let f2 o = Obj_IDENTT o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_LOAD_DATA ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_LOAD_DATA"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_LOAD_DATA l in
  let f2 o = Obj_LOAD_DATA o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_LOAD_OBJECT ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_LOAD_OBJECT"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_LOAD_OBJECT l in
  let f2 o = Obj_LOAD_OBJECT o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_LOAD_SCRIPT ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_LOAD_SCRIPT"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_LOAD_SCRIPT l in
  let f2 o = Obj_LOAD_SCRIPT o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_PARSE ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_PARSE"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_PARSE l in
  let f2 o = Obj_PARSE o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_PRINT ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_PRINT"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_PRINT l in
  let f2 o = Obj_PRINT o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_QUERY ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_QUERY"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_QUERY l in
  let f2 o = Obj_QUERY o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_REALIZE ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_REALIZE"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_REALIZE l in
  let f2 o = Obj_REALIZE o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_SAVE ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_SAVE"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_SAVE l in
  let f2 o = Obj_SAVE o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_SEMICOLONN ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_SEMICOLONN"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_SEMICOLONN l in
  let f2 o = Obj_SEMICOLONN o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_all_commands ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_all_commands"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_all_commands l in
  let f2 o = Obj_all_commands o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_command ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_command"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_command l in
  let f2 o = Obj_command o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_dypgen__early_action_0 ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_dypgen__early_action_0"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_dypgen__early_action_0 l in
  let f2 o = Obj_dypgen__early_action_0 o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_dypgen__epsilon ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_dypgen__epsilon"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_dypgen__epsilon l in
  let f2 o = Obj_dypgen__epsilon o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_optional_ident ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_optional_ident"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_optional_ident l in
  let f2 o = Obj_optional_ident o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_optional_idents ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_optional_idents"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_optional_idents l in
  let f2 o = Obj_optional_idents o in
  (List.map f2 ol, gd, ld)));
(fun l -> (
  let f1 (o,gd,ld) = match o with Obj_zzcommands ob -> (ob,gd,ld)
    | _ -> failwith "type error, bad obj in dyp_merge_Obj_zzcommands"
  in
  let l = List.map f1 l in
  let (ol,gd,ld) = dyp_merge_Obj_zzcommands l in
  let f2 o = Obj_zzcommands o in
  (List.map f2 ol, gd, ld)))]



let __dypgen_test_cons () =  [|
  (fun x -> match x with Inh_dypgen__early_action_0 _ -> true | _ -> false);
  (fun x -> match x with Lexeme_matched _ -> true | _ -> false);
  (fun x -> match x with Obj_ADD _ -> true | _ -> false);
  (fun x -> match x with Obj_ANALYSE _ -> true | _ -> false);
  (fun x -> match x with Obj_CHECK _ -> true | _ -> false);
  (fun x -> match x with Obj_IDB _ -> true | _ -> false);
  (fun x -> match x with Obj_IDENTT _ -> true | _ -> false);
  (fun x -> match x with Obj_LOAD_DATA _ -> true | _ -> false);
  (fun x -> match x with Obj_LOAD_OBJECT _ -> true | _ -> false);
  (fun x -> match x with Obj_LOAD_SCRIPT _ -> true | _ -> false);
  (fun x -> match x with Obj_PARSE _ -> true | _ -> false);
  (fun x -> match x with Obj_PRINT _ -> true | _ -> false);
  (fun x -> match x with Obj_QUERY _ -> true | _ -> false);
  (fun x -> match x with Obj_REALIZE _ -> true | _ -> false);
  (fun x -> match x with Obj_SAVE _ -> true | _ -> false);
  (fun x -> match x with Obj_SEMICOLONN _ -> true | _ -> false);
  (fun x -> match x with Obj_all_commands _ -> true | _ -> false);
  (fun x -> match x with Obj_command _ -> true | _ -> false);
  (fun x -> match x with Obj_dypgen__early_action_0 _ -> true | _ -> false);
  (fun x -> match x with Obj_dypgen__epsilon _ -> true | _ -> false);
  (fun x -> match x with Obj_optional_ident _ -> true | _ -> false);
  (fun x -> match x with Obj_optional_idents _ -> true | _ -> false);
  (fun x -> match x with Obj_zzcommands _ -> true | _ -> false)|]

let __dypgen_dummy_marker_2 = ()
let pp () = Dyp.make_parser
  __dypgen_ra_list Dyp_priority_data.relations global_data local_data
  (Dyp.Tools.make_nt_cons_map Dyp_symbols_array.nt_cons_list)
  Dyp_symbols_array.entry_points
  
  false 28 true
  
  Dyp_aux_functions.get_token_value
  Dyp_symbols.get_token_name Dyp_symbols.str_token
  global_data_equal local_data_equal (__dypgen_test_cons ())
  Dyp_symbols_array.str_cons
  Dyp_symbols_array.cons_array Dyp_aux_functions.cons_table
  (Dyp.Tools.array_of_list __dypgen_merge_list)
  dypgen_lexbuf_position __dypgen_regexp_decl __dypgen_main_lexer
  __dypgen_aux_lexer Dyp_symbols.ter_string_list
  (fun lexbuf -> Lexeme_matched (Dyp.lexeme lexbuf))
  false


let __dypgen_dummy_marker_5 = ()

let __dypgen_dummy_marker_3 = ()

let zzcommands ?(global_data=global_data) ?(local_data=local_data) f lexbuf =
  let pf = Dyp.parse (pp ()) "zzcommands" ~global_data:global_data
    ~local_data:local_data ~match_len:dypgen_match_length
    ~keep_data:dypgen_keep_data
    ~use_rule_order:dypgen_use_rule_order
    ~use_all_actions:dypgen_use_all_actions
    ~lexpos:dypgen_lexbuf_position f lexbuf in
  let aux1 (o,p) = match o with
    | Obj_zzcommands r -> (r,p)
    | _ -> failwith "Wrong type for entry result" in
  List.map aux1 pf


let __dypgen_dummy_marker_4 = ()


# 210 "script_parser.dyp"


  let rec parse_file ?(verbose=true)  filename  includes env =
    try
      let in_ch =
	let fullname = Utils.find_file filename includes  in
	  open_in fullname in
      let lexbuf = Lexing.from_channel in_ch in
      let () = Printf.printf "Parsing script file \"%s\"...\n%!" filename in
      let new_env=
	try (fst (List.hd (zzcommands ~global_data:(F.should_wait (),verbose,includes) ~local_data:(env,parse_file ~verbose)  Script_lexer.lexer lexbuf))) with
	  |  Dyp.Syntax_error -> raise (Error.dyp_error lexbuf filename) in
      let () = Printf.printf "Done.\n%!" in
	new_env
    with
      | Utils.No_file(f,msg) -> let e = Error.System_error (Printf.sprintf "No such file \"%s\" in %s" f msg) in
	let () = Printf.fprintf stderr "Error: %s\n%!" (Error.error_msg e filename) in
	let _ = Script_lexer.reset_echo () in
	  env
      | Sys_error s -> let e = Error.System_error s in
	let () = Printf.fprintf stderr "Error: %s\n%!" (Error.error_msg e filename) in
	let _ = Script_lexer.reset_echo () in
	  env
      | Error.Error e -> 
	  let () = Printf.fprintf stderr "Error: %s\n%!" (Error.error_msg e filename) in
	  let _ = Script_lexer.reset_echo () in
	    env
      | Scripting_errors.Error (e,p) ->
	  let () = Printf.fprintf stderr "Error: %s\n%!" (Scripting_errors.error_msg e p) in
	  let _ = Script_lexer.reset_echo () in
	    env
	      
  let commented_regexp = Str.regexp "^[ \t#]*#"

  let is_fully_commented_line s = Str.string_match commented_regexp s 0

  let bufferize () =
    let () = Printf.printf "# " in
    let buf = Buffer.create 16 in
    let no_semi_colon=ref true in
    let () =
      while !no_semi_colon do
	let input = read_line () in
	  if not (is_fully_commented_line input) then
	    try
	      let semi_colon_index=String.index input ';' in
	      let () = Buffer.add_string buf (String.sub input 0 (semi_colon_index+1)) in
		no_semi_colon:=false
	    with
	      | Not_found ->
		  Buffer.add_string buf input ;
		  Buffer.add_char buf '\n';
		  Printf.printf "  "
	  else
	    ()
      done in
      Buffer.contents buf
	

	
  let parse_entry ?(verbose=true) includes env =
    let in_str = bufferize () in
    let lexbuf = Lexing.from_string in_str in
    let new_env=
      try
	try (fst (List.hd (zzcommands ~global_data:(false,verbose,includes) ~local_data:(env,parse_file ~verbose)  Script_lexer.lexer lexbuf))) with
	  |  Dyp.Syntax_error -> raise (Error.dyp_error lexbuf "stdin")
      with
	| F.Stop -> env
	| Failure "lexing: empty token" -> env
	| Error.Error e -> 
	    let () = Printf.fprintf stderr "Error: %s\n%!" (Error.error_msg e "stdin") in
	    let _ = Script_lexer.reset_echo () in
	      env
	| Scripting_errors.Error (e,p) ->
	    let () = Printf.fprintf stderr "Error: %s\n%!" (Scripting_errors.error_msg e p) in
	    let _ = Script_lexer.reset_echo () in
	      env in
      new_env
	

end
let _ = () (* dummy line to improve OCaml error location *)
# 1540               "script_parser_temp.ml"
