let f : 'a . ('a -> 'a) Mapred_rfun.rfun = Mapred_rfun.register "name" (fun a -> a) ;;

