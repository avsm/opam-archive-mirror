#use "topfind";;
#thread;;
#require "mr_framework";;
open Mapred_toolkit;;
let dec1 = Mapred_split.tab_split;;
let cod1 = fun (k,v) -> k^"\t" ^ v;;
let dec1r = Mapred_rfun.register "dec1r" dec1;;
let cod1r = Mapred_rfun.register "cod1r" cod1;;
let codec = (dec1r,cod1r);;
let c = Plasma_client.open_cluster "p1" ["office1", 2730] (Unixqueue.create_unix_event_system());;
Plasma_client.configure_auth_daemon c;;
let rc = (object method bigblock_size = 65536 method mr_buffer_size = 16*65536 method mr_buffer_size_tight = 16*65536 end);;
let p2 = Place.from c codec `Line_structured rc (`Flat_dir "/d2");;
let [st1] = Store.read_place p2;;
let s1 = Seq.read st1;;
(*
let out = Store.write_place p2;;
let outseq = Seq.extend out;;
let s2 = Seq.sort ~hash:(fun (k,_) -> 0) ~cmp:(fun (k1,_) (k2,_) -> String.compare k1 k2) s1 outseq;;
 *)
(*
let str = string_of_int;;
let p3 = Place.create c codec `Line_structured rc (`Flat_dir "/d3");;
let s2 = Seq.mapl_sort_fold
  ~mapl:(fun (k,v) -> [k])
  ~hash:(fun k -> 0)
  ~cmp:(fun k1 k2 -> String.compare k1 k2)
  ~initfold:(fun _ -> None)
  ~fold:(fun st k ->
           match st with
             | Some(j,n) -> 
                 if j=k then (Some(j,n+1),[]) else (Some(k,1), [j, str n])
             | None ->
                 (Some(k,1), [])
        )
  ~finfold:(fun st ->
           match st with
             | Some(j,n) -> [j,str n]
             | None -> [] )
  ~partition_of:(fun k -> (Hashtbl.hash k) mod 5)
  ~partitions:5
  p2
  p3 ;;
List.iter Seq.flush s2;;  
let [p0w;p1w;p2w;p3w;p4w] = s2;;
let p0 = Seq.reread p0w;;
Seq.hdl 10 p0;;

 *)
