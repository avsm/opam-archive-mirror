let x =
  <:rfun< a b c @ d e f -> a ^ b ^ c ^ d ^ e ^ f >>
