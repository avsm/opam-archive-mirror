type t = A.t option
