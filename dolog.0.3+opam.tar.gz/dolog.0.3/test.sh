#!/bin/bash

ocaml <<EOF
#use "test.ml";;
EOF
