dolog
=====

A dumb OCaml logger

Every OCaml programmer seems to have his own logging module.
Let's not violate this ancestral tradition.

example.ml is a compilable example.

test.sh is a funny test script.
