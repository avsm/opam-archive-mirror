(* OASIS_START *)
(* DO NOT EDIT (digest: 5dae9528a3d6a4e085e0357a978986fa) *)

ocamlmod - Generate OCaml modules from source files
===================================================

See the file [INSTALL.txt](INSTALL.txt) for building and installation
instructions.

Copyright and license
---------------------

ocamlmod is distributed under the terms of the GNU Lesser General Public
License version 2.1 with OCaml linking exception.

(* OASIS_STOP *)
