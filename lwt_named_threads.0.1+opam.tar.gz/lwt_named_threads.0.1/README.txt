(* OASIS_START *)
(* DO NOT EDIT (digest: efb16273e740949dac894c10753f4007) *)

lwt_named_threads - Library to attach names and logs to Lwt threads (for
debug/trace/objsize)
=============================================================================================

See the file [INSTALL.txt](INSTALL.txt) for building and installation
instructions.

Copyright and license
---------------------

lwt_named_threads is distributed under the terms of the GNU Lesser General
Public License version 2.1 with OCaml linking exception.

(* OASIS_STOP *)
