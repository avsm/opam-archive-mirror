external now : unit -> int = "ocaml_read_time_stamp_counter" "noalloc"
