let x =  Example_piqi.default_example () in
Example_piqi_ext.prerr_example x
