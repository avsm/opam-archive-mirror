(* OASIS_START *)
(* DO NOT EDIT (digest: d5aa66d14748e64a0156f659c7099e62) *)

csv - A pure OCaml library to read and write CSV files.
=======================================================

This is a pure OCaml library to read and write CSV files, including all
extensions used by Excel — e.g. quotes, newlines, 8 bit characters in
fields, \"0 etc.  The library comes with a handy command line tool called
csvtool for handling CSV files from shell scripts.

See the file [INSTALL.txt](INSTALL.txt) for building and installation
instructions.

[Home page](https://github.com/Chris00/ocaml-csv)

Copyright and license
---------------------

csv is distributed under the terms of the GNU Lesser General Public License
version 2.1 with OCaml linking exception.

(* OASIS_STOP *)
