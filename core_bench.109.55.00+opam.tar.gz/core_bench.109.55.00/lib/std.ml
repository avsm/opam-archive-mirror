(** This [Std] module is expected to be opened. *)

(** Please look at {!Bench} *)
module Bench = Bench
