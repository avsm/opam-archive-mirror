
let verbose_lexing = ref false
let exn_when_lexical_error = ref true

let debug_lexer = ref false
