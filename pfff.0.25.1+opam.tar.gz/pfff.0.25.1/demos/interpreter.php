<?php

$x = 1;

$y = 0;
if($x == 1) {
  $y++;
}
show($y);

echo $y;
