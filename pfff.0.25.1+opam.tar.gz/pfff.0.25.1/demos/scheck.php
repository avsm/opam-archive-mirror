<?php

function foo($a) {

  return $b;

}