different visualization types:
http://www-958.ibm.com/software/data/cognos/manyeyes/page/Visualization_Options.html

