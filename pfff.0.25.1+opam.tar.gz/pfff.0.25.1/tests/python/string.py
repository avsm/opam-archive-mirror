def foo(x):
  print x
  print "this is it"
  print '''this is it
  '''


foo(2)
foo(3)
