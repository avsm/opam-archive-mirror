def foo(x):
  print x


foo(2)
foo(3)
