<?php

function foo() {
  $x = 1;
  $y = $x;
  $z = $y;
  return $z;
}