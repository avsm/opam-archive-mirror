<?php

function foo($x) {
  return $x ? 1 : 1.0;
}