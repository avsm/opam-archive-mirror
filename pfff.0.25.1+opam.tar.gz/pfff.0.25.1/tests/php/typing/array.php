<?php

function foo($a) {
  return $a[0][1];
}

