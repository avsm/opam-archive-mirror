<?php

function foo() {
  if(1) {
    $x = 1.0;
  } else {
    $x = 1;
  }
  return $x;
}