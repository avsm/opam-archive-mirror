<?php

class A {
  function foo($i) {
    return $i + 1;
  }
  static function bar($b) {
    return $b === true;
  }
}


