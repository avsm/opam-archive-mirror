<?php

function foo(string $x) {
  echo $x;
}

foo("astring\n");
foo(1);
