<?php

$header = <<<"EOD"
this is it
EOD;

var_dump($header);
