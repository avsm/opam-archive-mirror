<?php

namespace X;
function foo() {
  echo "foo\n";
}
class A {
}

const CST = 42;
