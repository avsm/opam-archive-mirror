<?php

var_dump(isset($x));
$x = 1;
var_dump(isset($x));
