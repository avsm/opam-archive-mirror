<?php

const true = 1;

const null = 0;

function __builtin__echo() {
}

function call_user_func($fn, ...) {
}

function defined() {
}