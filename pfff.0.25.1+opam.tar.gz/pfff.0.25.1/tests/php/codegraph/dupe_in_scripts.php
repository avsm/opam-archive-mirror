<?php

class DupeScript {
  public function foo() {
  }
}
