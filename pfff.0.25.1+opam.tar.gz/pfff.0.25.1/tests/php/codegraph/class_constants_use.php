<?php

$o = ClassConstant::CST1;
