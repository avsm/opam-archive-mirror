<?php

class ClassConstant {
  const CST1 = 1;
  const CST2 = 1;
 
}