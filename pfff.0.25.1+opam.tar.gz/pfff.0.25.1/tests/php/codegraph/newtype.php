<?hh

type PairAB =
  (A, B);

class B {
}
