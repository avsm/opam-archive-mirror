<?php

class DynA {
}

function test_dynamic_class() {
  echo Dyna::$fld;
}