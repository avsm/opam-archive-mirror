<?php

file2_foo();

