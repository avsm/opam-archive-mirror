<?php

function idx() { }

function time() { }

function user_get_name() { }
