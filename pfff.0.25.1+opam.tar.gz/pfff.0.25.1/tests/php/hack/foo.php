<?hh

class X {
  private ?int $x;
}
