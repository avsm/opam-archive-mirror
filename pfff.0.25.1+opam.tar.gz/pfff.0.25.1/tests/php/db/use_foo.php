<?php

function use_foo() {
  A::mfoo();

  $o = new A();
  $o->mbar();
}


