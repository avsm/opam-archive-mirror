<?php

interface I2 {
}
