let x = 1

let foo () = 2
