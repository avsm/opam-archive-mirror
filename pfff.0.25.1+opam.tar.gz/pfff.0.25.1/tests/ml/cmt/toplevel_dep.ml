
let _ =
  Foo.func 1 2

