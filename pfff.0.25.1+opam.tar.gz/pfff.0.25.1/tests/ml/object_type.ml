


let foo f arg =
  f (arg :> < memb1 : int >)
