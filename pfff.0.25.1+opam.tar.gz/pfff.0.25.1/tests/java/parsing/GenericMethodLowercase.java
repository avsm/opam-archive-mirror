
class X {
  public static <typeClass extends FacebookPage> String RequestPageInfo() {
  }
}

