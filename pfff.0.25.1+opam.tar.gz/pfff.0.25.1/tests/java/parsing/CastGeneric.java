class X {
  void main(Object x) {
    return (A<Int>) x;
  }
}