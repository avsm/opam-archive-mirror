class X <T extends A1 & A2> {
}