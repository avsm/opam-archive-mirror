class X {
  List<Object[]> x;

}