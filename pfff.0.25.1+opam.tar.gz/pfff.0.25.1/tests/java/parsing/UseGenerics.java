class UseGenerics extends EntryGenerics<String, Integer> {


}


