class X {
  Token x;
  public foo() {
    if (x.tag == 1) {
    }

  }
}