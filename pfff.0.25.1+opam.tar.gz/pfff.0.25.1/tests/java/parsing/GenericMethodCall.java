class X {
  public void foo() {
    return ImmutableSet.<Class<? extends Annotation>>of(QuickExperimentQueue.class);
  }

}
