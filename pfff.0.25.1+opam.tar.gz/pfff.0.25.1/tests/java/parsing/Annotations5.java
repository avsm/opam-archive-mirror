class X {

 @RunWith(WithTestDefaultsRunner.class)
 @Implements(PreferenceCategory.class)
 void main() {
 }

 @Implements(AssetManager.class)
 void main() {
 }


 @Implements(SQLiteQueryBuilder.class)
 @JMAutogen.ListType(jsonFieldName="edges", listElementTypes={FeedStoryEdge.class})
 @Test(expected = IllegalStateException.class)
 void main() {
 }

}
