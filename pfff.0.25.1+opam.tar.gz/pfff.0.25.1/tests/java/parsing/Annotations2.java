class X {

  @SuppressWarnings({"UnusedDeclaration"})
    void foo(String args[]) { }
}
