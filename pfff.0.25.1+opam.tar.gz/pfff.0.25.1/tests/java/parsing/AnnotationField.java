class X {

     // Instance variables
     @JMAutogen.InferredType(jsonFieldName=XXX)
     public final String username;
}

