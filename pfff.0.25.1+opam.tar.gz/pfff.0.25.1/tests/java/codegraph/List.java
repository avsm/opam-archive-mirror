package java.util;

interface List {
}
