package X;
//import bar.toto.X;
//import static bar.toto.Y.staticMethod;
//import bar.toto.AClass.NestedClass;

class Foo {

  static public int field1 = 0;

  public static void main(String[] args) {

    int x = field1;
    System.out.println("hello world");
    for (int i = 0; i < 10; i++) {
      int y = i;
    }
  }
}
