package inter;

class ExtendsExpr extends Expr {
  void main() {
    int x = op;
  }
}