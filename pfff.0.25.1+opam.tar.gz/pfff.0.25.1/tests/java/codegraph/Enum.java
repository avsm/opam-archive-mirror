class Enum {

  public enum AnEnum { 
      A_CONSTANT,
      B_CONSTANT;
  }


  void foo() {
    return A_CONSTANT;
  }
}