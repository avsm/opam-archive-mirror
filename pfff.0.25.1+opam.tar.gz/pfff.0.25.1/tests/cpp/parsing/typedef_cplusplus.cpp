int foo1;
foo1 x;
foo2* x;
foo3& x;

foo4& operator <<(void) { }
