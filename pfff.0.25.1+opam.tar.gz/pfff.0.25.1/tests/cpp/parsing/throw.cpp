class Foo {
  ~Foo() throw() {
  }
};

void foo() throw(Exception) {
}
