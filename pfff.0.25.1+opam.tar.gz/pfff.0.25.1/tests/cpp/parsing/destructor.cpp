Foo::~Foo() {
}

class Bar {
  ~Bar() { }
};
