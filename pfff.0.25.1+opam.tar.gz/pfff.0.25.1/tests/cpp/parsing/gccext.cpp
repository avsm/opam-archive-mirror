namespace foo {

void Foo::Bar() {
};

}
