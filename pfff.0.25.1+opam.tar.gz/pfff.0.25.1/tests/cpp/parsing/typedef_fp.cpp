

void main() {

  if(fp_foo1) foo();

  int x = fp_foo2 * b;

  x += fp_foo4 * foo;
  x *= fp_foo5 * foo;

  real x = fp_foo6 * fp_foo7 * fb_foo8;

  x = a ? fp_foo9 * foo : bar;

  x = a.fp_foo10 * foo;
  x = a[fp_foo11 * foo];

  x = 1 - fp_foo12 * foo;

//  int id = (int) (fp_foo3 * foo());

  if (smc_tiername_given) {
    Flags::addSmcConfig(FLAGS_smc_tiername);
  }

}

template<typename T>
inline T sqr(T x) {
  return fp_foo13 * x;
}

void main() {

  cha->nsize = icount * isize;

  return x->num_objects * p1_step;

  default_arg = xrealloc(default_arg, sizeof *default_arg * default_alloc);

  int cmp = hashcmp(index + mi * stride, sha1);

  if (v > XDL_K_HEUR * ec && v > best) {
  }

  if (n * old->ctype->bit_size == ctype->bit_size) {
  }

	return bytes * bits_in_char;

  if(off + n > MAXFILE*BSIZE) {
  }
}

// 	b2 = (char *)b + (n1 * s);

