void prototype() throw();
