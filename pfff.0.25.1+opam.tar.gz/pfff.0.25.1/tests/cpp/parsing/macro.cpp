#define FOO 1

#define BAR(x) (x + 1)
