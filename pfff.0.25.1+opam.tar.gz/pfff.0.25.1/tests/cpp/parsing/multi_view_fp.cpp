
// many FP in the multi view are because of bad template heuristic
// so see also template_fb.cpp
// Other FPs are because of ifdef-mid, so try to improve parsing_hacks_pp.ml

//TODO? #	define NAMESPACE_BEGIN(x) namespace x {

void main() {
}

