#include <stdio.h>

void main() {
  int x;
  printf("hello world\n");
}
