void main() {
  foo(1,2);
}
