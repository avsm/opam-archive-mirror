void printf() {
}

