int xopen();
