#!/bin/sh

set -e

ocaml-crunch static -m plain -o irminHTTPStatic.ml
