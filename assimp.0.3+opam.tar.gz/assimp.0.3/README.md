Bindings to [Assimp](http://assimp.sourceforge.net), Open Asset Import Library.

Assimp is released under 3-clause BSD license.
The OCaml binding is released under CC-0 license.

Make sure assimp is installed. Then:

```shell
$ make
$ make install
```


## CHANGELOG

Version 0.3, Sun Nov 27 20:25:49 CET 2016
  Increase Makefile portability

Version 0.2, Sun Dec 13 15:39:01 CET 2015
  Make use of result package

Version 0.1, Thu Sep 17 09:36:20 CET 2015
  Initial release
