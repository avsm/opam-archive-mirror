# ocaml-planet

A library for aggregating RSS2 and Atom feeds in OCaml.

Features:

* Performs deduplication.
* Supports pagination and generating well-formed html prefix snippets.
* Support for generating aggregate feeds.
* Sorts the posts from most recent to oldest.
* Depends on ocamlnet for html parsing.
