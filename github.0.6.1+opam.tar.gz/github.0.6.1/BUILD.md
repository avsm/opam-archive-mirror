To regenerate this OASIS setup, use the `oasis-mirage` OPAM package which
supports syntax extensions directly.  The default `oasis` will result in a
broken build!
