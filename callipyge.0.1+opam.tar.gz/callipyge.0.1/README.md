Callipyge
=========

Pure OCaml implementation of Curve25519

Documentation
=============

Not yet!

Build Requirements
==================

 * OCaml >= 4.02.0

[![Build Status](https://travis-ci.org/oklm-wsh/Callipyge.svg?branch=master)](https://travis-ci.org/oklm-wsh/Callipyge)
