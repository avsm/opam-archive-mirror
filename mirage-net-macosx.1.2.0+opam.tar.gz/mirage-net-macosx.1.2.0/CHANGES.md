### 1.2.0 (2016-11-11)

- Switch to topkg (#11, @hannesm and @samoht)
- Remove camlp4 (#7, @samoht)

### 1.1.0 (2015-03-04)

- Add an explicit `connect` function to interface (#1).
- Support the `Io_page` 1.4.0+ API. (#2).

### 1.0.0 (2014-12-01)

- Initial public release.
