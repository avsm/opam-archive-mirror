let example = {json|[
{
    "Id": "3b37372dfc695f3703a32a463dd0267e166aa0191a421ee3ef1b5950119ffcbf",
    "Created": "2015-11-12T10:26:27.719228993Z",
    "Path": "/agent",
    "Args": [],
    "State": {
        "Running": true,
        "Paused": false,
        "Restarting": false,
        "OOMKilled": false,
        "Dead": false,
        "Pid": 3597,
        "ExitCode": 0,
        "Error": "",
        "StartedAt": "2015-11-12T10:26:28.194767165Z",
        "FinishedAt": "0001-01-01T00:00:00Z"
    },
    "Image": "2e864c5150aaa4cad06d90d809303562f9d41302929ed6e047403926a1133e28",
    "NetworkSettings": {
        "Bridge": "",
        "EndpointID": "86a4f43931d4f7951a4da37fcf3bb09373cc59b22dc2d00d4212027ead1ae3db",
        "Gateway": "172.17.42.1",
        "GlobalIPv6Address": "",
        "GlobalIPv6PrefixLen": 0,
        "HairpinMode": false,
        "IPAddress": "172.17.0.37",
        "IPPrefixLen": 16,
        "IPv6Gateway": "",
        "LinkLocalIPv6Address": "",
        "LinkLocalIPv6PrefixLen": 0,
        "MacAddress": "02:42:ac:11:00:25",
        "NetworkID": "db86118596629cfe447031702693e460f6a265ea239b35a4fab9620294418806",
        "PortMapping": null,
        "Ports": {
            "51678/tcp": [
                {
                    "HostIp": "127.0.0.1",
                    "HostPort": "51678"
                }
            ]
        },
        "SandboxKey": "/var/run/docker/netns/3b37372dfc69",
        "SecondaryIPAddresses": null,
        "SecondaryIPv6Addresses": null
    },
    "ResolvConfPath": "/var/lib/docker/containers/3b37372dfc695f3703a32a463dd0267e166aa0191a421ee3ef1b5950119ffcbf/resolv.conf",
    "HostnamePath": "/var/lib/docker/containers/3b37372dfc695f3703a32a463dd0267e166aa0191a421ee3ef1b5950119ffcbf/hostname",
    "HostsPath": "/var/lib/docker/containers/3b37372dfc695f3703a32a463dd0267e166aa0191a421ee3ef1b5950119ffcbf/hosts",
    "LogPath": "/var/lib/docker/containers/3b37372dfc695f3703a32a463dd0267e166aa0191a421ee3ef1b5950119ffcbf/3b37372dfc695f3703a32a463dd0267e166aa0191a421ee3ef1b5950119ffcbf-json.log",
    "Name": "/ecs-agent",
    "RestartCount": 0,
    "Driver": "devicemapper",
    "ExecDriver": "native-0.2",
    "MountLabel": "",
    "ProcessLabel": "",
    "Volumes": {
        "/cgroup": "/cgroup",
        "/data": "/var/lib/ecs/data",
        "/etc/ecs": "/etc/ecs",
        "/log": "/var/log/ecs",
        "/var/cache/ecs": "/var/cache/ecs",
        "/var/lib/docker/execdriver": "/var/run/docker/execdriver",
        "/var/run/docker.sock": "/var/run/docker.sock"
    },
    "VolumesRW": {
        "/cgroup": false,
        "/data": true,
        "/etc/ecs": true,
        "/log": true,
        "/var/cache/ecs": true,
        "/var/lib/docker/execdriver": false,
        "/var/run/docker.sock": true
    },
    "AppArmorProfile": "",
    "ExecIDs": null,
    "HostConfig": {
        "Binds": [
            "/var/run/docker.sock:/var/run/docker.sock",
            "/var/log/ecs:/log",
            "/var/lib/ecs/data:/data",
            "/etc/ecs:/etc/ecs",
            "/var/cache/ecs:/var/cache/ecs",
            "/cgroup:/cgroup:ro",
            "/var/run/docker/execdriver:/var/lib/docker/execdriver:ro"
        ],
        "ContainerIDFile": "",
        "LxcConf": null,
        "Memory": 0,
        "MemorySwap": 0,
        "CpuShares": 0,
        "CpuPeriod": 0,
        "CpusetCpus": "",
        "CpusetMems": "",
        "CpuQuota": 0,
        "BlkioWeight": 0,
        "OomKillDisable": false,
        "Privileged": false,
        "PortBindings": {
            "51678/tcp": [
                {
                    "HostIp": "127.0.0.1",
                    "HostPort": "51678"
                }
            ]
        },
        "Links": null,
        "PublishAllPorts": false,
        "Dns": null,
        "DnsSearch": null,
        "ExtraHosts": null,
        "VolumesFrom": null,
        "Devices": null,
        "NetworkMode": "bridge",
        "IpcMode": "",
        "PidMode": "",
        "UTSMode": "",
        "CapAdd": null,
        "CapDrop": null,
        "RestartPolicy": {
            "Name": "",
            "MaximumRetryCount": 0
        },
        "SecurityOpt": null,
        "ReadonlyRootfs": false,
        "Ulimits": null,
        "LogConfig": {
            "Type": "json-file",
            "Config": {}
        },
        "CgroupParent": ""
    },
    "Config": {
        "Hostname": "3b37372dfc69",
        "Domainname": "",
        "User": "",
        "AttachStdin": false,
        "AttachStdout": false,
        "AttachStderr": false,
        "PortSpecs": null,
        "ExposedPorts": {
            "51678/tcp": {}
        },
        "Tty": false,
        "OpenStdin": false,
        "StdinOnce": false,
        "Env": [
            "ECS_CLUSTER=Facing-Test",
            "ECS_ENGINE_AUTH_TYPE=docker",
            "ECS_ENGINE_AUTH_DATA={\"https://index.docker.io/v1/\":{\"username\":\"quintlyworker\",\"password\":\"xGWF9MhiqVHGC9\",\"email\":\"admin@quintly.com\"}}",
            "ECS_LOGFILE=/log/ecs-agent.log",
            "ECS_DATADIR=/data",
            "ECS_AGENT_CONFIG_FILE_PATH=/etc/ecs/ecs.config.json",
            "ECS_UPDATE_DOWNLOAD_DIR=/var/cache/ecs",
            "ECS_UPDATES_ENABLED=true",
            "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
        ],
        "Cmd": null,
        "Image": "amazon/amazon-ecs-agent:latest",
        "Volumes": null,
        "VolumeDriver": "",
        "WorkingDir": "",
        "Entrypoint": [
            "/agent"
        ],
        "NetworkDisabled": false,
        "MacAddress": "",
        "OnBuild": null,
        "Labels": {}
    }
}
]|json}
