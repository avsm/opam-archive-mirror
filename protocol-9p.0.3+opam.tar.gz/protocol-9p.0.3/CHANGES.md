0.3 (20-Jan-2016)
- add version/attach mount debug messages
- pass initial connection attach to receive callback handler

0.2 (04-Jan-2016)
- respect negotiated msize in read
- add LICENSE file

0.1 (13-Dec-2015)
- initial version
