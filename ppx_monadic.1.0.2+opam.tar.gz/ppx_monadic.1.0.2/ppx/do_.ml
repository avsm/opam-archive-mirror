open Ppxx (* must come after Ast_helper *)
open Ast_mapper
open Parsetree
open Longident
open Location

let is_m s =
  match Longident.parse s with
  | Lident "m" -> Some None
  | Ldot (l, "m") -> Some (Some l)
  | _ -> None
  | exception _ -> None

let is_do e = match e.pexp_desc with
  | Pexp_ident {txt=Lident "do_"} -> Some None
  | Pexp_ident {txt=Ldot (lid, "do_"); loc} -> Some (Some {txt=lid; loc})
  | _ -> None
  
let is_do_clause e = match e.pexp_desc with
  | Pexp_sequence (e1, e2) -> 
      (* e1; e2; e3   is  e1; (e2; e3) *)
      begin match is_do e1 with
      | None -> None
      | Some lo -> Some (lo, e2)
      end
  | _ ->
      match is_do e with
      | None -> None
      | Some _ ->
          raise_errorf ~loc:e.pexp_loc "ppx_monadic: do_ must be followed by ;"

let desugar_do e = 
  let open Monadic in
  let rec f = function
    | End e -> e
    | Bind (Some p, e, t) ->
        [%expr 
            bind [%e e] (fun [%p p] -> [%e f t])
        ]
    | Bind (None, e, t) ->
        [%expr 
            bind [%e e] (fun () -> [%e f t])
        ]
    | Let (g, t) ->
        g & f t
  in
  f & parse None e

let extend super = 
  let expr self e = 
    match is_do_clause e with
    | Some (None, e) ->
        (* Format.eprintf "do_ clause: %a@." Pprintast.expression e; *)
        self.expr self & desugar_do e
    | Some (Some lid, e) ->
        (* Format.eprintf "do_ clause: %a@." Pprintast.expression e; *)
        (* self.expr self & Exp.open_ Fresh lid & desugar_do e *)
        let m_dot s = Exp.ident {txt= Ldot (lid.txt, s); loc=Location.none} in
        (* let in_m s = Exp.open_ Override lid & Exp.var s in *)
        [%expr
         let bind   = [%e m_dot "bind"] in
         let return = [%e m_dot "return"] in
         (* the following is to surpress Warning 26 *)
         let _ = bind in
         let _ = return in
         (* I believe having fail is not a good idea... *)  
         [%e self.expr self & desugar_do e]
        ]
               
    | None ->
        match e.pexp_desc with
        | Pexp_extension ({txt=x; loc}, PStr [{ pstr_desc= Pstr_eval ({ pexp_desc = Pexp_let(rec_flag, vbs, e)}, _attr) }]) ->
            (* let%XXX p = e1 in e2 *)
            begin match is_m x with
            | None -> super.expr self e
            | Some lidopt ->
                if rec_flag = Recursive then
                  raise_errorf ~loc:e.pexp_loc "ppx_monadic: let%%m cannot be recursive";
                match vbs with
                | [] -> assert false (* impos *)
                | [vb] ->
                    let bind = match lidopt with
                      | None -> [%expr bind]
                      | Some l -> Exp.ident ~loc {txt= Ldot (l, "bind"); loc}
                    in
                    self.expr self &
                    [%expr
                        [%e bind] [%e vb.pvb_expr] (fun [%p vb.pvb_pat] -> [%e e])
                    ]
                | _ ->
                    raise_errorf ~loc:e.pexp_loc "ppx_monadic: let%%m can take only one binding"
            end
        | _ -> super.expr self e
  in
  { super with expr }
