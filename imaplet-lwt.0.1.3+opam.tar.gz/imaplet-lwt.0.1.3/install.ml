  let data_path = "/usr/local/share/imaplet"
  let users_path = "/usr/local/share/imaplet/users"
  let config_path = "/usr/local/share/imaplet/imaplet.cf"
  let lmtp_srv_exec = "/usr/local/bin/imaplet_lmtp"
