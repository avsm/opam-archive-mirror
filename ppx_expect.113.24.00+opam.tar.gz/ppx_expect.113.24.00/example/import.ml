open! Core.Std

let () = print_string "hello world"
