open! Core.Std
open! Import

let%expect_test _ =
  [%expect {| hello world |}]
