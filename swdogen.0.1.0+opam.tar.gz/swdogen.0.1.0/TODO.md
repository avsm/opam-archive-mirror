1. add auth fields

2. fully support swagger version 1.2