open! Core.Std

module Parallel   = Parallel
module Map_reduce = Map_reduce
