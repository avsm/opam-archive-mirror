void an_empty_function() {};
