(* #use this to setup the interactive environment. *)

#require "cstruct, cstruct.syntax, sexplib.syntax, nocrypto, astring";;

#directory "_build/src";;
#load_rec "otr.cmo";;

