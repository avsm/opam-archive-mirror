var id;
var name = id ? 'John' : undefined;
module.exports = name;
