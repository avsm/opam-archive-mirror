/* @flow */

module.exports = { a() {} };