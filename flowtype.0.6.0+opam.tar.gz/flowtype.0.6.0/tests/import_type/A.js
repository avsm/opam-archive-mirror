/**
 * @flow
 */

class A {
}

module.exports = A;
