(* OASIS_START *)
(* DO NOT EDIT (digest: 50d0ab1a3e7c91b6ced1430094bf8b28) *)

treeprint - Small tree structure printer with operator associations and precedences.
====================================================================================

See the file [INSTALL.txt](INSTALL.txt) for building and installation
instructions.

Copyright and license
---------------------

treeprint is distributed under the terms of the GNU Lesser General Public
License version 2.0 with OCaml linking exception.

(* OASIS_STOP *)
