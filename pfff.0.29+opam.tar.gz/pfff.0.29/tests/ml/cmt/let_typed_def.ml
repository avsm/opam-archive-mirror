let (typed_def: int -> int) = fun i -> i

let test () =
  typed_def 1
