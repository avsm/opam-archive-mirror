exception BarExn
