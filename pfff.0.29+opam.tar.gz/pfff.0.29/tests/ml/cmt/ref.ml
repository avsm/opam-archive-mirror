open Pervasives

let use_ref = function
 { contents = x} -> x
