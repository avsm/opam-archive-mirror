(* if you hexdump this file you will see a 0a at the end, which is a \r
 * (viewed as a ^M under emacs).
 *)
