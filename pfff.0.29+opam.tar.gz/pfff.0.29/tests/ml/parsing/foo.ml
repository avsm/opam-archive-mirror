open Foo

type tbar = int

let x = 1

let foo i = 
  i

