class foo = object
  method foo () = 
    x <- true
end
