let (=~) s x = 
  failwith "todo"

let t1 x = 
  s =~ "foobar"
