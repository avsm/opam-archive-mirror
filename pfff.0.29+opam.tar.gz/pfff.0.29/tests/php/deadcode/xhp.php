<?php

// dead
function xhp_dead() {
  return <x:frag />;
}

