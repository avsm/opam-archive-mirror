<?php

foo(1,,);
