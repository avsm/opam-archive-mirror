<?php

class A {
  function foo() {
    self::bar();
  }
}