<?php

require 'namespace.php';

X\foo();
\X\foo();
