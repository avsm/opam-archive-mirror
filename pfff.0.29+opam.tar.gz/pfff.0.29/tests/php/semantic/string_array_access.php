<?php

$str = "fOo";

// strings can be used as an array
echo $str[2];

// this is also valid
echo $str{0};
