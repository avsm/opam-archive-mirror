<?php

$f = 'a_function';
$f3 = 'foo does not look like entity';
