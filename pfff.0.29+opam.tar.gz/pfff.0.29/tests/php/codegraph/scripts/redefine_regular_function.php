<?php

//ERROR: bad style, redefined builtin
function __builtin__echo() {
}

