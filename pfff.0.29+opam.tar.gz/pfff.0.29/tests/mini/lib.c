#ifdef __STDC__
#else
void printf(char* fmt) {
}
void* malloc(int x) {
}
#endif
