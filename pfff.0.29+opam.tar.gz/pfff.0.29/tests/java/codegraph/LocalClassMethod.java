class LocalClassMethod {
  public void foo1() {
    class Base { }
  }

  public void foo2() {
    class Base { }
  }

}