class TypeParamLookup <K, T> {
  K x;
}