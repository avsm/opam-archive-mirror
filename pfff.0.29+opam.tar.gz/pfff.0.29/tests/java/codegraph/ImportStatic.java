package ImportStatic;

import static java.lang.String.a_string_method;