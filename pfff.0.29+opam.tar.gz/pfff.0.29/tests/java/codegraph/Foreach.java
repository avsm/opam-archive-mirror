class Foreach {
  void main(String[] args) {
    for (Object v : args) {
      int x = v;
    }
  }
}
