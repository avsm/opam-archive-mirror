class
  X<paramClass> {
}
