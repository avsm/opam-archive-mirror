class LessThan {
  void main(int i, int j) {
    return i<j;
  }
}
