class Test {

  public void start(String operationType, @Nullable Bundle param) {
  }
  public View renderView(Context context, @Nullable View view) {
  }
}

