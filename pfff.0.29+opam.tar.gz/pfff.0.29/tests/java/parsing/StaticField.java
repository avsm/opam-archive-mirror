class X {
  static final int Int;

  void foo() {
    if(X.Int) {
    }
  }
}