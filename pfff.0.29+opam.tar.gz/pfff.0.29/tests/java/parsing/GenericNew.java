class X {
  void main() {
    
    List<Pair<Long, File>> toDelete = new ArrayList<Pair<Long, File>>();
  }

}

