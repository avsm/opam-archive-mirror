public interface Phone {

    enum State {
      IDLE, RINGING, OFFHOOK; // ok to have a trailing ;
     };
}
