class ContinuousImportTest extends AndroidTestCase {
  private static Class<?> TAG = 1;//ContinuousImport.class;
}

