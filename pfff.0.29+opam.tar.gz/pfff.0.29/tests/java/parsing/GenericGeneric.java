class FetchOperationData<paramClass extends FetchTickerExtra.Params,
                        extraClass extends TickerExtra,
                        resultClass extends FetchTickerExtra.Result<paramClass, extraClass>> 
{
}
