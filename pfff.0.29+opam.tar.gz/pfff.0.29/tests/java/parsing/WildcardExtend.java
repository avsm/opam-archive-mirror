
class WildCardExtend {
  public void setApps(List<? extends IndexListItem> list) {
  }
  private Class<? extends View> viewClass;
}
