public class WebViewTest {
  public static <T extends WebView> void runTest() {
  }
  public <T extends Parcelable<T>> T getResultDataParcelable() {
  }
}



