class X {
  public List<List<Int>> x;


  void main() {
    Set<Set<Entry<Integer, String>>> set;
  }


}