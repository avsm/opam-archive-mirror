void main() {
  vector<int> x;
  vector<foo> x;
}
