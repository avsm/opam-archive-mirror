
void main()
{
 map1<string2, 
      set3<string4> 
    >::iterator5 iter6;
}
