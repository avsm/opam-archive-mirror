struct Foo {
  // a MethodDecl
  void foo() throw() = 0;
};
