// if decide to skip template arguments, must also pass certain
// keywords like template!

foo1<foo2> x;

template<typename SCALAR>
SCALAR norm2(const TDenseVector<SCALAR>& x) {
}
