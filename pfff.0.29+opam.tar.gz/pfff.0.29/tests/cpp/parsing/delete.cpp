void main() {
  delete[] foo;

}
