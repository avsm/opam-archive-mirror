void main() {
  foo(new Foo());
}
