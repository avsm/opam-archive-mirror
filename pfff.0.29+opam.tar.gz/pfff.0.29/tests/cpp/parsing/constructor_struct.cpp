// a Constructor
struct Foo { Foo(); };
