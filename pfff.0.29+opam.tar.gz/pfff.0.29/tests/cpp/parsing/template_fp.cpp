void main() 
{
		for (i = 1; i < 4; i++) {
			if (i > 1)
        foo();
    }
}


inline double clampToRange(double value, double lower, double upper) {
  return value < lower? lower : (value > upper? upper : value);
}

void main()
{
      while(is_greater && i < nneighbors)
        is_greater &= v > *(pt + neighbors[i++]) ;

}

void main()
{
      for (j = 0; j < Polynomial<DEG>::size(); j++) {
      }
}
