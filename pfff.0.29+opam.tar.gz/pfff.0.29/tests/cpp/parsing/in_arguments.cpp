
// see also constructed_object.cpp

void main() {

// actually it could be a declaration ... not necessaraly an argument
// because i could be a constant and foo2 and foo3 typedefs
//  foo1 x(foo2, foo3[i]);
  string& x("foo");

  foo2 x(*y);
  foo2 x(&y);

  return (x * y);

  if(!(x & y)) {
  }

}
