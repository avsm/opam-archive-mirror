#define FOO 1

#undef FOO

void main() {
  
}
