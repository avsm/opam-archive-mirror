class Foo {
  int x;
  ;
};

