void main() {

  std::foo();

  std::vector x;

  std::vector<int> x;
  std<float>::vector<int> x;

  ::vector<int> x;

}

friend class ::KDTreeTestFixture;

const struct ::tm* tm_time;
