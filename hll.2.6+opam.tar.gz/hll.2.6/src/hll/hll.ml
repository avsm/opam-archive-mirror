open Core.Std

module P = Process

module Flag = struct
  open Command.Spec

  let opam_dir () =
    flag "-opam-dir" ~doc:"dir Path to the output opam repo directory"
      (required string)

  let tag () =
    flag "-tag" ~doc:"tag Tag to use for the version of the package"
      (optional string)

  let pins_file () =
    flag "-pins" ~doc:"file Path to a whitespace separated file of package to pinned version"
      (optional string)

  let hll_conf () =
    flag "-hll" ~doc:"file File of the hll config for this repo, hll.conf by default"
      (optional_with_default "hll.conf" string)

  let pds_conf () =
    flag "-pds" ~doc:"file File of the pds config for this repo, pds.conf by default"
      (optional_with_default "pds.conf" string)
end

let value_opt ~default = function
  | Some v -> v
  | None -> default

let value_exn ~msg = function
  | Some v -> v
  | None -> failwith msg

module Generate = struct
  type url_proto =
    | Git
    | Http

  type t = { tag : string
           ; url_protocol : url_proto
           ; url_template : string
           ; pattern : string
           ; desc : string
           ; maintainer : string
           ; external_deps : String.Set.t
           ; deps_blacklist : String.Set.t
           ; deps_map : TomlTypes.table
           ; pins : (string * string) list
           ; homepage : string
           ; authors : String.Set.t
           ; bug_reports : string
           ; dev_repo : string
           ; available : string
           ; build_deps : String.Set.t
           ; opam_extra_lines : string list
           }

  module Result = struct
    type t = { opam_content : string
             ; desc_content : string
             ; url_content : string
             }
  end

  let desc_file t = t.desc ^ "\n"

  let url_file t =
    let url =
      String.substr_replace_first
        t.url_template
        ~pattern:t.pattern
        ~with_:t.tag
    in
    match t.url_protocol with
      | Git ->
        sprintf "git: \"%s\"\n" url
      | Http -> begin
        let lines = P.read_stdout "curl" [| "-L"; url |] in
        (*
         * Process is, unfortunately, somewhat lame in that it breaks lines up
         * from the output rather than giving the raw output.  So join them again
         * and add the new line back.
         *)
        let data = String.concat ~sep:"\n" lines in
        let hex = Digest.string data |> Digest.to_hex in
        sprintf "archive: \"%s\"\nchecksum: \"%s\"\n" url hex
      end

  let format_external_deps deps pins =
    List.map
      ~f:(fun d ->
        match List.Assoc.find pins d with
          | Some pin ->
            sprintf "\"%s\" { %s }" d pin
          | None ->
            sprintf "\"%s\"" d)
      (Set.to_list deps)

  let format_authors = List.map ~f:(sprintf "\"%s\"")

  let str_if_not_empty k = function
    | "" -> []
    | v -> [sprintf "%s: \"%s\"" k v]

  let list_if_not_empty k = function
    | "" -> []
    | v -> [sprintf "%s: [%s]" k v]

  let concat_nl = String.concat ~sep:"\n"
  let concat_nltab = String.concat ~sep:"\n\t"

  let opam_file t =
    let all_build_deps =
      String.Set.union
        t.build_deps
        (String.Set.of_list ["ocamlfind"; "pds"])
    in
    (* The set of compile-time deps that map to package names *)
    let deps_map_src =
      String.Set.of_list
        (List.concat_map
           ~f:(fun (_, v) ->
               value_exn
                 ~msg:"Invalid deps_map value"
                 TomlLenses.(get v (array |-- strings)))
           (TomlTypes.Table.bindings t.deps_map))
    in
    (* The set of packages that the compile-time deps map to *)
    let deps_map_dst =
      String.Set.of_list
        (List.map
           ~f:(fun (k, _) -> TomlTypes.Table.Key.to_string k)
           (TomlTypes.Table.bindings t.deps_map))
    in
    let blacklist = Set.union t.deps_blacklist deps_map_src in
    let all_deps = Set.union (Set.union t.external_deps all_build_deps) deps_map_dst in
    let output_deps = Set.diff all_deps blacklist in
    let external_deps = format_external_deps output_deps t.pins in
    concat_nl
      (List.concat
         [ [ "opam-version: \"1.2\""
           ; sprintf "maintainer: \"%s\"" t.maintainer
           ; "build: ["
           ; "\t[make \"-j%{jobs}%\"]"
           ; "]"
           ; ""
           ; "install: ["
           ; "\t[make \"PREFIX=%{prefix}%\" \"install\"]"
           ; "]"
           ; ""
           ; "remove: ["
           ; "\t[make \"PREFIX=%{prefix}%\" \"remove\"]"
           ; "]"
           ; ""
           ; "depends: ["
           ; "\t" ^ concat_nltab external_deps
           ; "]"
           ; ""
           ; "authors: ["
           ; "\t" ^ concat_nltab (format_authors (Set.to_list t.authors))
           ; "]"
           ; ""
           ; sprintf "homepage: \"%s\"" t.homepage
           ]
         ; str_if_not_empty "bug-reports" t.bug_reports
         ; str_if_not_empty "dev-repo" t.dev_repo
         ; list_if_not_empty "available" t.available
         ; t.opam_extra_lines
         ; [""]
      ])

  let generate_pkg_content t =
    Result.({ opam_content = opam_file t
            ; desc_content = desc_file t
            ; url_content = url_file t
            })
end

module Generate_io = struct
  module Hll_conf = struct
    type t = { maintainer : string
             ; url_template : string
             ; url_protocol : Generate.url_proto
             ; url_pattern : string
             ; desc : string
             ; deps_blacklist : String.Set.t
             ; deps_map : TomlTypes.table
             ; homepage : string
             ; authors : String.Set.t
             ; bug_reports : string
             ; dev_repo : string
             ; build_deps : String.Set.t
             ; available : string
             ; opam_extra_lines : string list
             }

    let url_protocol_of_string = function
      | "git" -> Generate.Git
      | "http" -> Generate.Http
      | s -> failwith (sprintf "Invalid url_protocol (%s) in hll configuration" s)

    let read fname =
      let hll_conf = Toml.Parser.(from_filename fname |> unsafe) in
      let maintainer =
        value_exn
          ~msg:"A maintainer is required"
          TomlLenses.(get hll_conf (key "maintainer" |-- string))
      in
      let url_template =
        value_exn
          ~msg:"A url_template is required"
          TomlLenses.(get hll_conf (key "url_template" |-- string))
      in
      let url_protocol =
        value_exn
          ~msg:"A url_protocol is required"
          TomlLenses.(get hll_conf (key "url_protocol" |-- string))
      in
      let url_pattern =
        value_exn
          ~msg:"A url_pattern is required"
          TomlLenses.(get hll_conf (key "url_pattern" |-- string))
      in
      let desc =
        value_exn
          ~msg:"A desc is required"
          TomlLenses.(get hll_conf (key "desc" |-- string))
      in
      let authors =
        value_exn
          ~msg:"A list of authors is required"
          TomlLenses.(get hll_conf (key "authors" |-- array |-- strings))
      in
      let homepage =
        value_exn
          ~msg:"A homepage is required"
          TomlLenses.(get hll_conf (key "homepage" |-- string))
      in
      let bug_reports =
        value_opt
          ~default:""
          TomlLenses.(get hll_conf (key "bug_reports" |-- string))
      in
      let dev_repo =
        value_opt
          ~default:""
          TomlLenses.(get hll_conf (key "dev_repo" |-- string))
      in
      let deps_blacklist =
        value_opt
          ~default:[]
          TomlLenses.(get hll_conf (key "deps_blacklist" |-- array |-- strings))
      in
      let deps_map =
        value_opt
          ~default:TomlTypes.Table.empty
          TomlLenses.(get hll_conf (key "deps_map" |-- table))
      in
      let build_deps =
        value_opt
          ~default:[]
          TomlLenses.(get hll_conf (key "build_deps" |-- array |-- strings))
      in
      let available =
        value_opt
          ~default:""
          TomlLenses.(get hll_conf (key "available" |-- string))
      in
      let opam_extra_lines =
        value_opt
          ~default:[]
          TomlLenses.(get hll_conf (key "opam_extra_lines" |-- array |-- strings))
      in
      { maintainer = maintainer
      ; url_template = url_template
      ; url_protocol = url_protocol_of_string url_protocol
      ; url_pattern = url_pattern
      ; desc = desc
      ; authors = String.Set.of_list authors
      ; homepage = homepage
      ; bug_reports = bug_reports
      ; deps_blacklist = String.Set.of_list deps_blacklist
      ; deps_map = deps_map
      ; dev_repo = dev_repo
      ; available = available
      ; build_deps = String.Set.of_list build_deps
      ; opam_extra_lines = opam_extra_lines
      }
  end

  module Pds_conf = struct
    type t = { deps : String.Set.t
             ; targets : String.Set.t
             }

    let list_keys table =
      TomlTypes.Table.(
        fold
          (fun key _ keys -> Key.to_string key::keys)
          table
          [])

    let list_deps table =
      TomlTypes.Table.(
        fold
          (fun key v deps ->
            deps @ value_opt
              ~default:[]
              TomlLenses.(get v (table |-- key "deps" |-- array |-- strings)))
          table
          [])

    let read fname =
      let pds_conf = Toml.Parser.(from_filename fname |> unsafe) in
      let srcs =
        value_opt
          ~default:TomlTypes.Table.empty
          TomlLenses.(get pds_conf (key "src" |-- table))
      in
      let tests =
        value_opt
          ~default:TomlTypes.Table.empty
          TomlLenses.(get pds_conf (key "tests" |-- table))
      in
      let targets = list_keys srcs in
      let deps = list_deps srcs @ list_deps tests in
      { deps = String.Set.of_list deps
      ; targets = String.Set.of_list targets
      }

    let external_deps t =
      Set.filter ~f:(fun d -> not (Set.mem t.targets d)) t.deps
  end

  module Pins = struct
    type t = (string * string) list

    let empty = []

    let read fname =
      let lines = In_channel.read_lines fname in
      let pins =
        List.map
          ~f:(fun line ->
            match String.lsplit2 ~on:' ' line with
              | Some (dep, version) ->
                (String.strip dep, String.strip version)
              | None ->
                failwith "Invalid pinning, format is \"dep version\"")
          lines
      in
      pins
  end

  let output_pkg ~opam_dir ~name ~tag ~contents =
    let pkg_dir = Filename.concat opam_dir "packages" in
    let base_pkg_dir = Filename.concat pkg_dir name in
    let base_dir = Filename.concat base_pkg_dir (sprintf "%s.%s" name tag) in
    Unix.mkdir_p base_dir;
    List.iter
      ~f:(fun (fname, content) ->
        Out_channel.write_all fname ~data:content)
      ([ (Filename.concat base_dir "opam", contents.Generate.Result.opam_content)
       ; (Filename.concat base_dir "url", contents.Generate.Result.url_content)
       ; (Filename.concat base_dir "descr", contents.Generate.Result.desc_content)
       ])
end

let error_if_failed = function
  | P.Exit.Exit 0 -> ()
  | _ -> failwith "Unable to determine tag"

let maybe_load_tag = function
  | Some tag ->
    tag
  | None -> begin
    let output = P.run "git" [| "describe" |] in
    error_if_failed output.P.Output.exit_status;
    String.concat output.P.Output.stdout
  end

let maybe_load_pins = function
  | Some file -> Generate_io.Pins.read file
  | None -> Generate_io.Pins.empty

let generate_pkg opam_dir tag_opt pins_file_opt hll_conf pds_conf () =
  let tag = maybe_load_tag tag_opt in
  let pins = maybe_load_pins pins_file_opt in
  let hll_conf = Generate_io.Hll_conf.read hll_conf in
  let pds_conf = Generate_io.Pds_conf.read pds_conf in
  let gen_t =
    Generate.({ tag = tag
              ; url_protocol = hll_conf.Generate_io.Hll_conf.url_protocol
              ; url_template = hll_conf.Generate_io.Hll_conf.url_template
              ; pattern = hll_conf.Generate_io.Hll_conf.url_pattern
              ; desc = hll_conf.Generate_io.Hll_conf.desc
              ; maintainer = hll_conf.Generate_io.Hll_conf.maintainer
              ; external_deps = Generate_io.Pds_conf.external_deps pds_conf
              ; deps_blacklist = hll_conf.Generate_io.Hll_conf.deps_blacklist
              ; deps_map = hll_conf.Generate_io.Hll_conf.deps_map
              ; pins = pins
              ; homepage = hll_conf.Generate_io.Hll_conf.homepage
              ; authors = hll_conf.Generate_io.Hll_conf.authors
              ; bug_reports = hll_conf.Generate_io.Hll_conf.bug_reports
              ; dev_repo = hll_conf.Generate_io.Hll_conf.dev_repo
              ; available = hll_conf.Generate_io.Hll_conf.available
              ; build_deps = hll_conf.Generate_io.Hll_conf.build_deps
              ; opam_extra_lines = hll_conf.Generate_io.Hll_conf.opam_extra_lines
              })
  in
  let contents = Generate.generate_pkg_content gen_t in
  Generate_io.output_pkg
    ~opam_dir
    ~name:(Filename.basename (Sys.getcwd ()))
    ~tag
    ~contents

let generate_cmd = Command.basic
  ~summary:"Generate an opam package"
  Command.Spec.(empty
                +> Flag.opam_dir ()
                +> Flag.tag ()
                +> Flag.pins_file ()
                +> Flag.hll_conf ()
                +> Flag.pds_conf ())
  generate_pkg

let main () =
  Exn.handle_uncaught
    ~exit:true
    (fun () ->
      Command.run
        (Command.group
           ~summary:"hll commands"
           [ ("generate", generate_cmd) ]))

let () = main ()
