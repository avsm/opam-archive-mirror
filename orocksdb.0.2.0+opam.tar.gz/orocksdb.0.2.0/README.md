ORocksDb
========

This repository contains some ocaml bindings to the C api of [rocksdb](http://github.com/facebook/rocksdb/).
It is far from complete and basically only contains what I needed so far.

Feel free to suggest features / report bugs using the issue tracker available on the repo.
Pull requests are definitely welcome too!
