type t = private [< `foo | `bar > `bar ]
