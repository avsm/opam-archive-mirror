module M = struct

  let x = 1

end
