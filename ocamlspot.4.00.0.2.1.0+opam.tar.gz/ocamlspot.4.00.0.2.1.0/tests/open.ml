module (* M => *) M (* <= M *) = struct
  let (* x => *) x (* <= x *) = 1
end 

open M (* ? M *)
open Target (* ? Target *)

