let _ = false
let _ = Failure "h"
let _ = 1


