type t =  {foo:int ; bar : int ; baz : int} with compare
