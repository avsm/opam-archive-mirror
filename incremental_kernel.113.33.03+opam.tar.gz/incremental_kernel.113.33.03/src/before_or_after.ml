type t = Before | After
[@@deriving sexp_of]
