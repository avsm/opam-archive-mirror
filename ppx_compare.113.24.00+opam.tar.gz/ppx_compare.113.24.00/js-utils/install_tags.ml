let package_name = "ppx_compare"

let sections =
  [ ("lib",
    [ ("built_lib_ppx_compare", None)
    ; ("built_lib_ppx_compare_expander", None)
    ],
    [ ("META", None)
    ])
  ]
