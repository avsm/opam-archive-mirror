type t = A | B with sexp

(*** Local Variables: ***)
(*** compile-command: "ocamlc -c -i -pp \"camlp4o -I /usr/lib/ocaml/type-conv -I /usr/lib/ocaml/sexplib pa_type_conv.cmo pa_sexp_conv.cmo\" -I /usr/lib/ocaml/sexplib f.ml " ***)
(*** End: ***)
