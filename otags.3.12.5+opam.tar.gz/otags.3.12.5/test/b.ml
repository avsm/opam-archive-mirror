
let (b1, b2) as b3 = (1,2)

