### 0.1.2

- Fix link issue when no inotify/fsevents backends are available
- Use topkg 0.7.8

### 0.1.1

- Fix link issue with the inotify backend

### 0.1.0

- Initial release