open Core.Std let _ = _squelch_unused_module_warning_

let message = 42
