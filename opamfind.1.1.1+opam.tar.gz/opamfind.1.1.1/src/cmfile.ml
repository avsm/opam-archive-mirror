open Spotlib.Spot
open List

open Config
open Cmo_format
open Cmx_format
open Cmi_format

(* CM* signature digest *)
module CMIDigest : sig
  type t [@@deriving conv{ocaml}]
  val to_string : t -> string
  val of_cu	: compilation_unit -> t
  val of_ui	: unit_infos -> t
  val of_cmi	: cmi_infos -> t
end = struct

  type t = string

  open Ocaml_conv
  let ocaml_of_t = ocaml_of_string *< Digest.to_hex
  let t_of_ocaml ?(trace=[]) o = 
    Result.(bind (string_of_ocaml ~trace o) & fun s ->
      try return & Digest.from_hex s with exn -> `Error (`Exception exn, o, trace)
    )
  let t_of_ocaml_exn = Ocaml_conv.exn t_of_ocaml
      
  let to_string x = Digest.to_hex x

  let of_cu  cu  = try from_Some & assoc cu.cu_name   cu.cu_imports     with _ -> assert false
  let of_ui  ui  = try from_Some & assoc ui.ui_name   ui.ui_imports_cmi with _ -> assert false
  let of_cmi cmi = try from_Some & assoc cmi.cmi_name cmi.cmi_crcs      with _ -> assert false
end

(* Load a CM* file. *)
let load filename =
  with_ic (open_in_bin filename) & fun ic ->
    let len_magic_number = String.length cmo_magic_number in
    let magic_number = really_input_string ic len_magic_number in
  
    if magic_number = cmo_magic_number then begin
      let cu_pos = input_binary_int ic in
      seek_in ic cu_pos;
      let cu = (input_value ic : compilation_unit) in
      Some (`CMO cu)
    end 
    else if magic_number = cma_magic_number then begin
      let toc_pos = input_binary_int ic in
      seek_in ic toc_pos;
      let toc = (input_value ic : library) in
      Some (`CMA toc)
    end else if magic_number = cmi_magic_number then begin
      let cmi = Cmi_format.input_cmi ic in
      Some (`CMI cmi)
    end else if magic_number = cmx_magic_number then begin
      let ui = (input_value ic : unit_infos) in
      Some (`CMX ui)
    end else if magic_number = cmxa_magic_number then begin
      let li = (input_value ic : library_infos) in
      Some (`CMXA li)
    end else begin
      let pos_trailer = in_channel_length ic - len_magic_number in
      let _ = seek_in ic pos_trailer in
      let _ = really_input ic magic_number 0 len_magic_number in
      if magic_number = Config.exec_magic_number then Some `ByteExec
      else if Filename.check_suffix filename ".cmxs" then Some `CMXS
      else None
    end

let get_compilation_units f =
  match load f with
  | Some (`CMO u) ->
      let open Cmo_format in
      Some [u.cu_name]
  | Some (`CMA lib) ->
      let open Cmo_format in
      Some (map (fun u -> u.cu_name) lib.lib_units)
  | Some (`CMX ui) -> 
      let open Cmx_format in
      Some [ui.ui_name]
  | Some (`CMXA lib) ->
      let open Cmx_format in
      Some (map (fun (u, _) -> u.ui_name) lib.lib_units)
  | _ -> None

let check_compilation_unit dir u =
  let mpath = Module_path.of_string (dir ^/ u) in
  Module_path.file ".cmi" mpath
    
(* CMI Digest of module path *)
let cmi_md5 mpath =
  let cmi = Module_path.file ".cmi" mpath in
  match cmi with
  | None -> 
      !!% "WARNING: No cmi file for %s@." (Module_path.to_string mpath);
      None
  | Some cmi ->
      match load cmi with
      | None -> 
          !!% "WARNING: load failure of cmi file %s@." cmi;
          None
      | Some (`CMI x) -> Some (cmi, CMIDigest.of_cmi x)
      | _ -> assert false

let cmi_without_value cmi_path =
  let open Cmi_format in
  let cmi_infos = read_cmi cmi_path in
  cmi_infos.cmi_sign |> for_all (function
    | Types.Sig_value _ 
    | Sig_module _
    | Sig_class _ -> false
    | Sig_type _
    | Sig_typext _
    | Sig_modtype _
    | Sig_class_type _ -> true)

let find_cmi_file name =
  try Some (Misc.find_in_path !Config.load_path (name ^ ".cmi"))
  with Not_found -> None

