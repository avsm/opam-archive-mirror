open Spotlib.Spot
open Utils
open List

open Ppx_orakuda.Regexp.Re_pcre.Infix
open Ppx_orakuda.Regexp.Re_pcre.Literal

(** I should use OPAM library but I still feel it is not stable enough. 
    So far, I use OPAM cli. 
*)

(* Guess OPAM package name from a path name.
   Your OPAM prefix must contain ".opam" directory component.
*)

let get_prefix () =
  let prefix =
    let open Command in
    shell "opam config var prefix"
    |> stdout |> wait |> must_exit_with 0
    |> function
        | [line] -> String.chop_eols line
        | [] -> failwith "opam config var prefix: empty result"
        | _ -> failwith "opam config var prefix: too many lines"
  in

  if not & mem ".opam" & Filename.split_dir prefix then begin
    !!% "Error: Your OPAM prefix does not contain .opam@."; assert false
  end;
  prefix

let get_current_switch () =
  let open Command in
  shell "opam switch"
  |> stdout |> wait |> must_exit_with 0
  |> filter_map (fun s ->
    Option.fmap (fun x -> x#_1) (s =~ {m|^([^\s]+)\s+C\s+|m}))
  |> function
      | [sw] -> sw
      | [] -> assert false
      | _ -> assert false

module Switch = struct
  type t = {
    switch : string; (** "system", "4.03.0" *)
    prefix : string; (** ~/.opam/<switch> *)
    build_dir : string; (** ~/.opam/<switch>/build *)
    compiler_source_dir : string (** ~/.opam/<switch>/build/ocaml *)
  } [@@deriving conv{ocaml}]

  let get () =
    let switch = get_current_switch () in
    let prefix = get_prefix () in
    { switch; prefix;
      build_dir = prefix ^/ "build";
      compiler_source_dir = prefix ^/ "build/ocaml";
    }
end
  
let get_opam_path sw n =
  let open Command in
  let com = !% "opam info --switch %s --where %s" sw.Switch.switch n in
  shell com
  |> stdout |> wait |> must_exit_with 0
  |> function
      | [l] -> Some (chop_eols l)
      | [] ->
          !!% "Warning: %s  returned an empty line@." com;
          None
      | ls ->
          !!% "Warning: %s  returned strange lines: %S@." com (String.concat "" ls);
          None

module Package = struct
  type t = {
    name     : string;
    version  : string;
    desc     : string;
    base     : bool;
    switch   : Switch.t;
    virtual_ : bool (* package "ocaml" is virtual *)
  } [@@deriving conv{ocaml}]

  let name_version p = if p.base then p.name else p.name ^ "." ^ p.version

  let format ppf p = Format.string ppf (name_version p)

  let build_dir p = p.switch.Switch.build_dir ^/ name_version p

  let opam_path p = get_opam_path p.switch p.name
end

let package_dir_of sw =
  let contains = File.contains sw.Switch.prefix in
  fun p ->
    let d = if File.Test._f p then Filename.dirname p else p in
    match contains d with
    | None -> None
    | Some ("build"::xs) -> Some (`OPAMBuild xs)
    | Some ("lib"::"ocaml"::(_::_ as xs)) -> Some (`OCamlFindLib xs)
    | Some ("lib"::xs) -> Some (`OCamlFindLib xs)
    | Some _ -> None

(* We fix the OPAM root. *)

open Package

let get_installed sw =
  let open Command in
  let com = !% "opam list --switch %s -i" sw.Switch.switch in
  shell com
  |> stdout |> wait |> must_exit_with 0
  |> filter_map (fun line ->
    let line = String.chop_eols line in
    match () with
    | _ when [%p? Some _] <-- (line =~ {m|^# Installed packages|m}) ->
        (* The first line. CR jfuruse: very fragile against OPAM change *)
        None
    | _ when Some x <-- (line =~ {m|^([^\s]+)\s+([^\s]+)\s+(.*)$|m}) ->
        (* !!% "%s %s@." x#_1 x#_2; *)
        let base = x#_2 = "base" in
        Some { name = x#_1; version = x#_2; desc = x#_3; base;
               switch = sw; virtual_ = false;
             }
    | _ -> 
        !!% "Warning: %s  returned a strange line: %s@." com line;
        None)

let virtual_ocaml sw =
  { Package.name = "ocaml";
    version = "base";
    desc = "ocaml compiler set";
    base = true;
    switch = sw;
    virtual_ = true;
  }

let get_installed sw = 
  (* add "ocaml" base package *)
  let ps = get_installed sw in
  let ps =
    if File.Test._d & sw.Switch.build_dir ^/ "ocaml" then
      virtual_ocaml sw :: ps
    else ps
  in
  ps |- !!% "OPAM packages: %d found@." ** length

let test () =
  let sw = Switch.get () in
  let installed = get_installed sw in
  !!% "@[%a@]@." (Ocaml.format_with [%derive.ocaml_of: Package.t list]) installed;
(*
  flip iter M.installed (fun p ->
    !!% "%a= @[%a@]@."
      Package.format p
      (Ocaml.format_with [%derive.ocaml_of: string list]) (M.find_meta p))
*)
  
