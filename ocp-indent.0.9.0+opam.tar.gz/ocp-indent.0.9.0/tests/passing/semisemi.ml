module M = struct
  let () = ()
  ;;
  let f x = 3;;
  let () = ()
end

;;

let () = ()
