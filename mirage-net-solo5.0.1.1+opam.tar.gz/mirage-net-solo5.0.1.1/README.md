Mirage NETWORK implementation for Solo5
