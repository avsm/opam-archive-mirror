(*************************************************************************)
(*                                                                       *)
(*                                OCaPIC                                 *)
(*                                                                       *)
(*                             Benoit Vaugon                             *)
(*                                                                       *)
(*    This file is distributed under the terms of the CeCILL license.    *)
(*    See file ../../LICENSE-en.                                         *)
(*                                                                       *)
(*************************************************************************)

(* Tools *)

let val_of_hex c1 c0 =
  let val_of_char c =
    match c with
      | '0' .. '9' -> int_of_char c - int_of_char '0'
      | 'a' .. 'f' -> int_of_char c - int_of_char 'a' + 10
      | 'A' .. 'F' -> int_of_char c - int_of_char 'A' + 10
      | _ -> invalid_arg "Simul.val_of_hex"
  in
  val_of_char c1 * 16 + val_of_char c0
;;

(***)

type port = PORTA | PORTB | PORTC | PORTD | PORTE

let string_of_port port =
  match port with
    | PORTA -> "PORTA" | PORTB -> "PORTB" | PORTC -> "PORTC"
    | PORTD -> "PORTD" | PORTE -> "PORTE"
;;

let port_of_string s =
  match String.uppercase s with
    | "PORTA" -> PORTA | "PORTB" -> PORTB | "PORTC" -> PORTC
    | "PORTD" -> PORTD | "PORTE" -> PORTE
    | _ -> invalid_arg "Simul.port_of_string"
;;

let char_of_port port =
  match port with
    | PORTA -> 'A' | PORTB -> 'B' | PORTC -> 'C' | PORTD -> 'D' | PORTE -> 'E'
;;

let port_of_char c =
  match c with
    | 'A' | 'a' -> PORTA | 'B' | 'b' -> PORTB | 'C' | 'c' -> PORTC
    | 'D' | 'd' -> PORTD | 'E' | 'e' -> PORTE
    | _ -> invalid_arg "Simul.port_of_char"
;;

let index_of_port port =
  match port with
    | PORTA -> 0 | PORTB -> 1 | PORTC -> 2 | PORTD -> 3 | PORTE -> 4
;;

let port_of_index ind =
  match ind with
    | 0 -> PORTA | 1 -> PORTB | 2 -> PORTC | 3 -> PORTD | 4 -> PORTE
    | _ -> invalid_arg "Simul.port_of_index"
;;

(***)

type pin =
  | RA0 | RA1 | RA2 | RA3 | RA4 | RA5 | RA6 | RA7
  | RB0 | RB1 | RB2 | RB3 | RB4 | RB5 | RB6 | RB7
  | RC0 | RC1 | RC2 | RC3 | RC4 | RC5 | RC6 | RC7
  | RD0 | RD1 | RD2 | RD3 | RD4 | RD5 | RD6 | RD7
  | RE0 | RE1 | RE2 | RE3 | RE4 | RE5 | RE6 | RE7
;;

let string_of_pin pin =
  match pin with
    | RA0 -> "RA0" | RA1 -> "RA1" | RA2 -> "RA2" | RA3 -> "RA3"
    | RA4 -> "RA4" | RA5 -> "RA5" | RA6 -> "RA6" | RA7 -> "RA7"
    | RB0 -> "RB0" | RB1 -> "RB1" | RB2 -> "RB2" | RB3 -> "RB3"
    | RB4 -> "RB4" | RB5 -> "RB5" | RB6 -> "RB6" | RB7 -> "RB7"
    | RC0 -> "RC0" | RC1 -> "RC1" | RC2 -> "RC2" | RC3 -> "RC3"
    | RC4 -> "RC4" | RC5 -> "RC5" | RC6 -> "RC6" | RC7 -> "RC7"
    | RD0 -> "RD0" | RD1 -> "RD1" | RD2 -> "RD2" | RD3 -> "RD3"
    | RD4 -> "RD4" | RD5 -> "RD5" | RD6 -> "RD6" | RD7 -> "RD7"
    | RE0 -> "RE0" | RE1 -> "RE1" | RE2 -> "RE2" | RE3 -> "RE3"
    | RE4 -> "RE4" | RE5 -> "RE5" | RE6 -> "RE6" | RE7 -> "RE7"
;;

let port_of_pin pin =
  match pin with
    | RA0 | RA1 | RA2 | RA3 | RA4 | RA5 | RA6 | RA7 -> PORTA
    | RB0 | RB1 | RB2 | RB3 | RB4 | RB5 | RB6 | RB7 -> PORTB
    | RC0 | RC1 | RC2 | RC3 | RC4 | RC5 | RC6 | RC7 -> PORTC
    | RD0 | RD1 | RD2 | RD3 | RD4 | RD5 | RD6 | RD7 -> PORTD
    | RE0 | RE1 | RE2 | RE3 | RE4 | RE5 | RE6 | RE7 -> PORTE
;;

let index_of_pin pin =
  match pin with
    | RA0 | RB0 | RC0 | RD0 | RE0 -> 0
    | RA1 | RB1 | RC1 | RD1 | RE1 -> 1
    | RA2 | RB2 | RC2 | RD2 | RE2 -> 2
    | RA3 | RB3 | RC3 | RD3 | RE3 -> 3
    | RA4 | RB4 | RC4 | RD4 | RE4 -> 4
    | RA5 | RB5 | RC5 | RD5 | RE5 -> 5
    | RA6 | RB6 | RC6 | RD6 | RE6 -> 6
    | RA7 | RB7 | RC7 | RD7 | RE7 -> 7
;;

let pin_of_port_index port index =
  let error () = invalid_arg "Simul.pin_of_port_index" in
  match port with
    | PORTA ->
      begin match index with
        | 0 -> RA0 | 1 -> RA1 | 2 -> RA2 | 3 -> RA3 | 4 -> RA4 | 5 -> RA5
        | 6 -> RA6 | 7 -> RA7 | _ -> error ()
      end
    | PORTB ->
      begin match index with
        | 0 -> RB0 | 1 -> RB1 | 2 -> RB2 | 3 -> RB3 | 4 -> RB4 | 5 -> RB5
        | 6 -> RB6 | 7 -> RB7 | _ -> error ()
      end
    | PORTC ->
      begin match index with
        | 0 -> RC0 | 1 -> RC1 | 2 -> RC2 | 3 -> RC3 | 4 -> RC4 | 5 -> RC5
        | 6 -> RC6 | 7 -> RC7 | _ -> error ()
      end
    | PORTD ->
      begin match index with
        | 0 -> RD0 | 1 -> RD1 | 2 -> RD2 | 3 -> RD3 | 4 -> RD4 | 5 -> RD5
        | 6 -> RD6 | 7 -> RD7 | _ -> error ()
      end
    | PORTE ->
      begin match index with
        | 0 -> RE0 | 1 -> RE1 | 2 -> RE2 | 3 -> RE3 | 4 -> RE4 | 5 -> RE5
        | 6 -> RE6 | 7 -> RE7 | _ -> error ()
      end
;;

let pin_of_string s =
  let error () = invalid_arg "Simul.pin_of_string" in
  if String.length s <> 3 || (s.[0] <> 'R' && s.[0] <> 'r') then error ();
  try
    let port = port_of_char s.[1] in
    let index = int_of_char s.[2] - int_of_char '0' in
    pin_of_port_index port index
  with Invalid_argument _ -> error ()
;;

(***)

type input = IWrite of port * int | ITris of port * int | ISync | IStop

let input_of_string s =
  let error () = invalid_arg "Simul.input_of_string" in
  if String.length s <> 4 then error ();
  match s with
    | "SYNC" -> ISync
    | "STOP" -> IStop
    | _ ->
      try
        let port = port_of_char s.[1] in
        let value = val_of_hex s.[2] s.[3] in
        match s.[0] with
          | 'W' -> IWrite (port, value)
          | 'T' -> ITris (port, value)
          | _ -> error ()
      with Invalid_argument _ -> error ()
;;

(***)

type output = OSet of pin | OClear of pin | OWrite of port * int | ODone

let string_of_output output =
  match output with
    | OSet pin ->
      Printf.sprintf "S%c%d" (char_of_port (port_of_pin pin))
        (index_of_pin pin)
    | OClear pin ->
      Printf.sprintf "C%c%d" (char_of_port (port_of_pin pin))
        (index_of_pin pin)
    | OWrite (port, value) ->
      Printf.sprintf "W%c%02X" (char_of_port port) value
    | ODone -> "DONE"
;;

(***)

let channel = Event.new_channel ();;

let rec send_loop () =
  begin try
          let output = (Event.sync (Event.receive channel)) in
          print_string (string_of_output output);
          print_char '\n';
          flush stdout;
    with exn ->
      Printf.eprintf "Unhandled exception %s\n%!" (Printexc.to_string exn)
  end;
  send_loop ();
in
ignore (Thread.create send_loop ());
;;

let send output = Event.sync (Event.send channel output);;

(***)

type handler =
  | Exit_handler of (unit -> unit)
  | Write_handler of (port -> int -> unit)
  | Write_port_handler of port * (int -> unit)
  | Tris_handler of (port -> int -> unit)
  | Tris_port_handler of port * (int -> unit)
  | Set_handler of (pin -> unit)
  | Clear_handler of (pin -> unit)
  | Change_handler of (pin -> bool -> unit)
  | Set_pin_handler of pin * (unit -> unit)
  | Clear_pin_handler of pin * (unit -> unit)
  | Change_pin_handler of pin * (bool -> unit)
  | Setin_handler of (pin -> unit)
  | Setout_handler of (pin -> unit)
  | Setstate_handler of (pin -> bool -> unit)
  | Setin_pin_handler of pin * (unit -> unit)
  | Setout_pin_handler of pin * (unit -> unit)
  | Setstate_pin_handler of pin * (bool -> unit)

let handlers_mutex = Mutex.create ();;
let handlers = ref [];;

let add_handler handler =
  Mutex.lock handlers_mutex;
  handlers := handler :: !handlers;
  Mutex.unlock handlers_mutex;
;;

let remove_handler handler =
  Mutex.lock handlers_mutex;
  handlers := List.filter ((!=) handler) !handlers;
  Mutex.unlock handlers_mutex;
;;

(***)

let ports = [| 0 ; 0 ; 0 ; 0 ; 0 |];;
let triss = [| 0xFF ; 0xFF ; 0xFF ; 0xFF ; 0xFF |];;

let scall1 f arg =
  try Printexc.print f arg with _ -> ();
;;

let scall2 f arg1 arg2 =
  try Printexc.print (Printexc.print f arg1) arg2 with _ -> ();
;;

let exec input =
  match input with
    | IWrite (port, new_value) ->
      let index = index_of_port port in
      let old_value = ports.(index) in
      let lxor_values = old_value lxor new_value in
      let set_pins = ref [] in
      let clear_pins = ref [] in
      let () =
        for i = 0 to 7 do
          let mask = 1 lsl i in
          if lxor_values land mask <> 0 then
            if old_value land mask <> 0 then
              clear_pins := pin_of_port_index port i :: !clear_pins
            else
              set_pins := pin_of_port_index port i :: !set_pins
        done;
      in
      let set_pins = !set_pins in
      let clear_pins = !clear_pins in
      let call h =
        match h with
          | Write_handler f -> scall2 f port new_value;
          | Write_port_handler (p, f) -> if p = port then scall1 f new_value;
          | Set_handler f -> List.iter (scall1 f) set_pins;
          | Clear_handler f -> List.iter (scall1 f) clear_pins;
          | Change_handler f ->
            List.iter (fun p -> scall2 f p true) set_pins;
            List.iter (fun p -> scall2 f p false) clear_pins;
          | Set_pin_handler (p, f) ->
            List.iter (fun q -> if p = q then scall1 f ()) set_pins;
          | Clear_pin_handler (p, f) ->
            List.iter (fun q -> if p = q then scall1 f ()) clear_pins;
          | Change_pin_handler (p, f) ->
            List.iter (fun q -> if p = q then scall1 f true) set_pins;
            List.iter (fun q -> if p = q then scall1 f false) clear_pins;
          | _ -> ()
      in
      ports.(index) <- new_value;
      List.iter call !handlers;
      true
    | ITris (port, new_value) ->
      let index = index_of_port port in
      let old_value = ports.(index) in
      let lxor_values = old_value lxor new_value in
      let new_in_pins = ref [] in
      let new_out_pins = ref [] in
      let () =
        for i = 0 to 7 do
          let mask = 1 lsl i in
          if lxor_values land mask <> 0 then
            if old_value land mask <> 0 then
              new_out_pins := pin_of_port_index port i :: !new_out_pins
            else
              new_in_pins := pin_of_port_index port i :: !new_in_pins
        done;
      in
      let new_in_pins = !new_in_pins in
      let new_out_pins = !new_out_pins in
      let call h =
        match h with
          | Tris_handler f -> scall2 f port new_value;
          | Tris_port_handler (p, f) -> if p = port then scall1 f new_value;
          | Setin_handler f -> List.iter (scall1 f) new_in_pins;
          | Setout_handler f -> List.iter (scall1 f) new_out_pins;
          | Setstate_handler f ->
            List.iter (fun p -> scall2 f p true) new_in_pins;
            List.iter (fun p -> scall2 f p false) new_out_pins;
          | Setin_pin_handler (p, f) ->
            List.iter (fun q -> if p = q then scall1 f ()) new_in_pins;
          | Setout_pin_handler (p, f) ->
            List.iter (fun q -> if p = q then scall1 f ()) new_out_pins;
          | Setstate_pin_handler (p, f) ->
            List.iter (fun q -> if p = q then scall1 f true) new_in_pins;
            List.iter (fun q -> if p = q then scall1 f false) new_out_pins;
          | _ -> ()
      in
      triss.(index) <- new_value;
      List.iter call !handlers;
      true
    | ISync -> send ODone; true
    | IStop ->
      let call h = match h with Exit_handler f -> scall1 f () | _ -> () in
      List.iter call !handlers;
      false
;;

(***)

let (start, join) =
  let rec receive_loop () =
    let s = read_line () in
    match
      try Some (input_of_string s)
      with Invalid_argument _ ->
        Printf.eprintf "Invalid instruction: `%s'\n%!" s;
        None
    with
      | Some input -> if exec input then receive_loop ();
      | None -> receive_loop ();
  in
  let loop_thread_mutex = Mutex.create () in
  let loop_thread = ref None in
  let start () =
    Mutex.lock loop_thread_mutex;
    match !loop_thread with
      | Some _ ->
        Mutex.unlock loop_thread_mutex;
        failwith "invalid call to Simul.start, simulator already running";
      | None ->
        loop_thread := Some (Thread.create receive_loop ());
        Mutex.unlock loop_thread_mutex;
  and join () =
    Mutex.lock loop_thread_mutex;
    match !loop_thread with
      | None ->
        Mutex.unlock loop_thread_mutex;
        failwith "invalid call to Simul.join, simulator is not running";
      | Some th ->
        Mutex.unlock loop_thread_mutex;
        Thread.join th;
  in
  (start, join)
;;

(***)

let write_port port value = send (OWrite (port, value mod 256));;

let set_pin pin = send (OSet pin);;

let clear_pin pin = send (OClear pin);;

let change_pin pin b = send (if b then OSet pin else OClear pin);;

let read_port port = ports.(index_of_port port);;

let read_tris port = triss.(index_of_port port);;

let test_pin pin =
  let value = ports.(index_of_port (port_of_pin pin)) in
  let mask = 1 lsl (index_of_pin pin) in
  (value land mask) <> 0
;;

let state_pin pin =
  let value = triss.(index_of_port (port_of_pin pin)) in
  let mask = 1 lsl (index_of_pin pin) in
  (value land mask) <> 0
;;
