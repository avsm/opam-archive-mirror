(*************************************************************************)
(*                                                                       *)
(*                           Objective Caml                              *)
(*                                                                       *)
(*            Xavier Leroy, projet Cristal, INRIA Rocquencourt           *)
(*                                                                       *)
(*  Copyright 1996 Institut National de Recherche en Informatique et     *)
(*  en Automatique.  All rights reserved.  This file is distributed      *)
(*  under the terms of the GNU Library General Public License, with      *)
(*  the special exception on linking described in file ../OCaml-LICENSE. *)
(*                                                                       *)
(*************************************************************************)

(* $Id: int32.ml 7818 2007-01-30 09:34:36Z xleroy $ *)

(* Module [Int32]: 32-bit integers *)

external neg : int32 -> int32 = "%int32_neg"
external add : int32 -> int32 -> int32 = "%int32_add"
external sub : int32 -> int32 -> int32 = "%int32_sub"
external mul : int32 -> int32 -> int32 = "%int32_mul"
external div : int32 -> int32 -> int32 = "%int32_div"
external rem : int32 -> int32 -> int32 = "%int32_mod"
external logand : int32 -> int32 -> int32 = "%int32_and"
external logor : int32 -> int32 -> int32 = "%int32_or"
external logxor : int32 -> int32 -> int32 = "%int32_xor"
external shift_left : int32 -> int -> int32 = "%int32_lsl"
external shift_right : int32 -> int -> int32 = "%int32_asr"
external shift_right_logical : int32 -> int -> int32 = "%int32_lsr"
external of_int : int -> int32 = "%int32_of_int"
external to_int : int32 -> int = "%int32_to_int"

let zero = 0l
let one = 1l
let minus_one = -1l
let ten = 10l
let succ n = add n one
let pred n = sub n one
let abs n = if n >= zero then n else neg n
let min_int = 0x80000000l
let max_int = 0x7FFFFFFFl
let lognot n = logxor n minus_one

external unsafe_char_of_int : int -> char = "%identity"
external raise_ios : unit -> 'a = "caml_raise_ios_failure"

let to_string n =
  let str = String.create 11 in
  let rec f i k =
    if k < ten then begin
      str.[i] <- (unsafe_char_of_int (to_int k + int_of_char '0'));
      i
    end else begin
      str.[i] <- (unsafe_char_of_int (to_int (rem k ten) + int_of_char '0'));
      f (i - 1) (div k ten);
    end
  in
    if n >= zero then
      let b = f 10 n in String.sub str b (11 - b)
    else if n = min_int then
      let _ = f 10 max_int in
        str.[10] <- '8';
        str.[0] <- '-';
        str
    else
      let b = f 10 (neg n) - 1 in
        str.[b] <- '-';
        String.sub str b (11 - b)
;;

let of_string s =
  let len = String.length s in
  let rec gen_conv f i acc =
    if i = len then acc
    else gen_conv f (i + 1) (f acc s.[i])
  in
  let dec i =
    let dec_conv acc c =
      let ofs =
        match c with
          | '0' .. '9' -> int_of_char c - int_of_char '0'
          | _ -> raise_ios ()
      in
      let acc10 = mul acc ten in
      let res = add acc10 (of_int ofs) in
        if (div acc10 ten) <> acc || (sub res one) < minus_one then
          raise_ios ();
        res
    in
      gen_conv dec_conv i zero
  in
  let gen i =
    match s.[i] with
      | '0' ->
          if len = i + 1 then zero
          else begin match s.[i + 1] with
            | 'x' | 'X' ->
                if len = i + 2 then raise_ios ();
                let hex_conv acc c =
                  if shift_right_logical acc 28 <> zero then raise_ios ();
                  let ofs = match c with
                    | '0' .. '9' -> (int_of_char c - int_of_char '0')
                    | 'a' .. 'f' -> (int_of_char c - int_of_char 'a' + 10)
                    | 'A' .. 'F' -> (int_of_char c - int_of_char 'A' + 10)
                    | _ -> raise_ios ()
                  in
                    add (shift_left acc 4) (of_int ofs)
                in
                  gen_conv hex_conv (i + 2) zero
            | 'o' | 'O' ->
                if len = i + 2 then raise_ios ();
                let oct_conv acc c =
                  if shift_right_logical acc 29 <> zero then raise_ios ();
                  let ofs =
                    match c with
                      | '0' .. '7' -> int_of_char c - int_of_char '0'
                      | _ -> raise_ios ()
                  in
                    add (shift_left acc 3) (of_int ofs)
                in
                  gen_conv oct_conv (i + 2) zero
            | 'b' | 'B' ->
                if len = i + 2 then raise_ios ();
                let bin_conv acc c =
                  if acc < zero then raise_ios ();
                  match c with
                    | '0' -> shift_left acc 1
                    | '1' -> add (shift_left acc 1) one
                    | _ -> raise_ios ()
                in
                  gen_conv bin_conv (i + 2) zero
            | _ -> dec (i + 1)
          end
      | _ -> dec i
  in
    if len = 0 then raise_ios ();
    if s.[0] = '-' then if len = 1 then raise_ios () else neg (gen 1)
    else gen 0
;;

type t = int32

external compare : t -> t -> int = "caml_int32_compare"

(*
external of_float : float -> int32 = "caml_int32_of_float"
external to_float : int32 -> float = "caml_int32_to_float"
external bits_of_float : float -> int32 = "caml_int32_bits_of_float"
external float_of_bits : int32 -> float = "caml_int32_float_of_bits"
*)
