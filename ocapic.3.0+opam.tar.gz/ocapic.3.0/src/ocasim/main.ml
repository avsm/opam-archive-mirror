(*************************************************************************)
(*                                                                       *)
(*                                OCaPIC                                 *)
(*                                                                       *)
(*                             Benoit Vaugon                             *)
(*                                                                       *)
(*    This file is distributed under the terms of the CeCILL license.    *)
(*    See file ../../LICENSE-en.                                         *)
(*                                                                       *)
(*************************************************************************)

let error msg =
  Printf.eprintf "%s\n%!" msg;
  exit 1;
;;

if Array.length Sys.argv < 2 || not (Filename.check_suffix Sys.argv.(1) ".hex")
then
  error (Printf.sprintf "Usage: %s <file.hex> [ components ... ]" Sys.argv.(0));

Trigs.init ();;

try
  let filename = Sys.argv.(1) in
  let hexfile = Hexfile.parse filename in
  let flash = Flash.parse hexfile in
  let code = Code.parse flash in
  Interp.run flash.Flash.program code;
with Sys_error msg | Failure msg -> error ("Error: " ^ msg);
;;
