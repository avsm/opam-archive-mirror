(*************************************************************************)
(*                                                                       *)
(*                                OCaPIC                                 *)
(*                                                                       *)
(*                             Benoit Vaugon                             *)
(*                                                                       *)
(*    This file is distributed under the terms of the CeCILL license.    *)
(*    See file ../../LICENSE-en.                                         *)
(*                                                                       *)
(*************************************************************************)

let atom0_adr = 0xF88
let int32_custom_adr = 0x15E0
let int64_custom_adr = 0x15F0
let externals_anchor = 0x1600
let heap1_anchor = 0
