v0.1.1 2016-05-08 Cambridge (UK)
--------------------------------

- Fix `OS.Cmd` combinators on Linux. Thanks to Andreas Hauptmann for
  the help (#51)
- Fix `OS.Dir.delete` on Linux and Windows. Thanks to Andreas Hauptmann
  for the help (#50).
- Fix `OS.Cmd.exists` on Linux. Thanks to Andreas Hauptmann and
  Petter Urkedal for the help (#52).

v0.1.0 2016-05-23 La Forclaz (VS)
---------------------------------

First release.
