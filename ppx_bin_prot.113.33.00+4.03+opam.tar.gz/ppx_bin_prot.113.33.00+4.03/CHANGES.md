## 113.33.00+4.03

Various updates to work with OCaml 4.03.0

## 113.24.01

- Fix the META. ppx\_bin\_prot was not previously treated as a
  ppx\_deriving plugin, which was causing problems

## 113.24.00

- Minor changes, nothing worth mentionning.
