function lwt_unix_system_byte_order() {
  return 0;
}
