(* Eq for classes *)
class c = object end deriving (Eq)
