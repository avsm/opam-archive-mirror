module Make(Stream : Stoken.S) = struct

  include Pbase.Make(Stream)
  
  let last_position : Stream.Pos.t t = 
    stream >>= fun st ->
    return (match Stream.last_position st with
      | Some reg -> reg
      | None -> Stream.Pos.none)
  
  (** Efficient version of with_region *)
  let with_region merger t =
    last_position >>= fun last_bot_pos ->
    position      >>= fun last_top_pos ->
    t             >>= fun res -> 
    position      >>= fun top_pos ->
    last_position >>= fun bot_pos ->
    let pos = 
      if last_top_pos = top_pos then  (* CR jfuruse: implicitly using the equality of pos *)
        (* No advancement. OCaml's behaviour is: return the end of the last consumed position *)
        (* { last_bot_pos with start = last_bot_pos.end_ } *)
        `EndOf last_bot_pos
      else 
        (* { start = last_top_pos.start; end_ = bot_pos.end_ } *)
        `Between (last_top_pos, bot_pos)
    in
    (* \ assert (is_valid pos); *)
    return (res, merger pos)
  
end
