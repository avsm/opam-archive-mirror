(** Parser for Schar *)

module Base = Pbase.Make(Schar) (* Base parser *)
include Base
include Pbuffer.Extend(Schar)(Base) (* Extend Base with parser operators for buffered streams *)
