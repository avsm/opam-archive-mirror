let all_total  = ref 0
let all_wasted = ref 0
let total      = ref 0
let wasted     = ref 0
let top_ref    = ref (ref 0)
let stack      = ref [!top_ref]

let start () = 
  top_ref := ref 0;
  stack := !top_ref :: !stack

let stop () = 
  match !stack with
  | r::r'::rs -> 
      top_ref := r';
      stack := (r'::rs); 
      !r
  | _ -> assert false

let incr () =
  incr total;
  incr !top_ref

let add n =
  !top_ref := !(!top_ref) + n

let format ppf = 
  Format.fprintf ppf "Bind total %d, wasted %d, ratio %f"
    !total !wasted (float !wasted /. float !total)

let reset () =
  all_total := !all_total + !total;
  all_wasted := !all_wasted + !wasted;
  top_ref := ref 0;
  total := 0;
  wasted := 0;
  stack := [!top_ref]

let recover_all () =
  reset ();
  total := !all_total;
  wasted := !all_wasted


