open Test_helpers

let tests = compile_compare with_bisect "line-number-directive"
