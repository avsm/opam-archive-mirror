
int f_i0 ();
int f_i1 (int i0);
int f_i2 (int i0, int i1);
int f_i3 (int i0, int i1, int i2);
int f_i4 (int i0, int i1, int i2, int i3);
int f_i5 (int i0, int i1, int i2, int i3, int i4);
int f_i6 (int i0, int i1, int i2, int i3, int i4, int i5);
int f_i7 (int i0, int i1, int i2, int i3, int i4, int i5, int i6);
int f_i8 (int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7);
int f_i9 (int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8);
int f_i10 (int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9);
int f_i11 (int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10);
int f_i12 (int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11);
int f_i13 (int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12);
int f_i14 (int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13);
int f_i15 (int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14);

