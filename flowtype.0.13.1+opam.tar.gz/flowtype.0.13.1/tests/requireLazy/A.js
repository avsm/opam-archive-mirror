/**
 * @providesModule A
 * @flow
 */

module.exports = {
  numberValueA: 1,
  stringValueA: "someString"
};
