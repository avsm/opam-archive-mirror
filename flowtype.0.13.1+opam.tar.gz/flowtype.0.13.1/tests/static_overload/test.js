var x: number = StaticOverload.foo(0);
