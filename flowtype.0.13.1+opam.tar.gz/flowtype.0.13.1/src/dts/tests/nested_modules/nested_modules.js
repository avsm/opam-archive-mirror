// @flow
var M = require('M');
var P = require('P');

var a : string = P.a;
var cc = new M.C();
var x : string = cc.y;
