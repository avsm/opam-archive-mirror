declare module M {
    export var x: number
    export class C {
        y : typeof x
    }
}
