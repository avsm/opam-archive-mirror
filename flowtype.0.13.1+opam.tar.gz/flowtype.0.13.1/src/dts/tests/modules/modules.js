// @flow
var M = require('M');;

var x : M.C = new M.C();
var z : typeof M.x = x.y;
var m : string = z;
