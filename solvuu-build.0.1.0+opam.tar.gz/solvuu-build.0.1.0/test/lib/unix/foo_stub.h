#define K 42
