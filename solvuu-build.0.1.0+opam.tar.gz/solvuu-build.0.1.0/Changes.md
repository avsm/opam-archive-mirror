# solvuu-build release notes

## solvuu-build 0.1.0 2016-09-27
* Renamed project to solvuu-build instead of solvuu_build.
* Completely new API.
* Add high level documentation in README.

## solvuu-build 0.0.2 2016-02-23
* Support compilation of C files.
* Installation of each sub-library of a project now goes into its own
  sub-directory.

## solvuu-build 0.0.1 2016-02-15
* Initial release.
