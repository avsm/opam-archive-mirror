let y = A.x
