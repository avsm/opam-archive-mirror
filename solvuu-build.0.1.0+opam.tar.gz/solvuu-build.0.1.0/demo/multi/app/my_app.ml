open Printf
open My_project_async

let () = printf "B.y = %d\n" B.y
