open Printf
open My_project

let () = printf "B.y = %d\n" B.y
