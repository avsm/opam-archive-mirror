/**
 * @flow
 * @providesModule b
 */
require('./a');
