// @flow

let tests = [
  function(x: { [key: number]: string }) {
    (x[""]: number);
  }
];
