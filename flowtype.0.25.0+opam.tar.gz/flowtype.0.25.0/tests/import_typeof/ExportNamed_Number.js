/* @flow */

export var num = 42;
