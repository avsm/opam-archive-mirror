/* @flow */

module.exports = 42;
