// @flow

export var str = 'asdf';
export var num = 42;
