/* @flow */

export type talias1 = number;
export type talias2 = number;
export interface IFoo2 { prop: string };
