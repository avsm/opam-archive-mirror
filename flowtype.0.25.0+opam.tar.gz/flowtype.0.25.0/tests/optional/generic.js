function x<T>(x: T = 0) {}

class C {
  x<T>(x: T = 0) {}
}
