async function f(): Promise<number> {
  return Promise.resolve(1);
}
