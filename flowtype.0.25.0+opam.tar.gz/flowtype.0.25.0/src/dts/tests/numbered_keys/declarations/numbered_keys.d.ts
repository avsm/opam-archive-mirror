declare var x : {0: number; 1: string};
