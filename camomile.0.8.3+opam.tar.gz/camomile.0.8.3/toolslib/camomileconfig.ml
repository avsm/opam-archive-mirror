(* configuration for tools *)

let datadir = "./database"

let localedir = "./locales"

let charmapdir = "./charmaps"

let unimapdir = "./mappings"
