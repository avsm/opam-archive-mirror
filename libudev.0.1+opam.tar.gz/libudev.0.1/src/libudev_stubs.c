/* This is just here for ocamlbuild to generate a correct dlllibudev_stubs.so object */

void libudev_nop (void) { return; }
