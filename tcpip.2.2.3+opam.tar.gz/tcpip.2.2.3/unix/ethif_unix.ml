include Ethif.Make(Netif)
