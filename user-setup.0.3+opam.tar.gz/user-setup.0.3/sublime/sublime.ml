let name = "sublime"

let check () = false

let base_template = []

let base_setup = []

let files = []

let comment = (^) "# "

let tools = []
