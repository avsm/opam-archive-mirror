(* OASIS_START *)
(* DO NOT EDIT (digest: dfdbc6d29b58f96af9adcac7520322e2) *)
This is the README file for the cryptodbm distribution.

Encrypted layer over the dbm library: access to serverless, key-value
databases with symmetric encryption.

This library provides an encrypted layer on top of the Dbm and Cryptokit
packages. The improvements over Dbm are: - A single database file may contain
several independent subtables, identified by a name (a string). - Each
subtable can be signed and encrypted individually, or encrypted using a
common password. - The whole file can be signed. - Obfuscating data is
-optionally- appended to keys, data, and to the whole table, so that two
databases with   the same content look significantly different, once
encrypted. - Encryption is symmetric: encryption and decryption both use the
same password. - Signature is symmetric: signing and verifying the signature
both use the same signword.

See the files INSTALL.txt for building and installation instructions. 

Home page: http://cryptodbm.forge.ocamlcore.org/


(* OASIS_STOP *)
