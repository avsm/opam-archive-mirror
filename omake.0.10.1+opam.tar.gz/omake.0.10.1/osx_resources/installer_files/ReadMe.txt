This package installs OMake in the directories under /usr/local.  To use it you need to be sure that /usr/local/bin is in your PATH.

If you use bash, add the following to your ~/.bashrc file:
    export PATH=$PATH:/usr/local/bin

If you use csh or tcsh, add the following to your ~/.cshrc or ~/.tcshrc file:
    setenv PATH $PATH:/usr/local/bin

To get started with OMake, open your web browser to the URL:
    file://usr/local/share/doc/omake/html/index.html
