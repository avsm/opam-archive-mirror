

open Boot_top;;
Topdirs.dir_install_printer Format.std_formatter 
      (Longident.parse "Lm_location.pp_print_location");;
