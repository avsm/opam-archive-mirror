omake
=====

This is the new home of omake. Please see also the project page
at http://projects.camlcity.org/projects/omake.html for downloads,
and documentation.



