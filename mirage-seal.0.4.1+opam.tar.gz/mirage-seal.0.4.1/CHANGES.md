### 0.4.1 (2015-07-21)

* When serving https, send a HSTS header (#5, #16 by @hannesm)

### 0.4.0 (2015-07-17)

* Add redirection from HTTP to HTTPS (#5, #14 by @Drup)
* Add a Dockerfile

### 0.3.1 (2015-06-16)

* increase default memory to 32MB from 16 (#11, by @yomimono)

### 0.3.0 (2015-06-12)

* Add a `--no-tls` option to not use TLS to serve static files over HTTP only.
* Add Travis CI tests

### 0.2.0 (2015-06-02)

* Add content-type header to responses from sealed kernel (#7 by @mattgray)
* Support conduit 0.8.4

### 0.1.0 (2015-05-05)

* Initial release
