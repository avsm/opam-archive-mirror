open Spotlib.Spot

(** Type of the stream element *)
module type S = sig
  type t (** the element of the stream *)

  include Mtypes.Printable  with type t := t
  include Mtypes.Comparable with type t := t
end

module Char = struct
  type t = char
  let show = Printf.sprintf "%C"
  let format ppf = Format.fprintf ppf "%C"
  include Mtypes.Make_comparable(struct
    type t = char
    let compare (x : char) y = compare x y
  end)
end
