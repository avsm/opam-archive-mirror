SELECT strftime('%s','now');
