create table test1 (x1 integer not null, x2 integer);
-- @ins1
insert into test1 values;
-- @ins2
insert into test1 (x1,x2) values;
