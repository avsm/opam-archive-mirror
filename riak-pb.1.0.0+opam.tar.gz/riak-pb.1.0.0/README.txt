(* OASIS_START *)
(* DO NOT EDIT (digest: 93907016a339458d78de0f523102a70c) *)
This is the README file for the Riak OCaml Protobuffs distribution.

(C) 2012 Dave Parfitt

Protocol Buffers libraries for Riak

See the files INSTALL.txt for building and installation instructions. 


(* OASIS_STOP *)
